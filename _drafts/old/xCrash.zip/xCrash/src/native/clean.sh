#!/bin/bash

ndk-build -C ./libxcrash/jni clean
ndk-build -C ./libxcrash_dumper/jni clean
