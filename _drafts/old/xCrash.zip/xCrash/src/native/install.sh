#!/bin/bash

mkdir -p ../java/xcrash/xcrash_lib/libs/armeabi
mkdir -p ../java/xcrash/xcrash_lib/libs/armeabi-v7a
mkdir -p ../java/xcrash/xcrash_lib/libs/arm64-v8a
mkdir -p ../java/xcrash/xcrash_lib/libs/x86
mkdir -p ../java/xcrash/xcrash_lib/libs/x86_64

cp -f ./libxcrash/libs/armeabi/libfcrash.so     ../java/xcrash/xcrash_lib/libs/armeabi/libfcrash.so
cp -f ./libxcrash/libs/armeabi-v7a/libfcrash.so ../java/xcrash/xcrash_lib/libs/armeabi-v7a/libfcrash.so
cp -f ./libxcrash/libs/arm64-v8a/libfcrash.so   ../java/xcrash/xcrash_lib/libs/arm64-v8a/libfcrash.so
cp -f ./libxcrash/libs/x86/libfcrash.so         ../java/xcrash/xcrash_lib/libs/x86/libfcrash.so
cp -f ./libxcrash/libs/x86_64/libfcrash.so      ../java/xcrash/xcrash_lib/libs/x86_64/libfcrash.so

cp -f ./libxcrash_dumper/libs/armeabi/fcrash_dumper     ../java/xcrash/xcrash_lib/libs/armeabi/libfcrash_dumper.so
cp -f ./libxcrash_dumper/libs/armeabi-v7a/fcrash_dumper ../java/xcrash/xcrash_lib/libs/armeabi-v7a/libfcrash_dumper.so
cp -f ./libxcrash_dumper/libs/arm64-v8a/fcrash_dumper   ../java/xcrash/xcrash_lib/libs/arm64-v8a/libfcrash_dumper.so
cp -f ./libxcrash_dumper/libs/x86/fcrash_dumper         ../java/xcrash/xcrash_lib/libs/x86/libfcrash_dumper.so
cp -f ./libxcrash_dumper/libs/x86_64/fcrash_dumper      ../java/xcrash/xcrash_lib/libs/x86_64/libfcrash_dumper.so
