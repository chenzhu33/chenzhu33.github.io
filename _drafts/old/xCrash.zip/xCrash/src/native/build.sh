#!/bin/bash

ndk-build -C ./libxcrash/jni
ndk-build -C ./libxcrash_dumper/jni
