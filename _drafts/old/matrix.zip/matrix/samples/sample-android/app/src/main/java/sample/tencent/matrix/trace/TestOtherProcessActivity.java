package sample.tencent.matrix.trace;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;

public class TestOtherProcessActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
