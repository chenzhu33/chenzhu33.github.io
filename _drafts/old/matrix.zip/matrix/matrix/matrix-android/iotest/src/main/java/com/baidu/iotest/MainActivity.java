package com.baidu.iotest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.baidu.flywheel.io.FIOJniBridge;
import com.baidu.flywheel.io.NativeIOEvent;
import com.baidu.flywheel.io.OnJniIssuePublishListener;
import com.tencent.matrix.iocanary.config.IOConfig;
import com.tencent.mrs.plugin.IDynamicConfig;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        IDynamicConfig iDynamicConfig = new IDynamicConfig() {
            @Override
            public String get(String key, String defStr) {
                return defStr;
            }

            @Override
            public int get(String key, int defInt) {
                return defInt;
            }

            @Override
            public long get(String key, long defLong) {
                return defLong;
            }

            @Override
            public boolean get(String key, boolean defBool) {
                return defBool;
            }

            @Override
            public float get(String key, float defFloat) {
                return defFloat;
            }
        };

        FIOJniBridge.install(new IOConfig.Builder().dynamicConfig(iDynamicConfig).build(), new OnJniIssuePublishListener() {
            @Override
            public void onIssuePublish(List<NativeIOEvent> issues) {
                for (NativeIOEvent issue : issues) {
                    Log.e("tsds", issue.stack);
                }

            }
        });


        try {
            File file = new File(getExternalFilesDir("sda/x").getAbsolutePath() + "/io.log");
            if (!file.exists()) {
                file.createNewFile();
            }
            Log.e("sd","ds");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(5);
            fos.write("ds.ds".getBytes());
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
