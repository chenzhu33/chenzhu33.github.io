//
// Created by ghostshi on 2018/2/7.
//

#include <stdint.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#include "include/util.h"
#include "include/alog.h"

uintptr_t GetModuleBaseAddr(const char* module_name) {
    uintptr_t base_addr_long = 0;
    const char* file_name = "/proc/self/maps";
    FILE* fp = fopen(file_name, "r");
    char line[512];
    if (fp != NULL) {
        while(fgets(line, 512, fp) != NULL) {
            if (strstr(line, module_name) != NULL) {
                if (strstr(line, "deleted") == NULL) {
                    char* base_addr = strtok(line, "-");
                    base_addr_long = strtoul(base_addr, NULL, 16);
                } else{
                    ALOGE("find so base addr but the file is deleted, terminate for safe reason");
                }
                break;
            }
        }
        fclose(fp);
    } else {
        ALOGE("open maps file fail when GetModuleBaseAddr with %s", module_name);
    }
    return base_addr_long;
}