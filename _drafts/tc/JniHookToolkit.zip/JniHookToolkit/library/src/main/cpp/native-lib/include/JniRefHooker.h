//
// Created by hongpingwu on 2018/3/22.
//

#ifndef NATIVEMEMORY_JNIREFHOOKER_H
#define NATIVEMEMORY_JNIREFHOOKER_H

#include <jni.h>
#include <map>
#include <mutex>
#include <set>
#include "alog.h"
#include "../hookUtil/include/backtrace.h"

using namespace std;

class JniRefHooker {
    mutex refLock;
    int refCount = 0;
    bool refOverflowReport = false;
    map<BacktraceState*, set<jobject>, cmpFunc> refBacktrace;
    map<jobject, BacktraceState*> refRecord;
    size_t maxRef;
    size_t minRef;
    const char* tag;
    bool bLogOverflow = false;

public:
    JniRefHooker(size_t _maxRef, size_t _minRef, const char* _tag): maxRef(_maxRef), minRef(_minRef), tag(_tag) {}
    void addRef(JNIEnv* env, jobject ref);
    void deleteRef(JNIEnv* env, jobject ref);

    void dump(JNIEnv *pEnv);
};


#endif //NATIVEMEMORY_JNIREFHOOKER_H
