//
// Created by ghostshi on 2018/3/14.
//

#ifndef JNI_HOOK_TOOLKIT_MALLOC_HOOK_UTIL_H
#define JNI_HOOK_TOOLKIT_MALLOC_HOOK_UTIL_H

#include <stddef.h>
#include <list>
#include "../../include/util.h"
#include "../../include/tracker.h"
#include "hooker.h"

typedef struct {
    int64_t base_start_time_point;
    int64_t base_end_time_point;
    int64_t allocate_count;

    size_t last_allocate_size;
    //保证isOverAllocateCount函数里面没有临时变量
    int64_t current_time_us;
    struct timeval current_time;

    //如果本次time_slot上报过一次，就不再上报
    int is_report_this_time_slot;
} over_allocate_per_time_t;

class MallocHooker : public BaseHooker {
public:
    MallocHooker(NativeMonitor* monitor);

    void onInit(int n, ...) override final ;

    void beforeSoLoad(const char *library_path, jobject java_loader) override final ;

    void afterSoLoad(const char *library_path, jobject java_loader) override final ;
};

#endif //JNI_HOOK_TOOLKIT_MALLOC_HOOK_UTIL_H
