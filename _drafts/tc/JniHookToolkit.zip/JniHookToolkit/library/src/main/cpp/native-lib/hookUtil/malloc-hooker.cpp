//
// Created by ghostshi on 2018/3/14.
//

#include <malloc.h>
#include <string.h>
#include "include/malloc-hooker.h"
#include "../include/hook-lib.h"
#include "include/backtrace.h"
#include "../include/native-monitor.h"
#include <unordered_map>

static BaseHooker* mallocHookerPtr = nullptr;

int64_t SIZE_LIMITED = 2000L;
int64_t PER_TIME_LIMITED = 1000000L; //us单位
int64_t ALLOCATE_LIMITED = 1000;

pthread_key_t g_per_time_key;
int64_t g_over_allocate_per_time_switch;
int64_t g_big_allocate_switch;

typedef struct {
    int64_t count = 0;
    int64_t start_time = 0;
} count_time_t;

class LRUCache {
private:
    int capacity;
    list<pair<BacktraceState*, count_time_t>> recent;
    map<BacktraceState*, list<pair<BacktraceState*,count_time_t>>::iterator, cmpFunc> pos;
//    unordered_map<int, list<pair<int, int>>::iterator> pos;  //value存储的是一个迭代器
public:
    LRUCache(int capacity) : capacity(capacity) {}
    int get(BacktraceState** key, count_time_t * value) {
        map<BacktraceState*, list<pair<BacktraceState*, count_time_t>>::iterator>::iterator it = pos.find(*key);
        if (it != pos.end()){
            //如果找到之前对应的迭代器，需要把现在的key给detele掉.
            delete(*key);
            //然后用之前迭代器对应key，去更新，放到队头
            *key=it->first;
            put(*key, pos[*key]->second);
            *value = pos[*key]->second;
            return 1;
        }
        return 0;
    }

    void put(BacktraceState* key, count_time_t value) {
        if (pos.find(key) != pos.end()) {
            recent.erase(pos[key]);
//            delete (key);
        } else if (recent.size() >= capacity) {
            //淘汰最近最少使用的item，然后把相关的key给delete掉
            pos.erase(recent.back().first);
            recent.pop_back();
            delete (recent.back().first);
        }
        recent.push_front({ key, value });
        //指向对应的迭代器
        pos[key] = recent.begin();
    }

};

//保证没有函数调用
inline int isOverAllocateCount(size_t current_alloc_size) {
    LRUCache *tmp = (LRUCache*) pthread_getspecific(g_per_time_key);
    if(!tmp) {
        tmp = new LRUCache(10);
        pthread_setspecific(g_per_time_key,(void *) tmp);
        tmp = (LRUCache*) pthread_getspecific(g_per_time_key);
    }
    BacktraceState *backtraceState = capturePC(2);
    if(backtraceState){
        count_time_t count_and_time;
        int result = tmp->get(&backtraceState, &count_and_time);
        struct timeval current_time;
        gettimeofday(&current_time,NULL);
        uint64_t current_time_us = 1000000L * current_time.tv_sec + current_time.tv_usec ;
        if(!result) { //没找到
            count_time_t new_count_time;
            new_count_time.count = 1;
            new_count_time.start_time = current_time_us;
            tmp->put(backtraceState,new_count_time);
            return 0;
        } else  {
            if(((current_time_us - count_and_time.start_time) < PER_TIME_LIMITED) &&
               count_and_time.count > ALLOCATE_LIMITED ) {  //超出限制了
                count_and_time.count = 1; //重置，不然会一直上报
                tmp->put(backtraceState,count_and_time);
                return 1;
            } else { //未超限制
                count_and_time.count++;
                count_and_time.start_time = current_time_us;
                tmp->put(backtraceState,count_and_time);
                return 0;
            }
        }
    }
    return 0;
}

//perThread的变量后面要锁毁
void pthread_destruction(void *arg) {
//    over_allocate_per_time_t * tmp = (over_allocate_per_time_t*)arg;
//    ALOGD("allocate_count:%lld",tmp->allocate_count);
//    free(tmp);
    LRUCache * tmp = (LRUCache*)arg;
    delete(tmp);
}

extern "C" {
void *(*originMalloc)(size_t);

void* hookedMalloc(size_t size);

void* hookedMalloc(size_t size) {
//    ALOGI("every time tmp:%lld, %lld,%lld", SIZE_LIMITED, PER_TIME_LIMITED, ALLOCATE_LIMITED);
//    mallocHookerPtr->talkBeforeOriginFuncCalled("malloc", 0, 1, &size);
    void* ptr = originMalloc(size);
//    mallocHookerPtr->talkAfterOriginFuncCalled("malloc", 0, &ptr, 1, &size);
//    ALOGI("hooked malloc");
    if( g_big_allocate_switch && size > SIZE_LIMITED ) {
        BacktraceState *backtraceState = capturePC(1);
        if(backtraceState){
            int isAttachedThread = 0;
            JNIEnv *env = getJniEnv(&isAttachedThread);
            report(env,"BigMallocCatchedException",backtraceState, size);
            delete(backtraceState);
            if(isAttachedThread) {
                _detach_current_thread();
            }
        }
    }

//    ALOGIJAVA("%s","OverAllocatePerTimeCatchedException ");
    if ( g_over_allocate_per_time_switch && isOverAllocateCount(size)) {
        BacktraceState *backtraceState = capturePC(1);
        if(backtraceState){
            int isAttachedThread = 0;
            JNIEnv *env = getJniEnv(&isAttachedThread);

            report(env,"OverAllcatePerTimeCatchedException",backtraceState, PER_TIME_LIMITED,ALLOCATE_LIMITED );
            ALOGIJAVA("%s","OverAllocatePerTimeCatchedException ");
            delete(backtraceState);
            if(isAttachedThread) {
                _detach_current_thread();
            }
        }
    }

    return ptr;
}
}



void MallocHooker::onInit(int n, ...) {
    mallocHookerPtr = this;
    pthread_t tid =  pthread_self();
    ALOGIJAVA("MallocHooker init:%ld", tid);
    int64_t feature =NativeMonitor::getInstance().getFeasure();
    g_big_allocate_switch = feature & NativeMonitor::FLAG_LARGE_OBJECT_ALLOC_MONITOR;
    g_over_allocate_per_time_switch = feature & NativeMonitor::FLAG_OVER_ALLOCATE_PER_TIME_MONITOR;
    if(g_big_allocate_switch) {
        ALOGIJAVA("%s","big_allocate hooked");
    }
    if(g_over_allocate_per_time_switch) {
        ALOGIJAVA("%s","over_allocate_per_time hooked");
    }

    SIZE_LIMITED = NativeMonitor::getInstance().getMemoryLimited();
    PER_TIME_LIMITED = NativeMonitor::getInstance().getTimeLimited();
    ALLOCATE_LIMITED = NativeMonitor::getInstance().getCountLimited();
    //防止没有detach，这里把判断下之前有没有atach_thread
    int res = pthread_key_create(&g_per_time_key, pthread_destruction);
    if(res == 0) {
        ALOGIJAVA("thread_key_create success:%ld", tid);
        ALOGD("tid:%d thread_key_create sucess",tid);
    } else {
        ALOGIJAVA("tid:%d thread_key_create error, errcode:%d", tid, res);
        ALOGE("tid:%d thread_key_create error, errcode:%d",tid, res);
    }
}

void MallocHooker::beforeSoLoad(const char *library_path, jobject java_loader) {
    // do nothing
}

void MallocHooker::afterSoLoad(const char *library_path, jobject java_loader) {
    originMalloc = malloc;
    int ret = hookFunc(library_path, "malloc", (void *)originMalloc, (void *) hookedMalloc);
    if (ret > 0) {
        ALOGEJAVA("hook malloc in %s with error code: %d", library_path, ret);
    }
}

MallocHooker::MallocHooker(NativeMonitor* monitor) : BaseHooker("MallocHooker", monitor) {

}


