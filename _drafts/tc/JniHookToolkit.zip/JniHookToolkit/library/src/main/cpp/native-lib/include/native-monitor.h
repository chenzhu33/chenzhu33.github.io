//
// Created by ghostshi on 2018/3/13.
//

#ifndef JNI_HOOK_TOOLKIT_NATIVE_MONITOR_H
#define JNI_HOOK_TOOLKIT_NATIVE_MONITOR_H

#include <list>
#include <memory>
#include <unordered_set>
#include <jni.h>
#include <mutex>
#include "tree-node.h"
#include "util.h"
#include "read-write-lock.h"

class BaseTracker;

typedef std::shared_ptr<BaseTracker> BaseTrackerPtr;

class BaseHooker;

typedef std::shared_ptr<BaseHooker> BaseHookerPtr;

class LongSetFieldHooker;
class NativeThreadHooker;

class NativeMonitor {
public:
    static const int64_t FLAG_OVER_ALLOCATE_PER_TIME_MONITOR =  1LL << 31;
    static const int64_t FLAG_LARGE_OBJECT_ALLOC_MONITOR = 1LL << 32;

    static NativeMonitor& getInstance();

    int64_t getFeasure();
    int64_t getTimeLimited();
    int64_t getCountLimited();
    int64_t getMemoryLimited();

    void startSoLoadHook(JNIEnv *env, jclass javaClass,
                         const char *applicationId, const char *nativeLibDir);

    void start(JNIEnv *env, jclass javaClass, jlong featureFlag,
               jlong timeLimited, jlong countLimited, jlong memoryLimited);

    void beforeSoLoad(const char *library_path, jobject java_loader);

    void afterSoLoad(const char *library_path, jobject java_loader);

    void talkOnTopic(BaseHooker* hooker, std::string topic, FuncParamType& funcParam);

    void subscribeTopic(std::string topic, BaseTracker* tracker);

    int containsInSoWhiteList(std::string);

    void insert2SoWhiteList(std::string);

    void setAllSoHooked(int isOrNot);

    void hookLongSetField(JNIEnv* env);

    BaseHooker* getLocalRefHooker();
    int getSdkInt() const ;
    void dump(JNIEnv *) const;
    bool dumpUndetachThreads(std::ostringstream &os);

private:
    std::mutex mTrackerMutex;
    std::list<BaseTrackerPtr> mAllTrackers;
    /// hooker 列表，不支持运行时修改
    std::list<BaseHookerPtr> mAllHookers;
    LongSetFieldHooker* longSetFieldHooker;
    BaseHooker* pLocalRefHooker;
    NativeThreadHooker* nativeThreadHooker;

    //白名单
    std::unordered_set<std::string> mSoWhiteList;

    WfirstRWLock mTrackerTreeLock;
    TreeNodePtr mPathRoot;
    int64_t mFeatureFlag;

    /**
     * 全部so都打开，但是必须是上层传下来的malloc hook开关打开的情况下才有用
     */
    int mIsAllSoHooked = 0;

    int64_t mTimeLimited;
    int64_t mCountLimited;
    int64_t mMemoryLimited;

    std::string mApplicationId;
    std::string mNativeLibDir;

    std::mutex mSoPassedSetMutex;
    std::unordered_set<std::string> mSoPassedSoLoad;

    int sdkInt = 0;

    void setupTracker(JNIEnv* env, jclass clazz);

    void setupHooker(JNIEnv* env, jclass clazz);

    void init(JNIEnv* env);
    void initSdkInt(JNIEnv* env);

    bool isFeatureOn(JNIEnv* env, jclass clazz, std::string featureName);

    NativeMonitor(){}
    NativeMonitor(const NativeMonitor &) = delete;
    NativeMonitor& operator = (const NativeMonitor &) = delete;
};
#endif //JNI_HOOK_TOOLKIT_NATIVE_MONITOR_H
