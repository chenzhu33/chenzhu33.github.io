//
// Created by ghostshi on 2018/3/14.
//

#include "include/hooker.h"
#include "../include/alog.h"

std::string BaseHooker::getTalkTopicNamespace() {
    return mName;
}

void BaseHooker::talkMessage(std::string topicName, FuncParamType& funcParam) {
    mMonitor->talkOnTopic(this, topicName, funcParam);
}

void BaseHooker::talkBeforeOriginFuncCalled(std::string funcName, void* callerAddr, int paramNum, ...) {
    va_list args;
    va_start(args, paramNum);

    std::vector<void *> paramPtrList;

    for (int i = 0; i < paramNum; ++i) {
        void* paramPtr = va_arg(args, void*);
        paramPtrList.emplace_back(paramPtr);
    }

    va_end(args);

    FuncParamType funcParam = {
            nullptr,
            paramNum,
            paramPtrList,
            callerAddr
    };

    talkMessage(funcName + "/" + "before", funcParam);
}

void
BaseHooker::talkAfterOriginFuncCalled(std::string funcName, void* callerAddr, void *retValuePtr, int paramNum, ...) {
    va_list args;
    va_start(args, paramNum);

    std::vector<void *> paramPtrList;

    for (int i = 0; i < paramNum; ++i) {
        void* paramPtr = va_arg(args, void*);
        paramPtrList.emplace_back(paramPtr);
    }

    va_end(args);

    FuncParamType funcParam = {
            retValuePtr,
            paramNum,
            paramPtrList,
            callerAddr
    };

    talkMessage(funcName + "/" + "after", funcParam);
}

void BaseHooker::beforeSoLoad(const char *library_path, jobject java_loader) {

}

void BaseHooker::afterSoLoad(const char *library_path, jobject java_loader) {

}

