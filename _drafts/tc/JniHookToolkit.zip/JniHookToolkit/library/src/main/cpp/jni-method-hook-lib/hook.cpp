//
// Created by ghostshi on 2018/3/14.
//

#include "include/hook.h"
#include "include/alog.h"

uintptr_t globalOffset = 0;

void checkAndClearException(JNIEnv *env);

bool initJniMethodHook(JNIEnv *env, jmethodID jmethodID1, jmethodID  jmethodID2, void *jniFuncPtr) {
    if (globalOffset > 0) {
        ALOGI("jni method hook lib has already been initJniMethodHook.");
        return true;
    }

    if (jniFuncPtr == nullptr) {
        ALOGE("jniFuncPtr is null");
        return false;
    }

    if (jmethodID1 == nullptr) {
        ALOGE("jmethodId1 is null");
        return false;
    }

    if (jmethodID2 == nullptr) {
        ALOGE("jmethodId2 is null");
        return false;
    }

    intptr_t offsetToFind = reinterpret_cast<intptr_t >(jmethodID2) - reinterpret_cast<intptr_t >(jmethodID1);

    if (offsetToFind < 0) {
        offsetToFind = -offsetToFind;
    }
    if (offsetToFind > MAX_OFFSET_TO_FIND) {
        offsetToFind = MAX_OFFSET_TO_FIND;
    }

    ALOGI("offsetToFind to find is %d", offsetToFind);

    for(uintptr_t curOffset = 0; curOffset < offsetToFind; curOffset += sizeof(void*)) {
        uintptr_t curAddr = reinterpret_cast<uintptr_t >(jmethodID1) + curOffset;
        if ((*reinterpret_cast<void **>(curAddr)) == jniFuncPtr) {
            globalOffset = curOffset;
            ALOGI("find the native func ptr, the offset is %ld", curOffset);
            break;
        }
    }

    if (globalOffset == 0) {
        ALOGE("can not find jni method in this artmethod object");
    }

    return globalOffset > 0;
}

bool hookJniMethod(JNIEnv* env, const char* className, const char* methodName, const char* methodSignature, void* replacedFunc, void** originFuncPtr) {
    if (globalOffset == 0) {
        ALOGE("hook before init or initJniMethodHook fail");
        return false;
    }

    jclass clazz = env->FindClass(className);
    checkAndClearException(env);
    if (clazz == nullptr) {
        ALOGE("class %s not found", className);
        return false;
    }

    jmethodID nativeMethod = env->GetStaticMethodID(clazz, methodName, methodSignature);
    checkAndClearException(env);
    if (nativeMethod == nullptr) {
        ALOGW("can not find static method %s[%s], try to find it as instance method", methodName, methodSignature);
        nativeMethod = env->GetMethodID(clazz, methodName, methodSignature);
        checkAndClearException(env);
    }

    if (nativeMethod == nullptr) {
        ALOGE("can not find static/instance method %s[%s]", methodName, methodSignature);
        return false;
    }

    void** targetFuncPtr = reinterpret_cast<void **>(reinterpret_cast<uintptr_t >(nativeMethod) + globalOffset);
    *originFuncPtr = *targetFuncPtr;

    *targetFuncPtr = replacedFunc;

    return true;
}

void checkAndClearException(JNIEnv *env) {
    if (env->ExceptionCheck()) {
        // env->ExceptionDescribe();
        env->ExceptionClear();
    }
}


