//
// Created by ghostshi on 2018/3/13.
//

#include <sys/time.h>
#include "include/tracker.h"
#include "include/alog.h"
#include "hookUtil/include/backtrace.h"

LogAllTracker::LogAllTracker(NativeMonitor* monitor) : BaseTracker("LogAllTracker", monitor) {

}

std::vector<std::string> LogAllTracker::topicToSubscribe() {
    return {"/"};
}

void LogAllTracker::onMessage(std::string topic, FuncParamType& funcParam) {
    ALOGD("[LogAllTracker][%s][parameter count: %d]", topic.c_str(), funcParam.paramCount);
}

BaseTracker::BaseTracker(std::string name, NativeMonitor* monitor) : mName(name), mMonitor(monitor) {

}

void BaseTracker::onInit() {
    for (auto topic : topicToSubscribe()) {
        mMonitor->subscribeTopic(topic, this);
    }
}


//BaseMallocTracker::BaseMallocTracker(NativeMonitor* monitor)
//        : BaseTracker("MallocHooker", monitor) {
//    ALOGD("tracker name MallocHooker init");
//
//}

//void  BaseMallocTracker::onInit() {
//    BaseTracker::onInit();
//    ALOGD("hooked malloc onInit");
//    struct sigaction sigact;
//    sigact.sa_sigaction = BaseMallocTracker::sigactionHandler;
//    sigemptyset(&sigact.sa_mask);
//    sigact.sa_flags = SA_SIGINFO;
//    sigNumber = signalNumberFromString(getenv("LEAKTRACER_ONSIG_STARTALLTHREAD"));
//    __sigStartAllThread = sigNumber;
//    sigaction(SIGUSR1, &sigact, NULL);
//}

//void BaseMallocTracker::sigactionHandler(int sigNumber, siginfo_t *siginfo, void *arg)
//{
//    (void)siginfo;
//    (void)arg;
//    if (sigNumber == 1)
//    {
//        ALOGD("hooked malloc sigactionHandler");
//    }
//}

//std::vector<std::string> BaseMallocTracker::topicToSubscribe() {
//    return {"/MallocHooker/malloc/"};
//}

//void BaseMallocTracker::onMessage(std::string topic, FuncParamType& funcParam) {
//    ALOGD("onMessageMalloc:%s",topic.c_str());
//    if(topic == "/MallocHooker/malloc/before") {
//    } else if(topic == "/MallocHooker/malloc/after") {
//        ALOGI("hooked malloc after");
//        char** retValuePtr = (char**)funcParam.retValuePtr;
//        char* ptr = *retValuePtr;
//        size_t * malloc_size = static_cast<size_t*>(funcParam.getParamAtIdx(0));
//        ALOGD("hooked malloc add size:%d %p", *malloc_size, ptr);
//        ALOGD("hooked malloc:%s", backtrace->c_str());
//        ALOGD("hooked malloc size :%d", *malloc_size);
//        if(*malloc_size > getMallocBigSize()) {
//            BacktraceState *backtraceState = capturePC(6);
//            JNIEnv *env = getJniEnv();
//            malloc_report(env,"MALLOC_BIG",backtraceState);
//            delete(backtraceState);
//            std::string *log = getBacktrace(backtraceState->pc, backtraceState->size);
//            ALOGD("hooked big size malloc:%s", log->c_str());
//            delete(log);
//        }

//        if(isOverAllocateCount()) {
//            BacktraceState *backtraceState = capturePC();
//            JNIEnv *env = getJniEnv();
//            malloc_report(env,"MALLOC_OVER_ALLOCATE",backtraceState);
//            delete(backtraceState);
//            std::string *log = getBacktrace(backtraceState->pc, backtraceState->size);
//            ALOGD("hooked overCountAllocate malloc:%s", log->c_str());
//            delete(log);
//        }
//    }
//}

//int BaseMallocTracker::getMallocBigSize() {
//    return malloc_big_size;
//}

//int BaseMallocTracker::isOverAllocateCount() {
//    struct timeval current_time;
//    gettimeofday(&current_time,NULL);
//    unsigned long current_time_us = 1000000 * current_time.tv_sec + current_time.tv_usec ;
//
//    if(base_start_time_point == -1 ||
//       base_end_time_point == -1 ||
//       current_time_us > base_end_time_point) {
//        base_end_time_point = current_time_us;
//        base_end_time_point = base_start_time_point + PER_TIME_LIMITED;
//        allocate_count = 1;
//    } else if(current_time_us > base_start_time_point && current_time_us < base_end_time_point) {
//        allocate_count ++;
//    }
//
//    if(allocate_count >= ALLOCATE_LIMITED) {
//        return 1;
//    } else {
//        return 0;
//    }
//}


//BaseFreeTracker::BaseFreeTracker(NativeMonitor* monitor) : BaseTracker(
//        "FreeHookder", monitor) {
//    ALOGD("tracker name FreeHooker init");
//}

//std::vector<std::string> BaseFreeTracker::topicToSubscribe() {
//    return {"/FreeHooker/free/"};
//}

//void BaseFreeTracker:: onMessage(std::string topic, FuncParamType& funcParam) {
//    ALOGD("onMessageFree:%s",topic.c_str());
//    if(topic == "/FreeHooker/free/before") {
//        ALOGD("hooked free before");
//    } else if(topic == "/FreeHooker/free/after") {
//        ALOGD("hooked free after");
//    }
//}

