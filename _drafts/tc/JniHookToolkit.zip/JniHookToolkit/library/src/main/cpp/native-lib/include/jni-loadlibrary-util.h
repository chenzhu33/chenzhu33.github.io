//
// Created by ghostshi on 2018/3/14.
//

#ifndef JNI_HOOK_TOOLKIT_JNI_LOADLIBRARY_UTIL_H
#define JNI_HOOK_TOOLKIT_JNI_LOADLIBRARY_UTIL_H

#include <jni.h>
#include <string>

extern jstring (*originNativeLoad)(JNIEnv*, jclass, jstring, jobject, jstring);

extern jstring (*originNativeLoad_9_0)(JNIEnv*, jclass, jstring, jobject);

jstring JNICALL
hookedRuntimeNativeLoad(JNIEnv* env, jclass ignored, jstring javaFilename,
                   jobject javaLoader, jstring javaLibrarySearchPath);

jstring JNICALL
hookedRuntimeNativeLoad_9_0(JNIEnv* env, jclass ignored, jstring javaFilename,
                        jobject javaLoader);

void JNICALL
jniMethodToMark(JNIEnv*, jobject);

std::string FindLibrary(JNIEnv *env, jobject javaLoader, const char *name);

bool IsSystemSo(const char *so_path);

#endif //JNI_HOOK_TOOLKIT_JNI_LOADLIBRARY_UTIL_H
