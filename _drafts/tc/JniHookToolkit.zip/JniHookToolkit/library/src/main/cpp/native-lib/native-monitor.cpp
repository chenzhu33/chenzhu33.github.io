//
// Created by ghostshi on 2018/3/13.
//

#include <list>
#include <algorithm>
#include <inttypes.h>
#include <unistd.h>
#include "include/native-monitor.h"
#include "include/tracker.h"
#include "hookUtil/include/malloc-hooker.h"
#include "hookUtil/include/free-hooker.h"
#include "../jni-method-hook-lib/include/hook.h"
#include "include/alog.h"
#include "include/jni-loadlibrary-util.h"
#include "include/GlobalRefHooker.h"
#include "include/CheckJNIHooker.h"
#include "include/LocalRefHooker.h"
#include "include/PrimitiveArrayHooker.h"
#include "include/LongSetFieldHooker.h"
#include "include/WeakGlobalRefHooker.h"
#include "include/NativeThreadHooker.h"
#include "include/so_load_hooker.h"
#include <absl/strings/match.h>

constexpr int N = 24;

void NativeMonitor::startSoLoadHook(JNIEnv *env, jclass javaClass,
        const char *applicationId, const char *nativeLibDir) {
    mApplicationId = applicationId;
    mNativeLibDir = nativeLibDir;
    initSdkInt(env);

    if(sdkInt >= N) {
        auto hooker = new SoLoadHooker(this, mNativeLibDir, env, javaClass);
        mAllHookers.emplace_back(hooker);
    }
}

void NativeMonitor::start(JNIEnv *env, jclass javaClass, jlong featureFlag,
                          jlong timeLimited, jlong countLimited, jlong memoryLimited) {
    mFeatureFlag = featureFlag;
    mTimeLimited = timeLimited;
    mCountLimited = countLimited;
    mMemoryLimited = memoryLimited;

    initSdkInt(env);
    setupHooker(env, javaClass);
    setupTracker(env, javaClass);
    init(env);
    ALOGIJAVA("%s %lld %lld", "NativeMonitor started", timeLimited, countLimited);
}

void NativeMonitor::setupTracker(JNIEnv* env, jclass clazz) {
    std::lock_guard<std::mutex> lockGuardTracker(mTrackerMutex);

    if (isFeatureOn(env, clazz, "FLAG_LOG_ALL")) {
        mAllTrackers.emplace_back(new LogAllTracker(this));
    }
//    mAllTrackers.emplace_back(new NewGlobalRefTracker(NativeMonitor*(this)));
//    mAllTrackers.emplace_back(new DeleteGlobalRefTracker(NativeMonitor*(this)));
//    mAllTrackers.emplace_back(new NewLocalRefTracker(NativeMonitor*(this)));
//    mAllTrackers.emplace_back(new DeleteLocalRefTracker(NativeMonitor*(this)));
//    mAllTrackers.emplace_back(new FindClassTracker(NativeMonitor*(this)));
//    mAllTrackers.emplace_back(new NewObjectVTracker(NativeMonitor*(this)));
//    mAllTrackers.emplace_back(new NewObjectATracker(NativeMonitor*(this)));
//    mAllTrackers.emplace_back(new GetObjectClassTracker(NativeMonitor*(this)));
}

void NativeMonitor::setupHooker(JNIEnv* env, jclass clazz) {
//    if(isFeatureOn(env,clazz, "FLAG_JNI_LONG_SET_FIELD_MONITOR")) {
//        mAllHookers.emplace_back(new LongSetFieldHooker(this));
//    }
    if (isFeatureOn(env, clazz, "FLAG_LARGE_OBJECT_ALLOC_MONITOR") || isFeatureOn(env, clazz, "FLAG_OVER_ALLOCATE_PER_TIME_MONITOR")) {
        mAllHookers.emplace_back(new MallocHooker(this));
    }
//    if (isFeatureOn(env, clazz, "FLAG_LARGE_OBJECT_ALLOC_MONITOR")) {
//        mAllHookers.emplace_back(new FreeHooker(this));
//    }
    if (isFeatureOn(env, clazz, "FLAG_JNI_LOCAL_REF_MONITOR")) {
        pLocalRefHooker = new LocalRefHooker(this);
        mAllHookers.emplace_back(pLocalRefHooker);
    }
    if (isFeatureOn(env, clazz, "FLAG_JNI_GLOBAL_REF_MONITOR")) {
        mAllHookers.emplace_back(new GlobalRefHooker(this));
    }
    if (isFeatureOn(env, clazz, "FLAG_JNI_PRIMITIVE_ARRAY_MONITOR")) {
        // dalvik才需要监控
        mAllHookers.emplace_back(new PrimitiveArrayHooker(this));
    }
    if(isFeatureOn(env, clazz, "FLAG_JNI_WEAK_GLOBAL_REF_MONITOR")){
        mAllHookers.emplace_back(new WeakGlobalRefHooker(this));
    }

    if (isFeatureOn(env, clazz, "FLAG_JNI_CALLXXMETHOD_MONITOR")) {
        mAllHookers.emplace_back(new CheckJNIHooker(this));
    }

    if(isFeatureOn(env, clazz, "FLAG_JNI_NATIVE_THREAD_MONITOR")){
        nativeThreadHooker = new NativeThreadHooker(this);
        mAllHookers.emplace_back(nativeThreadHooker);
    }
}

void NativeMonitor::init(JNIEnv *env) {
    std::lock_guard<std::mutex> lockGuardTracker(mTrackerMutex);
    mPathRoot.reset(new TreeNode(""));

    initBacktraceTool(env);

    // setlongfield的hook时机被剥离，导致线程不安全，在hooker里调用setlongfield时要注意
    for(BaseHookerPtr &hooker : mAllHookers){
        hooker->beforeHook(1, env);
    }

    for (BaseHookerPtr &hooker : mAllHookers) {
        hooker->onInit(1, env);
    }

    for (BaseTrackerPtr &tracker : mAllTrackers) {
        tracker->onInit();
    }

    ALOGI("NativeMonitor::init finished");
}

void NativeMonitor::initSdkInt(JNIEnv *env) {
    if (sdkInt == 0) {
        jclass versionClass = env->FindClass("android/os/Build$VERSION");
        jfieldID sdkIntFieldID = env->GetStaticFieldID(versionClass, "SDK_INT", "I");
        sdkInt = env->GetStaticIntField(versionClass, sdkIntFieldID);
        env->DeleteLocalRef(versionClass);
    }
}

void NativeMonitor::beforeSoLoad(const char *library_path, jobject java_loader) {
    for (BaseHookerPtr &hooker : mAllHookers) {
        hooker->beforeSoLoad(library_path, java_loader);
    }
}

void NativeMonitor::afterSoLoad(const char *library_path, jobject java_loader) {
    std::string libraryPath(library_path);
    {
        std::lock_guard<mutex> soPassedSetGuard(mSoPassedSetMutex);
        const bool isInSet = mSoPassedSoLoad.find(libraryPath) != mSoPassedSoLoad.end();
        if (isInSet) {
            // ALOGD("NativeMonitor::afterSoLoad: %s but it is already processed", library);
            return;
        } else{
            mSoPassedSoLoad.insert(libraryPath);
        }
    }

    if (absl::StartsWith(libraryPath, "/data/user/0")) {
        std::string libDirByUser = "/data/user/0/" + mApplicationId + "/lib";
        if (absl::StartsWith(libraryPath, libDirByUser)) {
            libraryPath = libraryPath.replace(0, libDirByUser.size(), mNativeLibDir);
        } else {
            libraryPath = libraryPath.replace(0, 12, "/data/data");
        }
        // ALOGE("origin lib path is %s and replaced by %s", library_path, libraryPath.c_str());
    }

    ALOGIJAVA("NativeMonitor::afterSoLoad: %s", library_path);
    for (BaseHookerPtr &hooker : mAllHookers) {
        hooker->afterSoLoad(libraryPath.c_str(), java_loader);
    }
}

NativeMonitor &NativeMonitor::getInstance() {
    static NativeMonitor instance;
    return instance;
}

static void splitString(const std::string& s, std::vector<std::string>& v, const std::string& c)
{
    std::string::size_type pos1, pos2;
    pos2 = s.find(c);
    pos1 = 0;
    while(std::string::npos != pos2)
    {
        v.push_back(s.substr(pos1, pos2-pos1));

        pos1 = pos2 + c.size();
        pos2 = s.find(c, pos1);
    }
    if(pos1 != s.length())
        v.push_back(s.substr(pos1));
}

static inline void ltrim(std::string &s) {
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), [](int ch) {
        return !std::isspace(ch);
    }));
}

// trim from end (in place)
static inline void rtrim(std::string &s) {
    s.erase(std::find_if(s.rbegin(), s.rend(), [](int ch) {
        return !std::isspace(ch);
    }).base(), s.end());
}

// trim from both ends (in place)
static inline void trim(std::string &s) {
    ltrim(s);
    rtrim(s);
}

static inline void nomorizePath(std::string &input) {
    trim(input);

    if ("/" != input) {
        input.erase(std::find_if(input.rbegin(), input.rend(), [](char ch) {
            return '/' != ch;
        }).base(), input.end());
    }
}

void NativeMonitor::talkOnTopic(BaseHooker* hooker, std::string topic, FuncParamType& funcParam) {
    nomorizePath(topic);

    topic = "/" + hooker->getTalkTopicNamespace() + "/" + topic;

//    ALOGI("talkOnTopic: %s", topic.c_str());

    std::vector<std::string> paths;

    splitString(topic, paths, "/");

    UniqueReadguard<WfirstRWLock> readGuard(mTrackerTreeLock);

    TreeNodePtr cur = nullptr;
    std::string curSearchPath = "";
    for (std::string pathSegment : paths) {
        TreeNodePtr next = nullptr;
        if ("" == pathSegment) {
            next = mPathRoot;
        } else{
            curSearchPath += "/" + pathSegment;
            auto curPair = cur->subPathList.find(pathSegment);
            if (curPair != cur->subPathList.end()) {
                next = curPair->second;
            }
        }

        if (nullptr == next) {
//            ALOGW("no tracker subscribe the topic: %s", curSearchPath.c_str());
            break;
        } else {
            for (BaseTrackerPtr tracker : next->trackers) {
                ALOGD("tracker name:%s",tracker->mName.c_str());
                tracker->onMessage(topic, funcParam);
            }
        }

        cur = next;
    }
}

void NativeMonitor::subscribeTopic(std::string topic, BaseTracker* tracker) {
    ALOGI("subscribe topic %s", topic.c_str());
    nomorizePath(topic);

    if (topic.find("/") != 0) {
        return;
    }

    std::vector<std::string> paths;

    splitString(topic.substr(1, topic.length() - 1), paths, "/");

    UniqueWriteguard<WfirstRWLock> writeGuard(mTrackerTreeLock);

    TreeNodePtr cur = mPathRoot;

    for (std::string pathSegment : paths) {
        auto curPair = cur->subPathList.find(pathSegment);
        if (curPair == cur->subPathList.end()) {
            TreeNodePtr newTreeNodePtr(new TreeNode(pathSegment));
            newTreeNodePtr->father = cur;
            cur->subPathList[pathSegment] = newTreeNodePtr;
            cur = newTreeNodePtr;
        } else {
            cur = curPair->second;
        }
    }
    cur->trackers.emplace_back(tracker);
}

bool NativeMonitor::isFeatureOn(JNIEnv *env, jclass clazz, std::string featureName) {
    jfieldID fieldId = env->GetStaticFieldID(clazz, featureName.c_str(), "J");
    int64_t flag;
    if (fieldId == 0) {
        ALOGEJAVA("can not find field %s to check feature",  featureName.c_str());
        return false;
    }

    flag = env->GetStaticLongField(clazz, fieldId);
    //这里要加括号，否则优先级不对
    if ((mFeatureFlag & flag) > 0) {
        ALOGIJAVA("feature %s is on due to the flag %" PRId64, featureName.c_str(), mFeatureFlag);
        return true;
    }

    ALOGIJAVA("feature %s is off due to the flag %" PRId64, featureName.c_str(), mFeatureFlag);

    return false;
}

int64_t NativeMonitor::getFeasure() {
    return mFeatureFlag;
}

int64_t NativeMonitor::getTimeLimited() {
    return mTimeLimited;
}

int64_t NativeMonitor::getCountLimited() {
    return mCountLimited;
}

int64_t NativeMonitor::getMemoryLimited() {
    return mMemoryLimited;
}

int NativeMonitor::containsInSoWhiteList(std::string soTotalPathName) {
    //如果所有的so都要hook就不去白名单里面找了，都返回1
    if(mIsAllSoHooked) {
        ALOGD("[malloc hook]all so hook");
        ALOGIJAVA("%s","[malloc hook]all so hook");
        return 1;
    } else {
        if(mSoWhiteList.find(soTotalPathName) != mSoWhiteList.end()) {
            ALOGD("[malloc hook]hook:%s", soTotalPathName.c_str());
            ALOGIJAVA("[malloc hook]hook:%s", soTotalPathName.c_str());
            return 1;
        } else {
            ALOGE("[malloc hook]hook not find in so Whitee list:%s",soTotalPathName.c_str());
            ALOGEJAVA("[malloc hook]hook not find in so Whitee list:%s",soTotalPathName.c_str());
            return 0;
        }
    }
}

void NativeMonitor::insert2SoWhiteList(std::string soTotalPathName) {
    mSoWhiteList.insert(soTotalPathName);
}

void NativeMonitor::setAllSoHooked(int isOrNot) {
    mIsAllSoHooked = isOrNot;
}

void NativeMonitor::hookLongSetField(JNIEnv* env) {
    if(longSetFieldHooker != NULL){
        return;
    }
    longSetFieldHooker = new LongSetFieldHooker(this);
    longSetFieldHooker->beforeHook(1, env);
    longSetFieldHooker->onInit(1, env);
}

BaseHooker* NativeMonitor::getLocalRefHooker() {
    return this->pLocalRefHooker;
}

int NativeMonitor::getSdkInt() const {
    return sdkInt;
}

void NativeMonitor::dump(JNIEnv *env) const {
    // dispatch dump to sub module
    for (BaseHookerPtr hooker : mAllHookers) {
        hooker->dump(env);
    }
}

bool NativeMonitor::dumpUndetachThreads(std::ostringstream &os) {
    return nativeThreadHooker == NULL ? false : nativeThreadHooker->dumpUndetachThreads(os);
}
