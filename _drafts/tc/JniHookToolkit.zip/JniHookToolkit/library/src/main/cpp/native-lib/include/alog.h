//
// Created by ghostshi on 2018/2/6.
//

#ifndef GOTHOOKLIBRARY_ALOG_H_H
#define GOTHOOKLIBRARY_ALOG_H_H

#include <android/log.h>
#include <jni.h>

#define PROJECT_NAME "JniHookToolkit"

//#define YOU_SHOULD_PRINT_ALOG

#ifdef YOU_SHOULD_PRINT_ALOG
#define ALOGV(...) __android_log_print(ANDROID_LOG_VERBOSE, PROJECT_NAME, __VA_ARGS__)
#else
#define ALOGV(...)
#endif

#ifdef YOU_SHOULD_PRINT_ALOG
#define ALOGD(...) __android_log_print(ANDROID_LOG_DEBUG , PROJECT_NAME, __VA_ARGS__)
#else
#define ALOGD(...)
#endif

#ifdef YOU_SHOULD_PRINT_ALOG
#define ALOGI(...) __android_log_print(ANDROID_LOG_INFO  , PROJECT_NAME, __VA_ARGS__)
#else
#define ALOGI(...)
#endif

#ifdef YOU_SHOULD_PRINT_ALOG
#define ALOGW(...) __android_log_print(ANDROID_LOG_WARN  , PROJECT_NAME, __VA_ARGS__)
#else
#define ALOGW(...)
#endif

#define ALOGE(...) __android_log_print(ANDROID_LOG_ERROR  , PROJECT_NAME, __VA_ARGS__)

void logErrorToJava(const char* fmt, ...);

void logInfoToJava(const char* fmt, ...);

extern JNIEnv* getJniEnv(int *isAttachThread);
extern void _detach_current_thread();

#define ALOGEJAVA(fmt, ...) logErrorToJava(fmt, __VA_ARGS__)
#define ALOGIJAVA(fmt, ...) logInfoToJava(fmt, __VA_ARGS__)

#endif //GOTHOOKLIBRARY_ALOG_H_H
