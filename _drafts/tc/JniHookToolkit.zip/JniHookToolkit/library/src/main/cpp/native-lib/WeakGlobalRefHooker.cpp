//
// Created by hongpingwu on 2018/4/24.
//

#include "include/WeakGlobalRefHooker.h"
#include <jni.h>
#include "hookUtil/include/jni-func-hook-util.h"
#include "hookUtil/include/QJNIInterface.h"
#include "include/alog.h"
#include "hookUtil/include/backtrace.h"
#include "include/JniRefHooker.h"

#define MAX_WEAK_GLOBAL_REF 48000
#define MIN_WEAK_GLOBAL_REF 1000
#define TAG "WeakGlobalRefOverFlowCatchedException"

using namespace std;

//static GlobalRefHooker* hookerPtr;
static JniRefHooker* refHooker = nullptr;

jobject (*NewWeakGlobalRefOrigin)(JNIEnv*, jobject);
void (*DeleteWeakGlobalRefOrigin)(JNIEnv*, jobject);

static jobject weak_global_ref_hook(JNIEnv *env, jobject target) {
//    hookerPtr->talkBeforeOriginFuncCalled("NewGlobalRef", 0, 2, env, target);
    jobject obj = NewWeakGlobalRefOrigin(env, target);
    refHooker->addRef(env, obj);
//    hookerPtr->talkAfterOriginFuncCalled("NewGlobalRef", 0, obj, 2, env, target);
    return obj;
}

static void delete_weak_global_ref_hook(JNIEnv *env, jobject target) {
//    hookerPtr->talkBeforeOriginFuncCalled("DeleteGlobalRef", 0, 2, env, target);
    DeleteWeakGlobalRefOrigin(env, target);
    refHooker->deleteRef(env, target);
//    hookerPtr->talkAfterOriginFuncCalled("DeleteGlobalRef", 0, NULL, 2, env, target);
}

WeakGlobalRefHooker::WeakGlobalRefHooker(NativeMonitor* monitor) : BaseHooker("WeakGlobalRefHooker", monitor) {

}

void WeakGlobalRefHooker::beforeHook(int n, ...){
    va_list args;
    va_start(args, n);
    JNIEnv* env = va_arg(args, JNIEnv*);
    va_end(args);
    JNINativeInterface *structPtr = const_cast<JNINativeInterface *>(env->functions);

    DeleteWeakGlobalRefOrigin = structPtr->DeleteWeakGlobalRef;
    NewWeakGlobalRefOrigin = structPtr->NewWeakGlobalRef;
}

void WeakGlobalRefHooker::onInit(int n, ...) {
//    hookerPtr = this;
    refHooker = new JniRefHooker(MAX_WEAK_GLOBAL_REF, MIN_WEAK_GLOBAL_REF, TAG);

    // hook jni
    va_list args;
    va_start(args, n);
    JNIEnv* env = va_arg(args, JNIEnv*);
    va_end(args);
    JNINativeInterface *structPtr = const_cast<JNINativeInterface *>(env->functions);
    replaceJniEnvFunction((void **) &(structPtr->DeleteWeakGlobalRef),
                          (void *) delete_weak_global_ref_hook);
    replaceJniEnvFunction((void **) &(structPtr->NewWeakGlobalRef), (void *) weak_global_ref_hook);

    ALOGIJAVA("%s", "WeakGlobalRef is hooked");
}

void WeakGlobalRefHooker::dump(JNIEnv *env) {
    ALOGD("WeakGlobalRefHooker::dump");
    refHooker->dump(env);
    dumpReferenceTable(env);
}
