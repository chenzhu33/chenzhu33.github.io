//
// Created by ghostshi on 2018/3/15.


#include <sys/user.h>
#include <sys/mman.h>
#include <sys/errno.h>
#include <string.h>
#include <inttypes.h>
#include "../include/alog.h"

static inline bool make_mem_writable(void *p) {
    uintptr_t pageStart = reinterpret_cast<uintptr_t >(p) & PAGE_MASK;
    ALOGI("try to mprotect 0x%" PRIuPTR ", 0x%p", pageStart, p);
    int res = mprotect((void *) pageStart, PAGE_SIZE, PROT_WRITE | PROT_READ);
    if (res == -1) {
        int err = errno;
        ALOGE("%d", err);
        ALOGE("%s", strerror(err));
        return false;
    }

    return true;
}

void replaceJniEnvFunction(void **originFuncPtr, void *replacedFunc) {
    if (!make_mem_writable(originFuncPtr)) {
        ALOGE("make mem writable fail at %p", originFuncPtr);
    }

    *originFuncPtr = replacedFunc;
}

void dumpReferenceTable(JNIEnv *env) {
    // todo cache jclass to reduce reflect cost
    jclass vm_class = env->FindClass("dalvik/system/VMDebug");
    if(env->ExceptionCheck()){
        env->ExceptionDescribe();
        env->ExceptionClear();
    }
    if(vm_class == 0)
        return;

    jmethodID dump_mid = env->GetStaticMethodID(vm_class, "dumpReferenceTables", "()V");
    if(env->ExceptionCheck()){
        env->ExceptionDescribe();
        env->ExceptionClear();
    }
    if (dump_mid == 0)
        return;

    env->CallStaticVoidMethod(vm_class, dump_mid);
}
