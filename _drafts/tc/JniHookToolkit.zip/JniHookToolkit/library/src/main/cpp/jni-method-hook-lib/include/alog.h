//
// Created by ghostshi on 2018/2/6.
//

#ifndef GOTHOOKLIBRARY_JNI_METHOD_HOOK_ALOG_H_H
#define GOTHOOKLIBRARY_JNI_METHOD_HOOK_ALOG_H_H

#include <android/log.h>

#define PROJECT_NAME "JNIMethodHookLib"

//#define YOU_SHOULD_PRINT_ALOG

#ifdef YOU_SHOULD_PRINT_ALOG
#define ALOGV(...) __android_log_print(ANDROID_LOG_VERBOSE, PROJECT_NAME, __VA_ARGS__)
#else
#define ALOGV(...)
#endif

#ifdef YOU_SHOULD_PRINT_ALOG
#define ALOGD(...) __android_log_print(ANDROID_LOG_DEBUG , PROJECT_NAME, __VA_ARGS__)
#else
#define ALOGD(...)
#endif

#ifdef YOU_SHOULD_PRINT_ALOG
#define ALOGI(...) __android_log_print(ANDROID_LOG_INFO  , PROJECT_NAME, __VA_ARGS__)
#else
#define ALOGI(...)
#endif

#ifdef YOU_SHOULD_PRINT_ALOG
#define ALOGW(...) __android_log_print(ANDROID_LOG_WARN  , PROJECT_NAME, __VA_ARGS__)
#else
#define ALOGW(...)
#endif

#ifdef YOU_SHOULD_PRINT_ALOG
#define ALOGE(...) __android_log_print(ANDROID_LOG_ERROR  , PROJECT_NAME, __VA_ARGS__)
#else
#define ALOGE(...)
#endif

#endif //GOTHOOKLIBRARY_JNI_METHOD_HOOK_ALOG_H_H
