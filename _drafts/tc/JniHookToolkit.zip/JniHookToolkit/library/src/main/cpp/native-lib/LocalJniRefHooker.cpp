//
// Created by hongpingwu on 2018/3/22.
//

#include "include/LocalJniRefHooker.h"
#include "include/native-monitor.h"

// Extract the table index from an indirect reference.
static uint32_t ExtractIndex(jobject iref) {
    uintptr_t uref = reinterpret_cast<uintptr_t>(iref);
    // 采用位计算，快速读取间接引用对象在数组中的下标，时间复杂度是 O(1)
    // 如果采用遍历的方式是 O(n)
    // 右移两位，取低 16 位数据
    uint32_t index = uref >> 4;
    if (NativeMonitor::getInstance().getSdkInt() < 26)
        index = (uref >> 2) & 0xffff;
    return index;
}

size_t SegmentStateOffset(size_t pointer_size) {
    size_t locals_offset = pointer_size +  // functions pointer
                           2 * pointer_size +          // Thread* self + JavaVMExt* vm.
                           4 +                         // local_ref_cookie.
                           (pointer_size - 4);         // Padding.
    return locals_offset;
}

uint32_t SegmentState(JNIEnv *env) {
    size_t segmentStateOffset = SegmentStateOffset(sizeof(void *));
    char *pBase = ((char *) env);
    uint32_t *pSegmentState = reinterpret_cast<uint32_t *>(pBase + (uint32_t) segmentStateOffset);
    return *pSegmentState;
}

union IRTSegmentState {
    uint32_t all;
    struct {
        // 8.0 开始 topIndex 占 32 位，无 numHoles
        uint32_t topIndex:16;            /* index of first unused entry */
        uint32_t numHoles:16;            /* #of holes in entire table */
    } parts;
};

int GetCurrentTopIndex(JNIEnv *env) {
    IRTSegmentState state;
    state.all = SegmentState(env);
    int topIndex = state.all;
    if (NativeMonitor::getInstance().getSdkInt() < 26) {
        topIndex = state.parts.topIndex;
    }
    return topIndex;
}

void LocalJniRefHooker::addRef(JNIEnv *env, jobject ref) {
//    ALOGI("this = %p, %s , ref = %p", this, __FUNCTION__, ref);

    if (!ref) {
        return;
    }

    std::ostringstream *os = NULL;

    removeItemsBelowTopIndex(env);
    setLastTopIndex(GetCurrentTopIndex(env));

    if (refRecord.size() > maxRef + 1000) {
        if (!bLogOverflow){
            bLogOverflow = true;
            ALOGE("JNIRef %s %s", "too many ref records, skip", __FUNCTION__);
        }
        return;
    }

    bLogOverflow = false;

    auto iterator = refRecord.find(ref);
    if (iterator != refRecord.end()) {
        return;
    }

    AddRefRecord *pRecord = (AddRefRecord *) (malloc(sizeof(AddRefRecord)));
    if (!pRecord) {
        ALOGE("%s , malloc AddRefRecord fail", __FUNCTION__);
        return;
    }

    BacktraceState *trace = capturePC(2);
    if(!trace)
        return;
    map<BacktraceState *, set<jobject>>::iterator it = refBacktrace.find(trace);

    if (it != refBacktrace.end()) {
        delete (trace);
        trace = it->first;
    }
    refBacktrace[trace].insert(ref);

    pRecord->pTrace = trace;
    pRecord->ref = ref;
        pRecord->topIndex = GetCurrentTopIndex(env);
        pRecord->index = ExtractIndex(ref);
    refRecord.insert(std::pair<jobject, AddRefRecord *>(ref, pRecord));

    if (refBacktrace.size() > refRecord.size())
        ALOGE("%s , refBacktrace.size = %d > refCount = %d", __FUNCTION__, refBacktrace.size(),
              refRecord.size());

    int currentTopIndex = GetCurrentTopIndex(env);
    if (currentTopIndex > maxRef && !refOverflowReport) {
        refOverflowReport = true;
        os = new std::ostringstream();
        *os << "reference table overflow with limit: " << currentTopIndex << ", total call stacks: "
            << refBacktrace.size() << ", the top traces are: \n";
        getTopBacktrace(refBacktrace, *os);
    } else if (currentTopIndex < minRef) {
        refOverflowReport = false;
    }


    if (os) {
        report(env, tag, os->str().c_str());
        delete os;
    }
}

void LocalJniRefHooker::deleteRef(JNIEnv *env, jobject ref) {
    if (!ref)
        return;

    auto it = refRecord.find(ref);
    if (it != refRecord.end())
        removeItem(it->second);
}

void LocalJniRefHooker::removeItemsBelowTopIndex(JNIEnv *env) {
    int currentTopIndex = GetCurrentTopIndex(env);
//    ALOGI("this = %p, %s currentTop = %d , lastTop = %d", this, __FUNCTION__,
//          currentTopIndex, lastTopIndex);

    if (currentTopIndex >= lastTopIndex) {
        // no need to pop top items
        // if there are holes in the middle area the topIndex will equal to last value
        return;
    }

//    ALOGI("this = %p, %s reference size = %d", this, __FUNCTION__, refRecord.size());
    // iterate and remove
    int remove = 0;
    for (auto it = refRecord.cbegin(); it != refRecord.cend();) {
        AddRefRecord *record = it->second;
//        ALOGI("this = %p, %s item index = %d, top = %d", this, __FUNCTION__, record->index,
//              record->topIndex);
        if (record->topIndex < currentTopIndex) {
            ++it;
            continue;
        }

        it++;
        removeItem(record);
        remove++;
    }
//    ALOGI("this = %p, %s , remove count %d, remains = %d", this, __FUNCTION__, remove,
//          refRecord.size());
}

void LocalJniRefHooker::setLastTopIndex(const int lastTopIndex) {
    this->lastTopIndex = lastTopIndex;
}

void LocalJniRefHooker::removeItem(AddRefRecord *pRecord) {
    refRecord.erase(pRecord->ref);

    // remove from the backtrace set
    set<jobject> &objSet = refBacktrace[pRecord->pTrace];
    objSet.erase(pRecord->ref);
//        ALOGI("this = %p, %s remove %p reference from Backtrace %p size = %d", this,
//              __FUNCTION__, pRecord->ref, pRecord->pTrace, objSet->size());

    if (objSet.size() == 0) {
        refBacktrace.erase(pRecord->pTrace);

        delete (pRecord->pTrace);
    }

    pRecord->pTrace = NULL;
    free(pRecord);
}