//
// Created by hongpingwu on 2018/3/22.
//

#include "include/JniRefHooker.h"

void JniRefHooker::addRef(JNIEnv* env, jobject ref) {
    if(!ref)
        return;

    std::ostringstream* os = NULL;
    BacktraceState* trace = capturePC(2);
    if(!trace)
        return;

    // 用于控制 lock 的作用域
    {
        std::lock_guard<std::mutex> lock(refLock);

        if (refRecord.size() > maxRef + 1000) {
            if (!bLogOverflow){
                bLogOverflow = true;
                ALOGE("JNIRef %s %s", "too many ref records, skip", __FUNCTION__);
            }
            return;
        }

        bLogOverflow = false;

        if (refRecord.find(ref) != refRecord.end()) {
            return;
        }
        refCount++;

        map<BacktraceState *, set<jobject>>::iterator it = refBacktrace.find(trace);
        if (it != refBacktrace.end()) {
            delete (trace);
            trace = it->first;
        }
        refBacktrace[trace].insert(ref);
        if (refCount > maxRef && !refOverflowReport) {
            refOverflowReport = true;
            os = new std::ostringstream();
            *os << "reference table overflow with limit: " << refCount << ", total call stacks: "
                << refBacktrace.size() << ", the top traces are: \n";
            getTopBacktrace(refBacktrace, *os);
        } else if (refCount < minRef) {
            refOverflowReport = false;
        }
        refRecord.insert(std::make_pair(ref, trace));
    }

    if(os){
        report(env, tag, os->str().c_str());
        delete os;
    }
}

void JniRefHooker::deleteRef(JNIEnv* env, jobject ref) {
    if(!ref)
        return;

    std::lock_guard<std::mutex> lock(refLock);

    map<jobject , BacktraceState*>::iterator it = refRecord.find(ref);
    if (it == refRecord.end()){
        return;
    }

    BacktraceState *trace = it->second;
    if(trace) {
        map<BacktraceState*, set<jobject>>::iterator iterator = refBacktrace.find(trace);
        if (iterator != refBacktrace.end()){
            set<jobject> &objSet = iterator->second;
            objSet.erase(ref);
            if (objSet.size() == 0) {
                refBacktrace.erase(trace);
                delete (trace);
            }
        }
    }

    refRecord.erase(ref);
    refCount = refCount <= 0 ? 0 : refCount - 1;
}

void JniRefHooker::dump(JNIEnv *pEnv) {
    std::lock_guard<std::mutex> lock(refLock);
    ALOGE("JniRefHooker refCount = %d, maxRef= %d, refBacktrace.size = %d", refCount, maxRef, refBacktrace.size());
}
