//
// Created by hongpingwu on 2018/3/20.
//

#ifndef NATIVEMEMORY_LOCALREFTRACKER_H
#define NATIVEMEMORY_LOCALREFTRACKER_H


#include "tracker.h"
#include <string.h>

class NewLocalRefTracker : public BaseTracker {
public:
    NewLocalRefTracker(NativeMonitor* monitor)
            : BaseTracker("NewLocalRefTracker", monitor) {}

    std::vector <std::string> topicToSubscribe() override final;

    void onMessage(std::string topic, FuncParamType &funcParam) override final;

};

class DeleteLocalRefTracker : public BaseTracker {
public:
    DeleteLocalRefTracker(NativeMonitor* monitor)
            : BaseTracker("DeleteLocalRefTracker", monitor) {}

    std::vector <std::string> topicToSubscribe() override final;

    void onMessage(std::string topic, FuncParamType &funcParam) override final;
};

class FindClassTracker : public BaseTracker {
public:
    FindClassTracker(NativeMonitor* monitor)
            : BaseTracker("FindClassTracker", monitor) {}

    std::vector <std::string> topicToSubscribe() override final;

    void onMessage(std::string topic, FuncParamType &funcParam) override final;
};

class NewObjectVTracker : public BaseTracker {
public:
    NewObjectVTracker(NativeMonitor* monitor)
            : BaseTracker("NewObjectVTracker", monitor) {}

    std::vector <std::string> topicToSubscribe() override final;

    void onMessage(std::string topic, FuncParamType &funcParam) override final;
};

class NewObjectATracker : public BaseTracker {
public:
    NewObjectATracker(NativeMonitor* monitor)
            : BaseTracker("NewObjectATracker", monitor) {}

    std::vector <std::string> topicToSubscribe() override final;

    void onMessage(std::string topic, FuncParamType &funcParam) override final;
};

class GetObjectClassTracker : public BaseTracker {
public:
    GetObjectClassTracker(NativeMonitor* monitor)
            : BaseTracker("GetObjectClassTracker", monitor) {}

    std::vector <std::string> topicToSubscribe() override final;

    void onMessage(std::string topic, FuncParamType &funcParam) override final;
};

#endif //NATIVEMEMORY_LOCALREFTRACKER_H
