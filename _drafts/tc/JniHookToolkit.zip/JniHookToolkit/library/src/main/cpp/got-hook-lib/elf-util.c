//
// Created by ghostshi on 2018/2/6.
//

#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <sys/user.h>
#include <sys/errno.h>
#include <sys/mman.h>
#include <stdbool.h>
#include <elf.h>
#include <unistd.h>
#include <inttypes.h>
#include "include/elf-util.h"
#include "include/alog.h"
#include "include/util.h"

FILE *OpenElfFile(const char *library_path) {
    if (library_path != NULL) {
        ALOGD("Open ELF file: %s\n", library_path);
        FILE *fp = fopen(library_path, "r");
        return fp;
    }
    return NULL;
}

void CloseElfFile(FILE *elf_file) {
    if (elf_file != NULL) {
        ALOGD("Close ELF file\n");
        fclose(elf_file);
    }
}

void make_mem_writable(void *p) {
    uintptr_t pageStart = (size_t) (p) & PAGE_MASK;
    ALOGI("try to mprotect %lx, %lx", pageStart, (uintptr_t)p);
    int res = mprotect((void *) pageStart, PAGE_SIZE, PROT_WRITE | PROT_READ);
    if (res == -1) {
        int err = errno;
        ALOGE("fail to set mem writable %d, %s", err, strerror(err));
    }
}

static ElfN_Phdr* findSegmentByType(struct ElfInfo* info, const ElfN_Word type){
    ElfN_Phdr *target = NULL;
    ElfN_Phdr *phdr = info->phdr;

    for(int i = 0; i < info->ehdr->e_phnum; i++){
        if(phdr[i].p_type == type){
            target = phdr + i;
            break;
        }
    }

    return target;
}

#define SAFE_SET_VALUE(t, v) if(t) *(t) = (v)
static void getSegmentInfo(struct ElfInfo* info, const ElfN_Word type, ElfN_Phdr **ppPhdr, ElfN_Word *pSize, uintptr_t *data){
    ElfN_Phdr *_phdr = findSegmentByType(info, type);

    if(_phdr){
        SAFE_SET_VALUE(data, info->load_bias + _phdr->p_vaddr);
        SAFE_SET_VALUE(pSize, _phdr->p_memsz);
    }else{
        ALOGE("[-] Could not found segment type is %d\n", type);
        return;
    }

    SAFE_SET_VALUE(ppPhdr, _phdr);
}

static inline bool getElfHeader(struct ElfInfo* info) {
    ALOGD("got elf header");
    info->ehdr = (ElfN_Ehdr *)(info->elf_base);

    if (info->ehdr->e_phoff > sizeof(ElfN_Ehdr) + 0x10 || info->ehdr->e_phoff < 0) {
        ALOGE("Illegal phdr offset %x", info->ehdr->e_phoff);
        return false;
    }

    if (info->ehdr->e_shoff < 0) {
        ALOGE("Illegal shdr offset %x", info->ehdr->e_shoff);
        return false;
    }

    return true;
}

static inline void getSectionAndSegmentTable(struct ElfInfo* info) {
    info->shdr = (ElfN_Shdr *)(info->elf_base + info->ehdr->e_shoff);
    info->phdr = (ElfN_Phdr *)(info->elf_base + info->ehdr->e_phoff);

    ALOGI("addr of shdr is %p, offset is %x", info->shdr, info->ehdr->e_shoff);
    ALOGI("addr of phdr is %p, offset is %x", info->phdr, info->ehdr->e_phoff);
}

bool getShstrtabContent(struct ElfInfo* info, FILE *elf_file, char **shstrtab_content) {
    if (elf_file == NULL || info == NULL) {
        return false;
    }
    ElfN_Ehdr *elf_header = info->ehdr;
    ElfN_Off shstrtab_header_offset =
            elf_header->e_shoff + elf_header->e_shstrndx * sizeof(ElfN_Shdr);
    // 字符表偏移 shstrtab = section header string table
    ALOGD("shstrtab header offset: %x\n", shstrtab_header_offset);
    ElfN_Shdr *shstrtab_header = (ElfN_Shdr *) malloc(sizeof(ElfN_Shdr));
    fseek(elf_file, (long) shstrtab_header_offset, SEEK_SET);
    fread(shstrtab_header, sizeof(ElfN_Shdr), 1, elf_file);
    ElfN_Off shstrtab_base_offset = shstrtab_header->sh_offset;
    size_t shstrtab_size = shstrtab_header->sh_size;
    ALOGD("shstrtab base offset: %x, shstrtab size: %x\n", shstrtab_base_offset,
          shstrtab_size);
    free(shstrtab_header);

    if (shstrtab_base_offset <= 0 || shstrtab_size <= 0 || shstrtab_size > INT_MAX) {
        return false;
    }

    if (*shstrtab_content == NULL) {
        *shstrtab_content = (char *) malloc(shstrtab_size * sizeof(char));
    } else {
        *shstrtab_content = (char *) realloc(shstrtab_content, shstrtab_size * sizeof(char));
    }

    fseek(elf_file, (long) shstrtab_base_offset, SEEK_SET);
    fread(*shstrtab_content, shstrtab_size, 1, elf_file);

    return true;
}

static bool getGotInfoFromSectionHeader(struct ElfInfo *info, FILE *elfFile) {
    if (elfFile == NULL || info == NULL) {
        return false;
    }
    size_t section_count = info->ehdr->e_shnum;
    ElfN_Off section_header_offset = info->ehdr->e_shoff;
    char *shstrtab_content = NULL;

    bool getShstrtabRes = getShstrtabContent(info, elfFile, &shstrtab_content);
    if (!getShstrtabRes) {
        ALOGE("get shstrtab fail");
        free(shstrtab_content);
        return false;
    }

    ElfN_Shdr* section_header = malloc(sizeof(ElfN_Shdr));
    bool gotFound = false;
    bool gotPltFound = false;
    info->gotSectionSize = 0;
    info->gotAddrOffset = 0;
    info->gotPltSectionSize = 0;
    info->gotPltAddrOffset = 0;
    for (int i = 0; i < section_count; i++) {
        fseek(elfFile, (long)section_header_offset, SEEK_SET);
        fread(section_header, sizeof(ElfN_Shdr), 1, elfFile);
        char *section_name = shstrtab_content + section_header->sh_name;
        ALOGD("index: %d, section name: %s\n", i, section_name);
        if (strcmp(section_name, ".got") == 0) {
            info->gotSectionSize = section_header->sh_size;
            info->gotAddrOffset = section_header->sh_addr;
            gotFound = true;
        }
        if (strcmp(section_name, ".got.plt") == 0) {
            info->gotPltSectionSize = section_header->sh_size;
            info->gotPltAddrOffset = section_header->sh_addr;
            gotPltFound = true;
        }
        if (gotFound && gotPltFound) {
            break;
        }
        section_header_offset += sizeof(ElfN_Shdr);
    }
    free(section_header);
    free(shstrtab_content);

    ALOGD("got section size: %zu, got addr offset: %zx", info->gotSectionSize, info->gotAddrOffset);
    ALOGD("got.plt section size: %zu, got.plt addr offset: %zx", info->gotPltSectionSize, info->gotPltAddrOffset);

    if (!gotFound) {
        // .got 必须存在
        ALOGE("can not find the .got");
        return false;
    }

    return true;
}


static void clearCache(void *addr, size_t len){
    void *end = (uint8_t *)addr + len;
    __builtin___clear_cache(addr, end);
}

static bool replaceFuncPtrInRegion(void* start, size_t size, void* targetPtr, void* replacedPtr) {
    bool replaced = false;

    for (int i = 0; i < size; i += sizeof(void *)) {
        uintptr_t curAddr = (uintptr_t)start + i;
        void* got_entry = *((void **) curAddr);

        if (got_entry == targetPtr) {
            make_mem_writable((void *) curAddr);
            *((void **) (curAddr)) = replacedPtr;
            ALOGD("hooked entry %ld: %p with %p\n", i / sizeof(void *), got_entry,
                  replacedPtr);
            ALOGD("offset is " PRIxPTR, curAddr - (uintptr_t) start);
            replaced = true;
        }
    }

    return replaced;
}

static bool getEssentialInfoFromSegment(struct ElfInfo *info) {

    ElfN_Phdr *dynamic = NULL;
    ElfN_Word size = 0;

    getSegmentInfo(info, PT_DYNAMIC, &dynamic, &size, (uintptr_t *) &(info->dyn));

    if(!dynamic){
        ALOGE("[-] could't find PT_DYNAMIC segment");
        return false;
    }
    info->dynsz = size / sizeof(ElfN_Dyn);

    info->relpltsz = 0;
    info->reldynsz = 0;
    info->nbucket = 0;
    info->nchain = 0;

    ElfN_Dyn *dyn = info->dyn;
    uint32_t *rawdata = 0;
    for(int i = 0; i < info->dynsz; i++, dyn++){
        ALOGD("dyn tag is %lld, value is 0x%llx", dyn->d_tag, dyn->d_un.d_ptr);
        switch(dyn->d_tag){
            case DT_SYMTAB:
                info->sym = (ElfN_Sym *)(info->elf_base + dyn->d_un.d_ptr);
                break;
            case DT_STRTAB:
                info->symstr = (const char *)(info->elf_base + dyn->d_un.d_ptr);
                break;
            case DT_REL:
                info->reldyn = (ElfN_Rel *)(info->elf_base + dyn->d_un.d_ptr);
                break;
            case DT_RELSZ:
                info->reldynsz = dyn->d_un.d_val / sizeof(ElfN_Rel);
                break;
            case DT_JMPREL:
                info->relplt = (ElfN_Rel *)(info->elf_base + dyn->d_un.d_ptr);
                break;
            case DT_PLTRELSZ:
                info->relpltsz = dyn->d_un.d_val / sizeof(ElfN_Rel);
                break;
            case DT_HASH:
                rawdata = (uint32_t *) (info->load_bias + dyn->d_un.d_ptr);
                info->nbucket = rawdata[0];
                info->nchain = rawdata[1];
                info->bucket = (uint32_t *) (info->load_bias + dyn->d_un.d_ptr + 8);
                info->chain = (uint32_t *) (info->load_bias + dyn->d_un.d_ptr + info->nbucket * 4);
                break;
            default:
                // do nothing
                break;
        }
    }

    return true;
}

static bool replaceFunc(void *addr, void *replace_func, void **old_func){
    if(*(void **)addr == replace_func){
        ALOGW("addr %p had been replace.", addr);
        return false;
    }

    if(!*old_func){
        *old_func = *(void **)addr;
    }

    make_mem_writable(addr);

    *(void **)addr = replace_func;
    ALOGI("syscall");
    clearCache(addr, PAGE_SIZE);
    ALOGI("[+] old_func is %p, replace_func is %p, new_func %p.", *old_func, replace_func, *(void **)addr);

    return true;
}

unsigned elf_hash(const char *name) {
    const unsigned char *tmp = (const unsigned char *) name;
    unsigned h = 0, g;

    while (*tmp) {
        h = (h << 4) + *tmp++;
        g = h & 0xf0000000;
        h ^= g;
        h ^= g >> 24;
    }
    return h;
}

void findSymByName(struct ElfInfo* info, const char *symbol, ElfN_Sym **sym, int *symidx) {
    ElfN_Sym *target = NULL;
    uintptr_t index = 0;

    if (info->nchain > 0) {
        // has .hash
        // 部分 so 仅有 .gnu.hash，暂不支持
        unsigned hash = elf_hash(symbol);
        index = info->bucket[hash % info->nbucket];

        if (!strcmp(info->symstr + info->sym[index].st_name, symbol)) {
            target = info->sym + index;
        }

        if (!target) {
            do {
                index = info->chain[index];
                if (!strcmp(info->symstr + info->sym[index].st_name, symbol)) {
                    target = info->sym + index;
                    break;
                }

            } while (index != 0);
        }
    } else{
        // TODO 解析 .gnu.hash 并完成符号表查找
        return;
    }

    if(target){
    SAFE_SET_VALUE(sym, target);
    SAFE_SET_VALUE(symidx, index);
    }
}

static bool hookFuncByPlt(struct ElfInfo* info, const char* symbol, void **old_func, void *replace_func) {
    int symidx = 0;
    ElfN_Sym *sym = NULL;

    findSymByName(info, symbol, &sym, &symidx);

    if (symidx == 0) {
        ALOGE("can not find the symbol");
        return false;
    }

    bool replaced = false;

    for (int i = 0; i < info->relpltsz; i++) {
        ElfN_Rel rel = info->relplt[i];
        if (ELFN_R_SYM(rel.r_info) == symidx && ELFN_R_TYPE
                                                (rel.r_info) == R_ARM_JUMP_SLOT_N) {

            ALOGI("find jump slot in %llx", rel.r_offset);

            void *addr = (void *) (info->load_bias + rel.r_offset);
            if (!replaceFunc(addr, replace_func, old_func))
                return false;
            else
                replaced = true;

            //only once
            break;
        }
    }

    for (int i = 0; i < info->reldynsz; i++) {
        ElfN_Rel rel = info->reldyn[i];
        if (ELFN_R_SYM(rel.r_info) == symidx &&
            (ELFN_R_TYPE(rel.r_info) == R_ARM_ABS_N
             || ELFN_R_TYPE(rel.r_info) == R_ARM_GLOB_DAT_N)) {

            ALOGI("find abs or glob_dat in %llx", rel.r_offset);

            void *addr = (void *) (info->load_bias + rel.r_offset);
            if (!replaceFunc(addr, replace_func, old_func))
                return false;
            else
                replaced = true;
        }
    }

    // 如果没有任何一次成功的  replace，也认为 hook 失败了
    return replaced;
}

bool findActualLoadBias(struct ElfInfo* info) {
    ElfN_Phdr *phdr = info->phdr;

    uintptr_t minAddr = UINTPTR_MAX;
    for(int i = 0; i < info->ehdr->e_phnum; i++){
        if(phdr[i].p_type == PT_LOAD){
            if (phdr[i].p_vaddr < minAddr) {
                minAddr = phdr[i].p_vaddr;
            }
        }
    }

    ALOGI("min addr of PT_LOAD is %"PRIuPTR, minAddr);

    if (minAddr == UINTPTR_MAX) {
        return false;
    }

    info->load_bias = info->elf_base - minAddr;

    return true;
}

int patchGot(const char* library_path, const char* symbol, void* originFuncPtr, void* hookFuncPtr, enum MethodToFindGot method) {
    ALOGI("[%s]patch got by method %d", library_path, method);

    int res = 0;

    FILE *elfFile = OpenElfFile(library_path);

    if (elfFile == NULL) {
        return ERR_FILE_OPEN_FAIL;
    }

    uintptr_t module_base_addr = GetModuleBaseAddr(library_path);

    if (module_base_addr == 0) {
        res = ERR_GET_MODULE_BASE_FAIL;
        goto closeAndReturn;
    }

    struct ElfInfo elfInfo;
    elfInfo.elf_base = module_base_addr;

    bool elfHeaderLegal = getElfHeader(&elfInfo);
    if (!elfHeaderLegal) {
        res = ERR_ELF_HEADER_ILLEGAL;
        goto closeAndReturn;
    }

    getSectionAndSegmentTable(&elfInfo);

    bool isSucc = findActualLoadBias(&elfInfo);
    if (!isSucc) {
        res = ERR_GET_LOAD_BIAS_FAIL;
        goto closeAndReturn;
    }

    // 查找 got 表
    if (method == BySection) {
        isSucc = getGotInfoFromSectionHeader(&elfInfo, elfFile);
    } else{
        isSucc = getEssentialInfoFromSegment(&elfInfo);
    }

    if(!isSucc) {
        res = ERR_GET_GOT_OR_INFO_FAIL;
        goto closeAndReturn;
    }

    // hook

    bool replaced;
    if (method == BySection) {
        ALOGI("[%s]start hook .got", library_path);
        replaced = replaceFuncPtrInRegion((void *) (elfInfo.load_bias + elfInfo.gotAddrOffset), elfInfo.gotSectionSize, originFuncPtr, hookFuncPtr);
        if (elfInfo.gotPltAddrOffset > 0) {
            ALOGI("[%s]start hook .got.plt", library_path);
            replaced |= replaceFuncPtrInRegion((void *) (elfInfo.load_bias + elfInfo.gotPltAddrOffset), elfInfo.gotPltSectionSize, originFuncPtr, hookFuncPtr);
        }
    } else{
        ALOGI("[%s]hook func by plt", library_path);
        replaced = hookFuncByPlt(&elfInfo, symbol, &originFuncPtr, hookFuncPtr);
    }

    if (!replaced) {
        res = ERR_REPLACE_FUNC_FAIL;
        goto closeAndReturn;
    }

    ALOGI("[%s]everything done, close elf", library_path);

    closeAndReturn:
    CloseElfFile(elfFile);

    return res;
}