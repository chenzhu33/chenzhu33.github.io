//
// Created by shinkencai on 2018/4/1.
//

#include "include/LongSetFieldHooker.h"
#include "hookUtil/include/jni-func-hook-util.h"
#include "include/alog.h"

const static char* TAG = "SetLongFieldHook";
void (*originalSetLongField)(JNIEnv*, jobject, jfieldID, jlong);
std::mutex  mAllJavaThreadListMutex;
std::list<jobject> mAllJavaThreadList;
jclass g_thread_cls = NULL;
jfieldID g_nativePeer_filedID = NULL;
jclass g_job_report_class = NULL;
jmethodID g_job_report_method_id = NULL;

LongSetFieldHooker::LongSetFieldHooker(NativeMonitor* monitor):BaseHooker("LongSetFieldHooker",monitor) {
}

int ensureThreadFiledIDInit(JNIEnv *env) {
    if(g_nativePeer_filedID == NULL) {
        if (g_thread_cls == NULL) {
            jclass tmp = env->FindClass("java/lang/Thread");
            if (env->ExceptionCheck()) {
                env->ExceptionDescribe();
                env->ExceptionClear();
                return 0;
            }
            g_thread_cls = (jclass) env->NewGlobalRef(tmp);
        }
        g_nativePeer_filedID = env->GetFieldID(g_thread_cls, "nativePeer", "J");
        if(env->ExceptionCheck()) {
            env->ExceptionDescribe();
            env->ExceptionClear();
            return 0;
        }
    }
    //有问题的都返回了，到这里都没有问题，保证了两个变量有值
    return 1;
}

int ensureJobReportMethodInit(JNIEnv *env) {
    if(g_job_report_method_id == NULL) {
        if (g_job_report_class == NULL) {
            jclass tmp = env->FindClass(classThreadOnCreatedCallBack);
            if (env->ExceptionCheck()) {
                env->ExceptionDescribe();
                env->ExceptionClear();
                return 0;
            }
            g_job_report_class = (jclass) env->NewGlobalRef(tmp);
        }
        g_job_report_method_id = env->GetStaticMethodID(g_job_report_class,
                                                        "onThreadCreatedCallback",
                                                        "(Ljava/lang/Object;)V");
        if(env->ExceptionCheck()) {
            env->ExceptionDescribe();
            env->ExceptionClear();
            return 0;
        }
    }
    return 1;
}

void LongSetFieldHooker::hookedSetLongField(JNIEnv* env, jobject object, jfieldID fieldID, jlong childThreadPtr) {
    if (originalSetLongField) {
        originalSetLongField(env, object, fieldID, childThreadPtr);
        ALOGD("setLongField %p, %p", fieldID, g_nativePeer_filedID);
        if (ensureThreadFiledIDInit(env)) {
            if (fieldID == g_nativePeer_filedID) {
                ALOGI("%s setLongField is Thread", TAG);
                if (ensureJobReportMethodInit(env)) {
                    ALOGI("%s setLongField called job report", TAG);
                    if (childThreadPtr > 0) {
                        env->CallStaticVoidMethod(g_job_report_class, g_job_report_method_id, object);
                    }
                } else {
                    ALOGI("%s setLongField not called job report", TAG);
                }
            } else {
                ALOGI("%s setLongField not Thread", TAG);
            }
        }
    } else {
        ALOGE("oringal SetLongField is null", TAG);
    }
}

int LongSetFieldHooker::getThreadAliveCount() {
    int count = 0;
    int isAttachThread = 0;
    JNIEnv *env = getJniEnv(&isAttachThread);
    for(jobject jthread : mAllJavaThreadList) {
        //为FALSE表明还未回收
        if(env->IsSameObject(jthread,NULL) == JNI_FALSE ) {
            count++;
        }
    }

    if(isAttachThread) {
        _detach_current_thread();
    }
    return count;
}

void LongSetFieldHooker::onInit(int n, ...) {
    va_list args;
    va_start(args, n);
    JNIEnv* env = va_arg(args, JNIEnv*);
    va_end(args);
    JNINativeInterface *structPtr = const_cast<JNINativeInterface *>(env->functions);
    replaceJniEnvFunction((void **) &(structPtr->SetLongField), (void*)LongSetFieldHooker::hookedSetLongField);
    ALOGIJAVA("%s","[setLongField hooked]");
}

void LongSetFieldHooker::beforeHook(int n, ...){
    va_list args;
    va_start(args, n);
    JNIEnv* env = va_arg(args, JNIEnv*);
    va_end(args);
    JNINativeInterface *structPtr = const_cast<JNINativeInterface *>(env->functions);
    originalSetLongField = structPtr->SetLongField;
    ALOGD("%s save original setLongFied",TAG);
}