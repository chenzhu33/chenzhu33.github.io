#include <jni.h>
#include "include/hook-lib.h"
#include "include/alog.h"
#include "include/elf-util.h"

// 导出函数，外部 native 使用只允许使用该函数
int hookFunc(const char* library_path, const char* symbol, void* originFuncPtr, void* hookFuncPtr) {
    ALOGI("[hookFunc][library_path: %s][symbol: %s][originFuncPtr %p][hookFuncPtr %p]", library_path, symbol, originFuncPtr, hookFuncPtr);

    if (originFuncPtr == hookFuncPtr) {
        return ERR_ORIGIN_HOOK_EQUAL;
    }

    int totalRes = 0;

    int res = patchGot(library_path, symbol, originFuncPtr, hookFuncPtr, BySegment);
    if (res != 0) {
        ALOGE("hookFunc in %s by section fail with error: %d", library_path, res);
    } else{
        return res;
    }

    totalRes = res * ERR_OFFSET_SECTION;

//    res = patchGot(library_path, symbol, originFuncPtr, hookFuncPtr, BySegment);
//
//    if (res != 0) {
//        ALOGE("hookFunc in %s by segment fail with error: %d", library_path, res);
//    } else {
//        return res;
//    }
//
//    totalRes += res * ERR_OFFSET_SEGMENT;

    return totalRes;
}