//
// Created by ghostshi on 2018/3/16.
//

#include "include/tree-node.h"

std::string TreeNode::getFullPath() {
    std::string path = "";

    TreeNode* cur = this;
    while (cur != nullptr) {
        path += "/" + cur->pathName;
    }

    return path;
}
