//
// Created by hongpingwu on 2018/3/20.
//

#include "include/LocalRefHooker.h"
#include "hookUtil/include/jni-func-hook-util.h"
#include "include/alog.h"
#include "include/LocalJniRefHooker.h"
#include "hookUtil/include/QJNIInterface.h"

#define MAX_LOCAL_REF 400
#define MIN_LOCAL_REF 50
#define TAG "LocalRefOverflowCatchedException"

#define GET_JNI_REF_HOOKER (dynamic_cast<LocalRefHooker *>(NativeMonitor::getInstance().getLocalRefHooker())->getJniRefHooker())

#define SET_ORIGIN_METHOD(jtype)    origin##jtype = structPtr -> jtype;

#define SET_ORIGIN_METHOD_PRIMITIVE(jtype) SET_ORIGIN_METHOD(New##jtype##Array)

#define REPLACE_JNI_METHOD(jname) \
    do{\
        replaceJniEnvFunction((void **) &( structPtr -> jname ), (void *)  (hooked##jname) );\
    } while(0);

#define REPLACE_JNI_METHOD_PRIMITIVE(jtype) REPLACE_JNI_METHOD(New##jtype##Array)

#define HOOKED_NEW_PRIMITIVE_ARRAY(jtype, jname) \
    j##jtype##Array hookedNew##jname##Array(JNIEnv *env, jsize length) {\
        ALOGI("%s exec", __FUNCTION__);\
        j##jtype##Array ret = originNew##jname##Array(env, length);\
        GET_JNI_REF_HOOKER->addRef(env, ret);\
        return ret;\
    }

jclass (*originFindClass)(JNIEnv *, const char *);

jobject (*originToReflectedMethod)(JNIEnv *, jclass, jmethodID, jboolean);

jobject (*originToReflectedField)(JNIEnv *, jclass, jfieldID, jboolean);

jclass (*originGetObjectClass)(JNIEnv *, jobject);

jclass (*originGetSuperclass)(JNIEnv *, jclass);

jthrowable (*originExceptionOccurred)(JNIEnv *);

jobject (*originPopLocalFrame)(JNIEnv *, jobject);

jobject (*originNewLocalRef)(JNIEnv *, jobject);

jobject (*originAllocObject)(JNIEnv *, jclass);

jobject (*originNewObjectV)(JNIEnv *, jclass, jmethodID, va_list);

jobject (*originNewObjectA)(JNIEnv *, jclass, jmethodID, jvalue *);

jobject (*originCallObjectMethodV)(JNIEnv *, jobject, jmethodID, va_list);

jobject (*originCallObjectMethodA)(JNIEnv *, jobject, jmethodID, jvalue *);

jobject (*originCallNonvirtualObjectMethodV)(JNIEnv *, jobject, jclass,
                                             jmethodID, va_list);

jobject (*originCallNonvirtualObjectMethodA)(JNIEnv *, jobject, jclass,
                                             jmethodID, jvalue *);

jobject (*originGetObjectField)(JNIEnv *, jobject, jfieldID);

jobject (*originGetStaticObjectField)(JNIEnv *, jclass, jfieldID);

jobject (*originCallStaticObjectMethodV)(JNIEnv *, jclass, jmethodID, va_list);

jobject (*originCallStaticObjectMethodA)(JNIEnv *, jclass, jmethodID, jvalue *);

jstring (*originNewString)(JNIEnv *, const jchar *, jsize);

jstring (*originNewStringUTF)(JNIEnv *, const char *);

jobject (*originGetObjectArrayElement)(JNIEnv *, jobjectArray, jsize);

jobjectArray (*originNewObjectArray)(JNIEnv *, jsize, jclass, jobject);

jbooleanArray (*originNewBooleanArray)(JNIEnv *env, jsize length);

jbyteArray (*originNewByteArray)(JNIEnv *env, jsize length);

jcharArray (*originNewCharArray)(JNIEnv *env, jsize length);

jshortArray (*originNewShortArray)(JNIEnv *env, jsize length);

jintArray (*originNewIntArray)(JNIEnv *env, jsize length);

jlongArray (*originNewLongArray)(JNIEnv *env, jsize length);

jfloatArray (*originNewFloatArray)(JNIEnv *env, jsize length);

jdoubleArray (*originNewDoubleArray)(JNIEnv *env, jsize length);

static jobject hookedToReflectedMethod(JNIEnv *env, jclass cls, jmethodID mid, jboolean b) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originToReflectedMethod(env, cls, mid, b);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

static jobject hookedToReflectedField(JNIEnv *env, jclass cls, jfieldID fid, jboolean b) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originToReflectedField(env, cls, fid, b);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

static jclass hookedGetObjectClass(JNIEnv *env, jobject obj) {
    ALOGI("%s exec", __FUNCTION__);
    jclass ret = originGetObjectClass(env, obj);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

static jclass hookedGetSuperclass(JNIEnv *env, jclass cls) {
    ALOGI("%s exec", __FUNCTION__);
    jclass ret = originGetSuperclass(env, cls);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

static jthrowable hookedExceptionOccurred(JNIEnv *env) {
    ALOGI("%s exec", __FUNCTION__);
    jthrowable ret = originExceptionOccurred(env);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

static jobject hookedPopLocalFrame(JNIEnv *env, jobject obj) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originPopLocalFrame(env, obj);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

static jobject hookedNewLocalRef(JNIEnv *env, jobject object) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originNewLocalRef(env, object);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

static jobject hookedAllocObject(JNIEnv *env, jclass cls) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originAllocObject(env, cls);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

static jobject hookedNewObjectV(JNIEnv *env, jclass cls, jmethodID methodId, va_list args) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originNewObjectV(env, cls, methodId, args);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

static jobject hookedNewObjectA(JNIEnv *env, jclass cls, jmethodID methodID, jvalue *values) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originNewObjectA(env, cls, methodID, values);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

jobject hookedCallObjectMethodV(JNIEnv *env, jobject obj, jmethodID mid, va_list args) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originCallObjectMethodV(env, obj, mid, args);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

jobject hookedCallObjectMethodA(JNIEnv *env, jobject obj, jmethodID mid, jvalue *values) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originCallObjectMethodA(env, obj, mid, values);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

jobject hookedCallNonvirtualObjectMethodV(JNIEnv *env, jobject obj, jclass cls,
                                          jmethodID mid, va_list args) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originCallNonvirtualObjectMethodV(env, obj, cls, mid, args);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

jobject hookedCallNonvirtualObjectMethodA(JNIEnv *env, jobject obj, jclass cls,
                                          jmethodID mid, jvalue *args) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originCallNonvirtualObjectMethodA(env, obj, cls, mid, args);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

jobject hookedGetObjectField(JNIEnv *env, jobject obj, jfieldID fid) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originGetObjectField(env, obj, fid);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

jobject hookedGetStaticObjectField(JNIEnv *env, jclass cls, jfieldID fid) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originGetStaticObjectField(env, cls, fid);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

jobject hookedCallStaticObjectMethodV(JNIEnv *env, jclass cls, jmethodID mid, va_list args) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originCallStaticObjectMethodV(env, cls, mid, args);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

jobject hookedCallStaticObjectMethodA(JNIEnv *env, jclass cls, jmethodID mid, jvalue *args) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originCallStaticObjectMethodA(env, cls, mid, args);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

jstring hookedNewString(JNIEnv *env, const jchar *pChar, jsize length) {
    ALOGI("%s exec", __FUNCTION__);
    jstring ret = originNewString(env, pChar, length);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

jstring hookedNewStringUTF(JNIEnv *env, const char *pChar) {
    jstring ret = originNewStringUTF(env, pChar);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

jobject hookedGetObjectArrayElement(JNIEnv *env, jobjectArray array, jsize length) {
    ALOGI("%s exec", __FUNCTION__);
    jobject ret = originGetObjectArrayElement(env, array, length);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

jobjectArray hookedNewObjectArray(JNIEnv *env, jsize size, jclass cls, jobject obj) {
    ALOGI("%s exec", __FUNCTION__);
    jobjectArray ret = originNewObjectArray(env, size, cls, obj);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

HOOKED_NEW_PRIMITIVE_ARRAY(boolean, Boolean)

HOOKED_NEW_PRIMITIVE_ARRAY(byte, Byte)

HOOKED_NEW_PRIMITIVE_ARRAY(char, Char)

HOOKED_NEW_PRIMITIVE_ARRAY(short, Short)

HOOKED_NEW_PRIMITIVE_ARRAY(int, Int)

HOOKED_NEW_PRIMITIVE_ARRAY(long, Long)

HOOKED_NEW_PRIMITIVE_ARRAY(float, Float)

HOOKED_NEW_PRIMITIVE_ARRAY(double, Double)

void (*originDeleteLocalRef)(JNIEnv *, jobject);

static jclass hookedFindClass(JNIEnv *env, const char *cls) {
    ALOGI("%s exec", __FUNCTION__);
    jclass ret = originFindClass(env, cls);
    GET_JNI_REF_HOOKER->addRef(env, ret);
    return ret;
}

static void hookedDeleteLocalRef(JNIEnv *env, jobject object) {
    ALOGI("%s exec", __FUNCTION__);
    originDeleteLocalRef(env, object);
    GET_JNI_REF_HOOKER->deleteRef(env, object);
}

// init static member variable
__thread LocalJniRefHooker *LocalRefHooker::tlsRefHooker = 0;

LocalRefHooker::LocalRefHooker(NativeMonitor* monitor) :
        BaseHooker("LocalRefHooker", monitor) {

}

void LocalRefHooker::beforeHook(int n, ...) {
    va_list args;
    va_start(args, n);
    JNIEnv *env = va_arg(args, JNIEnv*);
    va_end(args);
    JNINativeInterface *structPtr = const_cast<JNINativeInterface *>(env->functions);
    SET_ORIGIN_METHOD(FindClass)
    SET_ORIGIN_METHOD(ToReflectedMethod)
    SET_ORIGIN_METHOD(ToReflectedField)
    SET_ORIGIN_METHOD(GetObjectClass)
    SET_ORIGIN_METHOD(GetSuperclass)
    SET_ORIGIN_METHOD(ExceptionOccurred)
    SET_ORIGIN_METHOD(PopLocalFrame)
    SET_ORIGIN_METHOD(NewLocalRef)
    SET_ORIGIN_METHOD(AllocObject)
    SET_ORIGIN_METHOD(NewObjectV)
    SET_ORIGIN_METHOD(NewObjectA)
    SET_ORIGIN_METHOD(CallObjectMethodV)
    SET_ORIGIN_METHOD(CallObjectMethodA)
    SET_ORIGIN_METHOD(CallNonvirtualObjectMethodV)
    SET_ORIGIN_METHOD(CallNonvirtualObjectMethodA)
    SET_ORIGIN_METHOD(GetObjectField)
    SET_ORIGIN_METHOD(GetStaticObjectField)
    SET_ORIGIN_METHOD(CallStaticObjectMethodV)
    SET_ORIGIN_METHOD(CallStaticObjectMethodA)
    SET_ORIGIN_METHOD(NewString)
//    SET_ORIGIN_METHOD(NewStringUTF)
    SET_ORIGIN_METHOD(GetObjectArrayElement)
    SET_ORIGIN_METHOD(NewObjectArray)
    SET_ORIGIN_METHOD(DeleteLocalRef)

    SET_ORIGIN_METHOD_PRIMITIVE(Boolean)
    SET_ORIGIN_METHOD_PRIMITIVE(Byte)
    SET_ORIGIN_METHOD_PRIMITIVE(Char)
    SET_ORIGIN_METHOD_PRIMITIVE(Short)
    SET_ORIGIN_METHOD_PRIMITIVE(Int)
    SET_ORIGIN_METHOD_PRIMITIVE(Long)
    SET_ORIGIN_METHOD_PRIMITIVE(Float)
    SET_ORIGIN_METHOD_PRIMITIVE(Double)
}

void LocalRefHooker::onInit(int n, ...) {
    va_list args;
    va_start(args, n);
    JNIEnv *env = va_arg(args, JNIEnv*);
    va_end(args);
    JNINativeInterface *structPtr = const_cast<JNINativeInterface *>(env->functions);
    REPLACE_JNI_METHOD(FindClass)
    REPLACE_JNI_METHOD(ToReflectedMethod)
    REPLACE_JNI_METHOD(ToReflectedField)
    REPLACE_JNI_METHOD(GetObjectClass)
    REPLACE_JNI_METHOD(GetSuperclass)
    REPLACE_JNI_METHOD(ExceptionOccurred)
    REPLACE_JNI_METHOD(PopLocalFrame)
    REPLACE_JNI_METHOD(NewLocalRef)
    REPLACE_JNI_METHOD(AllocObject)
    REPLACE_JNI_METHOD(NewObjectV)
    REPLACE_JNI_METHOD(NewObjectA)
    REPLACE_JNI_METHOD(CallObjectMethodV)
    REPLACE_JNI_METHOD(CallObjectMethodA)
    REPLACE_JNI_METHOD(CallNonvirtualObjectMethodV)
    REPLACE_JNI_METHOD(CallNonvirtualObjectMethodA)
    REPLACE_JNI_METHOD(GetObjectField)
    REPLACE_JNI_METHOD(GetStaticObjectField)
    REPLACE_JNI_METHOD(CallStaticObjectMethodV)
    REPLACE_JNI_METHOD(CallStaticObjectMethodA)
    REPLACE_JNI_METHOD(NewString)
    //TODO 打印 LOG 时导致递归 hook，需要增加状态变量避免二次 hook
    //  REPLACE_JNI_METHOD(NewStringUTF)
    REPLACE_JNI_METHOD(GetObjectArrayElement)
    REPLACE_JNI_METHOD(NewObjectArray)

    REPLACE_JNI_METHOD_PRIMITIVE(Boolean)
    REPLACE_JNI_METHOD_PRIMITIVE(Byte)
    REPLACE_JNI_METHOD_PRIMITIVE(Char)
    REPLACE_JNI_METHOD_PRIMITIVE(Short)
    REPLACE_JNI_METHOD_PRIMITIVE(Int)
    REPLACE_JNI_METHOD_PRIMITIVE(Long)
    REPLACE_JNI_METHOD_PRIMITIVE(Float)
    REPLACE_JNI_METHOD_PRIMITIVE(Double)

    REPLACE_JNI_METHOD(DeleteLocalRef)

    ALOGI("%s", "LocalRef is hooked");
}

LocalJniRefHooker *LocalRefHooker::getJniRefHooker() {
    if (!LocalRefHooker::tlsRefHooker)
        LocalRefHooker::tlsRefHooker = new LocalJniRefHooker(MAX_LOCAL_REF, MIN_LOCAL_REF, TAG);

    return LocalRefHooker::tlsRefHooker;
}