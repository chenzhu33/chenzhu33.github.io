//
// Created by ghostshi on 2018/3/14.
//

#ifndef JNI_HOOK_TOOLKIT_UTIL_H
#define JNI_HOOK_TOOLKIT_UTIL_H

#include <vector>

typedef struct _FunctionParam {
    void* retValuePtr;
    int paramCount;
    std::vector<void*> paramPtrList;
    void* callerAddr;

    void* getParamAtIdx(int idx) {
        if (idx < paramCount) {
            return paramPtrList[idx];
        }

        return nullptr;
    }
} FuncParamType;

#endif //JNI_HOOK_TOOLKIT_UTIL_H
