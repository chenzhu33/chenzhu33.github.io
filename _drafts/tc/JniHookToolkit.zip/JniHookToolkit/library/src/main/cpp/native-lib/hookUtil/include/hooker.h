//
// Created by ghostshi on 2018/3/14.
//

#ifndef JNI_HOOK_TOOLKIT_HOOKER_H
#define JNI_HOOK_TOOLKIT_HOOKER_H

#include <string>
#include <vector>
#include <memory>
#include "../../include/native-monitor.h"
#include "../../include/util.h"

class BaseHooker {
private:
    std::string mName;
    NativeMonitor* mMonitor;
public:
    BaseHooker(const std::string &name, NativeMonitor *monitorPtr)
            : mName(name), mMonitor(monitorPtr) {}

    virtual void onInit(int n, ...) {}

    virtual void beforeSoLoad(const char *library_path, jobject java_loader);

    virtual void afterSoLoad(const char *library_path, jobject java_loader);

    virtual std::string getTalkTopicNamespace() ;

    void talkMessage (std::string topicName, FuncParamType& funcParam) ;

    void talkBeforeOriginFuncCalled (std::string funcName, void* callerAddr, int paramNum, ...) ;

    void talkAfterOriginFuncCalled (std::string funcName, void* callerAddr, void* retValuePtr, int paramNum, ...);

    virtual void beforeHook(int n, ...){}

    virtual void dump(JNIEnv *){}
};

typedef std::shared_ptr<BaseHooker> BaseHookerPtr;

#endif //JNI_HOOK_TOOLKIT_HOOKER_H
