//
// Created by ghostshi on 2018/3/14.
//

#ifndef JNI_HOOK_TOOLKIT_FREE_HOOK_UTIL_H
#define JNI_HOOK_TOOLKIT_FREE_HOOK_UTIL_H

#include <stddef.h>
#include <list>
#include "../../include/util.h"
#include "../../include/tracker.h"
#include "hooker.h"

class FreeHooker : public BaseHooker {
public:
    FreeHooker(NativeMonitor* monitor);

    void onInit(int n, ...) override final ;

    void beforeSoLoad(const char *library_path, jobject java_loader) override final ;

    void afterSoLoad(const char *library_path, jobject java_loader) override final ;
};


#endif //JNI_HOOK_TOOLKIT_FREE_HOOK_UTIL_H
