//
// Created by passionli on 2018/4/20.
//

#include <jni.h>
#include "include/CheckJNIHooker.h"
#include "hookUtil/include/jni-func-hook-util.h"
#include "hookUtil/include/QJNIInterface.h"
#include "include/alog.h"
#include "hookUtil/include/backtrace.h"

#define TAG "CheckJNIArgsException"

using namespace std;

CheckJNIHooker::CheckJNIHooker(NativeMonitor* monitor) :
        BaseHooker("CheckJNIHooker", monitor) {

}

void CheckJNIHooker::beforeHook(int n, ...) {
}

void CheckJNIHooker::onInit(int n, ...) {
    va_list args;
    va_start(args, n);
    JNIEnv *env = va_arg(args, JNIEnv*);
    va_end(args);
    JNINativeInterface *structPtr = const_cast<JNINativeInterface *>(env->functions);

    CheckJNIHooker::originGetStaticMethodID = structPtr-> GetStaticMethodID;
    replaceJniEnvFunction((void **) &(structPtr-> GetStaticMethodID), (void *) CheckJNIHooker::hookedGetStaticMethodID);

#define REPLACE_GET_SET_XX_FIELD_INTERNAL(_gs, _jname, _suffix)\
    CheckJNIHooker::origin##_gs##et##_jname##_suffix = structPtr-> _gs##et##_jname##_suffix;\
    replaceJniEnvFunction((void **) &(structPtr-> _gs##et##_jname##_suffix), (void *) CheckJNIHooker::hooked##_gs##et##_jname##_suffix);

#define REPLACE_GET_SET_XX_FIELD(_jname)\
    REPLACE_GET_SET_XX_FIELD_INTERNAL(G, _jname, Field)\
    REPLACE_GET_SET_XX_FIELD_INTERNAL(S, _jname, Field)\
    REPLACE_GET_SET_XX_FIELD_INTERNAL(G, _jname, ArrayRegion)\
    REPLACE_GET_SET_XX_FIELD_INTERNAL(S, _jname, ArrayRegion)

    CheckJNIHooker::originGetObjectField = structPtr-> GetObjectField;
    CheckJNIHooker::originSetObjectField = structPtr-> SetObjectField;
    replaceJniEnvFunction((void **) &(structPtr-> GetObjectField), (void *) CheckJNIHooker::hookedGetObjectField);
    replaceJniEnvFunction((void **) &(structPtr-> SetObjectField), (void *) CheckJNIHooker::hookedSetObjectField);

    REPLACE_GET_SET_XX_FIELD(Boolean)
    REPLACE_GET_SET_XX_FIELD(Byte)
    REPLACE_GET_SET_XX_FIELD(Char)
    REPLACE_GET_SET_XX_FIELD(Short)
    REPLACE_GET_SET_XX_FIELD(Int)
    REPLACE_GET_SET_XX_FIELD(Long)
    REPLACE_GET_SET_XX_FIELD(Float)
    REPLACE_GET_SET_XX_FIELD(Double)
#undef REPLACE_GET_SET_XX_FIELD

#define REPLACE_GET_SET_STATIC_XX_FIELD_INTERNAL(_gs, _jname, _suffix)\
    CheckJNIHooker::origin##_gs##etStatic##_jname##_suffix = structPtr-> _gs##etStatic##_jname##_suffix;\
    replaceJniEnvFunction((void **) &(structPtr-> _gs##etStatic##_jname##_suffix), (void *) CheckJNIHooker::hooked##_gs##etStatic##_jname##_suffix);

#define REPLACE_GET_SET_STATIC_XX_FIELD(_jname)\
    REPLACE_GET_SET_STATIC_XX_FIELD_INTERNAL(G, _jname, Field)\
    REPLACE_GET_SET_STATIC_XX_FIELD_INTERNAL(S, _jname, Field)

    REPLACE_GET_SET_STATIC_XX_FIELD(Object)
    REPLACE_GET_SET_STATIC_XX_FIELD(Boolean)
    REPLACE_GET_SET_STATIC_XX_FIELD(Byte)
    REPLACE_GET_SET_STATIC_XX_FIELD(Char)
    REPLACE_GET_SET_STATIC_XX_FIELD(Short)
    REPLACE_GET_SET_STATIC_XX_FIELD(Int)
    REPLACE_GET_SET_STATIC_XX_FIELD(Long)
    REPLACE_GET_SET_STATIC_XX_FIELD(Float)
    REPLACE_GET_SET_STATIC_XX_FIELD(Double)
#undef REPLACE_GET_SET_STATIC_XX_FIELD_INTERNAL

#define REPLACE_CALL_XX_V(_jname)\
    CheckJNIHooker::originCall##_jname##MethodV = structPtr-> Call##_jname##MethodV;\
    replaceJniEnvFunction((void **) &(structPtr-> Call##_jname##MethodV), (void *) CheckJNIHooker::hookedCall##_jname##MethodV);\
    CheckJNIHooker::originCallStatic##_jname##MethodV = structPtr-> CallStatic##_jname##MethodV;\
    replaceJniEnvFunction((void **) &(structPtr-> CallStatic##_jname##MethodV), (void *) CheckJNIHooker::hookedCallStatic##_jname##MethodV);\
    CheckJNIHooker::originCall##_jname##MethodA = structPtr-> Call##_jname##MethodA;\
    replaceJniEnvFunction((void **) &(structPtr-> Call##_jname##MethodA), (void *) CheckJNIHooker::hookedCall##_jname##MethodA);\
    CheckJNIHooker::originCallStatic##_jname##MethodA = structPtr-> CallStatic##_jname##MethodA;\
    replaceJniEnvFunction((void **) &(structPtr-> CallStatic##_jname##MethodA), (void *) CheckJNIHooker::hookedCallStatic##_jname##MethodA);

    REPLACE_CALL_XX_V(Object)
    REPLACE_CALL_XX_V(Boolean)
    REPLACE_CALL_XX_V(Byte)
    REPLACE_CALL_XX_V(Char)
    REPLACE_CALL_XX_V(Short)
    REPLACE_CALL_XX_V(Int)
    REPLACE_CALL_XX_V(Long)
    REPLACE_CALL_XX_V(Float)
    REPLACE_CALL_XX_V(Double)
    REPLACE_CALL_XX_V(Void)
#undef REPLACE_CALL_XX_V
}

// static member field initial
#define ORIGIN_GET_XX_FIELD_INIT(_jtype, _jname)\
    j##_jtype (*CheckJNIHooker::originGet##_jname##Field)(JNIEnv *, jobject, jfieldID) = 0;\
    j##_jtype (*CheckJNIHooker::originGetStatic##_jname##Field)(JNIEnv *, jclass, jfieldID) = 0;

ORIGIN_GET_XX_FIELD_INIT(object, Object)
ORIGIN_GET_XX_FIELD_INIT(boolean, Boolean)
ORIGIN_GET_XX_FIELD_INIT(byte, Byte)
ORIGIN_GET_XX_FIELD_INIT(short, Short)
ORIGIN_GET_XX_FIELD_INIT(char, Char)
ORIGIN_GET_XX_FIELD_INIT(int, Int)
ORIGIN_GET_XX_FIELD_INIT(long, Long)
ORIGIN_GET_XX_FIELD_INIT(float, Float)
ORIGIN_GET_XX_FIELD_INIT(double, Double)
#undef ORIGIN_GET_XX_FIELD_INIT

#define ORIGIN_SET_XX_FIELD_INIT(_jtype, _jname)\
    void (*CheckJNIHooker::originSet##_jname##Field)(JNIEnv *, jobject, jfieldID, j##_jtype) = 0;\
    void (*CheckJNIHooker::originSetStatic##_jname##Field)(JNIEnv *, jclass, jfieldID, j##_jtype) = 0;

ORIGIN_SET_XX_FIELD_INIT(object, Object)
ORIGIN_SET_XX_FIELD_INIT(boolean, Boolean)
ORIGIN_SET_XX_FIELD_INIT(byte, Byte)
ORIGIN_SET_XX_FIELD_INIT(short, Short)
ORIGIN_SET_XX_FIELD_INIT(char, Char)
ORIGIN_SET_XX_FIELD_INIT(int, Int)
ORIGIN_SET_XX_FIELD_INIT(long, Long)
ORIGIN_SET_XX_FIELD_INIT(float, Float)
ORIGIN_SET_XX_FIELD_INIT(double, Double)
#undef ORIGIN_SET_XX_FIELD_INIT

#define ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(_GS, _jtype, _jname, _const) \
    void (*CheckJNIHooker::origin##_GS##et##_jname##ArrayRegion)(JNIEnv*, j##_jtype##Array,\
    jsize, jsize, _const j##_jtype*) = 0;

ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(G, boolean, Boolean, )
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(S, boolean, Boolean, const)
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(G, byte, Byte, )
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(S, byte, Byte, const)
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(G, short, Short, )
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(S, short, Short, const)
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(G, char, Char, )
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(S, char, Char, const)
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(G, int, Int, )
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(S, int, Int, const)
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(G, long, Long,)
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(S, long, Long, const)
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(G, float, Float, )
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(S, float, Float, const)
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(G, double, Double, )
ORIGIN_GET_SET_XX_ARRAY_REGION_INIT(S, double, Double, const)
#undef ORIGIN_GET_SET_XX_ARRAY_REGION_INIT

#define ORIGIN_CALL_XX_V_INIT(_jtype, _jname)\
    _jtype (*CheckJNIHooker::originCall##_jname##MethodV)(JNIEnv*, jobject, jmethodID, va_list) = 0;\
    _jtype (*CheckJNIHooker::originCall##_jname##MethodA)(JNIEnv*, jobject, jmethodID, jvalue*) = 0;\
    _jtype (*CheckJNIHooker::originCallStatic##_jname##MethodV)(JNIEnv*, jclass, jmethodID, va_list) = 0;\
    _jtype (*CheckJNIHooker::originCallStatic##_jname##MethodA)(JNIEnv*, jclass, jmethodID, jvalue*) = 0;

ORIGIN_CALL_XX_V_INIT(jobject, Object)
ORIGIN_CALL_XX_V_INIT(jboolean, Boolean)
ORIGIN_CALL_XX_V_INIT(jbyte, Byte)
ORIGIN_CALL_XX_V_INIT(jshort, Short)
ORIGIN_CALL_XX_V_INIT(jchar, Char)
ORIGIN_CALL_XX_V_INIT(jint, Int)
ORIGIN_CALL_XX_V_INIT(jlong, Long)
ORIGIN_CALL_XX_V_INIT(jfloat, Float)
ORIGIN_CALL_XX_V_INIT(jdouble, Double)
ORIGIN_CALL_XX_V_INIT(void, Void)
#undef ORIGIN_CALL_XX_V_INIT

jmethodID   (*CheckJNIHooker::originGetStaticMethodID)(JNIEnv*, jclass, const char*, const char*) = 0;

void CheckJNIHooker::reportInternal(JNIEnv *env, BacktraceState *trace, const char * pchar, const char * pFuncName) {
    std::ostringstream* os = new std::ostringstream();
    *os << "[hooked] check JNI Args ";
    *os << pchar << " in " << pFuncName << "\n";
    *os << " the top traces are: \n";
    getBacktrace(trace->pc, trace->size, *os);
    *os << "\n";
    report(env, TAG, os->str().c_str());
    delete os;
}

#undef TAG

