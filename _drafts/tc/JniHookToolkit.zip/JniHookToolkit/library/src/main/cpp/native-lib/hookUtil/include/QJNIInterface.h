//
// Created by hongpingwu on 2018/3/26.
//

#ifndef NATIVEMEMORY_QJNIINTERFACE_H
#define NATIVEMEMORY_QJNIINTERFACE_H

#include <jni.h>
// local
extern jobject (*originNewLocalRef)(JNIEnv*, jobject);
extern void (*originDeleteLocalRef)(JNIEnv*, jobject);
extern jclass (*originFindClass)(JNIEnv*, const char*);
extern jobject (*originNewObjectV)(JNIEnv*, jclass, jmethodID, va_list);
extern jobject (*originNewObjectA)(JNIEnv*, jclass, jmethodID, jvalue*);

// global
extern jobject (*NewGlobalRefOrigin)(JNIEnv*, jobject);
extern void (*DeleteGlobalRefOrigin)(JNIEnv*, jobject);

// weak global
extern jobject (*NewWeakGlobalRefOrigin)(JNIEnv*, jobject);
extern void (*DeleteWeakGlobalRefOrigin)(JNIEnv*, jobject);

// pinned
extern const jchar* (*originGetStringChars)(JNIEnv*, jstring, jboolean*);
extern jboolean*   (*originGetBooleanArrayElements)(JNIEnv*, jbooleanArray, jboolean*);
extern jbyte*      (*originGetByteArrayElements)(JNIEnv*, jbyteArray, jboolean*);
extern jchar*      (*originGetCharArrayElements)(JNIEnv*, jcharArray, jboolean*);
extern jshort*     (*originGetShortArrayElements)(JNIEnv*, jshortArray, jboolean*);
extern jint*       (*originGetIntArrayElements)(JNIEnv*, jintArray, jboolean*);
extern jlong*      (*originGetLongArrayElements)(JNIEnv*, jlongArray, jboolean*);
extern jfloat*     (*originGetFloatArrayElements)(JNIEnv*, jfloatArray, jboolean*);
extern jdouble*    (*originGetDoubleArrayElements)(JNIEnv*, jdoubleArray, jboolean*);
extern void*       (*originGetPrimitiveArrayCritical)(JNIEnv*, jarray, jboolean*);
extern const jchar* (*originGetStringCritical)(JNIEnv*, jstring, jboolean*);

extern void        (*originReleaseStringChars)(JNIEnv*, jstring, const jchar*);
extern void        (*originReleaseBooleanArrayElements)(JNIEnv*, jbooleanArray, jboolean*, jint);
extern void        (*originReleaseByteArrayElements)(JNIEnv*, jbyteArray, jbyte*, jint);
extern void        (*originReleaseCharArrayElements)(JNIEnv*, jcharArray, jchar*, jint);
extern void        (*originReleaseShortArrayElements)(JNIEnv*, jshortArray, jshort*, jint);
extern void        (*originReleaseIntArrayElements)(JNIEnv*, jintArray, jint*, jint);
extern void        (*originReleaseLongArrayElements)(JNIEnv*, jlongArray, jlong*, jint);
extern void        (*originReleaseFloatArrayElements)(JNIEnv*, jfloatArray, jfloat*, jint);
extern void        (*originReleaseDoubleArrayElements)(JNIEnv*, jdoubleArray, jdouble*, jint);
extern void        (*originReleasePrimitiveArrayCritical)(JNIEnv*, jarray, void*, jint);
extern void        (*originReleaseStringCritical)(JNIEnv*, jstring, const jchar*);

extern jclass (*originGetObjectClass)(JNIEnv*, jobject);


// attach/detach
extern jint        (*originAttachCurrentThread)(JavaVM*, JNIEnv**, void*);
extern jint        (*originDetachCurrentThread)(JavaVM*);

#endif //NATIVEMEMORY_QJNIINTERFACE_H
