//
// Created by ghostshi on 2018/3/13.
//


#ifndef JNI_HOOK_TOOLKIT_TRACKER_H
#define JNI_HOOK_TOOLKIT_TRACKER_H

#include <string>
#include <memory>
#include <vector>
#include "native-monitor.h"

class BaseTracker {
private:
    NativeMonitor* mMonitor;
public:
    std::string mName;
    BaseTracker(const std::string name, NativeMonitor* monitor);

    virtual void onInit();

    virtual void onMessage(std::string topic, FuncParamType& funcParam) = 0;

    virtual std::vector<std::string> topicToSubscribe() = 0;
};

typedef std::shared_ptr<BaseTracker> BaseTrackerPtr;

//class BaseMallocTracker : public BaseTracker {
//public:
//    BaseMallocTracker(NativeMonitor* monitor);
//    void onInit();
//    void onMessage(std::string topic, FuncParamType& funcParam) override final ;
//    std::vector<std::string> topicToSubscribe() override final ;
//    int getMallocBigSize();
//    int isOverAllocateCount();
//    static void sigactionHandler(int sigNumber, siginfo_t *siginfo, void *arg);
//private:
//    int malloc_big_size = 1024*1024*2L;



//};

//class BaseFreeTracker : public BaseTracker {
//public:
//    BaseFreeTracker(NativeMonitor* monitor);
//    void onMessage(std::string topic, FuncParamType& funcParam) override final ;
//    std::vector<std::string> topicToSubscribe() override final ;
//};

class LogAllTracker : public BaseTracker {
public:
    LogAllTracker(NativeMonitor* monitor);

    void onMessage(std::string topic, FuncParamType& funcParam) override final ;

    std::vector<std::string> topicToSubscribe() override final ;
};
/*
class MemoryLeakMallocTracker : public BaseTracker {
public:
    MemoryLeakMallocTracker();
    bool isSymbolCared(std::string symbol) override;
    void beforeFuncExec(void* callerAddr, std::string symbol, int n, ...) final ;
    virtual void afterFuncExec(void* callerAddr, std::string symbol, void* retValuePtr, int n, ...) final ;
};

class MemoryLeakFreeTracker : public BaseTracker {
public:
    MemoryLeakFreeTracker();
    bool isSymbolCared(std::string symbol) override;
    void beforeFuncExec(void* callerAddr, std::string symbol, int n, ...) final ;
    virtual void afterFuncExec(void* callerAddr, std::string symbol, void* retValuePtr, int n, ...) final ;
};

*/

#endif //JNI_HOOK_TOOLKIT_TRACKER_H
