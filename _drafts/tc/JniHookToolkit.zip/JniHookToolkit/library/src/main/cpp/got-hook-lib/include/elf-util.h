//
// Created by ghostshi on 2018/2/6.
//

#ifndef GOTHOOKLIBRARY_ELF_UTIL_H
#define GOTHOOKLIBRARY_ELF_UTIL_H

#include <elf.h>

/* Word size */
#if __WORDSIZE == 64
#define uintN_t uint64_t
#define ElfN_Ehdr Elf64_Ehdr
#define ElfN_Shdr Elf64_Shdr
#define ElfN_Phdr Elf64_Phdr
#define ElfN_Addr Elf64_Addr
#define ElfN_Sym Elf64_Sym
#define ElfN_Dyn Elf64_Dyn
#define ElfN_Off Elf64_Off
#define ElfN_Word Elf64_Word
#define ElfN_Rel Elf64_Rel
#define ELFCLASSN ELFCLASS64
#define ELFN_ST_TYPE ELF64_ST_TYPE
#define INT_RANGE_STR "64"

#define R_ARM_ABS_N 0x101
#define R_ARM_GLOB_DAT_N 0x401
#define R_ARM_JUMP_SLOT_N 0x402


#define ELFN_R_SYM(i) ((i) >> 32)
#define ELFN_R_TYPE(i) ((i) & 0xffffffff)
#else
#define uintN_t uint32_t
#define ElfN_Ehdr Elf32_Ehdr
#define ElfN_Shdr Elf32_Shdr
#define ElfN_Phdr Elf32_Phdr
#define ElfN_Addr Elf32_Addr
#define ElfN_Sym Elf32_Sym
#define ElfN_Dyn Elf32_Dyn
#define ElfN_Off Elf32_Off
#define ElfN_Word Elf32_Word
#define ElfN_Rel Elf32_Rel
#define ELFCLASSN ELFCLASS32
#define ELFN_ST_TYPE ELF32_ST_TYPE
#define INT_RANGE_STR "32"

#define R_ARM_ABS_N 0x02
#define R_ARM_GLOB_DAT_N 0x15
#define R_ARM_JUMP_SLOT_N 0x16

#define ELFN_R_SYM(x) ((x) >> 8)
#define ELFN_R_TYPE(x) ((x) & 0xff)
#endif

/**
 * elf关键信息
 */
struct ElfInfo{
    uintptr_t elf_base;
    uintptr_t load_bias;

    ElfN_Ehdr *ehdr;
    ElfN_Phdr *phdr;
    ElfN_Shdr *shdr;

    size_t gotSectionSize;
    size_t gotPltSectionSize;

    uintptr_t gotAddrOffset;
    uintptr_t gotPltAddrOffset;

    ElfN_Dyn *dyn;
    ElfN_Word dynsz;

    ElfN_Sym *sym;
    uintptr_t symsz;

    ElfN_Rel *relplt;
    uintptr_t relpltsz;
    ElfN_Rel *reldyn;
    uintptr_t reldynsz;

    uint32_t nbucket;
    uint32_t nchain;

    uint32_t *bucket;
    uint32_t *chain;

    const char *shstr;
    const char *symstr;
};

enum MethodToFindGot {
    BySection, BySegment
};

int patchGot(const char* library_path, const char* symbol, void* originFuncPtr, void* hookFuncPtr, enum MethodToFindGot method);

// 错误码定义

#define ERR_FILE_OPEN_FAIL 1
#define ERR_GET_MODULE_BASE_FAIL 2
#define ERR_GET_LOAD_BIAS_FAIL 3
#define ERR_GET_GOT_OR_INFO_FAIL 4
#define ERR_REPLACE_FUNC_FAIL 5
#define ERR_ELF_HEADER_ILLEGAL 6


#endif //GOTHOOKLIBRARY_ELF_UTIL_H
