//
// Created by hongpingwu on 2018/3/20.
//

#ifndef NATIVEMEMORY_LOCALREFHOOKER_H
#define NATIVEMEMORY_LOCALREFHOOKER_H


#include "../hookUtil/include/hooker.h"
#include "LocalJniRefHooker.h"

class LocalRefHooker : public BaseHooker {
public:
    /**
     * Thread Local Storage pointer
     */
    static __thread LocalJniRefHooker * tlsRefHooker;

    LocalRefHooker(NativeMonitor* monitor);

    void onInit(int n, ...) override final ;
    void beforeHook(int n, ...) override final;

    LocalJniRefHooker * getJniRefHooker();
};


#endif //NATIVEMEMORY_LOCALREFHOOKER_H
