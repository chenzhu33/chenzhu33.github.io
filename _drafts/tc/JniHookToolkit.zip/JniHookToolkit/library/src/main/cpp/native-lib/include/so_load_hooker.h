//
// Created by jefding on 2019/2/20.
//

#ifndef NATIVEMEMORY_SO_LOAD_HOOKER_H
#define NATIVEMEMORY_SO_LOAD_HOOKER_H

#include <dlfcn.h>
#include <include/jni/ext.h>
#include <include/bionic/linker/linker.h>
#include <dlfcn/dlfcn.h>
#include <set>
#include <mutex>

#include "../hookUtil/include/hooker.h"
#include "hook-lib.h"
#include "global_variables.h"
#include "../jni-method-hook-lib/include/hook.h"
#include "../hookUtil/include/backtrace.h"

class SoLoadHooker : public BaseHooker {
public:
    explicit SoLoadHooker(NativeMonitor *monitorPtr, const std::string &native_lib_dir, JNIEnv *env, jclass clazz)
            : BaseHooker("dlopen_hooker", monitorPtr), native_lib_dir_(native_lib_dir) {
        Instance() = this;
        ADEFINE_DEFER();
        defer([&]() {
            env->ExceptionDescribe();
            env->ExceptionClear();
        });

        monitor_class_ = (jclass) env->NewGlobalRef(clazz);
        ACHECK(monitor_class_);

        on_so_load_mid_ = env->GetStaticMethodID(clazz, "onSoLoad", "(Ljava/lang/String;Ljava/lang/String;)V");
        ACHECK(on_so_load_mid_);

        auto linker = bionic::Linker::Get();
        ACHECK(linker && bionic::Linker::Is_dlopen_ext_Valid(linker));

        is_valid_ = true;
        HookNativeLoad(env);
    }

    void HookNativeLoad(JNIEnv *env) {
        jni::ScopedLocalRefJNIEnv se(env);

        ADEFINE(env->ExceptionClear());
        jclass mark_class = se.FindClass(
                "com/tencent/mobileqq/nativememorymonitor/library/ClassToFindJniOffset");
        ACHECK(mark_class);

        jmethodID mark = se.GetStaticMethodID(mark_class, "mark", "()V");
        ACHECK(mark);

        jmethodID mark2 = se.GetStaticMethodID(mark_class, "mark2", "()V");
        ACHECK(mark2);

        auto ret = initJniMethodHook(env, mark, mark2, (void *) jniMethodToMark);
        ACHECK(ret, "initJniMethodHook fail");

        if (!hookJniMethod(env, "java/lang/Runtime", "nativeLoad",
                           "(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/String;)Ljava/lang/String;",
                           (void *) hookedRuntimeNativeLoad,
                           (void **) &originNativeLoad)) {
            if (!hookJniMethod(env, "java/lang/Runtime", "nativeLoad",
                               "(Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/String;",
                               (void *) hookedRuntimeNativeLoad_9_0,
                               (void **) &originNativeLoad_9_0)) {
                LOGE("hook nativeLoad fail");
            }
        }
    }

    void afterSoLoad(const char *library_path, jobject java_loader) override {
        ADEFINE_DEFER();
        ACHECK(is_valid_ && java_loader);

        auto env = jni::Ext::GetEnv(g_vm);
        ACHECK(env);

        if (env.ExceptionCheck()) {
            env.ExceptionDescribe();
            return;
        }

        auto std_path = FindLibrary(env, java_loader, library_path);
        LOGE("std_path = %s", std_path.c_str());
        ACHECK(!std_path.empty());

        auto segments = ProcMaps::SelfSegments();
        HookAndCheckSo(env, segments, std_path, java_loader);
    }

private:
    void HookAndCheckSo(jni::ScopedLocalRefJNIEnv &env,
                        const std::vector<MapsSegment> &segments,
                        const std::string &library_path,
                        jobject java_loader) {
        ADEFINE();
        ACHECK(!HasHooked(library_path));

        AddHookedList(library_path);
        OnSoLoad(env, library_path.c_str(), java_loader != nullptr);

        int ret = hookFunc(library_path.c_str(), "dlopen", (void *) dlopen, (void *) my_dlopen);
        if (ret) {
            LOGW("hook dlopen in %s with error code: %d", library_path.c_str(), ret);
        }

        auto module = ProcMaps::GetFirstModuleSegment(segments, library_path.c_str());
        ACHECK(module && module.GetOffset() == 0 && !module.HasDeleted());
        ACHECK(ProcMaps::IsValidPtr((void *) module.GetStartAddress(), module.GetLength()));

        auto lib = dlfcn::dlopen(module.GetStartAddress(), library_path);
        ACHECK(lib);

        auto needed = lib->GetNeeded();
        for (auto need : needed) {
            auto needed_path = GetLibraryFullPath(env, segments, library_path, java_loader, need);
            if (needed_path.empty() || IsSystemSo(needed_path.c_str())) {
                continue;
            }
            LOGV("needed: %s -> %s", need, needed_path.c_str());
            HookAndCheckSo(env, segments, needed_path, java_loader);
        }
//        if (!CheckSign(library_path)) {
//            LOGE("CheckSign failed");
//        }
    }

    void OnSoLoad(jni::ScopedLocalRefJNIEnv &env, const char *so_path, bool from_java) {
        if (monitor_class_ && on_so_load_mid_) {
            std::string backtrace;
            if (from_java) {
                backtrace = jni::Ext::GetStackTrace(env);
            } else {
                BacktraceState *trace = capturePC(3);
                backtrace = getBacktrace(trace->pc, trace->size);
                delete trace;
            }

            env.CallStaticVoidMethod(monitor_class_, on_so_load_mid_,
                                     env.NewStringUTF(so_path),
                                     env.NewStringUTF(backtrace.c_str()));
        }
    }

    std::string GetLibraryFullPath(jni::ScopedLocalRefJNIEnv &env,
                                   const std::vector<MapsSegment> &segments,
                                   const std::string &library_path,
                                   jobject java_loader,
                                   const char *needed) {
        auto path = fs::path(library_path).parent_path().append(needed);
        if (fs::exists(path)) {
            return path.native();
        }

        path = fs::path(native_lib_dir_).append(needed);
        if (fs::exists(path)) {
            return path.native();
        }

        if (java_loader) {
            return FindLibrary(env, java_loader, needed);
        }
        return "";
    }

    static SoLoadHooker *&Instance() {
        static SoLoadHooker *thiz;
        return thiz;
    }

    static void *my_dlopen(const char *filename, int flag) {
        LOGD("name: %s, flag: %d", filename, flag);
        auto linker = bionic::Linker::Get();
        if (!linker) {
            LOGE("get linker error");
            return nullptr;
        }

        const void *caller_addr = __builtin_return_address(0);
        auto ret = linker.dlopen(filename, flag, caller_addr);
        if (!ret) {
            LOGE("dlopen error: %s", filename);
            return nullptr;
        }

        ADEFINE_DEFER(ret);
        ACHECK(filename);
        ACHECK(Instance() && Instance()->is_valid_);

        auto segments = ProcMaps::SelfSegments();
        auto module = ProcMaps::GetFirstModuleSegment(segments, filename);
        ACHECK(module && !IsSystemSo(module.GetPath()) && module.GetOffset() == 0 && !module.HasDeleted());

        auto se = jni::Ext::GetEnv(g_vm);
        if (!se) {
            JNIEnv *env = nullptr;
            g_vm->AttachCurrentThread(&env, nullptr);
            if (env) {
                se.Init(env);
                defer([&]() {
                    g_vm->DetachCurrentThread();
                });
            }
        }
        ACHECK(se);

        Instance()->HookAndCheckSo(se, segments, module.GetPath(), nullptr);
        return ret;
    }

    void AddHookedList(const std::string &path) {
        std::lock_guard<std::mutex> guard(hooked_list_mutex_);
        hooked_list_.insert(path);
    }

    bool HasHooked(const std::string &path) {
        std::lock_guard<std::mutex> guard(hooked_list_mutex_);
        return hooked_list_.count(path) > 0;
    }

    static bool CheckSign(const std::string &so_path) {
        fs::path path(so_path);
        auto sig_file = path.replace_extension("sig");

        ADEFINE(false);
        ACHECK(fs::exists(sig_file));

        auto file = fopen(sig_file.native().c_str(), "re");
        ACHECK(file);
        auto sig_info = ParseSigInfo(file);
        fclose(file);

        const auto &ver = sig_info["ver"];
        const auto &date = sig_info["date"];
        const auto &timestamp = sig_info["timestamp"];
        const auto sign = (uint32_t) strtoll(sig_info["sign"].c_str(), nullptr, 16);

        uint32_t calc_sign = (uint32_t) -1;
        if (ver == "1.0") {
            calc_sign = CreateSignV1_0(so_path, date, timestamp);
            LOGW("%s: calc_sign = %x, sign = %x", path.filename().native().c_str(), calc_sign, sign);
        }

        if (!calc_sign) {
            return true;
        }
        return calc_sign == sign;
    }

    static inline void Write(void *buf, uint32_t data) {
        ((char *) buf)[0] = static_cast<char>(data >> 24 & 0xFF);
        ((char *) buf)[1] = static_cast<char>(data >> 16 & 0xFF);
        ((char *) buf)[2] = static_cast<char>(data >> 8 & 0xFF);
        ((char *) buf)[3] = static_cast<char>(data >> 0 & 0xFF);
    }

    // layout =
    //     filename +
    //     time +
    //     file_length +
    //     date +
    //     readfile(check_file_size);
    // sign = custom_crc(layout);
    static uint32_t CreateSignV1_0(const fs::path &so_path,
                                   const std::string &date,
                                   const std::string &timestamp) {
        constexpr size_t kCheckFileSize = 4000;
        auto check_file_size = kCheckFileSize;
        auto file_length = (uint32_t) fs::file_size(so_path);
        if (file_length < kCheckFileSize) {
            check_file_size = (size_t) file_length;
        }
        auto filename = so_path.filename().native();
        const auto time = (uint32_t) atoll(timestamp.c_str());
        auto buf_size = filename.size() + sizeof(time) + sizeof(file_length) + date.size() + check_file_size;

        std::shared_ptr<char> buf(new char[buf_size]);
        char *pos = buf.get();
        memcpy(pos, filename.c_str(), filename.size());
        pos += filename.size();

        Write(pos, time);
        pos += sizeof(time);

        Write(pos, file_length);
        pos += sizeof(file_length);

        memcpy(pos, date.c_str(), date.size());
        pos += date.size();

        ADEFINE(0);
        auto file = fopen(so_path.native().c_str(), "re");
        ACHECK(file);
        auto count = fread(pos, check_file_size, 1, file);
        fclose(file);
        ACHECK(count);

        uint32_t sign = 0;
        for (size_t i = 0; i < buf_size; i++) {
            uint32_t b = (uint32_t) buf.get()[i];
            if ((b & 1) != 0) {
                sign ^= (b << 9) ^ 0xEDB88320;
            } else {
                sign ^= b >> 1;
            }
        }
        return sign;
    }

    static std::map<std::string, std::string> ParseSigInfo(FILE *file) {
        std::map<std::string, std::string> sign;
        char line[256];
        while (fgets(line, sizeof(line), file) != nullptr) {
            char *value = nullptr;
            auto key = strtok_r(line, ":", &value);
            if (key && value) {
                sign[absl::StripAsciiWhitespace(key).data()] = absl::StripAsciiWhitespace(value);
            }
        }
        return sign;
    }

private:
    const std::string &native_lib_dir_;
    jclass monitor_class_;
    jmethodID on_so_load_mid_;
    std::set<std::string> hooked_list_{};
    std::mutex hooked_list_mutex_{};
    bool is_valid_ = false;
};

#endif //NATIVEMEMORY_SO_LOAD_HOOKER_H
