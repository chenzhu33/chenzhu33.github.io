//
// Created by hongpingwu on 2018/3/19.
//

#include "include/backtrace.h"
#include <iomanip>

#include <dlfcn.h>
#include "../../libunwind/include/unwind.h"

const size_t DEPTH = 16;
const size_t DEFAULT_DEPTH = 8;
// 默认跳过一层，capturePC
const size_t SKIP = 1;
jclass exceptionReporter = nullptr;
jmethodID reportMethod = nullptr;

namespace {

    struct BacktraceStateWrapper{
        BacktraceState* state;
        size_t actualSize = 0;
        size_t skip = SKIP;
    };

    static inline void copy(void** src, void** dest, size_t size){
        for(size_t i = 0; i < size; i++){
            dest[i] = src[i];
        }
    }

    static _Unwind_Reason_Code unwindCallback(struct _Unwind_Context* context, void* arg)
    {
        BacktraceStateWrapper* wrapper = static_cast<BacktraceStateWrapper*>(arg);
        if(wrapper->actualSize++ < wrapper->skip){
            return _URC_NO_REASON;
        }
        BacktraceState* state = wrapper->state;
        uintptr_t pc = _Unwind_GetIP(context);
        if (pc) {
            if (state->size == DEPTH) {
                return _URC_END_OF_STACK;
            } else if(state->size == DEFAULT_DEPTH){
                void** buffer = (void **) malloc(sizeof(void*) * DEPTH);
                if(!buffer){
                    // 内存不足就不抓了
                    return _URC_END_OF_STACK;
                }
                copy(state->pc, buffer, DEFAULT_DEPTH);
                free(state->pc);
                state->pc = buffer;
            }
            *(state->pc + (state->size++)) = reinterpret_cast<void*>(pc);
            return _URC_NO_REASON;
        }
        return _URC_END_OF_STACK;
    }

}

/**
 * 回溯调用栈的pc
 * @param skip 跳过层数，自动加上默认的1
 * @return
 */
BacktraceState* capturePC(size_t skip){
    void** buffer = (void **) malloc(sizeof(void*) * DEFAULT_DEPTH);
    if(buffer == NULL){
        return NULL;
    }
    BacktraceStateWrapper wrapper;
    BacktraceState* state = new BacktraceState(buffer, 0);
    wrapper.state = state;
    wrapper.skip = skip + SKIP;
    _Unwind_Backtrace(unwindCallback, &wrapper);
//    __android_log_print(ANDROID_LOG_INFO  , "ProjectName", "trace size: %ld", state->size);
    return state;
}

BacktraceState* capturePC(){
    void** buffer = (void **) malloc(sizeof(void*) * DEFAULT_DEPTH);
    if(buffer == NULL){
        return NULL;
    }
    BacktraceStateWrapper wrapper;
    BacktraceState* state = new BacktraceState(buffer, 0);
    wrapper.state = state;
    _Unwind_Backtrace(unwindCallback, &wrapper);
//    __android_log_print(ANDROID_LOG_INFO  , "ProjectName", "trace size: %ld", state->size);
    return state;
}

std::string getBacktrace(void** buffer, size_t count) {
    std::ostringstream os;
    for (size_t idx = 0; idx < count; ++idx) {
        const void* addr = buffer[idx];
        const char* symbol = "";

        Dl_info info;
        if (dladdr(addr, &info) && info.dli_sname) {
            symbol = info.dli_sname;
        }
        os << "#" << std::setw(2) << idx << ": " << addr << " " << info.dli_fname << "+" << (void*)((uintptr_t)addr - (uintptr_t)info.dli_fbase) <<"  " << symbol << "\n";
    }
    return os.str();
}

void getBacktrace(void** buffer, size_t count, std::ostringstream &os){
    for (size_t idx = 0; idx < count; ++idx) {
        const void* addr = buffer[idx];
        const char* symbol = "";

        Dl_info info;
        if (dladdr(addr, &info) && info.dli_sname) {
            symbol = info.dli_sname;
        }

        os << "#" << std::setw(2) << idx << ": " << addr << " " << info.dli_fname << "+" << (void*)((uintptr_t)addr - (uintptr_t)info.dli_fbase) <<"  " << symbol << "\n";
    }
}

int containsPC(void ** buffer, size_t count, void * pc){
    // 假设参数合法
    for (size_t i = 0; i < count; ++i) {
        if (buffer[i] == pc){
            return 1;
        }
    }

    return 0;
}

void report(JNIEnv* env, const char* tag, BacktraceState* trace, size_t malloc_size){
    if(!trace) {
        ALOGE("[error] report trace is null");
        return;
    }
    std::ostringstream* os = new std::ostringstream();
    *os << "[hooked] malloc error, malloc_size";
    *os << malloc_size;
    *os << ", the top traces are: \n";
    getBacktrace(trace->pc, trace->size, *os);
    *os << "\n";
    report(env,tag, os->str().c_str());
}

void report(JNIEnv* env, const char* tag, BacktraceState* trace, int64_t time_limited, int64_t count_limited){
    if(!trace) {
        ALOGE("[error] report trace is null");
        return;
    }
    std::ostringstream* os = new std::ostringstream();
    *os << "[hooked] malloc over_allocate_per,";
    *os << "time_limited:"<< time_limited;
    *os << "count_limited:"<< count_limited;
    *os << "the top traces are: \n";
    getBacktrace(trace->pc, trace->size, *os);
    *os << "\n";
    report(env,tag, os->str().c_str());
}

void report(JNIEnv* env, const char* tag, const char* msg){
    if(!exceptionReporter || !reportMethod){
        ALOGE("QQCatchedExceptionReporter not found");
        return;
    }
    jstring extraMsg = env->NewStringUTF(msg);
    jstring jTag = env->NewStringUTF(tag);
    env->CallStaticVoidMethod(exceptionReporter, reportMethod, jTag, extraMsg);
    if(originDeleteLocalRef){
        originDeleteLocalRef(env, extraMsg);
        originDeleteLocalRef(env, jTag);
    } else {
        env->DeleteLocalRef(extraMsg);
        env->DeleteLocalRef(jTag);
    }
}

void initBacktraceTool(JNIEnv* env){
    jclass tmp = env->FindClass("com/tencent/mobileqq/statistics/QQCatchedExceptionReporter");
    if (env->ExceptionCheck()) {  // 检查JNI调用是否有引发异常
        env->ExceptionDescribe();
        env->ExceptionClear();        // 清除引发的异常
        return;
    }
    exceptionReporter = (jclass) env->NewGlobalRef(tmp);
    reportMethod =  env -> GetStaticMethodID(exceptionReporter, "reportQQCatchException"
            , "(Ljava/lang/String;Ljava/lang/String;)V");
    if (env->ExceptionCheck()) {  // 检查JNI调用是否有引发异常
        env->ExceptionDescribe();
        env->ExceptionClear();        // 清除引发的异常
        env->DeleteGlobalRef(exceptionReporter);
        return;
    }
}

