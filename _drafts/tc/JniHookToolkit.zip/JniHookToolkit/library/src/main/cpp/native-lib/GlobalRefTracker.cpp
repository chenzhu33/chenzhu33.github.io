//
// Created by hongpingwu on 2018/3/19.
//

#include "include/GlobalRefTracker.h"
#include "hookUtil/include/backtrace.h"
#include "include/alog.h"

#include <jni.h>
#include <map>
#include <mutex>
#include <set>

#define PAGE_SIZE 4096

#define MAX_GLOBAL_REF 50000
#define MIN_GLOBAL_REF 1000

static mutex globalLock;
static int globalRefCount = 0;
static bool globalOverflowReport = false;
static map<BacktraceState*, set<jobject>*, cmpFunc> globalRefBacktrace;
static map<jobject, BacktraceState*> globalRefRecord;


std::vector<std::string> NewGlobalRefTracker::topicToSubscribe() {
    return {"/GlobalRefHooker/NewGlobalRef/after"};
}

void NewGlobalRefTracker::onMessage(std::string topic, FuncParamType& funcParam) {
    jobject obj = (jobject)funcParam.retValuePtr;
    if(obj) {
        BacktraceState* trace = capturePC();
        if (!trace)
            return;

        globalLock.lock();
        globalRefCount++;

        map<BacktraceState*, set<jobject>*>::iterator it = globalRefBacktrace.find(trace);
        set<jobject> *objSet;
        if (it != globalRefBacktrace.end()) {
            delete(trace);
            trace = it->first;
            objSet = it->second;
            objSet->insert(obj);
        } else {
            objSet = new set<jobject>();
            objSet->insert(obj);
            globalRefBacktrace[trace] = objSet;
        }
        if(globalRefCount > MAX_GLOBAL_REF && !globalOverflowReport){
            globalOverflowReport = true;
            dump(globalRefBacktrace);
        } else if(globalRefCount < MIN_GLOBAL_REF){
            globalOverflowReport = false;
        }
        globalRefRecord[obj] = trace;
        globalLock.unlock();
    }
}

std::vector<std::string> DeleteGlobalRefTracker::topicToSubscribe() {
    return {"/GlobalRefHooker/DeleteGlobalRef/after"};
}

void DeleteGlobalRefTracker::onMessage(std::string topic, FuncParamType& funcParam) {
    jobject target = (jobject) funcParam.paramPtrList[1];
    if(target) {
        globalLock.lock();
        BacktraceState *trace = globalRefRecord[target];
        if(trace) {
            set<jobject> *objSet = globalRefBacktrace[trace];
            if (objSet) {
                objSet->erase(target);
                if (objSet->size() == 0) {
                    globalRefBacktrace.erase(trace);
                    delete (trace);
                }
            }
        }
        globalRefRecord.erase(target);
        globalRefCount = globalRefCount <= 0 ? 0 : globalRefCount - 1;
        globalLock.unlock();
    }
}
