//
// Created by ghostshi on 2018/2/7.
//

#include <stdint.h>

#ifndef GOTHOOKLIBRARY_UTIL_H
#define GOTHOOKLIBRARY_UTIL_H

uintptr_t GetModuleBaseAddr(const char* module_name);

#endif //GOTHOOKLIBRARY_UTIL_H
