//
// Created by ghostshi on 2018/3/26.
//

#include <stdio.h>
#include <jni.h>
#include <pthread.h>
#include <include/base/macros.h>
#include <include/log/log.h>
#include <include/jni/scoped_local_ref_jni_env.h>
#include "include/alog.h"
#include "include/global_variables.h"

JavaVM* g_vm = nullptr;
static jclass clazz = nullptr;
static jmethodID logErrorMethod = nullptr;
static jmethodID  logInfoMethod = nullptr;

//这里调用了AttachCurrentThread，调用者要视情况，在native自己创建的线程里面Detach
extern JNIEnv* getJniEnv(int *isAttachThread) {
    //*isAttachThread回传给上层做处理
    JNIEnv* env = nullptr;
    int getEnvStat = g_vm->GetEnv((void **)&env, JNI_VERSION_1_4);
    if (getEnvStat == JNI_EDETACHED) {
        ALOGE("jvm not attached");
        if (g_vm->AttachCurrentThread(&env, NULL) != 0) {
            ALOGE("fail to attach");
        }
        *isAttachThread = 1;
    } else if (getEnvStat == JNI_OK) {
        *isAttachThread = 0;
    } else if (getEnvStat == JNI_EVERSION) {
        *isAttachThread = 0;
        ALOGE("GetEnv: version not supported");
    }

    return env;
}


extern void _detach_current_thread() {
    JNIEnv* env = nullptr;
    int getEnvStat = g_vm->GetEnv((void **)&env, JNI_VERSION_1_4);
    if (getEnvStat == JNI_EDETACHED) {
        ALOGE("jvm not attached");
    } else if (getEnvStat == JNI_OK) {
        g_vm->DetachCurrentThread();
        pthread_t tid = pthread_self();
        ALOGD("detach %d",tid);
    } else if (getEnvStat == JNI_EVERSION) {
        ALOGE("GetEnv: version not supported");
    }
}

static inline bool findClassIfNecessary(jni::ScopedLocalRefJNIEnv &env) {
    if (clazz != nullptr) {
        return true;
    }
    ADEFINE(env.ExceptionClear(), false);

    auto klass = env.FindClass("com/tencent/mobileqq/nativememorymonitor/library/NativeMemoryMonitor");
    ACHECK(klass);

    clazz = (jclass) env.NewGlobalRef(klass);
    ACHECK(clazz);

    return true;
}

static inline bool findLogMethodIfNecessary(JNIEnv* env) {
    ADEFINE(env->ExceptionClear(), false);

    jni::ScopedLocalRefJNIEnv se(env);
    ACHECK(findClassIfNecessary(se));

    if (nullptr == logErrorMethod) {
        logErrorMethod = env->GetStaticMethodID(clazz, "logErrorFromNative", "(Ljava/lang/String;)V");
        ACHECK(logErrorMethod);
    }

    if (nullptr == logInfoMethod) {
        logInfoMethod = env->GetStaticMethodID(clazz, "logInfoFromNative", "(Ljava/lang/String;)V");
        ACHECK(logInfoMethod);
    }

    return true;
}

void logErrorToJava(const char *fmt, ...) {
    int isAttachThread = 0;
    JNIEnv* env = getJniEnv(&isAttachThread);
    jstring str;

    if (nullptr == env) {
        goto fail;
    }

    if (!findLogMethodIfNecessary(env)) {
        // ALOGE("fail to find method needed");
        goto fail;
    }

    char buffer[256];
    va_list args;
    va_start (args, fmt);
    vsprintf (buffer, fmt, args);
    va_end (args);

    str = env->NewStringUTF(buffer);
    if (str == nullptr) {
        goto fail;
    }

    env->CallStaticVoidMethod(clazz, logErrorMethod, str);

    fail:
    env->ExceptionClear();
    if (isAttachThread) {
        _detach_current_thread();
    }
    return;
}

void logInfoToJava(const char *fmt, ...) {
    int isAttachThread = 0;
    JNIEnv* env = getJniEnv(&isAttachThread);
    jstring str;

    if (nullptr == env) {
        goto fail;
    }

    if (!findLogMethodIfNecessary(env)) {
        // ALOGE("fail to find method needed");
        goto fail;
    }

    char buffer[256];
    va_list args;
    va_start (args, fmt);
    vsprintf (buffer, fmt, args);
    va_end (args);

    str = env->NewStringUTF(buffer);
    if (str == nullptr) {
        goto fail;
    }

    env->CallStaticVoidMethod(clazz, logInfoMethod, str);

    fail:
    env->ExceptionClear();
    if (isAttachThread) {
        _detach_current_thread();
    }
    return;
}
