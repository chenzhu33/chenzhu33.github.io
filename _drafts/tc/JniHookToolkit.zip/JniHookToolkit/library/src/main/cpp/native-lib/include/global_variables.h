//
// Created by ghostshi on 2018/3/26.
//

#ifndef JNI_HOOK_TOOLKIT_GLOBAL_VARIABLES_H
#define JNI_HOOK_TOOLKIT_GLOBAL_VARIABLES_H

#include <jni.h>

extern JavaVM* g_vm;

#endif //JNI_HOOK_TOOLKIT_GLOBAL_VARIABLES_H
