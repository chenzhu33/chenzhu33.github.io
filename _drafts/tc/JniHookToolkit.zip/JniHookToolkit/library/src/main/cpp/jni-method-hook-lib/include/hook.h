//
// Created by ghostshi on 2018/3/14.
//

#ifndef JNI_HOOK_TOOLKIT_JNJ_METHOD_HOOK_LIB_HOOK_H
#define JNI_HOOK_TOOLKIT_JNJ_METHOD_HOOK_LIB_HOOK_H

#include <jni.h>

#define MAX_OFFSET_TO_FIND 100

bool initJniMethodHook(JNIEnv *env, jmethodID jmethodID1, jmethodID jmethodID2, void *jniFuncPtr);

bool hookJniMethod(JNIEnv* env, const char* className, const char* methodName, const char* methodSignature, void* replacedFunc, void** originFuncPtr);

#endif //JNI_HOOK_TOOLKIT_JNJ_METHOD_HOOK_LIB_HOOK_H
