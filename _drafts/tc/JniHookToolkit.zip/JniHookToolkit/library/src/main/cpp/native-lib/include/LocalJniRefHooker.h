//
// Created by hongpingwu on 2018/3/22.
//

#ifndef _NATIVEMEMORY_JNIREFHOOKER_H_
#define _NATIVEMEMORY_JNIREFHOOKER_H_

#include <jni.h>
#include <map>
#include <mutex>
#include <set>
#include "alog.h"
#include "../hookUtil/include/backtrace.h"

using namespace std;

/**
 * 记录一次增加引用的信息
 */
struct AddRefRecord{
    /**
     * 数组下标
     */
    int32_t index;
    /**
     * 数组下一个写入位置
     */
    int32_t topIndex;
    /**
     * 创建的间接引用
     */
    jobject ref;
    /**
     * 调用栈
     */
    BacktraceState * pTrace;
};

class LocalJniRefHooker {
    bool refOverflowReport = false;
    map<BacktraceState*, set<jobject>, cmpFunc> refBacktrace;
    map<jobject, AddRefRecord*> refRecord;
    size_t maxRef;
    size_t minRef;
    const char* tag;
    /**
     * 上一个栈顶下标
     */
    int lastTopIndex = 0;
    bool bLogOverflow = false;

public:
    LocalJniRefHooker(size_t _maxRef, size_t _minRef, const char* _tag):
            maxRef(_maxRef), minRef(_minRef), tag(_tag) {}
    void addRef(JNIEnv* env, jobject ref);
    void deleteRef(JNIEnv* env, jobject ref);

private:
    void removeItemsBelowTopIndex(JNIEnv * env);
    void setLastTopIndex(const int lastTopIndex);
    void removeItem(AddRefRecord * pRecord);
};


#endif
