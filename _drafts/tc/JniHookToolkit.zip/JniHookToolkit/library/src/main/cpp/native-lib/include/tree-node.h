//
// Created by ghostshi on 2018/3/16.
//

#ifndef JNI_HOOK_TOOLKIT_TOPICFINDER_H
#define JNI_HOOK_TOOLKIT_TOPICFINDER_H

#include <string>
#include <memory>
#include <map>
#include <list>

class TreeNode;

typedef std::shared_ptr<TreeNode> TreeNodePtr;

class BaseTracker;

typedef std::shared_ptr<BaseTracker> BaseTrackerPtr;

class TreeNode {
public:
    std::string pathName;
    std::map<std::string, TreeNodePtr> subPathList;
    TreeNodePtr father = nullptr;

    std::list<BaseTrackerPtr> trackers;

    std::string getFullPath();

    TreeNode(std::string name) : pathName(name) {}
};

#endif //JNI_HOOK_TOOLKIT_TOPICFINDER_H
