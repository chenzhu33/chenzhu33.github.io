//
// Created by ghostshi on 2018/3/15.
//

#ifndef JNI_HOOK_TOOLKIT_JNI_FUNC_HOOK_UTIL_H
#define JNI_HOOK_TOOLKIT_JNI_FUNC_HOOK_UTIL_H

void replaceJniEnvFunction(void** originFuncPtr, void* replacedFunc);

/**
 * dump 间接引用表。不要在 hook 函数内部调用，可能会导致递归 hook
 * @param env
 */
void dumpReferenceTable(JNIEnv *env);

#endif //JNI_HOOK_TOOLKIT_JNI_FUNC_HOOK_UTIL_H
