//
// Created by hongpingwu on 2018/3/19.
//

#include <jni.h>
#include "include/GlobalRefHooker.h"
#include "hookUtil/include/jni-func-hook-util.h"
#include "hookUtil/include/QJNIInterface.h"
#include "include/alog.h"
#include "hookUtil/include/backtrace.h"
#include "include/JniRefHooker.h"

#define MAX_GLOBAL_REF 48000
#define MIN_GLOBAL_REF 1000
#define TAG "GlobalRefOverFlowCatchedException"

using namespace std;

//static GlobalRefHooker* hookerPtr;
static JniRefHooker* refHooker = nullptr;

jobject (*NewGlobalRefOrigin)(JNIEnv*, jobject);
void (*DeleteGlobalRefOrigin)(JNIEnv*, jobject);

static jobject global_ref_hook(JNIEnv* env, jobject target) {
//    hookerPtr->talkBeforeOriginFuncCalled("NewGlobalRef", 0, 2, env, target);
    jobject obj = NewGlobalRefOrigin(env, target);
    refHooker->addRef(env, obj);
//    hookerPtr->talkAfterOriginFuncCalled("NewGlobalRef", 0, obj, 2, env, target);
    return obj;
}

static void delete_global_ref_hook(JNIEnv* env, jobject target) {
//    hookerPtr->talkBeforeOriginFuncCalled("DeleteGlobalRef", 0, 2, env, target);
    DeleteGlobalRefOrigin(env, target);
    refHooker->deleteRef(env, target);
//    hookerPtr->talkAfterOriginFuncCalled("DeleteGlobalRef", 0, NULL, 2, env, target);
}

GlobalRefHooker::GlobalRefHooker(NativeMonitor* monitor) : BaseHooker("GlobalRefHooker", monitor) {

}

void GlobalRefHooker::beforeHook(int n, ...){
    va_list args;
    va_start(args, n);
    JNIEnv* env = va_arg(args, JNIEnv*);
    va_end(args);
    JNINativeInterface *structPtr = const_cast<JNINativeInterface *>(env->functions);

    DeleteGlobalRefOrigin = structPtr->DeleteGlobalRef;
    NewGlobalRefOrigin = structPtr->NewGlobalRef;
}

void GlobalRefHooker::onInit(int n, ...) {
//    hookerPtr = this;
    refHooker = new JniRefHooker(MAX_GLOBAL_REF, MIN_GLOBAL_REF, TAG);

    // hook jni
    va_list args;
    va_start(args, n);
    JNIEnv* env = va_arg(args, JNIEnv*);
    va_end(args);
    JNINativeInterface *structPtr = const_cast<JNINativeInterface *>(env->functions);
    replaceJniEnvFunction((void **) &(structPtr->DeleteGlobalRef), (void *) delete_global_ref_hook);
    replaceJniEnvFunction((void **) &(structPtr->NewGlobalRef), (void *) global_ref_hook);

    ALOGIJAVA("%s", "GlobalRef is hooked");
}