//
// Created by hongpingwu on 2018/3/20.
//

#include "include/LocalRefTracker.h"
#include "hookUtil/include/backtrace.h"
#include "include/alog.h"

#include <jni.h>
#include <map>
#include <mutex>
#include <set>

#define PAGE_SIZE 4096

#define MAX_LOCAL_REF 450
#define MIN_LOCAL_REF 50

static mutex localLock;
static int localRefCount = 0;
static bool localOverflowReport = false;
static map<BacktraceState*, set<jobject>*, cmpFunc> localRefBacktrace;
static map<jobject, BacktraceState*> localRefRecord;

void newLocalRef(BacktraceState* trace, jobject obj){
    localLock.lock();
    localRefCount++;

    map<BacktraceState*, set<jobject>*>::iterator it = localRefBacktrace.find(trace);
    set<jobject> *objSet;
    if (it != localRefBacktrace.end()) {
        delete(trace);
        trace = it->first;
        objSet = it->second;
        objSet->insert(obj);
    } else {
        objSet = new set<jobject>();
        objSet->insert(obj);
        localRefBacktrace[trace] = objSet;
    }
    if(localRefCount > MAX_LOCAL_REF && !localOverflowReport){
        localOverflowReport = true;
        dump(localRefBacktrace);
    } else if(localRefCount < MIN_LOCAL_REF){
        localOverflowReport = false;
    }
    localRefRecord[obj] = trace;
    localLock.unlock();
}


std::vector<std::string> NewLocalRefTracker::topicToSubscribe() {
    return {"/LocalRefHooker/NewLocalRef/after"};
}

void NewLocalRefTracker::onMessage(std::string topic, FuncParamType& funcParam) {
    ALOGI("new local ref");
    jobject obj = (jobject)funcParam.retValuePtr;
    if(obj) {
        BacktraceState* trace = capturePC();
        if(!trace)
            return;
        newLocalRef(trace, obj);
    }
}

std::vector<std::string> DeleteLocalRefTracker::topicToSubscribe() {
    return {"/LocalRefHooker/DeleteLocalRef/after"};
}

void DeleteLocalRefTracker::onMessage(std::string topic, FuncParamType& funcParam) {
    ALOGI("delete local ref");
    jobject target = (jobject) funcParam.paramPtrList[1];
    if(target) {
        localLock.lock();
        BacktraceState *trace = localRefRecord[target];
        if(trace) {
            set<jobject> *objSet = localRefBacktrace[trace];
            if (objSet) {
                objSet->erase(target);
                if (objSet->size() == 0) {
                    localRefBacktrace.erase(trace);
                    delete (trace);
                }
            }
        }
        localRefRecord.erase(target);
        localRefCount = localRefCount <= 0 ? 0 : localRefCount - 1;
        localLock.unlock();
    }
}

/**
 * 自测完后，下面几个tracker都可以用NewLocalRefTracker来代替
 */
std::vector<std::string> FindClassTracker::topicToSubscribe() {
    return {"/LocalRefHooker/FindClass/after"};
}

void FindClassTracker::onMessage(std::string topic, FuncParamType &funcParam) {
    ALOGI("find class");
    jobject obj = (jobject)funcParam.retValuePtr;
    if(obj) {
        BacktraceState* trace = capturePC();
        if(!trace)
            return;
        newLocalRef(trace, obj);
    }
}

std::vector<std::string> NewObjectVTracker::topicToSubscribe() {
    return {"/LocalRefHooker/NewObjectV/after"};
}

void NewObjectVTracker::onMessage(std::string topic, FuncParamType &funcParam) {
    ALOGI("NewObjectV");
    jobject obj = (jobject)funcParam.retValuePtr;
    if(obj) {
        BacktraceState* trace = capturePC();
        if(!trace)
            return;
        newLocalRef(trace, obj);
    }
}

std::vector<std::string> NewObjectATracker::topicToSubscribe() {
    return {"/LocalRefHooker/NewObjectA/after"};
}

void NewObjectATracker::onMessage(std::string topic, FuncParamType &funcParam) {
    ALOGI("NewObjectA");
    jobject obj = (jobject)funcParam.retValuePtr;
    if(obj) {
        BacktraceState* trace = capturePC();
        if(!trace)
            return;
        newLocalRef(trace, obj);
    }
}

std::vector<std::string> GetObjectClassTracker::topicToSubscribe() {
    return {"/LocalRefHooker/GetObjectClass/after"};
}

void GetObjectClassTracker::onMessage(std::string topic, FuncParamType &funcParam) {
    ALOGI("GetObjectClass");
    jobject obj = (jobject)funcParam.retValuePtr;
    if(obj) {
        BacktraceState* trace = capturePC();
        if(!trace)
            return;
        newLocalRef(trace, obj);
    }
}
