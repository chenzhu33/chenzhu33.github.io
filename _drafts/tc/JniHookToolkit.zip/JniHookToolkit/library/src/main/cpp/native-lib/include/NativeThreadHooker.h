//
// Created by hongpingwu on 2018/11/7.
//

#ifndef NATIVEMEMORY_NATIVETHREADHOOKER_H
#define NATIVEMEMORY_NATIVETHREADHOOKER_H


#include "../hookUtil/include/hooker.h"
#include "native-monitor.h"

class NativeThreadHooker : public BaseHooker {

public:
    NativeThreadHooker(NativeMonitor* monitor);

    void onInit(int n, ...) override final ;
    void beforeHook(int n, ...) override final;

    bool dumpUndetachThreads(std::ostringstream &os);
};


#endif //NATIVEMEMORY_NATIVETHREADHOOKER_H
