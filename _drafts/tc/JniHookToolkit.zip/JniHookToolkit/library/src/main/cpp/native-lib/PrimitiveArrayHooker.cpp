//
// Created by hongpingwu on 2018/3/21.
//

#include "include/PrimitiveArrayHooker.h"
#include "hookUtil/include/jni-func-hook-util.h"
#include "hookUtil/include/QJNIInterface.h"
#include "include/alog.h"
#include <jni.h>
#include <map>
#include <mutex>
#include <set>
#include <dlfcn.h>
#include "hookUtil/include/backtrace.h"

#define MAX_PINNED_REF 900
#define MIN_PINNED_REF 100
#define TAG "PinnedRefTableOverflowCatchedException"

//static PrimitiveArrayHooker* primitiveArrayHookerPtr = nullptr;
static mutex refLock;
static int refCount = 0;
static bool refOverflowReport = false;
static map<BacktraceState*, set<void**>, cmpFunc> refBacktrace;
static map<void**, BacktraceState*> refRecord;

const jchar* (*originGetStringChars)(JNIEnv*, jstring, jboolean*);
jboolean*   (*originGetBooleanArrayElements)(JNIEnv*, jbooleanArray, jboolean*);
jbyte*      (*originGetByteArrayElements)(JNIEnv*, jbyteArray, jboolean*);
jchar*      (*originGetCharArrayElements)(JNIEnv*, jcharArray, jboolean*);
jshort*     (*originGetShortArrayElements)(JNIEnv*, jshortArray, jboolean*);
jint*       (*originGetIntArrayElements)(JNIEnv*, jintArray, jboolean*);
jlong*      (*originGetLongArrayElements)(JNIEnv*, jlongArray, jboolean*);
jfloat*     (*originGetFloatArrayElements)(JNIEnv*, jfloatArray, jboolean*);
jdouble*    (*originGetDoubleArrayElements)(JNIEnv*, jdoubleArray, jboolean*);
void*       (*originGetPrimitiveArrayCritical)(JNIEnv*, jarray, jboolean*);
const jchar* (*originGetStringCritical)(JNIEnv*, jstring, jboolean*);

void        (*originReleaseStringChars)(JNIEnv*, jstring, const jchar*);
void        (*originReleaseBooleanArrayElements)(JNIEnv*, jbooleanArray, jboolean*, jint);
void        (*originReleaseByteArrayElements)(JNIEnv*, jbyteArray, jbyte*, jint);
void        (*originReleaseCharArrayElements)(JNIEnv*, jcharArray, jchar*, jint);
void        (*originReleaseShortArrayElements)(JNIEnv*, jshortArray, jshort*, jint);
void        (*originReleaseIntArrayElements)(JNIEnv*, jintArray, jint*, jint);
void        (*originReleaseLongArrayElements)(JNIEnv*, jlongArray, jlong*, jint);
void        (*originReleaseFloatArrayElements)(JNIEnv*, jfloatArray, jfloat*, jint);
void        (*originReleaseDoubleArrayElements)(JNIEnv*, jdoubleArray, jdouble*, jint);
void        (*originReleasePrimitiveArrayCritical)(JNIEnv*, jarray, void*, jint);
void        (*originReleaseStringCritical)(JNIEnv*, jstring, const jchar*);


/**
 * Get jniGetNonMovableArrayElements's address. time cost 3 ~ 23 ms on virtual machine
 * @param env
 * @return jniGetNonMovableArrayElements's address, NULL if not found
 */
static void * getJniGetNonMovableArrayElementsAddr(JNIEnv *env){
    void * handle = dlopen("libnativehelper.so", RTLD_LAZY);

    if (!handle){
        return NULL;
    }

    // clear error
    dlerror();

    void *addr = dlsym(handle, "jniGetNonMovableArrayElements");

    char * error = dlerror();
    if (error){
        dlclose(handle);
        return NULL;
    }

    dlclose(handle);

    return addr;
}

static bool filterBacktrace(JNIEnv * env, BacktraceState * trace){
    bool result = false;

    static void *nonMovableArrayElementsAddr = 0;
    static bool notFoundPC = false;

    if (!nonMovableArrayElementsAddr && !notFoundPC){
        nonMovableArrayElementsAddr = getJniGetNonMovableArrayElementsAddr(env);
    }

    if (!nonMovableArrayElementsAddr){
        notFoundPC = true;
    } else {
        size_t count = trace->size >= 2 ? 2 : trace->size;
        int ret = containsPC(trace->pc, count, nonMovableArrayElementsAddr);
        result = ret == 1;
    }

    return result;
}

static void addRef(JNIEnv* env, void** ref) {
    if(ref) {
        std::ostringstream* os = NULL;

        BacktraceState* trace = capturePC(2);
        if (!trace){
            return;
        }
        if (filterBacktrace(env, trace)){
            return;
        }

        // 用于控制 lock 的作用域
        {
            std::lock_guard<std::mutex> lock(refLock);
            map<BacktraceState*, set<void**>>::iterator it = refBacktrace.find(trace);
            if (it != refBacktrace.end()) {
                delete(trace);
                trace = it->first;;
            }
            refBacktrace[trace].insert(ref);
            if(refCount > MAX_PINNED_REF && !refOverflowReport){
                refOverflowReport = true;
                os = new std::ostringstream();
                *os  << "reference table overflow with limit: " << refCount << ", total call stacks: " << refBacktrace.size() << ", the top traces are: \n";
                getTopBacktrace(refBacktrace, *os);
            } else if(refCount < MIN_PINNED_REF){
                refOverflowReport = false;
            }
            refRecord[ref] = trace;
            refCount++;
        }

        if(os){
            report(env, TAG, os->str().c_str());
            delete os;
        }
    }
}

static void deleteRef(JNIEnv* env, void** ref) {
    if(ref) {
        std::lock_guard<std::mutex> lock(refLock);
        BacktraceState *trace = refRecord[ref];
        if(trace) {
            set<void**> &objSet = refBacktrace[trace];
            objSet.erase(ref);
            if (objSet.size() == 0) {
                refBacktrace.erase(trace);
                delete (trace);
            }
        }
        refRecord.erase(ref);
        refCount = refCount <= 0 ? 0 : refCount - 1;
    }
}


static const jchar* hookedGetStringChars(JNIEnv* env, jstring jstr, jboolean* isCopy){
//    primitiveArrayHookerPtr->talkBeforeOriginFuncCalled("GetStringChars", 0, 2, env, jstr, isCopy);
    const jchar* ret = originGetStringChars(env, jstr, isCopy);
    addRef(env, (void**)ret);
//    primitiveArrayHookerPtr->talkAfterOriginFuncCalled("GetStringChars", 0, ch, 2, env, jstr, isCopy);
    return ret;
}

static jboolean* hookedGetBooleanArrayElements(JNIEnv* env, jbooleanArray array, jboolean* is_copy){
//    primitiveArrayHookerPtr->talkBeforeOriginFuncCalled("GetBooleanArrayElements", 0, 2, env, array, is_copy);
    jboolean* ret = originGetBooleanArrayElements(env, array, is_copy);
    addRef(env, (void**) ret);
//    primitiveArrayHookerPtr->talkAfterOriginFuncCalled("GetBooleanArrayElements", 0, ret, 2, env, array, is_copy);
    return ret;
}

static jbyte* hookedGetByteArrayElements(JNIEnv* env, jbyteArray array, jboolean* is_copy) {
//    primitiveArrayHookerPtr->talkBeforeOriginFuncCalled("GetByteArrayElements", 0, 2, env, array, is_copy);
    jbyte* ret = originGetByteArrayElements(env, array, is_copy);
    addRef(env, (void**) ret);
//    primitiveArrayHookerPtr->talkAfterOriginFuncCalled("GetByteArrayElements", 0, ret, 2, env, array, is_copy);
    return ret;
}

static jchar* hookedGetCharArrayElements(JNIEnv* env, jcharArray array, jboolean* is_copy){
    jchar* ret = originGetCharArrayElements(env, array, is_copy);
    addRef(env, (void**) ret);
    return ret;
}

static jshort* hookedGetShortArrayElements(JNIEnv* env, jshortArray array, jboolean* is_copy){
    jshort* ret = originGetShortArrayElements(env, array, is_copy);
    addRef(env, (void**) ret);
    return ret;
}

static jint* hookedGetIntArrayElements(JNIEnv* env, jintArray array, jboolean* is_copy){
    jint* ret = originGetIntArrayElements(env, array, is_copy);
    addRef(env, (void**) ret);
    return ret;
}

static jlong* hookedGetLongArrayElements(JNIEnv* env, jlongArray array, jboolean* is_copy){
    jlong* ret = originGetLongArrayElements(env, array, is_copy);
    addRef(env, (void**) ret);
    return ret;
}

static jfloat* hookedGetFloatArrayElements(JNIEnv* env, jfloatArray array, jboolean* is_copy){
    jfloat* ret = originGetFloatArrayElements(env, array, is_copy);
    addRef(env, (void**) ret);
    return ret;
}

static jdouble* hookedGetDoubleArrayElements(JNIEnv* env, jdoubleArray array, jboolean* is_copy){
    jdouble * ret = originGetDoubleArrayElements(env, array, is_copy);
    addRef(env, (void**) ret);
    return ret;
}

static void* hookedGetPrimitiveArrayCritical(JNIEnv* env, jarray array, jboolean* is_copy){
    void * ret = originGetPrimitiveArrayCritical(env, array, is_copy);
    addRef(env, (void**) ret);
    return ret;
}

static const jchar* hookedGetStringCritical(JNIEnv* env, jstring jstr, jboolean* is_copy){
    const jchar* ret = originGetStringCritical(env, jstr, is_copy);
    addRef(env, (void**) ret);
    return ret;
}

static void hookedReleaseStringChars(JNIEnv * env, jstring jstr, const jchar *chars) {
    originReleaseStringChars(env, jstr, chars);
    deleteRef(env, (void**)chars);
}

static void hookedReleaseBooleanArrayElements(JNIEnv *env, jbooleanArray array, jboolean *elements, jint mode) {
    originReleaseBooleanArrayElements(env, array, elements, mode);
    deleteRef(env, (void **) elements);
}

static void hookedReleaseByteArrayElements(JNIEnv *env, jbyteArray array, jbyte *elements, jint mode) {
    originReleaseByteArrayElements(env, array, elements, mode);
    deleteRef(env, (void **) elements);
}

static void hookedReleaseCharArrayElements(JNIEnv* env, jcharArray array, jchar* elements, jint mode){
    originReleaseCharArrayElements(env, array, elements, mode);
    deleteRef(env, (void **) elements);
}
static void hookedReleaseShortArrayElements(JNIEnv* env, jshortArray array, jshort* elements, jint mode){
    originReleaseShortArrayElements(env, array, elements, mode);
    deleteRef(env, (void **) elements);
}
static void hookedReleaseIntArrayElements(JNIEnv* env, jintArray array, jint* elements, jint mode){
    originReleaseIntArrayElements(env, array, elements, mode);
    deleteRef(env, (void **) elements);
}

static void hookedReleaseLongArrayElements(JNIEnv* env, jlongArray array, jlong* elements, jint mode){
    originReleaseLongArrayElements(env, array, elements, mode);
    deleteRef(env, (void **) elements);
}

static void hookedReleaseFloatArrayElements(JNIEnv* env, jfloatArray array, jfloat* elements, jint mode){
    originReleaseFloatArrayElements(env, array, elements, mode);
    deleteRef(env, (void **) elements);
}

static void hookedReleaseDoubleArrayElements(JNIEnv* env, jdoubleArray array, jdouble* elements, jint mode){
    originReleaseDoubleArrayElements(env, array, elements, mode);
    deleteRef(env, (void **) elements);
}

static void hookedReleasePrimitiveArrayCritical(JNIEnv* env, jarray array, void* elements, jint mode){
    originReleasePrimitiveArrayCritical(env, array, elements, mode);
    deleteRef(env, (void **) elements);
}

static void hookedReleaseStringCritical(JNIEnv* env, jstring jstr, const jchar* elements){
    originReleaseStringCritical(env, jstr, elements);
    deleteRef(env, (void **) elements);
}

PrimitiveArrayHooker::PrimitiveArrayHooker(NativeMonitor* monitor) : BaseHooker("PrimitiveArrayHooker", monitor) {

}

void PrimitiveArrayHooker::beforeHook(int n, ...) {
    va_list args;
    va_start(args, n);
    JNIEnv* env = va_arg(args, JNIEnv*);
    va_end(args);
    JNINativeInterface *structPtr = const_cast<JNINativeInterface *>(env->functions);
    originReleaseStringChars = structPtr->ReleaseStringChars;
    originGetStringChars = structPtr->GetStringChars;

    originReleaseBooleanArrayElements = structPtr->ReleaseBooleanArrayElements;
    originGetBooleanArrayElements = structPtr->GetBooleanArrayElements;

    originReleaseByteArrayElements = structPtr->ReleaseByteArrayElements;
    originGetByteArrayElements = structPtr->GetByteArrayElements;

    originReleaseCharArrayElements = structPtr->ReleaseCharArrayElements;
    originGetCharArrayElements = structPtr->GetCharArrayElements;

    originReleaseShortArrayElements = structPtr->ReleaseShortArrayElements;
    originGetShortArrayElements = structPtr->GetShortArrayElements;

    originReleaseIntArrayElements = structPtr->ReleaseIntArrayElements;
    originGetIntArrayElements = structPtr->GetIntArrayElements;

    originReleaseLongArrayElements = structPtr->ReleaseLongArrayElements;
    originGetLongArrayElements = structPtr->GetLongArrayElements;

    originReleaseFloatArrayElements = structPtr->ReleaseFloatArrayElements;
    originGetFloatArrayElements = structPtr->GetFloatArrayElements;

    originReleaseDoubleArrayElements = structPtr->ReleaseDoubleArrayElements;
    originGetDoubleArrayElements = structPtr->GetDoubleArrayElements;

    originReleasePrimitiveArrayCritical = structPtr->ReleasePrimitiveArrayCritical;
    originGetPrimitiveArrayCritical = structPtr->GetPrimitiveArrayCritical;

    originReleaseStringCritical = structPtr->ReleaseStringCritical;
    originGetStringCritical = structPtr->GetStringCritical;
}

void PrimitiveArrayHooker::onInit(int n, ...) {
//    primitiveArrayHookerPtr = this;

    // hook jni
    va_list args;
    va_start(args, n);
    JNIEnv* env = va_arg(args, JNIEnv*);
    va_end(args);
    JNINativeInterface *structPtr = const_cast<JNINativeInterface *>(env->functions);

    replaceJniEnvFunction((void**) &(structPtr->ReleaseStringChars), (void*)hookedReleaseStringChars);
    replaceJniEnvFunction((void **) &(structPtr->GetStringChars), (void *) hookedGetStringChars);

    replaceJniEnvFunction((void**) &(structPtr->ReleaseBooleanArrayElements), (void*)hookedReleaseBooleanArrayElements);
    replaceJniEnvFunction((void **) &(structPtr->GetBooleanArrayElements), (void *) hookedGetBooleanArrayElements);

    replaceJniEnvFunction((void**) &(structPtr->ReleaseByteArrayElements), (void*)hookedReleaseByteArrayElements);
    replaceJniEnvFunction((void **) &(structPtr->GetByteArrayElements), (void *) hookedGetByteArrayElements);

    replaceJniEnvFunction((void **) &(structPtr->ReleaseCharArrayElements), (void *) hookedReleaseCharArrayElements);
    replaceJniEnvFunction((void **) &(structPtr->GetCharArrayElements), (void *) hookedGetCharArrayElements);

    replaceJniEnvFunction((void **) &(structPtr->ReleaseShortArrayElements), (void *) hookedReleaseShortArrayElements);
    replaceJniEnvFunction((void **) &(structPtr->GetShortArrayElements), (void *) hookedGetShortArrayElements);

    replaceJniEnvFunction((void **) &(structPtr->ReleaseIntArrayElements), (void *) hookedReleaseIntArrayElements);
    replaceJniEnvFunction((void **) &(structPtr->GetIntArrayElements), (void *) hookedGetIntArrayElements);

    replaceJniEnvFunction((void **) &(structPtr->ReleaseLongArrayElements), (void *) hookedReleaseLongArrayElements);
    replaceJniEnvFunction((void **) &(structPtr->GetLongArrayElements), (void *) hookedGetLongArrayElements);

    replaceJniEnvFunction((void **) &(structPtr->ReleaseFloatArrayElements), (void *) hookedReleaseFloatArrayElements);
    replaceJniEnvFunction((void **) &(structPtr->GetFloatArrayElements), (void *) hookedGetFloatArrayElements);

    replaceJniEnvFunction((void **) &(structPtr->ReleaseDoubleArrayElements), (void *) hookedReleaseDoubleArrayElements);
    replaceJniEnvFunction((void **) &(structPtr->GetDoubleArrayElements), (void *) hookedGetDoubleArrayElements);

    replaceJniEnvFunction((void **) &(structPtr->ReleasePrimitiveArrayCritical), (void *) hookedReleasePrimitiveArrayCritical);
    replaceJniEnvFunction((void **) &(structPtr->GetPrimitiveArrayCritical), (void *) hookedGetPrimitiveArrayCritical);

    replaceJniEnvFunction((void **) &(structPtr->ReleaseStringCritical), (void *) hookedReleaseStringCritical);
    replaceJniEnvFunction((void **) &(structPtr->GetStringCritical), (void *) hookedGetStringCritical);

    ALOGIJAVA("%s", "primitive array is hooked");
}