//
// Created by hongpingwu on 2018/3/19.
//

#ifndef NATIVEMEMORY_GLOBALREFTRACKER_H
#define NATIVEMEMORY_GLOBALREFTRACKER_H


#include "tracker.h"
#include <string.h>

class NewGlobalRefTracker : public BaseTracker{
public:
    NewGlobalRefTracker(NativeMonitor* monitor)
            : BaseTracker("NewGlobalRefTracker", monitor) {}

    std::vector<std::string> topicToSubscribe() override final ;
    void onMessage(std::string topic, FuncParamType& funcParam) override final ;

};

class DeleteGlobalRefTracker : public BaseTracker {
public:
    DeleteGlobalRefTracker(NativeMonitor* monitor)
            : BaseTracker("DeleteGlobalRefTracker", monitor) {}

    std::vector<std::string> topicToSubscribe() override final ;
    void onMessage(std::string topic, FuncParamType& funcParam) override final ;
};

#endif //NATIVEMEMORY_GLOBALREFTRACKER_H
