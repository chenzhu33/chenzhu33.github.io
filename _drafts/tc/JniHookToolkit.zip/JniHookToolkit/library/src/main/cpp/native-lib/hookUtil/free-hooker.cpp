//
// Created by ghostshi on 2018/3/14.
//

#include <malloc.h>
#include "include/free-hooker.h"
#include "../include/hook-lib.h"

static FreeHooker* freeHookerPtr = nullptr;

extern "C" {
void (*originFree)(void*);

void hookedFree(void* __ptr);

void hookedFree(void* __ptr) {
//    freeHookerPtr->talkBeforeOriginFuncCalled("free", 0, 1, &__ptr);
    originFree(__ptr);
//    freeHookerPtr->talkAfterOriginFuncCalled("free", 0, nullptr, 1, &__ptr);
}
};

void FreeHooker::onInit(int n, ...) {
    freeHookerPtr = this;
}

void FreeHooker::beforeSoLoad(const char *library_path, jobject java_loader) {
    // do nothing
}

void FreeHooker::afterSoLoad(const char *library_path, jobject java_loader) {
    originFree = free;
    int ret = hookFunc(library_path, "free", (void *)originFree, (void *) hookedFree);
    if (ret > 0) {
        ALOGEJAVA("hook free in %s with error code: %d", library_path, ret);
    }
}

FreeHooker::FreeHooker(NativeMonitor* monitor) : BaseHooker("FreeHooker", monitor) {

}
