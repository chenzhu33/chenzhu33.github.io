//
// Created by ghostshi on 2018/3/14.
//

#include <string.h>
#include <functional>
#include <algorithm>
#include <include/jni/ext.h>
#include <absl/strings/match.h>
#include <include/base/macros.h>
#include <include/log/log.h>
#include <filesystem/fs.h>

#include "include/jni-loadlibrary-util.h"
#include "include/alog.h"
#include "include/native-monitor.h"

jstring (*originNativeLoad)(JNIEnv *, jclass, jstring, jobject, jstring) = nullptr;

jstring (*originNativeLoad_9_0)(JNIEnv *, jclass, jstring, jobject) = nullptr;

std::string FindLibrary(JNIEnv *env, jobject javaLoader, const char *name) {
    if (fs::exists(name)) {
        return name;
    }
    jni::ScopedLocalRefJNIEnv se(env);
    ADEFINE(se.ExceptionDescribe(), se.ExceptionClear(), "");

    std::string so_name = name;
    if (absl::StartsWith(so_name, "lib") && absl::EndsWith(so_name, ".so")) {
        so_name = so_name.substr(3, so_name.size() - 6);
    }

    static auto find_library_mid = se.GetMethodID(
            se.GetObjectClass(javaLoader), "findLibrary", "(Ljava/lang/String;)Ljava/lang/String;");
    ACHECK(find_library_mid);

    auto lib_name = (jstring) se.CallObjectMethod(
            javaLoader, find_library_mid, se.NewStringUTF(so_name.c_str()));
    ACHECK(lib_name, "so: %s", name);

    return jni::Ext::ToStdString(se, lib_name);
}

bool IsSystemSo(const char *so_path) {
    return absl::StartsWith(so_path, "/system/") ||
           absl::StartsWith(so_path, "/vendor/");
}

static jstring MyNativeLoad(JNIEnv *env, jclass ignored,
                            jstring javaFilename, jobject javaLoader, const std::function<jstring()> &todo) {
    const char *fileName = env->GetStringUTFChars(javaFilename, nullptr);
    std::string soString = fileName;
    env->ReleaseStringUTFChars(javaFilename, fileName);

    // 系统 so 我们可能都没权限。。不折腾
    bool isSystemSo = IsSystemSo(soString.c_str());
    LOGE("native load %s, isSystem %d", soString.c_str(), isSystemSo);

    if (isSystemSo) {
        return todo();
    }

    NativeMonitor::getInstance().beforeSoLoad(soString.c_str(), javaLoader);
    jstring res = todo();
    if (env->ExceptionCheck()) {
        env->ExceptionDescribe();
        return res;
    }
    NativeMonitor::getInstance().afterSoLoad(soString.c_str(), javaLoader);
    return res;
}

JNIEXPORT jstring JNICALL
hookedRuntimeNativeLoad(JNIEnv *env, jclass ignored, jstring javaFilename, jobject javaLoader,
                        jstring javaLibrarySearchPath) {
    return MyNativeLoad(env, ignored, javaFilename, javaLoader, [&]() {
        return originNativeLoad(env, ignored, javaFilename, javaLoader, javaLibrarySearchPath);
    });
}

JNIEXPORT jstring JNICALL
hookedRuntimeNativeLoad_9_0(JNIEnv *env, jclass ignored, jstring javaFilename, jobject javaLoader) {
    return MyNativeLoad(env, ignored, javaFilename, javaLoader, [&]() {
        return originNativeLoad_9_0(env, ignored, javaFilename, javaLoader);
    });
}

JNIEXPORT void JNICALL
jniMethodToMark(JNIEnv *, jobject) {
    ALOGI("mark");
}
