//
// Created by hongpingwu on 2018/3/19.
//

#ifndef NATIVEMEMORY_GLOBALREFHOOKER_H
#define NATIVEMEMORY_GLOBALREFHOOKER_H

#include "../hookUtil/include/hooker.h"
#include "../hookUtil/include/backtrace.h"


class GlobalRefHooker : public BaseHooker {

public:
    GlobalRefHooker(NativeMonitor* monitor);

    void onInit(int n, ...) override final ;
    void beforeHook(int n, ...) override final;
};


#endif //NATIVEMEMORY_GLOBALREFHOOKER_H
