//
// Created by shinkencai on 2018/4/1.
//

#ifndef NATIVEMEMORY_LONGSETFIELDHOOKER_H
#define NATIVEMEMORY_LONGSETFIELDHOOKER_H


#include "../hookUtil/include/hooker.h"
#include <list>

extern void (*originalSetLongField)(JNIEnv*, jobject, jfieldID, jlong);
//extern void hookedSetLongField(JNIEnv*, jobject, jfieldID, jlong);
extern int ensureThreadFiledIDInit(JNIEnv *env);
extern int ensureJobReportMethodInit(JNIEnv *env);
extern const char *classThreadOnCreatedCallBack;
class LongSetFieldHooker:public BaseHooker {
public:
    LongSetFieldHooker(NativeMonitor* monitor);

    void onInit(int n, ...) override final ;
    void beforeHook(int n, ...) override final;
    static void hookedSetLongField(JNIEnv*, jobject, jfieldID, jlong);
    static int getThreadAliveCount();
private:
};


#endif //NATIVEMEMORY_LONGSETFIELDHOOKER_H
