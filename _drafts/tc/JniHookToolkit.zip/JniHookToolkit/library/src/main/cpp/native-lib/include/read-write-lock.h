//
// Created by ghostshi on 2018/3/20.
//

#ifndef JNI_HOOK_TOOLKIT_READ_WRITE_LOCK_H
#define JNI_HOOK_TOOLKIT_READ_WRITE_LOCK_H

#include <mutex>
#include <condition_variable>

class WfirstRWLock
{
public:
    WfirstRWLock() = default;
    ~WfirstRWLock() = default;
public:
    void lock_read()
    {
        std::unique_lock<std::mutex> ulk(counter_mutex);
        cond_r.wait(ulk, [=]()->bool {return write_cnt == 0; });
        ++read_cnt;
    }
    void lock_write()
    {
        std::unique_lock<std::mutex> ulk(counter_mutex);
        ++write_cnt;
        cond_w.wait(ulk, [=]()->bool {return read_cnt == 0 && !inwriteflag; });
        inwriteflag = true;
    }
    void release_read()
    {
        std::unique_lock<std::mutex> ulk(counter_mutex);
        if (--read_cnt == 0 && write_cnt > 0)
        {
            cond_w.notify_one();
        }
    }
    void release_write()
    {
        std::unique_lock<std::mutex> ulk(counter_mutex);
        if (--write_cnt == 0)
        {
            cond_r.notify_all();
        }
        else
        {
            cond_w.notify_one();
        }
        inwriteflag = false;
    }

private:
    volatile size_t read_cnt{ 0 };
    volatile size_t write_cnt{ 0 };
    volatile bool inwriteflag{ false };
    std::mutex counter_mutex;
    std::condition_variable cond_w;
    std::condition_variable cond_r;
};

template <typename _RWLockable>
class UniqueWriteguard
{
public:
    explicit UniqueWriteguard(_RWLockable &rw_lockable)
            : rw_lockable_(rw_lockable)
    {
        rw_lockable_.lock_write();
    }
    ~UniqueWriteguard()
    {
        rw_lockable_.release_write();
    }
private:
    UniqueWriteguard() = delete;
    UniqueWriteguard(const UniqueWriteguard&) = delete;
    UniqueWriteguard& operator=(const UniqueWriteguard&) = delete;
private:
    _RWLockable &rw_lockable_;
};
template <typename _RWLockable>
class UniqueReadguard
{
public:
    explicit UniqueReadguard(_RWLockable &rw_lockable)
            : rw_lockable_(rw_lockable)
    {
        rw_lockable_.lock_read();
    }
    ~UniqueReadguard()
    {
        rw_lockable_.release_read();
    }
private:
    UniqueReadguard() = delete;
    UniqueReadguard(const UniqueReadguard&) = delete;
    UniqueReadguard& operator=(const UniqueReadguard&) = delete;
private:
    _RWLockable &rw_lockable_;
};


#endif //JNI_HOOK_TOOLKIT_READ_WRITE_LOCK_H
