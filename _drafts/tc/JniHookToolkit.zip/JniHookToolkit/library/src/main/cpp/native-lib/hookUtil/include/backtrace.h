//
// Created by hongpingwu on 2018/3/19.
//

#include <string>
#include <map>
#include <set>
#include <jni.h>
#include <iostream>
#include <sstream>
#include <stdlib.h>
#include "../../include/alog.h"
#include "QJNIInterface.h"

using namespace std;

#ifndef NATIVEMEMORY_BACKTRACE_H
#define NATIVEMEMORY_BACKTRACE_H

const int dumpNum = 10;
extern jclass exceptionReporter;
extern jmethodID reportMethod;

struct BacktraceState
{
    void** pc;
    size_t size;

    BacktraceState(void** p, size_t s):pc(p),size(s){}

    ~BacktraceState(){
        if(pc){
            free(pc);
        }
    }
};

struct cmpFunc {
    bool operator()(const BacktraceState *p1, const BacktraceState *p2) const {
        uintptr_t* i;
        uintptr_t* j;
        if(!p1->pc || !p2->pc) return p1->pc < p2->pc;
        for(i = (uintptr_t*) p1->pc, j = (uintptr_t*) p2->pc
                ; i < ((uintptr_t*)p1->pc + p1->size) && j < ((uintptr_t*)p2->pc + p2->size); i++, j++){
            if(*i < *j){
                return true;
            } else if(*i > *j){
                return false;
            }
        }
        return p1->size < p2->size;
    }
};

void initBacktraceTool(JNIEnv* env);
std::string getBacktrace(void** buffer, size_t count);
void getBacktrace(void** buffer, size_t count, std::ostringstream &os);
/**
 * 判断 buffer 数组中是否包含 pc 值
 * @param buffer PC 数组
 * @param count 数组长度
 * @param pc 待查找目标
 * @return 1 找到; 0 未找到
 */
int containsPC(void ** buffer, size_t count, void * pc);
BacktraceState* capturePC(size_t skip);
BacktraceState* capturePC();

struct TraceEntry{
    BacktraceState* trace;
    unsigned long size = 0;
};

inline void swap(TraceEntry* arr, int i, int j){
    TraceEntry tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
}

inline void adjustHeap(TraceEntry* arr, int size){
    int i = 0;
    while(i < size / 2){
        int right = (i + 1) * 2;
        int left = right - 1;
        int j;
        if(right == size || arr[left].size < arr[right].size){
            j = left;
        } else if(arr[right].size < arr[i].size){
            j = right;
        } else {
            break;
        }
        swap(arr, i, j);
        i = j;
    }
}

template <typename T>
void dump(map<BacktraceState*, set<T>, cmpFunc> &traceMap){
    TraceEntry arr[dumpNum];
    auto it = traceMap.begin();
    ALOGI("trace size: %d", traceMap.size());
    while(it != traceMap.end()){
        if(it->second->size() > arr[0].size){
            arr[0].trace = it->first;
            arr[0].size = it->second.size();
            adjustHeap(arr, dumpNum);
        }
        it++;
    }
    ALOGW("global reference table overflow, the top traces are: \n");
    for(int i = 0; i < dumpNum; i++){
        if(arr[i].size > 0) {
            BacktraceState *trace = arr[i].trace;
            ALOGW("called %ld times:\n%s\n\n", arr[i].size, getBacktrace(trace->pc, trace->size).c_str());
        }
    }
}



template <typename T>
void getTopBacktrace(map<BacktraceState*, set<T>, cmpFunc> &traceMap, std::ostringstream &os){
    TraceEntry arr[dumpNum];
    auto it = traceMap.begin();
    while(it != traceMap.end()){
        if(it->second.size() > arr[0].size){
            arr[0].trace = it->first;
            arr[0].size = it->second.size();
            adjustHeap(arr, dumpNum);
        }
        it++;
    }
    for(int i = 0; i < dumpNum; i++){
        if(arr[i].size > 0) {
            BacktraceState *trace = arr[i].trace;
            os << "called " << arr[i].size << " times: \n";
            getBacktrace(trace->pc, trace->size, os);
            os << "\n";
        }
    }
}

extern void report(JNIEnv* env, const char* tag, const char* msg);
extern void report(JNIEnv* env, const char* tag, BacktraceState* trace);
extern void report(JNIEnv* env, const char* tag, BacktraceState* trace, size_t);
extern void report(JNIEnv* env, const char* tag, BacktraceState* trace, int64_t, int64_t);
#endif //NATIVEMEMORY_BACKTRACE_H
