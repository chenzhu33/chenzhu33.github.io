//
// Created by passionli on 2018/4/20.
//

#ifndef _CHECKJNIHOOKER_
#define _CHECKJNIHOOKER_

#include "../hookUtil/include/hooker.h"
#include "../hookUtil/include/backtrace.h"
class CheckJNIHooker : public BaseHooker {
private:
    static void reportInternal(JNIEnv * env, BacktraceState * backtraceState, const char * pchar, const char *pFuncName);
public:
    CheckJNIHooker(NativeMonitor* monitor);
    void onInit(int n, ...) override final;
    void beforeHook(int n, ...) override final;

#define ORIGIN_GET_XX_FIELD(_jtype, _jname)\
    static j##_jtype (*originGet##_jname##Field)(JNIEnv *, jobject, jfieldID);\
    static j##_jtype (*originGetStatic##_jname##Field)(JNIEnv *, jclass, jfieldID);

    ORIGIN_GET_XX_FIELD(object, Object)
    ORIGIN_GET_XX_FIELD(boolean, Boolean)
    ORIGIN_GET_XX_FIELD(byte, Byte)
    ORIGIN_GET_XX_FIELD(short, Short)
    ORIGIN_GET_XX_FIELD(char, Char)
    ORIGIN_GET_XX_FIELD(int, Int)
    ORIGIN_GET_XX_FIELD(long, Long)
    ORIGIN_GET_XX_FIELD(float, Float)
    ORIGIN_GET_XX_FIELD(double, Double)
#undef ORIGIN_GET_XX_FIELD

#define ORIGIN_SET_XX_FIELD(_jtype, _jname)\
    static void (*originSet##_jname##Field)(JNIEnv *, jobject, jfieldID, j##_jtype);\
    static void (*originSetStatic##_jname##Field)(JNIEnv *, jclass, jfieldID, j##_jtype);

    ORIGIN_SET_XX_FIELD(object, Object)
    ORIGIN_SET_XX_FIELD(boolean, Boolean)
    ORIGIN_SET_XX_FIELD(byte, Byte)
    ORIGIN_SET_XX_FIELD(short, Short)
    ORIGIN_SET_XX_FIELD(char, Char)
    ORIGIN_SET_XX_FIELD(int, Int)
    ORIGIN_SET_XX_FIELD(long, Long)
    ORIGIN_SET_XX_FIELD(float, Float)
    ORIGIN_SET_XX_FIELD(double, Double)
#undef ORIGIN_SET_XX_FIELD

#define ORIGIN_GET_SET_XX_ARRAY_REGION(_GS, _jtype, _jname, _const) \
    static void (*origin##_GS##et##_jname##ArrayRegion)(JNIEnv*, j##_jtype##Array,\
    jsize, jsize, _const j##_jtype*);

    ORIGIN_GET_SET_XX_ARRAY_REGION(G, boolean, Boolean, )
    ORIGIN_GET_SET_XX_ARRAY_REGION(S, boolean, Boolean, const)
    ORIGIN_GET_SET_XX_ARRAY_REGION(G, byte, Byte, )
    ORIGIN_GET_SET_XX_ARRAY_REGION(S, byte, Byte, const)
    ORIGIN_GET_SET_XX_ARRAY_REGION(G, short, Short, )
    ORIGIN_GET_SET_XX_ARRAY_REGION(S, short, Short, const)
    ORIGIN_GET_SET_XX_ARRAY_REGION(G, char, Char, )
    ORIGIN_GET_SET_XX_ARRAY_REGION(S, char, Char, const)
    ORIGIN_GET_SET_XX_ARRAY_REGION(G, int, Int, )
    ORIGIN_GET_SET_XX_ARRAY_REGION(S, int, Int, const)
    ORIGIN_GET_SET_XX_ARRAY_REGION(G, long, Long,)
    ORIGIN_GET_SET_XX_ARRAY_REGION(S, long, Long, const)
    ORIGIN_GET_SET_XX_ARRAY_REGION(G, float, Float, )
    ORIGIN_GET_SET_XX_ARRAY_REGION(S, float, Float, const)
    ORIGIN_GET_SET_XX_ARRAY_REGION(G, double, Double, )
    ORIGIN_GET_SET_XX_ARRAY_REGION(S, double, Double, const)
#undef ORIGIN_GET_SET_XX_ARRAY_REGION

#define CHECK_JNI_ARGS(_clsOrObj, _prefix) \
        if(_clsOrObj == 0 || id == 0){\
            BacktraceState *backtraceState = capturePC(1);\
            if (backtraceState){\
            int isAttachedThread = 0;\
            JNIEnv *env = getJniEnv(&isAttachedThread);\
            const char * pFuncName = __FUNCTION__;\
            reportInternal(env, backtraceState,\
                (_clsOrObj == 0 && id == 0)? #_clsOrObj" == null and " _prefix"ID == 0":\
                (_clsOrObj == 0) ? #_clsOrObj" == null" : _prefix"ID == 0", pFuncName + 6);\
            delete(backtraceState);\
            if(isAttachedThread) {\
                _detach_current_thread();\
            }}\
        }

#define CHECK_JNI_ARGS_NONE_NULL(_input) \
        if(_input == nullptr){\
            BacktraceState *backtraceState = capturePC(1);\
            if (backtraceState) {\
            int isAttachedThread = 0;\
            JNIEnv *env = getJniEnv(&isAttachedThread);\
            const char * pFuncName = __FUNCTION__;\
            reportInternal(env, backtraceState,\
                #_input " == null" , pFuncName + 6);\
            delete(backtraceState);\
            if(isAttachedThread) {\
                _detach_current_thread();\
            }}\
        }

#define HOOKED_SET_XX_FIELD(_jtype, _jname)\
    static void hookedSet##_jname##Field(JNIEnv *env, jobject obj, jfieldID id, j##_jtype val) {\
        CHECK_JNI_ARGS(obj, "field")\
        originSet##_jname##Field(env, obj, id, val);\
    }\
    static void hookedSetStatic##_jname##Field(JNIEnv *env, jclass cls, jfieldID id, j##_jtype val) {\
        CHECK_JNI_ARGS(cls, "field")\
        originSetStatic##_jname##Field(env, cls, id, val);\
    }

    HOOKED_SET_XX_FIELD(object, Object)
    HOOKED_SET_XX_FIELD(boolean, Boolean)
    HOOKED_SET_XX_FIELD(byte, Byte)
    HOOKED_SET_XX_FIELD(short, Short)
    HOOKED_SET_XX_FIELD(char, Char)
    HOOKED_SET_XX_FIELD(int, Int)
    HOOKED_SET_XX_FIELD(long, Long)
    HOOKED_SET_XX_FIELD(float, Float)
    HOOKED_SET_XX_FIELD(double, Double)
#undef HOOKED_SET_XX_FIELD

#define HOOKED_GET_XX_FIELD(_jtype, _jname) \
    static j##_jtype hookedGet##_jname##Field(JNIEnv *env, jobject obj, jfieldID id) { \
        CHECK_JNI_ARGS(obj, "field")\
        return originGet##_jname##Field(env, obj, id);\
    }\
    static j##_jtype hookedGetStatic##_jname##Field(JNIEnv *env, jclass cls, jfieldID id) { \
        CHECK_JNI_ARGS(cls, "field")\
        return originGetStatic##_jname##Field(env, cls, id);\
    }

    HOOKED_GET_XX_FIELD(object, Object)
    HOOKED_GET_XX_FIELD(boolean, Boolean)
    HOOKED_GET_XX_FIELD(byte, Byte)
    HOOKED_GET_XX_FIELD(short, Short)
    HOOKED_GET_XX_FIELD(char, Char)
    HOOKED_GET_XX_FIELD(int, Int)
    HOOKED_GET_XX_FIELD(long, Long)
    HOOKED_GET_XX_FIELD(float, Float)
    HOOKED_GET_XX_FIELD(double, Double)
#undef HOOKED_GET_XX_FIELD

#define HOOKED_GET_SET_XX_ARRAY_REGION(_GS, _jtype, _jname, _const) \
    static void hooked##_GS##et##_jname##ArrayRegion(JNIEnv *env, j##_jtype##Array java_array, jsize start,\
                                                    jsize len, _const j##_jtype* buf) { \
        CHECK_JNI_ARGS_NONE_NULL(java_array)\
        origin##_GS##et##_jname##ArrayRegion(env, java_array, start, len, buf);\
    }

    HOOKED_GET_SET_XX_ARRAY_REGION(G, boolean, Boolean, )
    HOOKED_GET_SET_XX_ARRAY_REGION(S, boolean, Boolean, const)
    HOOKED_GET_SET_XX_ARRAY_REGION(G, byte, Byte, )
    HOOKED_GET_SET_XX_ARRAY_REGION(S, byte, Byte, const)
    HOOKED_GET_SET_XX_ARRAY_REGION(G, short, Short, )
    HOOKED_GET_SET_XX_ARRAY_REGION(S, short, Short, const)
    HOOKED_GET_SET_XX_ARRAY_REGION(G, char, Char, )
    HOOKED_GET_SET_XX_ARRAY_REGION(S, char, Char, const)
    HOOKED_GET_SET_XX_ARRAY_REGION(G, int, Int, )
    HOOKED_GET_SET_XX_ARRAY_REGION(S, int, Int, const)
    HOOKED_GET_SET_XX_ARRAY_REGION(G, long, Long,)
    HOOKED_GET_SET_XX_ARRAY_REGION(S, long, Long, const)
    HOOKED_GET_SET_XX_ARRAY_REGION(G, float, Float, )
    HOOKED_GET_SET_XX_ARRAY_REGION(S, float, Float, const)
    HOOKED_GET_SET_XX_ARRAY_REGION(G, double, Double, )
    HOOKED_GET_SET_XX_ARRAY_REGION(S, double, Double, const)
#undef HOOKED_GET_SET_XX_ARRAY_REGION

#define ORIGIN_CALL_XX_V(_jtype, _jname)\
    static _jtype (*originCall##_jname##MethodV)(JNIEnv*, jobject, jmethodID, va_list);\
    static _jtype (*originCall##_jname##MethodA)(JNIEnv*, jobject, jmethodID, jvalue*);\
    static _jtype (*originCallStatic##_jname##MethodV)(JNIEnv*, jclass, jmethodID, va_list);\
    static _jtype (*originCallStatic##_jname##MethodA)(JNIEnv*, jclass, jmethodID, jvalue*);

    ORIGIN_CALL_XX_V(jobject, Object)
    ORIGIN_CALL_XX_V(jboolean, Boolean)
    ORIGIN_CALL_XX_V(jbyte, Byte)
    ORIGIN_CALL_XX_V(jshort, Short)
    ORIGIN_CALL_XX_V(jchar, Char)
    ORIGIN_CALL_XX_V(jint, Int)
    ORIGIN_CALL_XX_V(jlong, Long)
    ORIGIN_CALL_XX_V(jfloat, Float)
    ORIGIN_CALL_XX_V(jdouble, Double)
    ORIGIN_CALL_XX_V(void, Void)
#undef ORIGIN_CALL_XX_V

#define HOOK_CALL_XX_V(_jtype, _jname)\
    static _jtype hookedCall##_jname##MethodV(JNIEnv* env, jobject obj, jmethodID id, va_list args) {\
            CHECK_JNI_ARGS(obj, "method")\
            return originCall##_jname##MethodV(env, obj, id, args);\
        }\
    static _jtype hookedCall##_jname##MethodA(JNIEnv* env, jobject obj, jmethodID id, jvalue* args) {\
            CHECK_JNI_ARGS(obj, "method")\
            return originCall##_jname##MethodA(env, obj, id, args);\
        }\
    static _jtype hookedCallStatic##_jname##MethodV(JNIEnv* env, jclass cls, jmethodID id, va_list args) {\
            CHECK_JNI_ARGS(cls, "method")\
            return originCallStatic##_jname##MethodV(env, cls, id, args);\
        }\
    static _jtype hookedCallStatic##_jname##MethodA(JNIEnv* env, jclass cls, jmethodID id, jvalue* args) {\
            CHECK_JNI_ARGS(cls, "method")\
            return originCallStatic##_jname##MethodA(env, cls, id, args);\
        }

    HOOK_CALL_XX_V(jobject, Object)
    HOOK_CALL_XX_V(jboolean, Boolean)
    HOOK_CALL_XX_V(jbyte, Byte)
    HOOK_CALL_XX_V(jshort, Short)
    HOOK_CALL_XX_V(jchar, Char)
    HOOK_CALL_XX_V(jint, Int)
    HOOK_CALL_XX_V(jlong, Long)
    HOOK_CALL_XX_V(jfloat, Float)
    HOOK_CALL_XX_V(jdouble, Double)
    HOOK_CALL_XX_V(void, Void)

#undef HOOK_CALL_XX_V

    static jmethodID   (*originGetStaticMethodID)(JNIEnv*, jclass, const char*, const char*);
    static jmethodID   hookedGetStaticMethodID(JNIEnv* env, jclass cls, const char* name, const char* sig){
        CHECK_JNI_ARGS_NONE_NULL(cls);
        return originGetStaticMethodID(env, cls, name, sig);
    }

#undef CHECK_JNI_ARGS
};
#endif //_CHECKJNIHOOKER_
