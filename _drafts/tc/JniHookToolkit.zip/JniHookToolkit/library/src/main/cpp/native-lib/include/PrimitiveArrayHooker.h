//
// Created by hongpingwu on 2018/3/21.
//

#ifndef NATIVEMEMORY_PRIMITIVEARRAYHOOKER_H
#define NATIVEMEMORY_PRIMITIVEARRAYHOOKER_H

#include "../hookUtil/include/hooker.h"

class PrimitiveArrayHooker : public BaseHooker {
public:
    PrimitiveArrayHooker(NativeMonitor* monitor);

    void onInit(int n, ...) override final ;
    void beforeHook(int n, ...) override final;
};


#endif //NATIVEMEMORY_PRIMITIVEARRAYHOOKER_H
