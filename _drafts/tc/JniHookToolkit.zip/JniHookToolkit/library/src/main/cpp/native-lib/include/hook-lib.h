//
// Created by ghostshi on 2018/2/6.
//

#ifndef GOTHOOKLIBRARY_NATIVE_LIB_H
#define GOTHOOKLIBRARY_NATIVE_LIB_H

#include "alog.h"

extern "C"
int hookFunc(const char* library_path, const char* symbol, void* originFuncPtr, void* hookFuncPtr);

#define ERR_OFFSET_SECTION 10
#define ERR_OFFSET_SEGMENT 10000

#define ERR_ORIGIN_HOOK_EQUAL 1

#endif //GOTHOOKLIBRARY_NATIVE_LIB_H
