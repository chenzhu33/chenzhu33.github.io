#include <jni.h>
#include <string>
#include <dlfcn.h>
#include <sstream>
#include <include/androidp/hidden_api_policy_crack.h>
#include <include/log/log.h>
#include "include/alog.h"
#include "include/native-monitor.h"
#include "include/jni-loadlibrary-util.h"
#include "include/global_variables.h"
#include "include/LongSetFieldHooker.h"

static const char *classJniOffsetPathName = "com/tencent/mobileqq/nativememorymonitor/library/ClassToFindJniOffset";
static const char *classMonitorPathName = "com/tencent/mobileqq/nativememorymonitor/library/NativeMemoryMonitor";
const char *classThreadOnCreatedCallBack = "com/tencent/mobileqq/app/JobReporter";


//#ifdef __cplusplus
//extern "C" {
//#endif
//
//// asan模式会优先链接asan动态库对应的函数
//void __asan_set_error_report_callback(void (*callback)(const char*)){
//    ALOGE("fake callback setter is called");
//}
//
//#ifdef __cplusplus
//}
//#endif


void nativeThreadCreateHookInit(JNIEnv* env,jobject /*thiz*/, jstring callBack) {
    const char* threadCreatedCallBack = env->GetStringUTFChars(callBack, nullptr);
    std::string *t = new std::string(threadCreatedCallBack);
    classThreadOnCreatedCallBack = t->c_str();
    ensureThreadFiledIDInit(env);
    ensureJobReportMethodInit(env);
}

void customASanCallback(const char* msg){
    ALOGE("ASanCallback");
    int isAttachThread = 0;
    JNIEnv *env = getJniEnv(&isAttachThread);
    jclass tmp = env->FindClass("com/tencent/mobileqq/statistics/NativeExceptionReport");
    if (env->ExceptionCheck()) {  // 检查JNI调用是否有引发异常
        env->ExceptionDescribe();
        env->ExceptionClear();        // 清除引发的异常
        return;
    }
    jclass exceptionReporter = (jclass) env->NewGlobalRef(tmp);
    jmethodID reportMethod =  env -> GetStaticMethodID(exceptionReporter, "reportASanError"
            , "(Ljava/lang/String;)V");
    if (env->ExceptionCheck()) {  // 检查JNI调用是否有引发异常
        env->ExceptionDescribe();
        env->ExceptionClear();
        env->DeleteGlobalRef(exceptionReporter);      // 清除引发的异常
        return;
    }
    jstring extraMsg = env->NewStringUTF(msg);
    env->CallStaticVoidMethod(exceptionReporter, reportMethod, extraMsg);
    env->DeleteLocalRef(extraMsg);
    env->DeleteGlobalRef(exceptionReporter);
}

void nativeSetupASanCallback(JNIEnv* env,jobject /*thiz*/) {
    ALOGE("set up callback ");
    void * handle = dlopen("libclang_rt.asan-arm-android.so", RTLD_LAZY);

    if (!handle){
        ALOGE("open asan library failed");
        return;
    }

    // clear error
    dlerror();

    void (*addr)(void (*callback)(const char*)) = (void (*)(void (*)(const char *)))(dlsym(handle, "__asan_set_error_report_callback"));

    char * error = dlerror();
    if (error){
        ALOGE("find asan callback failed");
        dlclose(handle);
        return;
    }

    dlclose(handle);
    addr(customASanCallback);
}

jstring getUndetachThreads(JNIEnv* env, jobject /*thiz*/){
    std::ostringstream os;
    return NativeMonitor::getInstance().dumpUndetachThreads(os) ? env->NewStringUTF(os.str().c_str()) : NULL;
}

void nativeSoLoadHook(JNIEnv *env, jobject thiz, jstring packageName, jstring nativeLibDir) {
    auto applicationIdChars = env->GetStringUTFChars(packageName, nullptr);
    auto nativeLibDirChars = env->GetStringUTFChars(nativeLibDir, nullptr);
    NativeMonitor::getInstance().startSoLoadHook(env, env->GetObjectClass(thiz), applicationIdChars, nativeLibDirChars);
    env->ReleaseStringUTFChars(packageName, applicationIdChars);
    env->ReleaseStringUTFChars(nativeLibDir, nativeLibDirChars);
}

jboolean applyHiddenApiPolicyCrack(JNIEnv *env, jobject thiz, jobject app_info) {
    ADEFINE(env->ExceptionClear(), JNI_FALSE);

    auto libart = dlfcn::dlopen("libart.so", true);
    ACHECK(libart);

    return static_cast<jboolean>(
            androidp::HiddenApiPolicyCrack::Apply(env, libart, app_info) ? JNI_TRUE : JNI_FALSE);
}

void nativeInit(JNIEnv* env, jobject thiz, jlong featureFlag, jobjectArray soWhiteList, jlong timeLimited, jlong countLimited, jlong memoryLimited) {
    jclass clazz = env->FindClass(classMonitorPathName);
    jsize size = soWhiteList == NULL ? 0 : env->GetArrayLength(soWhiteList);

    //先设置为false
    NativeMonitor::getInstance().setAllSoHooked(0);
    for(int i=0; i<size; i++) {
        jstring obj = (jstring)env->GetObjectArrayElement(soWhiteList,i);
        std::string sstr = (std::string)env->GetStringUTFChars(obj,NULL);
        //如果白名单里面有这个字段，就全部so都要hook
        if( sstr == "all_so_hook" ) {
            NativeMonitor::getInstance().setAllSoHooked(1);
            break;
        }
        ALOGD("sowhiteList test%s",sstr.c_str());
        NativeMonitor::getInstance().insert2SoWhiteList(sstr);
    }

    if (clazz != nullptr) {
        NativeMonitor::getInstance().start(env, clazz, featureFlag,
                                           timeLimited, countLimited, memoryLimited);
    } else{
        env->ExceptionClear();
        ALOGE("can not find monitor class");
    }

    ALOGD("three param:%lld, %lld, %lld ",timeLimited, countLimited, memoryLimited);

}

void nativeDump(JNIEnv * env, jobject obj){
    NativeMonitor::getInstance().dump(env);
}

jint nativeGetJavaThreadPeakCount(JNIEnv* env, jobject /*thiz*/) {
      return LongSetFieldHooker::getThreadAliveCount();
}

void nativeThreadHook(JNIEnv* env, jobject thiz){
    NativeMonitor::getInstance().hookLongSetField(env);
}

static JNINativeMethod methodsInJniOffset[] = {
        "mark", "()V", (void *)jniMethodToMark
};

static JNINativeMethod methodsInMonitor[] = {
//        "nativeInit", "(J[Ljava/lang/String;)V", (void *) nativeInit
//        "nativeInit", "(JLjava/lang/String;Ljava/lang/String;)V", (void *) nativeInit
        "nativeSoLoadHook", "(Ljava/lang/String;Ljava/lang/String;)V", (void *) nativeSoLoadHook,
        "nativeInit", "(J[Ljava/lang/String;JJJ)V", (void *) nativeInit,
        "nativeDump", "()V", (void *) nativeDump,
        "applyHiddenApiPolicyCrack", "(Landroid/content/pm/ApplicationInfo;)Z", (void *) applyHiddenApiPolicyCrack,
};

static JNINativeMethod methodsInThread[] = {
        {"nativeGetJavaThreadPeakCount", "()I", (void*)  nativeGetJavaThreadPeakCount},
        {"nativeThreadHook", "()V", (void*)  nativeThreadHook}
};

static JNINativeMethod methodsInThreadCreateCallback[] = {
        "nativeThreadCreateHookInit", "(Ljava/lang/String;)V", (void*)  nativeThreadCreateHookInit
};

static JNINativeMethod methodsInASan[] = {
        "setupASanCallback", "()V", (void*)  nativeSetupASanCallback
};

static JNINativeMethod methodsInAttach[] = {
        "getUndetachThreads", "()Ljava/lang/String;", (void*)  getUndetachThreads
};

/*
 * Register several native methodsInJniOffset for one class.
 */
static int registerNativeMethods(JNIEnv* env, const char* className,
                                 JNINativeMethod* gMethods, int numMethods)
{
    jclass clazz;
    clazz = (env->FindClass(className));
    if (clazz == NULL) {
        ALOGE("Native registration unable to find class '%s'", className);
        return JNI_FALSE;
    }
    if (env->RegisterNatives(clazz, gMethods, numMethods) < 0) {
        ALOGE("RegisterNatives failed for '%s'", className);
        return JNI_FALSE;
    }
    return JNI_TRUE;
}
/*
 * Register native methodsInJniOffset for all classes we know about.
 *
 * returns JNI_TRUE on success.
 */
static int registerNatives(JNIEnv* env)
{
    if (!registerNativeMethods(env, classJniOffsetPathName,
                               methodsInJniOffset, sizeof(methodsInJniOffset) / sizeof(methodsInJniOffset[0]))) {
        return JNI_FALSE;
    }

    if (!registerNativeMethods(env, classMonitorPathName,
                               methodsInMonitor, sizeof(methodsInMonitor) / sizeof(methodsInMonitor[0]))) {
        return JNI_FALSE;
    }

    if (!registerNativeMethods(env, classMonitorPathName,
                               methodsInThread, sizeof(methodsInThread) / sizeof(methodsInThread[0]))) {
        return JNI_FALSE;
    }

    if (!registerNativeMethods(env, classMonitorPathName,
                               methodsInThreadCreateCallback, sizeof(methodsInThreadCreateCallback) / sizeof(methodsInThreadCreateCallback[0]))) {
        return JNI_FALSE;
    }

    if (!registerNativeMethods(env, classMonitorPathName,
                               methodsInASan, sizeof(methodsInASan) / sizeof(methodsInASan[0]))) {
        return JNI_FALSE;
    }

    if (!registerNativeMethods(env, classMonitorPathName,
                               methodsInAttach, sizeof(methodsInAttach) / sizeof(methodsInAttach[0]))) {
        return JNI_FALSE;
    }

    return JNI_TRUE;
}
// ----------------------------------------------------------------------------
/*
 * This is called by the VM when the shared library is first loaded.
 */

typedef union {
    JNIEnv* env;
    void* venv;
} UnionJNIEnvToVoid;

jint JNI_OnLoad(JavaVM* vm, void* reserved)
{

    UnionJNIEnvToVoid uenv;
    uenv.venv = NULL;
    jint result = -1;
    JNIEnv* env = NULL;

    g_vm = vm;

    ALOGI("JNI_OnLoad");

    if (vm->GetEnv(&uenv.venv, JNI_VERSION_1_4) != JNI_OK) {
        ALOGE("ERROR: GetEnv failed");
        goto bail;
    }
    env = uenv.env;

    if (registerNatives(env) != JNI_TRUE) {
        ALOGE("ERROR: registerNatives failed");
        goto bail;
    }

    result = JNI_VERSION_1_4;

    bail:
    return result;
}