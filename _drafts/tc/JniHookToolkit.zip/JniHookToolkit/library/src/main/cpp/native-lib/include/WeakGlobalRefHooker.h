//
// Created by hongpingwu on 2018/4/24.
//

#ifndef NATIVEMEMORY_WEAKGLOBALREFHOOKER_H
#define NATIVEMEMORY_WEAKGLOBALREFHOOKER_H


#include "../hookUtil/include/hooker.h"
#include "../hookUtil/include/backtrace.h"

class WeakGlobalRefHooker : public BaseHooker {

public:
    WeakGlobalRefHooker(NativeMonitor* monitor);

    void onInit(int n, ...) override final ;
    void beforeHook(int n, ...) override final;
    void dump(JNIEnv *env);
};


#endif //NATIVEMEMORY_WEAKGLOBALREFHOOKER_H
