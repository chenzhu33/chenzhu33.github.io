//
// Created by hongpingwu on 2018/11/7.
//

#include "include/NativeThreadHooker.h"
#include "include/global_variables.h"
#include "include/alog.h"
#include "hookUtil/include/jni-func-hook-util.h"
#include "hookUtil/include/backtrace.h"
#include <unistd.h>

#define TAG "NativeThreadHooker"

jint (*originAttachCurrentThread)(JavaVM*, JNIEnv**, void*);
jint (*originDetachCurrentThread)(JavaVM*);
map<pid_t, BacktraceState*> tidMap;
mutex mLock;

NativeThreadHooker::NativeThreadHooker(NativeMonitor* monitor) : BaseHooker("NativeThreadHooker", monitor) {}

void NativeThreadHooker::beforeHook(int n, ...){
    originDetachCurrentThread = g_vm->functions->DetachCurrentThread;
    originAttachCurrentThread = g_vm->functions->AttachCurrentThread;
}

jint hookedAttachCurrentThread(JavaVM* vm, JNIEnv** env, void* attr){
    pid_t tid = gettid();
    {
        std::lock_guard<std::mutex> lock(mLock);
        if (tidMap.find(tid) == tidMap.end()) {
            BacktraceState *trace = capturePC(1);
            tidMap.insert(std::make_pair(tid, trace));
        }
    }
    return originAttachCurrentThread(vm, env, attr);
}

jint hookedDetachCurrentThread(JavaVM* vm){
    pid_t tid = gettid();
    {
        std::lock_guard<std::mutex> lock(mLock);
        map<pid_t, BacktraceState*>::iterator it = tidMap.find(tid);
        if (it != tidMap.end()) {
            BacktraceState* trace = it->second;
            delete(trace);
            tidMap.erase(tid);
        }
    }
    return originDetachCurrentThread(vm);
}

void NativeThreadHooker::onInit(int n, ...) {
    replaceJniEnvFunction((void **) &(g_vm->functions->DetachCurrentThread), (void *) hookedDetachCurrentThread);
    replaceJniEnvFunction((void **) &(g_vm->functions->AttachCurrentThread), (void *) hookedAttachCurrentThread);

    ALOGIJAVA("%s", "native thread is hooked");
}

bool NativeThreadHooker::dumpUndetachThreads(std::ostringstream &os) {
    std::lock_guard<std::mutex> lock(mLock);
    auto it = tidMap.begin();
    if (it == tidMap.end()) {
        return false;
    }
    os << "undetach threads are:\n";
    while (it != tidMap.end()) {
        os << "thread[tid=" << it->first << "] was attached from: \n";
        BacktraceState *trace = it->second;
        getBacktrace(trace->pc, trace->size, os);
        os << '\n';
        it++;
    }
    return true;
}
