//
// Created by hongpingwu on 2018/3/21.
//

#ifndef NATIVEMEMORY_PRIMITIVEARRAYTRACKER_H
#define NATIVEMEMORY_PRIMITIVEARRAYTRACKER_H

#include "tracker.h"
#include <string.h>


class PrimitiveArrayTracker {

};


#endif //NATIVEMEMORY_PRIMITIVEARRAYTRACKER_H
