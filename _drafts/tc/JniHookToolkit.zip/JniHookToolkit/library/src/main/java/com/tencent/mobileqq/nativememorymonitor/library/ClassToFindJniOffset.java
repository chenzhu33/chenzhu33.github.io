package com.tencent.mobileqq.nativememorymonitor.library;

/**
 * Created by ghostshi on 2018/3/14.
 */

public class ClassToFindJniOffset {
    public static native void mark();

    public static void mark2(){}
}
