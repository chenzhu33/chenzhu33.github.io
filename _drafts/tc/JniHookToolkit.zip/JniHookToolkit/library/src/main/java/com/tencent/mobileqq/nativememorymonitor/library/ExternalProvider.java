package com.tencent.mobileqq.nativememorymonitor.library;

/**
 * Created by jefding on 2019/3/6 20:16
 */
public interface ExternalProvider {
    void onSoLoad(final String soPath, final String backtrace);
}
