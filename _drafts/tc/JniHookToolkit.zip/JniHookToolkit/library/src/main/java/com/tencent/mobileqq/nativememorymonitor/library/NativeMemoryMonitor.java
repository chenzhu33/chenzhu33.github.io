package com.tencent.mobileqq.nativememorymonitor.library;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.util.Log;
import com.tencent.commonsdk.soload.SoLoadUtilNew;

/**
 * Created by ghostshi on 2018/3/14.
 *
 * Monitor 在 java 层的入口
 */

public class NativeMemoryMonitor {
    private static final String TAG = "NativeMemoryMonitor";

    // jni 相关开关
    public static final long FLAG_JNI_GLOBAL_REF_MONITOR = 1L;
    public static final long FLAG_JNI_LOCAL_REF_MONITOR = 1L << 1;
    public static final long FLAG_JNI_PRIMITIVE_ARRAY_MONITOR = 1L << 2;
    public static final long FLAG_JNI_LONG_SET_FIELD_MONITOR = 1L << 3;
    public static final long FLAG_JNI_WEAK_GLOBAL_REF_MONITOR = 1L << 4;

    public static final long FLAG_JNI_CALLXXMETHOD_MONITOR = 1L << 5;
    public static final long FLAG_JNI_NATIVE_THREAD_MONITOR = 1L << 6;

    // 内存相关
    public static final long FLAG_OVER_ALLOCATE_PER_TIME_MONITOR = 1L << 31;
    public static final long FLAG_LARGE_OBJECT_ALLOC_MONITOR = 1L << 32;

    // public static final long FLAG_SO_LOAD_MONITOR = 1L << 48;

    /**
     * 在上面内存相关的代码打开的前题下，如果白名单里面有该字段，就全部hook
     */
    public static final String ALL_SO_HOOK = "all_so_hook";

    public static final long FLAG_LOG_ALL = 1L << 62; // 调试用 flag

    private boolean mInit = false;
    private boolean mInitThreadHook = false;
    private static volatile boolean sSoLoaded = false;
    private static volatile boolean sSoLoadRes = false;
    private static ExternalProvider externalProvider;

    public synchronized void initThreadHook(String threadCreatedCallBack) {
        if (!sSoLoadRes) {
            return;
        }

        if (mInitThreadHook) {
            return;
        }
        mInitThreadHook = true;
        nativeThreadCreateHookInit(threadCreatedCallBack);
        nativeThreadHook();//独立Thread create hook
    }

    public synchronized void setupSoLoadHook(Context context, ExternalProvider externalProvider) {
        NativeMemoryMonitor.externalProvider = externalProvider;
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        nativeSoLoadHook(context.getPackageName(), applicationInfo.nativeLibraryDir);
    }

    public boolean applyHiddenApiPolicyCrack(Context context) {
        final ApplicationInfo applicationInfo = context.getApplicationInfo();
        return applyHiddenApiPolicyCrack(applicationInfo);
    }

    public synchronized void init(long featureFlag, String []soWhiteList,
                                  long timeLimited, long countLimited, long memory_limited){
        if (mInit) {
            return;
        }

        if (!sSoLoadRes) {
            logErrorFromNative("SoLoad fail");
            return;
        }

        // 调用以免被 proguard 掉。。
        logErrorFromNative("init");
        logInfoFromNative("init");

        nativeInit(featureFlag, soWhiteList,
                timeLimited, countLimited, memory_limited);
        mInit = true;
    }

    // callback for JNI
    private static void onSoLoad(final String soPath, final String backtrace) {
        final ExternalProvider externalProvider = NativeMemoryMonitor.externalProvider;
        if (externalProvider != null) {
            String trace = backtrace.replaceAll("\\t", " ");
            final String throwableString = "java.lang.Throwable: \n";
            if (trace.startsWith(throwableString)) {
                trace = trace.substring(throwableString.length());
            }
            externalProvider.onSoLoad(soPath, trace);
        }
    }

    public synchronized void dump(){
        nativeDump();
    }

    private static void logErrorFromNative(String log) {
        try {
            com.tencent.qphone.base.util.QLog.e(
                    TAG,
                    com.tencent.qphone.base.util.QLog.USR,
                    log
            );
        }
        catch (Throwable e) {
            Log.d(TAG, "try to log " + log + " but QLog is not found");
        }
    }

    private static void logInfoFromNative(String log) {
        try {
            com.tencent.qphone.base.util.QLog.i(
                    TAG,
                    com.tencent.qphone.base.util.QLog.CLR,
                    log
            );
        }
        catch (Throwable e) {
            Log.d(TAG, "try to log " + log + " but QLog is not found");
        }
    }

    private native void nativeThreadCreateHookInit(String callBack);
    private native void nativeSoLoadHook(String applicationId, String nativeLibDir);
    private native void nativeInit(long featureFlag, String[] soWhiteList, long timeLimited, long countLimited, long memoryLimited);
    private native void nativeThreadHook();
    private native int nativeGetJavaThreadPeakCount();
    private native boolean applyHiddenApiPolicyCrack(ApplicationInfo applicationInfo);

    public native void setupASanCallback();
    public int getJavaThreadPeakCount( ) {
        if (!sSoLoadRes) {
            return 0;
        }
        return nativeGetJavaThreadPeakCount();
    }
    private native void nativeDump();

    public native String getUndetachThreads();

    private NativeMemoryMonitor(){
    }

    private static void loadSoIfNeeded(Context context) {
        if (!sSoLoaded) {
            sSoLoadRes = SoLoadUtilNew.loadSoByName(context, "c++_shared")
                    && SoLoadUtilNew.loadSoByName(context, "native-memory-library-lib");
            logErrorFromNative("load so res: " + sSoLoadRes);
            sSoLoaded = true;
        }
    }

    public static NativeMemoryMonitor getInstance(Context context) {
        loadSoIfNeeded(context);
        return Holder.INSTANCE;
    }

    private static class Holder {
        private static NativeMemoryMonitor INSTANCE = new NativeMemoryMonitor();
    }
}
