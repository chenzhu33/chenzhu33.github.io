package com.tencent.mobileqq.app;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.NonNull;
import android.util.Log;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Created by ghostshi on 2018/1/25.
 */

public class JobReporter {

    private static final String TAG = "JobReporter";
    private static final int MSG_PUT_INTO_THRED_LIST = 1;
    private static final int MSG_REPORT_THRED_PEAK = 2;
    private static List<WeakReference<Thread>> weakThreadList = new ArrayList<WeakReference<Thread>>();
    public static final String ThreadOnCreatedCallBack = "com/tencent/mobileqq/app/JobReporter";
    private static HandlerThread handlerThread;
    static {
        handlerThread = new HandlerThread("dispatch-1") ;
        handlerThread.start();
    }


    //natvie hook callBack
    public static void onThreadCreatedCallback(Object o) {
        if (o != null && o instanceof Thread) {
            Thread t = (Thread) o;
            Log.d(TAG, "onThreadCreatedCallback cthread  : " + Thread.currentThread().getName() + " newThread " + t.getName());
            Message msg = mFileHandler.obtainMessage(MSG_PUT_INTO_THRED_LIST);
            msg.obj = o;
            mFileHandler.sendMessage(msg);
        } else {
            Log.e(TAG, "onThreadCreatedCallback error o= " + o);
        }
    }


    private static Handler mFileHandler = new Handler(handlerThread.getLooper()) {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == MSG_PUT_INTO_THRED_LIST && msg.obj != null) {
                Thread t = (Thread) msg.obj;
                WeakReference<Thread> tRef = new WeakReference<Thread>(t);
                weakThreadList.add(tRef);
            } else if (msg.what == MSG_REPORT_THRED_PEAK) {
                Log.e(TAG, "reportThreadPeakCount Yes " + getCurrentThreadCount());
            } else {
                super.handleMessage(msg);
            }
        }
    };

    private static boolean nativePeerGetFailed = false;

    private static int getCurrentThreadCount() {
        Field nativePeerF = getNativePeerField();
        if (nativePeerF == null) {
            return 0;
        }
        int count = 0;
        List<WeakReference<Thread>> weakThreadDelList = new ArrayList<WeakReference<Thread>>();
        for (WeakReference<Thread> tRef : weakThreadList) {
            if (nativePeerGetFailed) {
                count = 0;
                break;
            }
            Thread thread = tRef.get();
            if (thread != null) {
                try {
                    long nativePeer = (long) nativePeerF.get(thread);// release后等于0
                    if (nativePeer == 0) {
                        weakThreadDelList.add(tRef);
                        continue;
                    }
                    count++;
                } catch (Exception e) {
                    e.printStackTrace();
                    nativePeerGetFailed = true;
                }
            }
        }
        if (nativePeerGetFailed) {
            count = 0;
        }
        weakThreadList.removeAll(weakThreadDelList);
        return count;
    }

    private static Field nativePeerF = null;
    private static boolean nativePeerReflectFailed = false;

    private static Field getNativePeerField() {
        if (nativePeerF != null || nativePeerReflectFailed) {
            return nativePeerF;
        }
        try {
            nativePeerF = Thread.class.getDeclaredField("nativePeer");
            nativePeerF.setAccessible(true);
        } catch (Exception e) {
            e.printStackTrace();
            nativePeerF = null;
            nativePeerReflectFailed = true;
            return null;
        }
        return nativePeerF;
    }

    public static void reportThreadPeakCount(String cuin) {
        Message msg = mFileHandler.obtainMessage(MSG_REPORT_THRED_PEAK);
        msg.obj = cuin;
        mFileHandler.sendMessage(msg);
    }

}
