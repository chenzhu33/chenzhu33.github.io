package com.tencent.mobileqq.JniHookToolkit;

import android.app.Activity;
import android.os.*;
import android.util.Log;
import com.tencent.mobileqq.app.JobReporter;
import com.tencent.mobileqq.nativememorymonitor.library.ExternalProvider;
import com.tencent.mobileqq.nativememorymonitor.library.NativeMemoryMonitor;
import com.tencent.qphone.base.util.QLog;

public class MainActivity extends Activity {
    private static final String TAG = "MainActivity";
    private HandlerThread handlerThread =null;

    private ExternalProvider provider = new ExternalProvider() {
        @Override
        public void onSoLoad(String soPath, String backtrace) {
            Log.d(TAG, "soPath: " + soPath + ", backtrace:\n" + backtrace);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        QLog.init(BuildConfig.APPLICATION_ID, "", "", 0);

        NativeMemoryMonitor.getInstance(this).initThreadHook(JobReporter.ThreadOnCreatedCallBack);
        String[] a = {};
        long TIME_LIMITED_US = 2000000L;
        long COUNT_LIMITED = 2000L;
        long MOMERY_LIMITED = 1024*1024*20L;
        NativeMemoryMonitor.getInstance(this).setupSoLoadHook(this, provider);
        if (Build.VERSION.SDK_INT > 27) {
            final boolean result = NativeMemoryMonitor.getInstance(this).applyHiddenApiPolicyCrack(this);
            Log.d(TAG, "applyHiddenApiPolicyCrack: " + result);
        }
        NativeMemoryMonitor.getInstance(this).init(
                NativeMemoryMonitor.FLAG_JNI_NATIVE_THREAD_MONITOR,
                a,
                TIME_LIMITED_US,
                COUNT_LIMITED,
                MOMERY_LIMITED
        );
//        testThreadCreateHook();
//        testJniRefHookerLock();
        System.loadLibrary("native-lib");
//        NativeMemoryMonitor.getInstance(this).setupASanCallback();
        test(new int[]{1}, "");
        new Thread(){
            @Override
            public void run() {
                while(true){
                    System.out.println(NativeMemoryMonitor.getInstance(MainActivity.this).getUndetachThreads());
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }.start();
    }

    /**
     * 测试 JniRefHooker 多线程安全性问题
     */
    private void testJniRefHookerLock() {
        String[] a = {};
        long TIME_LIMITED_US = 2000000L;
        long COUNT_LIMITED = 2000L;
        long MOMERY_LIMITED = 1024*1024*20L;
        NativeMemoryMonitor.getInstance(this).init(
                NativeMemoryMonitor.FLAG_JNI_GLOBAL_REF_MONITOR|
                NativeMemoryMonitor.FLAG_JNI_WEAK_GLOBAL_REF_MONITOR|
                NativeMemoryMonitor.FLAG_JNI_LOCAL_REF_MONITOR|
                NativeMemoryMonitor.FLAG_JNI_PRIMITIVE_ARRAY_MONITOR,
                a,
                TIME_LIMITED_US,
                COUNT_LIMITED,
                MOMERY_LIMITED
        );
        System.loadLibrary("native-lib");

        for (int i = 0; i < 100; i++) {
            final int index = i;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Log.d(TAG, "nativeTestJniRefHooker: start " + index);
                    nativeTestJniRefHooker();
                    Log.d(TAG, "nativeTestJniRefHooker: end "+ index);
                }
            }).start();
        }
    }

    private native void nativeTestJniRefHooker();

    private void testDump() {
        String[] a = {};
        long TIME_LIMITED_US = 2000000L;
        long COUNT_LIMITED = 2000L;
        long MOMERY_LIMITED = 1024*1024*20L;
        NativeMemoryMonitor.getInstance(this).init(
                NativeMemoryMonitor.FLAG_JNI_CALLXXMETHOD_MONITOR|
                NativeMemoryMonitor.FLAG_JNI_WEAK_GLOBAL_REF_MONITOR|
                NativeMemoryMonitor.FLAG_JNI_CALLXXMETHOD_MONITOR|
                NativeMemoryMonitor.FLAG_JNI_GLOBAL_REF_MONITOR,
                a,
                TIME_LIMITED_US,
                COUNT_LIMITED,
                MOMERY_LIMITED
        );
        System.loadLibrary("native-lib");
//        System.loadLibrary("native-lib");

        // dump every 5 seconds
        getWindow().getDecorView().postDelayed(new Runnable() {
            @Override
            public void run() {
                NativeMemoryMonitor.getInstance(MainActivity.this).dump();

                getWindow().getDecorView().postDelayed(this, 5000);
            }
        }, 5000);
    }

    private native void test(int[] arr, String str);

    private void testCallXXMethod(){
        initCallXXMethodContext();
        nativeTestCheckJNI();
    }

    private native void nativeTestCheckJNI();

    private void testLocalRef(){
        String[] a = {};
        long TIME_LIMITED_US = 2000000L;
        long COUNT_LIMITED = 2000L;
        long MOMERY_LIMITED = 1024*1024*20L;
        NativeMemoryMonitor.getInstance(this).init(
                NativeMemoryMonitor.FLAG_JNI_LOCAL_REF_MONITOR,
                a,
                TIME_LIMITED_US,
                COUNT_LIMITED,
                MOMERY_LIMITED
        );
        System.loadLibrary("native-lib");
        nativeTestLocalRef();
        getWindow().getDecorView().postDelayed(new Runnable() {
            @Override
            public void run() {
                nativeTestLocalRef();
            }
        },2000);

        new Thread(new Runnable() {
            @Override
            public void run() {
                nativeTestLocalRef();
                SystemClock.sleep(2000);
                nativeTestLocalRef();
            }
        }).start();
    }

    private native void nativeTestLocalRef();

    private void initCallXXMethodContext(){
        String[] a = {};
        long TIME_LIMITED_US = 2000000L;
        long COUNT_LIMITED = 2000L;
        long MOMERY_LIMITED = 1024*1024*20L;
        NativeMemoryMonitor.getInstance(this).init(
                NativeMemoryMonitor.FLAG_JNI_CALLXXMETHOD_MONITOR,
                a,
                TIME_LIMITED_US,
                COUNT_LIMITED,
                MOMERY_LIMITED
        );
        System.loadLibrary("native-lib");
    }
    /**
     * Called from native
     */
    public void voidMethod(){
        Log.d("Demo", "voidMethod: ");
    }

    /**
     * Called from native
     * @return
     */
    public int callIntMethod(){
        Log.d("Demo", "callIntMethod() called");
        return 1;
    }

    /**
     * Called from native
     * @return
     */
    public int callIntMethod(int in){
        Log.d("Demo", "callIntMethod() called in="+ in);
        return in;
    }

    public String callObjectMethod(int in){
        Log.d("Demo", "callObjectMethod() called in="+ in);
        return "hello world";
    }

    public String callObjectMethodA(int in){
        Log.d("Demo", "callObjectMethod() called in="+ in);
        return "hello world";
    }

    public boolean callBooleanMethod(int in){
        return true;
    }

    public boolean callBooleanMethodA(int in){
        return false;
    }

    public byte callByteMethod(int in){
        byte b = 0x1;
        return b;
    }

    public byte callByteMethodA(int in){
        byte b = 0x1;
        return b;
    }

    public short callShortMethod(int in){
        return 0x01;
    }

    public short callShortMethodA(int in){
        return 0x01;
    }

    public char callCharMethod(int in){
        return 'a';
    }

    public char callCharMethodA(int in){
        return 'a';
    }

    public long callLongMethod(int in){
        return 0x1;
    }

    public long callLongMethodA(int in){
        return 0x01;
    }

    public float callFloatMethod(int in){
        return 0.1f;
    }

    public float callFloatMethodA(int in){
        return 0.1f;
    }

    public double callDoubleMethod(int in){
        return 0.1f;
    }

    public double callDoubleMethodA(int in){
        return 0.1f;
    }

    /**
     * 线程创建Hook测试
     ****/
    @Override
    protected void onStop() {
        super.onStop();
        JobReporter.reportThreadPeakCount(null);
    }

    public void testThreadCreateHook() {
        handlerThread = new HandlerThread("常驻线程");
        handlerThread.start();
        Handler h = new Handler(Looper.getMainLooper());
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                for (int i = 1; i < 1000; i++) {
                    Thread t = new Thread() {
                        @Override
                        public void run() {
                            try {
                                sleep(50000);
                                Log.d("JobReporter", "test.......");
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    };
                    t.setName("test-" + i);
                    t.start();
                }
            }
        }, 5000);
    }
    /**线程创建Hook测试****/

}
