package com.tencent.mobileqq.statistics;

import android.os.Environment;
import android.util.Log;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by hongpingwu on 2018/3/31.
 */

public class QQCatchedExceptionReporter {

    public static void reportQQCatchException(String tag, String msg){
        Log.i("demo", "write log: " + tag);
        File file = new File(Environment.getExternalStorageDirectory(), "testlog.txt");
        BufferedOutputStream os = null;
        try {
            if(!file.exists()){
                file.createNewFile();
            }
            os = new BufferedOutputStream(new FileOutputStream(file, true));
            os.write(tag.getBytes("utf-8"));
            os.write("\n".getBytes("utf-8"));
            os.write(msg.getBytes("utf-8"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(os != null){
                try {
                    os.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        Log.i("demo", "write log end");
    }
}
