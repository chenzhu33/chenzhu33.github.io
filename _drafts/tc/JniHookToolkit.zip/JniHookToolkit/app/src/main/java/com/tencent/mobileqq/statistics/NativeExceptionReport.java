package com.tencent.mobileqq.statistics;

import android.util.Log;

public class NativeExceptionReport {

    public static void reportASanError(String msg){
        Log.d("ASanCallback", "callback");
        String[] line = msg.split("\n");
        for(String str : line){
            Log.d("ASanCallback", str);
        }
    }
}
