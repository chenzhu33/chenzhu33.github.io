package com.tencent.mobileqq.JniHookToolkit;

public class GetSetXXField {
    public MainActivity obj;
    public boolean b;
    public byte bt;
    public short s;
    public char c;
    public int i;
    public long l;
    public float f;
    public double d;
}
