package com.tencent.mobileqq.JniHookToolkit;

public class CallStaticXXMethod {
    /**
     * Called from native
     */
    public static void voidMethod() {
    }
    public static void voidMethodA(int i) {
    }

    /**
     * Called from native
     *
     * @return
     */
    public static int callIntMethod() {
        return 1;
    }

    /**
     * Called from native
     *
     * @return
     */
    public static int callIntMethodA(int in) {
        return in;
    }

    public static String callObjectMethod(int in) {
        return "hello world";
    }

    public static String callObjectMethodA(int in) {
        return "hello world";
    }

    public static boolean callBooleanMethod(int in) {
        return true;
    }

    public static boolean callBooleanMethodA(int in) {
        return false;
    }

    public static byte callByteMethod(int in) {
        return 0x1;
    }

    public static byte callByteMethodA(int in) {
        return 0x1;
    }

    public static short callShortMethod(int in) {
        return 0x01;
    }

    public static short callShortMethodA(int in) {
        return 0x01;
    }

    public static char callCharMethod(int in) {
        return 'a';
    }

    public static char callCharMethodA(int in) {
        return 'a';
    }

    public static long callLongMethod(int in) {
        return 0x1;
    }

    public static long callLongMethodA(int in) {
        return 0x01;
    }

    public static float callFloatMethod(int in) {
        return 0.1f;
    }

    public static float callFloatMethodA(int in) {
        return 0.1f;
    }

    public static double callDoubleMethod(int in) {
        return 0.1f;
    }

    public static double callDoubleMethodA(int in) {
        return 0.1f;
    }
}
