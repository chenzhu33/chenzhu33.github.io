#include <jni.h>
#include <malloc.h>
#include <android/log.h>
#include <map>
#include <sys/time.h>
#include <pthread.h>
#include "gtest/gtest.h"

jobject objs[600];

JavaVM * gVm;
jobject gMainActivity;
pthread_key_t key;

void testHookCallXXMethod();

void *child1(void *arg) {
//    struct timeval time_begin, time_end;
//    gettimeofday(&time_begin,NULL);
//    void*  ptr = NULL;
//    for(int i = 0;i<1000;i++) {
//        ptr = malloc(10);
//    }
//    ptr = malloc(3000);
//    free(ptr);
//    gettimeofday(&time_end,NULL);
//    long cost = (time_end.tv_usec - time_begin.tv_usec)  + 1000000 * (time_end.tv_sec - time_end.tv_sec);
    __android_log_print(ANDROID_LOG_INFO, "Demo", "child1 thread %d is running", gettid());
    JNIEnv* env;
    gVm->AttachCurrentThread(&env, NULL);
    usleep(5 * 1000 * 1000);
    gVm->DetachCurrentThread();
    return (void *)1;
}

void *child2(void *arg) {
//    struct timeval time_begin, time_end;
//    gettimeofday(&time_begin,NULL);
//    void*  ptr = NULL;
//    for(int i = 0;i<1000;i++) {
//        ptr = malloc(10);
//    }
//    ptr = malloc(3000);
//    free(ptr);
//    gettimeofday(&time_end,NULL);
//    long cost = (time_end.tv_usec - time_begin.tv_usec)  + 1000000 * (time_end.tv_sec - time_end.tv_sec);
//    __android_log_print(ANDROID_LOG_INFO, "Demo", "child2 time cost%ld", cost);
    __android_log_print(ANDROID_LOG_INFO, "Demo", "child2 thread %d is running", gettid());
    JNIEnv* env;
    gVm->AttachCurrentThread(&env, NULL);
    usleep(10 * 1000 * 1000);
    gVm->DetachCurrentThread();
    return (void *)1;
}


void testHookCallXXMethod(JNIEnv *env,
                          jobject instance) {
    jclass thisClass = env->GetObjectClass(instance);
    jmethodID voidMethodID = env->GetMethodID(thisClass,"voidMethod","()V");
    env->CallVoidMethod(instance, voidMethodID);

    jmethodID intMethodID = env->GetMethodID(thisClass,"callIntMethod","()I");
    jint iRet = env->CallIntMethod(instance, intMethodID);
    __android_log_print(ANDROID_LOG_INFO, "demo", "CallIntMethod  java level return %d", iRet);

    // test crash
    // env->CallVoidMethod((jobject)(0), voidMethodID);

    env->DeleteLocalRef(thisClass);
}

extern "C"
JNIEXPORT void
JNICALL
Java_com_tencent_mobileqq_JniHookToolkit_MainActivity_test(
        JNIEnv *env,
        jobject instance, jintArray arr, jstring str) {
    __android_log_print(ANDROID_LOG_INFO, "demo", "test begin");

//    int count = 128;
//    for(int i = 0; i < 50000; i++){
//        jweak weakGlobalRef = env->NewWeakGlobalRef(instance);
//        jobject global = env->NewGlobalRef(instance);
//        if (count >= 0){
//            env->DeleteWeakGlobalRef(weakGlobalRef);
//            env->DeleteGlobalRef(global);
//
//            count--;
//        }
//    }
//
//    struct timeval time_begin, time_end;
//    gettimeofday(&time_begin,NULL);
//    void*  ptr = NULL;
//    for(int i = 0;i<1000;i++) {
//        ptr = malloc(10);
//    }
//    ptr = malloc(10);
//    gettimeofday(&time_end,NULL);
//    long cost = (time_end.tv_usec - time_begin.tv_usec)  + 1000000 * (time_end.tv_sec - time_end.tv_sec);
//    __android_log_print(ANDROID_LOG_INFO, "Demo", "time cost%ld", cost);
    pthread_t tid1;
    pthread_t tid2;
    pthread_create(&tid1, NULL, child1, NULL);
    pthread_create(&tid2, NULL, child2, NULL);


//    jclass tmp = env->FindClass("com/tencent/mobileqq/nativememorymonitor/library/NativeMemoryMonitor");
//    jclass cls = (jclass) env->NewGlobalRef(tmp);
//    jmethodID constrocMID = env->GetMethodID(cls,"<init>","()V");
//    jobject newObj = env->NewObject(cls, constrocMID);
//    env->DeleteLocalRef(tmp);
//    env->DeleteLocalRef(newObj);
//    env->DeleteGlobalRef(cls);
//
//    for(int i = 0; i < 500; i++) {
//        objs[i] = env->NewLocalRef(instance);
////        env->DeleteLocalRef(local);
//    }
//
//    jobject global = env->NewGlobalRef(instance);
//    env->DeleteGlobalRef(global);
//
//    const jchar* chars = env->GetStringChars(str, NULL);
//    env->ReleaseStringChars(str, chars);
//
//    jint* intArr = env->GetIntArrayElements(arr, NULL);
//    env->ReleaseIntArrayElements(arr, intArr, 0);
//
//    free(ptr);
//
//    // test hook CallVoidMethod
//    testHookCallXXMethod(env, instance);

    __android_log_print(ANDROID_LOG_INFO, "demo", "test end");
}

/**
 * 测试 Native 层不同的创建引用所属的不同调用栈
 * @param env
 * @param instance
 */
void testBacktraceContainsPC(JNIEnv *env, jobject instance){
    for (int i = 0; i < 256; ++i) {
        jclass cls = env->GetObjectClass(instance);
//        env->DeleteLocalRef(cls);
    }
}

extern "C"
JNIEXPORT void
JNICALL
Java_com_tencent_mobileqq_JniHookToolkit_MainActivity_nativeTestLocalRef(
        JNIEnv *env, jobject instance) {
    __android_log_print(ANDROID_LOG_INFO, "demo", "%s 1", __FUNCTION__);

    for (int i = 0; i < 256; ++i) {
        jclass cls = env->GetObjectClass(instance);
//        env->DeleteLocalRef(cls);
    }

    testBacktraceContainsPC(env, instance);

    __android_log_print(ANDROID_LOG_INFO, "demo", "%s 2", __FUNCTION__);
}

TEST(CallVoidMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass c = env->FindClass("java/lang/String");
    jmethodID mid1 = env->GetMethodID(c, "<init>", "()V");
    jmethodID mid2 = env->GetMethodID(c, "<init>", "([B)V");
    jmethodID mid3 = env->GetMethodID(c, "<init>", "([C)V");
    jmethodID mid4 = env->GetMethodID(c, "<init>", "(Ljava/lang/String;)V");

    const char* test_array = "Test";
    int byte_array_length = strlen(test_array);
    jbyteArray byte_array = env->NewByteArray(byte_array_length);
    env->SetByteArrayRegion(byte_array, 0, byte_array_length, reinterpret_cast<const jbyte*>(test_array));

    // Test NewObject
    jstring s = reinterpret_cast<jstring>(env->NewObject(c, mid2, byte_array));
    EXPECT_TRUE(s != 0);
    EXPECT_EQ(env->GetStringLength(s), byte_array_length);
    EXPECT_EQ(env->GetStringUTFLength(s), byte_array_length);
    const char* chars = env->GetStringUTFChars(s, 0);
    EXPECT_EQ(strcmp(test_array, chars), 0);
    env->ReleaseStringUTFChars(s, chars);

    // Test AllocObject and Call(Nonvirtual)VoidMethod
    jstring s1 = reinterpret_cast<jstring>(env->AllocObject(c));
    EXPECT_TRUE(s1 != 0);
    jstring s2 = reinterpret_cast<jstring>(env->AllocObject(c));
    EXPECT_TRUE(s2 != 0);
    jstring s3 = reinterpret_cast<jstring>(env->AllocObject(c));
    EXPECT_TRUE(s3 != 0);
    jstring s4 = reinterpret_cast<jstring>(env->AllocObject(c));
    EXPECT_TRUE(s4 != 0);

    jcharArray char_array = env->NewCharArray(5);
    jstring string_arg = env->NewStringUTF("helloworld");

    // With Var Args
    env->CallVoidMethod(s1, mid1);
    env->CallNonvirtualVoidMethod(s2, c, mid2, byte_array);

    // With JValues
    jvalue args3[1];
    args3[0].l = char_array;
    jvalue args4[1];
    args4[0].l = string_arg;
    env->CallVoidMethodA(s3, mid3, args3);

    // Test with global and weak global references
    jstring s5 = reinterpret_cast<jstring>(env->AllocObject(c));
    EXPECT_TRUE(s5 != 0);
    s5 = reinterpret_cast<jstring>(env->NewGlobalRef(s5));
    jstring s6 = reinterpret_cast<jstring>(env->AllocObject(c));
    EXPECT_TRUE(s6 != 0);
    s6 = reinterpret_cast<jstring>(env->NewWeakGlobalRef(s6));

    env->CallVoidMethod(s5, mid1);
    env->CallNonvirtualVoidMethod(s6, c, mid2, byte_array);
    EXPECT_EQ(env->GetStringLength(s5), 0);
    EXPECT_EQ(env->GetStringLength(s6), byte_array_length);
    const char* chars6 = env->GetStringUTFChars(s6, 0);
    EXPECT_EQ(strcmp(test_array, chars6), 0);
    env->ReleaseStringUTFChars(s6, chars6);
}

TEST(CallObjectMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->GetObjectClass(gMainActivity);
    jmethodID mid0 = env->GetMethodID(cls, "callObjectMethod","(I)Ljava/lang/String;");
    jobject string = env->CallObjectMethod(gMainActivity, mid0);
    const char *nativeString = env->GetStringUTFChars(static_cast<jstring>(string), 0);
    EXPECT_TRUE(strcmp("hello world", nativeString) == 0);

    mid0 = env->GetMethodID(cls, "callObjectMethodA","(I)Ljava/lang/String;");
    jvalue args;
    args.i = 2;
    string = env->CallObjectMethodA(gMainActivity, mid0, &args);
    nativeString = env->GetStringUTFChars(static_cast<jstring>(string), 0);
    EXPECT_TRUE(strcmp("hello world", nativeString) == 0);
}

TEST(CallBooleanMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->GetObjectClass(gMainActivity);
    jmethodID mid0 = env->GetMethodID(cls, "callBooleanMethod","(I)Z");
    jboolean result = env->CallBooleanMethod(gMainActivity, mid0);
    EXPECT_TRUE(result);

    mid0 = env->GetMethodID(cls, "callBooleanMethodA","(I)Z");
    jvalue args;
    args.i = 2;
    result = env->CallBooleanMethodA(gMainActivity, mid0, &args);
    EXPECT_FALSE(result);
}

TEST(CallByteMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->GetObjectClass(gMainActivity);
    jmethodID mid0 = env->GetMethodID(cls, "callByteMethod","(I)B");
    jbyte result = env->CallByteMethod(gMainActivity, mid0);
    EXPECT_TRUE(result == 0x1);

    mid0 = env->GetMethodID(cls, "callByteMethodA","(I)B");
    jvalue args;
    args.i = 2;
    result = env->CallByteMethodA(gMainActivity, mid0, &args);
    EXPECT_TRUE(result == 0x1);
}

TEST(CallShortMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->GetObjectClass(gMainActivity);
    jmethodID mid0 = env->GetMethodID(cls, "callShortMethod","(I)S");
    jshort result = env->CallShortMethod(gMainActivity, mid0);
    EXPECT_TRUE(result == 1);

    mid0 = env->GetMethodID(cls, "callShortMethodA","(I)S");
    jvalue args;
    args.i = 2;
    result = env->CallShortMethodA(gMainActivity, mid0, &args);
    EXPECT_TRUE(result==1);
}

TEST(CallCharMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->GetObjectClass(gMainActivity);
    jmethodID mid0 = env->GetMethodID(cls, "callCharMethod","(I)C");
    jchar result = env->CallCharMethod(gMainActivity, mid0);
    EXPECT_TRUE(result == 'a');

    mid0 = env->GetMethodID(cls, "callCharMethodA","(I)C");
    jvalue args;
    args.i = 2;
    result = env->CallCharMethodA(gMainActivity, mid0, &args);
    EXPECT_TRUE(result=='a');
}

TEST(CallIntMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->GetObjectClass(gMainActivity);
    jmethodID mid0 = env->GetMethodID(cls, "callIntMethod","()I");
    jint iRet = env->CallIntMethod(gMainActivity, mid0);
    EXPECT_EQ(1, iRet);

    jmethodID mid1 = env->GetMethodID(cls, "callIntMethod","(I)I");
    jvalue args;
    args.i = 3;
    iRet = env->CallIntMethodA(gMainActivity, mid1, &args);
    EXPECT_EQ(3, iRet);

    jclass jlrMethod = env->FindClass("java/lang/reflect/Method");
    EXPECT_TRUE(jlrMethod != 0);
    jclass jlrConstructor = env->FindClass("java/lang/reflect/Constructor");
    EXPECT_TRUE(jlrConstructor != 0);
    jclass c = env->FindClass("java/lang/String");
    EXPECT_TRUE(c != 0);
    jmethodID mid = env->GetMethodID(c, "<init>", "()V");
    EXPECT_TRUE(mid != 0);
    // Turn the mid into a java.lang.reflect.Constructor...
    jobject method = env->ToReflectedMethod(c, mid, JNI_FALSE);
//    for (size_t i = 0; i <= kLocalsMax; ++i) {
    // Regression test for b/18396311, ToReflectedMethod leaking local refs causing a local
    // reference table overflows with 512 references to ArtMethod
//        env->DeleteLocalRef(env->ToReflectedMethod(c, mid, JNI_FALSE));
//    }
    EXPECT_TRUE(method != 0);
    EXPECT_TRUE(env->IsInstanceOf(method, jlrConstructor));
    // ...and back again.
    jmethodID mid2 = env->FromReflectedMethod(method);
    EXPECT_TRUE(mid2 != 0);
    // Make sure we can actually use it.
    jstring s = reinterpret_cast<jstring>(env->AllocObject(c));
    EXPECT_TRUE(s != 0);
    env->CallVoidMethod(s, mid2);
    EXPECT_EQ(JNI_FALSE, env->ExceptionCheck());
    env->ExceptionClear();

    mid = env->GetMethodID(c, "length", "()I");
    EXPECT_TRUE(mid != 0);
    // Turn the mid into a java.lang.reflect.Method...
    method = env->ToReflectedMethod(c, mid, JNI_FALSE);
    EXPECT_TRUE(method != 0);
    EXPECT_TRUE(env->IsInstanceOf(method, jlrMethod));
    // ...and back again.
    mid2 = env->FromReflectedMethod(method);
    EXPECT_TRUE(mid2 != 0);
    // Make sure we can actually use it.
    s = env->NewStringUTF("poop");
    EXPECT_TRUE(s != 0);
    EXPECT_EQ(4, env->CallIntMethod(s, mid2));
}

TEST(CallLongMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->GetObjectClass(gMainActivity);
    jmethodID mid0 = env->GetMethodID(cls, "callLongMethod","(I)J");
    jlong result = env->CallLongMethod(gMainActivity, mid0);
    EXPECT_TRUE(result == 1);

    mid0 = env->GetMethodID(cls, "callLongMethodA","(I)J");
    jvalue args;
    args.i = 2;
    result = env->CallLongMethodA(gMainActivity, mid0, &args);
    EXPECT_TRUE(result==1);
}

TEST(CallFloatMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->GetObjectClass(gMainActivity);
    jmethodID mid0 = env->GetMethodID(cls, "callFloatMethod","(I)F");
    jfloat result = env->CallFloatMethod(gMainActivity, mid0);
    EXPECT_TRUE(result == 0.1f);

    mid0 = env->GetMethodID(cls, "callFloatMethodA","(I)F");
    jvalue args;
    args.i = 2;
    result = env->CallFloatMethodA(gMainActivity, mid0, &args);
    EXPECT_TRUE(result==0.1f);
}

TEST(CallDoubleMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->GetObjectClass(gMainActivity);
    jmethodID mid0 = env->GetMethodID(cls, "callDoubleMethod","(I)D");
    jdouble result = env->CallDoubleMethod(gMainActivity, mid0);
    EXPECT_TRUE(result == 0.1f);

    mid0 = env->GetMethodID(cls, "callDoubleMethodA","(I)D");
    jvalue args;
    args.i = 2;
    result = env->CallDoubleMethodA(gMainActivity, mid0, &args);
    EXPECT_TRUE(result== 0.1f);
}

TEST(CallStaticVoidMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass c = env->FindClass("com/tencent/mobileqq/JniHookToolkit/CallStaticXXMethod");
    jmethodID m = env->GetStaticMethodID(c, "voidMethod", "()V");
    env->CallStaticVoidMethod(c, m);

    m = env->GetStaticMethodID(c, "voidMethodA", "(I)V");
    jvalue args;
    args.i = 1;
    env->CallStaticVoidMethodA(c, m, &args);
}

TEST(CallStaticObjectMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass c = env->FindClass("com/tencent/mobileqq/JniHookToolkit/CallStaticXXMethod");
    jmethodID mid0 = env->GetStaticMethodID(c, "callObjectMethod","(I)Ljava/lang/String;");
    jobject string = env->CallStaticObjectMethod(c, mid0);

    const char *nativeString = env->GetStringUTFChars(static_cast<jstring>(string), 0);
    EXPECT_TRUE(strcmp("hello world", nativeString) == 0);

    mid0 = env->GetStaticMethodID(c, "callObjectMethodA","(I)Ljava/lang/String;");
    jvalue args;
    args.i = 2;
    string = env->CallStaticObjectMethodA(c, mid0, &args);
    nativeString = env->GetStringUTFChars(static_cast<jstring>(string), 0);
    EXPECT_TRUE(strcmp("hello world", nativeString) == 0);
}

TEST(CallStaticBooleanMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->FindClass("com/tencent/mobileqq/JniHookToolkit/CallStaticXXMethod");
    jmethodID mid0 = env->GetStaticMethodID(cls, "callBooleanMethod","(I)Z");
    jboolean result = env->CallStaticBooleanMethod(cls, mid0);
    EXPECT_TRUE(result);

    mid0 = env->GetStaticMethodID(cls, "callBooleanMethodA","(I)Z");
    jvalue args;
    args.i = 2;
    result = env->CallStaticBooleanMethodA(cls, mid0, &args);
    EXPECT_FALSE(result);
}

TEST(CallStaticByteMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->FindClass("com/tencent/mobileqq/JniHookToolkit/CallStaticXXMethod");
    jmethodID mid0 = env->GetStaticMethodID(cls, "callByteMethod","(I)B");
    jbyte result = env->CallStaticByteMethod(cls, mid0);
    EXPECT_TRUE(result == 0x1);

    mid0 = env->GetStaticMethodID(cls, "callByteMethodA","(I)B");
    jvalue args;
    args.i = 2;
    result = env->CallStaticByteMethodA(cls, mid0, &args);
    EXPECT_TRUE(result == 0x1);
}

TEST(CallStaticShortMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->FindClass("com/tencent/mobileqq/JniHookToolkit/CallStaticXXMethod");
    jmethodID mid0 = env->GetStaticMethodID(cls, "callShortMethod","(I)S");
    jshort result = env->CallStaticShortMethod(cls, mid0);
    EXPECT_TRUE(result == 1);

    mid0 = env->GetStaticMethodID(cls, "callShortMethodA","(I)S");
    jvalue args;
    args.i = 2;
    result = env->CallStaticShortMethodA(cls, mid0, &args);
    EXPECT_TRUE(result==1);
}

TEST(CallStaticCharMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->FindClass("com/tencent/mobileqq/JniHookToolkit/CallStaticXXMethod");
    jmethodID mid0 = env->GetStaticMethodID(cls, "callCharMethod","(I)C");
    jchar result = env->CallStaticCharMethod(cls, mid0);
    EXPECT_TRUE(result == 'a');

    mid0 = env->GetStaticMethodID(cls, "callCharMethodA","(I)C");
    jvalue args;
    args.i = 2;
    result = env->CallStaticCharMethodA(cls, mid0, &args);
    EXPECT_TRUE(result=='a');
}

TEST(CallStaticIntMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->FindClass("com/tencent/mobileqq/JniHookToolkit/CallStaticXXMethod");
    jmethodID mid0 = env->GetStaticMethodID(cls, "callIntMethod","()I");
    jint result = env->CallStaticIntMethod(cls, mid0);
    EXPECT_TRUE(result == 1);

    mid0 = env->GetStaticMethodID(cls, "callIntMethodA","(I)I");
    jvalue args;
    args.i = 1;
    result = env->CallStaticIntMethodA(cls, mid0, &args);
    EXPECT_TRUE(result==1);
}

TEST(CallStaticLongMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->FindClass("com/tencent/mobileqq/JniHookToolkit/CallStaticXXMethod");
    jmethodID mid0 = env->GetStaticMethodID(cls, "callLongMethod","(I)J");
    jlong result = env->CallStaticLongMethod(cls, mid0);
    EXPECT_TRUE(result == 1);

    mid0 = env->GetStaticMethodID(cls, "callLongMethodA","(I)J");
    jvalue args;
    args.i = 2;
    result = env->CallStaticLongMethodA(cls, mid0, &args);
    EXPECT_TRUE(result==1);
}

TEST(CallStaticFloatMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->FindClass("com/tencent/mobileqq/JniHookToolkit/CallStaticXXMethod");
    jmethodID mid0 = env->GetStaticMethodID(cls, "callFloatMethod","(I)F");
    jfloat result = env->CallStaticFloatMethod(cls, mid0);
    EXPECT_TRUE(result == 0.1f);

    mid0 = env->GetStaticMethodID(cls, "callFloatMethodA","(I)F");
    jvalue args;
    args.i = 2;
    result = env->CallStaticFloatMethodA(cls, mid0, &args);
    EXPECT_TRUE(result==0.1f);
}

TEST(CallStaticDoubleMethodA, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass cls = env->FindClass("com/tencent/mobileqq/JniHookToolkit/CallStaticXXMethod");
    jmethodID mid0 = env->GetStaticMethodID(cls, "callDoubleMethod","(I)D");
    jdouble result = env->CallStaticDoubleMethod(cls, mid0);
    EXPECT_TRUE(result == 0.1f);

    mid0 = env->GetStaticMethodID(cls, "callDoubleMethodA","(I)D");
    jvalue args;
    args.i = 2;
    result = env->CallStaticDoubleMethodA(cls, mid0, &args);
    EXPECT_TRUE(result== 0.1f);
}

TEST(GetSetXXField, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass c = env->FindClass("com/tencent/mobileqq/JniHookToolkit/GetSetXXField");
    jmethodID m = env->GetMethodID(c, "<init>", "()V");
    jobject object = env->NewObject(c, m);

    jfieldID f = env->GetFieldID(c, "obj", "Lcom/tencent/mobileqq/JniHookToolkit/MainActivity;");
    env->SetObjectField(object, f, gMainActivity);
    jobject objectField = env->GetObjectField(object, f);
    EXPECT_TRUE(env->IsSameObject(gMainActivity, objectField));

    f = env->GetFieldID(c, "b", "Z");
    env->SetBooleanField(object, f, JNI_TRUE);
    EXPECT_TRUE(env->GetBooleanField(object, f) == JNI_TRUE);

    f = env->GetFieldID(c, "bt", "B");
    env->SetByteField(object, f, 1);
    EXPECT_TRUE(env->GetByteField(object, f) == 1);

    f = env->GetFieldID(c, "c", "C");
    env->SetCharField(object, f, 'a');
    EXPECT_TRUE(env->GetCharField(object, f) == 'a');

    f = env->GetFieldID(c, "s", "S");
    env->SetShortField(object, f, 1);
    EXPECT_TRUE(env->GetShortField(object, f) == 1);

    f = env->GetFieldID(c, "i", "I");
    env->SetIntField(object, f, 1);
    EXPECT_TRUE(env->GetIntField(object, f) == 1);

    f = env->GetFieldID(c, "l", "J");
    env->SetLongField(object, f, 1);
    EXPECT_TRUE(env->GetLongField(object, f) == 1);

    f = env->GetFieldID(c, "f", "F");
    env->SetFloatField(object, f, 0.1F);
    EXPECT_TRUE(env->GetFloatField(object, f) == 0.1F);

    f = env->GetFieldID(c, "d", "D");
    env->SetDoubleField(object, f, 0.1);
    EXPECT_TRUE(env->GetDoubleField(object, f) == 0.1);
}


TEST(GetSetXXArrayRegion, NormalInput){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jbooleanArray array1 = env->NewBooleanArray(2);
    jboolean buf1[] = {0, 1};
    env->SetBooleanArrayRegion(array1, 0, 2, buf1);
    buf1[0] = 0;
    buf1[1] = 0;
    env->GetBooleanArrayRegion(array1, 0, 2, buf1);
    EXPECT_EQ(buf1[0], 0);
    EXPECT_EQ(buf1[1], 1);

    jbyteArray array2 = env->NewByteArray(2);
    jbyte buf2[] = {0, 1};
    env->SetByteArrayRegion(array2, 0, 2, buf2);
    buf2[0] = 0;
    buf2[1] = 0;
    env->GetByteArrayRegion(array2, 0, 2, buf2);
    EXPECT_EQ(buf2[0], 0);
    EXPECT_EQ(buf2[1], 1);

    jcharArray array3 = env->NewCharArray(2);
    jchar buf3[] = {0, 1};
    env->SetCharArrayRegion(array3, 0, 2, buf3);
    buf3[0] = 0;
    buf3[1] = 0;
    env->GetCharArrayRegion(array3, 0, 2, buf3);
    EXPECT_EQ(buf3[0], 0);
    EXPECT_EQ(buf3[1], 1);

    jshortArray array4 = env->NewShortArray(2);
    jshort buf4[] = {0, 1};
    env->SetShortArrayRegion(array4, 0, 2, buf4);
    buf4[0] = 0;
    buf4[1] = 0;
    env->GetShortArrayRegion(array4, 0, 2, buf4);
    EXPECT_EQ(buf4[0], 0);
    EXPECT_EQ(buf4[1], 1);

    jintArray array5 = env->NewIntArray(2);
    jint buf5[] = {0, 1};
    env->SetIntArrayRegion(array5, 0, 2, buf5);
    buf5[0] = 0;
    buf5[1] = 0;
    env->GetIntArrayRegion(array5, 0, 2, buf5);
    EXPECT_EQ(buf5[0], 0);
    EXPECT_EQ(buf5[1], 1);

    jlongArray array6 = env->NewLongArray(2);
    jlong buf6[] = {0, 1};
    env->SetLongArrayRegion(array6, 0, 2, buf6);
    buf6[0] = 0;
    buf6[1] = 0;
    env->GetLongArrayRegion(array6, 0, 2, buf6);
    EXPECT_EQ(buf6[0], 0);
    EXPECT_EQ(buf6[1], 1);

    jfloatArray array7 = env->NewFloatArray(2);
    jfloat buf7[] = {0, 1};
    env->SetFloatArrayRegion(array7, 0, 2, buf7);
    buf7[0] = 0;
    buf7[1] = 0;
    env->GetFloatArrayRegion(array7, 0, 2, buf7);
    EXPECT_EQ(buf7[0], 0);
    EXPECT_EQ(buf7[1], 1);

    jdoubleArray array8 = env->NewDoubleArray(2);
    jdouble buf8[] = {0, 1};
    env->SetDoubleArrayRegion(array8, 0, 2, buf8);
    buf8[0] = 0;
    buf8[1] = 0;
    env->GetDoubleArrayRegion(array8, 0, 2, buf8);
    EXPECT_EQ(buf8[0], 0);
    EXPECT_EQ(buf8[1], 1);
}

TEST(GetStaticMethodID, Normal){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jclass vm_class = env->FindClass("dalvik/system/VMDebug");
    jmethodID dump_mid = env->GetStaticMethodID(vm_class, "dumpReferenceTables", "()V");
    env->CallStaticVoidMethod(vm_class, dump_mid);
}

TEST(ReleaseByteArrayElements, Normal){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);

    jboolean isCopy;
    jbyteArray array = env->NewByteArray(4);
    jbyte buf[] = {1, 2, 3, 4};
    env->SetByteArrayRegion(array, 0, 4, buf);
    int i = 0;
    while (i++ < 10) {
        jbyte *elements = env->GetByteArrayElements(array, &isCopy);
        env->ReleaseByteArrayElements(array, elements, JNI_COMMIT);
    }
}

TEST(CallStaticVoidMethod, Crash){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);
//    env->CallStaticVoidMethod(0, 0);
}

TEST(CallStaticIntMethod, Crash){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);
//    env->CallStaticIntMethod(0, 0);
}

TEST(CallStaticShortMethod, Crash){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);
//    env->CallStaticShortMethod(0, 0);
}

TEST(CallStaticCharMethod, Crash){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);
//    env->CallStaticCharMethod(0, 0);
}

TEST(CallStaticByteMethod, Crash){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);
//    env->CallStaticByteMethod(0, 0);
}

TEST(CallStaticBooleanMethod, Crash){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);
//    env->CallStaticBooleanMethod(0, 0);
}

TEST(CallStaticObjectMethod, Crash){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);
//    env->CallStaticObjectMethod(0, 0);
}

TEST(CallStaticDoubleMethod, Crash){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);
//    env->CallStaticDoubleMethod(0, 0);
}

TEST(CallStaticFloatMethod, Crash){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);
//    env->CallStaticFloatMethod(0, 0);
}

TEST(CallStaticLongMethod, Crash){
    JNIEnv* env;
    gVm->GetEnv((void **)&env, JNI_VERSION_1_4);
//    env->CallStaticLongMethod(0, 0);
}

static void _Test(){
    int argc = 3;
    char * argv[] = {"test.exe",
                     "--gtest_output=xml:/sdcard/test.xml", "--gtest_filter=*.*", NULL};
    testing::InitGoogleTest(&argc, (char **)(argv));
    RUN_ALL_TESTS();
}

extern "C"
JNIEXPORT void
JNICALL
Java_com_tencent_mobileqq_JniHookToolkit_MainActivity_nativeTestCheckJNI
        (JNIEnv *env, jobject instance) {
    __android_log_print(ANDROID_LOG_INFO, "demo", "%s start", __FUNCTION__);

    gMainActivity = instance;
//    #define INVOKE_XX_FIELD(_jname)\
//        env->Get##_jname##Field(0, 0);\
//        env->Set##_jname##Field(0, 0, 0);
//
//    INVOKE_XX_FIELD(Object)
//    INVOKE_XX_FIELD(Boolean)
//    INVOKE_XX_FIELD(Byte)
//    INVOKE_XX_FIELD(Short)
//    INVOKE_XX_FIELD(Char)
//    INVOKE_XX_FIELD(Int)
//    INVOKE_XX_FIELD(Long)
//    INVOKE_XX_FIELD(Float)
//    INVOKE_XX_FIELD(Double)
//
//    #undef INVOKE_XX_FIELD

//    env->CallVoidMethod(0, 0);
//    env->CallObjectMethod(0, 0);
//    env->CallBooleanMethod(0, 0);
//    env->CallByteMethod(0, 0);
//    env->CallCharMethod(0, 0);
//    env->CallShortMethod(0, 0);
//    env->CallIntMethod(0, 0);
//    env->CallLongMethod(0, 0);
//    env->CallFloatMethod(0, 0);
//    env->CallDoubleMethod(0, 0);

//    jvalue *args = NULL;
//    env->CallVoidMethodA(0, 0, args);
//    env->CallObjectMethodA(0, 0, args);
//    env->CallBooleanMethodA(0, 0, args);
//    env->CallByteMethodA(0, 0, args);
//    env->CallCharMethodA(0, 0, args);
//    env->CallShortMethodA(0, 0, args);
//    env->CallIntMethodA(0, 0, args);
//    env->CallLongMethodA(0, 0, args);
//    env->CallFloatMethodA(0, 0, args);
//    env->CallDoubleMethodA((jobject)(78), 0, args);
//    env->CallDoubleMethodA((jobject)(78), 0, args);
//    env->CallDoubleMethodA((jobject)(78), (jmethodID)(4), args);

    _Test();
//    env->SetBooleanArrayRegion(0, 0, 0, 0);
//    env->SetByteArrayRegion(0, 0, 0, 0);
//    env->SetCharArrayRegion(0, 0, 0, 0);
//    env->SetShortArrayRegion(0, 0, 0, 0);
//    env->SetIntArrayRegion(0, 0, 0, 0);
//    env->SetLongArrayRegion(0, 0, 0, 0);
//    env->SetFloatArrayRegion(0, 0, 0, 0);
//    env->SetDoubleArrayRegion(0, 0, 0, 0);

//    env->GetStaticMethodID(0, "dumpReferenceTables", "()V");

    __android_log_print(ANDROID_LOG_INFO, "demo", "%s end", __FUNCTION__);
}

extern "C"
JNIEXPORT void
JNICALL
Java_com_tencent_mobileqq_JniHookToolkit_MainActivity_nativeTestJniRefHooker
        (JNIEnv *env, jobject instance) {
    uint64_t i = 0;
    while(i++ < 2*1024){
        jobject localRef = env->NewLocalRef(instance);
        jobject globalRef = env->NewGlobalRef(localRef);
        jobject weakGlobalRef = env->NewWeakGlobalRef(localRef);

        env->DeleteLocalRef(localRef);
        env->DeleteGlobalRef(globalRef);
        env->DeleteWeakGlobalRef(weakGlobalRef);
        if (i % 1000 == 0){
            __android_log_print(ANDROID_LOG_INFO, "demo", "%s tick", __FUNCTION__);
        }
    }
}

jint JNI_OnLoad(JavaVM* vm, void* reserved)
{
    gVm = vm;
    return JNI_VERSION_1_4;
}
