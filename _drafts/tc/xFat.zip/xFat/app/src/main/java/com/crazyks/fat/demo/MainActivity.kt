package com.crazyks.fat.demo

import android.app.AlertDialog
import android.app.Dialog
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.crazyks.fat.BadAllocationCallback
import com.crazyks.fat.FastAllocationTracker
import com.crazyks.fat.StackInfoHelper
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.StringBuilder
import java.util.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Example of a call to a native method
        sample_text.text = FastAllocationTracker.stringFromJNI()
        switch_btn.setOnClickListener {
            val state = FastAllocationTracker.getAllocationTrackerState()
            FastAllocationTracker.setAllocationTrackerState(!state)
            if (FastAllocationTracker.getAllocationTrackerState()) {
                sample_text.text = "Fast Allocation Tracker is ON"
            } else {
                sample_text.text = "Fast Allocation Tracker is OFF"
            }
        }
        new_object_btn.setOnClickListener {
            object : Thread() {
                override fun run() {
                    for (i in 0 until 512) {
                        JavaBean()
                        sleep(10)
                    }
                }
            }.start()
        }
        new_array_btn.setOnClickListener {
            ByteArray(513 * 1024) {
                0xFF.toByte()
            }
        }

        StackInfoHelper.registerCallback(object : BadAllocationCallback {
            override fun onBadAllocationHappened(
                type: Int,
                period: Int,
                className: String?,
                stackTrace: String?,
                times: Int,
                byteCount: Int
            ) {
                Handler(Looper.getMainLooper()).post {
                    val msg = when (type) {
                        StackInfoHelper.BAD_ALLOC_SINGLE_TOO_LARGE -> "分配了一个大对象 $className\n size = $byteCount Bytes\n$stackTrace"
                        StackInfoHelper.BAD_ALLOC_TOO_LARGE -> "${period}秒内多次分配了大对象 $className\nsize = $byteCount Bytes\n$stackTrace"
                        StackInfoHelper.BAD_ALLOC_TOO_FREQUENT -> "${period}秒内分配了${times}次对象 $className\n$stackTrace"
                        else -> "未知错误"
                    }
                    AlertDialog.Builder(this@MainActivity).setMessage(msg).create().show()
                }
            }

        })
    }
}
