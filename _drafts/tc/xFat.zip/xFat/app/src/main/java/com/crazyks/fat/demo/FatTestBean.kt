package com.crazyks.fat.demo

/**
 * @author chriskzhou
 */
class FatTestBean: Any() {
    override fun toString(): String {
        return "this is a fat test bean ${hashCode()}"
    }
}