package com.crazyks.fat.demo

import android.app.Application
import android.content.Context

/**
 * @author chriskzhou
 */
class MyApplication : Application() {
    companion object {
        var gApp: Application? = null
    }

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        gApp = this
    }
}