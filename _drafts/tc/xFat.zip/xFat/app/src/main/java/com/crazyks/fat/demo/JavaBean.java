package com.crazyks.fat.demo;

/**
 * @author chriskzhou
 */
public class JavaBean {

    @Override
    public String toString() {
        return "This is a Java Bean " + hashCode();
    }
}
