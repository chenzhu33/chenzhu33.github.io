Fast Allocation Tracker(简称FAT)是一款Android平台上内存异常分配的实时监控工具。

### 1. 如何使用

```
修改build.gradle，增加 implementation 'com.tencent.xfat:lib:0.0.17-SNAPSHOT'
启动监控: FastAllocationTracker.setAllocationTrackerState(true);
停止监控: FastAllocationTracker.setAllocationTrackerState(false);
```

### 2. 版本支持

#### 2.1 支持系统版本
目前支持Android5.x - 9.x的内存分配实时统计和监控。

Android Q及以上，待补充。

#### 2.2 支持架构
目前支持Arm32架构。

### 3. 目录结构
```
xFat
 + app             # 一个简单的Demo，体验内存分配异常监控
 + lib             # FAT源码
 - build.gradle    # 构建脚本，版本号在此修改
 - maven.gradle    # 发布到Maven的脚本
 - README.md       # 本文档
```

### 4. 如何发布

目前发布到SNAPSHOT仓库，发布前注意，需要编辑build.gradle，修改版本号，然后按如下流程发布：
```
$cd <xFat project dir>
$./gradlew deployMaven
```

### 5. 原理简介

本监控方案基于inline hook技术，深入虚拟机源码，实时捕获内存分配事件。
