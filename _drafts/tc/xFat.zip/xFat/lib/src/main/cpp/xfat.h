#ifndef _XFAT_H
#define _XFAT_H

#include <jni.h>
#include <sys/system_properties.h>
#include <dlfcn.h>
#include <string>
#include <map>
#include <atomic>
#include <pthread.h>
#include "android_log.h"
#include "inlineHook.h"
#include "elfio.h"
#include "elfutils.h"

#define SDK_PROP_NAME "ro.build.version.sdk"
#define FAT_CLASS_NAME "com/crazyks/fat/FastAllocationTracker"
#define STACK_INFO_HELPER_CLASS_NAME "com/crazyks/fat/StackInfoHelper"
#define DUMP_STACK_METHOD_NAME "dumpStack"
#define DUMP_STACK_METHOD_SIGN "()Ljava/lang/String;"
#define GET_CLASS_NAME_METHOD_NAME "getClassName"
#define GET_CLASS_NAME_METHOD_SIGN "(Ljava/lang/Object;)Ljava/lang/String;"
#define CALLBACK_METHOD_NAME "onBadAllocationHappened"
#define CALLBACK_METHOD_SIGN "(IILjava/lang/String;Ljava/lang/String;II)V"
#define STRING_CLASS_NAME "java/lang/String"
#define STRING_CODE "utf-8"
#define STRING_GET_BYTES_METHOD_NAME "getBytes"
#define STRING_GET_BYTES_METHOD_SIGN "(Ljava/lang/String;)[B"
#define STRING_INIT_METHOD_NAME "<init>"
#define STRING_INIT_METHOD_SIGN "([BLjava/lang/String;)V"

#define BL_CHAR_ARRAY "[C"
#define BL_INT_ARRAY "[I"
#define BL_LONG_ARRAY "[J"

#define BL_JAVA_LANG "Ljava/lang/"
#define BL_JAVA_UTIL "Ljava/util/"
#define BL_KOTLIN "Lkotlin/"
#define BL_ANDROID "Landroid/"
#define BL_ANDROID_DEX "Lcom/android/dex/"
#define BL_ANDROID_INTERNAL "Lcom/android/internal/"

#define VM_ART "/system/lib/libart.so"

#define NELEM(x) ((int) (sizeof(x) / sizeof((x)[0])))
#define AS_THUMB(x) ((void *)((long) (x) | 0x1))

#define RECORDS_CHECK_PERIOD_IN_SEC (5)
#define LIMIT_SINGLE_BYTE_COUNT (512 * 1024)
#define LIMIT_ALLOCATION_TIMES_PER_SEC (30)
#define LIMIT_AVERAGE_BYTE_COUNT_PER_SEC (256 * 1024)
#define LIMIT_ALLOCATION_TIMES (LIMIT_ALLOCATION_TIMES_PER_SEC * RECORDS_CHECK_PERIOD_IN_SEC)
#define LIMIT_ALLOCATION_BYTE_COUNT (LIMIT_AVERAGE_BYTE_COUNT_PER_SEC * RECORDS_CHECK_PERIOD_IN_SEC)

#define BAD_ALLOC_SINGLE_TOO_LARGE 101
#define BAD_ALLOC_TOO_LARGE 102
#define BAD_ALLOC_TOO_FREQUENT 103

// const char* Class::GetDescriptor(std::string* storage)
#define SYM_CLASS_GET_DESCRIPTOR "_ZN3art6mirror5Class13GetDescriptorEPNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE"
// jobject JNIEnvExt::NewLocalRef(mirror::Object* obj)
#define SYM_NEW_LOCAL_REF "_ZN3art9JNIEnvExt11NewLocalRefEPNS_6mirror6ObjectE"
// void JNIEnvExt::DeleteLocalRef(jobject obj)
#define SYM_DELETE_LOCAL_REF "_ZN3art9JNIEnvExt14DeleteLocalRefEP8_jobject"

// static void Dbg::RecordAllocation(mirror::Class* type, size_t byte_count)
#define SYM_RECORD_ALLOCATION_API21_22 "_ZN3art3Dbg16RecordAllocationEPNS_6mirror5ClassEj"
// static void Dbg::RecordAllocation(Thread* self, mirror::Class* type, size_t byte_count)
#define SYM_RECORD_ALLOCATION_API23 "_ZN3art3Dbg16RecordAllocationEPNS_6ThreadEPNS_6mirror5ClassEj"
// void AllocRecordObjectMap::RecordAllocation(Thread* self, mirror::Object** obj, size_t byte_count)
#define SYM_RECORD_ALLOCATION_API24_25 "_ZN3art2gc20AllocRecordObjectMap16RecordAllocationEPNS_6ThreadEPPNS_6mirror6ObjectEj"
// void AllocRecordObjectMap::RecordAllocation(Thread* self, ObjPtr<mirror::Object>* obj, size_t byte_count)
#define SYM_RECORD_ALLOCATION_API26_28 "_ZN3art2gc20AllocRecordObjectMap16RecordAllocationEPNS_6ThreadEPNS_6ObjPtrINS_6mirror6ObjectEEEj"

// Only for test search function symbol by feature
static uint8_t FT_RECORD_ALLOCATION_API25[] = {0x2D, 0xE9, 0xF0, 0x4F, 0x9F, 0xB0, 0x81, 0x46};

static uint32_t MEM_LIMIT = 0xFFFFFFFF;
static uint32_t FT_SIZE = 8;
static uint32_t SEARCH_STEP = 4;

static const char *BLACK_LIST_ITEMS[] = {
        BL_JAVA_LANG,
        BL_JAVA_UTIL,
        BL_KOTLIN,
        BL_ANDROID,
        BL_ANDROID_DEX,
        BL_ANDROID_INTERNAL,
};

static pthread_rwlock_t rwlock = PTHREAD_RWLOCK_INITIALIZER;
static const bool DEFAULT_DUMP_CONTROL_FLAG = false;

static pthread_t allocation_check_thread = 0;

static std::atomic<size_t> malloc_cnt(0);
static std::atomic<size_t> free_cnt(0);

void *malloc2(size_t size) {
    malloc_cnt++;
    return malloc(size);
}

void free2(void *ptr) {
    free_cnt++;
    free(ptr);
}

class FakeObjPtr {
    static constexpr size_t kCookieShift = 0;
    static constexpr size_t kCookieBits = 0;
    static constexpr uintptr_t kCookieMask = 0;
public:
    void *Ptr() {
        return (void *) reference_;
    }

private:
    // The encoded reference and cookie.
    uintptr_t reference_;
};

class AllocRecord {
public:
    char *stack_trace = nullptr;
    char *class_name = nullptr;
    size_t times = 0;
    size_t total_byte_count = 0;
    size_t max_byte_count = 0;
    size_t min_byte_count = 0;

    ~AllocRecord() {
        if (stack_trace) free2(stack_trace);
        if (class_name) free2(class_name);
        stack_trace = nullptr;
        class_name = nullptr;
    }
};

struct HookPoint {
    void *originFunc;
    void *newFunc;
    void **oldFunc;
};

static HookPoint *pHookPoint = nullptr;

static JavaVM *jvm = nullptr;
static jclass stackInfoHelper = nullptr;
static jmethodID dumpStackMethod = nullptr;
static jmethodID getClassNameMethod = nullptr;
static jmethodID callbackMethod = nullptr;

static jclass stringClass = nullptr;
static jstring stringEncode = nullptr;
static jmethodID stringGetBytesMethod = nullptr;
static jmethodID stringInitMethod = nullptr;

static bool enable = false;

static std::map<pthread_t, bool> dumpCtrlFlags;

static std::map<unsigned, AllocRecord *> records;
static pthread_rwlock_t record_lock = PTHREAD_RWLOCK_INITIALIZER;

static inline char *createStringFromJString(JNIEnv *env, jstring jstr) {
    if (env == nullptr || jstr == nullptr) return nullptr;
    char *rtn = nullptr;
    jbyteArray barr = (jbyteArray) env->CallObjectMethod(jstr, stringGetBytesMethod, stringEncode);
    size_t alen = static_cast<size_t>(env->GetArrayLength(barr));
    jbyte *ba = env->GetByteArrayElements(barr, JNI_FALSE);
    if (alen > 0) {
        rtn = (char *) malloc2(alen + 1);
        memcpy(rtn, ba, alen);
        rtn[alen] = 0;
    }
    env->ReleaseByteArrayElements(barr, ba, 0);
    env->DeleteLocalRef(barr);
    return rtn;
}

static inline jstring createJStringFromString(JNIEnv *env, char *str) {
    if (env == nullptr || str == nullptr) return nullptr;
    size_t strLen = strlen(str);
    jbyteArray barr = env->NewByteArray(strLen);
    env->SetByteArrayRegion(barr, 0, strLen, (jbyte *) str);
    jstring ret = (jstring) env->NewObject(stringClass, stringInitMethod, barr, stringEncode);
    env->DeleteLocalRef(barr);
    return ret;
}

static inline bool getEnv(JNIEnv **pEnv) {
    JNIEnv *env = nullptr;
    jint ret = jvm->GetEnv((void **) &env, JNI_VERSION_1_6);
    bool needDetach = false;

    if (ret != JNI_OK) {
        if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) {
            *pEnv = nullptr;
            LOGE("jni env attach to current thread failed.");
        } else {
            *pEnv = env;
            LOGD("jni env attach to current thread success.");
            needDetach = true;
        }
    } else {
        *pEnv = env;
        LOGD("get jni env success.");
    }

    return needDetach;
}

static inline bool getDumpCtrlFlag(pthread_t tid) {
    bool flag = DEFAULT_DUMP_CONTROL_FLAG;
    pthread_rwlock_rdlock(&rwlock);
    if (dumpCtrlFlags.find(tid) != dumpCtrlFlags.end()) {
        flag = dumpCtrlFlags[tid];
    }
    pthread_rwlock_unlock(&rwlock);
    return flag;
}

static inline void putDumpCtrlFlag(pthread_t tid, bool flag) {
    pthread_rwlock_wrlock(&rwlock);
    dumpCtrlFlags[tid] = flag;
    pthread_rwlock_unlock(&rwlock);
}

static inline void onBadAllocationDetected(int type,
                                           uint32_t period,
                                           char *class_name,
                                           char *stack_trace,
                                           size_t times,
                                           size_t byte_count) {
    putDumpCtrlFlag(allocation_check_thread, true);
    JNIEnv *env = nullptr;
    bool needDetach = getEnv(&env);
    if (env == nullptr) return;

    jstring cn = createJStringFromString(env, class_name);
    jstring st = createJStringFromString(env, stack_trace);

    env->CallStaticVoidMethod(stackInfoHelper, callbackMethod,
                              (jint) type, (jint) period, cn, st,
                              (jint) times, (jint) byte_count);

    env->DeleteLocalRef(cn);
    env->DeleteLocalRef(st);

    if (needDetach) {
        jvm->DetachCurrentThread();
        LOGD("jni env detach from current thread success.");
    }
    putDumpCtrlFlag(allocation_check_thread, false);
}

static inline void analyseAndResetRecords() {
    pthread_rwlock_wrlock(&record_lock);
    std::map<unsigned, AllocRecord *> tmp(records);
    records.clear();
    pthread_rwlock_unlock(&record_lock);

    // 分析并清除tmp
    LOGD("start analysing allocation, record size = %d malloc=%d, free=%d", tmp.size(), malloc_cnt.__a_, free_cnt.__a_);
    std::map<unsigned, AllocRecord *>::iterator iter = tmp.begin();
    while (iter != tmp.end()) {
        AllocRecord *r = iter->second;
        if (r->total_byte_count >= LIMIT_ALLOCATION_BYTE_COUNT) {
            onBadAllocationDetected(BAD_ALLOC_TOO_LARGE, RECORDS_CHECK_PERIOD_IN_SEC,
                                    r->class_name, r->stack_trace, r->times, r->total_byte_count);
            LOGE("allocation too large in %d second(s)\nclass=%s\ntotal size=%d\ntimes=%d\nstack=%s",
                 RECORDS_CHECK_PERIOD_IN_SEC,
                 r->class_name, r->total_byte_count, r->times, r->stack_trace);
        }
        if (r->times >= LIMIT_ALLOCATION_TIMES) {
            onBadAllocationDetected(BAD_ALLOC_TOO_FREQUENT, RECORDS_CHECK_PERIOD_IN_SEC,
                                    r->class_name, r->stack_trace, r->times, r->total_byte_count);
            LOGE("allocation too frequent in %d second(s)\nclass=%s\ntotal size=%d\ntimes=%d\nstack=%s",
                 RECORDS_CHECK_PERIOD_IN_SEC,
                 r->class_name, r->total_byte_count, r->times, r->stack_trace);
        }
        delete r;
        iter->second = nullptr;
        iter = tmp.erase(iter);
    }
    tmp.clear();
    LOGD("finished analysing allocation.");
}

static inline char *dumpStack() {
    JNIEnv *env = nullptr;
    bool needDetach = getEnv(&env);
    if (env == nullptr) return nullptr;

    jstring stackInfo = (jstring) env->CallStaticObjectMethod(stackInfoHelper, dumpStackMethod);
    char *cStackInfo = createStringFromJString(env, stackInfo);
    env->DeleteLocalRef(stackInfo);

    if (needDetach) {
        jvm->DetachCurrentThread();
        LOGD("jni env detach from current thread success.");
    }
    return cStackInfo;
}

static inline void recordAllocation(char *class_name, size_t byte_count) {
    if (class_name == nullptr) {
        return;
    }
    unsigned key = elf_hash(class_name);
    char *name = class_name;
    char *stack = nullptr;
    pthread_rwlock_wrlock(&record_lock);
    if (records.find(key) != records.end()) {
        AllocRecord *ar = records[key];
        name = ar->class_name;
        free2(class_name);
        ar->times++;
        ar->total_byte_count += byte_count;
        ar->max_byte_count = std::max(byte_count, ar->max_byte_count);
        ar->min_byte_count = std::min(byte_count, ar->min_byte_count);
        if ((ar->times >= LIMIT_ALLOCATION_TIMES || ar->total_byte_count >= LIMIT_ALLOCATION_BYTE_COUNT) &&
            ar->stack_trace == nullptr) {
            ar->stack_trace = dumpStack();
        }
        stack = ar->stack_trace;
    } else {
        AllocRecord *ar = new AllocRecord();
        ar->class_name = class_name;
        ar->times = 1;
        ar->total_byte_count = byte_count;
        ar->max_byte_count = byte_count;
        ar->min_byte_count = byte_count;
        if (byte_count >= LIMIT_SINGLE_BYTE_COUNT) {
            ar->stack_trace = dumpStack();
        }
        name = ar->class_name;
        stack = ar->stack_trace;
        records[key] = ar;
    }
    LOGD("record size changes to %d", records.size());
    pthread_rwlock_unlock(&record_lock);

    if (byte_count >= LIMIT_SINGLE_BYTE_COUNT) {
        onBadAllocationDetected(BAD_ALLOC_SINGLE_TOO_LARGE, RECORDS_CHECK_PERIOD_IN_SEC,
                                class_name, stack, 1, byte_count);
        LOGE("record a large allocation %s\nsize=%d\nstack=%s", name, byte_count, stack);
    } else {
        LOGD("record an allocation %s\nsize=%d\nstack=%s", name, byte_count, stack);
    }
}

static const char *(*classGetDescriptor)(void *, std::string *) = nullptr;

static jobject (*newLocalRef)(void *env, void *obj) = nullptr;

static void (*deleteLocalRef)(void *env, jobject obj) = nullptr;

static void (*oldRecordAllocationApi21to22)(void *, size_t) = nullptr;

static void (*oldRecordAllocationApi23)(void *, void *, size_t) = nullptr;

static void (*oldRecordAllocationApi24to25)(void *, void *, void **, size_t) = nullptr;

static void (*oldRecordAllocationApi26to28)(void *, void *self, void *obj, size_t byte_count) = nullptr;

static char *copyClassName(const char *inStr) {
    if (inStr == nullptr) return nullptr;
    if (strcmp(BL_CHAR_ARRAY, inStr) == 0 ||
        strcmp(BL_INT_ARRAY, inStr) == 0 ||
        strcmp(BL_LONG_ARRAY, inStr) == 0) {
        return nullptr;
    }
    size_t clen = strlen(inStr);
    for (int i = 0; i < NELEM(BLACK_LIST_ITEMS); i++) {
        if (strncmp(BLACK_LIST_ITEMS[i], inStr, std::min(strlen(BLACK_LIST_ITEMS[i]), clen)) == 0 ||
            (inStr[0] == '[' &&
             strncmp(BLACK_LIST_ITEMS[i], inStr + 1, std::min(strlen(BLACK_LIST_ITEMS[i]), clen - 1)) == 0)) {
            return nullptr;
        }
    }
    size_t len = strlen(inStr);
    char *outStr = (char *) malloc2(len + 1);
    memcpy(outStr, inStr, len);
    outStr[len] = 0;
    return outStr;
}

static char *getClassNameFromObject(void *obj) {
    JNIEnv *env = nullptr;
    bool needDetach = getEnv(&env);
    if (env == nullptr) return nullptr;

    jobject ref = newLocalRef(env, obj);
    jstring className = (jstring) env->CallStaticObjectMethod(stackInfoHelper, getClassNameMethod, ref);
    char *descriptor = createStringFromJString(env, className);
    env->DeleteLocalRef(className);
    deleteLocalRef(env, ref);

    if (needDetach) {
        jvm->DetachCurrentThread();
        LOGD("jni env detach from current thread success.");
    }

    return descriptor;
}

static void inline recordFromClass(void *clazz, size_t byte_count) {
    pthread_t tid = pthread_self();
    if (enable && !getDumpCtrlFlag(tid)) {
        putDumpCtrlFlag(tid, true);
        std::string storage;
        char *descriptor = copyClassName(classGetDescriptor(clazz, &storage));
        recordAllocation(descriptor, byte_count);
        putDumpCtrlFlag(tid, false);
    }
}

static void inline recordFromObject(void *obj, size_t byte_count) {
    pthread_t tid = pthread_self();
    if (enable && !getDumpCtrlFlag(tid)) {
        putDumpCtrlFlag(tid, true);
        char *descriptor = getClassNameFromObject(obj);
        recordAllocation(descriptor, byte_count);
        putDumpCtrlFlag(tid, false);
    }
}

static void newRecordAllocationApi21to22(void *type, size_t byte_count) {
    recordFromClass(type, byte_count);
    oldRecordAllocationApi21to22(type, byte_count);
}

static void newRecordAllocationApi23(void *self, void *type, size_t byte_count) {
    recordFromClass(type, byte_count);
    oldRecordAllocationApi23(self, type, byte_count);
}

static void newRecordAllocationApi24to25(void *thiz, void *self, void **obj, size_t byte_count) {
    recordFromObject(*obj, byte_count);
    oldRecordAllocationApi24to25(thiz, self, obj, byte_count);
}

static void newRecordAllocationApi26to28(void *thiz, void *self, void *obj, size_t byte_count) {
    recordFromObject(((FakeObjPtr *) obj)->Ptr(), byte_count);
    oldRecordAllocationApi26to28(thiz, self, obj, byte_count);
}

static inline int getSdkVersion() {
    char value[32] = {0};
    int ret = __system_property_get(SDK_PROP_NAME, value);
    if (ret <= 0) {
        LOGE(("cannot get sdk version"));
        return -1;
    }
    int ver = atoi(value);
    LOGD("sdk version is %d", ver);
    return ver;
}

static inline void *searchModule(const char *moduleName) {
    if (moduleName == nullptr) return nullptr;
    FILE *fp;
    long addr = 0;
    char *pch;
    char filename[] = "/proc/self/maps";
    char line[1024];
    fp = fopen(filename, "re");
    if (fp != nullptr) {
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, moduleName)) {
                pch = strtok(line, "-");
                addr = strtoul(pch, nullptr, 16);
                break;
            }
        }
        fclose(fp);
    }
    return (void *) addr;
}

static inline void *searchSymByElf(const char *vm, const char *sym) {
    if (vm == nullptr || sym == nullptr) return nullptr;
    void *base = searchModule(vm);
    LOGD("search %s in lib [%s]@%p by parsing elf", sym, vm, base);
    if (base == nullptr) return nullptr;
    void *addr = nullptr;

    ElfHandle *handle = openElfByFile(vm);
    ElfInfo info;
    getElfInfoBySectionView(info, handle);
    Elf32_Sym *symb = nullptr;
    int symidx = 0;
    findSymByName(info, sym, &symb, &symidx);
    Elf32_Phdr *load = findPhdrByType(info, PT_LOAD);
    if (symb && load) {
        addr = (void *) ((uint32_t) base + (symb->st_value - load->p_vaddr));
    }

    closeElfByFile(handle);
    return addr;
}

static inline void *searchSymByFeature(const char *vm, const unsigned char *ft, bool thumb) {
    if (vm == nullptr || ft == nullptr) return nullptr;
    void *lib = searchModule(vm);
    LOGD("search lib [%s]@%p by feature", vm, lib);
    if (lib == nullptr) return nullptr;
    void *addr = nullptr;
    for (unsigned char *p = (unsigned char *) lib; (uint32_t) p < MEM_LIMIT; p += SEARCH_STEP) {
        if (memcmp(p, ft, FT_SIZE) == 0) {
            addr = p;
            if (thumb) addr = AS_THUMB(addr);
            break;
        }
    }
    return addr;
}

static inline void *findSym(const char *vm, const char *sym, const unsigned char *ft, bool thumb) {
    if (vm == nullptr || sym == nullptr) return nullptr;
    void *lib = dlopen(vm, RTLD_LAZY);
    void *addr = nullptr;
    if (lib) {
        LOGD("find lib [%s]@%p", vm, lib);
        addr = dlsym(lib, sym);
    }
    if (lib == nullptr || addr == nullptr) {
        LOGD("cannot find [%s] in lib [%s], try search by parsing elf", sym, vm);
        addr = searchSymByElf(vm, sym);
        if (addr == nullptr) {
            LOGD("cannot find [%s] in lib [%s], try search by feature", sym, vm);
            addr = searchSymByFeature(vm, ft, thumb);
        }
    }
    if (addr) {
        LOGD("find [%s] in [%s] addr=%p", sym, vm, addr);
    } else {
        LOGW("cannot find [%s] in [%s]", sym, vm);
    }
    return addr;
}

static inline bool doHook(HookPoint *h) {
    if (h == nullptr) return false;
    registerInlineHook((uint32_t) h->originFunc,
                       (uint32_t) h->newFunc,
                       (uint32_t **) h->oldFunc);
    return !(inlineHook((uint32_t) h->originFunc) != ELE7EN_OK);
}

static inline bool doUnHook(HookPoint *h) {
    if (h == nullptr) return false;
    return !(inlineUnHook((uint32_t) h->originFunc) != ELE7EN_OK);
}

static bool allowChecking = true;

static void signal_quit_handler(int /*signum*/) {
    LOGD("receive quit signal, quit allocation checking.");
    allowChecking = false;
}

static void *checkingThread(void */*arg*/) {
    signal(SIGQUIT, signal_quit_handler);
    while (allowChecking) {
        if (enable) {
            analyseAndResetRecords();
        }
        sleep(RECORDS_CHECK_PERIOD_IN_SEC);
    }
    return nullptr;
}

static inline void startCheckingThread() {
    pthread_t tid;
    if ((pthread_create(&tid, nullptr, checkingThread, nullptr)) < 0) {
        LOGE("start checking thread failed.");
    } else {
        allocation_check_thread = tid;
        LOGD("start checking thread success, tid = %ld", tid);
    }
}

static inline void stopCheckingThread() {
    if (allocation_check_thread > 0) {
        pthread_kill(allocation_check_thread, SIGQUIT);
        allocation_check_thread = 0;
    }
}

static inline void setupHookPoint(int sdkVersion) {
    // 工具函数
    *((void **) &classGetDescriptor) = findSym(VM_ART, SYM_CLASS_GET_DESCRIPTOR, nullptr, true);
    *((void **) &newLocalRef) = findSym(VM_ART, SYM_NEW_LOCAL_REF, nullptr, true);
    *((void **) &deleteLocalRef) = findSym(VM_ART, SYM_DELETE_LOCAL_REF, nullptr, true);

    // Hook目标函数
    void *originFunc = nullptr;
    void *newFunc = nullptr;
    void **oldFunc = nullptr;
    switch (sdkVersion) {
        case 21:
        case 22:
            originFunc = findSym(VM_ART, SYM_RECORD_ALLOCATION_API21_22, nullptr, true);
            newFunc = (void *) newRecordAllocationApi21to22;
            oldFunc = (void **) &oldRecordAllocationApi21to22;
            break;
        case 23:
            originFunc = findSym(VM_ART, SYM_RECORD_ALLOCATION_API23, nullptr, true);
            newFunc = (void *) newRecordAllocationApi23;
            oldFunc = (void **) &oldRecordAllocationApi23;
            break;
        case 24:
        case 25:
            originFunc = findSym(VM_ART, SYM_RECORD_ALLOCATION_API24_25, FT_RECORD_ALLOCATION_API25, true);
            newFunc = (void *) newRecordAllocationApi24to25;
            oldFunc = (void **) &oldRecordAllocationApi24to25;
            break;
        case 26:
        case 27:
        case 28:
            originFunc = findSym(VM_ART, SYM_RECORD_ALLOCATION_API26_28, nullptr, true);
            newFunc = (void *) newRecordAllocationApi26to28;
            oldFunc = (void **) &oldRecordAllocationApi26to28;
            break;
        default:
            break;
    }
    if (originFunc && newFunc && oldFunc) {
        LOGE("ready for hook @%p new func is %p, old func is %p", originFunc, newFunc, oldFunc);
        pHookPoint = new HookPoint();
        pHookPoint->originFunc = originFunc;
        pHookPoint->newFunc = newFunc;
        pHookPoint->oldFunc = oldFunc;
        doHook(pHookPoint);
    } else {
        LOGE("Api %d is Unsupport now.", sdkVersion);
    }
}

static inline void resetAllHookPoint() {
    if (pHookPoint) {
        doUnHook(pHookPoint);
    }
}

#endif
