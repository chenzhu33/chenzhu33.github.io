/*
 * elfio.cpp
 *
 *  Created on: 2014年10月8日
 *      Author: boyliang
 */

#include <stdio.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include "android_log.h"
#include "elfio.h"

ElfHandle *openElfByFile(const char *path) {
    void *base = nullptr;
    FILE *fd = fopen(path, "re");
    if (fd == nullptr) {
        LOGE("[-] open %s fails.\n", path);
        return nullptr;
    }

    fseek(fd, 0, SEEK_END);
    size_t size = (size_t) ftell(fd);

    base = malloc(size);
    if (base == nullptr) {
        LOGE("[-] read %s fails.\n", path);
        return nullptr;
    }

    fseek(fd, 0, SEEK_SET);
    fread(base, size, 1, fd);
    fclose(fd);

    ElfHandle *handle = (ElfHandle *) malloc(sizeof(ElfHandle));
    handle->base = base;
    handle->space_size = size;
    handle->fromfile = true;

    return handle;
}

void closeElfByFile(ElfHandle *handle) {
    if (handle) {
        if (handle->base && handle->space_size > 0) {
            free(handle->base);
            free(handle);
        }
    }
}

/**
 * 查找soname的基址，如果为NULL，则为当前进程基址
 */
static void *findLibBase(const char *soname) {
    FILE *fd = fopen("/proc/self/maps", "r");
    char line[256];
    void *base = 0;

    while (fgets(line, sizeof(line), fd) != NULL) {
        if (soname == NULL || strstr(line, soname)) {
            line[8] = '\0';
            base = (void *) strtoul(line, NULL, 16);
            break;
        }
    }

    fclose(fd);
    return base;
}

/**
 * 从给定的so中获取基址
 */
ElfHandle *openElfBySoname(const char *soname) {
    void *base = findLibBase(soname);
    if (!base) {
        LOGE("[-] could find %s. \n", soname);
        return nullptr;
    }

    ElfHandle *handle = (ElfHandle *) malloc(sizeof(ElfHandle));
    handle->base = base;
    handle->space_size = -1;
    handle->fromfile = false;

    return handle;
}

/**
 * 释放资源
 */
void closeElfBySoname(ElfHandle *handle) {
    //only free the base
    free(handle);
}

