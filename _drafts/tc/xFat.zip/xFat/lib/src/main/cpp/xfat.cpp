#include "xfat.h"

jstring stringFromJNI(JNIEnv *env, jobject /* this */) {
    std::string hello = "Hello xFat";
    return env->NewStringUTF(hello.c_str());
}

jboolean enableAllocRecord(JNIEnv */*env*/, jobject /* this */) {
    if (pHookPoint) {
        enable = true;
        return JNI_TRUE;
    } else {
        return JNI_FALSE;
    }
}

void disableAllocRecord(JNIEnv */*env*/, jobject /* this */) {
    enable = false;
}

static JNINativeMethod gMethods[] = {
        {"stringFromJNI",      "()Ljava/lang/String;", (void *) stringFromJNI},
        {"enableAllocRecord",  "()Z",                  (void *) enableAllocRecord},
        {"disableAllocRecord", "()V",                  (void *) disableAllocRecord}
};

JNIEXPORT int JNICALL JNI_OnLoad(JavaVM *vm, void */*reserved*/) {
    JNIEnv *env;
    if (vm->GetEnv((void **) &env, JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }

    jclass javaClass = env->FindClass(FAT_CLASS_NAME);
    if (javaClass == nullptr) {
        return JNI_ERR;
    }

    if (env->RegisterNatives(javaClass, gMethods, NELEM(gMethods)) < 0) {
        return JNI_ERR;
    }

    // 缓存JavaVM*
    jvm = vm;

    // 缓存String.getBytes
    jclass stringClazz = env->FindClass(STRING_CLASS_NAME);
    if (stringClazz) {
        jstring strencode = env->NewStringUTF(STRING_CODE);
        stringGetBytesMethod = env->GetMethodID(stringClazz,
                                                STRING_GET_BYTES_METHOD_NAME,
                                                STRING_GET_BYTES_METHOD_SIGN);
        stringInitMethod = env->GetMethodID(stringClazz,
                                            STRING_INIT_METHOD_NAME,
                                            STRING_INIT_METHOD_SIGN);
        stringEncode = (jstring) env->NewGlobalRef(strencode);
        stringClass = (jclass) env->NewGlobalRef(stringClazz);
        env->DeleteLocalRef(strencode);
        env->DeleteLocalRef(stringClazz);
    }

    // 缓存StackInfoHelper.dumpStack
    jclass stackInfoHelperClazz = env->FindClass(STACK_INFO_HELPER_CLASS_NAME);
    if (stackInfoHelperClazz) {
        dumpStackMethod = env->GetStaticMethodID(stackInfoHelperClazz, DUMP_STACK_METHOD_NAME, DUMP_STACK_METHOD_SIGN);
        getClassNameMethod = env->GetStaticMethodID(stackInfoHelperClazz, GET_CLASS_NAME_METHOD_NAME, GET_CLASS_NAME_METHOD_SIGN);
        callbackMethod = env->GetStaticMethodID(stackInfoHelperClazz, CALLBACK_METHOD_NAME, CALLBACK_METHOD_SIGN);
        stackInfoHelper = (jclass) env->NewGlobalRef(stackInfoHelperClazz);
        env->DeleteLocalRef(stackInfoHelperClazz);
    } else {
        LOGE("cannot find class %s", STACK_INFO_HELPER_CLASS_NAME);
    }
    if (dumpStackMethod == nullptr) {
        LOGE("cannot find method %s %s", DUMP_STACK_METHOD_NAME, DUMP_STACK_METHOD_SIGN);
    }
    if (getClassNameMethod == nullptr) {
        LOGE("cannot find method %s %s", GET_CLASS_NAME_METHOD_NAME, GET_CLASS_NAME_METHOD_SIGN);
    }

    // 开启守护线程
    startCheckingThread();

    // 注册Hook点
    setupHookPoint(getSdkVersion());

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL JNI_OnUnload(JavaVM * /*vm*/, void * /*reserved*/) {
    stopCheckingThread();
    resetAllHookPoint();
}
