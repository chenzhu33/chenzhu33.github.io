package com.crazyks.fat

import com.crazyks.fat.alloctracker.JavaAllocationTracker
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Fast Allocation Tracker
 * 快速内存分配跟踪器
 *
 * @author chriskzhou
 */
object FastAllocationTracker {
    init {
        System.loadLibrary("xfat")
    }

    private val state = AtomicBoolean(false)

    /**
     * enable or disable the allocation tracker
     * 开启或关闭内存分配跟踪器
     *
     * @param enable true - enable; false - disable.
     */
    @JvmStatic
    fun setAllocationTrackerState(enable: Boolean) {
        if (enable == state.get()) return
        if (enable) {
            JavaAllocationTracker.enableRecentAllocations(true)
            enableAllocRecord()
            state.set(true)
        } else {
            JavaAllocationTracker.enableRecentAllocations(false)
            disableAllocRecord()
            state.set(false)
        }
    }

    /**
     * get the state of the allocation tracker
     * 获取内存分配跟踪器的状态
     *
     * @return true - allocation tracker is enable; false - allocation tracker is disable.
     */
    @JvmStatic
    fun getAllocationTrackerState(): Boolean = state.get()

    /**
     * get all allocation records.
     * 获取所有记录的内存分配情况
     *
     * @return as description.
     */
    @JvmStatic
    fun getAllocationRecords(): Array<AllocationInfo> {
        TODO()
    }

    /**
     * register an allocation analyzer to detect the inappropriate allocation.
     * 注册内存分配分析器来检测不合理的内存分配
     *
     * @param analyzer the implementation of the AbstractAllocationAnalyzer
     */
    @JvmStatic
    fun registerAnalyzer(analyzer: AbstractAllocationAnalyzer) {
        TODO()
    }

    /**
     * unregister an allocation analyzer, it must be called if the analyzing job is finished.
     * 注销一个内存分配分析器，当停止分析时必须调用本接口来注销分析器。
     *
     * @param analyzer the implementation of the AbstractAllocationAnalyzer
     * @throws RuntimeException if the analyzer is not registered, unregister it will cause an RuntimeException.
     */
    @JvmStatic
    fun unregisterAnalyzer(analyzer: AbstractAllocationAnalyzer) {
        TODO()
    }

    external fun stringFromJNI(): String

    private external fun enableAllocRecord(): Boolean

    private external fun disableAllocRecord()
}