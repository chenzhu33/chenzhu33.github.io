package com.crazyks.fat

import android.support.annotation.Keep
import java.util.concurrent.CopyOnWriteArrayList

/**
 * @author chriskzhou
 */
@Keep
object StackInfoHelper {
    private const val IDX_START_OFFSET = 3

    private const val EMPTY_STRING = ""

    const val BAD_ALLOC_SINGLE_TOO_LARGE = 101
    const val BAD_ALLOC_TOO_LARGE = 102
    const val BAD_ALLOC_TOO_FREQUENT = 103

    private val callbacks = CopyOnWriteArrayList<BadAllocationCallback>()

    fun registerCallback(callback: BadAllocationCallback) {
        if (callbacks.contains(callback)) return
        callbacks.add(callback)
    }

    fun unregisterCallback(callback: BadAllocationCallback) {
        callbacks.remove(callback)
    }

    @JvmStatic
    @Keep
    fun dumpStack(): String {
        val sb = StringBuilder()
        val trace = Thread.currentThread().stackTrace
        if (trace.size < IDX_START_OFFSET) {
            return EMPTY_STRING
        }
        for (idx in IDX_START_OFFSET until trace.size) {
            trace[idx]?.let { st ->
                sb.append("#[${idx - IDX_START_OFFSET}] ${st.className}.${st.methodName}() @${st.fileName}(${st.lineNumber})\n")
            }
        }
        return sb.toString()
    }

    @JvmStatic
    @Keep
    fun getClassName(obj: Any): String {
        return obj.javaClass.name
    }

    /**
     * 不合理内存分配回调
     *
     * @param type 不合理分配类型
     * @param period 监控频率
     * @param className 类名
     * @param stackTrace 调用栈
     * @param times 分配次数
     * @param byteCount 字节数
     */
    @JvmStatic
    @Keep
    fun onBadAllocationHappened(
        type: Int,
        period: Int,
        className: String?,
        stackTrace: String?,
        times: Int,
        byteCount: Int
    ) {
        callbacks.forEach {
            it.onBadAllocationHappened(type, period, className, stackTrace, times, byteCount)
        }
    }
}
