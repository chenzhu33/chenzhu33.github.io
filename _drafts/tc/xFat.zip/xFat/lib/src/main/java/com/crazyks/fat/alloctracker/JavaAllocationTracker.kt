package com.crazyks.fat.alloctracker

import com.crazyks.fat.FATLog
import java.lang.reflect.Method
import java.nio.ByteBuffer

object JavaAllocationTracker {
    private const val TAG = "JavaAllocationTracker"

    private val isSupported: Boolean

    private var enableRecentAllocationsMethod: Method? = null
    private var getRecentAllocationStatusMethod: Method? = null
    private var getRecentAllocationsMethod: Method? = null

    private const val HEADER_SIZE = 15
    private val EMPTY_ARRAY = ByteArray(0)
    private val EMPTY_ALLOCATION = arrayOf<AllocationInfo>()

    init {
        isSupported = try {
            val c = Class.forName("org.apache.harmony.dalvik.ddmc.DdmVmInternal")
            enableRecentAllocationsMethod = c.getDeclaredMethod(
                "enableRecentAllocations",
                java.lang.Boolean.TYPE
            )
            getRecentAllocationStatusMethod = c.getDeclaredMethod("getRecentAllocationStatus")
            getRecentAllocationsMethod = c.getDeclaredMethod("getRecentAllocations")
            true
        } catch (e: Exception) {
            FATLog.e(TAG, "init allocation tracker failed.", e)
            false
        }
    }

    @JvmStatic
    fun isAllocationTrackerSupported() = isSupported

    @JvmStatic
    fun enableRecentAllocations(enable: Boolean) {
        try {
            enableRecentAllocationsMethod?.invoke(null, enable)
        } catch (tr: Throwable) {
            FATLog.e(TAG, "enable allocation tracker failed.", tr)
        }
    }

    @JvmStatic
    fun getRecentAllocationStatus(): Boolean {
        return try {
            getRecentAllocationStatusMethod?.invoke(null) as? Boolean ?: false
        } catch (tr: Throwable) {
            FATLog.e(TAG, "get allocation tracker status failed.", tr)
            false
        }
    }

    @JvmStatic
    fun getRecentAllocations(): Array<AllocationInfo> {
        FATLog.d(TAG, "#1. get recent allocations data")
        val allocationsData = getRecentAllocationsData()
        return if (allocationsData.size < HEADER_SIZE) {
            EMPTY_ALLOCATION
        } else {
            try {
                FATLog.d(TAG, "#2. start parse recent allocations")
                AllocationsParser.parse(ByteBuffer.wrap(allocationsData))
            } catch (tr: Throwable) {
                FATLog.e(TAG, "parse allocation data failed.", tr)
                EMPTY_ALLOCATION
            }
        }
    }

    private fun getRecentAllocationsData(): ByteArray {
        return try {
            getRecentAllocationsMethod?.invoke(null) as? ByteArray ?: EMPTY_ARRAY
        } catch (tr: Throwable) {
            FATLog.e(TAG, "get recent allocations failed.", tr)
            EMPTY_ARRAY
        }
    }
}