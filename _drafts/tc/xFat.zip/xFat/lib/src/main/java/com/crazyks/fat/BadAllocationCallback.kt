package com.crazyks.fat

/**
 * @author chriskzhou
 */
interface BadAllocationCallback {
    fun onBadAllocationHappened(
        type: Int,
        period: Int,
        className: String?,
        stackTrace: String?,
        times: Int,
        byteCount: Int
    )
}
