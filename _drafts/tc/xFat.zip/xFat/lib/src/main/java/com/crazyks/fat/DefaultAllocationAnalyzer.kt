package com.crazyks.fat

/**
 * the default implementation of the AbstractAllocationAnalyzer
 * 内存分配分析器的默认实现
 *
 * @author chriskzhou
 */
class DefaultAllocationAnalyzer(
    config: AllocationAnalyzerConfig,
    callback: OnAllocationWarningCallback
) : AbstractAllocationAnalyzer(callback) {
}