package com.crazyks.fat

/**
 * the information of an allocation
 * 内存分配信息
 *
 * @author chriskzhou
 */
class AllocationInfo {
}