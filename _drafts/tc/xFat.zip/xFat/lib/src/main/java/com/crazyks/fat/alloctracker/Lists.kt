package com.crazyks.fat.alloctracker

object Lists {

    @JvmStatic
    fun <E> newArrayListWithExpectedSize(estimatedSize: Int): ArrayList<E> =
            ArrayList(computeArrayListCapacity(estimatedSize))

    private fun computeArrayListCapacity(arraySize: Int): Int {
        // 判断是否小于0，小于0则抛出异常。
        checkNonnegative(arraySize, "arraySize")
        return l2iSaturatedCast(5L + arraySize.toLong() + (arraySize / 10).toLong())
    }

    private fun checkNonnegative(value: Int, name: String): Int = if (value < 0) {
        throw IllegalArgumentException("$name cannot be negative but was: $value")
    } else {
        value
    }

    private fun l2iSaturatedCast(input: Long): Int =
            input.coerceAtLeast(0).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
}