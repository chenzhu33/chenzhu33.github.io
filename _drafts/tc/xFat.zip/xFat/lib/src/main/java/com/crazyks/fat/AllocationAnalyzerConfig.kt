package com.crazyks.fat

/**
 * the config for the allocation analyzer.
 * 内存分配分析器的配置
 *
 * @author chriskzhou
 */
class AllocationAnalyzerConfig {
}