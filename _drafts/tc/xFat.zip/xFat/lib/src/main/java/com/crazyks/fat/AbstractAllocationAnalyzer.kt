package com.crazyks.fat

/**
 * the abstract allocation analyzer
 * 内存分配分析器的抽象实现
 *
 * @author chriskzhou
 */
abstract class AbstractAllocationAnalyzer(private val callback: OnAllocationWarningCallback) {

    interface OnAllocationWarningCallback {
    }
}