package com.crazyks.fat

import android.util.Log

object FATLog {

    @JvmStatic
    fun d(tag: String, msg: String) {
        Log.d(tag, msg)
    }

    @JvmStatic
    fun w(tag: String, msg: String) {
        Log.w(tag, msg)
    }

    @JvmStatic
    fun e(tag: String, msg: String, tr: Throwable? = null) {
        if (tr != null) {
            Log.e(tag, msg, tr)
        } else {
            Log.e(tag, msg)
        }
    }
}
