package com.tencent.qapmsdk.test.TestDBOperation;

import android.app.Application;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.persist.DBHandler;
import com.tencent.qapmsdk.persist.DBHelper;
import com.tencent.qapmsdk.reporter.ResultObject;
import com.tencent.qapmsdk.test.TestEnv;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.lang.reflect.Method;
import java.util.ArrayList;


@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestDeleteReportedData {
    private static final String TAG = "TestDeleteReportedData";
    private DBHandler db;
    private DBHelper dbHelper;
    private ArrayList<ResultObject> list = new ArrayList<>(); // 存放从db中取出的ResultObject

//    @Rule
//    public ActivityTestRule<MainActivity> mActivityRule = new ActivityTestRule<>(
//            MainActivity.class);

    @Test
    public void test_deleteReportedData() throws Exception {
        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();
        QAPM.setProperty(QAPM.PropertyKeyAppInstance, app);
        QAPM.setProperty(QAPM.PropertyKeyAppId, TestEnv.APP_ID).setProperty(QAPM.PropertyKeyAppVersion, "2.1").setProperty(QAPM.PropertyKeySymbolId, "e6ae1282-ceb8-4237-89bd-2d23d00a8e33");
        QAPM.setProperty(QAPM.PropertyKeyUserId, TestEnv.USER_ID);
        QAPM.beginScene(QAPM.SCENE_ALL, QAPM.ModeDBIO);
        Thread.sleep(10000); // 等待app完成所有测试
        JSONObject params = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("dbName", "mySQL");
        data.put("dbIsWork", "true");
        params.put("dbStatus", data);
        ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, String.valueOf(1983559851));
//        Context context = mActivityRule.getActivity().getBaseContext();
//        Assert.assertNotNull(context);
        db = DBHandler.getInstance(app);
        Assert.assertNotNull(db);
        db.open(); // 打开数据库
        db.clearResultObjects();
        //获取数据库中的数据
        list = (ArrayList<ResultObject>) db.getAllResultObjects(PhoneUtil.getProcessName(Magnifier.sApp), Magnifier.productId, Magnifier.token, true); // 获取上报数据
        Assert.assertTrue(list.isEmpty()); // 此时数据库应该为空

        // 往数据库插入数据
        db.insertResultObject(ro, PhoneUtil.getProcessName(Magnifier.sApp),Magnifier.productId,Magnifier.token);
        Thread.sleep(500);
        list = (ArrayList<ResultObject>) db.getAllResultObjects(PhoneUtil.getProcessName(Magnifier.sApp), Magnifier.productId, Magnifier.token, true); // 获取上报数据
        Assert.assertEquals(1, list.size()); // 此时数据库中应该有一条数据

        Method method = db.getClass().getDeclaredMethod("delete", String.class, String.class, String[].class);
        method.setAccessible(true);
        method.invoke(db,DBHelper.TABLE_RESULT_OBJECTS,"_id=?", new String[] {String.valueOf(list.get(0).dbId)});

        list = (ArrayList<ResultObject>) db.getAllResultObjects(PhoneUtil.getProcessName(Magnifier.sApp), Magnifier.productId, Magnifier.token, true); // 获取上报数据

        Assert.assertTrue(list.isEmpty()); // 此时数据库应该为空
        Thread.sleep(2000);
        db.close();
    }
}

