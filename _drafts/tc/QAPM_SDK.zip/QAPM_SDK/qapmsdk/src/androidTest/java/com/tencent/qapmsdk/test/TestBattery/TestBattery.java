package com.tencent.qapmsdk.test.TestBattery;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

import com.tencent.qapmsdk.battery.BatteryStatsImpl;
import com.tencent.qapmsdk.common.ProcessStats;

import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestBattery {

    private static String TAG = "TestBattery";

    @Test
    public void test_BatteryMemoryCost() throws Exception{

        Runtime.getRuntime().gc();
        Thread.sleep(10000);

        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

        BatteryStatsImpl.getInstance().start();

        Thread.sleep(10000);

        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));

    }

    @Test
    public void test_BatteryCPUCost() throws Exception{

        long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("bettery monitor use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));

        BatteryStatsImpl.getInstance().start();

        Thread.sleep(10000);

        appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("bettery monitor use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));
    }

    @Test
    public void test_BatteryCollectCost() throws Exception{
        Runtime.getRuntime().gc();
        Thread.sleep(10000);
        long appUsage1 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage1 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("bettery monitor use cpu:%d",appUsage1));
        Log.i(TAG,String.format("device use cpu:%d",devUsage1));
        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));
        for (int i=0;i<50;i++){
            LogD(TAG,"测试LOG");
        }
        long useMemory1 = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before1 memory %d b",useMemory1));

        long appUsage2 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage2 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("bettery monitor use cpu:%d",appUsage2));
        Log.i(TAG,String.format("device use cpu:%d",devUsage2));
        BatteryStatsImpl.getInstance().start();
        Thread.sleep(10000);

        for (int i=0;i<50;i++){
            LogD(TAG,"测试LOG");
        }

        long useMemory2 = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before1 memory %d b",useMemory2));
        long appUsage3 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage3 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("bettery monitor use cpu:%d",appUsage3));
        Log.i(TAG,String.format("device use cpu:%d",devUsage3));

    }

    public void LogD(String ...args){
        if (args.length==0)
            return;
        String tag = args[0];
        if (tag == null || args.length<=1) return;
        StringBuilder logS = new StringBuilder(256);
        for (int i = 1; i < args.length; i++) {
            logS.append(args[i]);
        }
        String msg = logS.toString();
        BatteryStatsImpl.getInstance().onWriteLog(tag, msg);
//        Log.d(tag, msg);
    }

}
