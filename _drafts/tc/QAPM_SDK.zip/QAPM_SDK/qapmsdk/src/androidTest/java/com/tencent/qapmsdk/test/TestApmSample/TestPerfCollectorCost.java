package com.tencent.qapmsdk.test.TestApmSample;

import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.common.ProcessStats;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.sample.PerfCollector;
import com.tencent.qapmsdk.test.TestEnv;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestPerfCollectorCost {
    private static final String TAG = "TestPerfCollectorCost";

    @Test
    public void test_PerfCollectorMemoryCost() throws Exception{

        Magnifier.info.appId = TestEnv.APP_ID;
        QAPM.setProperty(QAPM.PropertyKeyAppInstance, InstrumentationRegistry.getTargetContext().getApplicationContext());
        Class<?> m = Magnifier.class;
        Method initCore = m.getDeclaredMethod("initCore",String.class);
        initCore.setAccessible(true);
        Boolean ret = (Boolean)initCore.invoke(null,Magnifier.info.appId);
        Assert.assertTrue(ret);
        Class<?> Config = Class.forName("com.tencent.qapmsdk.config.Config");
        Assert.assertNotNull(Config);
        Field STARTED_FUNC = Config.getDeclaredField("STARTED_FUNC");
        Assert.assertNotNull(STARTED_FUNC);
        STARTED_FUNC.setAccessible(true);
        STARTED_FUNC.setInt(null,64);
        Field RES_TYPE = Config.getDeclaredField("RES_TYPE");
        Assert.assertNotNull(RES_TYPE);
        RES_TYPE.setAccessible(true);
        RES_TYPE.setInt(null,3);
        Method init = CollectStatus.class.getDeclaredMethod("init");
        Assert.assertNotNull(init);
        init.setAccessible(true);
        init.invoke(null);

        Runtime.getRuntime().gc();
        Thread.sleep(10000);
        long useMemory1 = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory1));
//        QAPM.Config.STARTED_FUNC

        PerfCollector.getInstance().startGlobalMonitor("default");

        Thread.sleep(10000);
        long useMemory2 = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("satrt PerfCollector after memory %d b",useMemory2));
        Log.i(TAG,String.format("satrt PerfCollector cost memory %d b",useMemory2 - useMemory1));
    }

    @Test
    public void test_PerfCollectorCPUCost() throws Exception{

        Magnifier.info.appId = TestEnv.APP_ID;
        QAPM.setProperty(QAPM.PropertyKeyAppInstance, InstrumentationRegistry.getTargetContext().getApplicationContext());
        Class<?> m = Magnifier.class;
        Method initCore = m.getDeclaredMethod("initCore",String.class);
        initCore.setAccessible(true);
        Boolean ret = (Boolean)initCore.invoke(null,Magnifier.info.appId);
        Assert.assertTrue(ret);
        Class<?> Config = Class.forName("com.tencent.qapmsdk.config.Config");
        Assert.assertNotNull(Config);
        Field STARTED_FUNC = Config.getDeclaredField("STARTED_FUNC");
        Assert.assertNotNull(STARTED_FUNC);
        STARTED_FUNC.setAccessible(true);
        STARTED_FUNC.setInt(null,64);

        Field RES_TYPE = Config.getDeclaredField("RES_TYPE");
        Assert.assertNotNull(RES_TYPE);
        RES_TYPE.setAccessible(true);
        RES_TYPE.setInt(null,3);

        Method init = CollectStatus.class.getDeclaredMethod("init");
        Assert.assertNotNull(init);
        init.setAccessible(true);
        init.invoke(null);

        long appUsage1 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage1 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("before start dropFrame use cpu:%d",appUsage1));
        Log.i(TAG,String.format("device use cpu:%d",devUsage1));


        PerfCollector.getInstance().startGlobalMonitor("default");

        Thread.sleep(10000);
        long appUsage2 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage2 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("after start PerfCollector use cpu:%d",appUsage2));
        Log.i(TAG,String.format("device use cpu:%d",devUsage2));
        Log.i(TAG,String.format("start PerfCollector use cpu:%f",(float)(appUsage2-appUsage1)/(float)(devUsage2-devUsage1)*100));

    }
}
