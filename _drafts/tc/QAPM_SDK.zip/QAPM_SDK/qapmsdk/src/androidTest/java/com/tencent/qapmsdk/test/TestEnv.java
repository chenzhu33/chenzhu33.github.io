package com.tencent.qapmsdk.test;

public class TestEnv {
    public static String APP_ID = "33e15431-1024";
    public static String USER_ID = "11223344";
    public static String HOST =  "ten.sngapm.qq.com";
}
