package com.tencent.qapmsdk.test.TestJavaMethodHook;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;

import com.tencent.qapmsdk.io.util.JavaMethodHook;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.lang.reflect.Field;
import java.lang.reflect.Method;


@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestFindFieldBeFound {
    private static final String TAG = "TestFindFieldBeFound";
    private double memberVariable = 0.5; // 待测试的成员变量
    private Field res = null;

    @Test
    public void test_findFieldBeFound() throws Exception {


        Method method = JavaMethodHook.class.getDeclaredMethod("initHook");
        method.setAccessible(true);
        boolean isInit = (boolean) method.invoke(JavaMethodHook.class);

        Method method1 = JavaMethodHook.class.getDeclaredMethod("findField", Class.class, String.class);
        method1.setAccessible(true);
        res = (Field) method1.invoke(JavaMethodHook.class,this.getClass(),"memberVariable");

        Assert.assertNotNull(res);
    }
}

