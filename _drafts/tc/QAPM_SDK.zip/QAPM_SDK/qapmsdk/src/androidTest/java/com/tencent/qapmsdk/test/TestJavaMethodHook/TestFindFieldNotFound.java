package com.tencent.qapmsdk.test.TestJavaMethodHook;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;

import com.tencent.qapmsdk.io.util.JavaMethodHook;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;


@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestFindFieldNotFound {
    private static final String TAG = "TestFindFieldNotFound";
    private double memberVariable = 0.5; // 待测试的成员变量
    private Field res = null;

    @Test
    public void test_findFieldNotFound() {
        try {
            Method method = JavaMethodHook.class.getDeclaredMethod("initHook");
            method.setAccessible(true);
            boolean isInit = (boolean) method.invoke(JavaMethodHook.class);

            // 寻找一个不存在的成员变量，抛异常
            Method method1 = JavaMethodHook.class.getDeclaredMethod("findField", Class.class, String.class);
            method1.setAccessible(true);
            res = (Field) method1.invoke(JavaMethodHook.class,this.getClass(),"notFoundVariable");

        } catch (NoSuchFieldError e) {
            Assert.assertNull(res); // 捕获异常，此时res == null
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}

