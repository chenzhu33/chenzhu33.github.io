package com.tencent.qapmsdk.test;

import android.app.Application;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;

import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.reporter.ResultObject;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;


@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestReportJsonToQCloud {
    private static final String TAG = "TestReport";

    @Before
    public void setUp() {
        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();
        QAPM.setProperty(QAPM.PropertyKeyAppInstance, app);
        QAPM.setProperty(QAPM.PropertyKeyAppId, TestEnv.APP_ID).setProperty(QAPM.PropertyKeyAppVersion, "2.1").setProperty(QAPM.PropertyKeySymbolId, "e6ae1282-ceb8-4237-89bd-2d23d00a8e33");
        QAPM.setProperty(QAPM.PropertyKeyUserId, TestEnv.USER_ID).setProperty(QAPM.PropertyKeyLogLevel, QAPM.LevelDebug);
        QAPM.setProperty(QAPM.PropertyKeyEventCon, true);
        QAPM.setProperty(QAPM.PropertyKeyHost, TestEnv.HOST);
    }

    @Test
    public void test_uploadFilePathToQCloud() throws Exception{
        JSONObject params = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("fileObj1", "/sdcard/MagnifierSDK/"); // 传入目录
        JSONObject clientInfo = new JSONObject();
        clientInfo.put("plugin", String.valueOf(Config.PLUGIN_QCLOUD_FILE_IO));
        params.put("fileObj", data);
        params.put("clientinfo", clientInfo);
        ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, String.valueOf(1983559851));
        ReporterMachine.addCacheObj(ro);



    }

    @Test
    public void test_uploadFileToQCloud() throws Exception {
        JSONObject params = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("fileObj1", "/sdcard/MagnifierSDK/2016-06-03_15.06.54.523=com.tencent.qqlive@5@AndroidQQActivityLeak_LogData_MatchedLog[4.9.0.10278].finish.zip");
        JSONObject clientInfo = new JSONObject();
        clientInfo.put("plugin", String.valueOf(Config.PLUGIN_QCLOUD_FILE_IO));
        params.put("fileObj", data);
        params.put("clientinfo", clientInfo);
        ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, String.valueOf(1983559851));
        ReporterMachine.addCacheObj(ro);
    }

    @Test
    public void test_reportJsonToQCloud() throws Exception {

        JSONObject params = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("actTAG", "actFPSRecent");
        data.put("frameCount", "10");
        data.put("diffTime", "1000");
        data.put("fps", "10");
        data.put("extraInfo", "7");

        JSONObject clientInfo = new JSONObject();

        clientInfo.put("p_id", "4");
        clientInfo.put("versionname", "6.3.0.0");
        clientInfo.put("uin", "45242");
        clientInfo.put("model", "iPhone6.2");
        params.put("fpsCalculator", data);
        params.put("plugin", String.valueOf(Config.PLUGIN_QCLOUD_FILE_IO));
        params.put("clientinfo", clientInfo);
        ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, String.valueOf(1983559851));

        ReporterMachine rm = ReporterMachine.getInstance();
        rm.addCacheObj(ro);
        rm.startCacheReportAtOnce();
    }
}
