package com.tencent.qapmsdk.test.TestDBOperation;

import android.app.Application;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

import com.tencent.qapmsdk.common.ProcessStats;
import com.tencent.qapmsdk.io.IOMonitor;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestFileIOMonitor {

    private static final String TAG = "TestFileIOMonitor";
    @Test
    public void test_fileIoMoniterMemoryCost() throws Exception {

        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();

        Runtime.getRuntime().gc();
        Thread.sleep(10000);

        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

        IOMonitor ioMonitor = new IOMonitor(app,1,"2.3");
        ioMonitor.start();

        Thread.sleep(10000);

        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));
    }


    @Test
    public void test_fileIoMoniterCPUCost() throws Exception {

        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();

        long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("ioMonitor use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));

        IOMonitor ioMonitor = new IOMonitor(app,1,"2.3");
        ioMonitor.start();

        Thread.sleep(10000);

        appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("ioMonitor use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));
    }

    @Test
    public void test_fileIoMoniterCollectCost() throws Exception {
        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();
        Runtime.getRuntime().gc();
        Thread.sleep(10000);
        long appUsage1 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage1 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("dbMonitor use cpu:%d",appUsage1));
        Log.i(TAG,String.format("device use cpu:%d",devUsage1));
        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

        FileTest();

        Thread.sleep(2000);
        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before1 memory %d b",useMemory));

        long appUsage2 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage2 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("dbMonitor use cpu:%d",appUsage2));
        Log.i(TAG,String.format("device use cpu:%d",devUsage2));

        IOMonitor ioMonitor = new IOMonitor(app,1,"2.3");
        ioMonitor.start();

        Thread.sleep(10000);
        FileTest();
        Thread.sleep(2000);
        long appUsage3 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage3 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));

        Log.i(TAG,String.format("dbMonitor use cpu:%d",appUsage3));
        Log.i(TAG,String.format("device use cpu:%d",devUsage3));
    }


    public void FileTest() {
        File filep;
        File filedir;
        String testFile = "testFile.txt";

        String filePath = InstrumentationRegistry.getTargetContext().getApplicationContext().getFilesDir().getAbsolutePath();
        filedir = new File(filePath);
        if (!filedir.exists()) {
            filedir.mkdir();
        }
        try {
            filep=new File(filedir+"/"+testFile);
            if (!filep.exists()) {
                try {
                    filep.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            String str = "我在测试文件I/O呀！！！我在测试文件I/O呀！！！我在测试文件I/O呀！！！";
            byte bt[] = new byte[1024];
            bt = str.getBytes();
            for(int i = 0; i < 500; i++)
            {
                try {
                    FileOutputStream in = new FileOutputStream(filep);
                    in.write(bt, 0, bt.length);
                    in.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}