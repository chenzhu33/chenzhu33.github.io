package com.tencent.qapmsdk.test.TestJavaMethodHook;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;

import com.tencent.qapmsdk.io.util.JavaMethodHook;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;


@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestGetIntFieldBeFound {
    private static final String TAG = "TestGetIntFieldBeFound";
    private int memberVariable = 0; // 待测试的成员变量
    private double nonIntVariable = 0.5; // 非int类型的成员变量
    private int res = -1;

    @Test
    public void test_01_getIntFieldBeFound() throws Exception {
        Method method = JavaMethodHook.class.getDeclaredMethod("initHook");
        method.setAccessible(true);
        boolean isInit = (boolean) method.invoke(JavaMethodHook.class);

        Method method1 = JavaMethodHook.class.getDeclaredMethod("getIntField", Object.class, String.class);
        method1.setAccessible(true);
        res = (int) method1.invoke(JavaMethodHook.class,this,"memberVariable");
        Assert.assertEquals(0, res);
    }

    @Test
    public void test_02_getNonIntegerField() {
        // 尝试获取非int类型的变量
        res = -1;
        try {
            Method method = JavaMethodHook.class.getDeclaredMethod("initHook");
            method.setAccessible(true);
            boolean isInit = (boolean) method.invoke(JavaMethodHook.class);
            // 寻找一个非int类型的成员变量，抛异常
            Method method1 = JavaMethodHook.class.getDeclaredMethod("getIntField", Object.class, String.class);
            method1.setAccessible(true);
            res = (int) method1.invoke(JavaMethodHook.class,this,"nonIntVariable");

        } catch (IllegalArgumentException e) {
            Assert.assertEquals(-1, res); // 未获取到int值，res仍为 -1
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}


