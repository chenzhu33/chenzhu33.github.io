package com.tencent.qapmsdk.test.TestMemoryCelling;


import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

import com.tencent.qapmsdk.common.ProcessStats;
import com.tencent.qapmsdk.memory.DumpMemInfoHandler;
import com.tencent.qapmsdk.memory.MemoryMonitor;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.List;

@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestMemoryCell {
    private static final String TAG = "TestMemoryCell";


    @Test
    public void test_MemoryCellingMemoryCost() throws Exception{

        Runtime.getRuntime().gc();
        Thread.sleep(10000);

        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

        MemoryMonitor.initCelling(new MemoryMonitor.MemoryCellingListener() {
            @Override
            public void onBeforeUploadJson() {
//                   上传额外自定义字段 测试OK
//                    MemoryDumpHelper.getInstance().setExtraInfo("testname", "looklukelu");
            }

            @Override
            public List<String> onBeforeDump(final String dgst) {
                ArrayList<String> files = new ArrayList<String>();
                Object result[] = DumpMemInfoHandler.generateHprof(dgst);
                boolean success = (Boolean) result[0];
                if (success && null != result[1]) {
                    files.add((String) result[1]);
                } else {
                    Log.i(TAG, "failed dump memory");
                }
                return files;
            }

            /**
             * dump完成，可以把菊花dismiss掉了
             */
            @Override
            public void onAfterDump() {
            }
        });
        MemoryMonitor.getInstance().start();

        Thread.sleep(10000);

        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));
    }


    @Test
    public void test_memoryCellingCPUCost() throws Exception{

        long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("memoryleak use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));

        MemoryMonitor.initCelling(new MemoryMonitor.MemoryCellingListener() {
            @Override
            public void onBeforeUploadJson() {
//                   上传额外自定义字段 测试OK
//                    MemoryDumpHelper.getInstance().setExtraInfo("testname", "looklukelu");
            }

            @Override
            public List<String> onBeforeDump(final String dgst) {
                ArrayList<String> files = new ArrayList<String>();
                Object result[] = DumpMemInfoHandler.generateHprof(dgst);
                boolean success = (Boolean) result[0];
                if (success && null != result[1]) {
                    files.add((String) result[1]);
                } else {
                    Log.i(TAG, "failed dump memory");
                }
                return files;
            }

            /**
             * dump完成，可以把菊花dismiss掉了
             */
            @Override
            public void onAfterDump() {
            }
        });
        MemoryMonitor.getInstance().start();

        Thread.sleep(10000);

        appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("memorycelling use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));
    }

}
