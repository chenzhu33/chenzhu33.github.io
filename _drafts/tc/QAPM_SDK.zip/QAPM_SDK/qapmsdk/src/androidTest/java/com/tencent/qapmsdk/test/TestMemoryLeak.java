package com.tencent.qapmsdk.test;

import android.app.Application;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ProcessStats;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.lang.reflect.Method;

@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestMemoryLeak {
    private static final String TAG = "TestMemoryLeak";

    @Test
    public void test_MemoryLeakMemoryCost() throws Exception {

        Runtime.getRuntime().gc();
        Thread.sleep(10000);
        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();
        Class<?> c = Magnifier.class;
        Method inspectMemoryLeak = c.getDeclaredMethod("inspectMemoryLeak",Application.class);
        Assert.assertNotNull(inspectMemoryLeak);
        inspectMemoryLeak.setAccessible(true);
        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

        inspectMemoryLeak.invoke(null,app);

        Thread.sleep(10000);

        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));
    }


    @Test
    public void test_MemoryLeakCPUCost() throws Exception {


        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();
        Class<?> c = Magnifier.class;
        Method inspectMemoryLeak = c.getDeclaredMethod("inspectMemoryLeak",Application.class);
        Assert.assertNotNull(inspectMemoryLeak);
        inspectMemoryLeak.setAccessible(true);
        long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("memoryleak use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));

        inspectMemoryLeak.invoke(null,app);

        Thread.sleep(10000);
        appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("memoryleak use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));
    }

}
