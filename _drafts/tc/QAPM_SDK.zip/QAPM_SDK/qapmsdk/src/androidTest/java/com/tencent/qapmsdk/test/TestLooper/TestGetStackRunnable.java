package com.tencent.qapmsdk.test.TestLooper;

import android.os.Looper;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

import com.tencent.qapmsdk.common.ProcessStats;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestGetStackRunnable {

    private static String TAG = "TestGetStackRunnable";

    @Test
    public void test_getStackRunnable() throws Exception{

        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

        Class<?> GetStackRunnable = Class.forName("com.tencent.qapmsdk.looper.GetStackRunnable");
        Assert.assertNotNull(GetStackRunnable);
        Constructor<?> constructor = GetStackRunnable.getDeclaredConstructor(Thread.class);
        Assert.assertNotNull(constructor);
        constructor.setAccessible(true);
        Thread thread = Looper.getMainLooper().getThread();
        Object runnable = constructor.newInstance(thread);
        Method getStack = GetStackRunnable.getDeclaredMethod("getStack", boolean.class);
        getStack.setAccessible(true);

        Thread getStackThread = new Thread((Runnable) runnable, "get-stack-" + thread.getName());
        getStackThread.start();
        String stack = (String) getStack.invoke(runnable,true);
        Assert.assertNotNull(stack);

        Thread.sleep(5000);
        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));

    }


    @Test
    public void test_getStackRunnableCPUCost() throws Exception{

        long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("memoryleak use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));

        Class<?> GetStackRunnable = Class.forName("com.tencent.qapmsdk.looper.GetStackRunnable");
        Assert.assertNotNull(GetStackRunnable);
        Constructor<?> constructor = GetStackRunnable.getDeclaredConstructor(Thread.class);
        Assert.assertNotNull(constructor);
        constructor.setAccessible(true);
        Thread thread = Looper.getMainLooper().getThread();
        Object runnable = constructor.newInstance(thread);
        Method getStack = GetStackRunnable.getDeclaredMethod("getStack", boolean.class);
        getStack.setAccessible(true);

        Thread getStackThread = new Thread((Runnable) runnable, "get-stack-" + thread.getName());
        getStackThread.start();
        String stack = (String) getStack.invoke(runnable,true);
        Assert.assertNotNull(stack);

        Thread.sleep(5000);

        appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("memoryleak use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));
    }
}
