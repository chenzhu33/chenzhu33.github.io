package com.tencent.qapmsdk.test.TestApmSample;

import android.support.test.InstrumentationRegistry;

import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.sample.PerfCollector;
import com.tencent.qapmsdk.sample.PerfItem;
import com.tencent.qapmsdk.sample.TagItem;
import com.tencent.qapmsdk.test.TestEnv;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;
import java.util.concurrent.ConcurrentHashMap;

import static com.tencent.qapmsdk.test.TestApmSample.TestPerfCollectorStart.getRandomString;


/**
 * Created by felixliwang on 2018/5/30.
 */

public class TestPerfCollectorStop {
    private static final String TAG = "TestPerfCollectorStart";

    private PerfCollector perfCollector = null;

    private String ACTIVITYSTART = "ACTIVITYSTART";
    private String APPLAUNCH = "APPLAUNCH";
    private String regex = "^(?=.*\\\\d)(?=.*[a-z])(?=.*[A-Z]).{8,10}$";
    private String js = "<script>alert(“Attack!”)</script>";
    private String sql = "select distinct st.sno, sname from student st join sc sc on (st.sno = sc.sno) where sc.cno in (select cno from sc where sno = 's001') and sc.sno<>'s001'";


    @Before
    public void setUp() {

        QAPM.setProperty(QAPM.PropertyKeyAppInstance, InstrumentationRegistry.getTargetContext().getApplicationContext());
        QAPM.setProperty(QAPM.PropertyKeyAppId, TestEnv.APP_ID).setProperty(QAPM.PropertyKeyAppVersion, "2.1").setProperty(QAPM.PropertyKeySymbolId, "e6ae1282-ceb8-4237-89bd-2d23d00a8e33");
        QAPM.setProperty(QAPM.PropertyKeyUserId, TestEnv.USER_ID);
        QAPM.setProperty(QAPM.PropertyKeyHost, TestEnv.HOST);
        Config.loadConfigs();

    }

    @Test      //正常参数
    public void test_01_PerfCollectorStop_scene() throws Exception {

        String scene = "aaa";
        String extraInfo = "bbb";
        String uni_scene= scene + extraInfo;

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, TagItem> tagInfoCache = (ConcurrentHashMap<String, TagItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(scene,extraInfo);
        Assert.assertTrue(tagInfoCache.size()==1);
        TagItem startPerfItem = tagInfoCache.get(uni_scene);
        Assert.assertNotNull(startPerfItem);

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(scene,extraInfo);
//        Field f1 = perfCollector.getClass().getDeclaredField("collectorHandler");
//        f1.setAccessible(true);
//        Handler handler = (Handler) f1.get(perfCollector);
//        Assert.assertTrue(cr.mCollectCount==1);


    }






    @Test   //stage is null
    public void test_02_PerfCollectorStop_sceneIsNullObject() throws Exception {

        String scene = null;
        String extraInfo = "";

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(scene,extraInfo);
        Assert.assertTrue(tagInfoCache.size()==0);

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(scene,extraInfo);
        Assert.assertTrue(cr.mCollectCount==0);

    }

    @Test   //stage is ""
    public void test_03_PerfCollectorStop_sceneIsNullString() throws Exception {

        String scene = "";
        String extraInfo = "";

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(scene,extraInfo);
        Assert.assertTrue(tagInfoCache.size()==0);

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(scene,extraInfo);
        Assert.assertTrue(cr.mCollectCount==0);

    }




    @Test    //stage 包含空格
    public void test_04_PerfCollectorStop_scene1() throws Exception {

        String scene = "aaa aaa";
        String extraInfo = "";
        String uni_scene = scene + extraInfo;

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(scene,extraInfo);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(uni_scene));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(scene,extraInfo);
        Assert.assertTrue(cr.mCollectCount==1);

    }


    @Test    //stage 包含"/"
    public void test_05_PerfCollectorStop_scene2() throws Exception {

        String scene = "aaa/aaa";
        String extraInfo = "";
        String uni_scene = scene + extraInfo;

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(scene,extraInfo);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(uni_scene));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(scene,extraInfo);
        Assert.assertTrue(cr.mCollectCount==1);

    }

    @Test    //stage 包含":"
    public void test_05_PerfCollectorStop_scene3() throws Exception {

        String scene = "aaa:aaa";
        String extraInfo = "";
        String uni_scene = scene + extraInfo;

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(scene,extraInfo);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(uni_scene));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(scene,extraInfo);
        Assert.assertTrue(cr.mCollectCount==1);

    }

    @Test    //stage 包含"."
    public void test_06_PerfCollectorStop_scene4() throws Exception {

        String scene = "aaa.aaa";
        String extraInfo = "";
        String uni_scene = scene + extraInfo;

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(scene,extraInfo);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(uni_scene));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(scene,extraInfo);
        Assert.assertTrue(cr.mCollectCount==1);

    }


    @Test    //stage is 正则表达式
    public void test_07_PerfCollectorStop_scene5() throws Exception {


        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(regex,"");
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(regex));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(regex,"");
        Assert.assertTrue(cr.mCollectCount==1);

    }

    @Test    //stage is js
    public void test_08_PerfCollectorStop_scene6() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(js,"");
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(js));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(js,"");
        Assert.assertTrue(cr.mCollectCount==1);

    }


    @Test    //stage is sql
    public void test_09_PerfCollectorStop_scene7() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(sql,"");
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(sql));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(sql,"");
        Assert.assertTrue(cr.mCollectCount==1);

    }


    @Test    //stage is long string
    public void test_10_PerfCollectorStop_scene8() throws Exception {

        StringBuffer sb = new StringBuffer();
        for(int i=0;i<10000;i++){
            sb.append("aaaaa");
        }

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(sb.toString(),"");
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(sb.toString()));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(sb.toString(),"");
        Assert.assertTrue(cr.mCollectCount==1);

    }



//    @Test   //extraInfo is null
//    public void test_11_PerfCollectorStop_extraInfoIsNullObject() throws Exception {
//
//        String stage = "aaa";
//        String extraInfo = null;
//        String uni_scene = stage + extraInfo;
//
//        perfCollector = PerfCollector.getInstance();
//        Assert.assertNotNull(perfCollector);
//
//        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
//        field.setAccessible(true);
//        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
//        Assert.assertNotNull(tagInfoCache);
//        tagInfoCache.clear();
//
//        perfCollector.start(stage,extraInfo);
//        Assert.assertTrue(tagInfoCache.size()==1);
//        Assert.assertNotNull(tagInfoCache.get(uni_scene));
//
//        Thread.sleep(2000);
//        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_RESOURCE_REPORT);
//        Assert.assertTrue(cr.mCollectCount==0);
//        perfCollector.stop(stage,extraInfo);
//        Assert.assertTrue(cr.mCollectCount==1);
//
//    }






    @Test    //extraInfo 包含空格
    public void test_12_PerfCollectorStop_extraInfo1() throws Exception {

        String scene = "aaa";
        String extraInfo = "bbb bbb";
        String uni_scene = scene + extraInfo;

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(scene,extraInfo);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(uni_scene));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(scene,extraInfo);
        Assert.assertTrue(cr.mCollectCount==1);

    }


    @Test    //extraInfo 包含"/"
    public void test_13_PerfCollectorStop_extraInfo2() throws Exception {

        String scene = "aaa";
        String extraInfo = "bbb/bbb";
        String uni_scene = scene + extraInfo;

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(scene,extraInfo);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(uni_scene));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(scene,extraInfo);
        Assert.assertTrue(cr.mCollectCount==1);

    }

    @Test    //extraInfo 包含":"
    public void test_14_PerfCollectorStop_extraInfo3() throws Exception {

        String scene = "aaa";
        String extraInfo = "bbb:bbb";
        String uni_scene = scene + extraInfo;

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(scene,extraInfo);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(uni_scene));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(scene,extraInfo);
        Assert.assertTrue(cr.mCollectCount==1);

    }

    @Test    //extraInfo 包含"."
    public void test_15_PerfCollectorStop_extraInfo4() throws Exception {

        String scene = "aaa";
        String extraInfo = "bbb.bbb";
        String uni_scene = scene + extraInfo;

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start(scene,extraInfo);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(uni_scene));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop(scene,extraInfo);
        Assert.assertTrue(cr.mCollectCount==1);

    }


    @Test    //extraInfo is 正则表达式
    public void test_16_PerfCollectorStop_extraInfo5() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start("aaa",regex);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa"+regex));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop("aaa",regex);
        Assert.assertTrue(cr.mCollectCount==1);

    }

    @Test    //extraInfo is js
    public void test_17_PerfCollectorStop_extraInfo6() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start("aaa",js);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa"+js));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop("aaa",js);
        Assert.assertTrue(cr.mCollectCount==1);

    }


    @Test    //extraInfo is sql
    public void test_18_PerfCollectorStop_extraInfo7() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start("aaa",sql);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa"+sql));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop("aaa",sql);
        Assert.assertTrue(cr.mCollectCount==1);

    }


    @Test    //extraInfo is long string
    public void test_19_PerfCollectorStop_extraInfo8() throws Exception {

        StringBuffer sb = new StringBuffer();
        for(int i=0;i<10000;i++){
            sb.append("aaaaa");
        }

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start("aaa",sb.toString());
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa"+sb.toString()));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop("aaa",sb.toString());
        Assert.assertTrue(cr.mCollectCount==1);

    }




    @Test    //没有start，只有stop
    public void test_20_PerfCollectorStop_scene9() {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop("aaa","bbb");
        Assert.assertTrue(cr.mCollectCount==0);

    }


    @Test    //extraInfo is "APPLAUNCH"
    public void test_21_PerfCollectorStop_sceneIsAPPLAUNCH() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start("aaa",APPLAUNCH);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa"+APPLAUNCH));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop("aaa",APPLAUNCH);     //此时 appLaunchCount==0
        Assert.assertTrue(cr.mCollectCount==1);

//        Field f1 = PerfCollector.class.getDeclaredField("appLaunchCount");
//        f1.setAccessible(true);
//        Assert.assertTrue(((int) f1.get(PerfCollector.class))==1);
//
//        perfCollector.stop("aaa",APPLAUNCH);   //此时 appLaunchCount!=0
//        Assert.assertTrue(((int) f1.get(PerfCollector.class))==1);

    }


    @Test    //extraInfo is "ACTIVITYSTART" ACTIVITYSTART已不做特殊处理
    public void test_22_PerfCollectorStop_sceneIsACTIVITYSTART() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        perfCollector.start("aaa",ACTIVITYSTART);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa"+ACTIVITYSTART));

        Thread.sleep(2000);
        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        perfCollector.stop("aaa",ACTIVITYSTART);
        Assert.assertTrue(cr.mCollectCount==1);

    }



//    //Todo
//    @Test      //同一个线程，相同的scene，相同的extraInfo
//    public void test_23_PerfCollectorStop_oneThread1() throws Exception {
//
//        String stage = "aaaaa";
//        String extraInfo = "bbbbb";
//        String uni_scene = stage + extraInfo;
//
//        perfCollector = PerfCollector.getInstance();
//        Assert.assertNotNull(perfCollector);
//
//        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
//        field.setAccessible(true);
//        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
//        Assert.assertNotNull(tagInfoCache);
//        tagInfoCache.clear();
//
//        for(int i=0;i<20;i++){
//            perfCollector.start(stage,extraInfo);
//        }
//        Assert.assertTrue(tagInfoCache.size()==1);
//        Assert.assertNotNull(tagInfoCache.get(uni_scene));
//        Thread.sleep(2000);
//
//        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_RESOURCE_REPORT);
//        Assert.assertTrue(cr.mCollectCount==0);
//        for(int i=0;i<20;i++){
//            perfCollector.stop(stage,extraInfo);
//        }
//        Thread.sleep(2000);
//        Assert.assertTrue(cr.mCollectCount==20);
//
//
//    }


    @Test   //同一个线程，相同的scene，不同的extraInfo
    public void test_24_PerfCollectorStop_oneThread2() throws Exception {

        String scene = "aaaaa";
        String [] extraInfo = new String[20];
        for(int i=0;i<20;i++){
            extraInfo[i]=getRandomString(10);
        }

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        for(int i=0;i<20;i++){
            perfCollector.start(scene,extraInfo[i]);
        }
        Assert.assertTrue(tagInfoCache.size()==20);
        Thread.sleep(2000);

        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        for(int i=0;i<20;i++){
            perfCollector.stop(scene,extraInfo[i]);
        }
        Thread.sleep(2000);
        Assert.assertTrue(cr.mCollectCount==20);

    }

    @Test   //同一个线程，不同的scene，相同的extraInfo
    public void test_25_PerfCollectorStop_oneThread3() throws Exception {

        String [] scene = new String[20];
        for(int i=0;i<20;i++){
            scene[i]=getRandomString(10);
        }
        String extraInfo = "bbbbb";

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        for(int i=0;i<20;i++){
            perfCollector.start(scene[i],extraInfo);
        }
        Assert.assertTrue(tagInfoCache.size()==20);
        Thread.sleep(2000);

        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        for(int i=0;i<20;i++){
            perfCollector.stop(scene[i],extraInfo);
        }
        Thread.sleep(2000);
        Assert.assertTrue(cr.mCollectCount==20);

    }


    @Test   //同一个线程，不同的scene，不同的extraInfo
    public void test_26_PerfCollectorStop_oneThread4() throws Exception {

        String [] scene = new String[20];
        String [] extraInfo = new String[20];
        for(int i=0;i<20;i++){
            scene[i]=getRandomString(10);
            extraInfo[i]=getRandomString(10);
        }

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertNotNull(tagInfoCache);
        tagInfoCache.clear();

        for(int i=0;i<20;i++){
            perfCollector.start(scene[i],extraInfo[i]);
        }
        Assert.assertTrue(tagInfoCache.size()==20);
        Thread.sleep(2000);

        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        Assert.assertTrue(cr.mCollectCount==0);
        for(int i=0;i<20;i++){
            perfCollector.stop(scene[i],extraInfo[i]);
        }
        Thread.sleep(2000);
        Assert.assertTrue(cr.mCollectCount==20);

    }


//    //Todo
//    @Test  //多线程，相同的scene，相同的extraInfo
//    public void test_27_PerfCollectorStop_Threads1() throws Exception {
//
//        String stage = "aaaaa";
//        String extraInfo = "bbbbb";
//        String uni_scene = stage + extraInfo;
//
//        perfCollector = PerfCollector.getInstance();
//        Assert.assertNotNull(perfCollector);
//
//        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
//        field.setAccessible(true);
//        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
//        Assert.assertNotNull(tagInfoCache);
//        tagInfoCache.clear();
//
//        for(int i=0;i<20;i++){
//            new Thread(new MyThread1(stage,extraInfo)).start();
//        }
//        Thread.sleep(2000);
//        Assert.assertTrue(tagInfoCache.size()==1);
//        Assert.assertNotNull(tagInfoCache.get(uni_scene));
//
//        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_RESOURCE_REPORT);
//        Assert.assertTrue(cr.mCollectCount==0);
//        for(int i=0;i<20;i++){
//            new Thread(new MyThread2(stage,extraInfo)).start();
//        }
//        Thread.sleep(2000);
//        Assert.assertTrue(cr.mCollectCount==20);
//
//    }


//    @Test   //多线程，相同的scene，不同的extraInfo
//    public void test_28_PerfCollectorStop_Threads2() throws Exception {
//
//        String stage = "aaaaa";
//        String [] extraInfo = new String[20];
//        for(int i=0;i<20;i++){
//            extraInfo[i]=getRandomString(10);
//        }
//
//        perfCollector = PerfCollector.getInstance();
//        Assert.assertNotNull(perfCollector);
//
//        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
//        field.setAccessible(true);
//        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
//        Assert.assertNotNull(tagInfoCache);
//        tagInfoCache.clear();
//
//        for(int i=0;i<20;i++){
//            new Thread(new MyThread1(stage,extraInfo[i])).start();
//        }
//        Thread.sleep(2000);
//        Assert.assertTrue(tagInfoCache.size()==20);
//
//        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_RESOURCE_REPORT);
//        Assert.assertTrue(cr.mCollectCount==0);
//        for(int i=0;i<20;i++){
//            new Thread(new MyThread2(stage,extraInfo[i])).start();
//        }
//        Thread.sleep(2000);
//        Assert.assertTrue(cr.mCollectCount==20);
//
//    }

//    @Test  //多线程，不同的scene，相同的extraInfo
//    public void test_29_PerfCollectorStop_Threads3() throws Exception {
//
//        String [] stage = new String[20];
//        for(int i=0;i<20;i++){
//            stage[i]=getRandomString(10);
//        }
//        String extraInfo = "bbbbb";
//
//
//        perfCollector = PerfCollector.getInstance();
//        Assert.assertNotNull(perfCollector);
//
//        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
//        field.setAccessible(true);
//        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
//        Assert.assertNotNull(tagInfoCache);
//        tagInfoCache.clear();
//
//        for(int i=0;i<20;i++){
//            new Thread(new MyThread1(stage[i],extraInfo)).start();
//        }
//        Thread.sleep(2000);
//        int n = tagInfoCache.size();
//        Assert.assertTrue(tagInfoCache.size()==20);
//
//        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_RESOURCE_REPORT);
//        Assert.assertTrue(cr.mCollectCount==0);
//        for(int i=0;i<20;i++){
//            new Thread(new MyThread2(stage[i],extraInfo)).start();
//        }
//        Thread.sleep(2000);
//        Assert.assertTrue(cr.mCollectCount==20);
//
//    }


//    @Test   //多线程，不同的scene，不同的extraInfo
//    public void test_30_PerfCollectorStop_Threads4() throws Exception {
//
//        String [] stage = new String[20];
//        String [] extraInfo = new String[20];
//        for(int i=0;i<20;i++){
//            stage[i]=getRandomString(10);
//            extraInfo[i]=getRandomString(10);
//        }
//
//        perfCollector = PerfCollector.getInstance();
//        Assert.assertNotNull(perfCollector);
//
//        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
//        field.setAccessible(true);
//        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
//        Assert.assertNotNull(tagInfoCache);
//        tagInfoCache.clear();
//
//        for(int i=0;i<20;i++){
//            new Thread(new MyThread1(stage[i],extraInfo[i])).start();
//        }
//        Thread.sleep(2000);
//        Assert.assertTrue(tagInfoCache.size()==20);
//
//        CollectStatus.CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_RESOURCE_REPORT);
//        Assert.assertTrue(cr.mCollectCount==0);
//        for(int i=0;i<20;i++){
//            new Thread(new MyThread2(stage[i],extraInfo[i])).start();
//        }
//        Thread.sleep(2000);
//        Assert.assertTrue(cr.mCollectCount==20);
//
//    }






    class MyThread1 implements  Runnable{
        private String scene;
        private String extraInfo;

        public MyThread1(String scene,String extraInfo){
            this.scene = scene;
            this.extraInfo = extraInfo;

        }

        @Override
        public void run() {
            try {
                perfCollector.start(scene,extraInfo);

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    class MyThread2 implements  Runnable{
        private String scene;
        private String extraInfo;

        public MyThread2(String scene,String extraInfo){
            this.scene = scene;
            this.extraInfo = extraInfo;

        }

        @Override
        public void run() {
            try {
                perfCollector.stop(scene,extraInfo);

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }
}
