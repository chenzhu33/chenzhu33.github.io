package com.tencent.qapmsdk.test;

import android.app.Application;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.common.ProcessStats;
import com.tencent.qapmsdk.memory.DumpMemInfoHandler;
import com.tencent.qapmsdk.test.TestEnv;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;


@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestGenerateTraces {
    private static final String TAG = "TestGenerateTraces";
    private DumpMemInfoHandler handler;

    @Before
    public void setUp() {
        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();
        QAPM.setProperty(QAPM.PropertyKeyAppInstance, app);
        QAPM.setProperty(QAPM.PropertyKeyAppId, TestEnv.APP_ID).setProperty(QAPM.PropertyKeyAppVersion, "2.1").setProperty(QAPM.PropertyKeySymbolId, "e6ae1282-ceb8-4237-89bd-2d23d00a8e33");
        QAPM.setProperty(QAPM.PropertyKeyUserId, TestEnv.USER_ID).setProperty(QAPM.PropertyKeyLogLevel, QAPM.LevelDebug);
        QAPM.setProperty(QAPM.PropertyKeyEventCon, true);
        QAPM.beginScene(QAPM.SCENE_ALL, QAPM.ModeLeakInspector);
    }
    /*
    @Test
    public void test_generateTraces() {
        handler = new DumpMemInfoHandler();
        Assert.assertNotNull(handler);
        long timestamp = System.currentTimeMillis();
        String traces = DumpMemInfoHandler.generateTraces();
        checkFile(traces, timestamp, "线程快照");
    }*/

    public void checkFile(String path, long timestamp, String filedescription){
        Assert.assertNotNull(path);
        Assert.assertNotEquals(filedescription + "处理异常", path);
        File file = new File(path);
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
            Assert.assertTrue(filedescription + "创建的时间不正确",timestamp < file.lastModified());
        }
        catch (FileNotFoundException fileNotFoundEx)
        {
            Assert.fail(filedescription + "的文件不存在");
        }
    }

    @Test
    public void test_generateHprof() throws Exception {

        Runtime.getRuntime().gc();
        Thread.sleep(10000);

        Class<?> c = Magnifier.class;
        Method inspectMemoryLeak = c.getDeclaredMethod("inspectMemoryLeak",Application.class);
        Assert.assertNotNull(inspectMemoryLeak);
        inspectMemoryLeak.setAccessible(true);
        long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("memoryleak use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));

        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));


        handler = new DumpMemInfoHandler();
        Assert.assertNotNull(handler);
        long timestamp = System.currentTimeMillis();
        Object[] result = DumpMemInfoHandler.generateHprof("TestGenerateHprof");
        Assert.assertNotNull("获取内存快照的过程出问题",result);
        Assert.assertTrue("获取内存快照失败",(boolean)result[0]);

        String path = (String)result[1];

        checkFile(path, timestamp, "内存快照" );

        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));
        appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("memoryleak use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));
    }

}

