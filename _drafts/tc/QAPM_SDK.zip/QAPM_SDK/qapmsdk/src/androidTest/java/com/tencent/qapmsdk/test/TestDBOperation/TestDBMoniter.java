package com.tencent.qapmsdk.test.TestDBOperation;

import android.app.Application;
import android.database.sqlite.SQLiteDatabase;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

import com.tencent.qapmsdk.common.ProcessStats;
import com.tencent.qapmsdk.io.IOMonitor;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;
import java.io.IOException;

@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestDBMoniter {

    private static final String TAG = "TestDBMonitor";
    @Test
    public void test_dbMoniterMemoryCost() throws Exception {

        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();

        Runtime.getRuntime().gc();
        Thread.sleep(10000);

        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

        IOMonitor ioMonitor = new IOMonitor(app,2,"2.3");
        ioMonitor.start();

        Thread.sleep(10000);

        long useMemory1 = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory1));
        Log.i(TAG,String.format("dbmonitor use memory %d",useMemory1-useMemory));
    }


    @Test
    public void test_dbMoniterCPUCost() throws Exception {

        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();

        long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("dbMonitor use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));

        IOMonitor ioMonitor = new IOMonitor(app,2,"2.3");
        ioMonitor.start();

        Thread.sleep(10000);

        long appUsage1 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage1 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("dbMonitor use cpu:%d",appUsage1));
        Log.i(TAG,String.format("device use cpu:%d",devUsage1));
        float ratio = (float)(appUsage1-appUsage)/(float)(devUsage1-devUsage);
        Log.i(TAG,String.format("dbMonitor use cpu ratio",ratio));
    }

    @Test
    public void test_dbMoniterCollectCost() throws Exception {

        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();
        Runtime.getRuntime().gc();
        Thread.sleep(10000);
        long appUsage1 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage1 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("dbMonitor use cpu:%d",appUsage1));
        Log.i(TAG,String.format("device use cpu:%d",devUsage1));
        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

        SQLiteDatabaseTest();

        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before1 memory %d b",useMemory));


        Thread.sleep(2000);
        long appUsage2 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage2 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("dbMonitor use cpu:%d",appUsage2));
        Log.i(TAG,String.format("device use cpu:%d",devUsage2));

        //Log.i(TAG,String.format("device use cpu:%d",devUsage2));

        IOMonitor ioMonitor = new IOMonitor(app,2,"2.3");
        ioMonitor.start();

        Thread.sleep(10000);
        SQLiteDatabaseTest();

        long appUsage3 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage3 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));

        Log.i(TAG,String.format("dbMonitor use cpu:%d",appUsage3));
        Log.i(TAG,String.format("device use cpu:%d",devUsage3));
    }

    public void SQLiteDatabaseTest() {
        File dbf;
        File dbp;
        String dbPath;
        String qqDB = "2872971611.db";
        SQLiteDatabase sqliteDB;
        String filePath = InstrumentationRegistry.getTargetContext().getApplicationContext().getFilesDir().getAbsolutePath();
        dbPath = filePath.replace("files", "databases");
        dbp=new File(dbPath);
        if (!dbp.exists()) {
            dbp.mkdir();
        }

        boolean isExist = true;
        try {
            dbf=new File(dbPath+"/"+qqDB);
            if(!dbf.exists()){
                isExist = false;
                try {
                    dbf.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            sqliteDB = SQLiteDatabase.openOrCreateDatabase(dbf, null);
            if(!isExist){
                String sql_create = "create table if not exists events(_id INTEGER PRIMARY KEY, content TEXT, status INTEGER, send_count INTEGER, timestamp INTEGER)";
                sqliteDB.execSQL(sql_create);
            }
            String sql = "insert into events  (content, status, send_count, timestamp) values ('test', 0,"+ String.valueOf((int)(Math.random()*100)) +" , 31)";

            //sqlite事务测试
            sqliteDB.beginTransaction();
            try{
                for(int i=0;i<500;i++){
                    sqliteDB.execSQL(sql);
                }
                sqliteDB.setTransactionSuccessful();
            }catch (Exception e){
                e.printStackTrace();
            }finally {
                sqliteDB.endTransaction();
            }

            sqliteDB.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
