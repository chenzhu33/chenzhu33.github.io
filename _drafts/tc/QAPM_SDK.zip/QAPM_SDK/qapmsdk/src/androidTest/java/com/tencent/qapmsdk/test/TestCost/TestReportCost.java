package com.tencent.qapmsdk.test.TestCost;


import android.os.Looper;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.common.NetworkWatcher;
import com.tencent.qapmsdk.common.ProcessStats;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.memory.DumpMemInfoHandler;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.reporter.ResultObject;
import com.tencent.qapmsdk.test.TestEnv;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestReportCost {

    private static String TAG = "TestReportCost";
    @Test
    public void test_ReportJsonCost() throws Exception {

        Magnifier.info.appId = TestEnv.APP_ID;

        QAPM.setProperty(QAPM.PropertyKeyAppInstance, InstrumentationRegistry.getTargetContext().getApplicationContext());
        QAPM.setProperty(QAPM.PropertyKeyAppId, TestEnv.APP_ID).setProperty(QAPM.PropertyKeyAppVersion, "2.1").setProperty(QAPM.PropertyKeySymbolId, "e6ae1282-ceb8-4237-89bd-2d23d00a8e33");
        QAPM.setProperty(QAPM.PropertyKeyUserId, TestEnv.USER_ID);
        QAPM.setProperty(QAPM.PropertyKeyHost, TestEnv.HOST);

        Class<?> m = Magnifier.class;
        Method initCore = m.getDeclaredMethod("initCore",String.class);
        initCore.setAccessible(true);
        Boolean ret = (Boolean)initCore.invoke(null,Magnifier.info.appId);
        Assert.assertTrue(ret);

        ReporterMachine rm = ReporterMachine.getInstance();
        rm.startMachine();

        Class<?> nw = NetworkWatcher.class;
        Field wifiAvailable = nw.getDeclaredField("wifiAvailable");
        wifiAvailable.setAccessible(true);
        wifiAvailable.setBoolean(null,true);

        Thread.sleep(5000);
        Class<?> NetworkBytesCollector = Class.forName("com.tencent.qapmsdk.sample.NetworkBytesCollector");
        Assert.assertNotNull(NetworkBytesCollector);
        Constructor<?> constructor = NetworkBytesCollector.getDeclaredConstructor();
        Assert.assertNotNull(constructor);
        constructor.setAccessible(true);
        Object networkBytesCollector = constructor.newInstance();
        Method getTotalBytes = NetworkBytesCollector.getDeclaredMethod("getTotalBytes");
        long[] netBytes = (long[]) getTotalBytes.invoke(networkBytesCollector);
        long sendBytes = 0,recvBytes = 0;
        if(netBytes!=null){
            sendBytes = netBytes[0];
            recvBytes = netBytes[2];
        }

        long appUsage1 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage1 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("dbAndIoMonitor use cpu:%d",appUsage1));
        Log.i(TAG,String.format("device use cpu:%d",devUsage1));
        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

//        // upload battery json
//        String s = "{\"fg30LogCount\":[{\"count\":\"0\",\"time\":1511696099},{\"count\":\"0\",\"time\":1511696109}],\"fg30SysDetail\":[{\"timeList\":[1511695647],\"tag\":\"[c.t.m.g.cz$1.run(TL:109),com.tencent.mobileqq.javahooksdk.JavaHookBridge.handleHookMethod(JavaHookBridge.java:236)]\"}],\"fg30WFSCount\":[{\"count\":\"43\",\"time\":1511696099},{\"count\":\"0\",\"time\":1511696109}],\"fg30WlCount\":[{\"useBatteryTime\":0,\"count\":\"0\",\"useTime\":0,\"time\":1511696099},{\"useBatteryTime\":0,\"count\":\"0\",\"useTime\":0,\"time\":1511696109}],\"fg30CmdCount\":[{\"count\":\"0\",\"time\":1511696099},{\"count\":\"0\",\"time\":1511696109}],\"fg30SysCount\":[{\"count\":\"3\",\"time\":1511696109},{\"count\":\"0\",\"time\":1511696158}],\"fg30SdkDetail\":[{\"timeList\":[1511695039],\"tag\":\"PrecoverLbsConfig\"},{\"timeList\":[1511695402,1511695650,1511695395,1511695344,1511695307,1511695310,1511695306,1511695342,1511695416,1511695342,1511695309,1511695309,1511695357,1511695307,1511695374,1511695313,1511695379,1511695310,1511695676,1511695651,1511695479,1511695310,1511695395,1511695445,1511695309,1511695269,1511695395,1511695649,1511695445,1511695678,1511695311,1511695490,1511695445,1511695488,1511695248,1511695476,1511695307,1511695309,1511695310,1511695400,1511695459,1511695395,1511695650,1511695394,1511695342,1511695678,1511695308,1511695445,1511695342,1511695464,1511695342,1511695310,1511695309,1511695309,1511695356,1511695305,1511695306,1511695342,1511695342,1511695307,1511695307,1511695496,1511695445,1511695483,1511695342,1511695351,1511695414,1511695342,1511695679,1511695348,1511695342,1511695650,1511695310,1511695342,1511695408,1511695395,1511695470,1511695355,1511695310,1511695444,1511695342,1511695308,1511695492,1511695307,1511695485,1511695415,1511695346,1511695342,1511695676,1511695651,1511695446,1511695445,1511695306,1511695309,1511695648,1511695310,1511695305,1511695311,1511695307,1511695649,1511695353,1511695299,1511695376,1511695649,1511695395,1511695398,1511695309,1511695678,1511695289,1511695446,1511695395,1511695394,1511695412,1511695306,1511695395,1511695395,1511695463,1511695342,1511695308,1511695309,1511695305,1511695307,1511695342,1511695447,1511695474,1511695309,1511695309,1511695475,1511695307,1511695470,1511695408,1511695650,1511695364,1511695651,1511695678,1511695306,1511695445,1511695409,1511695457,1511695311,1511695310,1511695648,1511695446,1511695307,1511695498,1511695443,1511695362,1511695309,1511695494,1511695481,1511695445,1511695311,1511695306,1511695301,1511695309,1511695442,1511695306,1511695649,1511695284,1511695360,1511695450,1511695456,1511695310,1511695676,1511695472,1511695307,1511695395,1511695309,1511695650],\"tag\":\"QQMapActivity\"},{\"timeList\":[1511695039],\"tag\":\"wealthgod_locate_check\"},{\"timeList\":[1511695039],\"tag\":\"GeneralLBSConfigs\"},{\"timeList\":[1511695034],\"tag\":\"ArkAppLocationManager\"}],\"fg30WFLCount\":[{\"useBatteryTime\":0,\"count\":\"0\",\"useTime\":0,\"time\":1511696099},{\"useBatteryTime\":0,\"count\":\"0\",\"useTime\":0,\"time\":1511696109}],\"device\":\"MI 4C\",\"uin\":\"328659992\",\"fg30SdkCount\":[{\"count\":\"173\",\"time\":1511696109},{\"count\":\"0\",\"time\":1511696124}],\"sdk\":19,\"fg30WFSDetail\":[{\"timeList\":[1511696083,1511695625],\"tag\":\"[c.t.m.g.dd.onCellInfoChanged(TL:173),c.t.m.g.dd.a(TL:198),c.t.m.g.cm.b(TL:359),c.t.m.g.da.onCellInfoEvent(TL:936),c.t.m.g.di.b(TL:142),c.t.m.g.di.c(TL:233),c.t.m.g.ee.a(TL:123),com.tencent.mobileqq.javahooksdk.JavaHookBridge.handleHookMethod(JavaHookBridge.java:236)]\"},{\"timeList\":[1511695342,1511695456,1511695307,1511695306,1511695651,1511695445,1511695308,1511695299,1511695395,1511695410,1511695461,1511695403,1511695395,1511695445,1511695677,1511695342,1511695345,1511695310,1511695309,1511695361,1511695395,1511695650,1511695649,1511695313,1511695200,1511695442,1511695305,1511695307,1511695493,1511695446,1511695342,1511695485,1511695311,1511695309,1511695309,1511695307,1511695477,1511695376,1511695353,1511695310,1511695470],\"tag\":\"[c.t.m.g.di$1.run(TL:70),c.t.m.g.di.a(TL:29),c.t.m.g.di.c(TL:233),c.t.m.g.ee.a(TL:123),com.tencent.mobileqq.javahooksdk.JavaHookBridge.handleHookMethod(JavaHookBridge.java:236)]\"}]}";
//        JSONObject params = new JSONObject();
//        params.put("plugin", Config.PLUGIN_QCLOUD_NEW_BATTERY);
//        params.put("batterydata", new JSONObject(s));
//        ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, Magnifier.info.uin);
//        ReporterMachine.addResultObj(ro);

//        // upload call stack
        JSONObject params2 = new JSONObject();
        params2.put("stage", "MainActivity");
        params2.put("cost_time", 3000);
        StackTraceElement[] stack = Looper.getMainLooper().getThread().getStackTrace();
        params2.put("stack", Arrays.toString(stack));
        params2.put("plugin", Config.PLUGIN_QCLOUD_LOOPER_STACK);
        ResultObject ro2 = new ResultObject(0, "testcase", true, 1, 1, params2, true, true, Magnifier.info.uin);
        ReporterMachine.addResultObj(ro2);

        // upload drop frame
//        JSONObject joInner = new JSONObject();
//        JSONObject jo2InnerLevel = new JSONObject();
//        JSONArray joDropTimes = new JSONArray();
//        long[] item = {350,1,0,0,0,0};
//        jo2InnerLevel.put("dropDuration", 5.881160736083984);
//        for (int i=0; i<6; ++i) {
//            joDropTimes.put(i, item[i]);
//        }
//        jo2InnerLevel.put("dropTimes", joDropTimes);
//        joInner.put("0", jo2InnerLevel);
//        JSONObject r = new JSONObject();
//        r.put("MainActivity", joInner);
//        JSONObject params4 = new JSONObject();
//        params4.put("dropFrame", r);
//        params4.put("plugin", Config.PLUGIN_QCLOUD_DROPFRAME);
//        ResultObject ro4 = new ResultObject(0, "testcase", true, 1, 1, params4, true, true, Magnifier.info.uin);
//        ReporterMachine.addResultObj(ro4);

        Thread.sleep(3000);

        long appUsage2 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage2 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);

        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));
        Log.i(TAG,String.format("jsonupload use cpu:%d",appUsage2));
        Log.i(TAG,String.format("device use cpu:%d",devUsage2));
        float ratio = (float)(appUsage2 - appUsage1) / (float)(devUsage2 - devUsage1);

        Log.i(TAG,String.format("report a json cost cpu: %f\n",ratio));


        netBytes = (long[]) getTotalBytes.invoke(networkBytesCollector);
        if(netBytes!=null){
            sendBytes = netBytes[0] - sendBytes;
            recvBytes = netBytes[2] - recvBytes;
        }

        Log.i(TAG,String.format("report a json send bytes:%d b",sendBytes));
        Log.i(TAG,String.format("report a json recv bytes:%d b",recvBytes));
        Log.i(TAG,String.format("report a json cost bytes:%d b",(sendBytes + recvBytes)));
    }

    @Test
    public void test_ReportFileCost() throws Exception {

        Magnifier.info.appId = TestEnv.APP_ID;

        QAPM.setProperty(QAPM.PropertyKeyAppInstance, InstrumentationRegistry.getTargetContext().getApplicationContext());
        QAPM.setProperty(QAPM.PropertyKeyAppId, TestEnv.APP_ID).setProperty(QAPM.PropertyKeyAppVersion, "2.1").setProperty(QAPM.PropertyKeySymbolId, "e6ae1282-ceb8-4237-89bd-2d23d00a8e33");
        QAPM.setProperty(QAPM.PropertyKeyUserId, TestEnv.USER_ID);
        QAPM.setProperty(QAPM.PropertyKeyHost, TestEnv.HOST);

        Class<?> m = Magnifier.class;
        Method initCore = m.getDeclaredMethod("initCore",String.class);
        initCore.setAccessible(true);
        Boolean ret = (Boolean)initCore.invoke(null,Magnifier.info.appId);
        Assert.assertTrue(ret);

        ReporterMachine rm = ReporterMachine.getInstance();
        rm.startMachine();

        Class<?> nw = NetworkWatcher.class;
        Field wifiAvailable = nw.getDeclaredField("wifiAvailable");
        wifiAvailable.setAccessible(true);
        wifiAvailable.setBoolean(null,true);

        Thread.sleep(2000);

        Object[] result = DumpMemInfoHandler.generateHprof("TestActivityLeak");
        Assert.assertNotNull(result);
//        Assert.assertTrue((Boolean)result[0]);
        String hprofPath = (String)result[1];
        List<String> files = new ArrayList<>();
        files.add(hprofPath);
        Object[] zipRet = DumpMemInfoHandler.zipFiles(files, "leak");
        Assert.assertNotNull(zipRet);
//        Assert.assertTrue((Boolean)zipRet[0]);

        Thread.sleep(2000);
        Class<?> NetworkBytesCollector = Class.forName("com.tencent.qapmsdk.sample.NetworkBytesCollector");
        Assert.assertNotNull(NetworkBytesCollector);
        Constructor<?> constructor = NetworkBytesCollector.getDeclaredConstructor();
        Assert.assertNotNull(constructor);
        constructor.setAccessible(true);
        Object networkBytesCollector = constructor.newInstance();
        Method getTotalBytes = NetworkBytesCollector.getDeclaredMethod("getTotalBytes");
        long[] netBytes = (long[]) getTotalBytes.invoke(networkBytesCollector);
        long sendBytes = 0,recvBytes = 0;
        if(netBytes!=null){
            sendBytes = netBytes[0];
            recvBytes = netBytes[2];
        }

        long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("fileupload use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));
        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

        //upload file
        JSONObject params = new JSONObject();
        params.put("plugin", Config.PLUGIN_QCLOUD_LEAK_HPROF);
        params.put("versionname", "6.3.0.0");
        params.put("uin", Magnifier.info.uin);
        params.put("model", "iPhone6");
        params.put("processname", "com.example.sdkapp");
        params.put("event_time", System.currentTimeMillis());
        params.put("stage", "MainActivity");
        params.put("timecost", "112233");
        params.put("p_id", 1);
        params.put("fileObj",  zipRet[1]);
        ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, Magnifier.info.uin);
        ReporterMachine.addResultObj(ro);

        Thread.sleep(20000);

        long useMemory1 = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        long appUsage1 = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage1 = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("after memory %d b",useMemory1));
        Log.i(TAG,String.format("use memory %d b",useMemory1 - useMemory));
        Log.i(TAG,String.format("fileupload use cpu:%d",appUsage1));
        Log.i(TAG,String.format("device use cpu:%d",devUsage1));
        Log.i(TAG,String.format("report leak file use cpu:%f",(float)(appUsage1-appUsage)/(float)(devUsage1-devUsage)*100));
        netBytes = (long[]) getTotalBytes.invoke(networkBytesCollector);
        if(netBytes!=null){
            sendBytes = netBytes[0] - sendBytes;
            recvBytes = netBytes[2] - recvBytes;
        }
        Log.i(TAG,String.format("report a file send bytes:%d b",sendBytes));
        Log.i(TAG,String.format("report a file recv bytes:%d b",recvBytes ));
        Log.i(TAG,String.format("report a file cost bytes:%d b",(sendBytes + recvBytes)));
    }

    @Test
    public void test_GetConfigCost() throws Exception {

        Magnifier.info.appId = TestEnv.APP_ID;

        QAPM.setProperty(QAPM.PropertyKeyAppInstance, InstrumentationRegistry.getTargetContext().getApplicationContext());
        QAPM.setProperty(QAPM.PropertyKeyAppId, TestEnv.APP_ID).setProperty(QAPM.PropertyKeyAppVersion, "2.1").setProperty(QAPM.PropertyKeySymbolId, "e6ae1282-ceb8-4237-89bd-2d23d00a8e33");
        QAPM.setProperty(QAPM.PropertyKeyUserId, TestEnv.USER_ID);
        QAPM.setProperty(QAPM.PropertyKeyHost, TestEnv.HOST);

        Class<?> m = Magnifier.class;
        Method initCore = m.getDeclaredMethod("initCore",String.class);
        initCore.setAccessible(true);
        Boolean ret = (Boolean)initCore.invoke(null,Magnifier.info.appId);
        Assert.assertTrue(ret);

        Class<?> NetworkBytesCollector = Class.forName("com.tencent.qapmsdk.sample.NetworkBytesCollector");
        Assert.assertNotNull(NetworkBytesCollector);
        Constructor<?> constructor = NetworkBytesCollector.getDeclaredConstructor();
        Assert.assertNotNull(constructor);
        constructor.setAccessible(true);
        Object networkBytesCollector = constructor.newInstance();
        Method getTotalBytes = NetworkBytesCollector.getDeclaredMethod("getTotalBytes");
        long[] netBytes = (long[]) getTotalBytes.invoke(networkBytesCollector);
        long sendBytes = 0,recvBytes = 0;
        if(netBytes!=null){
            sendBytes = netBytes[0];
            recvBytes = netBytes[2];
        }

        Runtime.getRuntime().gc();
        Thread.sleep(10000);
        long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("memoryleak use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));
        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

        Class<?> c = Config.class;
        Method getConfigFromSvr = c.getDeclaredMethod("getConfigFromSvr");
        getConfigFromSvr.setAccessible(true);
        JSONObject config = (JSONObject) getConfigFromSvr.invoke(null);
        Assert.assertNotNull(config);

        Thread.sleep(5000);

        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));
        appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("memoryleak use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));

        netBytes = (long[]) getTotalBytes.invoke(networkBytesCollector);
        if(netBytes!=null){
            sendBytes = netBytes[0] - sendBytes;
            recvBytes = netBytes[2] - recvBytes;
        }
        Log.i(TAG,String.format("get config send bytes:%d b",sendBytes));
        Log.i(TAG,String.format("get config recv bytes:%d b",recvBytes));
        Log.i(TAG,String.format("get config cost bytes:%d b",(sendBytes + recvBytes)));
    }

    public static double cpu(String PackageName) {
        double Cpu = 0;
        try{
            Runtime runtime = Runtime.getRuntime();
            Process proc = runtime.exec("adb shell top -n 1| grep "+PackageName);
            try {
                if (proc.waitFor() != 0) {
                    System.err.println("exit value = " + proc.exitValue());
                }
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        proc.getInputStream()));
                StringBuffer stringBuffer = new StringBuffer();
                String line = null;
                while ((line = in.readLine()) != null) {
                    stringBuffer.append(line+" ");


                }
                String str1=stringBuffer.toString();
                String  str3=str1.substring(str1.indexOf(PackageName)-43,str1.indexOf(PackageName));
                String cpu= str3.substring(0,4);
                cpu=cpu.trim();
                Cpu=Double.parseDouble(cpu);

            } catch (InterruptedException e) {
                System.err.println(e);
            }finally{
                try {
                    proc.destroy();
                } catch (Exception e2) {
                }
            }
        }
        catch (Exception StringIndexOutOfBoundsException)
        {

            System.out.print("请检查设备是否连接");

        }

        return Cpu;

    }
}
