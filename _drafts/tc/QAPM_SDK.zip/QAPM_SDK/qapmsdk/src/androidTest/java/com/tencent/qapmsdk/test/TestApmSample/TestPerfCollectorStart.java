package com.tencent.qapmsdk.test.TestApmSample;

import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;

import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.sample.PerfCollector;
import com.tencent.qapmsdk.sample.PerfItem;
import com.tencent.qapmsdk.sample.TagItem;
import com.tencent.qapmsdk.test.TestEnv;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.lang.reflect.Field;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by felixliwang on 2018/5/23.
 */

@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestPerfCollectorStart {
    private static final String TAG = "TestPerfCollectorStart";

    private PerfCollector perfCollector = null;


    private String uni_scene = null;
    private String ACTIVITYSTART = "ACTIVITYSTART";
    private String regex = "^(?=.*\\\\d)(?=.*[a-z])(?=.*[A-Z]).{8,10}$";
    private String js = "<script>alert(“Attack!”)</script>";
    private String sql = "select distinct st.sno, sname  from student st  join sc sc on (st.sno = sc.sno)  where sc.cno in (select cno from sc where sno = 's001') and sc.sno<>'s001'";


    @Before
    public void setUp() {

        QAPM.setProperty(QAPM.PropertyKeyAppInstance, InstrumentationRegistry.getTargetContext().getApplicationContext());
        QAPM.setProperty(QAPM.PropertyKeyAppId, TestEnv.APP_ID).setProperty(QAPM.PropertyKeyAppVersion, "2.1").setProperty(QAPM.PropertyKeySymbolId, "e6ae1282-ceb8-4237-89bd-2d23d00a8e33");
        QAPM.setProperty(QAPM.PropertyKeyUserId, TestEnv.USER_ID);
        QAPM.setProperty(QAPM.PropertyKeyHost, TestEnv.HOST);
        Config.loadConfigs();

    }

    @Test      //正常参数
    public void test_01_PerfCollectorStart_scene() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, TagItem>) field.get(perfCollector)).clear();

        perfCollector.start("aaa","bbb");
        ConcurrentHashMap<String, TagItem> tagInfoCache = (ConcurrentHashMap<String, TagItem>) field.get(perfCollector);

        uni_scene = "aaabbb";
        Assert.assertTrue(tagInfoCache.size()==1);
        tagInfoCache.get(uni_scene);
        TagItem startPerfItem = tagInfoCache.get(uni_scene);
        Assert.assertNotNull(startPerfItem);

        Field f1 = startPerfItem.getClass().getDeclaredField("stage");
        f1.setAccessible(true);
        Assert.assertTrue(f1.get(startPerfItem).equals("aaa"));
        Field f2 = startPerfItem.getClass().getDeclaredField("extraInfo");
        f2.setAccessible(true);
        Assert.assertTrue(f2.get(startPerfItem).equals("bbb"));
    }









    @Test   //stage is null
    public void test_02_PerfCollectorStart_sceneIsNullObject() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start(null,"");
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==0);

    }

    @Test   //stage is ""
    public void test_03_PerfCollectorStart_sceneIsNullString() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start("","");
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==0);

    }




    @Test    //stage 包含空格
    public void test_04_PerfCollectorStart_scene1() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start("aaa aaa","");
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa aaa"));

    }


    @Test    //stage 包含"/"
    public void test_05_PerfCollectorStart_scene2() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start("aaa/aaa","");
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa/aaa"));


    }

    @Test    //stage 包含":"
    public void test_06_PerfCollectorStart_scene3() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start("aaa:aaa","");
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa:aaa"));

    }

    @Test    //stage 包含"."
    public void test_07_PerfCollectorStart_scene4() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start("aaa.aaa","");
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa.aaa"));

    }


    @Test    //stage is 正则表达式
    public void test_08_PerfCollectorStart_scene5() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start(regex,"");
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(regex));

    }

    @Test    //stage is js
    public void test_09_PerfCollectorStart_scene6() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start(js,"");
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(js));

    }


    @Test    //stage is sql
    public void test_10_PerfCollectorStart_scene7() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start(sql,"");
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(sql));

    }


    @Test    //stage is long string
    public void test_11_PerfCollectorStart_scene8() throws Exception {

        StringBuffer sb = new StringBuffer();
        for(int i=0;i<10000;i++){
            sb.append("aaaaa");
        }

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start(sb.toString(),"");
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get(sb.toString()));

    }



//    @Test   //extraInfo is null
//    public void test_12_PerfCollectorStart_extraInfoIsNullObject() throws Exception {
//
//        perfCollector = PerfCollector.getInstance();
//        Assert.assertNotNull(perfCollector);
//
//        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
//        field.setAccessible(true);
//        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
//        Assert.assertNotNull(tagInfoCache);
//        tagInfoCache.clear();
//
//        perfCollector.start("aaa",null);
//        Assert.assertTrue(tagInfoCache.size()==1);
//        Assert.assertNotNull(tagInfoCache.get("aaanull"));
//
//    }






    @Test    //extraInfo 包含空格
    public void test_13_PerfCollectorStart_extraInfo1() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();


        perfCollector.start("aaa","bbb bbb");
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaabbb bbb"));

    }


    @Test    //extraInfo 包含"/"
    public void test_14_PerfCollectorStart_extraInfo2() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start("aaa","bbb/bbb");
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaabbb/bbb"));

    }

    @Test    //extraInfo 包含":"
    public void test_15_PerfCollectorStart_extraInfo3() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start("aaa","bbb:bbb");
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaabbb:bbb"));

    }

    @Test    //extraInfo 包含"."
    public void test_16_PerfCollectorStart_extraInfo4() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start("aaa","bbb.bbb");
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaabbb.bbb"));

    }


    @Test    //extraInfo is 正则表达式
    public void test_17_PerfCollectorStart_extraInfo5() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start("aaa",regex);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa"+regex));

    }

    @Test    //extraInfo is js
    public void test_18_PerfCollectorStart_extraInfo6() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start("aaa",js);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa"+js));

    }


    @Test    //extraInfo is sql
    public void test_19_PerfCollectorStart_extraInfo7() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start("aaa",sql);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa"+sql));

    }


    @Test    //extraInfo is long string
    public void test_20_PerfCollectorStart_extraInfo8() throws Exception {

        StringBuffer sb = new StringBuffer();
        for(int i=0;i<10000;i++){
            sb.append("aaaaa");
        }

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start("aaa",sb.toString());
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa"+sb.toString()));

    }





    @Test    //extraInfo is "ACTIVITYSTART" ACTIVITYSTART已不做特殊处理
    public void test_21_PerfCollectorStart_sceneIsACTIVITYSTART() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        perfCollector.start("aaa",ACTIVITYSTART);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaa" + ACTIVITYSTART));

    }



    @Test      //同一个线程，相同的scene，相同的extraInfo
    public void test_22_PerfCollector_oneThread1() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        for(int i=0;i<20;i++){
            perfCollector.start("aaaaa","bbbbb");
        }
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaaaabbbbb"));

    }


    @Test   //同一个线程，相同的scene，不同的extraInfo
    public void test_23_PerfCollector_oneThread2() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        for(int i=0;i<20;i++){
            perfCollector.start("aaaaa",getRandomString(10));
        }
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==20);

    }

    @Test   //同一个线程，不同的scene，相同的extraInfo
    public void test_24_PerfCollector_oneThread3() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        for(int i=0;i<20;i++){
            perfCollector.start(getRandomString(10),"bbbbb");
        }
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==20);

    }


    @Test   //同一个线程，不同的scene，不同的extraInfo
    public void test_25_PerfCollector_oneThread4() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        for(int i=0;i<20;i++){
            perfCollector.start(getRandomString(10),getRandomString(10));
        }
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==20);

    }


    @Test  //多线程，相同的scene，相同的extraInfo
    public void test_26_PerfCollector_Threads1() throws Exception {

        perfCollector = PerfCollector.getInstance();
        Assert.assertNotNull(perfCollector);

        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
        field.setAccessible(true);
        Assert.assertNotNull(field.get(perfCollector));
        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();

        for(int i=0;i<20;i++){
            new Thread(new MyThread("aaaaa","bbbbb")).start();
        }
        Thread.sleep(2000);
        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
        Assert.assertTrue(tagInfoCache.size()==1);
        Assert.assertNotNull(tagInfoCache.get("aaaaabbbbb"));

    }


//    @Test   //多线程，相同的scene，不同的extraInfo
//    public void test_27_PerfCollector_Threads2() throws Exception {
//
//        perfCollector = PerfCollector.getInstance();
//        Assert.assertNotNull(perfCollector);
//
//        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
//        field.setAccessible(true);
//        Assert.assertNotNull((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector));
//        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();
//
//        for(int i=0;i<20;i++){
//            new Thread(new MyThread("aaaaa",getRandomString(10))).start();
//        }
//        Thread.sleep(2000);
//        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
//        Assert.assertTrue(tagInfoCache.size()==20);
//
//    }

//    @Test  //多线程，不同的scene，相同的extraInfo
//    public void test_28_PerfCollector_Threads3() throws Exception {
//
//
//        perfCollector = PerfCollector.getInstance();
//        Assert.assertNotNull(perfCollector);
//
//        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
//        field.setAccessible(true);
//        Assert.assertNotNull((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector));
//        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();
//
//        for(int i=0;i<20;i++){
//            new Thread(new MyThread(getRandomString(10),"bbbbb")).start();
//        }
//        Thread.sleep(2000);
//        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
//        Assert.assertTrue(tagInfoCache.size()==20);
//
//    }


//    @Test   //多线程，不同的scene，不同的extraInfo
//    public void test_29_PerfCollector_Threads4() throws Exception {
//
//        perfCollector = PerfCollector.getInstance();
//        Assert.assertNotNull(perfCollector);
//
//        Field field = perfCollector.getClass().getDeclaredField("tagInfoCache");
//        field.setAccessible(true);
//        Assert.assertNotNull((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector));
//        ((ConcurrentHashMap<String, PerfItem>) field.get(perfCollector)).clear();
//
//        for(int i=0;i<20;i++){
//            new Thread(new MyThread(getRandomString(10),getRandomString(10))).start();
//        }
//        Thread.sleep(2000);
//        ConcurrentHashMap<String, PerfItem> tagInfoCache = (ConcurrentHashMap<String, PerfItem>) field.get(perfCollector);
//        Assert.assertTrue(tagInfoCache.size()==20);
//
//    }




    public static String getRandomString(int length) {
        String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";//含有字符和数字的字符串
        Random random = new Random();
        StringBuffer sb = new StringBuffer();//StringBuffer类生成，为了拼接字符串

        for (int i = 0; i < length; ++i) {
            int number = random.nextInt(62);

            sb.append(str.charAt(number));
        }
        return sb.toString();
    }

    class MyThread implements  Runnable{
        private String scene;
        private String extraInfo;

        public MyThread(String scene,String extraInfo){
            this.scene = scene;
            this.extraInfo = extraInfo;

        }

        @Override
        public void run() {
            try {
                perfCollector.start(scene,extraInfo);

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }


}

