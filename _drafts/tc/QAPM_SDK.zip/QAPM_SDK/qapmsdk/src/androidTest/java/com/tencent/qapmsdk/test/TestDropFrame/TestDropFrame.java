package com.tencent.qapmsdk.test.TestDropFrame;


import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

import com.tencent.qapmsdk.common.ProcessStats;
import com.tencent.qapmsdk.dropframe.DropFrameMonitor;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestDropFrame {
    private static final String TAG = "TestDropFrame";


    @Test
    public void test_DropFrameMemoryCost() throws Exception{

        Runtime.getRuntime().gc();
        Thread.sleep(10000);
        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

//        Class<?> DropFrameRunnable = Class.forName("com.tencent.qapmsdk.Magnifier$DropFrameRunnable");
//        Assert.assertNotNull(DropFrameRunnable);
//        Constructor<?> constructor = DropFrameRunnable.getDeclaredConstructor();
//        Assert.assertNotNull(constructor);
//        constructor.setAccessible(true);
//
//        Handler h2 = new Handler(Looper.getMainLooper());
//        Object dfr =  constructor.newInstance();
//        h2.post((Runnable) dfr);

//        Choreographer a = android.view.Choreographer.getInstance();
//        Assert.assertNotNull(a);
        DropFrameMonitor monitor = DropFrameMonitor.getInstance();
        monitor.start("ceshi");

        Thread.sleep(10000);
        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));
    }

    @Test
    public void test_DropFrameCPUCost() throws Exception{
        long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("dropFrame use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));

//        Class<?> DropFrameRunnable = Class.forName("com.tencent.qapmsdk.Magnifier$DropFrameRunnable");
//        Assert.assertNotNull(DropFrameRunnable);
//        Constructor<?> constructor = DropFrameRunnable.getDeclaredConstructor();
//        Assert.assertNotNull(constructor);
//        constructor.setAccessible(true);
//
//        Handler h2 = new Handler(Looper.getMainLooper());
//        Object dfr =  constructor.newInstance();
//        h2.post((Runnable) dfr);

        DropFrameMonitor monitor = DropFrameMonitor.getInstance();
        Assert.assertNotNull(monitor);

        monitor.start("ceshi");

        Thread.sleep(10000);
        appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("dropFrame use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));
    }

    @Test
    public void test_DropFrameStopCost() throws Exception {
        Runtime.getRuntime().gc();
        Thread.sleep(10000);
        long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);

        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));
        Log.i(TAG,String.format("dropFrame use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));
        DropFrameMonitor monitor = DropFrameMonitor.getInstance();
        Assert.assertNotNull(monitor);
        monitor.start("ceshi");
        Thread.sleep(5000);


        monitor.stop();

        Thread.sleep(2000);
        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));
        appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("dropFrame use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));
    }

}
