package com.tencent.qapmsdk.test.TestLooper;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

import com.tencent.qapmsdk.common.ProcessStats;
import com.tencent.qapmsdk.looper.LooperMonitor;

import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestLooperCost {
    private static final String TAG = "TestMemoryLeak";

    @Test
    public void test_LooperMemoryCost() throws Exception{

        Runtime.getRuntime().gc();
        Thread.sleep(10000);

        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

        LooperMonitor.monitorMainLooper();
        Thread.sleep(10000);

        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));
    }


    @Test
    public void test_LooperCPUCost() throws Exception{

        long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("looper use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));

        LooperMonitor.monitorMainLooper();
        Thread.sleep(10000);

        appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("looper use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));
    }
}
