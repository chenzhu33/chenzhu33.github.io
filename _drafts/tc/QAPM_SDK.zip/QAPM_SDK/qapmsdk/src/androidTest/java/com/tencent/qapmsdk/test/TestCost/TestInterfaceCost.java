package com.tencent.qapmsdk.test.TestCost;

import android.app.Application;
import android.os.SystemClock;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.battery.BatteryStatsImpl;
import com.tencent.qapmsdk.common.ProcessStats;
import com.tencent.qapmsdk.test.TestEnv;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;


@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestInterfaceCost {

    private static final String TAG = "TestInterfaceCost";

    @Before
    public void setUp() throws Exception {
        QAPM.setProperty(QAPM.PropertyKeyAppInstance,(Application) InstrumentationRegistry.getTargetContext().getApplicationContext());
        QAPM.setProperty(QAPM.PropertyKeyAppId, TestEnv.APP_ID).setProperty(QAPM.PropertyKeyAppVersion, "2.1").setProperty(QAPM.PropertyKeySymbolId, "e6ae1282-ceb8-4237-89bd-2d23d00a8e33");
        QAPM.setProperty(QAPM.PropertyKeyUserId, TestEnv.USER_ID).setProperty(QAPM.PropertyKeyLogLevel, QAPM.LevelDebug);
        QAPM.setProperty(QAPM.PropertyKeyHost, TestEnv.HOST);
    }


    @Test
    public void test_StartAllCost() throws Exception {
        Runtime.getRuntime().gc();
        Thread.sleep(10000);

        long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("bettery monitor use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));

        BatteryStatsImpl.getInstance().start();
        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

        long startTime = SystemClock.uptimeMillis();

        QAPM.beginScene(QAPM.SCENE_ALL, QAPM.ModeAll);


        Log.i("启动所有耗时",String.format("%d ms",SystemClock.uptimeMillis()-startTime));

        Thread.sleep(10000);

        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));
        appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("bettery monitor use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));

    }

    @Test
    public void test_StartDBIOCost() {
        long startTime = SystemClock.uptimeMillis();

        QAPM.beginScene(QAPM.SCENE_ALL, QAPM.ModeDBIO);

        Log.i("启动DB耗时",String.format("%d ms",SystemClock.uptimeMillis()-startTime));
    }

    @Test
    public void test_StartFileIOCost() {
        long startTime = SystemClock.uptimeMillis();

        QAPM.beginScene(QAPM.SCENE_ALL, QAPM.ModeFileIO);

        Log.i("启动FileIO耗时",String.format("%d ms",SystemClock.uptimeMillis()-startTime));
    }

    @Test
    public void test_StartBatteryCost() {
        long startTime = SystemClock.uptimeMillis();

        QAPM.beginScene(QAPM.SCENE_ALL, QAPM.ModeBattery);

        Log.i("启动电量监控耗时",String.format("%d ms",SystemClock.uptimeMillis()-startTime));
    }

    @Test
    public void test_StartLooperCost() {
        long startTime = SystemClock.uptimeMillis();

        QAPM.beginScene(QAPM.SCENE_ALL, QAPM.ModeLooper);

        Log.i("启动Looper耗时",String.format("%d ms",SystemClock.uptimeMillis()-startTime));
    }

    @Test
    public void test_StartMemoryCeillingCost() {
        long startTime = SystemClock.uptimeMillis();

        QAPM.beginScene(QAPM.SCENE_ALL, QAPM.ModeCeiling);

        Log.i("启动内存触顶耗时",String.format("%d ms",SystemClock.uptimeMillis()-startTime));
    }

    @Test
    public void test_StartMemoryLeakCost() {
        long startTime = SystemClock.uptimeMillis();

        QAPM.beginScene(QAPM.SCENE_ALL, QAPM.ModeLeakInspector);

        Log.i("启动内存泄漏耗时",String.format("%d ms",SystemClock.uptimeMillis()-startTime));
    }

    @Test
    public void test_StartDropFrameCost() {
       long startTime = SystemClock.uptimeMillis();

        QAPM.beginScene(QAPM.SCENE_ALL, QAPM.ModeDropFrame);

        Log.i("启动DropFrame耗时",String.format("%d ms",SystemClock.uptimeMillis()-startTime));
    }

    @Test
    public void test_StartResourceCost() {
       long startTime = SystemClock.uptimeMillis();

        QAPM.beginScene(QAPM.SCENE_ALL, QAPM.ModeResource);

        Log.i("启动区间性能耗时",String.format("%d ms",SystemClock.uptimeMillis()-startTime));
    }
}
