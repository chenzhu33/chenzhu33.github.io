package com.tencent.qapmsdk.test.TestDBOperation;

import android.app.Application;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.persist.DBHandler;
import com.tencent.qapmsdk.persist.DBHelper;
import com.tencent.qapmsdk.reporter.ResultObject;
import com.tencent.qapmsdk.test.TestEnv;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;


@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestUpdateReportedData {
    private static final String TAG = "TestUpdateReportedData";
    private DBHandler db;
    private ArrayList<ResultObject> list = new ArrayList<>(); // 存放从db中取出的ResultObject
    private ResultObject roGet; // 存放从数据库中取出的一条ResultObject数据

//    @Rule
//    public ActivityTestRule<MainActivity> mActivityRule = new ActivityTestRule<>(
//            MainActivity.class);

    @Test
    public void test_updateReportedData() throws Exception {
        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();
        QAPM.setProperty(QAPM.PropertyKeyAppInstance, app);
        QAPM.setProperty(QAPM.PropertyKeyAppId, TestEnv.APP_ID).setProperty(QAPM.PropertyKeyAppVersion, "2.1").setProperty(QAPM.PropertyKeySymbolId, "e6ae1282-ceb8-4237-89bd-2d23d00a8e33");
        QAPM.setProperty(QAPM.PropertyKeyUserId, TestEnv.USER_ID);
        QAPM.beginScene(QAPM.SCENE_ALL, QAPM.ModeDBIO);
        Thread.sleep(10000); // 等待app完成所有测试
        JSONObject params = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("dbName", "mySQL");
        data.put("dbIsWork", "true");
        params.put("dbStatus", data);
        ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, String.valueOf("1983559851"));
//        Context context = mActivityRule.getActivity().getBaseContext();
//        Assert.assertNotNull(context);
        db = DBHandler.getInstance(app);
        Assert.assertNotNull(db);
        db.open(); // 打开数据库
        db.clearResultObjects();// 执行操作前，先清空数据库
        Assert.assertTrue(list.isEmpty()); // 此时数据库应该为空

        db.insertResultObject(ro, PhoneUtil.getProcessName(Magnifier.sApp),Magnifier.productId,Magnifier.token); // 往数据库插入数据
        list = (ArrayList<ResultObject>) db.getAllResultObjects(PhoneUtil.getProcessName(Magnifier.sApp), Magnifier.productId, Magnifier.token, true);// 获取所有的上报数据
        roGet = list.get(0);
        Assert.assertEquals(1, list.size()); // 此时数据库中只有刚insert的一个数据
        Assert.assertTrue(roGet.isRealTime); // isRealTime == true
        Thread.sleep(500);
        int i = db.update(DBHelper.TABLE_RESULT_OBJECTS,list.get(0).dbId,1);
        Assert.assertTrue(i!=-1);
        Assert.assertTrue(i!=-2);
        Thread.sleep(2000);
        db.close();
    }
}

