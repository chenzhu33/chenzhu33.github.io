package com.tencent.qapmsdk.test.TestInputOutputInterface;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;


@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestSQLiteMonitorCreateFile {
    private static final String TAG = "TestSQLiteMonitorCreateFile";
    private Object monitor = null;

    @Before
    public void setUp() {
        try {
            Class<?> t = Class.forName("com.tencent.qapmsdk.io.SQLiteMonitor");
            Constructor<?> constructor = t.getDeclaredConstructor(String.class);
            constructor.setAccessible(true);
            monitor = constructor.newInstance("1.1");
        }
        catch (Exception e){
            Log.e("======", e.getMessage());
        }
        System.console();
    }

    @Test
    public void test_SQLiteMonitorCreateFile() throws Exception {
        Assert.assertNotNull(monitor);
        // 访问类的私有变量
        Field field = monitor.getClass().getDeclaredField("saveFile");
        field.setAccessible(true); // 允许访问
        File saveFile = (File) field.get(monitor); // 获得私有变量的值
//        Assert.assertNull(saveFile); // 未创建文件，文件路径saveFile == null

        Method method = monitor.getClass().getDeclaredMethod("createFile"); // 获取私有方法和参数
        method.setAccessible(true); // 允许访问
        method.invoke(monitor); // 调用被测类的方法

        saveFile = (File) field.get(monitor); // 重新获取私有变量的值
        Assert.assertNotNull(saveFile); // 已创建文件，文件路径saveFile != null
    }
}

