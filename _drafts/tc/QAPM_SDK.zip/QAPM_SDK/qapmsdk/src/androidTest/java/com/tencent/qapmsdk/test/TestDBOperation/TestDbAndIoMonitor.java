package com.tencent.qapmsdk.test.TestDBOperation;

import android.app.Application;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

import com.tencent.qapmsdk.common.ProcessStats;
import com.tencent.qapmsdk.io.IOMonitor;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.lang.reflect.Method;

@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestDbAndIoMonitor {

    private static final String TAG = "TestDbAndIoMonitor";
    @Test
    public void test_dbAndIoMoniterMemoryCost() throws Exception {

        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();

        long useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("before memory %d b",useMemory));

        IOMonitor ioMonitor = new IOMonitor(app,3,"2.3");
        ioMonitor.start();

        Thread.sleep(10000);

        useMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        Log.i(TAG,String.format("after memory %d b",useMemory));
    }


    @Test
    public void test_dbAndIoMoniterCPUCost() throws Exception {

        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();

        long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        long devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("dbAndIoMonitor use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));

        IOMonitor ioMonitor = new IOMonitor(app,3,"2.3");
        ioMonitor.start();

        Thread.sleep(10000);

        appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
        devUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
        Log.i(TAG,String.format("dbAndIoMonitor use cpu:%d",appUsage));
        Log.i(TAG,String.format("device use cpu:%d",devUsage));
    }

    @Test
    public void test_dbAndIoZipFile() throws Exception {
        Application app = (Application) InstrumentationRegistry.getTargetContext().getApplicationContext();
        IOMonitor ioMonitor = new IOMonitor(app,3,"2.3");
        ioMonitor.start();

        Class<?> SQLiteMonitor = Class.forName("com.tencent.qapmsdk.io.SQLiteMonitor");
        Assert.assertNotNull(SQLiteMonitor);
        Method createFile = SQLiteMonitor.getDeclaredMethod("createFile");
        createFile.setAccessible(true);
        createFile.invoke(null);

//        Thread.sleep(1000);

    }
}