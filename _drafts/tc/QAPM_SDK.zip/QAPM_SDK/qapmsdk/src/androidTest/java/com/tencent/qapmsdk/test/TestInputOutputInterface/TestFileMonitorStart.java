package com.tencent.qapmsdk.test.TestInputOutputInterface;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;

import com.tencent.qapmsdk.io.FileIOMonitor;
import com.tencent.qapmsdk.io.util.NativeMethodHook;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.lang.reflect.Field;
import java.lang.reflect.Method;


@RunWith(AndroidJUnit4.class)
@SmallTest
public class TestFileMonitorStart {
    private static final String TAG = "TestFileMonitorStart";
    private FileIOMonitor monitor = null;
    NativeMethodHook hook = null;

    @Test
    public void test_fileMonitorStart() throws Exception {
        monitor = FileIOMonitor.getInstance();
        Assert.assertNotNull(monitor);
        Field field = monitor.getClass().getDeclaredField("hook");
        field.setAccessible(true); // 允许访问


        Method method1 = monitor.getClass().getDeclaredMethod("setType", int.class);
        method1.setAccessible(true);
        method1.invoke(monitor,1);
        Method method2 = monitor.getClass().getDeclaredMethod("setAppVersion", String.class);
        method2.setAccessible(true);
        method2.invoke(monitor,"V1.0");
        // 调用start()方法
        Method method = monitor.getClass().getDeclaredMethod("start"); // 获取私有方法start和参数
        method.setAccessible(true); // 允许访问
        method.invoke(monitor); // 调用被测类的方法start()

        hook = (NativeMethodHook) field.get(monitor); // 再次获得私有变量的值
        Assert.assertNotNull(hook); // 已调用start()，hook != null
    }
}
