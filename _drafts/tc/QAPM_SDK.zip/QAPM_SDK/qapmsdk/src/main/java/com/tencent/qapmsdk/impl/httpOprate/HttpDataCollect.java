package com.tencent.qapmsdk.impl.httpOprate;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.NetworkWatcher;
import com.tencent.qapmsdk.impl.api.data.TransactionData;
import com.tencent.qapmsdk.impl.harvest.HttpLibType;
import com.tencent.qapmsdk.impl.instrumentation.QAPMNetworkProcessHeader;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionState;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionStateUtil;
import com.tencent.qapmsdk.impl.model.HttpDataModel;
import com.tencent.qapmsdk.impl.util.TraceUtil;

import java.io.IOException;
import java.util.Iterator;
import java.util.TreeMap;

import okhttp3.Headers;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class HttpDataCollect implements IDataCollect {
    private final static String TAG = "QAPM_Impl_HttpDataCollect";
    private volatile boolean canCollect = true;

    public HttpDataCollect() {
    }

    public boolean isCanCollect() {
        return this.canCollect;
    }

    public static void collectResponseInfo(QAPMTransactionState qapmTransactionState, String appData, int bytesRecevied, int statusCode) {
        if (appData != null && !"".equals(appData)) {
            qapmTransactionState.setAppData(appData);
        }

        qapmTransactionState.setStatusCode(statusCode);
        if (bytesRecevied >= 0) {
            qapmTransactionState.setBytesReceived((long)bytesRecevied);
        } else {
            qapmTransactionState.setBytesReceived(0L);
        }

    }

    public void collectException(QAPMTransactionState qapmTransactionState, IOException exception) {
        if (this.canCollect()) {
            Magnifier.ILOGUTIL.d(TAG, "okhttp3.0 ->httpError");
            QAPMTransactionStateUtil.setErrorCodeFromException(qapmTransactionState, exception);
            if (!qapmTransactionState.isComplete()) {
                TransactionData transactionData = qapmTransactionState.end();
                if (transactionData == null) {
                    return;
                }

                transactionData.setHttpLibType(HttpLibType.OkHttp);
//                QAPMAndroidAgentImpl var4 = QAPMAgent.getImpl();
//                if (var4 == null) {
//                    return;
//                }
//
//                HarvestConfiguration var5 = var4.n();
//                if (var5 == null) {
//                    return;
//                }

//                k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
                if (qapmTransactionState.isError()) {
                    String exceptionInfo = "";
                    if (qapmTransactionState.getException() != null) {
                        exceptionInfo = qapmTransactionState.getException();
                    }

                    Magnifier.ILOGUTIL.d(TAG, "okhttp3.0 ->error message:" + exceptionInfo);
                    //todo:存储数据
                    HttpDataModel.collectData(transactionData, exceptionInfo);
                    //h.a(qapmTransactionState.getUrl(), qapmTransactionState.getFormattedUrlParams(), qapmTransactionState.getAllGetRequestParams(), qapmTransactionState.getStatusCode(), exceptionInfo, qapmTransactionState.getRequestMethodType(), transactionData.h(), transactionData.f(), transactionData.w(), transactionData.l(), transactionData.d());
                }
                else{
                    HttpDataModel.collectData(transactionData);
                }
            }

        }
    }

    public void collectRequest(Request request, QAPMTransactionState qapmTransactionState) {
        if (this.canCollect()) {
            String url = request.url().toString();
            String params = null;
            if (url != null && url.contains("?")) {
                int index = url.indexOf("?");
                String host = url.substring(0, index);
                params = url.substring(index + 1);
                url = host;
            }

            qapmTransactionState.setUrl(url);
            qapmTransactionState.setUrlParams(params);
            qapmTransactionState.setAllGetRequestParams(params);
            qapmTransactionState.setMethodType(request.method());
            QAPMTransactionStateUtil.setRequestMethod(qapmTransactionState, request.method());
            qapmTransactionState.setCarrier(NetworkWatcher.activeNetworkCarrier());
            qapmTransactionState.setHttpLibType(HttpLibType.OkHttp);
            if (url != null) {
                collectHead(qapmTransactionState, request);
            }

        }
    }

    public void collectResponse(Response response, QAPMTransactionState qapmTransactionState) {
        if (this.canCollect()) {
            if (response == null) {
                Magnifier.ILOGUTIL.e(TAG, "okhttp3.0 ->CallBack.onResponse(response) response is null ");
            } else {
//                String var3 = response.header("X-Tingyun-Tx-Data");
//                if (Harvest.isCdn_enabled()) {
//                    QAPMAndroidAgentImpl var4 = QAPMAgent.getImpl();
//                    if (var4 != null) {
//                        String var5 = var4.n().getCdnHeaderName();
//                        a.a("cdnHeaderName  key : " + var5);
//                        if (var5 != null && !var5.isEmpty()) {
//                            String var6 = response.header(var5);
//                            qapmTransactionState.setCdnVendorName(var6 == null ? "" : var6);
//                            a.a("cdnHeaderName  value : " + var6);
//                        }
//                    }
//                }

                int statusCode = response.code();
                ResponseBody body = response.body();
                long contentLen = body == null ? 0L : body.contentLength();
                collectResponseInfo(qapmTransactionState, "", (int)contentLen, statusCode);
                collectOther(qapmTransactionState, response);
            }
        }
    }

    public boolean canCollect() {
        return TraceUtil.getCanMonitorHttp();
    }

    private static void collectOther(QAPMTransactionState transactionState, Response response) {

        TransactionData transactionData = transactionState.end();
        if (transactionData != null) {
            //k.a(var4, new com.networkbench.agent.impl.g.b.a(var4));
            if ((long)transactionState.getStatusCode() >= 400L) {
                TreeMap treeMap = new TreeMap();
                Headers headers = response.headers();
                if (headers != null && headers.size() > 0) {
                    Iterator iterator = headers.names().iterator();

                    while(iterator.hasNext()) {
                        String str = (String)iterator.next();
                        String headerInfo = headers.get(str);
                        if (headerInfo != null) {
                            treeMap.put(str, headerInfo);
                        }
                    }
                }

                String exceptionInfo = "";
                if (transactionState.getException() != null) {
                    exceptionInfo = transactionState.getException();
                }


                //todo:存储数据
                HttpDataModel.collectData(transactionData, treeMap, exceptionInfo);
                //h.a(transactionData.o(), transactionData.s(), transactionData.c(), transactionData.q(), response.message(), treeMap, exceptionInfo, transactionData.n(), transactionData.h(), transactionData.f(), transactionData.w(), transactionData.l(), transactionData.d());
            }
            else{
                HttpDataModel.collectData(transactionData);
            }

        }


    }

    private static void collectHead(QAPMTransactionState qapmTransactionState, final Request request) {
        QAPMTransactionStateUtil.processParamsFilter(qapmTransactionState, qapmTransactionState.getUrlParams());
        QAPMNetworkProcessHeader qapmNetworkProcessHeader = new QAPMNetworkProcessHeader() {
            public String getFilterHeader(String filterHeader) {
                return request != null && filterHeader != null ? request.header(filterHeader) : "";
            }
        };
        QAPMTransactionStateUtil.processHeaderParam(qapmTransactionState.getUrl(), qapmNetworkProcessHeader, qapmTransactionState);
    }
}
