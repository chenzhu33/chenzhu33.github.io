package com.tencent.qapmsdk.impl.report;

import android.os.Build;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.reporter.ResultObject;
import com.tencent.qapmsdk.sample.MonitorRunnable;
import com.tencent.qapmsdk.sample.SingleItem;
import com.tencent.qapmsdk.sample.TagItem;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Vector;

public class ReportRunnable implements Runnable {
    private static final String TAG = "QAPM_Impl_ReportRunnable";
    @Nullable
    private static volatile ReportRunnable instance = null;
    @Nullable
    private String processName = null;

    @Nullable
    public static ReportRunnable getInstance() {
        if(Magnifier.sApp != null){
            return getInstance(PhoneUtil.getProcessName(Magnifier.sApp));
        }
        else{
            return  getInstance("default");
        }
    }


    @Nullable
    public static ReportRunnable getInstance(String processName) {
        if (instance == null){
            synchronized (MonitorRunnable.class){
                if (instance == null){
                    instance = new ReportRunnable();
                }
            }
        }
        if (instance.processName == null){
            instance.processName = processName;
        }
        return instance;
    }


    @Override
    public void run() {
        reportMonitor();
        reportSingleton();
        MonitorReport.hasReport = false;
    }

    private void reportMonitor(){
        //备份后就将原始的清理了
        if (MonitorReport.getInstance().getMonitorItems().isEmpty()){
            return;
        }
        Vector<TagItem> monitorItems = (Vector<TagItem>) MonitorReport.getInstance().getMonitorItems().clone();
        MonitorReport.getInstance().getMonitorItems().clear();
        JSONObject params = new JSONObject();
        try{
            params.put("p_id", Magnifier.productId);
            params.put("version", Magnifier.info.version);
            params.put("uin", Magnifier.info.uin);
            params.put("manu", Build.MANUFACTURER);
            params.put("device", Build.MODEL);
            params.put("os", Build.VERSION.RELEASE);
            params.put("rdmuuid", Magnifier.info.uuid);
            params.put("plugin",  Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
            params.put("sdk_ver", Config.SDK_VERSION);

            if (Magnifier.sApp != null) {
                params.put("deviceid", PhoneUtil.getDeviceId(Magnifier.sApp));
            } else {
                params.put("deviceid", "0");
            }
            params.put("zone", "default");

            JSONArray immediates = new JSONArray();
            JSONArray manuTags = new JSONArray();


            params.put("immediates", immediates);


            for (TagItem tagItem : monitorItems){
                if (Double.isNaN(tagItem.eventTime) || tagItem.tagId == Long.MAX_VALUE){
                    continue;
                }
                JSONObject manuTag = new JSONObject();

                manuTag.put("event_time", tagItem.eventTime);
                manuTag.put("tag_id", tagItem.tagId);
                if (!Double.isNaN(tagItem.duringTime)){
                    manuTag.put("during_time", tagItem.duringTime);
                }
                manuTag.put("type", tagItem.type);
                manuTag.put("stage", tagItem.stage);
                manuTag.put("sub_stage", tagItem.subStage);
                manuTag.put("extra_info", tagItem.extraInfo);
                manuTag.put("process_name", processName);
                manuTag.put("is_slow", tagItem.isSlow ? 1 : 0);
                manuTags.put(manuTag);
            }
            params.put("manu_tags", manuTags);
            ResultObject ro = new ResultObject(0, "sample", true, 1, 1, params, true, false, Magnifier.info.uin);
            ReporterMachine.addResultObj(ro);
            CollectStatus.addCollectCount(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
        }
        catch (Exception e){
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
    }

    private void reportSingleton(){
        if (MonitorReport.getInstance().getSingleItems().isEmpty()){
            return;
        }
        Vector<SingleItem> singleItems = (Vector<SingleItem>) MonitorReport.getInstance().getSingleItems().clone();
        MonitorReport.getInstance().getSingleItems().clear();
        try {
            for (SingleItem singleItem : singleItems){
                JSONObject singletonJsonObject = new JSONObject();
                singletonJsonObject.put("stage", singleItem.stage);
                singletonJsonObject.put("event_time", singleItem.eventTime);
                singletonJsonObject.put("cost_time", singleItem.costTime);
                singletonJsonObject.put("stack", "");
                singletonJsonObject.put("plugin", Config.PLUGIN_QCLOUD_LOOPER_STACK);
                singletonJsonObject.put("extra_data", singleItem.extraData);
                ResultObject ro = new ResultObject(0, "sample", true, 1, 1, singletonJsonObject, true, false, Magnifier.info.uin);
                ReporterMachine.addResultObj(ro);
                CollectStatus.addCollectCount(Config.PLUGIN_QCLOUD_LOOPER_STACK);
            }

        }
        catch(JSONException e){
            Magnifier.ILOGUTIL.exception(TAG, e);
        }

    }

}
