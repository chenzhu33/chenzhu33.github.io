package com.tencent.qapmsdk.common;

import android.support.annotation.NonNull;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DateTimeUtils {
    public static String getFormatTime(long time, @NonNull String format) {
        if (time <= 0) {
            return null;
        }
        Date data = new Date (time);
        SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.US);
        return sdf.format(data);
    }
}