package com.tencent.qapmsdk.impl.instrumentation;

import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.NetworkWatcher;
import com.tencent.qapmsdk.impl.harvest.RequestMethodType;
import com.tencent.qapmsdk.impl.util.TraceUtil;

import java.io.IOException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.net.ssl.SSLException;


public class QAPMTransactionStateUtil {
    private final static String TAG = "QAPM_Impl_QAPMTransactionStateUtil";

    public QAPMTransactionStateUtil() {
    }

    public static void setUrlAndCarrier(QAPMTransactionState transactionState, HttpURLConnection conn) {
        String var2 = conn.getURL().toString();
        String var3 = null;
        if (var2.contains("?")) {
            int var4 = var2.indexOf("?");
            String var5 = var2.substring(0, var4);
            var3 = var2.substring(var4 + 1);
            var2 = var5;
        }

        transactionState.setUrl(var2);
        transactionState.setUrlParams(var3);
        transactionState.setAllGetRequestParams(var3);
        transactionState.setAllGetRequestParams(var3);
        transactionState.setCarrier(NetworkWatcher.activeNetworkCarrier());
    }

//    public static void setCrossProcessHeader(HttpURLConnection conn) {
//        try {
//            String var1 = h.j().T();
//            if (!TextUtils.isEmpty(var1) && h.j().S()) {
//                int var2 = h.U();
//                String var3 = h.a(var1, var2);
//                conn.setRequestProperty("X-Tingyun-Id", var3);
//            }
//        } catch (Exception var4) {
//            log.d("QAPMTransactionStateUtil  setCrossProcessHeader() has an error :" + var4);
//        }
//
//    }

    public static void setRequestMethod(QAPMTransactionState transaction, String requestmethod) {
        transaction.setRequestMethod(setRequestMethod(requestmethod));
    }

    public static RequestMethodType setRequestMethod(String requestmethod) {
        if (requestmethod.toUpperCase().equals("OPTIONS")) {
            return RequestMethodType.OPTIONS;
        } else if (requestmethod.toUpperCase().equals("GET")) {
            return RequestMethodType.GET;
        } else if (requestmethod.toUpperCase().equals("HEAD")) {
            return RequestMethodType.HEAD;
        } else if (requestmethod.toUpperCase().equals("POST")) {
            return RequestMethodType.POST;
        } else if (requestmethod.toUpperCase().equals("PUT")) {
            return RequestMethodType.PUT;
        } else if (requestmethod.toUpperCase().equals("DELETE")) {
            return RequestMethodType.DELETE;
        } else if (requestmethod.toUpperCase().equals("TRACE")) {
            return RequestMethodType.TRACE;
        } else {
            return requestmethod.toUpperCase().equals("CONNECT") ? RequestMethodType.CONNECT : RequestMethodType.GET;
        }
    }

    public static void processUrlParams(QAPMTransactionState transactionState, final HttpURLConnection conn) {
        processParamsFilter(transactionState, transactionState.getUrlParams());
        QAPMNetworkProcessHeader processHeader = new QAPMNetworkProcessHeader() {
            public String getFilterHeader(String filterHeader) {
                return conn.getRequestProperty(filterHeader);
            }
        };
        processHeaderParam(transactionState.getUrl(), processHeader, transactionState);
    }

    public static void inspectAndInstrumentResponse(QAPMTransactionState transactionState, HttpURLConnection conn) {
        try {
            if (!TraceUtil.getCanMonitorHttp()) {
                return;
            }

//            if (Harvest.isCdn_enabled()) {
//                QAPMAndroidAgentImpl var2 = QAPMAgent.getImpl();
//                if (var2 != null) {
//                    String var3 = var2.n().getCdnHeaderName();
//                    log.a("cdnHeaderName key : " + var3);
//                    if (var3 != null && !"".equals(var3)) {
//                        transactionState.setCdnVendorName(conn.getHeaderField(var3) == null ? "" : conn.getHeaderField(var3));
//                        log.a("cdnHeaderName value :" + conn.getHeaderField(var3));
//                    }
//                }
//            }

            String data = conn.getHeaderField("X-Tingyun-Tx-Data");
            if (data != null && !"".equals(data)) {
                Magnifier.ILOGUTIL.d(TAG, "header:" , data);
                transactionState.setAppData(data);
            }

            processUrlParams(transactionState, conn);
            int contentLength = conn.getContentLength();
            if (contentLength >= 0) {
                transactionState.setBytesReceived((long)contentLength);
            }

            Magnifier.ILOGUTIL.d(TAG, "content length:" , String.valueOf(contentLength));
            int statusCode = transactionState.getStatusCode();

            try {
                statusCode = conn.getResponseCode();
            } catch (IOException e1) {
            } catch (NullPointerException e2) {
            } catch (Exception e3) {
            }

            transactionState.setStatusCode(statusCode);
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, "Failed to retrieve response code due to underlying (Harmony?) NPE", e);
        }

    }

//    public static com.networkbench.agent.impl.b.h.c getAvalidUrlParam(ConcurrentHashMap<UrlFilter, com.networkbench.agent.impl.b.h.c> urlParamArray, String url) throws NullPointerException {
//        com.networkbench.agent.impl.b.h.c var2 = null;
//        Iterator var3 = urlParamArray.entrySet().iterator();
//
//        while(var3.hasNext()) {
//            Map.Entry var4 = (Map.Entry)var3.next();
//            UrlFilter var5 = (UrlFilter)var4.getKey();
//            if (var5.isAvalidUrl(url)) {
//                var2 = (com.networkbench.agent.impl.b.h.c)var4.getValue();
//                break;
//            }
//        }
//
//        return var2;
//    }

    public static String processParamsFilter(QAPMTransactionState QAPMTransactionState, String urlParam) {
        String url = QAPMTransactionState.getUrl();
        if (!TextUtils.isEmpty(url) && !TextUtils.isEmpty(urlParam)) {
            //todo:参数处理
//            Magnifier.ILOGUTIL.d(TAG, "processParam filter url:" , url , ", urlParam:" , urlParam);
//            ConcurrentHashMap var3 = HarvestConfiguration.getDefaultHarvestConfiguration().getUrlParamArray();
//            com.networkbench.agent.impl.b.h.c var4 = getAvalidUrlParam(var3, url);
//            if (null == var4) {
//                log.a("not find url param");
//                QAPMTransactionState.setUrlParams("");
//                return "";
//            } else {
//                String[] var5 = urlParam.split("&");
//                HashMap var6 = new HashMap();
//                String[] var7 = var5;
//                int var8 = var5.length;
//
//                int var9;
//                for(var9 = 0; var9 < var8; ++var9) {
//                    String var10 = var7[var9];
//                    if (var10 != null) {
//                        String[] var11 = var10.split("=");
//                        if (var11 != null && var11.length == 2) {
//                            var6.put(var11[0], var11[1]);
//                        }
//                    }
//                }
//
//                StringBuilder var13 = new StringBuilder();
//                if (var4.a != null && var4.a.length > 0) {
//                    String[] var14 = var4.a;
//                    var9 = var14.length;
//
//                    for(int var16 = 0; var16 < var9; ++var16) {
//                        String var17 = var14[var16];
//                        String var12 = (String)var6.get(var17);
//                        if (!TextUtils.isEmpty(var12)) {
//                            var13.append(var17).append("=").append(var12).append("&");
//                        }
//                    }
//                }
//
//                String var15 = var13.toString();
//                if (!TextUtils.isEmpty(var15)) {
//                    var15 = var15.substring(0, var15.length() - 1);
//                }
//
//                log.a(" find url param : " + var15);
//                QAPMTransactionState.setNewUrlParams(var15);
//                return var15;
//            }
            return "";
        }
        else {
            QAPMTransactionState.setUrlParams("");
            return "";
        }
    }

    public static void processHeaderParam(String url, QAPMNetworkProcessHeader qapmNetworkProcessHeader, QAPMTransactionState transactionState) {
        if (!TextUtils.isEmpty(url) && null != transactionState && qapmNetworkProcessHeader != null) {
            //todo:头处理
//            ConcurrentHashMap var3 = HarvestConfiguration.getDefaultHarvestConfiguration().getUrlParamArray();
//            com.networkbench.agent.impl.b.h.c var4 = getAvalidUrlParam(var3, url);
//            if (null != var4) {
//                StringBuilder var5 = new StringBuilder();
//                String[] var6 = var4.c;
//                if (null != var6 && var6.length > 0) {
//                    for(int var7 = 0; var7 < var6.length; ++var7) {
//                        String var8 = qapmNetworkProcessHeader.getFilterHeader(var6[var7]);
//                        if (!TextUtils.isEmpty(var8)) {
//                            var5.append(var6[var7]).append('=').append(var8).append('&');
//                        }
//                    }
//                }
//
//                String var9 = var5.toString();
//                if (!TextUtils.isEmpty(var9)) {
//                    var9 = var9.substring(0, var5.length() - 1);
//                }
//
//                transactionState.setFormattedUrlParams(var9);
//            }
        }
    }

    public static int inspectAndInstrument(QAPMTransactionState transactionState, int responseCode) {
        transactionState.setStatusCode(responseCode);
        transactionState.setBytesReceived(0L);
        return responseCode;
    }

    public static String getSanitizedStackTrace() {
        StringBuilder sb = new StringBuilder();
        StackTraceElement[] stack = Thread.currentThread().getStackTrace();
        int stackLength = 0;

        for(int i = 0; i < stack.length; ++i) {
            StackTraceElement stackTraceElement = stack[i];
            sb.append(stackTraceElement.toString());
            if (i <= stack.length - 1) {
                sb.append("\n");
            }

            ++stackLength;
            //todo:调整堆栈深度
            if (stackLength >= 1024) {
                break;
            }
        }

        return sb.toString();
    }

    public static void setErrorCodeFromException(QAPMTransactionState transactionState, Exception e) {
        if (e instanceof IOException) {
            if (isSocketECONNRESET(e)) {
                transactionState.setErrorCode(911, e.toString());
                transactionState.setStatusCode(911);
                return;
            }

            String message = e.getMessage();
            if (e != null && message != null && message.contains("ftruncate failed: ENOENT (No such file or directory)")) {
                transactionState.setErrorCode(917, e.toString());
                transactionState.setStatusCode(917);
                return;
            }
        }

        if (e instanceof UnknownHostException) {
            transactionState.setErrorCode(901, e.toString());
            transactionState.setStatusCode(901);
        } else if (e instanceof SocketTimeoutException) {
            transactionState.setErrorCode(903, e.toString());
            transactionState.setStatusCode(903);
        } else if (e instanceof ConnectException) {
            transactionState.setErrorCode(902, e.toString());
            transactionState.setStatusCode(902);
        } else if (e instanceof MalformedURLException) {
            transactionState.setErrorCode(900, e.toString());
            transactionState.setStatusCode(900);
        } else if (e instanceof SSLException) {
            transactionState.setErrorCode(908, e.toString());
            transactionState.setStatusCode(908);
        } else {
            transactionState.setErrorCode(-1, e.toString());
            transactionState.setStatusCode(-1);
        }

    }

    public static boolean isSocketECONNRESET(Exception e) {
        boolean isSocketECONNRESET = false;

        try {
            if (e != null) {
                if (e instanceof SocketException && e.getMessage().contains("recvfrom failed: ECONNRESET (Connection reset by peer)")) {
                    isSocketECONNRESET = true;
                }
            }
        } catch (Exception exception) {
            Magnifier.ILOGUTIL.exception(TAG, "isSocketECONNRESET error", exception);
        }

        return isSocketECONNRESET;
    }

}
