package com.tencent.qapmsdk.impl.instrumentation;

import android.os.Build;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.webview.WebViewX5Proxy;

import java.util.regex.Matcher;

public class QAPMWebLoadInstrument {
    private final static String TAG = "QAPM_Impl_QAPMWebLoadInstrument";
    public static int WEBVIEW_TAG = 20190623;

    public QAPMWebLoadInstrument() {
    }

    public static void setWebViewClient(WebView webView, WebViewClient webViewClient) {
        try {
            if (Build.VERSION.SDK_INT < 19) {
                webView.setWebViewClient(webViewClient);
                return;
            }

            if (WebViewX5Proxy.getInstance().getWebViewX5MonitorState()) {
                webView.getSettings().setJavaScriptEnabled(true);
                QAPMJavaScriptBridge javaScriptBridge = QAPMJavaScriptBridge.getInstance();
                webView.addJavascriptInterface(javaScriptBridge, "AndroidQAPMJsBridge");
                webView.setTag(WEBVIEW_TAG, WEBVIEW_TAG);
            }

//            if (s.a(Harvest.isHttp_network_enabled()) && h.j().S() && Harvest.isWebView_enabled() && h.j().d()) {
//                String var4 = webView.getSettings().getUserAgentString();
//                if (!TextUtils.isEmpty(var4) && !var4.contains("X-Tingyun-Id")) {
//                    webView.getSettings().setUserAgentString(var4 + " " + "X-Tingyun-Id" + "/" + crocessHeaderStr());
//                }
//            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, "set user agent failed:", e);
        }

        webView.setWebViewClient(webViewClient);
    }

    private static String crocessHeaderStr() {
//        if (h.j().S()) {
//            String var0 = h.a(h.j().T(), h.U());
//            if (!TextUtils.isEmpty(var0)) {
//                return var0;
//            }
//        }

        return "";
    }
}
