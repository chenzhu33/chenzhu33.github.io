package com.tencent.qapmsdk.reporter;

import android.os.Handler;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.APMnameVerifier;
import com.tencent.qapmsdk.common.Authorization;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.NetworkWatcher;
import com.tencent.qapmsdk.common.SSLFactory;
import com.tencent.qapmsdk.reporter.IReporter.ReportResultCallback;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.GZIPOutputStream;

import javax.net.ssl.HttpsURLConnection;

class JsonUploadRunnable extends BaseUploadRunnable {
    private static final String TAG = ILogUtil.getTAG(JsonUploadRunnable.class);

    public int PROTOCOL_HTTP = 0, PROTOCOL_HTTPS = 1;
    @Nullable
    private URL url = null;
    @Nullable
    private JSONObject jsonObj = null;
    private int remainingRetry = 0;
    @Nullable
    private ReportResultCallback callback = null;
    private int dbId = -1;
    @Nullable
    private Handler mHandler = null;

    private int protocol = PROTOCOL_HTTPS;    //

    JsonUploadRunnable(final URL u, final JSONObject obj, ReportResultCallback cb, int id, Handler h) {
        url = u;
        jsonObj = obj;
        callback = cb;
        dbId = id;
        mHandler = h;
    }
    
    @Override
    public boolean isSucceeded(String resp) {
        try {
            // Server traffic overload.
            if (TextUtils.isEmpty(resp)) return true;
            JSONObject result = new JSONObject(resp);
            int status = result.getInt("status");
            if (status == 1000 || status == 1495) {
                return true;
            } else if (status == 1408) {
                Authorization.GetToken(Magnifier.info.appId,false);
                return false;
            } else {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public void run() {
        DataOutputStream outStream = null;
        HttpURLConnection conn = null;
        long uploadtime = System.currentTimeMillis();
        GZIPOutputStream gzipos = null;

        protocol = getProtocol(url);

        try {
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(ReporterMachine.SOCKET_TIMEOUT_MILLI);
            conn.setReadTimeout(ReporterMachine.SOCKET_TIMEOUT_MILLI);
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-gzip");
            conn.setRequestProperty("Content-Encoding", "gzip");

            if (TextUtils.isEmpty(Magnifier.token) && !Authorization.GetToken(Magnifier.info.appId,true)) {
                return;
            }
            conn.setRequestProperty("Authorize",Magnifier.token);
            if (protocol==PROTOCOL_HTTPS){
                //这里如果返回为空则setSSLSocketFactory会抛异常，会被catch捕获，所以不用判空
                ((HttpsURLConnection)conn).setSSLSocketFactory(SSLFactory.getDefaultSSLSocketFactory());
                ((HttpsURLConnection)conn).setHostnameVerifier(APMnameVerifier.getInstance());
                ((HttpsURLConnection)conn).connect();
            }

            outStream = new DataOutputStream(conn.getOutputStream());
            gzipos = new GZIPOutputStream(outStream);
            gzipos.write(jsonObj.toString().getBytes("utf-8"));
            gzipos.finish();
            
            InputStream in = new BufferedInputStream(conn.getInputStream());
            String resp = NetworkWatcher.readStream(in);
            Magnifier.ILOGUTIL.i(TAG, resp);
            boolean uploadOK = isSucceeded(resp);
            if (uploadOK) {
                if (callback != null) callback.onSuccess(dbId);
            } else if (remainingRetry > 0) {
                remainingRetry = remainingRetry - 1;
                int num = (int) (Math.random() * 5 + 2);
                mHandler.postDelayed(this, num * 1000);
            } else {
                if (callback != null) {
                    callback.onFailure(0, uploadtime, ReporterMachine.ERROR_OTHER, resp, url.toString() + "?" + jsonObj.toString());
                }
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
            if (remainingRetry > 0) {
                remainingRetry = remainingRetry - 1;
                mHandler.postDelayed(this, 30 * 60 * 1000);
            }
        } catch (OutOfMemoryError e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
            remainingRetry = 0;
            if (callback != null) {
                try {
                    int plugin = jsonObj.getInt("plugin");
                    // TODO: define a value for OOM in the response code field
                    callback.onFailure(plugin, uploadtime, ReporterMachine.ERROR_OOM, "OutOfMemoryError", url.toString() + "?" + jsonObj.toString());
                } catch (Exception e1) {
                    Magnifier.ILOGUTIL.exception(TAG, e1);
                }
                //jsonObj.toString()可能oom
                catch (OutOfMemoryError e1){
                    Magnifier.ILOGUTIL.exception(TAG, e1);
                }

            }
        } catch (Throwable t) {
            Magnifier.ILOGUTIL.exception(TAG, t);
            remainingRetry = 0;
        } finally {
            if (null != gzipos) {
                try {
                    gzipos.close();
                    gzipos = null;
                } catch (IOException e) {
                    Magnifier.ILOGUTIL.exception(TAG, e);
                }
            }
            if (null != outStream) {
                try {
                    outStream.close();
                    outStream = null;
                } catch (IOException e) {
                    Magnifier.ILOGUTIL.exception(TAG, e);
                }
            }
            if (null != conn) {
                conn.disconnect();
                conn = null;
            }
        }
    }

    private int getProtocol(URL url){
        if(url.getProtocol().equals("http")){
            return PROTOCOL_HTTP;
        }
        return PROTOCOL_HTTPS;
    }
}