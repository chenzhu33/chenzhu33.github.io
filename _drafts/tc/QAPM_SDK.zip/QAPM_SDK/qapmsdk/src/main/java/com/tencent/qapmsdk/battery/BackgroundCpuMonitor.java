package com.tencent.qapmsdk.battery;

class BackgroundCpuMonitor {
    private static final boolean DEBUG = false;
    // 配置格式:灰度采样率；正式采样率；低端机进程cpu告警线；低端机msf线程告警线；正常机器进程cpu告警线；正常机器msf线程cpu告警线；单日最大上报次数；是否自动染色
    static final String DEBUG_CFG = DEBUG ? "1;1;8;8;1;1;3;1" : "1;1;8;8;5;5;3;1";
    //static final String PUB_CFG = "0.1;0;10;5;10;5;2;0";
}