package com.tencent.qapmsdk.common;

/**
 * Created by nickyliu on 2017/10/31.
 */

public interface BaseListener {
}