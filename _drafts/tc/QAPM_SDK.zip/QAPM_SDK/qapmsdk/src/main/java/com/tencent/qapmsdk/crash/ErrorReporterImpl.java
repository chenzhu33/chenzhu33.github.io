package com.tencent.qapmsdk.crash;

import android.app.Application;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.crash.builder.LastActivityManager;
import com.tencent.qapmsdk.crash.builder.ReportBuilder;
import com.tencent.qapmsdk.crash.builder.ReportExecutor;
import com.tencent.qapmsdk.crash.config.CoreConfiguration;
import com.tencent.qapmsdk.crash.data.CrashReportDataFactory;
import com.tencent.qapmsdk.crash.util.ProcessFinisher;
import java.util.HashMap;
import java.util.Map;

public class ErrorReporterImpl implements Thread.UncaughtExceptionHandler, ErrorReporter {

    private static final String LOG_TAG = ILogUtil.getTAG(ErrorReporterImpl.class);
    private volatile static ErrorReporterImpl instance;
    private final Application context;
    private final Thread.UncaughtExceptionHandler defaultExceptionHandler;
    private final Map<String, String> customData = new HashMap<>();
    private final ReportExecutor reportExecutor;
    private volatile Boolean isStart = false;

    private final static String CRASH_TYPE = "CRASH_TYPE";

    private ErrorReporterImpl(Application context, @NonNull CoreConfiguration config, boolean enabled){
        this.context = context;

        final CrashReportDataFactory crashReportDataFactory = new CrashReportDataFactory(context, config);
        crashReportDataFactory.collectStartUp();

        defaultExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();

        final LastActivityManager lastActivityManager = new LastActivityManager(this.context);
        final ProcessFinisher processFinisher = new ProcessFinisher(context, true, lastActivityManager);

        reportExecutor = new ReportExecutor(context, config, crashReportDataFactory , defaultExceptionHandler, processFinisher, lastActivityManager);
        reportExecutor.setEnabled(enabled);
    }

    public void start() {
        if(!isStart){
            Thread.setDefaultUncaughtExceptionHandler(this);
            isStart = true;
            Magnifier.ILOGUTIL.i(LOG_TAG, "init caught java crash ok.");
        }

    }

    @Override
    public void uncaughtException(Thread thread, Throwable ex) {

        // If we're not enabled then just pass the Exception on to the defaultExceptionHandler.
        if (!reportExecutor.isEnabled()) {
            Magnifier.ILOGUTIL.i(LOG_TAG, "caught exception is not enable.");
            reportExecutor.handReportToDefaultExceptionHandler(thread, ex);
            return;
        }
        try {
            Magnifier.ILOGUTIL.exception(LOG_TAG,"caught a " + ex.getClass().getSimpleName() + " for " + context.getPackageName(), ex);

            customData.put(CRASH_TYPE, "Java");
            // Generate and send crash report
            new ReportBuilder()
                    .uncaughtExceptionThread(thread)
                    .exception(ex)
                    .customData(customData)
                    .endApplication()
                    .build(reportExecutor);

        } catch (Exception fatality) {
            // ACRA failed. Prevent any recursive call to ACRA.uncaughtException(), let the native reporter do its job.
            Magnifier.ILOGUTIL.exception(LOG_TAG, "failed to capture the error - handing off to native error reporter.", fatality);
            reportExecutor.handReportToDefaultExceptionHandler(thread, ex);
        }
    }

    public void buildData(Thread thread, Throwable e){

        customData.put(CRASH_TYPE, "Native");
        new ReportBuilder()
                .uncaughtExceptionThread(thread)
                .customData(customData)
                .exception(e)
                .endApplication()
                .build(reportExecutor);
    }

    public void unregister() {
        Thread.setDefaultUncaughtExceptionHandler(defaultExceptionHandler);
    }

    @Override
    public String putCustomData(@NonNull String key, String value) {
        return customData.put(key, value);
    }

    @Override
    public String removeCustomData(@NonNull String key) {
        return customData.remove(key);
    }

    @Override
    public void clearCustomData() {
        customData.clear();
    }

    @Override
    public String getCustomData(@NonNull String key) {
        return customData.get(key);
    }

    @Override
    public void handleSilentException(@Nullable Throwable e) {
        new ReportBuilder()
                .exception(e)
                .customData(customData)
                .sendSilently()
                .build(reportExecutor);
    }

    @Override
    public void setEnabled(boolean enabled) {

    }

    @Override
    public void handleException(@Nullable Throwable e, boolean endApplication) {
        final ReportBuilder builder = new ReportBuilder();
        builder.exception(e)
                .customData(customData);
        if (endApplication) {
            builder.endApplication();
        }
        builder.build(reportExecutor);
    }

    @Override
    public void handleException(@Nullable Throwable e) {
        handleException(e, false);
    }

    public static ErrorReporterImpl getInstance(@NonNull Application context, @NonNull CoreConfiguration config) {
        if (instance==null) {
            synchronized(ErrorReporterImpl.class) {
                if (instance == null) {
                    instance = new ErrorReporterImpl(context, config, true);
                }
            }
        }
        return instance;
    }
}
