package com.tencent.qapmsdk.impl.appstate;

import com.tencent.qapmsdk.impl.instrumentation.QAPMTraceUnit;
import com.tencent.qapmsdk.impl.instrumentation.QAPMUnit;
import com.tencent.qapmsdk.impl.instrumentation.TraceType;

public class MonitorAdapter {
    public QAPMMonitorThreadLocal qapmMonitorThreadLocal;
    public SectionHarve sectionHarve;
    public TraceType.CONTEXT traceType;

    protected MonitorAdapter(QAPMTraceUnit traceUnit, long threshold, TraceType.CONTEXT traceType) {
        this.sectionHarve = initSectionHarve(traceUnit, threshold, traceType);
        this.traceType = traceType;
        this.qapmMonitorThreadLocal = QAPMMonitorThreadLocal.getInstance();
    }

    public static SectionHarve initSectionHarve(QAPMTraceUnit qapmTraceUnit, long threshold, TraceType.CONTEXT traceType){
        return new SectionHarve(qapmTraceUnit, threshold, traceType);
    }

    public static MonitorAdapter newOne(String metricName, long threshold, TraceType.CONTEXT traceType){
        return newOne(metricName, "", threshold,  traceType);
    }

    public static MonitorAdapter newOne(String metricName, String subMetricName, long threshold, TraceType.CONTEXT traceType){
        QAPMTraceUnit qapmTraceUnit = new QAPMTraceUnit();
        qapmTraceUnit.metricName = metricName;
        qapmTraceUnit.subMetricName = subMetricName;
        MonitorAdapter monitorAdapter = new MonitorAdapter(qapmTraceUnit, threshold, traceType);
        monitorAdapter.getQapmMonitorThreadLocal().push(qapmTraceUnit, true);
        return monitorAdapter;
    }


    public QAPMMonitorThreadLocal getQapmMonitorThreadLocal()
    {
        return this.qapmMonitorThreadLocal;
    }

    public void addMonitorUnit(QAPMTraceUnit qapmTraceUnit){
        this.qapmMonitorThreadLocal.push(qapmTraceUnit, true);
    }

    public void deleteMonitorUnit(boolean checkTime){
        try{
            QAPMUnit lastUnit = this.qapmMonitorThreadLocal.threadQapmUnit();
            if (lastUnit == null) {
                return;
            }
            this.qapmMonitorThreadLocal.pop(checkTime);

        } catch (Exception e){
        }
    }

    public SectionHarve finishMonitor(){
        if (this.sectionHarve == null){
            return null;
        }
        else {
            return this.sectionHarve.exitTrace();
        }
    }

}
