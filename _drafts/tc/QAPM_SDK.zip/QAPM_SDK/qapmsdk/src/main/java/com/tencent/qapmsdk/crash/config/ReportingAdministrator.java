package com.tencent.qapmsdk.crash.config;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.crash.builder.LastActivityManager;
import com.tencent.qapmsdk.crash.builder.ReportBuilder;
import com.tencent.qapmsdk.crash.data.CrashReportData;
import com.tencent.qapmsdk.crash.plugins.Plugin;

public interface ReportingAdministrator extends Plugin {
    /**
     * Determines if report collection should start
     *
     * @param context       a context
     * @param config        the current config
     * @param reportBuilder the reportBuilder for the report about to be collected
     * @return if this report should be collected
     */
     boolean shouldStartCollecting(@NonNull Context context, @NonNull CoreConfiguration config, @NonNull ReportBuilder reportBuilder);

    /**
     * Determines if a collected report should be sent
     *
     * @param context         a context
     * @param config          the current config
     * @param crashReportData the collected report
     * @return if this report should be sent
     */
    boolean shouldSendReport(@NonNull Context context, @NonNull CoreConfiguration config, @NonNull CrashReportData crashReportData);

    /**
     * notifies the user about a dropped report
     *
     * @param context a context
     * @param config  the current config
     */
    void notifyReportDropped(@NonNull Context context, @NonNull CoreConfiguration config);

    boolean shouldFinishActivity(@NonNull Context context, @NonNull CoreConfiguration config, LastActivityManager lastActivityManager);

    /**
     * Determines if the application should be killed
     *
     * @param context         a context
     * @param config          the current config
     * @param reportBuilder   the reportBuilder for the report about to be collected
     * @param crashReportData the collected report
     * @return if the application should be killed
     */
    boolean shouldKillApplication(@NonNull Context context, @NonNull CoreConfiguration config, @NonNull ReportBuilder reportBuilder, @Nullable CrashReportData crashReportData);
}
