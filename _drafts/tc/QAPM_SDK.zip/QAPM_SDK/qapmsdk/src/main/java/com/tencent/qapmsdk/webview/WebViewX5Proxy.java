package com.tencent.qapmsdk.webview;

import android.nfc.Tag;
import android.os.Build;
import android.os.SystemClock;
import android.webkit.ValueCallback;
import android.webkit.WebView;

import com.tencent.qapmsdk.Magnifier;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;

public class WebViewX5Proxy {
    private final static String TAG = "QAPM_WebView_WebViewX5Proxy";
    private volatile static WebViewX5Proxy x5;
    private boolean webViewX5MonitorState;
    private ConcurrentLinkedQueue<JSONObject> x5Datas = new ConcurrentLinkedQueue<JSONObject>();
    private final int MAX_QUEUE = 20;
    private JSONObject frameData;
    private Method x5EvaluateJavascript = null;

    public WebViewX5Proxy(){
        webViewX5MonitorState = false;
        try {
            Class x5WebView = Class.forName("com.tencent.smtt.sdk.WebView");
            Class valueCallBack = Class.forName("android.webkit.ValueCallback");
            Class[] evaluteParames = new Class[]{String.class, valueCallBack};
            x5EvaluateJavascript = x5WebView.getDeclaredMethod("evaluateJavascript", evaluteParames);
            x5EvaluateJavascript.setAccessible(true);
        }
        catch (Exception e){
            Magnifier.ILOGUTIL.e(TAG, "cannot reflect x5 webview evaluateJavascript");
        }
    }

    public static WebViewX5Proxy getInstance() {
        if (null == x5) {
            synchronized(WebViewX5Proxy.class) {
                if (null == x5) {
                    x5 = new WebViewX5Proxy();
                }
            }
        }
        return x5;
    }

    void setWebViewX5MonitorState(boolean state){
        webViewX5MonitorState = state;
    }

    //x5内核反射函数，用于判断是否开启内核监控
    public  boolean getWebViewX5MonitorState(){
        return webViewX5MonitorState;
    }

    //x5内核反射函数，用于设置web基础性能数据
    public void addMonitorData(final JSONObject data){
        boolean isCallBack = false;
        if (x5Datas.size() > 20){
            x5Datas.poll();
        }
        try {
            data.put(WebViewDataType.IS_SYSTEM_KERNEL, 0);
            data.put(WebViewDataType.BASE_TIME, System.currentTimeMillis() - SystemClock.uptimeMillis());
            if(data.getString("url").equals(this.frameData.getString("url"))){
                mergerJson(data, this.frameData);
            }

            //只支持4.4以上
            if (Magnifier.info.wbListener != null && Build.VERSION.SDK_INT >= 19){
                Object webView = Magnifier.info.wbListener.saveWebView();
                if (webView instanceof WebView){
                    ((WebView) webView).evaluateJavascript("javascript:window.qapmAndroidBreadCrumb()", new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                            afterCallJs(data, value);
                        }
                    });
                    isCallBack = true;
                }
                else {
                    //调用x5接口
                    if (x5EvaluateJavascript != null){
                        try {
                            x5EvaluateJavascript.invoke(webView, "javascript:window.qapmAndroidBreadCrumb()", new ValueCallback<String>() {
                                @Override
                                public void onReceiveValue(String value) {
                                    afterCallJs(data, value);
                                }
                            });
                            isCallBack = true;
                        }
                        catch (Exception e){
                            Magnifier.ILOGUTIL.exception(TAG, "invoke webview evaluateJavascript error:", e);
                        }
                    }
                }
            }
            else {
                data.put(WebViewDataType.BREAD_CRUMB_ID, "");
            }
            if (!isCallBack){
                x5Datas.add(data);
            }
        } catch (JSONException e){
            Magnifier.ILOGUTIL.exception(TAG, e);
        }

    }

    //x5内核反射函数，用于设置内核的frame数据
    public void addFrameMonitorData(JSONObject frameDate){
        this.frameData = frameDate;
    }

    private JSONObject mergerJson(JSONObject monitorData, JSONObject frameData) throws JSONException{
        Iterator<String>iterator = frameData.keys();
        while (iterator.hasNext()){
            String key = iterator.next();
            if (key.equals("url")){
                continue;
            } else {
                monitorData.put(key, frameData.getLong(key));
            }
        }
        return monitorData;
    }

    ConcurrentLinkedQueue<JSONObject> getMonitorData(){
        return x5Datas;
    }

    public void clear(){
        this.x5Datas.clear();
    }

    private void afterCallJs(JSONObject jsonObject, String breadCrumbId){
        try{
            breadCrumbId = breadCrumbId.replaceAll("\"","");
            if (breadCrumbId.equals("null")){
                breadCrumbId = "";
            }
            jsonObject.put(WebViewDataType.BREAD_CRUMB_ID, breadCrumbId);
        }
        catch (Exception e){

        }
        x5Datas.add(jsonObject);

    }
}
