package com.tencent.qapmsdk.persist;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "sdk_db";
    private static final int DB_VERSION = 5;
    
    // Table result_objects
    public static final String TABLE_RESULT_OBJECTS = "result_objects";
    public static final String COLUMN_PROCESSNAME = "process_name";
    public static final String COLUMN_PRODUCTID = "p_id";
    public static final String COLUMN_VERSION = "version";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_PARAMS = "params";
    public static final String COLUMN_ISREALTIME = "is_real_time";
    public static final String COLUMN_UIN = "uin";
    public static final String COLUMN_STATUS = "status";
    public static final String COLUMN_OCCURTIME = "occur_time";
    private static final String CREATE_RESULT_OBJECTS = "CREATE TABLE " + TABLE_RESULT_OBJECTS + " (" +
        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
        COLUMN_PROCESSNAME + " TEXT," +
        COLUMN_PRODUCTID + " INT," +
        COLUMN_VERSION + " TEXT," +
        COLUMN_PARAMS + " TEXT," +
        COLUMN_ISREALTIME + " TINYINT," +
        COLUMN_UIN + " TEXT," +
        COLUMN_STATUS + " TINYINT," +
        COLUMN_OCCURTIME + " BIGINT" +
        ");";
    
    // Table upload_errors
    public static final String TABLE_UPLOAD_ERRORS = "upload_errors";
    public static final String COLUMN_PLUGIN = "plugin";
    public static final String COLUMN_UPLOADTIME = "uploadtime";
    public static final String COLUMN_ERROR_CODE = "error_code";
    public static final String COLUMN_ERROR_MSG = "error_msg";
    public static final String COLUMN_HTTP_GET = "http_get";
    private static final String CREATE_UPLOAD_ERRORS = "CREATE TABLE " + TABLE_UPLOAD_ERRORS + " (" +
        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
        COLUMN_PROCESSNAME + " TEXT," +
        COLUMN_PRODUCTID + " INT," +
        COLUMN_VERSION + " TEXT," +
        COLUMN_UIN + " TEXT," +
        COLUMN_PLUGIN + " SMALLINT," +
        COLUMN_UPLOADTIME + " BIGINT," +
        COLUMN_ERROR_CODE + " SMALLINT," +
        COLUMN_ERROR_MSG + " TEXT," +
        COLUMN_HTTP_GET + " TEXT," +
        COLUMN_STATUS + " TINYINT" +
        ");";
    
    // Table drop frame
    public static final String TABLE_DROP_FRAME = "drop_frame";
    public static final String COLUMN_SCENE = "scene";
    public static final String COLUMN_STATE = "state";
    public static final String COLUMN_DROP_DURATION = "drop_duration";
    public static final String COLUMN_DROP_COUNT = "drop_count";
    public static final String COLUMN_RANGE_0 = "range_0";
    public static final String COLUMN_RANGE_1 = "range_1";
    public static final String COLUMN_RANGE_2_4 = "range_2_4";
    public static final String COLUMN_RANGE_4_8 = "range_4_8";
    public static final String COLUMN_RANGE_8_15 = "range_8_15";
    public static final String COLUMN_RANGE_OVER_15 = "range_over_15";
    private static final String CREATE_DROP_FRAME = "CREATE TABLE " + TABLE_DROP_FRAME + " (" +
        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
        COLUMN_PROCESSNAME + " TEXT," +
        COLUMN_PRODUCTID + " INT," +
        COLUMN_VERSION + " TEXT," +
        COLUMN_UIN + " TEXT," +
        COLUMN_SCENE + " TEXT," +
        COLUMN_STATE + " TINYINT," +
        COLUMN_DROP_DURATION + " FLOAT," +
        COLUMN_DROP_COUNT + " INT," +
        COLUMN_RANGE_0 + " INT," +
        COLUMN_RANGE_1 + " INT," +
        COLUMN_RANGE_2_4 + " INT," +
        COLUMN_RANGE_4_8 + " INT," +
        COLUMN_RANGE_8_15 + " INT," +
        COLUMN_RANGE_OVER_15 + " INT," +
        COLUMN_STATUS + " TINYINT," +
        COLUMN_OCCURTIME + " BIGINT" +
        ");";
    
    // Table configs
    public static final String TABLE_CONFIGS = "configs";
    public static final String COLUMN_THRESHOLD = "threshold";
    public static final String COLUMN_MAX_REPORT_NUM = "max_report_num";
    public static final String COLUMN_EVENT_SAMPLE_RATIO = "event_sample_ratio";
    public static final String COLUMN_STACK_DEPTH = "stack_depth";
    private static final String CREATE_CONFIGS = "CREATE TABLE " + TABLE_CONFIGS + " (" +
        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
        COLUMN_PRODUCTID + " INT," +
        COLUMN_VERSION + " TEXT," +
        COLUMN_PLUGIN + " SMALLINT," +
        COLUMN_THRESHOLD + " FLOAT," +
        COLUMN_MAX_REPORT_NUM + " INT," +
        COLUMN_EVENT_SAMPLE_RATIO + " FLOAT," +
        COLUMN_STACK_DEPTH + " INT" +
        ");";

    //Table anr stack
    public static final String TABLE_ANR_STACK = "anr_stack";
    public static final String COLUMN_STACK = "stack";
    private static final String CREATE_ANR_STACK = "CREATE TABLE " + TABLE_ANR_STACK + " (" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            COLUMN_PROCESSNAME + " TEXT," +
            COLUMN_PRODUCTID + " INT," +
            COLUMN_VERSION + " TEXT," +
            COLUMN_UIN + " TEXT," +
            COLUMN_STACK + " TEXT" +
            ");";

    @Nullable
    private volatile static DBHelper helper = null;
    
    private DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DB_VERSION);
    }
    
    @Nullable
    static DBHelper getInstance(Context context) {
        if (helper == null) {
            synchronized(DBHelper.class) {
                if (helper == null) {
                    helper = new DBHelper(context);
                }
            }
        }
        return helper;
    }

    @Override
    public void onCreate(@NonNull SQLiteDatabase db) {
        db.execSQL(CREATE_RESULT_OBJECTS);
        db.execSQL(CREATE_UPLOAD_ERRORS);
        db.execSQL(CREATE_DROP_FRAME);
        db.execSQL(CREATE_CONFIGS);
        db.execSQL(CREATE_ANR_STACK);
    }

    @Override
    public void onUpgrade(@NonNull SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("Drop table if exists " + TABLE_RESULT_OBJECTS);
        db.execSQL("Drop table if exists " + TABLE_UPLOAD_ERRORS);
        db.execSQL("Drop table if exists " + TABLE_DROP_FRAME);
        db.execSQL("Drop table if exists " + TABLE_CONFIGS);
        db.execSQL("Drop table if exists " + TABLE_ANR_STACK);
        onCreate(db);
    }
}