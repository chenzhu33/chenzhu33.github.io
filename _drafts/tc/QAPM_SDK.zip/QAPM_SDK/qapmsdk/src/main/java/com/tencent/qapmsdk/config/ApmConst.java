package com.tencent.qapmsdk.config;

/**
 * Created by anthonytan on 2018/5/15.
 */

public class ApmConst {
    public static final int ModeLeakInspector = 1, ModeFileIO = 2, ModeDBIO = 4, ModeLooper = 8,
            ModeCeiling = 16, ModeBattery = 32, ModeResource = 64, ModeDropFrame = 128 ,
            ModeANR = 256, ModeCrash = 512, ModeWebView = 1024, ModeHTTP = 2048;
    public static final int ModeAll = ModeLeakInspector | ModeFileIO | ModeDBIO | ModeLooper | ModeCeiling | ModeBattery | ModeResource | ModeDropFrame | ModeANR | ModeCrash | ModeWebView | ModeHTTP;
    public static final int ModeStable = ModeLooper | ModeResource | ModeDropFrame;

    public static final int LevelOff = 0, LevelError = 1, LevelWarn = 2, LevelInfo = 3, LevelDebug = 4, LevelVerbos = 5;
}
