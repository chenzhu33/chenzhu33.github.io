package com.tencent.qapmsdk.impl.instrumentation.io;

public interface QAPMStreamCompleteListener {
    void streamComplete(QAPMStreamCompleteEvent qapmStreamCompleteEvent);

    void streamError(QAPMStreamCompleteEvent qapmStreamCompleteEvent);
}