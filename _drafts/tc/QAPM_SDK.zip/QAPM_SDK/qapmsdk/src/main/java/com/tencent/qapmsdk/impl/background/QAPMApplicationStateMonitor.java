package com.tencent.qapmsdk.impl.background;

import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.impl.appstate.AppStateTimeInfo;
import com.tencent.qapmsdk.impl.instrumentation.QAPMAppInstrumentation;

import java.util.ArrayList;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public class QAPMApplicationStateMonitor implements Runnable{

    private long backgroundTime = 0L;
    private long activitySurviveCount = 0L;
    private final int SnoozeTimenterval;
    private final Object firstLock = new Object();
    private final Object secondLock = new Object();
    private boolean applicationNotInSnooze = true;
    private static QAPMApplicationStateMonitor instance;
    //后台休眠时间
    public static final int ALTERNATEPERIOD = 30000;

    QAPMApplicationStateMonitor(int initialDelay, int period, TimeUnit timeUnit, int snoozeTimeInMilliseconds) {
        this.activitySurviveCount = 0L;
        this.backgroundTime = 0L;
        this.applicationNotInSnooze = true;
        this.SnoozeTimenterval = snoozeTimeInMilliseconds;

        ScheduledThreadPoolExecutor scheduledThreadPoolExecutor = new ScheduledThreadPoolExecutor(1, new ThreadFactory() {
            public Thread newThread(Runnable r) {
                return new Thread(r, "[QAPMAgent] App State Monitor");
            }
        });
        scheduledThreadPoolExecutor.scheduleAtFixedRate(this, (long)initialDelay, (long)period, timeUnit);
    }



    public static QAPMApplicationStateMonitor getInstance()
    {
        if (instance == null) {
            instance = new QAPMApplicationStateMonitor();
        }
        return instance;
    }

    private QAPMApplicationStateMonitor()
    {
        this(5, 5, TimeUnit.SECONDS, ALTERNATEPERIOD);
    }


    public void run() {
        synchronized(this.firstLock) {
            if (this.getSnoozeTime() >= (long)this.SnoozeTimenterval && this.applicationNotInSnooze) {
                this.applicationNotInSnooze = false;
            }

        }
    }

    public void activityStopped(String activityName) {
        synchronized(this.firstLock) {
            synchronized(this.secondLock) {
                --this.activitySurviveCount;
                if (this.activitySurviveCount == 0L) {
                    AppStateTimeInfo.lastBackgroundTime = System.currentTimeMillis();
                    QAPMAppInstrumentation.isAppInBackground = true;
                    this.backgroundTime = System.currentTimeMillis();
                }
            }

        }
    }


    public void activityStarted(String activityName) {
        QAPMAppInstrumentation.activityStartBeginIns(activityName);
        synchronized(this.firstLock) {
            synchronized(this.secondLock) {
                ++this.activitySurviveCount;
                if (this.activitySurviveCount == 1L) {
                    this.backgroundTime = 0L;
                }
            }

            if (!this.applicationNotInSnooze) {
                QAPMAppInstrumentation.appStateTimeInfo.hasSnooze = true;
                this.applicationNotInSnooze = true;
            }

        }
    }

    private long getSnoozeTime()
    {
        synchronized (this.firstLock)
        {
            synchronized (this.secondLock)
            {
                if (this.backgroundTime == 0L) {
                    return 0L;
                }
                return System.currentTimeMillis() - this.backgroundTime;
            }
        }
    }
}
