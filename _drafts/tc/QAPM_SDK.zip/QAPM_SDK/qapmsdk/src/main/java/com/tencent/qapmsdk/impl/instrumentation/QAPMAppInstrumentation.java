package com.tencent.qapmsdk.impl.instrumentation;

import android.content.Context;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.appstate.CommonActivityTrace;
import com.tencent.qapmsdk.impl.appstate.AppStateTimeInfo;
import com.tencent.qapmsdk.impl.appstate.QAPMActivityTrace;

public class QAPMAppInstrumentation {
    private final static String TAG = "QAPM_Impl_QAPMAppInstrumentation";
    public static AppStateTimeInfo appStateTimeInfo;
    public static QAPMActivityTrace activityTrace = new QAPMActivityTrace();
    public static volatile boolean isAppInBackground;

    public QAPMAppInstrumentation() {
    }

    @QAPMReplaceCallSite
    public static void attachBaseContextBeginIns(Context context) {
        try {
            appStateTimeInfo.attachBaseContextBeginIns(context);
        } catch (Throwable e) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMAppInstrumentation  attachBaseContextBeginIns() has an error :" , e);
        }

    }

    @QAPMReplaceCallSite
    public static void attachBaseContextEndIns() {
        try {
            appStateTimeInfo.attachBaseContextEndIns();
        } catch (Throwable e) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMAppInstrumentation  attachBaseContextEndIns() has an error :" , e);
        }

    }

    @QAPMReplaceCallSite
    public static void applicationCreateBeginIns() {
        try {
            appStateTimeInfo.applicationCreateBeginIns();
        } catch (Throwable e) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMAppInstrumentation  applicationCreateBeginIns() has an error :" , e);
        }

    }

    @QAPMReplaceCallSite
    public static void applicationCreateEndIns() {
        try {
            appStateTimeInfo.applicationCreateEndIns();
        } catch (Throwable e) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMAppInstrumentation  applicationCreateEndIns() has an error :" , e);
        }

    }

    @QAPMReplaceCallSite
    public static void activityCreateBeginIns(String name) {
        try {
            activityTrace.onCreateOrOnRestartEnterMethod(name, "#onCreate");
            if (!isAppInBackground) {
                return;
            }

            appStateTimeInfo.activityCreateBeginIns(name);
        } catch (Throwable e) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMAppInstrumentation  activityCreateBeginIns() has an error :" , e);
        }

    }

    @QAPMReplaceCallSite
    public static void activityCreateEndIns() {
        try {
            activityTrace.onCreateOrOnRestartExitMethod();
            if (!isAppInBackground) {
                return;
            }

            appStateTimeInfo.activityCreateEndIns();
        } catch (Throwable e) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMAppInstrumentation  activityCreateEndIns() has an error :" , e);
        }

    }

    @QAPMReplaceCallSite
    public static void activityRestartBeginIns(String name) {
        try {
            activityTrace.onCreateOrOnRestartEnterMethod(name, "#onRestart");
            if (!isAppInBackground) {
                return;
            }

            appStateTimeInfo.activityRestartBeginIns(name);
        } catch (Throwable e) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMAppInstrumentation  activityRestartBeginIns() has an error :", e);
        }

    }

    @QAPMReplaceCallSite
    public static void activityRestartEndIns() {
        activityTrace.onCreateOrOnRestartExitMethod();
        try {
            if (!isAppInBackground) {
                return;
            }

            appStateTimeInfo.activityRestartEndIns();
        } catch (Throwable e) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMAppInstrumentation  activityRestartEndIns() has an error :" , e);
        }

    }

    @QAPMReplaceCallSite
    public static void activityResumeBeginIns(String name) {
        try {
            activityTrace.onResumeEnterMethod(name);
            if (!isAppInBackground) {
                return;
            }

            appStateTimeInfo.activityResumeBeginIns(name);
        } catch (Throwable e) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMAppInstrumentation  activityResumeBeginIns() has an error :", e);
        }

    }

    @QAPMReplaceCallSite
    public static void activityResumeEndIns() {
        try {
            if (isAppInBackground) {
                appStateTimeInfo.activityResumeEndIns();
            }
            activityTrace.onResumeExitMethod();

        } catch (Throwable e) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMAppInstrumentation  activityResumeEndIns() has an error :" , e);
        }

    }


    @QAPMReplaceCallSite
    public static void activityStartBeginIns(String name) {
        try {
            activityTrace.onStartEnterMethod(name);
            if (!isAppInBackground) {
                return;
            }

            appStateTimeInfo.activityStartBeginIns(name);
        } catch (Throwable e) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMAppInstrumentation  activityStartBeginIns() has an error :", e);
        }

    }

    public static void activityStartEndIns() {
        try {
            activityTrace.onStartExitMethod();
            if (!isAppInBackground) {
                return;
            }

            appStateTimeInfo.activityStartEndIns();
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMAppInstrumentation  activityStartEndIns() has an error :" , e);
        }

    }


//    public static void HybridOnResumeEndIns(String className) {
//        try {
//            appStateTimeInfo.HybridOnResumeEndIns(className);
//        } catch (Throwable e) {
//            Magnifier.ILOGUTIL.exception("QAPMAppInstrumentation  HybirdOnResumeEndIns() has an error :" , e);
//        }
//
//    }

    static {
        try {
            appStateTimeInfo = AppStateTimeInfo.getInstance();
        } catch (Throwable e) {
        }

        isAppInBackground = true;
    }
}
