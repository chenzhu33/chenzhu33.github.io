package com.tencent.qapmsdk.io;

import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteProgram;
import android.database.sqlite.SQLiteQuery;
import android.database.sqlite.SQLiteStatement;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Pair;

import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.reporter.ResultObject;
import com.tencent.qapmsdk.io.dexposed.DexposedBridge;
import com.tencent.qapmsdk.io.dexposed.XC_MethodHook;
import com.tencent.qapmsdk.io.util.NativeMethodHook;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.common.FileUtil;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.PhoneUtil;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

class SQLiteMonitor {
    private static final String TAG = ILogUtil.getTAG(SQLiteMonitor.class);
    
    private static Class<SQLiteProgram> SQLiteProgramClass;
    private static Class<SQLiteDatabase> SQLiteDatabaseClass;
    private static Class<SQLiteStatement> SQLiteStatementClass;
    private static Class<SQLiteCursor> SQLiteCursorClass;
    
    private final static int STACKPRE = 6;
    @Nullable
    private static String processName = "";
    private static List<SQLInfo> writeToFileList = Collections.synchronizedList(new ArrayList<SQLInfo>());
    private static boolean isSaveRecord = false;
    private final static int ITEMLEN = 2048;
    private final static int WRITELEN = 200;
    @NonNull
    private static StringBuilder stackTrace = new StringBuilder(1024);
    @Nullable
    private static File saveFile = null;
    @Nullable
    private static File fileDir = null;
    @Nullable
    private static String packageName = null;
    @Nullable
    private static RandomAccessFile randf = null;
    private static final int UPLOADSIZE = 20*1024*1024;
    @Nullable
    private static String mVersion = null;
    private boolean HAVE_HOOK = false;
    private boolean CACHEHITSWITCH = false;  //缓存命中率检查开关
    @Nullable
    private volatile static SQLiteMonitor sqLiteMonitor = null;

    private SQLiteMonitor(String version) {
        mVersion = version;
    }

    @Nullable
    static SQLiteMonitor getInstance(String version) {
        if (null == sqLiteMonitor) {
            synchronized (SQLiteMonitor.class) {
                if (null == sqLiteMonitor) {
                    sqLiteMonitor = new SQLiteMonitor(version);
                }
            }
        }
        return sqLiteMonitor;
    }

    public static class DbStats {
        /** name of the database */
        public String dbName;

        /** the page size for the database */
        public long pageSize;

        /** the database size */
        public long dbSize;

        /** documented here http://www.sqlite.org/c3ref/c_dbstatus_lookaside_used.html */
        public int lookaside;

        /** statement cache stats: hits/misses/cachesize */
        public String cache;

        public DbStats(String dbName, long pageCount, long pageSize, int lookaside, int hits, int misses, int cachesize) {
            this.dbName = dbName;
            this.pageSize = pageSize / 1024;
            dbSize = (pageCount * pageSize) / 1024;
            this.lookaside = lookaside;
            this.cache = hits + "/" + misses + "/" + cachesize;
        }
    }
    
    /**
     * 获得进程名
     * @return
     */
    @Nullable
    private static String getProcessName() {
        int pid = android.os.Process.myPid();
        String processName = null;
        FileInputStream fileInputStream = null;
        InputStreamReader inputStreamReader= null;
        BufferedReader bufferedReader = null;
        try {
            File file = new File("/proc/" + pid + "/cmdline");
            fileInputStream = new FileInputStream(file);
            inputStreamReader = new InputStreamReader(fileInputStream);
            bufferedReader = new BufferedReader(inputStreamReader);
            processName = bufferedReader.readLine().trim();
        } catch (IOException e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        } finally {
            try {
                bufferedReader.close();
                inputStreamReader.close();
                fileInputStream.close();
            } catch (IOException e) {
                Magnifier.ILOGUTIL.exception(TAG, e);
            }
        }
        return processName;
    }
    
    private static void createFile() {
        packageName = getProcessName().split(":")[0];
        fileDir = new File(FileUtil.getRootPath() + "/dumpfile/2016=" + packageName + "@28@SQLiteAnalysis");
        if (fileDir != null && !(fileDir.exists())) {
            fileDir.mkdirs();
        }
        String fileName = "SQLiteMonitor.csv";
        saveFile = new File(fileDir, fileName);
        BufferedWriter bw = null;
        try {
            if (saveFile != null && !saveFile.exists()) {
                if (!saveFile.createNewFile()) {
                    Magnifier.ILOGUTIL.e(TAG, saveFile.toString(), " create file failed");
                } else {
                    bw = new BufferedWriter(new FileWriter(saveFile));
                    bw.write("TimeStamp,DB,processName,threadName,time,SQL,StackTrace\r\n");
                    bw.close();
                }
            }
        } catch (IOException e) {
            Magnifier.ILOGUTIL.e(TAG, e.toString());
        } finally {
            if (bw != null){
                try {
                    bw.close();
                }
                catch (Exception e){
                    Magnifier.ILOGUTIL.e(TAG, e.toString());
                }

            }
        }
    }
    
    protected void start() {
        processName = getProcessName();
        Magnifier.ILOGUTIL.i(TAG, "SQLiteMonitor is running:", processName);
        if (!HAVE_HOOK) {
            if (NativeMethodHook.hooksoLoadSign) {
                isSaveRecord = true;           //是否保存文件内容
                try {
                    SQLiteDatabaseClass = SQLiteDatabase.class;
                    SQLiteStatementClass = SQLiteStatement.class;
                    SQLiteCursorClass = SQLiteCursor.class;
                    SQLiteProgramClass = SQLiteProgram.class;
                } catch (Exception e) {
                    Magnifier.ILOGUTIL.exception(TAG, e);
                    return;
                }
                //创建类似/sdcard/Tencent/SNGAPM/dumpfile/2016=com.tencent.mobileqq@28@SQLiteAnalysis的 文件夹
                createFile();
                hookMethods();
                HAVE_HOOK = true;
            } else {
                Magnifier.ILOGUTIL.e(TAG, "init hook error!");
                return;
            }    
        } else {
            isSaveRecord = true;
            createFile();
        }
    }
    
    @SuppressWarnings("unchecked")
    protected void stop() {
        if (HAVE_HOOK) {
            if (CACHEHITSWITCH) {
                Method getActiveDatabases;
                Method collectDbStats;
                ArrayList<SQLiteDatabase> dblist;
                try {
                    //getActiveDatabase函数获得当前进程所有打开的database
                    getActiveDatabases = SQLiteDatabaseClass.getDeclaredMethod("getActiveDatabases");
                    getActiveDatabases.setAccessible(true);
                    collectDbStats = SQLiteDatabaseClass.getDeclaredMethod("collectDbStats", ArrayList.class);
                    collectDbStats.setAccessible(true);
                    Object arg = null;
                    dblist = (ArrayList<SQLiteDatabase>)getActiveDatabases.invoke(SQLiteDatabaseClass, arg);
                    ArrayList<DbStats> dbStatsList = new ArrayList<DbStats>();
                    //NativeMethodHook.hookHitMiss();
                    for(SQLiteDatabase db : dblist) {
                        List<Pair<String, String>> attachdbs = db.getAttachedDbs();
                        boolean hasMainDb = false;
                        for (Pair<String, String> attachdb : attachdbs) {
                            if (attachdb.first.equals("main")) {
                                NativeMethodHook.setDbName(attachdb.second);
                                hasMainDb = true;
                                break;
                            }
                        }
                        if (hasMainDb) {
                            collectDbStats.invoke(db, dbStatsList);
                        }
                    }
                    NativeMethodHook.writehm();
                } catch (Exception e) {
                    Magnifier.ILOGUTIL.exception(TAG, e);
                }
            }
            Magnifier.ILOGUTIL.i(TAG, "SQLiteMonitor is stopped:", getProcessName());
            long startTime = System.currentTimeMillis();
            if (isSaveRecord) {
                writeToFile();
            }
            try {
                writeToFileList.clear();
            } catch (Exception e) {
                Magnifier.ILOGUTIL.exception(TAG, e);
            }
            isSaveRecord = false;
            Magnifier.ILOGUTIL.d(TAG, String.valueOf(System.currentTimeMillis() - startTime));
        }
    }

    private void hookMethods() {
        hook_openDatabase();
        hook_endTransaction();
        hook_beginTransaction();
        hook_enableWLA();
        hook_executeUpdateDelete();
        hook_executeInsert();
        hook_execute();
        hook_fillWindow();
    }


    synchronized static void writeToFile() {
        int size = writeToFileList.size();
        try {
            if (saveFile != null && !saveFile.exists()) {
                if (!saveFile.createNewFile()) {
                    Magnifier.ILOGUTIL.e(TAG, saveFile.toString(), " create file failed");
                } else {
                    BufferedWriter bw = new BufferedWriter(new FileWriter(saveFile));
                    bw.write("TimeStamp,DB,processName,threadName,time,SQL,StackTrace\r\n");
                    bw.close();
                }
            }
        } catch (IOException e) {
            Magnifier.ILOGUTIL.e(TAG, e.toString());
        }
        try {
            randf = new RandomAccessFile(saveFile, "rw");
        } catch (FileNotFoundException e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
            return;
        }
        long startTime = System.currentTimeMillis();
        MappedByteBuffer buffer = null;
        FileChannel foChannel = randf.getChannel();
        try {
            buffer = foChannel.map(FileChannel.MapMode.READ_WRITE, randf.length(), size*ITEMLEN);
        } catch (IOException e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
            return;
        }
        Magnifier.ILOGUTIL.i(TAG, "SQLite mmap cost:", String.valueOf(System.currentTimeMillis() - startTime));
        for(int i = 0; i < size; i++) {
            String itemStr = writeToFileList.get(i).toString();
            if (itemStr.length() > ITEMLEN) {
                itemStr = itemStr.substring(0, ITEMLEN - 5);
                itemStr += "\r\n";
            }
            buffer.put(itemStr.getBytes());
        }
        writeToFileList.clear();
        //瀵逛簬SQL娴嬭瘯锛屽彧鏈夎繖閲屾潵鏀瑰啓鏂囦欢鍚嶇敤浜庝笂浼�
        if (saveFile.length() > UPLOADSIZE && CollectStatus.canCollect(Config.PLUGIN_QCLOUD_DB_IO)) {
            CollectStatus.addCollectCount(Config.PLUGIN_QCLOUD_DB_IO);
            FileIOMonitor.getInstance().saveNativeData();
            String timeStamp = "";
            Date dt = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss.ms", Locale.US);
            timeStamp = sdf.format(dt);
            File newFile = new File(FileUtil.getRootPath() + "/dumpfile/" + timeStamp + "=" + packageName + "@28@SQLiteAnalysis" + "[" + mVersion + "].finish");
            fileDir.renameTo(newFile);
            String fileName = newFile.toString();
            createFile();
            String newFileAbsoPath = fileName;
            try {
                File tempFile = new File(fileName);
                if (tempFile != null && tempFile.isDirectory()) {
                    String dir = tempFile.getParent();
                    long curTime = System.currentTimeMillis();
                    String outputName = "out_" + String.valueOf(curTime) + ".zip";
                    String fullPath = dir + "/" + outputName;
                    FileUtil.zipFiles(fileName, fullPath);
                    newFileAbsoPath = fullPath;
                    if (newFileAbsoPath.length() == 0) {
                        return;
                    } else {
                        FileUtil.deleteAllFilesOfDir(tempFile);
                    }
                }
                JSONObject params = new JSONObject();
                params.put("processname", PhoneUtil.getProcessName(Magnifier.sApp));
                params.put("fileObj", newFileAbsoPath);
                params.put("plugin", Config.PLUGIN_QCLOUD_DB_IO);
                ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, false, true, Magnifier.info.uin);
                ReporterMachine.addResultObj(ro);
            } catch (Exception e) {}
        }
        try {
            randf.close();
            randf = null;
        } catch (IOException e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
        Magnifier.ILOGUTIL.i(TAG, "SQLite write cost:", String.valueOf(System.currentTimeMillis() - startTime));
    }

    @NonNull
    private synchronized static String getStackTrace() {
        StackTraceElement[] ste = Thread.currentThread().getStackTrace();
        String temp = "";
        stackTrace.delete(0, stackTrace.length());
        for (int i = STACKPRE; i < ste.length; i++) {
            stackTrace.append(ste[i] + "->\t");
        }
        temp = stackTrace.toString();
        if (temp.length() > (ITEMLEN - 200)) {
            temp = temp.substring(0, ITEMLEN - 200);
        }
        return temp;
    }

    private void hook_openDatabase() {
        DexposedBridge.findAndHookMethod(SQLiteDatabaseClass,"openDatabase", String.class, CursorFactory.class, int.class, DatabaseErrorHandler.class,
                new XC_MethodHook() {
                    long startTime = 0;
                    @Override
                    public void beforeHookedMethod(MethodHookParam param) {
                        startTime = System.currentTimeMillis();
                    }

                    @Override
                    public void afterHookedMethod(@NonNull MethodHookParam param) {
                        if (isSaveRecord) {
                            long timeStamp = System.currentTimeMillis();
                            String isWLA = "false";
                            //ENABLE_WRITE_AHEAD_LOGGING = 0x20000000
                            if ((((Integer)param.args[2]).intValue() & 0x20000000) != 0) {
                                isWLA = "true";
                            }
                            writeToFileList.add(new SQLInfo(timeStamp, (String) param.args[0],  processName, Thread.currentThread().getName(), timeStamp - startTime, "openDatabase:" + isWLA, getStackTrace()));
                            if (writeToFileList.size() > WRITELEN) {
                                writeToFile();
                            }
                        }
                    }
                });
//        hookMethodList.add(info);
    }

    private void hook_enableWLA() {

        DexposedBridge.findAndHookMethod(SQLiteDatabaseClass, "enableWriteAheadLogging", new XC_MethodHook() {
            long startTime = 0;
            @Override
            public void beforeHookedMethod(MethodHookParam param) {
                startTime = System.currentTimeMillis();
            }

            @Override
            public void afterHookedMethod(@NonNull MethodHookParam param) {
                if (isSaveRecord) {
                    long timeStamp = System.currentTimeMillis();
                    SQLiteDatabase db = (SQLiteDatabase)param.thisObject;
                    writeToFileList.add(new SQLInfo(timeStamp, db.getPath(), processName, Thread.currentThread().getName(), timeStamp - startTime, "set WAL", getStackTrace()));
                    if (writeToFileList.size() > WRITELEN) {
                        writeToFile();
                    }
                }
            }

        });
    }

    private void hook_endTransaction() {
        DexposedBridge.findAndHookMethod(SQLiteDatabaseClass, "endTransaction", new XC_MethodHook() {
            long startTime = 0;
            @Override
            public void beforeHookedMethod(MethodHookParam param) {
                startTime = System.currentTimeMillis();
            }

            @Override
            public void afterHookedMethod(@NonNull MethodHookParam param) {
                if (isSaveRecord) {
                    long timestamp = System.currentTimeMillis();
                    long costtime = timestamp - startTime;
                    SQLiteDatabase db = (SQLiteDatabase)param.thisObject;
                    writeToFileList.add(new SQLInfo(timestamp, db.getPath(), processName, Thread.currentThread().getName(),  costtime, "end transaction", getStackTrace()));
                    if (writeToFileList.size() > WRITELEN) {
                        writeToFile();
                    }
                }
            }
        });
    }

    private void hook_beginTransaction() {
        DexposedBridge.findAndHookMethod(SQLiteDatabaseClass, "beginTransaction", new XC_MethodHook() {
            long startTime = 0;
            @Override
            public void beforeHookedMethod(MethodHookParam param) {
                startTime = System.currentTimeMillis();
            }

            @Override
            public void afterHookedMethod(@NonNull MethodHookParam param) {
                if (isSaveRecord) {
                    long timeStamp = System.currentTimeMillis();
                    SQLiteDatabase db = (SQLiteDatabase)param.thisObject;
                    writeToFileList.add(new SQLInfo(timeStamp, db.getPath(), processName, Thread.currentThread().getName(), timeStamp-startTime, "begin transaction", getStackTrace()));
                    if (writeToFileList.size() > WRITELEN) {
                        writeToFile();
                    }
                }
            }
        });
    }

    private void hook_executeInsert() {
        DexposedBridge.findAndHookMethod(SQLiteStatementClass, "executeInsert", new XC_MethodHook() {
            long startTime = 0;
            @Override
            public void beforeHookedMethod(MethodHookParam param) {
                startTime = System.currentTimeMillis();
            }

            @Override
            public void afterHookedMethod(@NonNull MethodHookParam param) {
                if (isSaveRecord) {
                    long timestamp = System.currentTimeMillis();
                    SQLiteStatement statement = (SQLiteStatement)param.thisObject;
                    SQLiteDatabase db = null;
                    String sql = "";
                    Object[] bindArgs = null;
                    String args = "";
                    try {
                        Field dbFilld = SQLiteProgramClass.getDeclaredField("mDatabase");
                        Field sqlField = SQLiteProgramClass.getDeclaredField("mSql");
                        Field argField= SQLiteProgramClass.getDeclaredField("mBindArgs");
                        dbFilld.setAccessible(true);
                        sqlField.setAccessible(true);
                        argField.setAccessible(true);
                        db = (SQLiteDatabase)dbFilld.get(statement);
                        sql = (String)sqlField.get(statement);
                        bindArgs = (Object[])argField.get(statement);
                        if (bindArgs != null) {
                            for(Object item:bindArgs) {
                                args += "$";
                                args += item;
                            }
                        }

                    } catch(Exception e) {
                        Magnifier.ILOGUTIL.exception(TAG, e);
                    }
                    writeToFileList.add(new SQLInfo(timestamp, db.getPath(), processName, Thread.currentThread().getName(), timestamp - startTime, sql + args, getStackTrace()));
                    if (writeToFileList.size() > WRITELEN) {
                        writeToFile();
                    }
                }
            }
        });

    }

    private void hook_executeUpdateDelete() {
        DexposedBridge.findAndHookMethod(SQLiteStatementClass, "executeUpdateDelete", new XC_MethodHook() {
            long startTime = 0;
            @Override
            public void beforeHookedMethod(MethodHookParam param) {
                startTime = System.currentTimeMillis();
            }

            @Override
            public void afterHookedMethod(@NonNull MethodHookParam param) {
                if (isSaveRecord) {
                    long timestamp = System.currentTimeMillis();
                    SQLiteStatement statement = (SQLiteStatement)param.thisObject;
                    SQLiteDatabase db = null;
                    String sql = "";
                    Object[] bindArgs = null;
                    String args = "";
                    try {
                        Field dbFilld = SQLiteProgramClass.getDeclaredField("mDatabase");
                        Field sqlField = SQLiteProgramClass.getDeclaredField("mSql");
                        Field  argField= SQLiteProgramClass.getDeclaredField("mBindArgs");
                        dbFilld.setAccessible(true);
                        sqlField.setAccessible(true);
                        argField.setAccessible(true);
                        db = (SQLiteDatabase)dbFilld.get(statement);
                        sql = (String)sqlField.get(statement);
                        bindArgs = (Object[])argField.get(statement);
                        if (bindArgs != null) {
                            for(Object item:bindArgs) {
                                args += "$";
                                args += item;
                            }
                        }
                    } catch(Exception e) {
                        Magnifier.ILOGUTIL.exception(TAG, e);
                    }
                    writeToFileList.add(new SQLInfo(timestamp, db.getPath(), processName, Thread.currentThread().getName(), timestamp - startTime, sql + args, getStackTrace()));
                    if (writeToFileList.size() > WRITELEN) {
                        writeToFile();
                    }
                }
            }
        });

    }

    private void hook_execute() {
        DexposedBridge.findAndHookMethod(SQLiteStatementClass, "execute", new XC_MethodHook() {
            long startTime = 0;
            @Override
            public void beforeHookedMethod(MethodHookParam param) {
                startTime = System.currentTimeMillis();
            }

            @Override
            public void afterHookedMethod(@NonNull MethodHookParam param) {
                if (isSaveRecord) {
                    long timestamp = System.currentTimeMillis();
                    SQLiteStatement statement = (SQLiteStatement)param.thisObject;
                    SQLiteDatabase db = null;
                    String sql = "";
                    Object[] bindArgs = null;
                    String args = "";
                    try {
                        Field dbFilld = SQLiteProgramClass.getDeclaredField("mDatabase");
                        Field sqlField = SQLiteProgramClass.getDeclaredField("mSql");
                        Field  argField= SQLiteProgramClass.getDeclaredField("mBindArgs");
                        dbFilld.setAccessible(true);
                        sqlField.setAccessible(true);
                        argField.setAccessible(true);
                        db = (SQLiteDatabase)dbFilld.get(statement);
                        sql = (String)sqlField.get(statement);
                        bindArgs = (Object[])argField.get(statement);
                        if (bindArgs != null) {
                            for(Object item:bindArgs) {
                                args += "$";
                                args += item;
                            }
                        }

                    } catch(Exception e) {
                        Magnifier.ILOGUTIL.exception(TAG, e);
                    }
                    writeToFileList.add(new SQLInfo(timestamp, db.getPath(), processName, Thread.currentThread().getName(), timestamp - startTime, sql + args, getStackTrace()));
                    if (writeToFileList.size() > WRITELEN) {
                        writeToFile();
                    }
                }
            }
        });

    }

    private void hook_fillWindow() {
        DexposedBridge.findAndHookMethod(SQLiteCursorClass, "fillWindow", int.class, new XC_MethodHook() {
            long startTime = 0;
            @Override
            public void beforeHookedMethod(MethodHookParam param) {
                startTime = System.currentTimeMillis();
            }

            @Override
            public void afterHookedMethod(@NonNull MethodHookParam param) {
                if (isSaveRecord) {
                    long timestamp = System.currentTimeMillis();
                    SQLiteDatabase db = null;
                    String sql = "";
                    Object[] bindArgs = null;
                    String args = "";
                    try {
                        Field mQueryField = SQLiteCursorClass.getDeclaredField("mQuery");
                        mQueryField.setAccessible(true);
                        SQLiteQuery mQueryObject = (SQLiteQuery)mQueryField.get(param.thisObject);
                        Field dbFilld = SQLiteProgramClass.getDeclaredField("mDatabase");
                        Field sqlField = SQLiteProgramClass.getDeclaredField("mSql");
                        Field  argField= SQLiteProgramClass.getDeclaredField("mBindArgs");
                        dbFilld.setAccessible(true);
                        sqlField.setAccessible(true);
                        argField.setAccessible(true);
                        db = (SQLiteDatabase)dbFilld.get(mQueryObject);
                        sql = (String)sqlField.get(mQueryObject);
                        bindArgs = (Object[])argField.get(mQueryObject);
                        if (bindArgs != null) {
                            for(Object item:bindArgs) {
                                args += "$";
                                args += item;
                            }
                        }
                    } catch(Exception e) {
                        Magnifier.ILOGUTIL.exception(TAG, e);
                    }
                    writeToFileList.add(new SQLInfo(timestamp, db.getPath(), processName, Thread.currentThread().getName(), timestamp - startTime, sql + args, getStackTrace()));
                    if (writeToFileList.size() > WRITELEN) {
                        writeToFile();
                    }
                }
            }
        });
    }
}