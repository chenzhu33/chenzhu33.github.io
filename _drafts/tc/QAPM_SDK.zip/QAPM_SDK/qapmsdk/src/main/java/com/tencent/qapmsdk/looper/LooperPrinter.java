package com.tencent.qapmsdk.looper;

import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Printer;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.FileUtil;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.reporter.ResultObject;

import org.json.JSONObject;

class LooperPrinter implements Printer {
    private final static String TAG = ILogUtil.getTAG(LooperPrinter.class);
    private static final String START_PREFIX = ">>"/* + ">>> Dispatching to"*/;
    private static final String STOP_PREFIX = "<<"/* + "<<< Finished to"*/;
    static int sLogThreshold = 200;

    private long startTime;
    private String lastLog;
    private String mLooperName;
    @NonNull
    private static String workDir = FileUtil.getRootPath() + "/Log/";
    
    LooperPrinter(String name) {
        mLooperName = name;
    }

    @Override
    public void println(@NonNull String x) {
        // TODO Auto-generated method stub
        MonitorInfo mi = LooperMonitor.monitorMap.get(mLooperName);
        if (x.startsWith(START_PREFIX)) {
            startTime = SystemClock.uptimeMillis();
            lastLog = x;
            if (mi != null && mi.stackGetterInited == true) {
                mi.lastStackRequestTime = SystemClock.uptimeMillis();
                mi.stack = null;
                mi.whetherReportThisTime = false;
            }
        } else if (startTime != 0L && x.startsWith(STOP_PREFIX)) {
            long cost = SystemClock.uptimeMillis() - startTime;
            startTime = 0;
            if (cost > sLogThreshold) {
                if (android.os.Debug.isDebuggerConnected()) {
                    return;
                }
                if (!CollectStatus.whetherSamplingThisTime(Config.PLUGIN_QCLOUD_LOOPER_STACK)) {
                    return;
                }
                Magnifier.ILOGUTIL.i(TAG, mLooperName, ", cost=", String.valueOf(cost), ", ", lastLog);
                gotoReport(mi, cost);
            } else {
                if (mi != null && mi.stackGetterInited == true) {
                    mi.lastStackRequestTime = 0;
                    mi.stack = null;
                }
            }
        }
    }
    
    private void gotoReport(@NonNull MonitorInfo mi, long duration) {
        if (!CollectStatus.canCollect(Config.PLUGIN_QCLOUD_LOOPER_STACK)) {
            return;
        }
//        try{
//            if(Magnifier.isEventCon && EventCon.getInstance().isEnable()){
//                // 上报EventCon事件
//                EventExternalHeader event = new EventExternalHeader("QAPM", UUID.randomUUID().toString(), 1002, "LAG", Long.valueOf(duration).intValue());
//                event.setTime(mi.cacheRealStackTime);
//                EventCon.getInstance().sendEvent(event);
//                Magnifier.ILOGUTIL.d(TAG, event.getEventJson().toString());
//            }
//        }catch (Throwable t){
//            Magnifier.ILOGUTIL.exception(TAG, t);
//        }

        CollectStatus.addCollectCount(Config.PLUGIN_QCLOUD_LOOPER_STACK);
        String stack = mi.stack;
        if (TextUtils.isEmpty(stack)) return;
        try {
            JSONObject params = new JSONObject();
            String stage = Magnifier.getCurrentActivityName();
            params.put("stage", stage != null ? stage : "");
            params.put("event_time", mi.cacheRealStackTime);
            params.put("cost_time", duration);
            params.put("stack", mi.stack);
            params.put("plugin", Config.PLUGIN_QCLOUD_LOOPER_STACK);
            ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, Magnifier.info.uin);
            ReporterMachine.addResultObj(ro);
        } catch (Exception e) {}
    }
}