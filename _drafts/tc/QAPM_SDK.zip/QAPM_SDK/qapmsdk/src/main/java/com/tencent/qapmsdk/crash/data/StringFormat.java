package com.tencent.qapmsdk.crash.data;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.crash.CrashConstants;
import com.tencent.qapmsdk.crash.collections.ImmutableSet;
import com.tencent.qapmsdk.crash.config.ReportField;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public enum StringFormat {

    JSON("application/json") {
        @NonNull
        @Override
        public String toFormattedString(@NonNull CrashReportData data, @NonNull ImmutableSet<ReportField> order, @NonNull String mainJoiner, @NonNull String subJoiner, boolean urlEncode) throws JSONException {
            final Map<String, Object> map = data.toMap();
            final JSONStringer stringer = new JSONStringer().object();
            for (ReportField field : order) {
                stringer.key(field.toString()).value(map.remove(field.toString()));
            }
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                stringer.key(entry.getKey()).value(entry.getValue());
            }
            return stringer.endObject().toString();
        }
    },
    APM_JSON("application/json") {
        @NonNull
        @Override
        public String toFormattedString(@NonNull CrashReportData data, @NonNull ImmutableSet<ReportField> order, @NonNull String mainJoiner, @NonNull String subJoiner, boolean urlEncode) throws JSONException {
            final Map<String, Object> map = data.toMap();
            final JSONStringer stringer = new JSONStringer().object();
            for (ReportField field : order) {
                stringer.key(field.toString()).value(map.remove(field.toString()));
            }

            JSONObject threadDetail = (JSONObject) map.get("THREAD_DETAILS");

            stringer.key("plugin").value(Config.PLUGIN_QCLOUD_CRASH);
            JSONArray parts = new JSONArray();
            JSONObject crash = new JSONObject();
            crash.put("category", "crash");
            JSONObject customData = (JSONObject) map.get("CUSTOM_DATA");
            String type = "";
            if(customData!=null&&customData.has("CRASH_TYPE")){
                type = customData.getString("CRASH_TYPE");
            }
            crash.put("exp_type", type);
            crash.put("exp_name", map.containsKey("STACK_TRACE_NAME")? map.get("STACK_TRACE_NAME"):"");
            crash.put("exp_reason", map.containsKey("STACK_TRACE_MESSAGE")? map.get("STACK_TRACE_MESSAGE"):"");
            crash.put("launch_uuid", map.get("USER_CRASH_TIMESTAMP"));

            JSONArray slices = new JSONArray();
            JSONObject slice = new JSONObject();
            slice.put("duration", 0);
            JSONObject thread = new JSONObject();
            thread.put("name", threadDetail!=null ? String.valueOf(threadDetail.get("id")):"");
            ArrayList<String> stacks = map.containsKey("STACK_TRACE")? (ArrayList<String>)map.get("STACK_TRACE") : new ArrayList<String>();
            JSONArray calls = new JSONArray(stacks);
            thread.put("frame", new JSONObject().put("calls",calls));
            slice.put("threads", new JSONArray().put(thread));

            slices.put(slice);
            crash.put("stack_normal_crash", new JSONObject().put("time_slices", slices));
            crash.put("oob", map.containsKey("LOGCAT")?map.get("LOGCAT"):"");
            crash.put("instant_crash", 1);
            crash.put("crashedThread", threadDetail!=null ?String.valueOf(threadDetail.get("id")):"");
            parts.put(crash);
            stringer.key("parts").value(parts);
            return stringer.endObject().toString();
        }
    },
    KEY_VALUE_LIST("application/x-www-form-urlencoded") {
        @NonNull
        @Override
        public String toFormattedString(@NonNull CrashReportData data, @NonNull ImmutableSet<ReportField> order, @NonNull String mainJoiner, @NonNull String subJoiner, boolean urlEncode) throws UnsupportedEncodingException {
            final Map<String, String> map = toStringMap(data.toMap(), subJoiner);
            final StringBuilder builder = new StringBuilder();
            for (ReportField field : order) {
                append(builder, field.toString(), map.remove(field.toString()), mainJoiner, urlEncode);
            }
            for (Map.Entry<String, String> entry : map.entrySet()) {
                append(builder, entry.getKey(), entry.getValue(), mainJoiner, urlEncode);
            }
            return builder.toString();
        }

        private void append(@NonNull StringBuilder builder, @Nullable String key, @Nullable String value, @Nullable String joiner, boolean urlEncode) throws UnsupportedEncodingException {
            if (builder.length() > 0) {
                builder.append(joiner);
            }
            if (urlEncode) {
                key = key != null ? URLEncoder.encode(key, CrashConstants.UTF8) : null;
                value = value != null ? URLEncoder.encode(value, CrashConstants.UTF8) : null;
            }
            builder.append(key).append('=').append(value);
        }

        @NonNull
        private Map<String, String> toStringMap(@NonNull Map<String, Object> map, @NonNull String joiner) {
            final Map<String, String> stringMap = new HashMap<>(map.size());
            for (final Map.Entry<String, Object> entry : map.entrySet()) {
                stringMap.put(entry.getKey(), valueToString(joiner, entry.getValue()));
            }
            return stringMap;
        }

        private String valueToString(@NonNull String joiner, @Nullable Object value) {
            if (value instanceof JSONObject) {
                return TextUtils.join(joiner, flatten((JSONObject) value));
            } else {
                return String.valueOf(value);
            }
        }

        @NonNull
        private List<String> flatten(@NonNull JSONObject json) {
            final List<String> result = new ArrayList<>();
            for (final Iterator<String> iterator = json.keys(); iterator.hasNext(); ) {
                final String key = iterator.next();
                Object value;
                try {
                    value = json.get(key);
                } catch (JSONException e) {
                    value = null;
                }
                if (value instanceof JSONObject) {
                    for (String s : flatten((JSONObject) value)) {
                        result.add(key + "." + s);
                    }
                } else {
                    result.add(key + "=" + value);
                }
            }
            return result;
        }
    };

    private final String contentType;

    StringFormat(@NonNull String contentType) {
        this.contentType = contentType;
    }

    @NonNull
    public abstract String toFormattedString(@NonNull CrashReportData data, @NonNull ImmutableSet<ReportField> order, @NonNull String mainJoiner, @NonNull String subJoiner, boolean urlEncode) throws Exception;

    @NonNull
    public String getMatchingHttpContentType() {
        return contentType;
    }
}
