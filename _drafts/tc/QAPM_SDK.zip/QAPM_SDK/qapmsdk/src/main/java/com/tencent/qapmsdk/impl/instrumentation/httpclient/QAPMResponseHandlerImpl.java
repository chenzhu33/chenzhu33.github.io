package com.tencent.qapmsdk.impl.instrumentation.httpclient;

import com.tencent.qapmsdk.impl.instrumentation.QAPMHttpClientUtil;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionState;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;

import java.io.IOException;

public class QAPMResponseHandlerImpl<T> implements ResponseHandler<T> {
    private final ResponseHandler<T> impl;
    private final QAPMTransactionState transactionState;

    private QAPMResponseHandlerImpl(ResponseHandler<T> impl, QAPMTransactionState transactionState) {
        this.impl = impl;
        this.transactionState = transactionState;
    }

    public T handleResponse(HttpResponse response) throws ClientProtocolException, IOException {
        QAPMHttpClientUtil.inspectAndInstrument(this.transactionState, response);
        return this.impl.handleResponse(response);
    }

    public static <T> ResponseHandler<? extends T> wrap(ResponseHandler<? extends T> impl, QAPMTransactionState transactionState) {
        return new QAPMResponseHandlerImpl(impl, transactionState);
    }
}
