package com.tencent.qapmsdk.impl.appstate;

import com.tencent.qapmsdk.impl.instrumentation.TraceType;
import com.tencent.qapmsdk.impl.util.TraceUtil;
import com.tencent.qapmsdk.impl.instrumentation.MetricEventListener;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTraceUnit;

public class MethodEventListener implements MetricEventListener {
    public MonitorAdapter monitorAdapter;

    public MethodEventListener() {
    }


    public MonitorAdapter registerEvent(String name, long threshold, TraceType.CONTEXT traceType) {
        this.monitorAdapter = MonitorAdapter.newOne(name, threshold, traceType);
        //QAPMTraceEngine.registerListener(this);
        return this.monitorAdapter;
    }

    public SectionHarve finishMonitor(){
        if (this.monitorAdapter == null){
            return null;
        }
        else{
            return this.monitorAdapter.finishMonitor();
        }
    }

    public QAPMMonitorThreadLocal getQapmMonitorThreadLocal(){
        return this.monitorAdapter.getQapmMonitorThreadLocal();
    }


    public void enterMethod(QAPMTraceUnit unit) {
        if (TraceUtil.canInstrumentMonitor) {
            if (this.monitorAdapter != null){
                this.monitorAdapter.addMonitorUnit(unit);
            }

        }
    }

    public void exitMethod() {
        if (TraceUtil.canInstrumentMonitor) {
            if (this.monitorAdapter != null){
                this.monitorAdapter.deleteMonitorUnit(true);
            }
        }
    }

    public void exitMethodCustom(String name) {
        if (TraceUtil.canInstrumentMonitor) {
            if (this.monitorAdapter != null){

            }

        }
    }


    public void asyncEnterMethod(QAPMTraceUnit traceUnit) {
        if (this.monitorAdapter != null){

        }

    }
}

