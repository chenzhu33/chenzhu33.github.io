package com.tencent.qapmsdk.config;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.SparseArray;

import com.tencent.qapmsdk.BuildConfig;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.APMnameVerifier;
import com.tencent.qapmsdk.common.Authorization;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.NetworkWatcher;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.common.SSLFactory;
import com.tencent.qapmsdk.reporter.ReporterMachine;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.zip.GZIPOutputStream;

import javax.net.ssl.HttpsURLConnection;

public class Config {
    private static final String TAG = ILogUtil.getTAG(Config.class);

    private static final String KEY_CONFIG_SWITCH = "config_switch";
    private static final String KEY_CONFIG_USER_SAMPLE_RATIO = "config_user_sample_ratio";
    private static final String KEY_CONFIG_NEXT_GET_CONFIG = "config_next_get_config";
    private static final String KEY_CONFIG_MAX_REPORT_NUMBER = "config_max_report_number";
    private static final String KEY_CONFIG_MAX_RESOURCE_REPORT_NUMBER = "config_max_resource_report_number";
    private static final String KEY_CONFIG_VERSION_TYPE = "config_version_type";
    private static final String KEY_CONFIG_RESOURCE_TYPE = "config_resource_type";
    //用来处理ABtest配置
    private static final String KEY_CONFIG_ABTEST_TYPE = "config_abtest_type";
    private static final String KEY_CONFIG_DATA = "config_data";

    public static final String SDK_VERSION = BuildConfig.VERSION_NAME;
    @Nullable
    public static String curConfigMd5 = "";
    public static final int MAX_SVR_CONFIG = 100;

    public static final ArrayList<String> whiteHttpHosts = new ArrayList<>(Arrays.asList("sngapm.qq.com", "ten.sngapm.qq.com", "qapm.qq.com", "162.14.17.144"));

    // plugin for qcloud
    public static final int PLUGIN_QCLOUD_DROPFRAME = 101;
    public static final int PLUGIN_QCLOUD_LOOPER_STACK = 102;
    public static final int PLUGIN_QCLOUD_CT_STACK = 103;
    public static final int PLUGIN_QCLOUD_TRAFFIC = 104;
    public static final int PLUGIN_QCLOUD_DB_IO = 105;
    public static final int PLUGIN_QCLOUD_FILE_IO = 106;
    public static final int PLUGIN_QCLOUD_LEAK_HPROF = 107;
    public static final int PLUGIN_QCLOUD_CEILING_HPROF = 108;
    public static final int PLUGIN_QCLOUD_CEILING_VALUE = 109;
    public static final int PLUGIN_QCLOUD_AUDIO_STACK = 119;
    public static final int PLUGIN_QCLOUD_BATTERY = 121;
    public static final int PLUGIN_QCLOUD_NEW_BATTERY = 124;
    public static final int PLUGIN_QCLOUD_DEVICE_INFO = 131;
    public static final int PLUGIN_QCLOUD_CRASH = 135;

    public static final int PLUGIN_QCLOUD_NEW_RESOURCE_REPORT = 138;
    public static final int PLUGIN_QCLOUD_NEW_RESOURCE_REPORT_TFS = 139;
    public static final int PLUGIN_QCLOUD_ANR_STACK = 140;

    public static final int PLUGIN_QCLOUD_WEB_VIEW = 141;
    public static final int PLUGIN_QCLOUD_HTTP = 142;

    public static final int STATUS_UPDATE_CONFIG = 1000;
    public static final int STATUS_SAME_CONFIG   = 1200;

    public static final int S_FIRSTSCREEN_THR = 2800;
    public static final int S_LAUNCH_THR = 3000;
    public static final int S_WEBVIEW_REPORT_INTERVAL = 2 * 60;
    public static final int S_ACTIVITY_THR = 500;

    public static int PROTOCOL_HTTP = 0, PROTOCOL_HTTPS = 1;
    private static int protocol = PROTOCOL_HTTPS;
    static final  List<Integer> Plugins = Arrays.asList(
        PLUGIN_QCLOUD_DROPFRAME,
        PLUGIN_QCLOUD_CT_STACK,
        PLUGIN_QCLOUD_TRAFFIC,
        PLUGIN_QCLOUD_DB_IO,
        PLUGIN_QCLOUD_FILE_IO,
        PLUGIN_QCLOUD_LEAK_HPROF,
        PLUGIN_QCLOUD_CEILING_HPROF,
        PLUGIN_QCLOUD_CEILING_VALUE,
        PLUGIN_QCLOUD_AUDIO_STACK,
        PLUGIN_QCLOUD_BATTERY,
        PLUGIN_QCLOUD_NEW_BATTERY,
        PLUGIN_QCLOUD_DEVICE_INFO,
        PLUGIN_QCLOUD_ANR_STACK,
        PLUGIN_QCLOUD_CRASH
    );

    public static final List<Integer> OtherPlugins = Arrays.asList(
            PLUGIN_QCLOUD_LOOPER_STACK,
            PLUGIN_QCLOUD_NEW_RESOURCE_REPORT,
            PLUGIN_QCLOUD_WEB_VIEW,
            PLUGIN_QCLOUD_HTTP
    );

//    public static boolean STARTED_LEAKINSPECTOR = false;
//    public static boolean STARTED_FILEIO = false;
//    public static boolean STARTED_DBIO = false;
//    public static boolean STARTED_DROPFRAME = false;
//    public static boolean STARTED_LOOPER = false;
//    public static boolean STARTED_CEILING = false;
//    public static boolean STARTED_BATTERY = false;
//    public static boolean STARTED_SAMPLE = false;
    public static int STARTED_FUNC = 0;

    public static class SamplingConfig {
        public int threshold = 100; // 阈值
        public int maxReportNum = 10; // 最大上报数量
        public float eventSampleRatio = 0.1f; // 每个用户的事件采样率
        public int maxStackDepth = 0; // 如果DPC下发了最大截栈深度是0，则会关闭堆栈抓取功能

        public SamplingConfig(int threshold, int maxReportNum, float eventSampleRatio, int stackDepth) {
            this.threshold = threshold;
            this.maxReportNum = maxReportNum;
            this.eventSampleRatio = eventSampleRatio;
            this.maxStackDepth = stackDepth;
        }
    }
    
    @NonNull
    public static SparseArray<SamplingConfig> mSampleConfigs = new SparseArray<SamplingConfig>(Plugins.size() + OtherPlugins.size());
    static {
        mSampleConfigs.append(PLUGIN_QCLOUD_DROPFRAME, new SamplingConfig( 100, 2, 0.1f, 6));
        mSampleConfigs.append(PLUGIN_QCLOUD_LOOPER_STACK, new SamplingConfig(100, 30, 0.01f, 0));
        mSampleConfigs.append(PLUGIN_QCLOUD_TRAFFIC, new SamplingConfig( 100, 10, 0.1f, 6));
        mSampleConfigs.append(PLUGIN_QCLOUD_DB_IO, new SamplingConfig( 100, 10, 0.1f, 6));
        mSampleConfigs.append(PLUGIN_QCLOUD_FILE_IO, new SamplingConfig(85, 10, 0.1f, 6));
        mSampleConfigs.append(PLUGIN_QCLOUD_LEAK_HPROF, new SamplingConfig(100, 10, 0.1f, 6));
        mSampleConfigs.append(PLUGIN_QCLOUD_CEILING_HPROF, new SamplingConfig(85, 2, 0.1f, 6));
        mSampleConfigs.append(PLUGIN_QCLOUD_CEILING_VALUE, new SamplingConfig( 85, 3, 0.01f, 0));
        mSampleConfigs.append(PLUGIN_QCLOUD_AUDIO_STACK, new SamplingConfig(100, 10, 0.1f, 6));
        mSampleConfigs.append(PLUGIN_QCLOUD_BATTERY, new SamplingConfig(100, 10, 0.1f, 6));
        mSampleConfigs.append(PLUGIN_QCLOUD_NEW_RESOURCE_REPORT, new SamplingConfig(S_LAUNCH_THR, 3000, 1.0f, 0));
        mSampleConfigs.append(PLUGIN_QCLOUD_DEVICE_INFO, new SamplingConfig(100, 1, 0.001f, 0));
        mSampleConfigs.append(PLUGIN_QCLOUD_ANR_STACK, new SamplingConfig(100,2,0.1f,6));
        mSampleConfigs.append(PLUGIN_QCLOUD_CRASH, new SamplingConfig(100,10,1f,6));
        mSampleConfigs.append(PLUGIN_QCLOUD_WEB_VIEW, new SamplingConfig(S_FIRSTSCREEN_THR,100,1f,0));
        mSampleConfigs.append(PLUGIN_QCLOUD_HTTP, new SamplingConfig(100,100,1f,0));
    }

    @NonNull
    private static String CONFIG_URL_PATTERN = "%s/appconfig/v3/config/%d/";
    @NonNull
    private static String CONFIG_URL = "";
    public static int MAX_REPORT_NUM = 100;
    public static int MAX_RESOURCE_REPORT_NUM = 20;
    public static int switchRef = ApmConst.ModeStable;
    public static float userSampleRatio = 1.0f;
    public static long nextGetConfig = 0;
    public static int VER_TYPE = 0;
    // 0:不开资源采样和tag采样；
    // 1:开资源采样；
    // 2：开tag采样；
    // 3:资源和tag都开
    // 7: 白名单用户模式
    public static int RES_TYPE = 2;
    //2.5.1新增用于查掉帧问题，ABTest用，下个迭代去除
    public static int AB_TYPE = 0;


    private static JSONObject getConfigFromSvr() throws JSONException {
        if (TextUtils.isEmpty(CONFIG_URL)) {
            CONFIG_URL = String.format(
                    Locale.US,
                    CONFIG_URL_PATTERN,
                    Magnifier.info.host,
                    Magnifier.productId);
        }

        Magnifier.ILOGUTIL.i(TAG, "getConfigFromSvr url: ", CONFIG_URL);

        String result = "{}";
        DataOutputStream outStream = null;
        HttpURLConnection conn = null;
        GZIPOutputStream gzipos = null;
        try {
            URL url = new URL(CONFIG_URL);
            protocol = getProtocol(url);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(ReporterMachine.SOCKET_TIMEOUT_MILLI);
            conn.setReadTimeout(ReporterMachine.SOCKET_TIMEOUT_MILLI);
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setUseCaches(false);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-gzip");
            conn.setRequestProperty("Content-Encoding", "gzip");
            if (TextUtils.isEmpty(Magnifier.token) && !Authorization.GetToken(Magnifier.info.appId,true)) {
                return null;
            }
            conn.setRequestProperty("Authorize",Magnifier.token);
            if(protocol==PROTOCOL_HTTPS){
                //这里如果返回为空则setSSLSocketFactory会抛异常，会被catch捕获，所以不用判空
                ((HttpsURLConnection)conn).setSSLSocketFactory(SSLFactory.getDefaultSSLSocketFactory());
                ((HttpsURLConnection)conn).setHostnameVerifier(APMnameVerifier.getInstance());
                conn.connect();
            }


            JSONObject jsonObj = new JSONObject();
            jsonObj.put("pid",  String.valueOf(Magnifier.productId));
            jsonObj.put("version", URLEncoder.encode(Magnifier.info.version,"UTF-8"));
            jsonObj.put("device", URLEncoder.encode(Build.MODEL,"UTF-8"));
            jsonObj.put("uin", Magnifier.info.uin);
            jsonObj.put("deviceid", PhoneUtil.getDeviceId(Magnifier.sApp));
            jsonObj.put("os", Build.VERSION.RELEASE);
            jsonObj.put("sdk_ver", SDK_VERSION);
            if (!TextUtils.isEmpty(curConfigMd5)){
                jsonObj.put("md5code", curConfigMd5);
            }

            Magnifier.ILOGUTIL.i(TAG, jsonObj.toString());

            outStream = new DataOutputStream(conn.getOutputStream());
            gzipos = new GZIPOutputStream(outStream);
            gzipos.write(jsonObj.toString().getBytes("utf-8"));
            gzipos.finish();

            InputStream in = new BufferedInputStream(conn.getInputStream());
            result = NetworkWatcher.readStream(in);
            Magnifier.ILOGUTIL.i(TAG, result);

        } catch (Throwable th) {
            Magnifier.ILOGUTIL.exception(TAG, th);
        } finally {
            if (null != gzipos) {
                try {
                    gzipos.close();
                    gzipos = null;
                } catch (IOException e) {
                    Magnifier.ILOGUTIL.exception(TAG, e);
                }
            }
            if (outStream != null) {
                try {
                    outStream.close();
                } catch (IOException e) {}
                outStream = null;
            }
            if (conn != null) {
                conn.disconnect();
                conn = null;
            }
        }
        return new JSONObject(result);
    }

//    private static void parseSwitch(int ref) {
//        RUN_LEAKINSPECTOR = (ref & 1) > 0;
//        RUN_IOSDK = (ref & 2) > 0;
//        RUN_DBSDK = (ref & 4) > 0;
//        RUN_LOOPER = (ref & 8) > 0;
//        RUN_CEILING = (ref & 16) > 0;
//        RUN_BATTERY = (ref & 32) > 0;
//        RUN_SAMPLE = (ref & 64) > 0;
//    }
    
    private static void parseConfig(JSONObject obj) throws JSONException {
        Magnifier.ILOGUTIL.i(TAG, "parseConfig obj: " + obj.toString());
        int p_id = obj.getInt("pid");
        if (p_id != Magnifier.productId) return;
        Iterator<?> it = obj.keys();
        while (it.hasNext()) {
            String key = (String) it.next();
            if ("switch".equals(key)) {
                switchRef = obj.getInt(key);
//                parseSwitch(switchRef);
                if (Magnifier.editor != null) {
                    Magnifier.editor.putInt(KEY_CONFIG_SWITCH, switchRef);
                }
            } else if("usr".equals(key)) {
                userSampleRatio = (float)obj.getDouble(key);
                if (Magnifier.editor != null) {
                    Magnifier.editor.putFloat(KEY_CONFIG_USER_SAMPLE_RATIO, userSampleRatio);
                }
            } else if("next".equals(key)) {
                int interval = obj.getInt(key);
                nextGetConfig = interval * 60l * 60l * 1000l + System.currentTimeMillis();
                if (Magnifier.editor != null) {
                    Magnifier.editor.putLong(KEY_CONFIG_NEXT_GET_CONFIG, nextGetConfig);
                }
            } else if("ma".equals(key)) {
                MAX_REPORT_NUM = obj.getInt(key);
                if (Magnifier.editor != null) {
                    Magnifier.editor.putInt(KEY_CONFIG_MAX_REPORT_NUMBER, MAX_REPORT_NUM);
                }
            } else if("mb".equals(key)) {
                MAX_RESOURCE_REPORT_NUM = obj.getInt(key);
                if (Magnifier.editor != null) {
                    Magnifier.editor.putInt(KEY_CONFIG_MAX_RESOURCE_REPORT_NUMBER, MAX_RESOURCE_REPORT_NUM);
                }
            } else if("vt".equals(key)) {
                VER_TYPE = obj.getInt(key);
                if (Magnifier.editor != null) {
                    Magnifier.editor.putInt(KEY_CONFIG_VERSION_TYPE, VER_TYPE);
                }
            } else if("rt".equals(key)) {
                RES_TYPE = obj.getInt(key);
                if (Magnifier.editor != null) {
                    Magnifier.editor.putInt(KEY_CONFIG_RESOURCE_TYPE, RES_TYPE);
                }
            } else if("ab".equals(key)) {
                AB_TYPE = obj.getInt(key);
                if (Magnifier.editor != null) {
                    Magnifier.editor.putInt(KEY_CONFIG_ABTEST_TYPE, AB_TYPE);
                }
            } else if (key.startsWith("p_")) {
                int plugin = Integer.parseInt(key.replace("p_", ""));
                SamplingConfig defaultConfig = mSampleConfigs.get(plugin);
                if (defaultConfig != null) {
                    int thres = defaultConfig.threshold;
                    int mrn = defaultConfig.maxReportNum;
                    float esr = defaultConfig.eventSampleRatio;
                    int msd = defaultConfig.maxStackDepth;
                    String factors = obj.getString(key);
                    String[] parts = factors.split(",");
                    if (parts.length >= 4) {
                        if (!TextUtils.isEmpty(parts[0])) thres = Integer.parseInt(parts[0]);
                        if (!TextUtils.isEmpty(parts[1])) mrn = Integer.parseInt(parts[1]);
                        if (!TextUtils.isEmpty(parts[2])) esr = Float.parseFloat(parts[2]);
                        if (!TextUtils.isEmpty(parts[3])) msd = Integer.parseInt(parts[3]);
                        SamplingConfig sc = new SamplingConfig(thres, mrn, esr, msd);
                        mSampleConfigs.setValueAt(mSampleConfigs.indexOfKey(plugin), sc);
                    }
                }
            } else;
        }
        if (Magnifier.editor != null) {
            Magnifier.editor.commit();
        }
    }

    private static void loadLocalConfigs(int p_id, String version) {
        if (Magnifier.dbHandler != null) {
            SparseArray<SamplingConfig> tempConfigs = Magnifier.dbHandler.getConfigs(p_id, version);
            if (tempConfigs != null && tempConfigs.size() > 0) {
                for (int i = 0; i < tempConfigs.size(); i++){
                    int key = tempConfigs.keyAt(i);
                    mSampleConfigs.put(key, tempConfigs.get(key));
                }
            }
        }
        if (Magnifier.QAPM_SP != null) {
            float usr = Magnifier.QAPM_SP.getFloat(KEY_CONFIG_USER_SAMPLE_RATIO,0l);
            if (usr > 0) {
                userSampleRatio = usr;
            }

            int maxReportNumber = Magnifier.QAPM_SP.getInt(KEY_CONFIG_MAX_REPORT_NUMBER,0);
            if (maxReportNumber > 0) {
                MAX_REPORT_NUM = maxReportNumber;
            }

            int maxSampleReportNumber = Magnifier.QAPM_SP.getInt(KEY_CONFIG_MAX_RESOURCE_REPORT_NUMBER,0);
            if (maxSampleReportNumber >= 0) {
                MAX_RESOURCE_REPORT_NUM = maxSampleReportNumber;
            }

            int ref = Magnifier.QAPM_SP.getInt(KEY_CONFIG_SWITCH, 0);
            if (ref > 0) {
                switchRef = ref;
//                parseSwitch(ref);
            }

            int versionType = Magnifier.QAPM_SP.getInt(KEY_CONFIG_VERSION_TYPE,0);
            if (versionType > 0) {
                VER_TYPE = versionType;
            }

            int resourceType = Magnifier.QAPM_SP.getInt(KEY_CONFIG_RESOURCE_TYPE,2);
            if (resourceType >= 0) {
                RES_TYPE = resourceType;
            }

            int abType = Magnifier.QAPM_SP.getInt(KEY_CONFIG_ABTEST_TYPE,0);
            if (abType >= 0) {
                AB_TYPE = abType;
            }
        }
    }

    public static void loadConfigs() {
        CollectStatus.init();
        if (Magnifier.QAPM_SP != null && Magnifier.editor != null) {
            curConfigMd5 = Magnifier.QAPM_SP.getString(KEY_CONFIG_DATA, "");
            try {
                if (CollectStatus.load_config_cnt < MAX_SVR_CONFIG){
                    JSONObject configs = getConfigFromSvr();
                    if (configs != null && configs.getInt("status") == STATUS_UPDATE_CONFIG){
                        parseConfig(configs.getJSONObject("data"));
                        curConfigMd5 = configs.getString("md5");
                        Magnifier.dbHandler.saveConfigs(mSampleConfigs, Magnifier.productId, Magnifier.info.version);

                    }
                    else {
                        loadLocalConfigs(Magnifier.productId, Magnifier.info.version);
                    }
                    CollectStatus.load_config_cnt++;
                    Magnifier.editor.
                            putString(KEY_CONFIG_DATA, curConfigMd5).
                            putInt(CollectStatus.KEY_COUNT_TODAY_LOAD_CONFIG, CollectStatus.load_config_cnt).
                            apply();
                }
                else {
                    loadLocalConfigs(Magnifier.productId, Magnifier.info.version);
                }


            } catch (Throwable t) {
                Magnifier.ILOGUTIL.exception(TAG, t);
            }


        }
    }

    private static int getProtocol(URL url){
        if(url.getProtocol().equals("http")){
            return PROTOCOL_HTTP;
        }
        return PROTOCOL_HTTPS;
    }
}