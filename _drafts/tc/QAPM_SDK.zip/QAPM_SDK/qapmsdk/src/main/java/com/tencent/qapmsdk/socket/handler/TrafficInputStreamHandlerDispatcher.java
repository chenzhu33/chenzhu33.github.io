package com.tencent.qapmsdk.socket.handler;


import android.support.annotation.NonNull;
import android.support.annotation.RestrictTo;

import com.tencent.qapmsdk.socket.model.SocketInfo;

import java.util.HashSet;
import java.util.Set;


@RestrictTo(RestrictTo.Scope.LIBRARY)
public class TrafficInputStreamHandlerDispatcher {

    private Set<ITrafficInputStreamHandler> mInputStreamHandlers = new HashSet<>();

    public TrafficInputStreamHandlerDispatcher() {
        for (ITrafficInputStreamHandlerFactory factory : TrafficIOStreamHandlerManager.getInputStreamHandlersFactories()) {
            mInputStreamHandlers.add(factory.create());
        }
    }

    public void dispatchRead(@NonNull byte[] b, int off, int len, int read, SocketInfo socketInfo) {
        for (ITrafficInputStreamHandler handler : mInputStreamHandlers) {
            handler.onInput(b, off, len, read, socketInfo);
        }
    }

    public void dispatchClose() {
        for (ITrafficInputStreamHandler handler : mInputStreamHandlers) {
            handler.onClose();
        }
    }
}