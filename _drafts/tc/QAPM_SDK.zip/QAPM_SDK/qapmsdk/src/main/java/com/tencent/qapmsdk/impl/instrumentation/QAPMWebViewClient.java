package com.tencent.qapmsdk.impl.instrumentation;

import android.annotation.TargetApi;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Build;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.tencent.qapmsdk.webview.WebViewX5Proxy;

public class QAPMWebViewClient extends WebViewClient {
    private boolean isAddJavascript = false;
    private String mainPageUrl;

    public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
        super.onPageStarted(webView, str, bitmap);
        if (Build.VERSION.SDK_INT < 19) {
            return;
        }
        this.mainPageUrl = str;
        if (WebViewX5Proxy.getInstance().getWebViewX5MonitorState() && webView.getTag(QAPMWebLoadInstrument.WEBVIEW_TAG) == null){
            webView.addJavascriptInterface(QAPMJavaScriptBridge.getInstance(),"AndroidQAPMJsBridge");
        }
    }

    public void onPageFinished(WebView view, String url) {
        super.onPageFinished(view, url);
    }

    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
        super.onReceivedError(view, errorCode, description, failingUrl);
    }

    public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        super.onReceivedError(view, request, error);
    }

    @TargetApi(23)
    public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
        super.onReceivedHttpError(view, request, errorResponse);
    }

    public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
        onReceivedSslError(view, handler, error);
    }
}
