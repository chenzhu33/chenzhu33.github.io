package com.tencent.qapmsdk.impl.instrumentation;

import android.annotation.TargetApi;
import android.webkit.ValueCallback;
import android.webkit.WebView;

public class QAPMWebChromeX5Client {
    private static int injectMax = 0;

    public static void initJSMonitorX5(WebView view, int newProgress)
    {
    }

    @TargetApi(19)
    private static void injectScriptFile(WebView view)
    {

    }

    public static void addWebViewBridge(WebView view)
    {

    }
}
