package com.tencent.qapmsdk.impl.appstate;

import android.os.Looper;

import com.tencent.qapmsdk.impl.instrumentation.QAPMUnit;
import com.tencent.qapmsdk.impl.instrumentation.TraceStack;

public class MonitorThreadLocal {
    protected ThreadLocal<QAPMUnit> methodEventThreadLocal;
    protected ThreadLocal<TraceStack<QAPMUnit>> traceStackThreadLocal;
    protected QAPMUnit mainThreadQapmUnit;

    public MonitorThreadLocal()
    {
        this.methodEventThreadLocal = new ThreadLocal();
        this.traceStackThreadLocal = new ThreadLocal();
    }

    public QAPMUnit getMainThreadQapmUnit()
    {
        return this.mainThreadQapmUnit;
    }


    public void push(QAPMUnit qapmUnit, Boolean isMainThread)
    {
        if (qapmUnit == null) {
            return;
        }
        if (getTraceStack() != null)
        {
            this.traceStackThreadLocal.set(getTraceStack());
            if ((getTraceStack().isEmpty()) || (getTraceStack().peek() != qapmUnit)) {
                getTraceStack().push(qapmUnit);
            }
            this.methodEventThreadLocal.set(qapmUnit);
            if (isMainThread.booleanValue()) {
                this.mainThreadQapmUnit = qapmUnit;
            }
        }
    }

    public void pop()
    {
        this.methodEventThreadLocal.remove();
        if (this.traceStackThreadLocal.get() != null) {
            ((TraceStack)this.traceStackThreadLocal.get()).pop();
        }
        resetThreadUnit();
    }

    public void resetThreadUnit()
    {
        if ((this.traceStackThreadLocal.get() == null) || (((TraceStack)this.traceStackThreadLocal.get()).isEmpty()))
        {
            this.methodEventThreadLocal.set(null);
        }
        else
        {
            QAPMUnit localQAPMUnit = (QAPMUnit)((TraceStack)this.traceStackThreadLocal.get()).peek();
            this.methodEventThreadLocal.set(localQAPMUnit);
            if (Looper.myLooper() == Looper.getMainLooper()) {
                this.mainThreadQapmUnit = localQAPMUnit;
            }
        }
    }

    public QAPMUnit threadQapmUnit()
    {
        return (QAPMUnit)this.methodEventThreadLocal.get();
    }

    public int stackSize()
    {
        TraceStack localTraceStack = (TraceStack)this.traceStackThreadLocal.get();
        if (localTraceStack == null){
            return 0;
        }

        return ((TraceStack)this.traceStackThreadLocal.get()).size();
    }

    public void clear()
    {
        this.methodEventThreadLocal.remove();
        if (this.traceStackThreadLocal.get() != null) {
            ((TraceStack)this.traceStackThreadLocal.get()).clear();
        }
    }


    protected TraceStack<QAPMUnit> getTraceStack()
    {
        TraceStack<QAPMUnit> localTraceStack = (TraceStack<QAPMUnit>)this.traceStackThreadLocal.get();
        if (localTraceStack == null) {
            localTraceStack = new TraceStack<QAPMUnit>();
        }
        return localTraceStack;
    }
}
