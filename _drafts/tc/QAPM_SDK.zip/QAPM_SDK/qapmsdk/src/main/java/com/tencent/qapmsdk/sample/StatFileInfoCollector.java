package com.tencent.qapmsdk.sample;

import android.annotation.SuppressLint;
import android.os.Process;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.VisibleForTesting;

import com.tencent.qapmsdk.Magnifier;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;

/**
 * Created by nickyliu on 2018/10/11.
 */

public class StatFileInfoCollector extends StateCollector {

    private static final String TAG = "StatFileInfoCollector";
    private static final int[] myPid = {Process.myPid()};
    private static final String PID_STATS_PATH = "/proc/" + myPid[0] + "/stat";
    private static final String SYS_STATS_PATH = "/proc/stat";
    @NonNull
    private long[] bytes = new long[5];

    @Nullable
    private RandomAccessFile curPidStat = null;
    @Nullable
    private RandomAccessFile curSysStat = null;




    protected void finalize() {
        closeFile();
    }


    @Nullable
    public synchronized long[] getStatInfo() {
        if (!mIsValid) {
            return null;
        }
        Arrays.fill(bytes, 0);

        try {
            if (curSysStat == null) {
                curSysStat = openFile(SYS_STATS_PATH);
            }
            if (curPidStat == null) {
                curPidStat = openFile(PID_STATS_PATH);
            }
            curSysStat.seek(0);
            Arrays.fill(bufferBytes, (byte) -1);
            curSysStat.read(bufferBytes, 0, bufferBytes.length);
            curIndex = 0;
            mReachedEof = false;
            mIsValid = true;

            if (peek()) {
                skipPast(' '); // cpu
                skipPast(' '); // 空格
                long user = readNumber(); // user
                long nice = readNumber(); // nice
                long system = readNumber(); // system
                long idle = readNumber(); // idle
                long irq = readNumber(); // irq
                long softirq = readNumber(); // softirq
                long stealstolen = readNumber(); // stealstolen

                bytes[0] = user + nice + system + idle + irq + softirq + stealstolen; //rt_bytes
                bytes[1] = bytes[0] - idle;
            }

            curPidStat.seek(0);
            Arrays.fill(bufferBytes, (byte) -1);
            curPidStat.read(bufferBytes, 0, bufferBytes.length);
            curIndex = 0;
            mReachedEof = false;
            mIsValid = true;
            int i = 0;
            while (!mReachedEof && mIsValid && peek() && i < 13) {
                skipPast(' '); // cpu
                i++;
            }
            if (!mReachedEof && mIsValid){
                long utime = readNumber();
                long stime = readNumber();
                bytes[2] = utime + stime;
            }
            i = 0;
            while (!mReachedEof && mIsValid && peek() && i < 4) {
                skipPast(' '); // cpu
                i++;
            }
            if (!mReachedEof && mIsValid){
                bytes[3] = readNumber();
            }
            i = 0;
            while (!mReachedEof && mIsValid && peek() && i < 3) {
                skipPast(' '); // cpu
                i++;
            }
            if (!mReachedEof && mIsValid){
                bytes[4] = readNumber();
            }

        } catch (IOException ioe) {
            mIsValid = true;
            Magnifier.ILOGUTIL.exception(TAG, ioe);
            closeFile();
            return null;
        }
        mIsValid = true;
        return bytes;
    }

    @VisibleForTesting
    @SuppressLint("InstanceMethodCanBeStatic")
    private RandomAccessFile openFile(String path) throws FileNotFoundException {
        return new RandomAccessFile(path, "r");
    }


    private void closeFile() {
        mIsValid = false;
        if (curPidStat != null) {
            try {
                curPidStat.close();
            } catch (IOException ignored) {
                // Ignore
            }
        }
        if (curSysStat != null) {
            try {
                curSysStat.close();
            } catch (IOException ignored) {
                // Ignore
            }
        }
    }


}
