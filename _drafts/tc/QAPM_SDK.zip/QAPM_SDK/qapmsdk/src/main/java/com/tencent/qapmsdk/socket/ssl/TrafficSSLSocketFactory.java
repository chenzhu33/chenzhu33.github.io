package com.tencent.qapmsdk.socket.ssl;

import android.Manifest;
import android.net.SSLCertificateSocketFactory;
import android.support.annotation.Keep;
import android.support.annotation.RestrictTo;
import android.util.Log;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.socket.util.ReflectionHelper;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;

import javax.net.ssl.SSLContextSpi;
import javax.net.ssl.SSLSocketFactory;


/**
 * Created by nicorao on 2017/12/6.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY)
public class TrafficSSLSocketFactory extends SSLSocketFactory {

    private static final String TAG = "QAPM_Socket_TrafficSSLSocketFactory";

    private SSLSocketFactory mSSLSocketFactory;

    // 为了兼容okhttp的反射
    @Keep
    private Object sslParameters;

    // Security Provider的ssl.SocketFactory.provider指定了这个类，需保留空的构造函数供反射使用
    @Keep
    public TrafficSSLSocketFactory() throws Exception {
        this((SSLSocketFactory) ReflectionHelper.of(SSLContextSpi.class).method("engineGetSocketFactory").invoke(new TrafficSSLContextImpl.Default().mOpenSSLContextImpl));
    }

    public TrafficSSLSocketFactory(SSLSocketFactory factory) {
        mSSLSocketFactory = factory;
        try {
            if (factory instanceof SSLCertificateSocketFactory) {
                factory = (SSLSocketFactory) ReflectionHelper.of(SSLCertificateSocketFactory.class).method("getDelegate").invoke(factory);
            }
            sslParameters = ReflectionHelper.of(ReflectionHelper.getOpenSSLPackageName() + ".OpenSSLSocketFactoryImpl").field("sslParameters").get(factory);
        } catch (Exception e) {
            Magnifier.ILOGUTIL.w(TAG, "set sslParameters failed: " , e.toString());
        }
    }

    @Override
    public String[] getDefaultCipherSuites() {
        return mSSLSocketFactory.getDefaultCipherSuites();
    }

    @Override
    public String[] getSupportedCipherSuites() {
        return mSSLSocketFactory.getSupportedCipherSuites();
    }

    @Override
    public Socket createSocket() throws IOException {
        return new TrafficSSLSocket(mSSLSocketFactory.createSocket(), (String) null, 0);
    }

    @Override
    public Socket createSocket(Socket s, String host, int port, boolean autoClose) throws IOException {
        return new TrafficSSLSocket(mSSLSocketFactory.createSocket(s, host, port, autoClose), host, port);
    }

    @Override
    public Socket createSocket(String host, int port) throws IOException {
        return new TrafficSSLSocket(mSSLSocketFactory.createSocket(host, port), host, port);
    }

    @Override
    public Socket createSocket(String host, int port, InetAddress localHost, int localPort) throws IOException {
        return new TrafficSSLSocket(mSSLSocketFactory.createSocket(host, port, localHost, localPort), host, port);
    }

    @Override
    public Socket createSocket(InetAddress address, int port) throws IOException {
        return new TrafficSSLSocket(mSSLSocketFactory.createSocket(address, port), address, port);
    }

    @Override
    public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort) throws IOException {
        return new TrafficSSLSocket(mSSLSocketFactory.createSocket(address, port, localAddress, localPort), address, port);
    }
}

