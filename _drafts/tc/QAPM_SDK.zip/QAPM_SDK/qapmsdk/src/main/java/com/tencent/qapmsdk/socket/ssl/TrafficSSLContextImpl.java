package com.tencent.qapmsdk.socket.ssl;

import android.support.annotation.RestrictTo;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.socket.util.ReflectionHelper;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLContextSpi;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSessionContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;



/**
 * Created by nicorao on 2017/12/6.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY)
public class TrafficSSLContextImpl extends SSLContextSpi {

    private static final String TAG = "QAPM_Socket_TrafficSSLContextImpl";

    private static final String CLASSNAME_OPENSSLCONTEXTIMPL = ReflectionHelper.getOpenSSLPackageName() + ".OpenSSLContextImpl";

    private static final Map<Class<?>, Constructor<?>> PROTOCOL_CONSTRUCTOR_CACHE = new ConcurrentHashMap<>();

    SSLContextSpi mOpenSSLContextImpl;

    // 用于给Android Framework反射空构造函数
    public TrafficSSLContextImpl() {}

    TrafficSSLContextImpl(String[] protocols) throws Exception {
        mOpenSSLContextImpl = (SSLContextSpi) getProtocolConstructor(getClass(), protocols).newInstance();
    }

    private static Constructor<?> getProtocolConstructor(Class<?> clz, String[] protocols) throws ClassNotFoundException, NoSuchMethodException {
        Constructor<?> constructor = PROTOCOL_CONSTRUCTOR_CACHE.get(clz);
        if (constructor == null) {
            // 按protocols的顺序优先选择
            for (String c : protocols) {
                try {
                    constructor = ReflectionHelper.of(CLASSNAME_OPENSSLCONTEXTIMPL +  "$" + c).constructor();
                    PROTOCOL_CONSTRUCTOR_CACHE.put(clz, constructor);
                    return constructor;
                } catch (Exception ignored) {}
            }
            // 如果找不到，则回退OpenSSLContextImpl
            constructor = ReflectionHelper.of(CLASSNAME_OPENSSLCONTEXTIMPL).constructor();
            PROTOCOL_CONSTRUCTOR_CACHE.put(clz, constructor);
            return constructor;
        }
        return constructor;
    }

    @Override
    protected void engineInit(KeyManager[] km, TrustManager[] tm, SecureRandom sr) throws KeyManagementException {
        try {
            ReflectionHelper.of(SSLContextSpi.class).method("engineInit", KeyManager[].class, TrustManager[].class, SecureRandom.class).invoke(mOpenSSLContextImpl, km, tm, sr);
        } catch (Exception e) {
            if (e instanceof InvocationTargetException && e.getCause() instanceof KeyManagementException) {
                throw (KeyManagementException) e.getCause();
            }
            ReflectionHelper.processException(e);
            throw new KeyManagementException(e);
        }
    }

    @Override
    protected SSLSocketFactory engineGetSocketFactory() {
        try {
            return new TrafficSSLSocketFactory((SSLSocketFactory) ReflectionHelper.of(SSLContextSpi.class).method("engineGetSocketFactory").invoke(mOpenSSLContextImpl));
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        return (SSLSocketFactory) SSLSocketFactory.getDefault();
    }

    @Override
    protected SSLServerSocketFactory engineGetServerSocketFactory() {
        try {
            return (SSLServerSocketFactory) ReflectionHelper.of(SSLContextSpi.class).method("engineGetServerSocketFactory").invoke(mOpenSSLContextImpl);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        return (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
    }

    @Override
    protected SSLEngine engineCreateSSLEngine() {
        try {
            return (SSLEngine) ReflectionHelper.of(SSLContextSpi.class).method("engineCreateSSLEngine").invoke(mOpenSSLContextImpl);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        try {
            return SSLContext.getDefault().createSSLEngine();
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    @Override
    protected SSLEngine engineCreateSSLEngine(String host, int port) {
        try {
            return (SSLEngine) ReflectionHelper.of(SSLContextSpi.class).method("engineCreateSSLEngine", String.class, int.class).invoke(mOpenSSLContextImpl, host, port);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        try {
            return SSLContext.getDefault().createSSLEngine(host, port);
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    @Override
    protected SSLSessionContext engineGetServerSessionContext() {
        try {
            return (SSLSessionContext) ReflectionHelper.of(SSLContextSpi.class).method("engineGetServerSessionContext").invoke(mOpenSSLContextImpl);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        try {
            return SSLContext.getDefault().getServerSessionContext();
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    @Override
    protected SSLSessionContext engineGetClientSessionContext() {
        try {
            return (SSLSessionContext) ReflectionHelper.of(SSLContextSpi.class).method("engineGetClientSessionContext").invoke(mOpenSSLContextImpl);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        try {
            return SSLContext.getDefault().getClientSessionContext();
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    @Override
    protected SSLParameters engineGetDefaultSSLParameters() {
        try {
            return (SSLParameters) ReflectionHelper.of(SSLContextSpi.class).method("engineGetDefaultSSLParameters").invoke(mOpenSSLContextImpl);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        return super.engineGetDefaultSSLParameters();
    }

    @Override
    protected SSLParameters engineGetSupportedSSLParameters() {
        try {
            return (SSLParameters) ReflectionHelper.of(SSLContextSpi.class).method("engineGetSupportedSSLParameters").invoke(mOpenSSLContextImpl);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        return super.engineGetSupportedSSLParameters();
    }

    public static class Default extends TrafficSSLContextImpl {
        private static final String[] PROTOCOLS = {"TLSv12", "TLSv11", "TLSv1", "SSLv3"};
        public Default() throws Exception {
            try {
                mOpenSSLContextImpl = (SSLContextSpi) ReflectionHelper.of(ReflectionHelper.getOpenSSLPackageName() + ".DefaultSSLContextImpl").constructor().newInstance();
            } catch (Exception e) {
                Magnifier.ILOGUTIL.exception(TAG, "new DefaultSSLContextImpl failed, try OpenSSLContextImpl!", e);
                // java.security.NoSuchAlgorithmException: KeyStore BKS implementation not found;
                // 在个别系统上，不知道为什么找不到default的keystore，这里尝试使用OpenSSLContextImpl，
                // 注意，DefaultSSLContextImpl初始化时会赋值SSLParametersImpl对象，这里使用这里尝试使用OpenSSLContextImpl时需要手动init一次
                mOpenSSLContextImpl = (SSLContextSpi) getProtocolConstructor(getClass(), PROTOCOLS).newInstance();
                try {
                    TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
                    tmf.init((KeyStore) null);
                    ReflectionHelper.of(SSLContextSpi.class).method("engineInit", KeyManager[].class, TrustManager[].class, SecureRandom.class).invoke(mOpenSSLContextImpl, null, tmf.getTrustManagers(), new java.security.SecureRandom());
                } catch (Exception ignored) {
                    Magnifier.ILOGUTIL.exception(TAG, "init OpenSSLContextImpl failed", ignored);
                }
            }
        }
    }

    public static class TLSv12 extends TrafficSSLContextImpl {
        private static final String[] PROTOCOLS = {"TLSv12", "TLSv11", "TLSv1"};
        public TLSv12() throws Exception {
            super(PROTOCOLS);
        }
    }

    public static class TLSv11 extends TrafficSSLContextImpl {
        private static final String[] PROTOCOLS = {"TLSv11", "TLSv1"};
        public TLSv11() throws Exception {
            super(PROTOCOLS);
        }
    }

    public static class TLSv1 extends TrafficSSLContextImpl {
        private static final String[] PROTOCOLS = {"TLSv1"};
        public TLSv1() throws Exception {
            super(PROTOCOLS);
        }
    }

    public static class SSLv3 extends TrafficSSLContextImpl {
        private static final String[] PROTOCOLS = {"SSLv3"};
        public SSLv3() throws Exception {
            super(PROTOCOLS);
        }
    }
}

