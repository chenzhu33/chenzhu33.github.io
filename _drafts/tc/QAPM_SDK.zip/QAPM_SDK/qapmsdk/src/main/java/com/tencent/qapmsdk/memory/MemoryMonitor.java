package com.tencent.qapmsdk.memory;

import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.common.BaseListener;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.common.ThreadManager;

import java.util.ArrayList;
import java.util.List;


public class MemoryMonitor implements Handler.Callback {
    private final static String TAG = ILogUtil.getTAG(MemoryMonitor.class);
    private final static int MSG_MEMORY_CACULATE = 1;

    @Nullable
    private volatile static MemoryMonitor sInstance = null;
    @Nullable
    private Handler mMemoryMonitorHandler;
    MemoryCellingListener memoryCellingListener;
    @NonNull
    private ArrayList<String> activityList = new ArrayList<String>(20);
    @NonNull
    private StringBuilder sb = new StringBuilder(128);
    private long pssSize;
    private long heapSize;

    public interface MemoryCellingListener extends BaseListener {
        /**
         * 检测发现内存触顶，可以在这里实现Toast提醒或转圈等逻辑，因为dump的过程比较耗时而且会卡住进程
         *
         * @return 返回zip文件中需要更多的文件
         */
        void onBeforeUploadJson();

        List<String> onBeforeDump(final String tag);

        /**
         * dump完成，可以把菊花dismiss掉了
         */
        void onAfterDump();
    }

    private MemoryMonitor(MemoryCellingListener l) {
        mMemoryMonitorHandler = new Handler(ThreadManager.getMonitorThreadLooper(), this);
        memoryCellingListener = l;
    }

    @Nullable
    public static MemoryMonitor getInstance() {
        if (sInstance == null) {
            synchronized (MemoryMonitor.class) {
                if (sInstance == null) {
                    throw new RuntimeException("Oh man, MemoryMonitor must init before getInstance.");
                }
            }
        }
        return sInstance;
    }


    private void onLowMemory(long memory) {
        if (memoryCellingListener == null) {
            throw new RuntimeException("Please init a memory celling listener first!");
        }

        Object curActivity = Magnifier.getCurrentActivity();
        String curActivityName = Magnifier.getCurrentActivityName();
        String activityHash = curActivityName + "@" + (curActivity != null ? curActivity.hashCode() : "");

        // 每个Activity实例只会上报一次
        if (!activityList.contains(activityHash)) {
            Magnifier.ILOGUTIL.d(TAG, "activityandhash report:", activityHash);
            long threshold = Config.mSampleConfigs.get(Config.PLUGIN_QCLOUD_CEILING_VALUE).threshold * Runtime.getRuntime().maxMemory() / 100;
            memoryCellingListener.onBeforeUploadJson();
            MemoryDumpHelper.getInstance().onReportToYunYing(memory, threshold, curActivityName, Magnifier.info.uin);
            activityList.add(activityHash);
            MemoryDumpHelper.getInstance().startDumpingMemory("LowMemory");
        }
    }

    public void start() {
        mMemoryMonitorHandler.removeMessages(MSG_MEMORY_CACULATE);
        mMemoryMonitorHandler.sendEmptyMessageDelayed(MSG_MEMORY_CACULATE, 5000);
    }

    public static void initCelling(MemoryCellingListener listener) {
        if (sInstance != null) {
            //throw new RuntimeException("Oh man, this only can be called once.");
            return;
        }
        sInstance = new MemoryMonitor(listener);
    }

    @Override
    public boolean handleMessage(@NonNull Message msg) {
        switch (msg.what) {
            case MSG_MEMORY_CACULATE:
                if (isOverMemoryThreshold()) {
                    onLowMemory(heapSize);
                }
                if (!CollectStatus.canCollect(Config.PLUGIN_QCLOUD_CEILING_VALUE)) {
                    int maxNum = Config.mSampleConfigs.get(Config.PLUGIN_QCLOUD_CEILING_VALUE).maxReportNum;
                    Magnifier.ILOGUTIL.d(TAG, "memory celling report count above, remove MSG_MEMORY_CACULATE msg, max report num: ", String.valueOf(maxNum));
                    mMemoryMonitorHandler.removeMessages(MSG_MEMORY_CACULATE);
                } else {
                    // 如果没有达到上报次数，5S循环一次，获取峰值内存
                    mMemoryMonitorHandler.sendEmptyMessageDelayed(MSG_MEMORY_CACULATE, 5 * 1000);
                }
                break;
        }
        return true;
    }

    /**
     * 计算单次启动过程中的峰值内存
     */
    private boolean isOverMemoryThreshold() {
        pssSize = PhoneUtil.getMemory(android.os.Process.myPid());
        heapSize = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        sb.setLength(0);
        sb.append("PSS=");
        sb.append(pssSize / 1024);
        sb.append(" KB HeapMax=");
        sb.append(Runtime.getRuntime().maxMemory() / 1024);
        sb.append(" KB HeapAlloc=");
        sb.append(Runtime.getRuntime().totalMemory() / 1024);
        sb.append(" KB HeapFree=");
        sb.append(Runtime.getRuntime().freeMemory() / 1024);
        sb.append(" KB");
        return heapSize > (Config.mSampleConfigs.get(Config.PLUGIN_QCLOUD_CEILING_VALUE).threshold * Runtime.getRuntime().maxMemory() / 100);
    }
}
