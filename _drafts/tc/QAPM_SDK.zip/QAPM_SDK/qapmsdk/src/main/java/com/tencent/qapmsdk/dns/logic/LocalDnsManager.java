package com.tencent.qapmsdk.dns.logic;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by nicorao on 2017/11/30.
 */

public class LocalDnsManager {

    private static LocalDnsManager sInstance = new LocalDnsManager();

    private Map<String, List<String>> mLocalDnsMap;

    private LocalDnsManager() {}

    public static LocalDnsManager getInstance() {
        return sInstance;
    }

    public void setLocalDnsMap(Map<String, List<String>> map) {
        mLocalDnsMap = map != null ? new HashMap<>(map) : null;
    }

    public List<String> getIpList(String host) {
        final Map<String, List<String>> localDnsMap = mLocalDnsMap;
        return localDnsMap != null ? localDnsMap.get(host) : null;
    }
}
