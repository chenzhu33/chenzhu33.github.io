package com.tencent.qapmsdk.common;

import android.os.HandlerThread;
import android.os.Looper;

/**
 * Created by anthonytan on 2017/11/24.
 */

public class ThreadManager {
    private volatile static Looper MONITOR_LOOPER = null;
    private volatile static Looper LOG_LOOPER = null;
    private volatile static Looper REPORTER_LOOPER = null;
    private volatile static Looper BATTERY_LOOPER = null;
    private volatile static Looper STACK_LOOPER = null;

    public static Looper getMonitorThreadLooper() {
        if (MONITOR_LOOPER == null) {
            synchronized(ThreadManager.class) {
                if (MONITOR_LOOPER == null) {
                    HandlerThread t = new HandlerThread("QAPM_Monitor");
                    t.start();
                    MONITOR_LOOPER = t.getLooper();
                }
            }
        }
        return MONITOR_LOOPER;
    }

    public static Looper getLogThreadLooper() {
        if (LOG_LOOPER == null) {
            synchronized(ThreadManager.class) {
                if (LOG_LOOPER == null) {
                    HandlerThread t = new HandlerThread("QAPM_Log");
                    t.start();
                    LOG_LOOPER = t.getLooper();
                }
            }
        }
        return LOG_LOOPER;
    }
    
    public static Looper getReporterThreadLooper() {
        if (REPORTER_LOOPER == null) {
            synchronized(ThreadManager.class) {
                if (REPORTER_LOOPER == null) {
                    HandlerThread t = new HandlerThread("QAPM_Reporter");
                    t.start();
                    REPORTER_LOOPER = t.getLooper();
                }
            }
        }
        return REPORTER_LOOPER;
    }
    
    public static Looper getBatteryThreadLooper() {
        if (BATTERY_LOOPER == null) {
            synchronized(ThreadManager.class) {
                if (BATTERY_LOOPER == null) {
                    HandlerThread t = new HandlerThread("QAPM_Battery");
                    t.start();
                    BATTERY_LOOPER = t.getLooper();
                }
            }
        }
        return BATTERY_LOOPER;
    }

    public static Looper getStackThreadLooper() {
        if (STACK_LOOPER == null) {
            synchronized(ThreadManager.class) {
                if (STACK_LOOPER == null) {
                    HandlerThread t = new HandlerThread("QAPM_Stack");
                    t.start();
                    STACK_LOOPER = t.getLooper();
                }
            }
        }
        return STACK_LOOPER;
    }
}