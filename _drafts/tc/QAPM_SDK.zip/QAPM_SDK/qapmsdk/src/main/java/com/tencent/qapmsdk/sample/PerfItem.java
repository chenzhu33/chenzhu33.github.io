package com.tencent.qapmsdk.sample;

import android.os.Looper;

import java.util.HashMap;

/**
 * Created by nickyliu on 2017/11/6.
 */

public class PerfItem {
    protected String mStage = "";
    protected String mExtraInfo = "";
    protected double mEventTime = Double.NaN;
    protected long mMemory = Long.MAX_VALUE;
    protected long mCpuJiffies = Long.MAX_VALUE;
    protected long mCpuSysJiffies = Long.MAX_VALUE;
    protected long mCpuSysUsedJiffies = Long.MAX_VALUE;
    protected double mCpuRate = Double.NaN;
    protected double mSysCpuRate = Double.NaN;
    protected long mNetFllowRecvBytes = Long.MAX_VALUE;
    protected long mNetFllowSendBytes = Long.MAX_VALUE;
    protected long mNetFllowPackets = Long.MAX_VALUE;
    protected long mThread = Long.MAX_VALUE;
    protected long mGC = Long.MAX_VALUE;
    protected long mIOCount = Long.MAX_VALUE;
    protected long mIOBytes = Long.MAX_VALUE;
    protected double mTemperature = Double.NaN;
//    protected HashMap<String, Long> mCpuFrequency = null;
}