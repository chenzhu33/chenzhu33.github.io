package com.tencent.qapmsdk.crash;

import android.support.annotation.Keep;

public interface CrashHandleListener {
    @Keep
    void onCrash(int id, String threadName, Error e);
}
