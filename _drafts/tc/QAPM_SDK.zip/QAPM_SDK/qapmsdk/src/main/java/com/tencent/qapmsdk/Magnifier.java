package com.tencent.qapmsdk;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.tencent.qapmsdk.anr.ANRMonitor;
import com.tencent.qapmsdk.battery.BatteryStatsImpl;
import com.tencent.qapmsdk.common.AsyncSPEditor;
import com.tencent.qapmsdk.common.Authorization;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.NetworkWatcher;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.common.ThreadManager;
import com.tencent.qapmsdk.common.VersionUtils;
import com.tencent.qapmsdk.config.ApmConst;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.config.CollectStatus.CurrentRecord;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.config.UserInfo;
import com.tencent.qapmsdk.crash.CrashMonitor;
import com.tencent.qapmsdk.dns.HttpDns;
import com.tencent.qapmsdk.dropframe.DropFrameMonitor;
import com.tencent.qapmsdk.impl.util.TraceUtil;
import com.tencent.qapmsdk.io.IOMonitor;
import com.tencent.qapmsdk.looper.LooperMonitor;
import com.tencent.qapmsdk.memory.DumpMemInfoHandler;
import com.tencent.qapmsdk.memory.LeakInspector;
import com.tencent.qapmsdk.memory.LeakInspector.InspectUUID;
import com.tencent.qapmsdk.memory.LeakInspector.InspectorListener;
import com.tencent.qapmsdk.memory.MemoryDumpHelper;
import com.tencent.qapmsdk.memory.MemoryMonitor;
import com.tencent.qapmsdk.memory.MemoryMonitor.MemoryCellingListener;
import com.tencent.qapmsdk.persist.DBHandler;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.sample.BatteryChangedReceiver;
import com.tencent.qapmsdk.sample.PerfCollector;
import com.tencent.qapmsdk.socket.TrafficMonitor;
import com.tencent.qapmsdk.webview.WebViewMonitor;

import java.io.File;
import java.lang.ref.WeakReference;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 项目名称：MagnifierAndroidSDK
 * 类描述：
 * 创建人：
 * 创建时间：
 * 修改人：janksenhu
 * 修改时间：2016/2/18
 * 修改备注：
 */
public class Magnifier {
    public static final ILogUtil ILOGUTIL = ILogUtil.getInstance(ApmConst.LevelOff);
    public static final String TAG = ILogUtil.getTAG(Magnifier.class);
    public static final String KEY_CONFIG_UIN = "config_uin";
    
    public static int productId = 0;
    @Nullable
    public static String token = "";
    @Nullable
    public static Application sApp;
    public static SharedPreferences QAPM_SP;
    public static AsyncSPEditor editor;
    @Nullable
    public static DBHandler dbHandler;
    @Nullable
    private static IOMonitor mIO;
    private static DropFrameMonitor mDropFrameMonitor;
    private static CrashMonitor mCrashMonitor;
    private static WebViewMonitor mWebViewMonitor;

    private static PerfCollector perfCollector;
    public static String revision = "0";
    @Nullable
    public static Boolean isEventCon = false;
    @NonNull
    public static UserInfo info = new UserInfo();
    private static final String FLUSHACTION = "FLUSHACTION";
    public static final int processId = Process.myPid();
    private static volatile boolean isCoreInited = false;
    private static volatile boolean isMonitorInited = false;

    protected static void init(int mode, boolean userIdChanged) {
        boolean needInit = (!isCoreInited || userIdChanged || (mode & Config.STARTED_FUNC) != mode);
        if (!needInit) return;
        boolean allInfo = (sApp != null && !TextUtils.isEmpty(info.appId) && !TextUtils.isEmpty(info.version));
        if (!allInfo) return;
        synchronized (Magnifier.class) {
            if (needInit) {
                if (!isCoreInited) {
                    isCoreInited = true;
                    initCore(Magnifier.info.appId);
                }
                initMonitors(mode);
            }
        }
    }

    private static boolean initCore(@NonNull String key) {
        if (sApp == null) return false;
        try {
            String[] polymer = key.split("-");
            info.appId = polymer[0];
            productId = Integer.valueOf(polymer[1]);
        } catch (Throwable e) {
            ILOGUTIL.exception(TAG, e);
            return false;
        }
        QAPM_SP = sApp.getSharedPreferences(TAG, Context.MODE_PRIVATE);
        editor = new AsyncSPEditor(QAPM_SP.edit());
        //为10000的话就认为还没有赋值，那么就从配置中获取下
        if(info.uin.equals("10000")){
            info.uin = QAPM_SP.getString(KEY_CONFIG_UIN, "10000");
        }
        dbHandler = DBHandler.getInstance(sApp.getApplicationContext());
        if (VersionUtils.isIceScreamSandwich()) {
            sApp.registerActivityLifecycleCallbacks(new SDKLifecycleCallback());
        }
        return true;
    }

    @NonNull
    private static BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, @Nullable Intent intent) {
            if (intent != null && FLUSHACTION.equals(intent.getAction()))  {
                String monitorname = intent.getStringExtra("monitorname");
                if ("iomonitor".equals(monitorname)) {
                    mIO.flush();
                }
                ILOGUTIL.d(TAG, "start monitor:", monitorname);
            }
        }
    };

    @NonNull
    public static BatteryChangedReceiver batteryChangedReceiver = new BatteryChangedReceiver();

    private static class RunSDKRunnable implements Runnable {
        private int func = 0;

        private RunSDKRunnable(int f) {
            func = f;
        }

        @Override
        public void run() {
            if (!isMonitorInited) {
                Object[] result = PhoneUtil.hasAllPermissions(sApp);
                boolean permissionOK = (Boolean) result[0];
                if (!permissionOK) {
                    ILOGUTIL.e(TAG, "permission lack: " + result[1]);
                    return;
                }
                NetworkWatcher.init(sApp.getApplicationContext());
                if (!Authorization.GetToken(info.appId,true)) {
                    ILOGUTIL.i(TAG, "No available authorities.");
                    return;
                }
            }

            Config.loadConfigs();
            if (!new BigInteger(PhoneUtil.getDeviceId(sApp),16).mod(new BigInteger(String.valueOf((int)(1/Config.userSampleRatio)))).equals(BigInteger.ZERO)) {
                ILOGUTIL.i(TAG, "Not chosen to get info.");
                return;
            }

            if (!isMonitorInited) {
                // 放在拉取配置之后，是为避免没抽中却启动了上报线程，把启动耗时上报上去的问题。
                ReporterMachine rm = ReporterMachine.getInstance();
                rm.startMachine();
            }

            func &= Config.switchRef;

            if ((Config.STARTED_FUNC & ApmConst.ModeLeakInspector) <= 0 && (func & ApmConst.ModeLeakInspector) > 0) {
                Config.STARTED_FUNC |= ApmConst.ModeLeakInspector;
                inspectMemoryLeak(sApp);
            }

            int type = 0;
            if ((Config.STARTED_FUNC & ApmConst.ModeFileIO) <= 0 && (func & ApmConst.ModeFileIO) > 0) {
                Config.STARTED_FUNC |= ApmConst.ModeFileIO;
                type |= 1;
            }
            if ((Config.STARTED_FUNC & ApmConst.ModeDBIO) <= 0 && (func & ApmConst.ModeDBIO) > 0) {
                Config.STARTED_FUNC |= ApmConst.ModeDBIO;
                type |= 2;
            }
            if (type > 0) {
                IntentFilter filters = new IntentFilter();
                filters.addAction(FLUSHACTION);
                sApp.registerReceiver(receiver, filters);
                mIO = new IOMonitor(sApp, type, info.version);
                mIO.start();
            }

            if ((Config.STARTED_FUNC & ApmConst.ModeLooper) <= 0 && (func & ApmConst.ModeLooper) > 0) {
                Config.STARTED_FUNC |= ApmConst.ModeLooper;
                LooperMonitor.monitorMainLooper();
//                if(Magnifier.isEventCon){
//                    try {
//                        EventCon.getInstance().setFunctionFlag(FunctionFlag.QAPM_LAG, true);
//                    }catch (Throwable t){
//                        Magnifier.ILOGUTIL.exception(TAG, t);
//                    }
//                }
            }

            if ((Config.STARTED_FUNC & ApmConst.ModeCeiling) <= 0 && (func & ApmConst.ModeCeiling) > 0) {
                Config.STARTED_FUNC |= ApmConst.ModeCeiling;
                initMemoryCelling();
            }

            if ((Config.STARTED_FUNC & ApmConst.ModeBattery) <= 0 && (func & ApmConst.ModeBattery) > 0) {
                Config.STARTED_FUNC |= ApmConst.ModeBattery;
                BatteryStatsImpl.getInstance().start();
            }

            if ((Config.STARTED_FUNC & ApmConst.ModeDropFrame) <= 0 && (func & ApmConst.ModeDropFrame) > 0) {
                Config.STARTED_FUNC |= ApmConst.ModeDropFrame;
                Handler h2 = new Handler(Looper.getMainLooper());
                DropFrameRunnable dfr = new DropFrameRunnable();
                h2.post(dfr);
            }

            if ((Config.STARTED_FUNC & ApmConst.ModeANR) <= 0 && (func & ApmConst.ModeANR) > 0) {
                Config.STARTED_FUNC |= ApmConst.ModeANR;
                ANRMonitor.initANRMonitor();
            }

            if ((Config.STARTED_FUNC & ApmConst.ModeCrash) <= 0 && (func & ApmConst.ModeCrash) > 0) {
                Config.STARTED_FUNC |= ApmConst.ModeCrash;
                mCrashMonitor = new CrashMonitor(sApp).setReportCrash();
            }

            if ((Config.STARTED_FUNC & ApmConst.ModeWebView) <= 0 && (func & ApmConst.ModeWebView) > 0) {
                Config.STARTED_FUNC |= ApmConst.ModeWebView;
                mWebViewMonitor = new WebViewMonitor(Config.mSampleConfigs.get(Config.PLUGIN_QCLOUD_WEB_VIEW).threshold);
                mWebViewMonitor.start();
            }

            if ((Config.STARTED_FUNC & ApmConst.ModeHTTP) <= 0 && (func & ApmConst.ModeHTTP) > 0) {
                Config.STARTED_FUNC |= ApmConst.ModeHTTP;
                TrafficMonitor.install();
                HttpDns.install(sApp);
                TraceUtil.setCanMonitortHttp(true);
            }

            //后台没开启了，强制做一次关闭
            if ((Config.RES_TYPE & PerfCollector.OPENRESOUCE) == 0){
                PerfCollector.getInstance().stopGlobalMonitor();
            }
            //否则后台开启了，且开启了资源采集，强制开启每秒采集（即白名单开启）
            else if ((Config.STARTED_FUNC & ApmConst.ModeResource) > 0
                    && Config.RES_TYPE == PerfCollector.OPENAUTO
                    && PerfCollector.globalMonitorCount <= 0){
                if(sApp != null){
                    PerfCollector.getInstance().startGlobalMonitor(PhoneUtil.getProcessName(sApp));
                }
                else{
                    PerfCollector.getInstance().startGlobalMonitor("default");
                }

            }


            isMonitorInited = true;

            ILOGUTIL.i(TAG, String.format(Locale.getDefault(),"QAPM SDK start success! PID: %d, APM_VERSION: %s, SWITCH: %d, STARTED: %d",
                    productId, Config.SDK_VERSION, func, Config.STARTED_FUNC));
            ILOGUTIL.i(TAG, String.format(Locale.getDefault(), "LEAKINSPECTOR : %b, IO : %b, DB : %b, LOOPER : %b, CEILING : %b, BATTERY : %b, SAMPLE : %b, ModeDropFrame: %b，ModeANR: %b, ModeCrash: %b",
                    (Config.STARTED_FUNC & ApmConst.ModeLeakInspector) > 0,
                    (Config.STARTED_FUNC & ApmConst.ModeFileIO) > 0,
                    (Config.STARTED_FUNC & ApmConst.ModeDBIO) > 0,
                    (Config.STARTED_FUNC & ApmConst.ModeLooper) > 0,
                    (Config.STARTED_FUNC & ApmConst.ModeCeiling) > 0,
                    (Config.STARTED_FUNC & ApmConst.ModeBattery) > 0,
                    (Config.STARTED_FUNC & ApmConst.ModeResource) > 0,
                    (Config.STARTED_FUNC & ApmConst.ModeDropFrame) > 0,
                    (Config.STARTED_FUNC & ApmConst.ModeANR) >0,
                    (Config.STARTED_FUNC & ApmConst.ModeCrash) >0));
        }
    }

    private static class DropFrameRunnable implements Runnable {
        @Override
        public void run() {
            mDropFrameMonitor = DropFrameMonitor.getInstance();
        }
    }

    private static boolean initMonitors(int func) {
        /*
         * 1. LeakInspector
         * 2. IOMonitor
         * 4. SQLiteMonitor
         * 8. LooperMonitor
         * 16.Ceiling
         */
        if (null == sApp || productId <= 0 || TextUtils.isEmpty(info.version)) {
            return false;
        }

        // 区间性能监控开启的时机比拉取配置早，暂时无法关闭。
        if ((Config.STARTED_FUNC & ApmConst.ModeResource) <= 0 && (func & Config.switchRef & ApmConst.ModeResource) > 0) {
            Config.STARTED_FUNC |= ApmConst.ModeResource;
            perfCollector = PerfCollector.getInstance().setPackageInfo(sApp.getApplicationContext());
            sApp.registerReceiver(batteryChangedReceiver, BatteryChangedReceiver.getFilter());

        }
        Handler h = new Handler(ThreadManager.getMonitorThreadLooper());
        RunSDKRunnable rsr = new RunSDKRunnable(func);
        h.post(rsr);
        return true;
    }

    public static void rest() {
        if (editor != null) {
            editor.putInt(CollectStatus.KEY_COUNT_TODAY_REPORTED, CollectStatus.reported)
                    .putInt(CollectStatus.KEY_COUNT_TODAY_SAMPLE_REPORTED, CollectStatus.sample_reported)
                    .putInt(CollectStatus.KEY_COUNT_TODAY_LOAD_CONFIG, CollectStatus.load_config_cnt)
                    .commit();
        }
        if (dbHandler != null)
            dbHandler.close();
        if (mIO != null) {
            mIO.stop();
        }
        if (mDropFrameMonitor != null) {
            mDropFrameMonitor.stop();
        }
        if (mWebViewMonitor != null){
            mWebViewMonitor.stop();
        }
        NetworkWatcher.unInit();
    }

    private static void inspectMemoryLeak(@NonNull Application app) {
        if (null != info.iListener) {
            LeakInspector.initInspector(new Handler(ThreadManager.getMonitorThreadLooper()), info.iListener);
        } else {
            LeakInspector.initInspector(new Handler(ThreadManager.getMonitorThreadLooper()), new InspectorListener() {

                @Override
                public void onFinishDump(final boolean isSuccess, final String objDigest, final String zipPath) {
                }

                @Nullable
                @Override
                public List<String> onPrepareDump(final String objDigest) {
                    return null;
                }

                @Override
                public boolean onFilter(Object obj) {
                    // TODO Auto-generated method stub
                    return false;
                }

                @Override
                public boolean onLeaked(InspectUUID uuid) {
                    // TODO Auto-generated method stub
                    return true;
                }

                @Override
                public void onCheckingLeaked(int currentWaitSecond, String objDigest){
                    // TODO Auto-generated method stub
                }
            });
        }
        LeakInspector.enableAutoDump(true);
        LeakInspector.startActivityInspect(app);
    }

    private static void initMemoryCelling() {
        if (!CollectStatus.canCollect(Config.PLUGIN_QCLOUD_CEILING_VALUE)) {
            ILOGUTIL.d(TAG, "Cannot collect memory celling.");
            return;
        }
        
        CurrentRecord cr = CollectStatus.mRecord.get(Config.PLUGIN_QCLOUD_CEILING_VALUE);
        if (cr != null && cr.mCollectCount < 1) {
            MemoryDumpHelper.getInstance().onReportToYunYing(-1, -1, "-1", info.uin);
        }
        if (null != info.mcListener) {
            ILOGUTIL.d(TAG, "cellingListener is implement by product");
            MemoryMonitor.initCelling(info.mcListener);
        } else {
//            静默dump的listener
            MemoryMonitor.initCelling(new MemoryCellingListener() {
                @Override
                public void onBeforeUploadJson() {
//                   上传额外自定义字段 测试OK
//                    MemoryDumpHelper.getInstance().setExtraInfo("testname", "looklukelu");
                }

                @NonNull
                @Override
                public List<String> onBeforeDump(final String dgst) {
                    ArrayList<String> files = new ArrayList<String>();
                    Object result[] = DumpMemInfoHandler.generateHprof(dgst);
                    boolean success = (Boolean) result[0];
                    if (success && null != result[1]) {
                        files.add((String) result[1]);
                    } else {
                        ILOGUTIL.d(TAG, "failed dump memory");
                    }
                    return files;
                }

                /**
                 * dump完成，可以把菊花dismiss掉了
                 */
                @Override
                public void onAfterDump() {
                }
            });
        }
        MemoryMonitor.getInstance().start();
    }

    public static Object getCurrentActivity() {
        WeakReference<Activity> weakAct = SDKLifecycleCallback.sWeakActivity;
        if (weakAct != null && weakAct.get() != null) {
            return weakAct.get();
        } else {
            if (sApp != null) {
                return PhoneUtil.getActiveComponent(sApp.getApplicationContext());
            } else {
                return null;
            }
        }
    }

    public static String getCurrentActivityName() {
        if (TextUtils.isEmpty(SDKLifecycleCallback.sActivityName)){
            return "";
        }
        return SDKLifecycleCallback.sActivityName;
    }

}