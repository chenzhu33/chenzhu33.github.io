package com.tencent.qapmsdk.crash.data;

import android.content.Context;
import android.support.annotation.NonNull;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.crash.builder.ReportBuilder;
import com.tencent.qapmsdk.crash.collector.ApplicationStartupCollector;
import com.tencent.qapmsdk.crash.collector.Collector;
import com.tencent.qapmsdk.crash.collector.CollectorException;
import com.tencent.qapmsdk.crash.config.CoreConfiguration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public final class CrashReportDataFactory {

    private static final String LOG_TAG = ILogUtil.getTAG(CrashReportDataFactory.class);
    private final Context context;
    private final CoreConfiguration config;
    private final List<Collector> collectors;

    public CrashReportDataFactory(@NonNull Context context, @NonNull CoreConfiguration config) {
        this.context = context;
        this.config = config;
        collectors = config.getCollectors();
        //noinspection Java8ListSort
        Collections.sort(collectors, new Comparator<Collector>() {
            @Override
            public int compare(Collector c1, Collector c2) {
                Collector.Order o1;
                Collector.Order o2;
                try {
                    o1 = c1.getOrder();
                } catch (Throwable t) {
                    o1 = Collector.Order.NORMAL;
                }
                try {
                    o2 = c2.getOrder();
                } catch (Throwable t) {
                    o2 = Collector.Order.NORMAL;
                }
                return o1.ordinal() - o2.ordinal();
            }
        });
    }

    /**
     * Collects crash data.
     *
     * @param builder ReportBuilder for whom to crete the crash report.
     * @return CrashReportData identifying the current crash.
     */
    @NonNull
    public CrashReportData createCrashData(@NonNull final ReportBuilder builder) {
        final ExecutorService executorService = Executors.newCachedThreadPool();
        final CrashReportData crashReportData = new CrashReportData();
        final List<Future<?>> futures = new ArrayList<>();
        for (final Collector collector : collectors) {
            futures.add(executorService.submit(new Runnable() {
                @Override
                public void run() {
                    //catch absolutely everything possible here so no collector obstructs the others
                    try {
                        Magnifier.ILOGUTIL.d(LOG_TAG, "Calling collector " + collector.getClass().getName());
                        collector.collect(context, config, builder, crashReportData);
                        Magnifier.ILOGUTIL.d(LOG_TAG, "Collector " + collector.getClass().getName() + " completed");
                    } catch (CollectorException e) {
                        Magnifier.ILOGUTIL.exception(LOG_TAG, e);
                    } catch (Exception t) {
                        Magnifier.ILOGUTIL.exception(LOG_TAG, "Error in collector " + collector.getClass().getSimpleName(), t);
                    }
                }
            }));
        }
        for (Future<?> future : futures) {
            while (!future.isDone()) {
                try {
                    future.get();
                } catch (InterruptedException ignored) {
                } catch (ExecutionException e) {
                    break;
                }
            }
        }
        return crashReportData;
    }

    public void collectStartUp() {
        for (Collector collector : collectors) {
            if (collector instanceof ApplicationStartupCollector) {
                //catch absolutely everything possible here so no collector obstructs the others
                try {
                    ((ApplicationStartupCollector) collector).collectApplicationStartUp(context, config);
                } catch (Exception t) {
                    Magnifier.ILOGUTIL.exception(LOG_TAG, collector.getClass().getSimpleName() + " failed to collect its startup data", t);
                }
            }
        }
    }
}
