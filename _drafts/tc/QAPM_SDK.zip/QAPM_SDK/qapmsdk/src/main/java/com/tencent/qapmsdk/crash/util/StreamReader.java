package com.tencent.qapmsdk.crash.util;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.crash.CrashConstants;
import com.tencent.qapmsdk.crash.collections.BoundedLinkedList;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class StreamReader {
    private static final String LOG_TAG = ILogUtil.getTAG(StreamReader.class);
    private static final int NO_LIMIT = -1;
    private static final int INDEFINITE = -1;
    private final InputStream inputStream;
    private int limit = NO_LIMIT;
    private int timeout = INDEFINITE;
    private Predicate<String> filter = null;

    public StreamReader(@NonNull String filename) throws FileNotFoundException {
        this(new File(filename));
    }

    public StreamReader(@NonNull File file) throws FileNotFoundException {
        this(new FileInputStream(file));
    }

    public StreamReader(@NonNull InputStream inputStream) {
        this.inputStream = inputStream;
    }

    @NonNull
    public StreamReader setLimit(int limit) {
        this.limit = limit;
        return this;
    }

    @NonNull
    public StreamReader setTimeout(int timeout) {
        this.timeout = timeout;
        return this;
    }

    @NonNull
    public StreamReader setFilter(Predicate<String> filter) {
        this.filter = filter;
        return this;
    }

    @NonNull
    public String read() throws IOException {
        final String text = timeout == INDEFINITE ? readFully() : readWithTimeout();
        if (filter == null) {
            if (limit == NO_LIMIT) {
                return text;
            }
            final String[] lines = text.split("\\r?\\n");
            if(lines.length <= limit){
                return text;
            }
            return TextUtils.join("\n", Arrays.copyOfRange(lines, lines.length - limit, lines.length));
        }
        final String[] lines = text.split("\\r?\\n");
        final List<String> buffer = limit == NO_LIMIT ? new LinkedList<String>() : new BoundedLinkedList<String>(limit);
        for (String line : lines) {
            if (filter.apply(line)) {
                buffer.add(line);
            }
        }
        return TextUtils.join("\n", buffer);
    }

    @NonNull
    private String readFully() throws IOException {
        final Reader input = new InputStreamReader(inputStream);
        try {
            final StringWriter output = new StringWriter();
            final char[] buffer = new char[CrashConstants.DEFAULT_BUFFER_SIZE_IN_BYTES];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
            }
            return output.toString();
        } finally {
            safeClose(input);
        }
    }

    @NonNull
    private String readWithTimeout() throws IOException {
        final long until = System.currentTimeMillis() + timeout;
        try {
            final ByteArrayOutputStream output = new ByteArrayOutputStream();
            final byte[] buffer = new byte[CrashConstants.DEFAULT_BUFFER_SIZE_IN_BYTES];
            int count;
            while ((count = fillBufferUntil(buffer, until)) != -1) {
                output.write(buffer, 0, count);
            }
            return output.toString();
        } finally {
            safeClose(inputStream);
        }
    }

    private int fillBufferUntil(@NonNull byte[] buffer, long until) throws IOException {
        int bufferOffset = 0;
        while (System.currentTimeMillis() < until && bufferOffset < buffer.length) {
            final int readResult = inputStream.read(buffer, bufferOffset, Math.min(inputStream.available(), buffer.length - bufferOffset));
            if (readResult == -1) break;
            bufferOffset += readResult;
        }
        return bufferOffset;
    }

    public static void safeClose(@Nullable Closeable closeable) {
        if (closeable == null) return;

        try {
            closeable.close();
        } catch (IOException e) {
            // We made out best effort to release this resource. Nothing more we can do.
            Magnifier.ILOGUTIL.exception(LOG_TAG, e);
        }
    }

    public static void writeStringToFile(@NonNull File file, @NonNull String content) throws IOException {
        final OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
        try {
            writer.write(content);
            writer.flush();
        } finally {
            safeClose(writer);
        }
    }
}
