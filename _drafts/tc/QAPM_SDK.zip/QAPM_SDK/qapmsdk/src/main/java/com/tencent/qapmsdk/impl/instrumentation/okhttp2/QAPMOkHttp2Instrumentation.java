package com.tencent.qapmsdk.impl.instrumentation.okhttp2;

import android.text.TextUtils;

import com.squareup.okhttp.Call;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.OkUrlFactory;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.ResponseBody;
import com.squareup.okhttp.Request.Builder;
import com.squareup.okhttp.internal.Version;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.instrumentation.QAPMHttpURLConnectionExtension;
import com.tencent.qapmsdk.impl.instrumentation.QAPMHttpsURLConnectionExtension;
import com.tencent.qapmsdk.impl.instrumentation.QAPMReplaceCallSite;

import java.net.HttpURLConnection;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;


public class QAPMOkHttp2Instrumentation {
    private final static String TAG = "QAPM_Impl_QAPMOkHttp2Instrumentation";

    public QAPMOkHttp2Instrumentation() {
    }

    @QAPMReplaceCallSite
    public static Request build(Builder builder) {
        return (new QAPMRequestBuilderExtension(builder)).build();
    }

    @QAPMReplaceCallSite
    public static Call newCall(OkHttpClient client, Request request) {
        Magnifier.ILOGUTIL.d(TAG, "OkHttpInstrumentation2 - wrapping newCall");
        return (Call)(isSpecificOkhttp() ? client.newCall(request) : new QAPMCallExtension(client, request));
    }

    public static boolean isSpecificOkhttp() {
        String version;
        try {
            version = Version.userAgent();
        } catch (Throwable e) {
            return true;
        }

        if (!TextUtils.isEmpty(version)) {
            String[] verSplit = version.split("/");
            if (verSplit == null) {
                return true;
            }

            if (!verSplit[1].startsWith("2.4.")) {
                return false;
            }
        }

        return true;
    }

    @QAPMReplaceCallSite
    public static com.squareup.okhttp.Response.Builder body(com.squareup.okhttp.Response.Builder builder, ResponseBody body) {
        return isSpecificOkhttp() ? builder.body(body) : (new ResponseBuilderExtension(builder)).body(body);
    }

    @QAPMReplaceCallSite
    public static com.squareup.okhttp.Response.Builder newBuilder(com.squareup.okhttp.Response.Builder builder) {
        return (com.squareup.okhttp.Response.Builder)(isSpecificOkhttp() ? builder : new ResponseBuilderExtension(builder));
    }

    @QAPMReplaceCallSite
    public static HttpURLConnection open(OkUrlFactory factory, URL url) {
        HttpURLConnection httpURLConnection = factory.open(url);
        if (httpURLConnection instanceof HttpsURLConnection) {
            return new QAPMHttpsURLConnectionExtension((HttpsURLConnection)httpURLConnection);
        } else {
            return (HttpURLConnection)(httpURLConnection instanceof HttpURLConnection ? new QAPMHttpURLConnectionExtension(httpURLConnection) : httpURLConnection);
        }
    }
}

