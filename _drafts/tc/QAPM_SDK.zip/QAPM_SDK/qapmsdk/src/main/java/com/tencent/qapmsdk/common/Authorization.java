package com.tencent.qapmsdk.common;

import android.os.Build;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.reporter.ReporterMachine;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.GeneralSecurityException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Iterator;
import java.util.Locale;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;


/**
 * Created by toringzhang on 2018/3/27.
 */

public class Authorization {
    private static final String TAG   = ILogUtil.getTAG(Authorization.class);
    private static final String TOKEN = "token";
    @NonNull
    private static String AUTH_URL_PATTERN = "%s/entrance/%d/authorize/";
    @NonNull
    private static String AUTH_URL    = "";

    public static int PROTOCOL_HTTP = 0, PROTOCOL_HTTPS = 1;
    private static int protocol = PROTOCOL_HTTPS;
    private static boolean GetTokenFromLocal(boolean local) {
        if (!local || Magnifier.QAPM_SP == null) {
            return false;
        }
        String token = Magnifier.QAPM_SP.getString(TOKEN, "");
        if (token.length() <= 0) {
            return false;
        }
        Magnifier.token = token;
        return true;
    }


    private static boolean GetTokenFromServer(String appKey) throws JSONException {
        if (TextUtils.isEmpty(appKey)){
            return false;
        }

        if (TextUtils.isEmpty(AUTH_URL)) {
            AUTH_URL = String.format(Locale.US, AUTH_URL_PATTERN, Magnifier.info.host, Magnifier.productId);
        }
        String result = "{}";
        DataOutputStream outStream = null;
        HttpURLConnection conn = null;
        boolean isOK = false;
        try {
            URL url = new URL(AUTH_URL);
            protocol = getProtocol(url);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(ReporterMachine.SOCKET_TIMEOUT_MILLI);
            conn.setReadTimeout(ReporterMachine.SOCKET_TIMEOUT_MILLI);
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            if(protocol==PROTOCOL_HTTPS){
                //这里如果返回为空则setSSLSocketFactory会抛异常，会被catch捕获，所以不用判空
                ((HttpsURLConnection)conn).setSSLSocketFactory(SSLFactory.getDefaultSSLSocketFactory());
                ((HttpsURLConnection)conn).setHostnameVerifier(APMnameVerifier.getInstance());
                conn.connect();
            }


            outStream = new DataOutputStream(conn.getOutputStream());
            JSONObject params = new JSONObject();
            params.put("app_key", appKey);
            params.put("p_id", Magnifier.productId);
            params.put("deviceid", PhoneUtil.getDeviceId(Magnifier.sApp));
            params.put("uin", Magnifier.info.uin);
            params.put("version", Magnifier.info.version);
            params.put("sdk_ver", Config.SDK_VERSION);
            params.put("device", Build.MODEL);
            params.put("os", Build.VERSION.RELEASE);

            StringBuffer sb = new StringBuffer(1024);
            Iterator<?> ciKeys = params.keys();
            String key = (String)ciKeys.next();
            String value = params.getString(key);
            sb.append(key).append("=").append(URLEncoder.encode(value, "UTF-8"));
            while (ciKeys.hasNext()) {
                key = (String)ciKeys.next();
                value = params.getString(key);
                sb.append("&").append(key).append("=").append(URLEncoder.encode(value, "UTF-8"));
            }
            Magnifier.ILOGUTIL.i(TAG, String.valueOf(sb));
            outStream.write(String.valueOf(sb).getBytes());
            outStream.flush();
            outStream.close();
            if(conn.getResponseCode()==200){
                isOK = true;
            }
            InputStream in = new BufferedInputStream(conn.getInputStream());
            result = NetworkWatcher.readStream(in);
        } catch (Throwable th) {
            Magnifier.ILOGUTIL.exception(TAG, th);
        } finally {
            if (outStream != null) {
                try {
                    outStream.close();
                } catch (IOException e) {}
                outStream = null;
            }
            if (conn != null) {
                conn.disconnect();
                conn = null;
            }
        }

        if (isOK) {
            JSONObject jsonObject = new JSONObject(result);
            String token = jsonObject.getString("token");
            Magnifier.token = token;
            Magnifier.ILOGUTIL.i(TAG, "GetTokenFromServer url:" + AUTH_URL + " ,token:"+token);
            return true;
        }
        return false;
    }

    private static boolean WriteTokenLocal(String token) {
        if (Magnifier.QAPM_SP == null || Magnifier.editor == null) {
            Magnifier.ILOGUTIL.e(TAG,"QAPM_Magnifier.xml not found.");
            return false;
        }
        Magnifier.editor.putString(TOKEN,token).commit();
        return true;
    }

    public static boolean GetToken(String appKey, boolean local) {
        if (!GetTokenFromLocal(local)) {
            try {
                if (!GetTokenFromServer(appKey)) {
                    return false;
                }
                WriteTokenLocal(Magnifier.token);
            } catch (Exception e) {
                Magnifier.ILOGUTIL.exception(TAG, e);
                return false;
            }
        }
        return true;
    }

    private static int getProtocol(URL url){
        if(url.getProtocol().equals("http")){
            return PROTOCOL_HTTP;
        }
        return PROTOCOL_HTTPS;
    }
}