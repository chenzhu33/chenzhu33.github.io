package com.tencent.qapmsdk.memory;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;

/**
 * 
 * @author acolorzhang
 *
 */
public class ActivityLeakSolution {
    private final static String TAG = ILogUtil.getTAG(LeakInspector.class);
    private static boolean isSoluteLeak = false;
    /**
     * @author sodinochen
     * @param destContext
     */
    public static void setSwitchLeakSolution(boolean isOpen) {
        isSoluteLeak = isOpen;
    }

    public static void fixInputMethodManagerLeak(@Nullable Context destContext) {
        if (!isSoluteLeak) {
            return;
        }
        if (destContext == null) {
            return;
        }
        InputMethodManager imm = null;
        // 瑙ｅ喅bug:http://tapd.oa.com/10066461/bugtrace/bugs/view?bug_id=1010066461049548927&url_cache_key=e8baf96f24d40b6f946bdf286c6be58e
        try {
            imm = (InputMethodManager) destContext.getSystemService(Context.INPUT_METHOD_SERVICE);
        } catch (Throwable t) {
            Magnifier.ILOGUTIL.exception(TAG, t);
        }
        if (imm == null) {
            return;
        }
        // Method imm_windowDismissed =
        // imm.getClass().getDeclaredMethod("windowDismissed",
        // IBinder.class);
        // if (imm_windowDismissed != null) {
        // if (imm_windowDismissed.isAccessible() == false) {
        // imm_windowDismissed.setAccessible(true);
        // }
        // imm_windowDismissed.invoke(imm,
        // this.getWindow().getDecorView().getWindowToken());
        // }
        // Method imm_startGettingWindowFocus =
        // imm.getClass().getDeclaredMethod("startGettingWindowFocus",
        // View.class); // 设置mCurRootView值为null
        // if (imm_startGettingWindowFocus != null) {
        // if (imm_startGettingWindowFocus.isAccessible() == false) {
        // imm_startGettingWindowFocus.setAccessible(true);
        // }
        // imm_startGettingWindowFocus.invoke(imm, new Object[]{null});
        // }

        // 以上注释掉的是google来的,但效果太差了,仍不回收,mat path to gc结果为unknow
        // 来个粗暴的,直接将path to gc的链路剪断:mCurRootView mServedView mNextServedView
        String [] arr = new String[]{"mCurRootView", "mServedView", "mNextServedView"};
        Field f = null;
        Object obj_get = null;
        for (int i = 0;i < arr.length;i ++) {
            String param = arr[i];
            try {
                f = imm.getClass().getDeclaredField(param);
                if (f.isAccessible() == false) {
                    f.setAccessible(true);
                }
                obj_get = f.get(imm);
                if (obj_get != null && obj_get instanceof View) {
                    View v_get = (View) obj_get;
                    if (v_get.getContext() == destContext) { // 被InputMethodManager持有引用的context是想要目标销毁的
                        f.set(imm, null); // 置空，破坏掉path to gc节点
                    } else {
                        // 不是想要目标销毁的，即为又进了另一层界面了，不要处理，避免影响原逻辑,也就不用继续for循环了
                        Magnifier.ILOGUTIL.d(TAG, "fixInputMethodManagerLeak break, context not suitable, get_context=", v_get.getContext().toString(), ", dest_context=", destContext.toString());
                        break;
                    }
                }
            } catch (Throwable t) {
                Magnifier.ILOGUTIL.exception(TAG, t);
            }
        }
    }

    /**
     * 修复bug:http://tapd.oa.com/10066461/bugtrace/bugs/view?bug_id=1010066461049555451&url_cache_key=e8baf96f24d40b6f946bdf286c6be58e
     * */
//    public static void fixMesssageLeak(Dialog dlg) {
//        if (dlg == null) {
//            return;
//        }
//        String arr [] = new String[] { "mDismissMessage", "mCancelMessage", "mShowMessage" };
//        for (String param : arr) {
//            try {
//                Field f = Dialog.class.getDeclaredField(param);
//                if (f == null) {
//                    continue;
//                }
//                if (f.isAccessible() == false) {
//                    f.setAccessible(true);
//                }
//                Object obj_get = f.get(dlg);
//                if (obj_get instanceof Message) {
//                    Message msg = (Message) obj_get;
////                    msg.recycle();// 清除各种target/callback/what
//                    // 这里会引起一个anr:http://tapd.oa.com/QzoneInQqAndroid/bugtrace/bugs/view?bug_id=1110065771049563223
//                    // 原因未明，就放弃使用msg.recycle()吧..
//                    // 简单处理，清掉obj、what就好了..
//                    if (msg.obj != null) {
//                        msg.obj = null;
//                        msg.what = 0; // 清除掉what，避免被send之后导致obj的NPE
//                    }
//                }
//            } catch (NoSuchFieldException e) {
//                Magnifier.ILOGUTIL.exception(TAG, e);
//            } catch (IllegalArgumentException e) {
//                Magnifier.ILOGUTIL.exception(TAG, e);
//            } catch (IllegalAccessException e) {
//                Magnifier.ILOGUTIL.exception(TAG, e);
//            } catch (Throwable tr) {
//                Magnifier.ILOGUTIL.exception(TAG, tr);
//            }
//        }
//    }
    
    public static void fixAudioManagerLeak(@NonNull Context ctx) {
        if (!isSoluteLeak || Build.VERSION.SDK_INT >= 23) {
            return;
        }
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            Field field;
            field = am.getClass().getDeclaredField("mContext");
            field.setAccessible(true);
            field.set(am, null);
        } catch (NoSuchFieldException e) {
            Magnifier.ILOGUTIL.e(TAG, e.toString());
        } catch (IllegalArgumentException e) {
            Magnifier.ILOGUTIL.e(TAG, e.toString());
        } catch (IllegalAccessException e) {
            Magnifier.ILOGUTIL.e(TAG, e.toString());
        } catch (Exception e) {
            Magnifier.ILOGUTIL.e(TAG, e.toString());
        }
    }
    
    /**
     * 下面两个方法为了干掉下面的泄漏
     * 修复这个东西：http://tapd.oa.com/10066461/bugtrace/bugs/view?bug_id=1010066461050089198
     * 系统已fix：https://android.googlesource.com/platform/frameworks/base/+/893d6fe%5E%21/#F0
    Class Name                                                                                                                   | Shallow Heap | Retained Heap
    ------------------------------------------------------------------------------------------------------------------------------------------------------------
    mContext android.widget.EditText @ 0x411606d0                                                                                |          656 |         1,104
    '- this$0 android.widget.TextView$ChangeWatcher @ 0x41161840                                                                 |           16 |            16
       '- [0] java.lang.Object[13] @ 0x41162090                                                                                  |           64 |         2,304
          '- mSpans android.text.SpannableStringBuilder @ 0x41161d30                                                             |           48 |         2,576
             '- mSpanned, mSource android.text.method.ReplacementTransformationMethod$SpannedReplacementCharSequence @ 0x41161df8|           24 |         2,600
                '- mSpanned android.text.TextLine @ 0x410f7d00                                                                   |           72 |         2,768
                   '- [1] android.text.TextLine[3] @ 0x4102ac00                                                                  |           24 |         2,960
                      '- sCached class android.text.TextLine @ 0x40fbb7d8 System Class                                           |           16 |         3,064
    ------------------------------------------------------------------------------------------------------------------------------------------------------------
     * 
     * @param tv
     */
    @SuppressWarnings("unchecked")
    private static void fixTextWatcherLeak(@Nullable TextView tv) {
        if (tv == null) {
            return;
        }
        //这个诡异的家伙，设置了Hint就会释放，奇怪
        tv.setHint("");
        try {
            Field f = TextView.class.getDeclaredField("mListeners");
            if (f == null) {
                return;
            }
            if (f.isAccessible() == false) {
                f.setAccessible(true);
            }
            Object obj_get = f.get(tv);
            if (obj_get instanceof ArrayList) {
                ArrayList<TextWatcher> tws = (ArrayList<TextWatcher>) obj_get;
                Iterator<TextWatcher> iter = tws.iterator();
                while(iter.hasNext()) {
                    iter.next();
                    iter.remove();
                }
            }
        } catch (NoSuchFieldException e) {
            Magnifier.ILOGUTIL.e(TAG, e.toString());
        } catch (IllegalArgumentException e) {
            Magnifier.ILOGUTIL.e(TAG, e.toString());
        } catch (IllegalAccessException e) {
            Magnifier.ILOGUTIL.e(TAG, e.toString());
        } catch (Throwable tr) {
            Magnifier.ILOGUTIL.e(TAG, tr.toString());
        }
    }
    
    /**
     * @see #fixTextWatcherLeak()
     */
    @SuppressWarnings("unused")
    private static void fixTextWatcherLeak2() {
        try {
            {
                Class<?> clazz = Class.forName("android.text.TextLine");
                Field sCachedF = clazz.getDeclaredField("sCached");
                sCachedF.setAccessible(true);
                Object[] sCached = (Object[])sCachedF.get(null);
                if (sCached == null) {
                    throw new IllegalStateException("Failed to invoke currentActivityThread");
                }
                
                synchronized(sCached) {
                    for (Object cache : sCached) {
                        Field spanned = cache.getClass().getDeclaredField("mSpanned");
                        spanned.setAccessible(true);
                        Spanned mSpanned = (Spanned)spanned.get(cache);
    
                        if (mSpanned != null) {
                            spanned = mSpanned.getClass().getDeclaredField("mSpanned");
                            spanned.setAccessible(true);
                            mSpanned = (Spanned)spanned.get(mSpanned);
                            if (mSpanned instanceof SpannableStringBuilder) {
                                ((SpannableStringBuilder) mSpanned).clearSpans();
                            }
                        }
                    }
                }
            }
        } catch (ClassNotFoundException cnfe) {
            Magnifier.ILOGUTIL.e(TAG, cnfe.toString());
        } catch (IllegalArgumentException iae) {
            Magnifier.ILOGUTIL.e(TAG, iae.toString());
        } catch (IllegalAccessException iae) {
            Magnifier.ILOGUTIL.e(TAG, iae.toString());
        } catch (NoSuchFieldException nsfe) {
            Magnifier.ILOGUTIL.e(TAG, nsfe.toString());
        } catch (Exception e) {
            Magnifier.ILOGUTIL.e(TAG, e.toString());
        }
        
    }
    
    /**
     * 终极回收大法
     * @param app
     */
//    public static void unbindDrawables(Activity app) {
//        if (app == null || app.getWindow() == null || app.getWindow().peekDecorView() == null) {
//            return;
//        }
//        try {
//            View rootView = app.getWindow().peekDecorView().getRootView();
//            unbindDrawablesAndRecyle(app, rootView);
//        } catch (Throwable th) {
//            th.printStackTrace();
//        }
//    }
    
    @SuppressWarnings("deprecation")
    private static void recycleView(@Nullable View view) {
        if (view == null) {
            return;
        }
        
        try {
            view.setOnClickListener(null);
        } catch (IncompatibleClassChangeError e) {
            throw (IncompatibleClassChangeError) (new IncompatibleClassChangeError("May cause dvmFindCatchBlock crash!").initCause(e));
        } catch (Throwable mayHappen) {
        }

        try {
            view.setOnCreateContextMenuListener(null);
        } catch (IncompatibleClassChangeError e) {
            throw (IncompatibleClassChangeError) (new IncompatibleClassChangeError("May cause dvmFindCatchBlock crash!").initCause(e));
        } catch (Throwable mayHappen) {
        }

        try {
            view.setOnFocusChangeListener(null);
        } catch (IncompatibleClassChangeError e) {
            throw (IncompatibleClassChangeError) (new IncompatibleClassChangeError("May cause dvmFindCatchBlock crash!").initCause(e));
        } catch (Throwable mayHappen) {
        }

        try {
            view.setOnKeyListener(null);
        } catch (IncompatibleClassChangeError e) {
            throw (IncompatibleClassChangeError) (new IncompatibleClassChangeError("May cause dvmFindCatchBlock crash!").initCause(e));
        } catch (Throwable mayHappen) {
        }

        try {
            view.setOnLongClickListener(null);
        } catch (IncompatibleClassChangeError e) {
            throw (IncompatibleClassChangeError) (new IncompatibleClassChangeError("May cause dvmFindCatchBlock crash!").initCause(e));
        } catch (Throwable mayHappen) {
        }

        try {
            view.setOnClickListener(null);
        } catch (IncompatibleClassChangeError e) {
            throw (IncompatibleClassChangeError) (new IncompatibleClassChangeError("May cause dvmFindCatchBlock crash!").initCause(e));
        } catch (Throwable mayHappen) {
        }

        try {
            view.setOnTouchListener(null);
        } catch (IncompatibleClassChangeError e) {
            throw (IncompatibleClassChangeError) (new IncompatibleClassChangeError("May cause dvmFindCatchBlock crash!").initCause(e));
        } catch (Throwable mayHappen) {
        }
        
        Drawable d = view.getBackground();
        if (d != null) {
            d.setCallback(null);
            view.setBackgroundDrawable(null);
        }

        view.destroyDrawingCache();
    }
    
    /**
     * 可以回收TextView及子类
     * @param tv
     */
    private static void recycleTextView(TextView tv) {
        Drawable[] ds = tv.getCompoundDrawables();
        for (Drawable d : ds) {
            if (d != null) {
                d.setCallback(null);
            }
        }
        tv.setCompoundDrawables(null, null, null, null);
        //下面的几个注释，目前为止没出现过这种泄漏，先不管
//        tv.setOnEditorActionListener(null);
//        tv.setKeyListener(null);
//        tv.setMovementMethod(null);
        if (tv instanceof EditText) {
            fixTextWatcherLeak(tv);
        }
        
        //取消焦点，尝试解决Editor$Blink导致的Activity内存泄漏，Blink是一个Runnable
        //官方在6.0已解决 https://android.googlesource.com/platform/frameworks/base/+/5b734f2430e9f26c769d6af8ea5645e390fcf5af%5E%21/
        //怀疑问题的原因：TextView.onDetachFromWindow会removeCallback，但是逻辑上可能会makeBlink，导致继续postDelay了一个Blink
        //怀疑问题的原因：异步线程在onDestroy（也就是onDetachFromWindow）之后，仍然操作了这个TextView，导致了继续post这个Blink
        //尝试解决，不一定会解决，但会降低泄漏的几率
        //解决方法：setCursorVisible，这样Blink.run里判断的shouldBlink就会false，则不会继续post这个Blink了
        tv.setCursorVisible(false);
    }
    
    /**
     * 回收ImageView、ImageButton等
     * @param iv
     */
    private static void recycleImageView(@NonNull Activity app, @Nullable ImageView iv) {
        if (iv == null) {
            return;
        }
        
        Drawable d = iv.getDrawable();
        if (d != null) {
            d.setCallback(null);
        }
        
        iv.setImageDrawable(null);

        // Report if iamge too large
        try {
            if (d != null && d instanceof BitmapDrawable) {
                // TODO: 频率限制
                Bitmap b = ((BitmapDrawable) d).getBitmap();
                int imgW = b.getWidth();
                int imgH = b.getHeight();
                if (imgW > 0 && imgH > 0) {
                    int viewW = iv.getWidth();
                    int viewH = iv.getHeight();
                    int exceededSquere = 0;
                    if (viewW > 0 && viewH > 0) {
                        int ratioW = Math.round((float)imgW / (float)viewW);
                        int ratioH = Math.round((float)imgH / (float)viewH);
                        int maxZoomRatio = Math.max(ratioW, ratioH);
                        if (maxZoomRatio >= 2) {
                            exceededSquere = viewW * viewH * (maxZoomRatio * maxZoomRatio - 1);
                        }
                    } else {
                        exceededSquere = imgW * imgH;
                    }

                    if (exceededSquere > 0) {
                        // 频率限制
                        StringBuffer sb = new StringBuffer(100);
                        int vid = iv.getId();
                        sb.append(app.getClass().getName()).append('_').append(vid);
                        if (vid == -1) {
                            ViewParent parent = iv.getParent();
                            while(vid == -1 && parent != null && parent instanceof ViewGroup) {
                                vid = ((ViewGroup)parent).getId();
                                sb.append('_');
                                sb.append(vid);
                                parent = parent.getParent();
                            }
                        }
                        /*
                        JSONObject params = new JSONObject();
                        JSONObject data = new JSONObject();
                        data.put("viewsize", "(" + viewW + "," + viewH + ")");
                        data.put("picsize", "(" + imgW + "," + imgH + ")");
                        JSONObject clientInfo = new JSONObject();
                        clientInfo.put("plugin", String.valueOf(Config.PLUGIN_LARGEPIC));
                        clientInfo.put("processname", ProcessUtil.getProcessName(MagnifierSDK.sApp));
                        params.put("largePic", data);
                        params.put("clientinfo", clientInfo);
                        ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, false, true, MagnifierSDK.uin);
                        ReporterMachine.addResultObj(ro);
                        */
                    }
                }
            }
        } catch (Throwable ignore) {
        }
    }
    
    /**
     * 回收ProgressBar等
     * @param pb
     */
    private static void recycleProgressBar(ProgressBar pb) {
        Drawable pd = pb.getProgressDrawable();
        if (pd != null) {
            pb.setProgressDrawable(null);
            pd.setCallback(null);
        }
        Drawable id = pb.getIndeterminateDrawable();
        if (id != null) {
            pb.setIndeterminateDrawable(null);
            id.setCallback(null);
        }        
    }
    
    /**
     * 回收ListView
     * @param listView
     */
    private static void recycleListView(android.widget.ListView listView) {
        Drawable selector = listView.getSelector();
        if (selector != null) {
            selector.setCallback(null);
            //不能设置空的selector
//            listView.setSelector(null);
        }
        
        try {
            android.widget.ListAdapter la = listView.getAdapter();
            if (la != null) {
                listView.setAdapter(null);
                //不能关闭cursor。万一出问题呢
//                if (la instanceof android.widget.CursorAdapter) {//判断CursorAdapter，关闭cursor
//                    android.widget.CursorAdapter ca = (android.widget.CursorAdapter) la;
//                    Cursor c = ca.getCursor();
//                    if (c != null && !c.isClosed()) {
//                        c.close();
//                    }
//                }
            }
        } catch (IncompatibleClassChangeError e) {
            throw (IncompatibleClassChangeError) (new IncompatibleClassChangeError("May cause dvmFindCatchBlock crash!").initCause(e));
        } catch (Throwable mayHappen) {
        }

        try {
            listView.setOnScrollListener(null);
        } catch (IncompatibleClassChangeError e) {
            throw (IncompatibleClassChangeError) (new IncompatibleClassChangeError("May cause dvmFindCatchBlock crash!").initCause(e));
        } catch (Throwable mayHappen) {
        }

        try {
            listView.setOnItemClickListener(null);
        } catch (IncompatibleClassChangeError e) {
            throw (IncompatibleClassChangeError) (new IncompatibleClassChangeError("May cause dvmFindCatchBlock crash!").initCause(e));
        } catch (Throwable mayHappen) {
        }

        try {
            listView.setOnItemLongClickListener(null);
        } catch (IncompatibleClassChangeError e) {
            throw (IncompatibleClassChangeError) (new IncompatibleClassChangeError("May cause dvmFindCatchBlock crash!").initCause(e));
        } catch (Throwable mayHappen) {
        }

        try {
            listView.setOnItemSelectedListener(null);
        } catch (IncompatibleClassChangeError e) {
            throw (IncompatibleClassChangeError) (new IncompatibleClassChangeError("May cause dvmFindCatchBlock crash!").initCause(e));
        } catch (Throwable mayHappen) {
        }
    }
    
    /**
     * 回收FrameLayout资源
     * @param fl
     */
    private static void recycleFrameLayout(@Nullable FrameLayout fl) {
        if (fl != null) {
            Drawable fg = fl.getForeground();
            if (fg != null) {
                fg.setCallback(null);
                fl.setForeground(null);
            }
        }
    }
    
    /**
     * 回收LinearLayout资源
     * @param ll
     */
    @TargetApi(16)
    private static void recycleLinearLayout(@Nullable LinearLayout ll) {
        if (ll == null) {
            return;
        }
        
        if (Build.VERSION_CODES.HONEYCOMB <= Build.VERSION.SDK_INT) {
            //API 11以上，设置Divider
            Drawable dd = null;
            if (Build.VERSION_CODES.JELLY_BEAN <= Build.VERSION.SDK_INT) {
                dd = ll.getDividerDrawable();
            } else {
                //API 16以下反射获取
                try {
                    Field f = ll.getClass().getDeclaredField("mDivider");
                    f.setAccessible(true);
                    dd = (Drawable)f.get(ll);
                } catch (NoSuchFieldException e) {
                    Magnifier.ILOGUTIL.e(TAG, e.toString());
                } catch (IllegalArgumentException e) {
                    Magnifier.ILOGUTIL.e(TAG, e.toString());
                } catch (IllegalAccessException e) {
                    Magnifier.ILOGUTIL.e(TAG, e.toString());
                }
            }
            if (dd != null) {
                dd.setCallback(null);
                ll.setDividerDrawable(null);
            }
        }
    }
    
    /**
     * 回收ViewGroup
     * @param vg
     */
    private static void recycleViewGroup(@NonNull Activity app, ViewGroup vg) {
        final int childCount = vg.getChildCount();
        for (int i = 0; i < childCount; i++) {
            unbindDrawablesAndRecyle(app, vg.getChildAt(i));
        }
    }
    
    private static void unbindDrawablesAndRecyle(@NonNull Activity app, @Nullable View view) {
        if (view == null)
            return;
        
        recycleView(view);
        
        if (view instanceof ImageView) {
            //ImageView ImageButton都会走这里
            recycleImageView(app, (ImageView)view);
        } else if (view instanceof TextView) {
            //释放TextView、Button周边图片资源
            recycleTextView((TextView)view);
        } else if (view instanceof ProgressBar) {
            //ProgressBar
            recycleProgressBar((ProgressBar)view);
        } else {
            //ListView
            if (view instanceof android.widget.ListView) {
                recycleListView((android.widget.ListView)view);
            } else if (view instanceof FrameLayout) {
                recycleFrameLayout((FrameLayout) view);
            } else if (view instanceof LinearLayout) {
                recycleLinearLayout((LinearLayout) view);
            }
            
            if (view instanceof ViewGroup) {
                recycleViewGroup(app, (ViewGroup)view);
            }
        }
        
    }
}
