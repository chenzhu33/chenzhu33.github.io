package com.tencent.qapmsdk.reporter;

public interface IReporter {
    boolean report(ResultObject ro, ReportResultCallback callback);
    
    interface ReportResultCallback {
        void onSuccess(int id);
        void onFailure(int plugin, long uploadtime, int error_code, String error_msg, String http_get);
    }
}