package com.tencent.qapmsdk.socket.util;

import android.support.annotation.RestrictTo;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.socket.TrafficSocketImplFactory;
import com.tencent.qapmsdk.socket.ssl.TrafficOpenSSLProvider;
import com.tencent.qapmsdk.socket.ssl.TrafficSSLSocketFactory;

import java.io.IOException;
import java.net.Socket;
import java.net.SocketImplFactory;
import java.security.Security;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.net.ssl.SSLContext;

/**
 * Created by nicorao on 2017/12/8.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY)
public class HookUtils {

    private static final String TAG = "QAPM_Socket_HookUtils";

    private static final TrafficHookCompatImpl HOOK_IMPL;

    static {
        HOOK_IMPL = new TrafficHookCompatImplBase();
    }

    private static AtomicBoolean sInit = new AtomicBoolean();

    public static void hook() {
        if (sInit.getAndSet(true)) {
            Magnifier.ILOGUTIL.w(TAG, "qapm socket traffic monitor has been hooked!");
            return;
        }
        try {
            HOOK_IMPL.hook();
            Magnifier.ILOGUTIL.i(TAG, "qapm socket traffic hook all success!");
        } catch (Throwable tr) {
            ReflectionHelper.processException(tr);
        }
    }

    private interface TrafficHookCompatImpl {
        void hook() throws Exception;
    }

    private static class TrafficHookCompatImplBase implements TrafficHookCompatImpl {

        void hookSocketFactoryImpl() throws Exception {
            try {
                Socket.setSocketImplFactory(new TrafficSocketImplFactory());
            } catch (IOException e) {
                // 由于Socket.factory只能设置一个，如果抛异常，可能是被设置了
                SocketImplFactory oldFactory = (SocketImplFactory) ReflectionHelper.of(Socket.class).field("factory").get(null);
                // 检查一下是不是已经设置过了
                if (!(oldFactory instanceof TrafficSocketImplFactory)) {
                    ReflectionHelper.of(Socket.class).field("factory").set(null, new TrafficSocketImplFactory(oldFactory));
                }
            }
        }

        @Override
        public void hook() throws Exception {
            // hook socket
            hookSocketFactoryImpl();
            Magnifier.ILOGUTIL.d(TAG, "hook SocketFactoryImpl success");
            // hook ssl socket
            // 1、插入自定义的OpenSSLProvider
            Security.insertProviderAt(new TrafficOpenSSLProvider(), 1);
            Magnifier.ILOGUTIL.d(TAG, "insert TrafficOpenSSLProvider success");
            // 2、更改ssl.SocketFactory.provider的值，影响SSLSocketFactory.getDefault的结果
            try {
                Security.setProperty("ssl.SocketFactory.provider", TrafficSSLSocketFactory.class.getName());
                Magnifier.ILOGUTIL.d(TAG, "set ssl.SocketFactory.provider property success");
            } catch (NullPointerException ignored) {
                // vivo funtouch 2.5 有bug
                Magnifier.ILOGUTIL.exception(TAG, "set socketfacotry provider failed!", ignored);
            }
            // 3、更新旧的Default
            try {
                SSLContext.setDefault(SSLContext.getInstance("Default"));
                Magnifier.ILOGUTIL.d(TAG, "change default SSLContext success");
            } catch (Exception e) {
                Magnifier.ILOGUTIL.exception(TAG, "update default sslcontext failed!", e);
            }
        }
    }
}

