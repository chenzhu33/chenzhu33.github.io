package com.tencent.qapmsdk.common;

import android.os.SystemClock;
import android.support.annotation.NonNull;

import com.tencent.qapmsdk.Magnifier;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * Created by nickyliu on 2017/10/31.
 */

public class AppInfo {
    @NonNull
    private static String TAG = ILogUtil.getTAG(AppInfo.class);
    private static int PROC_APP_START_FIELD = 21;
    private static final long CLOCK_TICKS_PER_SECOND = SysConf.getScClkTck(0);
    private static final String START_FILE = "/proc/self/stat";

    public static long launchTime() {
        long launchTime = 0;
        long appStartTime =0;
        if (CLOCK_TICKS_PER_SECOND <= 0 ){
            return launchTime;
        }
        RandomAccessFile procFile = null;
        long curTime = SystemClock.elapsedRealtime();
        try {
            File statFile = new File(START_FILE);
            if (statFile.isFile()){
                procFile = new RandomAccessFile(START_FILE, "r");
                String procFileContents = procFile.readLine();
                String[] fields =
                        procFileContents != null
                                ? procFileContents.split(" ", PROC_APP_START_FIELD + 2)
                                : null;

                if (fields == null || fields.length < PROC_APP_START_FIELD + 1) {
                    launchTime = 0;
                }
                else{
                    appStartTime = new Double(Long.parseLong(fields[PROC_APP_START_FIELD]) * 1.0 / CLOCK_TICKS_PER_SECOND * 1000).longValue();
                    launchTime = curTime - appStartTime;
                }
            }

        } catch (IOException ioe) {
            launchTime = 0;
        } finally {
            if (procFile != null) {
                try {
                    procFile.close();
                } catch (IOException ignored) {
                    // ignored
                }
            }
        }
        Magnifier.ILOGUTIL.d(TAG, "the cur time is " + String.valueOf(curTime) +
                ", the app start time is " + String.valueOf(appStartTime) +
                ", the launch time is " + String.valueOf(launchTime));
        return launchTime;
    }

}