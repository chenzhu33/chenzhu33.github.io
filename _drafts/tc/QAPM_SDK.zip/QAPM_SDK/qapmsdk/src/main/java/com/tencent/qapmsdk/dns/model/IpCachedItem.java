package com.tencent.qapmsdk.dns.model;

public class IpCachedItem {
    public String ip;
    public int hitTime;
    public double avgElapse;

    public IpCachedItem(String ip) {
        this.ip = ip;
    }

    @Override
    public String toString() {
        return "IpCachedItem{" +
                "ip='" + ip + '\'' +
                ", hitTime=" + hitTime +
                ", avgElapse=" + avgElapse +
                '}';
    }
}
