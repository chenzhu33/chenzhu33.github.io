package com.tencent.qapmsdk.socket.handler;


import com.tencent.qapmsdk.socket.model.SocketInfo;

public class HttpBodyLogInterceptor {

    private static IHttpBodyLogInterceptor sInterceptor;

    public static void setInterceptor(IHttpBodyLogInterceptor interceptor) {
        sInterceptor = interceptor;
    }

    public static byte[] intercept(byte[] body, SocketInfo socketInfo) {
        final IHttpBodyLogInterceptor interceptor = sInterceptor;
        if (interceptor != null) {
            return interceptor.intercept(body, socketInfo);
        }
        return body;
    }
}
