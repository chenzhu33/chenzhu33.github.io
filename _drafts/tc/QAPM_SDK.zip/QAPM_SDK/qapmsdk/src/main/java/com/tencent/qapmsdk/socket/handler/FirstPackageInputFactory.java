package com.tencent.qapmsdk.socket.handler;

import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.socket.model.SocketInfo;

public class FirstPackageInputFactory implements ITrafficInputStreamHandlerFactory {

    private FirstPackageInputMonitor firstPackageInputMonitor = new FirstPackageInputMonitor();

    public ITrafficInputStreamHandler create(){
        if (firstPackageInputMonitor == null){
            firstPackageInputMonitor = new FirstPackageInputMonitor();
        }
        return firstPackageInputMonitor;
    }

    private class FirstPackageInputMonitor implements ITrafficInputStreamHandler {
        public void onInput(@NonNull byte[] b, int off, int len, int read, @Nullable SocketInfo socketInfo){
            socketInfo.readStamp(SystemClock.elapsedRealtime());
        }
        public void onClose(){

        }
    }
}
