package com.tencent.qapmsdk.battery;

import android.support.annotation.Nullable;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

class HighFrequencyDetector {
    static final class Action {
        private long timestamp = 0l;
        @SuppressWarnings("unused")
        private Object userData;
    }

    @Nullable
    private LinkedList<Action> actionList = null;
    private int maxActionCount;
    private long detectInterval;

    HighFrequencyDetector(int actionCount, long interval) {
        actionList = new LinkedList<Action>();
        maxActionCount = actionCount;
        detectInterval = interval;
    }

    @Nullable
    List<Action> onAction(Object userData) {
        Action action = new Action();
        action.timestamp = System.currentTimeMillis();
        action.userData = userData;
        synchronized (actionList) {
            actionList.addLast(action);
            // 队列最多维护maxActionCount个数的数据
            if (actionList.size() < maxActionCount) {
                return null;
            }
            
            Action headerAction = actionList.getFirst();
            if (action.timestamp - headerAction.timestamp < detectInterval) {
                // detectInterval时间段内事件超频
                List<Action> rsList = new ArrayList<Action>(actionList);
                return rsList;
            } else {
                actionList.removeFirst();
                return null;
            }
        }
    }
    
    void trimCache() {
        synchronized(actionList) {
            actionList.clear();
        }
    }
    
//    public static String getDescription(List<Action> list) {
//        StringBuilder sb = new StringBuilder();
//        if (list != null && list.size() > 0) {
//            SimpleDateFormat formatter;
//            formatter = new SimpleDateFormat("HH点mm分ss", Locale.US);
//            sb.ensureCapacity(list.size() * (list.get(0).userData.toString().length() + 20));
//            for (Action action : list) {
//                sb.append("[").append(formatter.format(new Date(action.timestamp))).append(":").append(action.userData.toString()).append("]");
//            }
//        }
//        return sb.toString();
//    }
}