package com.tencent.qapmsdk.impl.instrumentation.httpclient;

import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.impl.api.data.TransactionData;
import com.tencent.qapmsdk.impl.instrumentation.QAPMHttpClientUtil;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionState;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMCountingInputStream;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMCountingOutputStream;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMStreamCompleteEvent;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMStreamCompleteListener;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMStreamCompleteListenerSource;
import com.tencent.qapmsdk.impl.model.HttpDataModel;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.http.Header;
import org.apache.http.HttpEntity;

public class QAPMHttpRequestEntityImpl implements QAPMStreamCompleteListener, HttpEntity {
    private final HttpEntity impl;
    private final QAPMTransactionState transactionState;

    public QAPMHttpRequestEntityImpl(HttpEntity impl, QAPMTransactionState transactionState) {
        this.impl = impl;
        this.transactionState = transactionState;
    }

    public void consumeContent() throws IOException {
        try {
            this.impl.consumeContent();
        } catch (IOException e) {
            QAPMHttpClientUtil.setErrorCodeFromException(this.transactionState, e);
            if (!this.transactionState.isComplete()) {
                TransactionData transactionData = this.transactionState.end();
                HttpDataModel.collectData(transactionData, e);
//                k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
            }

            throw e;
        }
    }

    public InputStream getContent() throws IOException, IllegalStateException {
        TransactionData transactionData;
        try {
            if (!this.transactionState.isSent()) {
                QAPMCountingInputStream inputStream = new QAPMCountingInputStream(this.impl.getContent());
                inputStream.addStreamCompleteListener(this);
                return inputStream;
            } else {
                return this.impl.getContent();
            }
        } catch (IOException e) {
            QAPMHttpClientUtil.setErrorCodeFromException(this.transactionState, e);
            if (!this.transactionState.isComplete()) {
                transactionData = this.transactionState.end();
                HttpDataModel.collectData(transactionData, e);
//                k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
            }

            throw e;
        } catch (IllegalStateException e1) {
            QAPMHttpClientUtil.setErrorCodeFromException(this.transactionState, e1);
            if (!this.transactionState.isComplete()) {
                transactionData = this.transactionState.end();
                HttpDataModel.collectData(transactionData, e1);
//                k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
            }

            throw e1;
        }
    }

    public Header getContentEncoding() {
        return this.impl.getContentEncoding();
    }

    public long getContentLength() {
        return this.impl.getContentLength();
    }

    public Header getContentType() {
        return this.impl.getContentType();
    }

    public boolean isChunked() {
        return this.impl.isChunked();
    }

    public boolean isRepeatable() {
        return this.impl.isRepeatable();
    }

    public boolean isStreaming() {
        return this.impl.isStreaming();
    }

    public void writeTo(OutputStream outstream) throws IOException {
        try {
            if (!this.transactionState.isSent()) {
                QAPMCountingOutputStream qapmCountingOutputStream = new QAPMCountingOutputStream(outstream);
                this.impl.writeTo(qapmCountingOutputStream);
                this.transactionState.setBytesSent(qapmCountingOutputStream.getCount());
            } else {
                this.impl.writeTo(outstream);
            }

        } catch (IOException e) {
            QAPMHttpClientUtil.setErrorCodeFromException(this.transactionState, e);
            if (!this.transactionState.isComplete()) {
                TransactionData transactionData = this.transactionState.end();
                HttpDataModel.collectData(transactionData, e);
//                k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
            }

            throw e;
        }
    }

    public void streamComplete(QAPMStreamCompleteEvent event) {
        QAPMStreamCompleteListenerSource source = (QAPMStreamCompleteListenerSource)event.getSource();
        source.removeStreamCompleteListener(this);
        this.transactionState.setBytesSent(event.getBytes());
    }

    public void streamError(QAPMStreamCompleteEvent event) {
        QAPMStreamCompleteListenerSource var2 = (QAPMStreamCompleteListenerSource)event.getSource();
        var2.removeStreamCompleteListener(this);
        QAPMHttpClientUtil.setErrorCodeFromException(this.transactionState, event.getException());
        if (!this.transactionState.isComplete()) {
            this.transactionState.setBytesSent(event.getBytes());
            TransactionData transactionData = this.transactionState.end();
            HttpDataModel.collectData(transactionData, event.getException());
//            k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
        }

    }
}
