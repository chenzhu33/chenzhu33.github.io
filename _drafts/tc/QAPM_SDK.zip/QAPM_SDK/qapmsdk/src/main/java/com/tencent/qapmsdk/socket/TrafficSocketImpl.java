package com.tencent.qapmsdk.socket;

import android.os.Build;
import android.os.SystemClock;
import android.support.annotation.RestrictTo;
import android.system.ErrnoException;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.dns.model.DnsInfo;
import com.tencent.qapmsdk.impl.report.TrafficMonitorReport;
import com.tencent.qapmsdk.socket.model.SocketInfo;
import com.tencent.qapmsdk.socket.util.ReflectionHelper;

import java.io.FileDescriptor;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketImpl;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


/**
 * Created by nicorao on 2017/12/6.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY)
public class TrafficSocketImpl extends SocketImpl {

    private static final String TAG = "QAPM_Socket_TrafficSocketImpl";

    private static final Map<String, Object> FIELD_CACHE = new ConcurrentHashMap<>();

    private static final Object EMPTY = new Object();

    private SocketImpl mOldImpl;

    private String mHost;
    private String mIP;
    private int mPort;

    private SocketInfo mSocketInfo = new SocketInfo();

    private TrafficInputStream mIn;
    private TrafficOutputStream mOut;

    TrafficSocketImpl(SocketImpl impl) {
        mOldImpl = impl;
        update();
    }

    public SocketImpl getOldImpl() {
        return mOldImpl;
    }

    private Object getField(String fieldName) {
        Object obj = FIELD_CACHE.get(fieldName);
        if (obj == null) {
            try {
                obj = ReflectionHelper.of(SocketImpl.class).field(fieldName);
            } catch (NoSuchFieldException e) {
                Magnifier.ILOGUTIL.w(TAG, "get field ", fieldName, " error: ", e.toString());
                obj = EMPTY;
            }
            FIELD_CACHE.put(fieldName, obj);
        }
        return obj;
    }

    private void update(String fieldName, Object from, Object to) {
        Object obj = getField(fieldName);
        if (obj instanceof Field) {
            Field field = (Field) obj;
            try {
                field.set(to, field.get(from));
            } catch (IllegalAccessException e) {
                Magnifier.ILOGUTIL.w(TAG, "set field ", fieldName, "error: ", e.toString());
            }
        }
    }

    private void update() {
        // 需要从mOldImpl同步回TrafficSocketImpl的变量：
        // 1、fd
        // 2、address
        // 3、port
        // 4、localport
        update("fd", mOldImpl, this);
        update("address", mOldImpl, this);
        update("port", mOldImpl, this);
        update("localport", mOldImpl, this);
        // 需要从TrafficSocketImpl同步回mOldImpl的变量：
        // 1、socket
        // 2、serverSocket
        update("socket", this, mOldImpl);
        update("serverSocket", this, mOldImpl);
    }

    private String getFd() {
        Object fd = null;
        try {
            fd = ReflectionHelper.of(SocketImpl.class).field("fd").get(this);
        } catch (Exception ignored) {}
        return ReflectionHelper.printFd(fd);
    }

    private int getImplHashCode() {
        return mOldImpl != null ? mOldImpl.hashCode() : 0;
    }

    @Override
    protected void create(boolean stream) throws IOException {
        try {
            ReflectionHelper.of(mOldImpl.getClass()).method("create", boolean.class).invoke(mOldImpl, stream);
        } catch (Exception e) {
            if (e instanceof InvocationTargetException && e.getCause() instanceof IOException) {
                throw (IOException) e.getCause();
            }
            ReflectionHelper.processException(e);
            throw new IOException(e);
        }
        update();
    }

    @Override
    protected void connect(String host, int port) throws IOException {
        if (!TrafficMonitor.config().isEnableNetwork()) throw new IOException("Disable network by developer!");
        mHost = host;
        mIP = "";
        mPort = port;
        final long start = SystemClock.elapsedRealtime();
        try {
            ReflectionHelper.of(mOldImpl.getClass()).method("connect", String.class, int.class).invoke(mOldImpl, host, port);
            TrafficConnectReporter.onConnected(true, mHost, mPort, (SystemClock.elapsedRealtime() - start), mSocketInfo);
        } catch (Exception e) {
            mSocketInfo.exception = e;
            TrafficConnectReporter.onConnected(false, mHost, mPort, (SystemClock.elapsedRealtime() - start), mSocketInfo);
            if (e instanceof InvocationTargetException && e.getCause() instanceof IOException) {
                throw (IOException) e.getCause();
            }
            ReflectionHelper.processException(e);
            throw new IOException(e);
        }
        update();
    }

    @Override
    protected void connect(InetAddress address, int port) throws IOException {
        if (!TrafficMonitor.config().isEnableNetwork()) throw new IOException("Disable network by developer!");
        mHost = address.getHostName();
        mIP = address.getHostAddress();
        mPort = port;
        final long start = SystemClock.elapsedRealtime();
        try {
            ReflectionHelper.of(mOldImpl.getClass()).method("connect", InetAddress.class, int.class).invoke(mOldImpl, address, port);
            TrafficConnectReporter.onConnected(true, mHost, mPort, (SystemClock.elapsedRealtime() - start), mSocketInfo);
        } catch (Exception e) {
            mSocketInfo.exception = e;
            TrafficConnectReporter.onConnected(false, mHost, mPort, (SystemClock.elapsedRealtime() - start), mSocketInfo);
            if (e instanceof InvocationTargetException && e.getCause() instanceof IOException) {
                throw (IOException) e.getCause();
            }
            ReflectionHelper.processException(e);
            throw new IOException(e);
        }
        update();
    }

    @Override
    protected void connect(SocketAddress address, int timeout) throws IOException {
        if (!TrafficMonitor.config().isEnableNetwork()) throw new IOException("Disable network by developer!");
        if (address instanceof InetSocketAddress) {
            InetSocketAddress isa = (InetSocketAddress) address;
            if (Build.VERSION.SDK_INT >= 19) {
                mHost = isa.getHostString() ;
            } else {
                mHost = isa.getHostName();
            }
            mIP = isa.isUnresolved() ? "" : isa.getAddress().getHostAddress();
            if (mHost.equals(mIP)){
                mHost = DnsInfo.getHostFromIp(mIP);
            }
            mPort = isa.getPort();
        }
        final long start = SystemClock.elapsedRealtime();
        try {
            ReflectionHelper.of(mOldImpl.getClass()).method("connect", SocketAddress.class, int.class).invoke(mOldImpl, address, timeout);
            TrafficConnectReporter.onConnected(true, mHost, mPort, (SystemClock.elapsedRealtime() - start), mSocketInfo);
        } catch (Exception e) {
            mSocketInfo.exception = e;
            TrafficConnectReporter.onConnected(false, mHost, mPort, (SystemClock.elapsedRealtime() - start), mSocketInfo);
            if (e instanceof InvocationTargetException) {
                final int sdk = Build.VERSION.SDK_INT;
                Throwable cause = e.getCause();
                if (cause instanceof IOException) {
                    throw (IOException) cause;
                } else if (cause instanceof ClassCastException) {
                    // On android 8.0, socket.connect throws a ClassCastException due to a bug
                    // see https://issuetracker.google.com/issues/63649622 and https://github.com/square/okhttp/pull/3624/commits/a141f98bdc24857efcb8ae99b6d11c03846c9567
                    throw new IOException(e);
                } else if (sdk >= 21 && cause instanceof ErrnoException && cause.getMessage().contains("EBADF")) {
                    // 应该也是系统的bug，可能是FD被回收了
                    throw new IOException(e);
                } else if (sdk >= 21 && cause instanceof ErrnoException && cause.getMessage().contains("EACCES")) {
                    // 没有权限
                    throw new IOException(e);
                } else if (sdk >= 21 && cause instanceof ErrnoException && cause.getMessage().contains("ENOTSOCK")) {
                    // Socket operation on non-socket，不知道什么错误
                    throw new IOException(e);
                } else if (sdk >= 21 && cause instanceof ErrnoException && cause.getMessage().contains("ENETUNREACH")) {
                    // 网络不可用
                    throw new IOException(e);
                }
            }
            ReflectionHelper.processException(e);
            throw new IOException(e);
        }
        update();
    }

    @Override
    protected void bind(InetAddress host, int port) throws IOException {
        if (!TrafficMonitor.config().isEnableNetwork()) throw new IOException("Disable network by developer!");
        try {
            ReflectionHelper.of(mOldImpl.getClass()).method("bind", InetAddress.class, int.class).invoke(mOldImpl, host, port);
        } catch (Exception e) {
            if (e instanceof InvocationTargetException && e.getCause() instanceof IOException) {
                throw (IOException) e.getCause();
            }
            ReflectionHelper.processException(e);
            throw new IOException(e);
        }
        update();
    }

    @Override
    protected void listen(int backlog) throws IOException {
        if (!TrafficMonitor.config().isEnableNetwork()) throw new IOException("Disable network by developer!");
        try {
            ReflectionHelper.of(mOldImpl.getClass()).method("listen", int.class).invoke(mOldImpl, port);
        } catch (Exception e) {
            if (e instanceof InvocationTargetException && e.getCause() instanceof IOException) {
                throw (IOException) e.getCause();
            }
            ReflectionHelper.processException(e);
            throw new IOException(e);
        }
        update();
    }

    @Override
    protected void accept(SocketImpl s) throws IOException {
        if (!TrafficMonitor.config().isEnableNetwork()) throw new IOException("Disable network by developer!");
        try {
            ReflectionHelper.of(mOldImpl.getClass()).method("accept", SocketImpl.class).invoke(mOldImpl, s);
        } catch (Exception e) {
            if (e instanceof InvocationTargetException && e.getCause() instanceof IOException) {
                throw (IOException) e.getCause();
            }
            ReflectionHelper.processException(e);
            throw new IOException(e);
        }
        update();
    }

    @Override
    protected InputStream getInputStream() throws IOException {
        if (!TrafficMonitor.config().isEnableNetwork()) throw new IOException("Disable network by developer!");
        if (mIn == null) {
            try {
                mIn = new TrafficInputStream(
                        (InputStream) ReflectionHelper.of(mOldImpl.getClass()).method("getInputStream").invoke(mOldImpl),
                        mSocketInfo);
            } catch (Exception e) {
                if (e instanceof InvocationTargetException && e.getCause() instanceof IOException) {
                    throw (IOException) e.getCause();
                }
                ReflectionHelper.processException(e);
                throw new IOException(e);
            }
        }
        mSocketInfo.isEnd = false;
        return mIn;
    }

    @Override
    protected OutputStream getOutputStream() throws IOException {
        if (!TrafficMonitor.config().isEnableNetwork()) throw new IOException("Disable network by developer!");
        if (mOut == null) {
            try {
                mOut = new TrafficOutputStream((OutputStream) ReflectionHelper.of(mOldImpl.getClass()).method("getOutputStream").invoke(mOldImpl), mSocketInfo);

                mOut.initData(false, mHost, mIP, mPort, getFd(), getImplHashCode());

            } catch (Exception e) {
                if (e instanceof InvocationTargetException && e.getCause() instanceof IOException) {
                    throw (IOException) e.getCause();
                }
                ReflectionHelper.processException(e);
                throw new IOException(e);
            }
        }
        return mOut;
    }

    @Override
    protected int available() throws IOException {
        int result;
        try {
            result = (int) ReflectionHelper.of(mOldImpl.getClass()).method("available").invoke(mOldImpl);
        } catch (Exception e) {
            if (e instanceof InvocationTargetException && e.getCause() instanceof IOException) {
                throw (IOException) e.getCause();
            }
            ReflectionHelper.processException(e);
            throw new IOException(e);
        }
        return result;
    }

    @Override
    protected void close() throws IOException {
        try {
            ReflectionHelper.of(mOldImpl.getClass()).method("close").invoke(mOldImpl);
            //socket处理结束后上报
            TrafficMonitorReport.getInstance().doReport();
        } catch (Exception e) {
            if (e instanceof InvocationTargetException) {
                if (e.getCause() instanceof IOException) {
                    throw (IOException) e.getCause();
                } else if (e.getCause() instanceof NullPointerException) {
                    // 魅族close时有bug
                    throw new IOException(e);
                }
            }
            ReflectionHelper.processException(e);
            throw new IOException(e);
        }
        update();
    }

    @Override
    protected void sendUrgentData(int data) throws IOException {
        try {
            ReflectionHelper.of(mOldImpl.getClass()).method("sendUrgentData", int.class).invoke(mOldImpl, data);
        } catch (Exception e) {
            if (e instanceof InvocationTargetException && e.getCause() instanceof IOException) {
                throw (IOException) e.getCause();
            }
            ReflectionHelper.processException(e);
            throw new IOException(e);
        }
    }

    @Override
    public void setOption(int optID, Object value) throws SocketException {
        mOldImpl.setOption(optID, value);
    }

    @Override
    public Object getOption(int optID) throws SocketException {
        return mOldImpl.getOption(optID);
    }

    @Override
    protected void shutdownInput() throws IOException {
        try {
            ReflectionHelper.of(mOldImpl.getClass()).method("shutdownInput").invoke(mOldImpl);
        } catch (Exception e) {
            if (e instanceof InvocationTargetException && e.getCause() instanceof IOException) {
                throw (IOException) e.getCause();
            }
            ReflectionHelper.processException(e);
            throw new IOException(e);
        }
    }

    @Override
    protected void shutdownOutput() throws IOException {
        try {
            ReflectionHelper.of(mOldImpl.getClass()).method("shutdownOutput").invoke(mOldImpl);
        } catch (Exception e) {
            if (e instanceof InvocationTargetException && e.getCause() instanceof IOException) {
                throw (IOException) e.getCause();
            }
            ReflectionHelper.processException(e);
            throw new IOException(e);
        }
    }

    @Override
    protected FileDescriptor getFileDescriptor() {
        try {
            return (FileDescriptor) ReflectionHelper.of(mOldImpl.getClass()).method("getFileDescriptor").invoke(mOldImpl);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        return super.getFileDescriptor();
    }

    @Override
    protected InetAddress getInetAddress() {
        try {
            return (InetAddress) ReflectionHelper.of(mOldImpl.getClass()).method("getInetAddress").invoke(mOldImpl);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        return super.getInetAddress();
    }

    @Override
    protected int getPort() {
        try {
            return (int) ReflectionHelper.of(mOldImpl.getClass()).method("getPort").invoke(mOldImpl);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        return super.getPort();
    }

    @Override
    protected boolean supportsUrgentData() {
        try {
            return (boolean) ReflectionHelper.of(mOldImpl.getClass()).method("supportsUrgentData").invoke(mOldImpl);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        return super.supportsUrgentData();
    }

    @Override
    protected int getLocalPort() {
        try {
            return (int) ReflectionHelper.of(mOldImpl.getClass()).method("getLocalPort").invoke(mOldImpl);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        return super.getLocalPort();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("TrafficSocketImpl[");
        try {
            sb.append(ReflectionHelper.of(mOldImpl.getClass()).method("toString").invoke(mOldImpl));
        } catch (Exception ignored) {
            sb.append(super.toString());
        }
        return sb.append("]").toString();
    }

    @Override
    protected void setPerformancePreferences(int connectionTime, int latency, int bandwidth) {
        try {
            ReflectionHelper.of(mOldImpl.getClass()).method("setPerformancePreferences", int.class, int.class, int.class).invoke(mOldImpl, connectionTime, latency, bandwidth);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        super.setPerformancePreferences(connectionTime, latency, bandwidth);
    }
}
