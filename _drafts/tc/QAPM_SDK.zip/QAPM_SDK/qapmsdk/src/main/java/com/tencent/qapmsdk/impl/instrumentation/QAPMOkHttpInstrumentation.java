package com.tencent.qapmsdk.impl.instrumentation;

import com.tencent.qapmsdk.Magnifier;

import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class QAPMOkHttpInstrumentation {
    private final static String TAG = "QAPM_Impl_QAPMOkHttpInstrumentation";
    public QAPMOkHttpInstrumentation() {
    }

    @QAPMWrapReturn(
            className = "com/squareup/okhttp/OkHttpClient",
            methodName = "open",
            methodDesc = "(Ljava/net/URL;)Ljava/net/HttpURLConnection;"
    )
    public static HttpURLConnection open(HttpURLConnection connection) {
        Magnifier.ILOGUTIL.d(TAG, "OkHttpInstrumentation - wrapping return of call to open");
        connection = processControllerDispatch(connection);
        if (connection == null) {
            return connection;
        } else if (connection instanceof HttpsURLConnection) {
            return new QAPMHttpsURLConnectionExtension((HttpsURLConnection)connection);
        } else {
            return (HttpURLConnection)(connection != null ? new QAPMHttpURLConnectionExtension(connection) : connection);
        }
    }

    @QAPMWrapReturn(
            className = "com/squareup/okhttp/OkHttpClient",
            methodName = "open",
            methodDesc = "(Ljava/net/URL;Ljava/net/Proxy)Ljava/net/HttpURLConnection;"
    )
    public static HttpURLConnection openWithProxy(HttpURLConnection connection) {
        Magnifier.ILOGUTIL.d(TAG, "OkHttpInstrumentation -wrapping return of call to openWithProxy");
        connection = processControllerDispatch(connection);
        if (connection instanceof HttpsURLConnection) {
            return new QAPMHttpsURLConnectionExtension((HttpsURLConnection)connection);
        } else {
            return (HttpURLConnection)(connection != null ? new QAPMHttpURLConnectionExtension(connection) : connection);
        }
    }

    @QAPMWrapReturn(
            className = "com/squareup/okhttp/OkUrlFactory",
            methodName = "open",
            methodDesc = "(Ljava/net/URL;)Ljava/net/HttpURLConnection;"
    )
    public static HttpURLConnection urlFactoryOpen(HttpURLConnection connection) {
        Magnifier.ILOGUTIL.d(TAG, "OkHttpInstrumentation - wrapping return of call to OkUrlFactory.open...");
        connection = processControllerDispatch(connection);
        if (connection instanceof HttpsURLConnection) {
            return new QAPMHttpsURLConnectionExtension((HttpsURLConnection)connection);
        } else {
            return (HttpURLConnection)(connection != null ? new QAPMHttpURLConnectionExtension(connection) : connection);
        }
    }

    private static HttpURLConnection processControllerDispatch(HttpURLConnection connection) {
        if (connection == null) {
            return connection;
        } else {
            URL url = connection.getURL();
            String host = url.getHost();
            return connection;
        }
    }

}