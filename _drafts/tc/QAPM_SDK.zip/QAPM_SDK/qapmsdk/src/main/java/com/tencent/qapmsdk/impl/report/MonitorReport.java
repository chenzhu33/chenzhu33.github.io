package com.tencent.qapmsdk.impl.report;

import android.os.Handler;

import com.tencent.qapmsdk.common.ThreadManager;
import com.tencent.qapmsdk.impl.util.TraceUtil;
import com.tencent.qapmsdk.sample.SingleItem;
import com.tencent.qapmsdk.sample.TagItem;
import com.tencent.qapmsdk.sample.TagType;

import java.util.Vector;

public class MonitorReport {
    private Vector<TagItem> monitorItems = new Vector<>();
    private Vector<SingleItem> singleItems = new Vector<>();
    static volatile boolean hasReport = false;
    private static volatile MonitorReport instance = null;

    private MonitorReport(){

    }

    public static MonitorReport getInstance(){
        if (instance == null){
            synchronized (MonitorReport.class){
                if (instance == null){
                    instance = new MonitorReport();
                }
            }
        }
        return instance;
    }


    Vector<TagItem> getMonitorItems(){
        return this.monitorItems;
    }

    Vector<SingleItem> getSingleItems(){
        return this.singleItems;
    }



    public void addMonitorMetric(long tagId,long beginTime, long endTime,
                                 String stageName, String subStage, boolean isSlow){
        if (endTime - beginTime < 0){
            return;
        }

        TagItem beginItem = new TagItem();
        beginItem.duringTime = 0;
        beginItem.stage = stageName;
        beginItem.subStage = subStage;
        beginItem.extraInfo = "";
        beginItem.eventTime = beginTime / 1000.0;
        beginItem.tagId = tagId;
        beginItem.type = TagType.BEGINTAG;
        beginItem.isSlow = isSlow;
        monitorItems.add(beginItem);

        TagItem endItem = new TagItem();
        endItem.duringTime = endTime - beginTime;
        endItem.stage = stageName;
        endItem.subStage = subStage;
        endItem.extraInfo = "";
        endItem.eventTime = endTime / 1000.0;
        endItem.tagId = tagId;
        endItem.isSlow = isSlow;
        endItem.type = TagType.ENDTAG;
        monitorItems.add(endItem);

    }

    public void addMonitorSingle(long costTime, long eventTime,
                                 String stageName, String extraData){
        SingleItem singleItem = new SingleItem();
        singleItem.costTime = costTime;
        singleItem.stage = stageName;
        singleItem.extraData = extraData;
        singleItem.eventTime = eventTime;
        singleItems.add(singleItem);

    }


    public void doReport(){
        if (!hasReport){
            Handler h = new Handler(ThreadManager.getMonitorThreadLooper());
            ReportRunnable reportRunnable = ReportRunnable.getInstance();
            //todo: 调整上报频率
            h.postDelayed(reportRunnable, TraceUtil.REPORT_THRESHOLD);
            hasReport = true;
        }
    }
}
