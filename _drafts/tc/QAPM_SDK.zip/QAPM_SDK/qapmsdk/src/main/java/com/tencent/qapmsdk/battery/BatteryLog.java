package com.tencent.qapmsdk.battery;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Pair;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.BaseListener;
import com.tencent.qapmsdk.common.FileUtil;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.ThreadManager;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BatteryLog {
    private static final String TAG = ILogUtil.getTAG(BatteryLog.class);
    @Nullable
    private static Handler sWriteHandler ;
    private static String sCommonFileName;
    private static String sReportFileName;
    private static String processName;
    private static long logInitTimestamp;
    private static BufferedWriter sCommonWriter;
    private static BufferedWriter sReportWriter;
    @NonNull
    private static String logPath = FileUtil.getRootPath() + "/battery/";
    private static final String FORMAT_VERSION = "1.3";
    public static BatteryReportListener brListener;

    static void init(String _processName, long timestamp) {
        processName = _processName;
        logInitTimestamp = timestamp;
        sWriteHandler = new LogHandler(ThreadManager.getBatteryThreadLooper());
        sWriteHandler.sendEmptyMessage(MSG_INIT_LOG);
    }

    public interface BatteryReportListener extends BaseListener {
        @NonNull
        List<String> onBeforeReport();
    }

    static void writeReportLog(Object... objs) {
        if (sWriteHandler != null && sReportWriter != null) {
            Message msg = sWriteHandler.obtainMessage(MSG_WRITE_LOG, 1, 0, objs);
            msg.sendToTarget();
        }
    }
    
    static void writeCommonLog(Object... objs) {
        if (sWriteHandler != null && sCommonWriter != null) {
            Message msg = sWriteHandler.obtainMessage(MSG_WRITE_LOG, 0, 0, objs);
            msg.sendToTarget();
        }
    }

    static void cleanStorage(long deadLine) {
        if (sWriteHandler != null) {
            Message msg = sWriteHandler.obtainMessage(MSG_CLEAN_LOG, deadLine);
            msg.sendToTarget();
        }
    }
    
    private static String getRevision() {
        if ("0".equals(Magnifier.revision) || TextUtils.isEmpty(Magnifier.info.version))
            return Magnifier.revision;
        String regex = "(\\d+\\.\\d+\\.\\d+)[\\.\\d-]*\\.r?(\\d+)";
        Matcher m = Pattern.compile(regex).matcher(Magnifier.info.version);
        int i = 0;
        while (m.find(i)) {
            if (i == 2) {
                Magnifier.revision = m.group(i);
                return Magnifier.revision;
            }
            i += 1;
        }
        return Magnifier.revision;
    }

    private static final int MSG_INIT_LOG = 0;
    private static final int MSG_CLEAN_LOG = 1;
    private static final int MSG_WRITE_LOG = 2;

    private static class LogHandler extends Handler {
        private LogHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(@NonNull Message msg) {
            if (msg.what == MSG_INIT_LOG) {
                sCommonFileName = logPath + processName + "_" + logInitTimestamp + ".log";
                sReportFileName = logPath + processName + "_" + logInitTimestamp + ".rpt";
                File directoryFile = new File(logPath);
                File commonLogFile = new File(sCommonFileName);
                File reportLogFile = new File(sReportFileName);
                try {
                    if (commonLogFile.exists()) {
                        commonLogFile.delete();
                    }
                    if (reportLogFile.exists()) {
                        reportLogFile.delete();
                    }
                    if (!directoryFile.exists()) {
                        directoryFile.mkdirs();
                    }
                    commonLogFile.createNewFile();
                    sCommonWriter = new BufferedWriter(new FileWriter(commonLogFile), 8 * 1024);
                    reportLogFile.createNewFile();
                    sReportWriter = new BufferedWriter(new FileWriter(reportLogFile), 8 * 1024);
                    String buildType = "pub";
                    //TODO这里要传revision号       AppSetting.revision
                    writeCommonLog("header", Magnifier.info.version, getRevision(), buildType, Magnifier.info.uuid,
                            android.os.Build.MANUFACTURER, android.os.Build.MODEL, android.os.Build.VERSION.SDK_INT,
                            logInitTimestamp, FORMAT_VERSION);
                } catch (Throwable e) {
                }
                Magnifier.ILOGUTIL.d(TAG, "start LogHandler init");
            } else if (msg.what == MSG_WRITE_LOG) {
                @SuppressWarnings("resource")
                BufferedWriter writer = msg.arg1 == 0 ? sCommonWriter : sReportWriter;
                if (writer != null) {
                    StringBuilder sb = getReuseStringBuilder();
                    for (Object obj : (Object[]) msg.obj) {
                        if ((obj instanceof Object[]) || (obj instanceof String[])) {
                            for (Object subObj : (Object[]) obj) {
                                sb.append(subObj);
                            }
                        } else {
                            sb.append(obj).append("|");
                        }
                    }
                    sb.append("\r\n");
                    try {
                        writer.write(sb.toString());
                        writer.flush();
                    } catch (Throwable t) {
                        Magnifier.ILOGUTIL.exception(TAG, t);
                    }
                    Magnifier.ILOGUTIL.i(TAG, " start MSG_WRITE ", sb.toString());
                }
            } else if (msg.what == MSG_CLEAN_LOG) {
                try {
                    File[] files = new File(logPath).listFiles();
                    for (File file : files) {
                        // try的范围写大，防止目录下出现不合法文件，对于这种文件直接删除
                        try {
                            boolean shouldDelete = true;
                            long fileTime = getFileTime(file);
                            if (fileTime != -1 && fileTime > (Long) msg.obj) {
                                shouldDelete = false;
                            }
                            if (shouldDelete) {
                                file.delete();
                            }
                        } catch (Throwable t) {
                            try {
                                file.delete();
                            } catch (Throwable t1) {}
                        }
                    }
                } catch (Throwable t) {
                }
                Magnifier.ILOGUTIL.d(TAG, "start MSG_CLEAN");
            }
        }
    }
    
    static List<File> getReportLogFile(long timeStart, long timeEnd, long minFileSize) {
        File logDirect = new File(logPath);
        if (!logDirect.exists()) {
            return null;
        }
        List<File> rsList = new ArrayList<File>();
        try {
            File[] fileList = logDirect.listFiles();
            if (fileList == null){
                return rsList;
            }
            for (File file : fileList) {
                if (file.getName() == null || !file.getName().endsWith(".rpt")) {
                    continue;
                }
                long fileTime = getFileTime(file);
                if (fileTime != -1 && fileTime < timeEnd && fileTime > timeStart) {
                    // 判断文件大小
                    if (file.length() > minFileSize) {
                        rsList.add(file);
                    }
                }
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
        return rsList;
    }
    
    static Pair<Long, File> getCommonLogFileForReport(long timeStart, long timeEnd, int maxCount, long minFileSize) {
        File logDirect = new File(logPath);
        if (!logDirect.exists()) {
            return null;
        }
        File zipFile = null;
        List<String> toReportFileList = new ArrayList<String>();
        long lastestTime = 0l;
        try {
            File[] fileList = logDirect.listFiles();
            for (File file : fileList) {
                if (file.getName() == null || !file.getName().endsWith(".log")) {
                    continue;
                }
                long fileTime = getFileTime(file);
                if (fileTime != -1 && fileTime < timeEnd && fileTime > timeStart) {
                    // 判断文件大小
                    if (file.length() > minFileSize) {
                        if (maxCount -- > 0) {
                            toReportFileList.add(file.getAbsolutePath());
                        }
                        if (fileTime > lastestTime) {
                            lastestTime = fileTime;
                        }
                    }
                }
            }
            
            if (toReportFileList.size() > 0) {
                if (brListener != null) {
                    List<String> logFileList = brListener.onBeforeReport();
                    for (String log : logFileList) { 
                        toReportFileList.add(log);
                    }
                }
                String outputPath = logPath + timeEnd + ".zip";
                if (FileUtil.zipFiles(toReportFileList, outputPath)) {
                    zipFile = new File(outputPath);
                    if (!zipFile.exists()) {
                        zipFile = null;
                    }
                } else {
                    Magnifier.ILOGUTIL.e(TAG, "zip fail");
                }
            }
        } catch (Throwable t) {
            Magnifier.ILOGUTIL.exception(TAG, t);
        }
        return new Pair<Long, File>(lastestTime, zipFile);
    }
    
    /**
     * 日志文件时间</br>
     * @param file
     * @return - -1表示文件格式不认识，其他值表示时间
     */
    private static long getFileTime(File file) {
        String tempName = file.getName();
        try {
            String timestamp = tempName.substring(tempName.indexOf("_") + 1);
            if (timestamp.endsWith(".log") || timestamp.endsWith(".zip") || timestamp.endsWith("rpt")) {
                timestamp = timestamp.substring(0, timestamp.length() - 4);
                return Long.valueOf(timestamp);
            }
        } catch (Exception e) {}
        return -1;
    }

    @NonNull
    private static ThreadLocal<StringBuilder> sSbLocal = new ThreadLocal<StringBuilder>();

    /**
     * StringBuilder复用，禁止切换线程持有
     * 
     * @return
     */
    static StringBuilder getReuseStringBuilder() {
        StringBuilder sb = sSbLocal.get();
        if (sb == null) {
            sb = new StringBuilder(1024);
            sSbLocal.set(sb);
        } else {
            sb.delete(0, sb.length());
        }
        return sb;
    }
}