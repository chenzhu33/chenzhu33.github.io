package com.tencent.qapmsdk.impl.instrumentation;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.httpOprate.QAPMHTTPInterceptor;
import com.tencent.qapmsdk.impl.httpOprate.QAPMHttpCall;
import com.tencent.qapmsdk.impl.util.TraceUtil;

import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.OkUrlFactory;


public class QAPMOkHttp3Instrumentation {
    private final static String TAG = "QAPM_Impl_QAPMOkHttp3Instrumentation";
    public QAPMOkHttp3Instrumentation() {
    }

    public static OkHttpClient init() {
        return (new OkHttpClient.Builder()).addInterceptor(new QAPMHTTPInterceptor()).build();
    }

    public static OkHttpClient.Builder builderInit() {
        return (new OkHttpClient.Builder()).addInterceptor(new QAPMHTTPInterceptor());
    }

    @QAPMReplaceCallSite
    public static Call newCall(OkHttpClient client, Request request) {
        return new QAPMHttpCall(client, request);
    }

    @QAPMReplaceCallSite
    public static HttpURLConnection open(OkUrlFactory factory, URL url) {
        try {
            String host = url.getHost();
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMOkHttp3Instrumentation open has an error :" , e);
        }

        HttpURLConnection httpURLConnection = factory.open(url);
        if (httpURLConnection == null) {
            return null;
        }
        else if (!TraceUtil.getCanMonitorHttp()) {
            return httpURLConnection;
        }
        else {
            Magnifier.ILOGUTIL.d(TAG, "okhttp3  open gather  begin !!");
            if (httpURLConnection instanceof HttpsURLConnection) {
                return new QAPMHttpsURLConnectionExtension((HttpsURLConnection)httpURLConnection);
            } else {
                return (HttpURLConnection)(httpURLConnection instanceof HttpURLConnection ? new QAPMHttpURLConnectionExtension(httpURLConnection) : httpURLConnection);
            }
        }
    }

}
