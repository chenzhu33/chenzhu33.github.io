package com.tencent.qapmsdk.impl.instrumentation;

import android.text.TextUtils;
import android.util.Log;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.util.TraceUtil;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import javax.net.ssl.HttpsURLConnection;

public class QAPMInstrumentation {
    private final static String TAG = "QAPM_Impl_QAPMInstrumentation";

    public QAPMInstrumentation() {
    }

    @QAPMWrapReturn(
            className = "java/net/URL",
            methodName = "openConnection",
            methodDesc = "()Ljava/net/URLConnection;"
    )
    public static URLConnection openConnection(URLConnection connection) {
        try {
            if (connection == null) {
                return connection;
            } else if (!TraceUtil.getCanMonitorHttp()) {
                return connection;
            } else {
                Magnifier.ILOGUTIL.d(TAG, "URLConnection openConnection gather  begin !!");
                if (connection instanceof HttpsURLConnection) {
                    return new QAPMHttpsURLConnectionExtension((HttpsURLConnection)connection);
                } else {
                    return (URLConnection)(connection instanceof HttpURLConnection ? new QAPMHttpURLConnectionExtension((HttpURLConnection)connection) : connection);
                }
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.e(TAG, "QAPMInstrumentation openConnection() has an error : " , e.toString());
            return connection;
        }
    }

    @QAPMWrapReturn(
            className = "java.net.URL",
            methodName = "openConnection",
            methodDesc = "(Ljava/net/Proxy;)Ljava/net/URLConnection;"
    )
    public static URLConnection openConnectionWithProxy(URLConnection connection) {
        try {
            if (connection == null) {
                return connection;
            } else if (!TraceUtil.getCanMonitorHttp()) {
                return connection;
            } else {
                Magnifier.ILOGUTIL.d(TAG, "URLConnection openConnectionWithProxy gather  begin !!");
                if (connection instanceof HttpsURLConnection) {
                    return new QAPMHttpsURLConnectionExtension((HttpsURLConnection)connection);
                } else {
                    return (URLConnection)(connection instanceof HttpURLConnection ? new QAPMHttpURLConnectionExtension((HttpURLConnection)connection) : connection);
                }
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.e(TAG, "QAPMInstrumentation openConnectionWithProxy() has an error : " , e.toString());
            return connection;
        }
    }

}
