package com.tencent.qapmsdk.socket.model;

import java.io.EOFException;

public class Utf8Checker {

    private static final int REPLACEMENT_CHARACTER = '\ufffd';

    private int prefixOffset;

    public boolean isPlaintext(byte[] buffer) {
        try {
            int byteCount = buffer.length < 64 ? buffer.length : 64;
            byte[] prefix = new byte[byteCount];
            System.arraycopy(buffer, 0, prefix, 0, byteCount);
            for (int i = 0; i < 16; i++) {
                if (prefix.length - prefixOffset == 0) {
                    break;
                }
                int codePoint = readUtf8CodePoint(prefix);
                if (Character.isISOControl(codePoint) && !Character.isWhitespace(codePoint)) {
                    return false;
                }
            }
            return true;
        } catch (EOFException e) {
            return false; // Truncated UTF-8 sequence.
        }
    }

    private int readUtf8CodePoint(byte[] buffer) throws EOFException {
        if (buffer.length - prefixOffset == 0) throw new EOFException();

        byte b0 = buffer[prefixOffset];
        int codePoint;
        int byteCount;
        int min;

        if ((b0 & 0x80) == 0) {
            // 0xxxxxxx.
            codePoint = b0 & 0x7f;
            byteCount = 1; // 7 bits (ASCII).
            min = 0x0;

        } else if ((b0 & 0xe0) == 0xc0) {
            // 0x110xxxxx
            codePoint = b0 & 0x1f;
            byteCount = 2; // 11 bits (5 + 6).
            min = 0x80;

        } else if ((b0 & 0xf0) == 0xe0) {
            // 0x1110xxxx
            codePoint = b0 & 0x0f;
            byteCount = 3; // 16 bits (4 + 6 + 6).
            min = 0x800;

        } else if ((b0 & 0xf8) == 0xf0) {
            // 0x11110xxx
            codePoint = b0 & 0x07;
            byteCount = 4; // 21 bits (3 + 6 + 6 + 6).
            min = 0x10000;

        } else {
            // We expected the first byte of a code point but got something else.
            prefixOffset += 1;
            return REPLACEMENT_CHARACTER;
        }

        if (buffer.length - prefixOffset < byteCount) {
            throw new EOFException("size < " + byteCount + ": " + (buffer.length - prefixOffset)
                    + " (to read code point prefixed 0x" + Integer.toHexString(b0) + ")");
        }

        // Read the continuation bytes. If we encounter a non-continuation byte, the sequence consumed
        // thus far is truncated and is decoded as the replacement character. That non-continuation byte
        // is left in the stream for processing by the next call to readUtf8CodePoint().
        for (int i = 1; i < byteCount; i++) {
            byte b = buffer[prefixOffset + i];
            if ((b & 0xc0) == 0x80) {
                // 0x10xxxxxx
                codePoint <<= 6;
                codePoint |= b & 0x3f;
            } else {
                prefixOffset += i;
                return REPLACEMENT_CHARACTER;
            }
        }

        prefixOffset += byteCount;

        if (codePoint > 0x10ffff) {
            return REPLACEMENT_CHARACTER; // Reject code points larger than the Unicode maximum.
        }

        if (codePoint >= 0xd800 && codePoint <= 0xdfff) {
            return REPLACEMENT_CHARACTER; // Reject partial surrogates.
        }

        if (codePoint < min) {
            return REPLACEMENT_CHARACTER; // Reject overlong code points.
        }

        return codePoint;
    }
}

