package com.tencent.qapmsdk.impl.instrumentation;

import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.api.data.TransactionData;
import com.tencent.qapmsdk.impl.harvest.HttpLibType;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMCountingInputStream;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMCountingOutputStream;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMStreamCompleteEvent;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMStreamCompleteListener;
import com.tencent.qapmsdk.impl.model.HttpDataModel;
import com.tencent.qapmsdk.impl.util.StringUtil;
import com.tencent.qapmsdk.impl.util.TraceUtil;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ProtocolException;
import java.net.URL;
import java.security.Permission;
import java.security.Principal;
import java.security.cert.Certificate;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocketFactory;

public class QAPMHttpsURLConnectionExtension extends HttpsURLConnection {
    private final static String TAG = "QAPM_Impl_QAPMHttpsURLConnectionExtension";
    private HttpsURLConnection impl;
    private QAPMTransactionState transactionState;
    QAPMCountingInputStream qapmCountingInputStream;

    public QAPMHttpsURLConnectionExtension(HttpsURLConnection impl) {
        super(impl.getURL());
        this.impl = impl;
        this.getTransactionState();

        try {
            if (impl != null && TraceUtil.getCanMonitorHttp()) {
                this.transactionState.setAppPhase(0);
//                QAPMTransactionStateUtil.setCrossProcessHeader(impl);
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMHttpsURLConnectionExtension has an error : " , e);
        }

    }

    public String getCipherSuite() {
        return this.impl.getCipherSuite();
    }

    public Certificate[] getLocalCertificates() {
        return this.impl.getLocalCertificates();
    }

    public Certificate[] getServerCertificates() throws SSLPeerUnverifiedException {
        try {
            return this.impl.getServerCertificates();
        } catch (SSLPeerUnverifiedException e) {
            this.error(e);
            throw e;
        }
    }

    public void addRequestProperty(String field, String newValue) {
        this.impl.addRequestProperty(field, newValue);
    }

    public void disconnect() {
        if (this.transactionState != null && !this.transactionState.isComplete()) {
            this.addTransactionAndErrorData(this.transactionState);
        }

        this.impl.disconnect();
    }

    public boolean usingProxy() {
        return this.impl.usingProxy();
    }

    public void connect() throws IOException {
        this.getTransactionState();

        try {
            this.impl.connect();
        } catch (IOException e) {
            this.error(e);
            throw e;
        }
    }

    public boolean getAllowUserInteraction() {
        return this.impl.getAllowUserInteraction();
    }

    public int getConnectTimeout() {
        return this.impl.getConnectTimeout();
    }

    public Object getContent() throws IOException {
        this.getTransactionState();

        Object content;
        try {
            content = this.impl.getContent();
        } catch (IOException e) {
            this.error(e);
            throw e;
        }

        int contentLength = this.impl.getContentLength();
        if (contentLength >= 0) {
            QAPMTransactionState transactionState = this.getTransactionState();
            if (!transactionState.isComplete()) {
                transactionState.setBytesReceived((long)contentLength);
                this.addTransactionAndErrorData(transactionState);
            }
        }

        return content;
    }

    public Object getContent(Class[] types) throws IOException {
        this.getTransactionState();

        Object content;
        try {
            content = this.impl.getContent(types);
        } catch (IOException e) {
            this.error(e);
            throw e;
        }

        this.checkResponse();
        return content;
    }

    public String getContentEncoding() {
        this.getTransactionState();
        String contentEncoding = this.impl.getContentEncoding();
        this.checkResponse();
        return contentEncoding;
    }

    public int getContentLength() {
        this.getTransactionState();
        int contentLength = this.impl.getContentLength();
        this.checkResponse();
        return contentLength;
    }

    public String getContentType() {
        this.getTransactionState();
        String contentType = this.impl.getContentType();
        this.checkResponse();
        return contentType;
    }

    public long getDate() {
        this.getTransactionState();
        long date = this.impl.getDate();
        this.checkResponse();
        return date;
    }

    public InputStream getErrorStream() {
        this.getTransactionState();
        if (this.qapmCountingInputStream != null) {
            return this.qapmCountingInputStream;
        } else {
            try {
                this.qapmCountingInputStream = new QAPMCountingInputStream(this.impl.getErrorStream(), true);
            } catch (Exception e) {
                Magnifier.ILOGUTIL.e(TAG, e.toString());
                return this.impl.getErrorStream();
            }

            return this.qapmCountingInputStream;
        }
    }

    public long getHeaderFieldDate(String field, long defaultValue) {
        this.getTransactionState();
        long headerFieldDate = this.impl.getHeaderFieldDate(field, defaultValue);
        this.checkResponse();
        return headerFieldDate;
    }

    public boolean getInstanceFollowRedirects() {
        return this.impl.getInstanceFollowRedirects();
    }

    public Permission getPermission() throws IOException {
        return this.impl.getPermission();
    }

    public String getRequestMethod() {
        QAPMTransactionState transactionState = this.getTransactionState();
        String requestMethod = this.impl.getRequestMethod();
        QAPMTransactionStateUtil.setRequestMethod(transactionState, requestMethod);
        this.transactionState.setHttpLibType(HttpLibType.URLConnection);
        return requestMethod;
    }

    public int getResponseCode() throws IOException {
        this.getTransactionState();

        int responsCode;
        try {
            responsCode = this.impl.getResponseCode();
        } catch (IOException e) {
            this.error(e);
            throw e;
        }

        this.checkResponse();
        return responsCode;
    }

    public String getResponseMessage() throws IOException {
        this.getTransactionState();

        String responseMessage;
        try {
            responseMessage = this.impl.getResponseMessage();
        } catch (IOException e) {
            this.error(e);
            throw e;
        }

        this.checkResponse();
        return responseMessage;
    }

    public void setChunkedStreamingMode(int chunkLength) {
        this.impl.setChunkedStreamingMode(chunkLength);
    }

    public void setFixedLengthStreamingMode(int contentLength) {
        this.impl.setFixedLengthStreamingMode(contentLength);
    }

    public void setInstanceFollowRedirects(boolean followRedirects) {
        this.impl.setInstanceFollowRedirects(followRedirects);
    }

    public void setRequestMethod(String method) throws ProtocolException {
        this.getTransactionState();

        try {
            this.impl.setRequestMethod(method);
            this.transactionState.setMethodType(method);
            this.transactionState.setHttpLibType(HttpLibType.URLConnection);
            QAPMTransactionStateUtil.setRequestMethod(this.getTransactionState(), method);
        } catch (ProtocolException e) {
            this.error(e);
            throw e;
        }
    }

    public boolean getDefaultUseCaches() {
        return this.impl.getDefaultUseCaches();
    }

    public boolean getDoInput() {
        return this.impl.getDoInput();
    }

    public boolean getDoOutput() {
        return this.impl.getDoOutput();
    }

    public long getExpiration() {
        this.getTransactionState();
        long expiration = this.impl.getExpiration();
        this.checkResponse();
        return expiration;
    }

    public String getHeaderField(int pos) {
        this.getTransactionState();
        String headerField = this.impl.getHeaderField(pos);
        this.checkResponse();
        return headerField;
    }

    public String getHeaderField(String key) {
        this.getTransactionState();
        String headerField = this.impl.getHeaderField(key);
        this.checkResponse();
        return headerField;
    }

    public int getHeaderFieldInt(String field, int defaultValue) {
        this.getTransactionState();
        int headerFieldInt = this.impl.getHeaderFieldInt(field, defaultValue);
        this.checkResponse();
        return headerFieldInt;
    }

    public String getHeaderFieldKey(int posn) {
        this.getTransactionState();
        String headerFieldKey = this.impl.getHeaderFieldKey(posn);
        this.checkResponse();
        return headerFieldKey;
    }

    public Map<String, List<String>> getHeaderFields() {
        this.getTransactionState();
        Map headerFields = this.impl.getHeaderFields();
        this.checkResponse();
        return headerFields;
    }

    public long getIfModifiedSince() {
        this.getTransactionState();
        long ifModifiedSince = this.impl.getIfModifiedSince();
        this.checkResponse();
        return ifModifiedSince;
    }

    public InputStream getInputStream() throws IOException {
        final QAPMTransactionState state = this.getTransactionState();
        QAPMCountingInputStream inputStream = null;

        try {
            inputStream = new QAPMCountingInputStream(this.impl.getInputStream());
            QAPMTransactionStateUtil.inspectAndInstrumentResponse(state, this.impl);
        } catch (IOException ex) {
            this.error(ex);
            throw ex;
        }

        if (inputStream != null) {
            inputStream.addStreamCompleteListener(new QAPMStreamCompleteListener() {
                public void streamError(QAPMStreamCompleteEvent e) {
                    try {
                        int code = QAPMHttpsURLConnectionExtension.this.impl.getResponseCode();
                        state.setStatusCode(code);
                    } catch (IOException e1) {
                    }

                    if (!state.isComplete()) {
                        state.setBytesReceived(e.getBytes());
                    }

                    QAPMHttpsURLConnectionExtension.this.error(e.getException());
                }

                public void streamComplete(QAPMStreamCompleteEvent e) {
                    if (!state.isComplete()) {
                        int responseCode = 0;

                        try {
                            responseCode = QAPMHttpsURLConnectionExtension.this.impl.getResponseCode();
                            state.setStatusCode(responseCode);
                        } catch (IOException var7) {
                        }

                        long byteLen = e.getBytes();
                        if (responseCode != 206) {
                            long contentLength = (long)QAPMHttpsURLConnectionExtension.this.impl.getContentLength();
                            byteLen = contentLength >= 0L ? contentLength : byteLen;
                        }

                        state.setBytesReceived(byteLen);
                        QAPMHttpsURLConnectionExtension.this.addTransactionAndErrorData(state);
                    }

                }
            });
        }

        return inputStream;
    }

    public long getLastModified() {
        this.getTransactionState();
        long lastModified = this.impl.getLastModified();
        this.checkResponse();
        return lastModified;
    }

    public OutputStream getOutputStream() throws IOException {
        final QAPMTransactionState state = this.getTransactionState();

        QAPMCountingOutputStream outputStream;
        try {
            outputStream = new QAPMCountingOutputStream(this.impl.getOutputStream());
        } catch (IOException var4) {
            this.error(var4);
            throw var4;
        }

        if (outputStream != null) {
            outputStream.addStreamCompleteListener(new QAPMStreamCompleteListener() {
                public void streamError(QAPMStreamCompleteEvent e) {
                    if (!state.isComplete()) {
                        state.setBytesSent(e.getBytes());
                    }

                    QAPMHttpsURLConnectionExtension.this.error(e.getException());
                }

                public void streamComplete(QAPMStreamCompleteEvent e) {
                    if (!state.isComplete()) {
                        String contentLen = QAPMHttpsURLConnectionExtension.this.impl.getRequestProperty("content-length");
                        long byteLen = e.getBytes();
                        if (contentLen != null) {
                            try {
                                byteLen = Long.parseLong(contentLen);
                            } catch (NumberFormatException var6) {
                            }
                        }

                        state.setBytesSent(byteLen);
                    }

                }
            });
        }

        return outputStream;
    }

    public int getReadTimeout() {
        return this.impl.getReadTimeout();
    }

    public Map<String, List<String>> getRequestProperties() {
        return this.impl.getRequestProperties();
    }

    public String getRequestProperty(String field) {
        return this.impl.getRequestProperty(field);
    }

    public URL getURL() {
        return this.impl.getURL();
    }

    public boolean getUseCaches() {
        return this.impl.getUseCaches();
    }

    public void setAllowUserInteraction(boolean newValue) {
        this.impl.setAllowUserInteraction(newValue);
    }

    public void setConnectTimeout(int timeoutMillis) {
        this.impl.setConnectTimeout(timeoutMillis);
    }

    public void setDefaultUseCaches(boolean newValue) {
        this.impl.setDefaultUseCaches(newValue);
    }

    public void setDoInput(boolean newValue) {
        this.impl.setDoInput(newValue);
    }

    public void setDoOutput(boolean newValue) {
        this.impl.setDoOutput(newValue);
    }

    public void setIfModifiedSince(long newValue) {
        this.impl.setIfModifiedSince(newValue);
    }

    public void setReadTimeout(int timeoutMillis) {
        this.impl.setReadTimeout(timeoutMillis);
    }

    public void setRequestProperty(String field, String newValue) {
        this.impl.setRequestProperty(field, newValue);
    }

    public void setUseCaches(boolean newValue) {
        this.impl.setUseCaches(newValue);
    }

    public String toString() {
        return this.impl.toString();
    }

    public Principal getPeerPrincipal() throws SSLPeerUnverifiedException {
        return this.impl.getPeerPrincipal();
    }

    public Principal getLocalPrincipal() {
        return this.impl.getLocalPrincipal();
    }

    public void setHostnameVerifier(HostnameVerifier hostnameVerifier) {
        this.impl.setHostnameVerifier(hostnameVerifier);
    }

    public HostnameVerifier getHostnameVerifier() {
        return this.impl.getHostnameVerifier();
    }

    public void setSSLSocketFactory(SSLSocketFactory sf) {
        this.impl.setSSLSocketFactory(sf);
    }

    public SSLSocketFactory getSSLSocketFactory() {
        return this.impl.getSSLSocketFactory();
    }

    private void checkResponse() {
        if (!this.getTransactionState().isComplete()) {
            QAPMTransactionStateUtil.inspectAndInstrumentResponse(this.getTransactionState(), this.impl);
        }

    }

    private QAPMTransactionState getTransactionState() {
        if (this.transactionState == null) {
            this.transactionState = new QAPMTransactionState();
            QAPMTransactionStateUtil.setUrlAndCarrier(this.transactionState, this.impl);
        }

        return this.transactionState;
    }

    private void error(Exception e) {
        try {
            if (!TraceUtil.getCanMonitorHttp()) {
                return;
            }


            QAPMTransactionState state = this.getTransactionState();

            try {
                state.setContentType(StringUtil.contentType(this.impl.getContentType()));
            } catch (Exception ex1) {
                Magnifier.ILOGUTIL.exception(TAG, "QAPMTransactionStateUtil. getContentType occur an error", ex1);
            }

            try {
                if (state != null && !state.hasParseUrlParams) {
                    QAPMTransactionStateUtil.processUrlParams(state, this.impl);
                }
            } catch (Exception ex3) {
                Magnifier.ILOGUTIL.exception(TAG, "QAPMTransactionStateUtil.processUrlParams occur an error", ex3);
            }

            QAPMTransactionStateUtil.setErrorCodeFromException(state, e);
            if (!state.isComplete()) {
                String exceptionInfo = "";
                if (state.getException() != null) {
                    exceptionInfo = state.getException();
                }

                QAPMTransactionStateUtil.inspectAndInstrumentResponse(state, this.impl);
                TransactionData transactionData = state.end();
//                k.a(var6, new com.networkbench.agent.impl.g.b.a(var6));
                if (state.isError()) {
                    //todo:存储数据
                    HttpDataModel.collectData(transactionData, exceptionInfo);
                    //com.networkbench.agent.impl.g.h.a(state.getUrl(), state.getFormattedUrlParams(), state.getAllGetRequestParams(), state.getStatusCode(), exceptionInfo, state.getRequestMethodType(), var6.h(), var6.f(), var6.w(), var6.l(), var6.d());
                }
                else{
                    HttpDataModel.collectData(transactionData);
                }
            }
        } catch (Exception ex2) {
            Magnifier.ILOGUTIL.exception(TAG,"QAPMHttpsURLConnectionExtension error() has an error : ", ex2);
        }

    }

    private void addTransactionAndErrorData(QAPMTransactionState transactionState) {
        try {
            if (!TraceUtil.getCanMonitorHttp()) {
                return;
            }


            try {
                transactionState.setContentType(StringUtil.contentType(this.impl.getContentType()));
            } catch (Exception ex) {
                Magnifier.ILOGUTIL.exception(TAG, "QAPMHttpsURLConnectionExtension addTransactionAndErrorData() has an error : ", ex);
            }

            TransactionData transactionData = transactionState.end();
            if (transactionData == null) {
                return;
            }

            int statusCode = transactionData.getStatusCode();
//            k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
            if ((long)statusCode >= 400L) {
                StringBuilder sb = new StringBuilder();

                try {
                    InputStream inputStream = this.getErrorStream();
                    if (inputStream instanceof QAPMCountingInputStream) {
                        sb.append(((QAPMCountingInputStream)inputStream).getBufferAsString());
                    }
                } catch (Exception ex1) {
                    Magnifier.ILOGUTIL.e(TAG, ex1.toString());
                }

                if (this.impl.getHeaderFields() != null && this.impl.getHeaderFields().size() > 0) {
                    TreeMap treeMap = new TreeMap();

                    try {
                        Map headerFields = this.impl.getHeaderFields();
                        Iterator iterator = headerFields.keySet().iterator();

                        while(iterator.hasNext()) {
                            String str = (String)iterator.next();
                            if (!TextUtils.isEmpty(str)) {
                                treeMap.put(str, ((List)headerFields.get(str)).get(0));
                            }
                        }
                    } catch (Exception ex4) {
                    }

                    String exceptionInfo = "";
                    if (transactionState.getException() != null) {
                        exceptionInfo = transactionState.getException();
                    }
                    //todo:存储数据
                    HttpDataModel.collectData(transactionData, treeMap, exceptionInfo);
                    //com.networkbench.agent.impl.g.h.a(transactionData, sb.toString(), treeMap, exceptionInfo);
                } else {
                    sb.append("no response");
                }
            }
            else {
                HttpDataModel.collectData(transactionData);
            }
        } catch (Exception ex3) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMHttpsURLConnectionExtension addTransactionAndErrorData has an error : ", ex3);
        }

    }
}
