package com.tencent.qapmsdk.socket.ssl;

import android.support.annotation.RestrictTo;

import java.security.Provider;

/**
 * Created by nicorao on 2017/12/6.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY)
public class TrafficOpenSSLProvider extends Provider {

    private static final String TAG = "QAPM_Socket_TrafficOpenSSLProvider";

    private static final String PROVIDER_NAME = "TrafficAndroidOpenSSL";

    public enum Service {
        SSL("SSLContext.SSL", TrafficSSLContextImpl.SSLv3.class.getName()),
        SSLv3("SSLContext.SSLv3", TrafficSSLContextImpl.SSLv3.class.getName()),
        TLS("SSLContext.TLS", TrafficSSLContextImpl.TLSv12.class.getName()),
        TLSv1("SSLContext.TLSv1", TrafficSSLContextImpl.TLSv1.class.getName()),
        TLSv1_1("SSLContext.TLSv1.1", TrafficSSLContextImpl.TLSv11.class.getName()),
        TLSv1_2("SSLContext.TLSv1.2", TrafficSSLContextImpl.TLSv12.class.getName()),
        DEFAULT("SSLContext.Default", TrafficSSLContextImpl.Default.class.getName()),
        ;

        public String typeAlgorithm;
        public String clazz;

        Service(String typeAlgorithm, String clazz) {
            this.typeAlgorithm = typeAlgorithm;
            this.clazz = clazz;
        }
    }

    public TrafficOpenSSLProvider() throws Exception {
        super(PROVIDER_NAME, 1.0, "Custom Traffic Android's OpenSSL-backed security provider");
        for (Service service : Service.values()) {
            put(service.typeAlgorithm, service.clazz);
        }
    }
}

