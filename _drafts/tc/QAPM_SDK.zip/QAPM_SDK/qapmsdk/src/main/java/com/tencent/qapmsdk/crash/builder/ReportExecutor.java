package com.tencent.qapmsdk.crash.builder;

import android.content.Context;
import android.os.Build;
import android.os.Debug;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.crash.config.CoreConfiguration;
import com.tencent.qapmsdk.crash.data.CrashReportData;
import com.tencent.qapmsdk.crash.data.CrashReportDataFactory;
import com.tencent.qapmsdk.crash.file.CrashReportPersister;
import com.tencent.qapmsdk.crash.util.ProcessFinisher;
import com.tencent.qapmsdk.reporter.IReporter;
import com.tencent.qapmsdk.reporter.QCloudReporter;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.reporter.ResultObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ReportExecutor {
    private static final String LOG_TAG = ILogUtil.getTAG(ReportExecutor.class);
    private final Context context;
    private final CoreConfiguration config;

    public static String logPath;
    public static File logDir;
    private SimpleDateFormat ft = new SimpleDateFormat("yyyyMMddhhmmss", Locale.CHINA);

    private final CrashReportDataFactory crashReportDataFactory;
//    private final List<ReportingAdministrator> reportingAdministrators;
//    private final SchedulerStarter schedulerStarter;
    private final LastActivityManager lastActivityManager;

    // A reference to the system's previous default UncaughtExceptionHandler
    // kept in order to execute the default exception handling after sending the report.
    private final Thread.UncaughtExceptionHandler defaultExceptionHandler;

    private final ProcessFinisher processFinisher;

    private boolean enabled = true;

    /**
     * Creates a new instance
     *
     * @param context                 a context
     * @param config                  the config
     *
     * @param defaultExceptionHandler pass-through handler
     * @param processFinisher         used to end process after reporting
     *
     * @param lastActivityManager     used to finish activities after reporting
     */
    public ReportExecutor(@NonNull Context context, @NonNull CoreConfiguration config, @NonNull CrashReportDataFactory crashReportDataFactory,
                          @Nullable Thread.UncaughtExceptionHandler defaultExceptionHandler, @NonNull ProcessFinisher processFinisher,
                           @NonNull LastActivityManager lastActivityManager) {
        this.context = context;
        this.config = config;
        this.crashReportDataFactory = crashReportDataFactory;
        this.defaultExceptionHandler = defaultExceptionHandler;
        this.processFinisher = processFinisher;
        this.lastActivityManager = lastActivityManager;
        logDir = context.getDir("crash",  Context.MODE_PRIVATE);
        logPath = logDir.getAbsolutePath();
    }

    /**
     * pass-through to default handler
     *
     * @param t the crashed thread
     * @param e the uncaught exception
     */
    public void handReportToDefaultExceptionHandler(@Nullable Thread t, @NonNull Throwable e) {
        if (defaultExceptionHandler != null) {
            Magnifier.ILOGUTIL.i(LOG_TAG, "disabled for " + context.getPackageName()
                    + " - forwarding uncaught Exception on to default ExceptionHandler");
            defaultExceptionHandler.uncaughtException(t, e);
        } else {
            Magnifier.ILOGUTIL.e(LOG_TAG, "disabled for " + context.getPackageName() + " - no default ExceptionHandler");
            Magnifier.ILOGUTIL.exception(LOG_TAG, "caught a " + e.getClass().getSimpleName() + " for " + context.getPackageName(), e);
        }

    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    /**
     * Try to create a report.
     *
     * @param reportBuilder The report builder used to assemble the report
     */
    public final void execute(@NonNull final ReportBuilder reportBuilder) {

        if (!enabled) {
            Magnifier.ILOGUTIL.v(LOG_TAG, "disabled. Report not sent.");
            return;
        }

        // 生成 上报Data
        final CrashReportData crashReportData = crashReportDataFactory.createCrashData(reportBuilder);

        if (reportBuilder.isEndApplication()) {
            // Finish the last activity early to prevent restarts on android 7+
            processFinisher.finishLastActivity(reportBuilder.getUncaughtExceptionThread());
        }
        StrictMode.ThreadPolicy oldPolicy = StrictMode.allowThreadDiskWrites();

        if(config.isSendNow()) {
            sendReport(crashReportData);
        } else {
            final File reportFile = getReportFileName(crashReportData);
            saveCrashReportFile(reportFile, crashReportData);
        }

        StrictMode.setThreadPolicy(oldPolicy);

        Magnifier.ILOGUTIL.d(LOG_TAG, "Wait for Interactions + worker ended. Kill Application ? " + reportBuilder.isEndApplication());

        if (reportBuilder.isEndApplication()) {
            if (Debug.isDebuggerConnected()) {
                //Killing a process with a debugger attached would kill the whole application including our service, so we can't do that.
                final String warning = "Warning: Acra may behave differently with a debugger attached";
                Magnifier.ILOGUTIL.w(LOG_TAG, warning);
            } else {
                endApplication(reportBuilder.getUncaughtExceptionThread(), reportBuilder.getException());
            }
        }
    }

    /**
     * End the application.
     */
    private void endApplication(@Nullable Thread uncaughtExceptionThread, Throwable th) {
        final boolean letDefaultHandlerEndApplication = config.alsoReportToAndroidFramework;

        final boolean handlingUncaughtException = uncaughtExceptionThread != null;
        if (handlingUncaughtException && letDefaultHandlerEndApplication && defaultExceptionHandler != null) {
            // Let the system default handler do it's job and display the force close dialog.
            Magnifier.ILOGUTIL.i(LOG_TAG, "Handing Exception on to default ExceptionHandler.");
            defaultExceptionHandler.uncaughtException(uncaughtExceptionThread, th);
        } else {
            Magnifier.ILOGUTIL.d(LOG_TAG, "Finish Application now.");
            processFinisher.endApplication();
        }
    }

    /**
     * Starts a Process to start sending outstanding error reports.
     * 这里为防止主线程退出导致上报失败，要向主线程发消息
     */
    private static void sendReport(@NonNull CrashReportData crashData) {

        try {
            String json = crashData.toJSON();
            JSONObject params = new JSONObject(json);
            ResultObject ro = new ResultObject(0, "crash", true, 1, 1, params, true, true, Magnifier.info.uin);
            ReporterMachine.addResultObj(ro);
        }catch (JSONException e){
            Magnifier.ILOGUTIL.e(LOG_TAG, "crashData: " + crashData.getContent().toString());
            Magnifier.ILOGUTIL.exception(LOG_TAG, e);
        }

    }

    public static void sendReportFromFiles(@NonNull File dir)  {
        Magnifier.ILOGUTIL.d(LOG_TAG, "sendReportFromFiles dir: " + dir.getAbsolutePath());
        if (dir.isDirectory()){
            for (final File file: dir.listFiles()){
                CrashReportPersister persister = new CrashReportPersister();
                try {
                    CrashReportData crashData = persister.load(file);
                    JSONObject params = crashData.getContent();
                    params.put("p_id", Magnifier.productId);
                    params.put("version", Magnifier.info.version);
                    params.put("uin", Magnifier.info.uin);
                    params.put("manu", Build.MANUFACTURER);
                    params.put("device", Build.MODEL);
                    params.put("os", Build.VERSION.RELEASE);
                    params.put("rdmuuid", Magnifier.info.uuid);
                    params.put("deviceid", PhoneUtil.getDeviceId(Magnifier.sApp));
                    ResultObject ro = new ResultObject(0, "crash", true, 1, 1, params, true, true, Magnifier.info.uin);
                    QCloudReporter QCloud_Reporter = new QCloudReporter();
                    QCloud_Reporter.report(ro, new IReporter.ReportResultCallback() {
                        @Override
                        public void onSuccess(int id) {
                            Magnifier.ILOGUTIL.i(LOG_TAG, "delete file " + file.getName());
                            file.delete();
                        }

                        @Override
                        public void onFailure(int plugin, long uploadtime, int error_code, String error_msg, String http_get) {
                            Magnifier.ILOGUTIL.w(LOG_TAG, "report error. plugin: " + plugin + ",uploadtime: " + uploadtime +
                                    ",error_code: " + error_code + ",error_msg: " + error_msg + ",http_get: " + http_get);
                        }
                    });

                } catch (IOException ioEx){
                    Magnifier.ILOGUTIL.exception(LOG_TAG, "load file error.", ioEx);
                    file.delete();
                } catch (JSONException jsEx){
                    Magnifier.ILOGUTIL.exception(LOG_TAG, "parse json error.", jsEx);
                    file.delete();
                }

            }
        }
    }

    @NonNull
    private File getReportFileName(@NonNull CrashReportData crashData) {
        final String timestamp = ft.format(new Date());
        final String packageName = this.context.getPackageName();
        final String fileName = packageName + '_' + timestamp;

        File directoryFile = new File(logPath);
        if(!directoryFile.exists()){
            directoryFile.mkdirs();
        }
        return new File(logPath, fileName);
    }

    /**
     * Store a report
     *
     * @param file      the file to store in
     * @param crashData the content
     */
    private static void saveCrashReportFile(@NonNull File file, @NonNull CrashReportData crashData) {
        try {
            Magnifier.ILOGUTIL.d(LOG_TAG, "Writing report crash file - " + file);
            final CrashReportPersister persister = new CrashReportPersister();
            persister.store(crashData, file);
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(LOG_TAG, "An error occurred while writing the report file... crashData: " + crashData.getContent().toString(), e);
        }
    }
}
