package com.tencent.qapmsdk.socket.handler;

public interface ITrafficOutputStreamHandlerFactory {
    ITrafficOutputStreamHandler create();
}

