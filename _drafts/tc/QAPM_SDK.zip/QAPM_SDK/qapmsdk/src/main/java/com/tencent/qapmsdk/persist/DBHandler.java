package com.tencent.qapmsdk.persist;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.SparseArray;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.config.Config.SamplingConfig;
import com.tencent.qapmsdk.dropframe.DropResultObject;
import com.tencent.qapmsdk.reporter.ResultObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DBHandler {
    private static final String NAME = "name";
    private static final long CURRENT_TIME = System.currentTimeMillis();
    private static final String OVERTIME_STRING = String.valueOf(CURRENT_TIME - 3 * 24 * 60 * 60 * 1000);
    private static final String TAG = ILogUtil.getTAG(DBHandler.class);
    
    @Nullable
    private volatile static DBHandler handler;
    @Nullable
    private DBHelper dbHelper;
    private SQLiteDatabase database;
    
    public class Status {
        public static final int TO_SEND = 1;
        public static final int SENT = 2;
    }
    
    private DBHandler(Context context) {
        dbHelper = DBHelper.getInstance(context);
        open();
    }
    
    @Nullable
    public static DBHandler getInstance(Context context) {
        if (handler == null) {
            synchronized(DBHandler.class) {
                if (handler == null) {
                    handler = new DBHandler(context);
                }
            }
        }
        return handler;
    }
    
    public void open() {
        if (database != null && database.isOpen()) {
            return;
        } else {
            try {
                database = dbHelper.getWritableDatabase();
            } catch (Exception e) {
                Magnifier.ILOGUTIL.exception(TAG, e);
            }
        }
    }

    public void close() {
        if (database != null && database.isOpen()) {
            dbHelper.close();
            handler = null;
        }
    }
    
    public long insertResultObject(@NonNull ResultObject ro, String processName, int p_id, String version) {
        if (database == null || (!database.isOpen())) {
            return -2;
        }
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.COLUMN_PROCESSNAME, processName);
        cv.put(DBHelper.COLUMN_PRODUCTID, p_id);
        cv.put(DBHelper.COLUMN_VERSION, version);
        cv.put(DBHelper.COLUMN_PARAMS, ro.params.toString());
        cv.put(DBHelper.COLUMN_ISREALTIME, ro.isRealTime);
        cv.put(DBHelper.COLUMN_UIN, ro.uin);
        cv.put(DBHelper.COLUMN_STATUS, Status.TO_SEND);
        long occurTime = 0;
        try {
            occurTime = ro.params.getJSONObject("clientinfo").optLong("event_time");
        } catch (Exception e) {
        }
        if (occurTime == 0) {
            occurTime = CURRENT_TIME;
        }
        cv.put(DBHelper.COLUMN_OCCURTIME, occurTime);
        try {
            return database.insert(DBHelper.TABLE_RESULT_OBJECTS, NAME, cv);
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
            return -1;
        }
    }
    
    public long insertDropFrame(String uin, String scene, @NonNull DropResultObject item, String processName, int p_id, String version) {
        if (database == null || (!database.isOpen())) {
            return -2;
        }
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.COLUMN_PROCESSNAME, processName);
        cv.put(DBHelper.COLUMN_PRODUCTID, p_id);
        cv.put(DBHelper.COLUMN_VERSION, version);
        cv.put(DBHelper.COLUMN_UIN, uin);
        cv.put(DBHelper.COLUMN_SCENE, scene);
        cv.put(DBHelper.COLUMN_STATE, item.state);
        cv.put(DBHelper.COLUMN_DROP_DURATION, item.duration);
        cv.put(DBHelper.COLUMN_DROP_COUNT, item.dropcount);
        cv.put(DBHelper.COLUMN_RANGE_0, item.dropIntervals[0]);
        cv.put(DBHelper.COLUMN_RANGE_1, item.dropIntervals[1]);
        cv.put(DBHelper.COLUMN_RANGE_2_4, item.dropIntervals[2]);
        cv.put(DBHelper.COLUMN_RANGE_4_8, item.dropIntervals[3]);
        cv.put(DBHelper.COLUMN_RANGE_8_15, item.dropIntervals[4]);
        cv.put(DBHelper.COLUMN_RANGE_OVER_15, item.dropIntervals[5]);
        cv.put(DBHelper.COLUMN_STATUS, Status.TO_SEND);
        cv.put(DBHelper.COLUMN_OCCURTIME, System.currentTimeMillis());
        try {
            return database.insert(DBHelper.TABLE_DROP_FRAME, NAME, cv);
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
            return -1;
        }
    }

    public long insertANRStack(String uin,String item, String processName, int p_id, String version){
        if (database == null || (!database.isOpen())) {
            return -2;
        }
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.COLUMN_PROCESSNAME, processName);
        cv.put(DBHelper.COLUMN_PRODUCTID, p_id);
        cv.put(DBHelper.COLUMN_VERSION, version);
        cv.put(DBHelper.COLUMN_UIN, uin);
        cv.put(DBHelper.COLUMN_STACK,item);
        try {
            return database.insert(DBHelper.TABLE_ANR_STACK, NAME, cv);
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
            return -1;
        }
    }

    public long saveConfigs(@NonNull SparseArray<SamplingConfig> configs, int p_id, String version) {
        if (database == null || (!database.isOpen())) {
            return -2;
        }
        delete(DBHelper.TABLE_CONFIGS, null, null);
        database.beginTransaction();
        int size = configs.size();
        ContentValues cv = new ContentValues();
        for (int index = 0; index < size; index++) {
            int key = configs.keyAt(index);
            SamplingConfig sc = configs.get(key);
            cv.put(DBHelper.COLUMN_PRODUCTID, p_id);
            cv.put(DBHelper.COLUMN_VERSION, version);
            cv.put(DBHelper.COLUMN_PLUGIN, key);
            cv.put(DBHelper.COLUMN_THRESHOLD, sc.threshold);
            cv.put(DBHelper.COLUMN_MAX_REPORT_NUM, sc.maxReportNum);
            cv.put(DBHelper.COLUMN_EVENT_SAMPLE_RATIO, sc.eventSampleRatio);
            cv.put(DBHelper.COLUMN_STACK_DEPTH, sc.maxStackDepth);
            try {
                database.insert(DBHelper.TABLE_CONFIGS, NAME, cv);
            } catch (Exception e) {
                Magnifier.ILOGUTIL.exception(TAG, e);
            }
        }
        database.setTransactionSuccessful();
        database.endTransaction();
        return 0;
    }

    @Nullable
    public SparseArray<SamplingConfig> getConfigs(int p_id, String version) {
        if (database == null || (!database.isOpen())) {
            return null;
        }
        Cursor cursor = null;
        SparseArray<SamplingConfig> configs = null;
        try {
            cursor = database.query(DBHelper.TABLE_CONFIGS, null, "p_id=? and version=?", new String[] {String.valueOf(p_id), version}, null, null, null);
            if (cursor == null) return null;
            int rows = cursor.getCount();
            if (rows < 1) return null;
            configs = new SparseArray<>(rows);
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                int plugin = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_PLUGIN));
                int thres = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_THRESHOLD));
                int mrn = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_MAX_REPORT_NUM));
                float esr = cursor.getFloat(cursor.getColumnIndex(DBHelper.COLUMN_EVENT_SAMPLE_RATIO));
                int msd = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_STACK_DEPTH));
                SamplingConfig sc = new SamplingConfig(thres, mrn, esr, msd);
                configs.put(plugin, sc);
                cursor.moveToNext();
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return configs;
    }
    
    private int delete(String table, String whereClause, String[] whereArgs) {
        if (database == null || (!database.isOpen())) {
            return -2;
        }
        try {
            return database.delete(table, whereClause, whereArgs);
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
            return -1;
        }
    }

    public int update(String table, long id, int status) {
        if (database == null || (!database.isOpen())) {
            return -2;
        }
        if (status != Status.TO_SEND && status != Status.SENT) {
            return -1;
        }
        ContentValues cv = new ContentValues();
        cv.put("status", status);
        try {
            return database.update(table, cv, DBHelper.COLUMN_ID + "=" + id, null);
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
            return -1;
        }
    }
    
    @NonNull
    private JSONObject buildSingleScene(DropResultObject item) throws JSONException {
        JSONObject joInner = new JSONObject();
        JSONObject jo2InnerLevel = new JSONObject();
        JSONArray joDropTimes = new JSONArray();
        jo2InnerLevel.put("dropDuration", item.duration / 1000000000.0f);
        for (int i = 0; i < 6; ++i) {
            joDropTimes.put(i, item.dropIntervals[i]);
        }
        jo2InnerLevel.put("dropTimes", joDropTimes);
        //jo2InnerLevel.put("dropCount", item.dropcount);
        joInner.put(String.valueOf(item.state), jo2InnerLevel);
        return joInner;
    }
    
    @NonNull
    private JSONObject buildDropFrameJson(HashMap<String, DropResultObject> map) throws JSONException {
        JSONObject result = new JSONObject();
        for (String scene : map.keySet()) {
            DropResultObject item = map.get(scene);
            JSONObject joInner = buildSingleScene(item);
            result.put(scene, joInner);
        }
        return result;
    }
    
    private ResultObject getDropFrame(String processName, int p_id, String version, boolean onlyToSend) {
        if (database == null || (!database.isOpen()) || !CollectStatus.canCollect(Config.PLUGIN_QCLOUD_DROPFRAME)) {
            return null;
        }
        CollectStatus.addCollectCount(Config.PLUGIN_QCLOUD_DROPFRAME);
        ResultObject ro = null;
        JSONObject obj = new JSONObject();
        HashMap<String, DropResultObject> map = new HashMap<String, DropResultObject>();
        String scene = "";
        short state = 0;
        Cursor cursor = null;
        try {
            if (true == onlyToSend) {
                cursor = database.query(DBHelper.TABLE_DROP_FRAME, null, "status=? and process_name=? and p_id=? and version=?", new String[] {String.valueOf(Status.TO_SEND), processName, String.valueOf(p_id), version}, null, null, null);
            } else {
                cursor = database.query(DBHelper.TABLE_DROP_FRAME, null, "process_name=? and p_id=? and version=?", new String[] {processName, String.valueOf(p_id), version}, null, null, null);
            }
            if (cursor == null) return null;
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                scene = cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_SCENE));
                state = cursor.getShort(cursor.getColumnIndex(DBHelper.COLUMN_STATE));
                float duration = cursor.getFloat(cursor.getColumnIndex(DBHelper.COLUMN_DROP_DURATION));
                int dropCount = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_DROP_COUNT));
                int range_0_count = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_RANGE_0));
                int range_1_count = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_RANGE_1));
                int range_2_4_count = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_RANGE_2_4));
                int range_4_8_count = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_RANGE_4_8));
                int range_8_15_count = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_RANGE_8_15));
                int range_over_15_count = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_RANGE_OVER_15));
                if (map.containsKey(scene)) {
                    DropResultObject item = map.get(scene);
                    item.dropcount += dropCount;
                    item.duration += duration;
                    item.dropIntervals[0] += range_0_count;
                    item.dropIntervals[1] += range_1_count;
                    item.dropIntervals[2] += range_2_4_count;
                    item.dropIntervals[3] += range_4_8_count;
                    item.dropIntervals[4] += range_8_15_count;
                    item.dropIntervals[5] += range_over_15_count;
                    map.put(scene, item);
                } else {
                    long[] intervals = {range_0_count, range_1_count, range_2_4_count, range_4_8_count, range_8_15_count, range_over_15_count};
                    DropResultObject item = new DropResultObject(dropCount, duration, intervals);
                    item.state = state;
                    map.put(scene, item);
                }
                cursor.moveToNext();
            }
            int collectCount = cursor.getCount();
            if (collectCount > 0) {
                obj = buildDropFrameJson(map);
                JSONObject params = new JSONObject();
                //params.put("scroll_count", collectCount);
                params.put("dropFrame", obj);
                params.put("plugin", Config.PLUGIN_QCLOUD_DROPFRAME);
                ro = new ResultObject(0, "testcase", true, 1, 1, params, false, true, Magnifier.info.uin);
            }
            delete(DBHelper.TABLE_DROP_FRAME, null, null);
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return ro;
    }

    public HashMap<String, DropResultObject> getDropFrame(String processName, int p_id, String version, long last_time, long cur_time) {
        HashMap<String, DropResultObject> map = new HashMap<String, DropResultObject>();
        if (database == null || (!database.isOpen())) {
            return map;
        }
        String scene = "";
        short state = 0;
        Cursor cursor = null;
        try {

            cursor = database.query(DBHelper.TABLE_DROP_FRAME, null, "process_name=? and p_id=? and version=? and occur_time > ? and occur_time < ?",
                    new String[] {processName, String.valueOf(p_id), version, String.valueOf(last_time), String.valueOf(cur_time)},
                    null, null, null);

            if (cursor == null){
                return map;
            }
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                scene = cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_SCENE));
                state = cursor.getShort(cursor.getColumnIndex(DBHelper.COLUMN_STATE));
                float duration = cursor.getFloat(cursor.getColumnIndex(DBHelper.COLUMN_DROP_DURATION));
                int dropCount = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_DROP_COUNT));
                int range_0_count = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_RANGE_0));
                int range_1_count = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_RANGE_1));
                int range_2_4_count = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_RANGE_2_4));
                int range_4_8_count = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_RANGE_4_8));
                int range_8_15_count = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_RANGE_8_15));
                int range_over_15_count = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_RANGE_OVER_15));
                if (map.containsKey(scene)) {
                    DropResultObject item = map.get(scene);
                    item.dropcount += dropCount;
                    item.duration += duration;
                    item.dropIntervals[0] += range_0_count;
                    item.dropIntervals[1] += range_1_count;
                    item.dropIntervals[2] += range_2_4_count;
                    item.dropIntervals[3] += range_4_8_count;
                    item.dropIntervals[4] += range_8_15_count;
                    item.dropIntervals[5] += range_over_15_count;
                    map.put(scene, item);
                } else {
                    long[] intervals = {range_0_count, range_1_count, range_2_4_count, range_4_8_count, range_8_15_count, range_over_15_count};
                    DropResultObject item = new DropResultObject(dropCount, duration, intervals);
                    item.state = state;
                    map.put(scene, item);
                }
                cursor.moveToNext();
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return map;
    }

    
    @NonNull
    public List<ResultObject> getAllResultObjects(String processName, int p_id, String version, boolean onlyToSend) {
        List<ResultObject> roList = new ArrayList<ResultObject>();
        if (database == null || (!database.isOpen())) {
            return roList;
        }
        Cursor cursor = null;
        try {
            if (true == onlyToSend) {
                cursor = database.query(DBHelper.TABLE_RESULT_OBJECTS, null, "process_name=? and p_id=? and version=? and status=? and occur_time>=?", new String[] {processName, String.valueOf(p_id), version, String.valueOf(Status.TO_SEND), OVERTIME_STRING}, null, null, null);
            } else {
                cursor = database.query(DBHelper.TABLE_RESULT_OBJECTS, null, "process_name=? and p_id=? and version=?", new String[] {processName, String.valueOf(p_id), version}, null, null, null);
            }
            if (cursor == null) return roList;
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                ResultObject ro = cursorToResultObject(cursor);
                if (ro != null) {
                    roList.add(ro);
                }
                cursor.moveToNext();
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        ResultObject dropFrame = getDropFrame(processName, p_id, version, onlyToSend);
        if (dropFrame != null) {
            roList.add(dropFrame);
        }
        return roList;
    }
    
    public int deleteAllSentOrOvertime(String table, boolean overtime) {
        if (overtime) {
            return delete(table, "status=? OR occur_time<?", new String[] {String.valueOf(Status.SENT), OVERTIME_STRING});
        } else {
            return delete(table, "status=?", new String[] {String.valueOf(Status.SENT)});
        }
    }
    
    public int clearResultObjects() {
        return delete(DBHelper.TABLE_RESULT_OBJECTS, null, null);
    }
    
    @Nullable
    private ResultObject cursorToResultObject(@Nullable Cursor cursor) throws JSONException {
        if (cursor == null) return null;
        ResultObject ro = new ResultObject();
        ro.dbId = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_ID));
        ro.params = new JSONObject(cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_PARAMS)));
        ro.isRealTime = (cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_ISREALTIME)) > 0);
        ro.uin = cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_UIN));
        return ro;
    }
}