package com.tencent.qapmsdk.io;

import android.content.Context;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.io.util.IOConst;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.VersionUtils;

public class IOMonitor {
    @Nullable
    private FileIOMonitor fileMonitor = null;
    @Nullable
    private SQLiteMonitor sqlMonitor = null;
    private boolean haveStart = false;

    private static final String LOG_TAG = ILogUtil.getTAG(IOMonitor.class);

    /*
     * if type: 1 collect file io data 2 collect database data 3 collect both of
     * all SQLite，File IO现在已经支持到android 7.0以下
     */
    public IOMonitor(Context context, int type, String version) {
        switch (type) {
        case 1:
            if (VersionUtils.checkFileIOCompatibility()) {
                fileMonitor = FileIOMonitor.getInstance();
                fileMonitor.setType(IOConst.ONLY_NATIVE_IO);
                fileMonitor.setAppVersion(version);
            } else {
                Magnifier.ILOGUTIL.e(LOG_TAG, "your phone can't support IO test now");
            }
            break;
        case 2:
            if (VersionUtils.isHookSupport()) {
                sqlMonitor = SQLiteMonitor.getInstance(version);
                fileMonitor = FileIOMonitor.getInstance();
                fileMonitor.setType(IOConst.ONLY_SQLITE_IO);
                fileMonitor.setAppVersion(version);
            } else {
                Magnifier.ILOGUTIL.e(LOG_TAG, "your phone can't support SQL test now");
            }
            break;
        case 3:
            if (VersionUtils.isHookSupport()) {
                fileMonitor = FileIOMonitor.getInstance();
                fileMonitor.setType(IOConst.BOTH_NATIVE_SQLITE);
                fileMonitor.setAppVersion(version);
                sqlMonitor = SQLiteMonitor.getInstance(version);
            } else if (VersionUtils.checkFileIOCompatibility()) {
                fileMonitor = FileIOMonitor.getInstance();
                fileMonitor.setType(IOConst.ONLY_NATIVE_IO);
                fileMonitor.setAppVersion(version);
                Magnifier.ILOGUTIL.e(LOG_TAG, "your phone can't support SQL test now");
            }
            break;
        }
    }

    public void start() {
        if (!haveStart) {
            if (fileMonitor != null)
                fileMonitor.start();
            if (sqlMonitor != null)
                sqlMonitor.start();
            haveStart = true;
        }
    }

    @SuppressWarnings("static-access")
    public void flush() {
        if (sqlMonitor != null) {
            sqlMonitor.writeToFile();
        }
        if (fileMonitor != null) {
            fileMonitor.saveNativeData();
        }
    }

    public void stop() {
        if (haveStart) {
            if (fileMonitor != null)
                fileMonitor.stop();
            if (sqlMonitor != null)
                sqlMonitor.stop();
            haveStart = false;
        }
    }
}