package com.tencent.qapmsdk.battery;

import android.support.annotation.Nullable;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

class HighFrequencyStringDetector {
    private int maintainCount;
    private int maxAppearCount;
    private LinkedHashMap<String, Integer> map;
    
    HighFrequencyStringDetector(int _maintainCount, int _maxAppearCount) {
        this.maintainCount = _maintainCount;
        this.maxAppearCount = _maxAppearCount;
        this.map = new LinkedHashMap<String, Integer>(_maintainCount, 0.5f, true);
    }
    
    void putString(String str) {
        synchronized(map) {
            if (map.containsKey(str)) {
                map.put(str, map.get(str)+ 1);
            } else {
                map.put(str, 1);
            }
            while (map.size() > maintainCount) {
                Map.Entry<String, Integer> toEvict = map.entrySet().iterator().next();
                map.remove(toEvict.getKey());
            }
        }
    }
    
    @Nullable
    public Map<String, Integer> getHighFrequencyString() {
        Map<String, Integer> rsMap = null;
        synchronized(map) {
            for(Iterator<Map.Entry<String, Integer>> iter = map.entrySet().iterator(); iter.hasNext(); ) {
                Map.Entry<String, Integer> entry = iter.next();
                if (entry.getValue() >= maxAppearCount) {
                    if (rsMap == null) {
                        rsMap = new HashMap<String, Integer>();
                    }
                    rsMap.put(entry.getKey(), entry.getValue());
                }
            }
        }
        return rsMap;
    }
    
    void clear() {
        synchronized(map) {
            map.clear();
        }
    }
}