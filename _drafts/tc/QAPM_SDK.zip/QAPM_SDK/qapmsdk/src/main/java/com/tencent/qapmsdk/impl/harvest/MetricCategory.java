package com.tencent.qapmsdk.impl.harvest;


import java.util.HashMap;
import java.util.Map;

public enum MetricCategory {
    NONE("None"),
    VIEW_LOADING("ViewLoading"),
    VIEW_LAYOUT("ViewLayout"),
    DATABASE("Storage"),
    IMAGE("Image"),
    JSON("Json"),
    NETWORK("Network"),
    BACKGROUND("Background"),
    CUSTOMEVENT("CustomEvent");

    private String categoryName;
    private static final Map<String, MetricCategory> methodMap = new HashMap<String, MetricCategory>() {
        private static final long a = -1342597889479051466L;

        {
            this.put("onCreate", MetricCategory.VIEW_LOADING);
        }
    };

    private MetricCategory(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryName() {
        return this.categoryName;
    }

    public static MetricCategory categoryForMethod(String fullMethodName) {
        if (fullMethodName == null) {
            return NONE;
        } else {
            String subString = null;
            int index = fullMethodName.indexOf("#");
            if (index >= 0) {
                subString = fullMethodName.substring(index + 1);
            }

            MetricCategory metricCategory = (MetricCategory)methodMap.get(subString);
            if (metricCategory == null) {
                metricCategory = NONE;
            }

            return metricCategory;
        }
    }
}

