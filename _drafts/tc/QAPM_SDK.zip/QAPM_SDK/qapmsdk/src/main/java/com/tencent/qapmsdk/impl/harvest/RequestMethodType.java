package com.tencent.qapmsdk.impl.harvest;

public enum RequestMethodType {
    GET,
    POST,
    PUT,
    DELETE,
    HEAD,
    TRACE,
    OPTIONS,
    CONNECT;

    private RequestMethodType() {
    }
}

