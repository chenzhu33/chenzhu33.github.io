package com.tencent.qapmsdk.looper;

import android.support.annotation.Nullable;

class MonitorInfo {
    interface IMonitorCallback {
        void onMonitorEnd();
    }
    
    volatile boolean whetherReportThisTime = false;
    @Nullable
    volatile String stack = null;
    volatile long lastStackRequestTime = 0;
    volatile long cacheRealStackTime = 0;
    boolean stackGetterInited = false; // 由于该变量很常用，为了效率不设置为volatile，抓栈线程启动的同步由下面的'stackGetter'来做
    @Nullable
    volatile GetStackRunnable stackGetter = null;
    IMonitorCallback callback;
}