package com.tencent.qapmsdk.dns.model;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class DnsCacheObj {

    public String host;
    public CopyOnWriteArrayList<IpCachedItem> ipList;
    public long ttl;
    public long updateTime;
    public boolean wifi;
    public String ssid;
    public int from;

    public List<String> getIpList() {
        List<String> result = new ArrayList<>();
        if (ipList != null && ipList.size() > 0) {
            for (IpCachedItem item : ipList) {
                result.add(item.ip);
            }
        }
        return result;
    }

    public static String hash(String ssid) {
        if (ssid == null) ssid = "";
        return String.valueOf(ssid.hashCode());
    }

    @Override
    public String toString() {
        return "DnsCacheObj{" +
                "host='" + host + '\'' +
                ", ipList=" + ipList +
                ", ttl=" + ttl +
                ", updateTime=" + updateTime +
                ", wifi=" + wifi +
                ", ssid='" + ssid + '\'' +
                ", from=" + from +
                '}';
    }
}
