package com.tencent.qapmsdk.dns;

import android.content.Context;
import android.util.Log;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.dns.logic.LocalDnsManager;
import com.tencent.qapmsdk.dns.model.DnsInfo;
import com.tencent.qapmsdk.dns.network.NetworkReceiver;
import com.tencent.qapmsdk.dns.network.NetworkUtils;
import com.tencent.qapmsdk.dns.policy.IpPolicy;
import com.tencent.qapmsdk.dns.utils.HookUtils;
import com.tencent.qapmsdk.dns.utils.Utils;

import java.net.InetAddress;
import java.util.List;
import java.util.Map;

/**
 * Created by quinn on 17/10/2017.
 *
 * 使用域名到某台HttpDns服务器查询ip列表
 *
 */

public class HttpDns {

    private static final String TAG = "QAPM_HttpDns";


    /**
     * 加载httpdns
     * @param context 建议传入ApplicationContext
     */
    public static void install(Context context) {
        NetworkReceiver.register(context);
        NetworkUtils.init(context);
        HttpDns.setCallback(new Callback() {
            boolean hook = false;
            @Override
            public void onHook(boolean success, Throwable tr) {
                hook = success;
            }

            @Override
            public void onResolveDns(DnsType type, String host, InetAddress[] inetAddresses, long cost) {
                if (hook){
                    DnsInfo.setDns(host, inetAddresses, cost);
                }
            }
        });
        HookUtils.hook();
    }

    /**
     * 设置本地dns映射，优先于cachedns、httpdns、systemdns被处理
     * @param localDnsMap 本地dns映射表
     */
    public static void setLocalDns(Map<String, List<String>> localDnsMap) {
        LocalDnsManager.getInstance().setLocalDnsMap(localDnsMap);
    }


    /**
     * 设置ip选择策略
     * @param policy
     */
    public static void setIpPolicy(IpPolicy policy) {
        IpPolicy.setIpPolicy(policy);
    }

    public static void setCallback(Callback callback) {
        Utils.setCallback(callback);
    }

    public enum DnsType {
        LOCAL,
        CACHE,
        SYSTEM,
        ;
    }

    public interface Callback {
        void onHook(boolean success, Throwable tr);
        void onResolveDns(DnsType type, String host, InetAddress[] inetAddresses, long cost);
    }
}
