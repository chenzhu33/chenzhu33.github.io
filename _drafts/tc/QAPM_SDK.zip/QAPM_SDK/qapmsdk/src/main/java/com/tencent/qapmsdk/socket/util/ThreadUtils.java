package com.tencent.qapmsdk.socket.util;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Process;
import android.support.annotation.RestrictTo;

/**
 * Created by nicorao on 2018/1/3.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY)
public class ThreadUtils {

    private static Handler sHandler;

    static {
        // 去掉优先级 Process.THREAD_PRIORITY_BACKGROUND 避免太滞后处理
        HandlerThread thread = new HandlerThread("TrafficSingle");
        thread.start();
        sHandler = new Handler(thread.getLooper());
    }

    public static void replaceSingle(Runnable task, long delay) {
        sHandler.removeCallbacks(task);
        sHandler.postDelayed(task, delay);
    }

    public static void removeSingle(Runnable task) {
        sHandler.removeCallbacks(task);
    }
}
