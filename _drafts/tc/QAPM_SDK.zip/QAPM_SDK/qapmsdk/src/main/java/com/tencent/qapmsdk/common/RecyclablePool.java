package com.tencent.qapmsdk.common;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

public class RecyclablePool {
    private static boolean DEBUG = false;
    public static class Recyclable {
        @Nullable
        private Recyclable next;
        private boolean inPool;
        public void recycle() {
            next = null;
        }
        @Nullable
        public Recyclable getNext() {
            return next;
        }
        private void changeNext(@Nullable Recyclable nn, boolean outPool) {
            if (inPool && outPool) {
                if (DEBUG) {
                    Log.d("POOL", "changeNext " + nn + ", " + outPool);
                }
                throw new RuntimeException("WTF");
            }
            if (DEBUG && nn == null) {
                Log.d("POOL", "changeNext " + nn + ", " + outPool);
            }
            next = nn;
        }
    }

    @NonNull
    private Recyclable mHead = new Recyclable();
    private volatile int mCount = 0;
    private volatile int mCapacity = 0;

    public RecyclablePool(@NonNull Class<? extends Recyclable> clz, int capacity) {
        //连续申请比用时申请：空间连续
        Recyclable item;
        synchronized (mHead) {
            mCapacity = capacity;
            mHead.inPool = true;
            for (int i = 0; i < capacity; ++i) {
                try {
                    item = clz.newInstance();
                    item.inPool = true;
                    item.changeNext(mHead.getNext(), false);
                    mHead.changeNext(item, false);
                    ++mCount;
                } catch (Throwable e) {}
            }
        }
    }

    @Nullable
    public Recyclable obtain(@NonNull Class<? extends Recyclable> clz) {
        Recyclable o = null;
        int count = mCount;
        if (count > 0) {
            synchronized (mHead) {
                if (mCount > 0) {
                    o = mHead.getNext();
                    if (DEBUG) {
                        Log.d("POOL", "obtain " + mCount + ", " + o);
                    }
                    if (o == null) {
                        throw new RuntimeException("WTF");
                    } else {
                        if (!o.inPool) {
                            throw new RuntimeException("WTF");
                        }
                        mHead.changeNext(o.next, false);
                        o.inPool = false;
                        --mCount;
                    }
                }
            }
        } else {
            if (DEBUG) {
                Log.d("POOL", "obtain " + count);
            }
        }
        if (o == null) {
            try {
                o = clz.newInstance();
            } catch (Throwable e) {}
        }
        return o;
    }

    public void recycle(@NonNull Recyclable o) {
        o.recycle();
        int count = mCount;
        if (count < mCapacity) {
            synchronized (mHead) {
                if (o.inPool) {
                    throw new RuntimeException("WTF");
                }
                if (mCount < mCapacity) {
                    o.changeNext(mHead.getNext(), false);
                    mHead.changeNext(o, false);
                    o.inPool = true;
                    ++mCount;

                    if (DEBUG) {
                        Log.d("POOL", "recycle " + mCount + ", " + o);
                    }
                }
            }
        } else {
            if (DEBUG) {
                Log.d("POOL", "recycle " + count);
            }
        }
    }
}