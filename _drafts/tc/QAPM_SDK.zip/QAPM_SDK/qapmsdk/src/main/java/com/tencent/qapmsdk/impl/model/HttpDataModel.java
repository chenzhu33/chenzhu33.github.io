package com.tencent.qapmsdk.impl.model;

import com.tencent.qapmsdk.dns.model.DnsInfo;
import com.tencent.qapmsdk.impl.api.data.TransactionData;
import com.tencent.qapmsdk.impl.report.TrafficMonitorReport;
import com.tencent.qapmsdk.socket.model.SocketInfo;
import com.tencent.qapmsdk.socket.model.SocketTracer;

import java.net.InetAddress;
import java.net.URL;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HttpDataModel {

    public static void collectData(TransactionData data, TreeMap treeMap, String exceptionInfo){
        SocketInfo socketInfo = getSocketInfo(data);
        if (socketInfo != null){
            socketInfo.url = data.getUrl();
            socketInfo.duringTime = data.getTime();
            socketInfo.startTimeStamp = data.getStartTimeStamp();
            if (socketInfo.statusCode == 0 || data.getErrorCode() > 400){
                socketInfo.statusCode = data.getStatusCode();
                socketInfo.errorCode = data.getErrorCode();
            }
            SocketTracer.removeSocketInfoFromMap(data.getUrl());

        }
        else {
            socketInfo = generateSocketInfo(data);
        }
        TrafficMonitorReport.getInstance().addHttpToQueue(socketInfo);
        TrafficMonitorReport.getInstance().doReport();
    }

    public static void collectData(TransactionData data, String exceptionInfo){
        SocketInfo socketInfo = getSocketInfo(data);
        if (socketInfo != null){
            socketInfo.url = data.getUrl();
            socketInfo.duringTime = data.getTime();
            socketInfo.startTimeStamp = data.getStartTimeStamp();
            if (socketInfo.statusCode == 0 || data.getErrorCode() > 400){
                socketInfo.statusCode = data.getStatusCode();
                socketInfo.errorCode = data.getErrorCode();
            }
            SocketTracer.removeSocketInfoFromMap(data.getUrl());

        }
        else {
            socketInfo = generateSocketInfo(data);
        }
        TrafficMonitorReport.getInstance().addHttpToQueue(socketInfo);
        TrafficMonitorReport.getInstance().doReport();
    }

    public static void collectData(TransactionData data){
        SocketInfo socketInfo = getSocketInfo(data);
        if (socketInfo != null){
            socketInfo.url = data.getUrl();
            socketInfo.duringTime = data.getTime();
            socketInfo.startTimeStamp = data.getStartTimeStamp();
            if (socketInfo.statusCode == 0){
                socketInfo.statusCode = data.getStatusCode();
            }
            SocketTracer.removeSocketInfoFromMap(data.getUrl());
            TrafficMonitorReport.getInstance().addHttpToQueue(socketInfo);
            TrafficMonitorReport.getInstance().doReport();
        }
    }

    public static void collectData(TransactionData data, Exception e){
        SocketInfo socketInfo = getSocketInfo(data);
        if (socketInfo != null){
            socketInfo.url = data.getUrl() + (data.getAllGetRequestParams() == null ? "" : "?" + data.getAllGetRequestParams());
            socketInfo.duringTime = data.getTime();
            socketInfo.startTimeStamp = data.getStartTimeStamp();
            socketInfo.statusCode = data.getStatusCode();
            socketInfo.errorCode = data.getErrorCode();
            SocketTracer.removeSocketInfoFromMap(data.getUrl());
        }
        else {
            socketInfo = generateSocketInfo(data);
        }
        TrafficMonitorReport.getInstance().addHttpToQueue(socketInfo);
        TrafficMonitorReport.getInstance().doReport();
    }

    private static SocketInfo getSocketInfo(TransactionData data){
        try {
            String url = data.getUrl();
            URL uri = new URL(url);
            int port = uri.getPort();
            String key;
            if (port != -1){
                Pattern portPattern = Pattern.compile(":"+port);
                String[] urlSplit = portPattern.split(url);
                String host = urlSplit.length > 1 ? urlSplit[0] + urlSplit[1] : urlSplit[0];
                key = host + (data.getAllGetRequestParams() == null ? "" : "?" + data.getAllGetRequestParams());
            }
            else {
                key = url + (data.getAllGetRequestParams() == null ? "" : "?" + data.getAllGetRequestParams());
            }

            SocketInfo socketInfo = SocketTracer.getSocketInfoFromMap(key);
            //避免因为先处理了域名解析后再用ip链接，这样会导致匹配不到,所以要域名解析后的链接再看看。
            if (socketInfo == null && hostIsIp(uri)){
                String host = uri.getHost();
                String domain = DnsInfo.getHostFromIp(host);
                key = key.replace(host, domain);
                socketInfo = SocketTracer.getSocketInfoFromMap(key);
            }
            return socketInfo;
        }
        catch (Exception e){
            return null;
        }

    }

    private static boolean hostIsIp(URL url){
        String host = url.getHost();
        Pattern ipPattern = Pattern.compile("^(2[0-5]{2}|[0-1]?\\d{1,2})(\\.(2[0-5]{2}|[0-1]?\\d{1,2})){3}$");
        Matcher m = ipPattern.matcher(host);
        return m.find();
    }

    private static SocketInfo generateSocketInfo(TransactionData data){
        SocketInfo socketInfo = new SocketInfo();
        String url = data.getUrl();
        socketInfo.url = url;
        socketInfo.duringTime = data.getTime();
        socketInfo.startTimeStamp = data.getStartTimeStamp();
        socketInfo.contentType = data.getContentType();
        socketInfo.statusCode = data.getStatusCode();
        socketInfo.errorCode = data.getErrorCode();
        try {
            URL uri = new URL(url);
            if (hostIsIp(uri)){
                socketInfo.ip = uri.getHost();
            }
            else {
                InetAddress[] arrayOfInetAddress = InetAddress.getAllByName(uri.getHost());
                socketInfo.dnsTime = DnsInfo.getDnsElapse(uri.getHost());
                if (arrayOfInetAddress.length > 0){
                    socketInfo.ip = arrayOfInetAddress[0].getHostAddress();
                }
            }
        }
        catch (Exception e){
        }
        return socketInfo;
    }

}
