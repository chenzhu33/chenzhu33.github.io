package com.tencent.qapmsdk.reporter;

abstract class BaseUploadRunnable implements Runnable {
    public abstract boolean isSucceeded(String resp);
}