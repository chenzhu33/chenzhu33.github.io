package com.tencent.qapmsdk.impl.appstate;

import android.content.Context;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.AsyncSPEditor;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTraceUnit;
import com.tencent.qapmsdk.impl.instrumentation.TraceType;
import com.tencent.qapmsdk.impl.util.TraceUtil;
import com.tencent.qapmsdk.impl.instrumentation.QAPMAppInstrumentation;

public class AppStateTimeInfo {
    private final static String TAG = "QAPM_Impl_AppStateTimeInfo";
    private long appBeginTime;
    private long appAttachBaseContextBeginTime;
    private long appAttachBaseContextEndTime;
    private long appCreateBeginTime;
    private long appCreateEndTime;
    private long activityCreateBeginTime;
    private long activityCreateEndTime;
    private long activityReStartBeginTime;
    private long activityReStartEndTime;
    private long activityStartBeginTime;
    private long activityStartEndTime;
    private long activityResumeBeginTime;
    private long activityResumeEndTime;
    private long HybridOnResumeEndTime;

    public static boolean hasStartEnd = false;
    public boolean hasSnooze = false;
    public static volatile long lastBackgroundTime = 0L;
    private static AppStateTimeInfo instance;
    private MethodEventListener eventListener = new MethodEventListener();
    private String activityName;
    private AsyncSPEditor editor = null;

    public static AppStateTimeInfo getInstance() {
        if (instance == null) {
            synchronized(AppStateTimeInfo.class) {
                if (instance == null) {
                    instance = new AppStateTimeInfo();
                }
            }
        }

        return instance;
    }

//    public MethodEventListener getEventListener() {
//        return this.eventListener;
//    }

    private AppStateTimeInfo() {

    }

    private void reSet() {
        this.appAttachBaseContextBeginTime = 0L;
        this.appAttachBaseContextEndTime = 0L;
        this.appCreateEndTime = 0L;
        this.activityCreateBeginTime = 0L;
        this.activityCreateEndTime = 0L;
        this.activityReStartBeginTime = 0L;
        this.activityReStartEndTime = 0L;
        this.activityStartBeginTime = 0L;
        this.activityStartEndTime = 0L;
        this.activityResumeBeginTime = 0L;
        this.HybridOnResumeEndTime = 0L;
    }

    private boolean isHotStart() {
        if (this.appAttachBaseContextBeginTime == 0L && lastBackgroundTime != 0L) {
            long hotStartThreshold = (long)TraceUtil.HOT_START_THRESHOLD;
            boolean res = System.currentTimeMillis() - lastBackgroundTime >= hotStartThreshold * 1000L;
            return res;
        } else {
            return false;
        }
    }

    private void doHostStart() {
        //热启动前清理数据
        QAPMMonitorThreadLocal.getInstance().getFinishedMethodThreadLocal().get().clear();
        TraceUtil.appState.set(AppState.HOTSTART.getValue());
        this.appBeginTime = System.currentTimeMillis();
        //this.eventListener.registerEvent(TraceType.CONTEXT.APP);
    }

    private void initConfig() {
        try {
            Context context = TraceUtil.getContext();
            Magnifier.QAPM_SP = context.getSharedPreferences(Magnifier.TAG,  Context.MODE_PRIVATE);
            editor = new AsyncSPEditor(Magnifier.QAPM_SP.edit());
            int curVersionCode = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
            TraceUtil.versionCode = curVersionCode;
            int lastVersionCode = Magnifier.QAPM_SP.getInt(ConfigurationName.appVersion, -1);

            if (lastVersionCode == -1) {
                TraceUtil.canInstrumentMonitor = true;
            } else {
                TraceUtil.setFirstVisit(Magnifier.QAPM_SP.getInt(ConfigurationName.betaOn, 0));
                TraceUtil.canInstrumentMonitor = true;
            }

            //判断是否对版本升级，如果升级版本或者之前的版本不存在则为首次启动
            if (lastVersionCode != -1 && lastVersionCode == curVersionCode) {
                TraceUtil.appState.set(AppState.COLDSTART.getValue());
            } else {
                TraceUtil.appState.set(AppState.FIRSTSTART.getValue());
            }

        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, "initInAttachBaseContextEnv:", e);
        }

    }


    //处理上报
    private void beforeReport() {
        if (TraceUtil.appState.get() != AppState.COMMONRESTART.getValue()
                && TraceUtil.appState.get() != AppState.INIT.getValue()
                && TraceUtil.appState.get() != AppState.f.getValue()
        ) {
            if (appLaunchDurationTime() != -1){
                long appLaunchBeginTime = this.appLaunchBeginTime();

                MonitorAdapter monitorAdapter = MonitorAdapter.newOne("QAPM_APPLAUNCH",
                        this.appLaunchStageName(),
                        Config.mSampleConfigs.get(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT).threshold,
                        TraceType.CONTEXT.APP);
                monitorAdapter.sectionHarve.setEntryTimestamp(appLaunchBeginTime);
                monitorAdapter.sectionHarve.setExitTimestamp(this.activityResumeEndTime);

                if (TraceUtil.appState.get() == AppState.FIRSTSTART.getValue() || TraceUtil.appState.get() == AppState.COLDSTART.getValue()){
                    monitorAdapter.addMonitorUnit(new QAPMTraceUnit(
                            "QAPM_APPLAUNCH",
                            TraceUtil.LAUNCH_APPLICATION_INIT,
                            this.appAttachBaseContextBeginTime,
                            this.appAttachBaseContextEndTime,
                            TraceType.CONTEXT.APP.getValue()
                    ));

                    monitorAdapter.deleteMonitorUnit(false);

                    monitorAdapter.addMonitorUnit(new QAPMTraceUnit(
                            "QAPM_APPLAUNCH",
                            TraceUtil.LAUNCH_MAIN_ACTIVITY_INIT,
                            this.appAttachBaseContextEndTime,
                            this.appCreateEndTime,
                            TraceType.CONTEXT.APP.getValue()
                    ));

                    monitorAdapter.deleteMonitorUnit(false);

                }

                monitorAdapter.addMonitorUnit(new QAPMTraceUnit(
                        "QAPM_APPLAUNCH",
                        TraceUtil.LAUNCH_ACTIVITY_LOAD,
                        this.activityPageStartLoadingTime(),
                        this.activityResumeEndTime,
                        TraceType.CONTEXT.APP.getValue()
                ));
                monitorAdapter.deleteMonitorUnit(false);
                monitorAdapter.sectionHarve.readyToReport(monitorAdapter.getQapmMonitorThreadLocal());
            }



            if (editor != null){
                editor.putInt(ConfigurationName.appVersion, TraceUtil.versionCode);
                editor.putInt(ConfigurationName.betaOn, 1);
                editor.commit();
            }
        }

    }

    private long appLaunchBeginTime(){
        if(TraceUtil.appState.get() == AppState.HOTSTART.getValue()){
            if (this.activityCreateBeginTime == 0L){
                return this.activityReStartBeginTime;
            } else {
                //todo: 这里是否需要按照后面处理区段的逻辑处理？
                //return this.appCreateEndTime == 0 ? this.activityCreateBeginTime : this.appCreateEndTime;
                return this.activityCreateBeginTime;
            }
        }
        else if (TraceUtil.appState.get() == AppState.FIRSTSTART.getValue() || TraceUtil.appState.get() == AppState.COLDSTART.getValue()){
            return this.appAttachBaseContextBeginTime;
        }
        else {
            return -1;
        }
    }

    private long activityPageStartLoadingTime(){
        if (this.activityCreateBeginTime == 0L){
            return this.activityReStartBeginTime;
        } else {
            return this.appCreateEndTime == 0 ? this.activityCreateBeginTime : this.appCreateEndTime;
        }
    }



    private long mainActivityInitDurationTime() {
        return TraceUtil.appState.get() == AppState.HOTSTART.getValue() ?
                -1L : this.appCreateEndTime - this.appAttachBaseContextEndTime;
    }

    private long appApplicationInitDurationTime() {
        return TraceUtil.appState.get() == AppState.HOTSTART.getValue() ?
                -1L : this.appAttachBaseContextEndTime - this.appAttachBaseContextBeginTime;
    }

    private long activityResumeDurationTime() {
        if (this.activityCreateBeginTime == 0L) {
            return this.activityResumeEndTime - this.activityReStartEndTime;
        } else {
            return this.HybridOnResumeEndTime <= 0L ?
                    this.activityResumeEndTime - this.activityCreateEndTime
                    : this.HybridOnResumeEndTime - this.activityCreateEndTime;
        }
    }

    private long activityCreateDurationTime() {
        if (this.activityCreateBeginTime != 0L && this.activityCreateEndTime != 0L) {
            return this.appCreateEndTime == 0L && this.activityCreateBeginTime != 0L ?
                    this.activityCreateEndTime - this.activityCreateBeginTime
                    : this.activityCreateEndTime - this.appCreateEndTime;
        } else {
            return this.activityReStartEndTime - this.activityReStartBeginTime;
        }
    }


    private long appLaunchDurationTime(){
        if(TraceUtil.appState.get() == AppState.HOTSTART.getValue()){
            return this.activityCreateDurationTime() + this.activityResumeDurationTime();
        }
        else if (TraceUtil.appState.get() == AppState.FIRSTSTART.getValue() || TraceUtil.appState.get() == AppState.COLDSTART.getValue()){
            return this.appApplicationInitDurationTime() + this.mainActivityInitDurationTime() + this.activityCreateDurationTime() + this.activityResumeDurationTime();
        }
        else {
            return -1;
        }
    }

    private String appLaunchStageName(){
        if(TraceUtil.appState.get() == AppState.HOTSTART.getValue()){
            return TraceUtil.WARM_LAUNCH;
        }
        else if(TraceUtil.appState.get() == AppState.COLDSTART.getValue()){
            return TraceUtil.COLD_LAUNCH;
        }
        else if(TraceUtil.appState.get() == AppState.FIRSTSTART.getValue()){
            return TraceUtil.FIRST_TIME_LAUNCH;
        }
        else{
            return "";
        }
    }


    public void attachBaseContextBeginIns(Context context) {
        hasStartEnd = false;
        TraceUtil.saveContext(context);
        this.initConfig();
        if (TraceUtil.canInstrumentMonitor) {
            this.appBeginTime = System.currentTimeMillis();
            this.appAttachBaseContextBeginTime = this.appBeginTime;
            //this.eventListener.registerEvent(TraceType.CONTEXT.APP);
        }
    }

    private Context getContext() {
        return TraceUtil.getContext();
    }

    public void attachBaseContextEndIns() {
        if (TraceUtil.canInstrumentMonitor) {
            this.appAttachBaseContextEndTime = System.currentTimeMillis();
        }
    }

    public void applicationCreateBeginIns() {
        if (TraceUtil.canInstrumentMonitor) {
            this.appCreateBeginTime = System.currentTimeMillis();
        }
    }

    public void applicationCreateEndIns() {
        if (TraceUtil.canInstrumentMonitor) {
            this.appCreateEndTime = System.currentTimeMillis();
        }
    }

    public void activityCreateBeginIns(String activityName) {
        if (!hasStartEnd) {
            if (TraceUtil.canInstrumentMonitor) {
                this.activityName = activityName;
                if (TraceUtil.appState.get() == AppState.f.getValue()) {
                    if (this.isHotStart()) {
                        this.doHostStart();
                    } else {
                        TraceUtil.appState.set(AppState.COMMONRESTART.getValue());
                    }
                }

                this.activityCreateBeginTime = System.currentTimeMillis();
            }
        }
    }

    public void activityCreateEndIns() {
        if (!hasStartEnd) {
            if (TraceUtil.canInstrumentMonitor) {
                this.activityCreateEndTime = System.currentTimeMillis();
            }
        }
    }

    public void activityStartBeginIns(String activityName) {
        if (!hasStartEnd) {
            if (TraceUtil.canInstrumentMonitor) {
                this.activityStartBeginTime = System.currentTimeMillis();
            }
        }
    }

    public void activityStartEndIns() {
        if (!hasStartEnd) {
            if (TraceUtil.canInstrumentMonitor) {
                if (this.activityStartEndTime == 0L) {
                    this.activityStartEndTime = System.currentTimeMillis();
                }

            }
        }
    }

    public void activityRestartBeginIns(String activityName) {
        hasStartEnd = false;
        this.activityName = activityName;
        TraceUtil.canInstrumentMonitor = true;
        if (TraceUtil.canInstrumentMonitor) {
            if (this.activityReStartBeginTime == 0L) {
                if (this.isHotStart()) {
                    this.doHostStart();
                } else {
                    TraceUtil.appState.set(AppState.COMMONRESTART.getValue());
                }

                this.activityReStartBeginTime = System.currentTimeMillis();
            }

        }
    }

    public void activityRestartEndIns() {
        if (TraceUtil.canInstrumentMonitor) {
            if (this.activityReStartEndTime == 0L) {
                this.activityReStartEndTime = System.currentTimeMillis();
            }

        }
    }

    public void activityResumeBeginIns(String activityName) {
        if (!hasStartEnd) {
            if (TraceUtil.canInstrumentMonitor) {
                this.activityName = activityName;
                this.activityResumeBeginTime = System.currentTimeMillis();
            }
        }
    }

    public void activityResumeEndIns() {
        if (TraceUtil.canInstrumentMonitor) {
            if (!hasStartEnd) {
                try {
                    this.activityResumeEndTime = System.currentTimeMillis();
//                    if(!hasSnooze){
//                        this.hasStartEnd = true;
//                    }
//                    else{
//                        this.beforeReport();
//                    }
                    hasStartEnd = true;
                    this.beforeReport();


                } catch (Exception e) {
                    Magnifier.ILOGUTIL.exception(TAG, "error:", e);
                } finally {
                    //if (com.networkbench.agent.impl.util.h.j().W() == com.networkbench.agent.impl.util.h.a.a) {
                        this.appStartEnd();
                    //}

                }
            }
        }
    }

//    public void HybridOnResumeEndIns(String className) {
//        if (className.equals(this.activityName)) {
//            if (this.activityResumeEndTime <= 0L) {
//                com.networkbench.agent.impl.util.h.j().j(false);
//                return;
//            }
//
//            this.HybridOnResumeEndTime = System.currentTimeMillis();
//            this.beforeReport();
//            this.appStartEnd();
//            this.hasStartEnd = false;
//        }
//
//    }

    private void appStartEnd() {
        QAPMAppInstrumentation.isAppInBackground = false;
        TraceUtil.appState.set(AppState.INIT.getValue());
        instance.reSet();
    }
}
