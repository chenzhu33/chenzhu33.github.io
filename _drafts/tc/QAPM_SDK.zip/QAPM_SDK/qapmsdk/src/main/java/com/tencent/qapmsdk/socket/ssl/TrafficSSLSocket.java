package com.tencent.qapmsdk.socket.ssl;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.SystemClock;
import android.support.annotation.Keep;
import android.support.annotation.RestrictTo;

import com.tencent.qapmsdk.socket.TrafficConnectReporter;
import com.tencent.qapmsdk.socket.TrafficInputStream;
import com.tencent.qapmsdk.socket.TrafficMonitor;
import com.tencent.qapmsdk.socket.TrafficOutputStream;
import com.tencent.qapmsdk.socket.TrafficSocketImpl;
import com.tencent.qapmsdk.socket.model.SocketInfo;
import com.tencent.qapmsdk.socket.util.ReflectionHelper;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketImpl;
import java.nio.channels.SocketChannel;

import javax.net.ssl.HandshakeCompletedListener;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;



/**
 * Created by nicorao on 2017/12/6.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY)
public class TrafficSSLSocket extends SSLSocket {

    private static final String TAG = "QAPM_Socket_TrafficSSLSocket";

    private static final String CLASSNAME_OPENSSLSOCKETIMPL = ReflectionHelper.getOpenSSLPackageName() + ".OpenSSLSocketImpl";

    private SSLSocket mSocket;

    private TrafficInputStream mIn;
    private TrafficOutputStream mOut;

    private SocketInfo mSocketInfo;

    private String mHost;
    private String mIP;
    private int mPort;

    TrafficTrustManager mTrafficTrustManager;

    TrafficSSLSocket(Socket socket, InetAddress address, int port) {
        this(socket, address.getHostName(), address, port);
    }

    TrafficSSLSocket(Socket socket, String host, int port) {
        this(socket, host, null, port);
    }

    private TrafficSSLSocket(Socket socket, String host, InetAddress address, int port) {
        mSocket = (SSLSocket) socket;
        mSocketInfo = new SocketInfo();
        mHost = host;
        if (address != null) {
            mIP = address.getHostAddress();
        } else if (socket.getInetAddress() != null) {
            mIP = socket.getInetAddress().getHostAddress();
        } else {
            mIP = "";
        }
        mPort = port;
        cloneTrafficTrustManager(host);
    }

    private void cloneTrafficTrustManager(String host) {
        try {
            Object sslParameters = ReflectionHelper.of(mSocket.getClass()).field("sslParameters").get(mSocket);
            Field fieldX509TrustManager = ReflectionHelper.of(sslParameters.getClass()).field(Build.VERSION.SDK_INT >= 21 ? "x509TrustManager" : "trustManager");
            Object x509TrustManager = fieldX509TrustManager.get(sslParameters);
            if (x509TrustManager instanceof TrafficTrustManager) {
                TrafficTrustManager newTrafficTrustManager = (TrafficTrustManager) ReflectionHelper.of(Object.class).method("clone").invoke(x509TrustManager);
                newTrafficTrustManager.setHost(host);
                fieldX509TrustManager.set(sslParameters, newTrafficTrustManager);
                mTrafficTrustManager = newTrafficTrustManager;
            }
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
    }

    private String getFd() {
        Object fd = null;
        try {
            Socket realSocket = (Socket) ReflectionHelper.of(CLASSNAME_OPENSSLSOCKETIMPL).field("socket").get(mSocket);
            Object oImpl = ReflectionHelper.of(Socket.class).field("impl").get(realSocket);
            fd = ReflectionHelper.of(SocketImpl.class).field("fd").get(oImpl);
        } catch (Exception ignored) {}
        return ReflectionHelper.printFd(fd);
    }

    private int getImplHashCode() {
        SocketImpl oldImpl = null;
        try {
            Socket realSocket = (Socket) ReflectionHelper.of(CLASSNAME_OPENSSLSOCKETIMPL).field("socket").get(mSocket);
            Object oImpl = ReflectionHelper.of(Socket.class).field("impl").get(realSocket);
            if (oImpl instanceof TrafficSocketImpl) {
                oldImpl = ((TrafficSocketImpl) oImpl).getOldImpl();
            }
        } catch (Exception ignored) {}
        return oldImpl != null ? oldImpl.hashCode() : 0;
    }

    // 为了给OkHttp反射调用
    @Keep
    public void setUseSessionTickets(boolean useSessionTickets) {
        try {
            ReflectionHelper.of(CLASSNAME_OPENSSLSOCKETIMPL).method("setUseSessionTickets", boolean.class).invoke(mSocket, useSessionTickets);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
    }

    // 为了给OkHttp反射调用，这个函数重要，用于开启SNI
    @Keep
    public void setHostname(String hostname) {
        try {
            ReflectionHelper.of(CLASSNAME_OPENSSLSOCKETIMPL).method("setHostname", String.class).invoke(mSocket, hostname);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
    }

    // 为了给OkHttp反射调用
    @Keep
    public byte[] getAlpnSelectedProtocol() {
        try {
            return (byte[]) ReflectionHelper.of(CLASSNAME_OPENSSLSOCKETIMPL).method("getAlpnSelectedProtocol").invoke(mSocket);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
        return null;
    }

    // 为了给OkHttp反射调用
    @Keep
    public void setAlpnProtocols(byte[] alpnProtocols) {
        try {
            ReflectionHelper.of(CLASSNAME_OPENSSLSOCKETIMPL).method("setAlpnProtocols", byte[].class).invoke(mSocket, (Object) alpnProtocols);
        } catch (Exception e) {
            ReflectionHelper.processException(e);
        }
    }

    @Override
    public void connect(SocketAddress endpoint) throws IOException {
        if (!TrafficMonitor.config().isEnableNetwork()) throw new IOException("Disable network by developer!");
        mSocket.connect(endpoint);
    }

    @Override
    public void connect(SocketAddress endpoint, int timeout) throws IOException {
        if (!TrafficMonitor.config().isEnableNetwork()) throw new IOException("Disable network by developer!");
        mSocket.connect(endpoint, timeout);
    }

    @Override
    public void bind(SocketAddress bindpoint) throws IOException {
        if (!TrafficMonitor.config().isEnableNetwork()) throw new IOException("Disable network by developer!");
        mSocket.bind(bindpoint);
    }

    @Override
    public InetAddress getInetAddress() {
        return mSocket.getInetAddress();
    }

    @Override
    public InetAddress getLocalAddress() {
        return mSocket.getLocalAddress();
    }

    @Override
    public int getPort() {
        return mSocket.getPort();
    }

    @Override
    public int getLocalPort() {
        return mSocket.getLocalPort();
    }

    @Override
    public SocketAddress getRemoteSocketAddress() {
        return mSocket.getRemoteSocketAddress();
    }

    @Override
    public SocketAddress getLocalSocketAddress() {
        return mSocket.getLocalSocketAddress();
    }

    @Override
    public SocketChannel getChannel() {
        return mSocket.getChannel();
    }

    @Override
    public InputStream getInputStream() throws IOException {
        if (!TrafficMonitor.config().isEnableNetwork()) throw new IOException("Disable network by developer!");
        if (mIn == null) {
            mIn = new TrafficInputStream(
                    mSocket.getInputStream(),
                    mSocketInfo);
        }
        return mIn;
    }

    @Override
    public OutputStream getOutputStream() throws IOException {
        if (!TrafficMonitor.config().isEnableNetwork()) throw new IOException("Disable network by developer!");
        if (mOut == null) {
            mOut = new TrafficOutputStream(mSocket.getOutputStream(), mSocketInfo);
            mOut.initData(true, mHost, mIP, mPort, getFd(), getImplHashCode());
        }
        return mOut;
    }

    @Override
    public void setTcpNoDelay(boolean on) throws SocketException {
        mSocket.setTcpNoDelay(on);
    }

    @Override
    public boolean getTcpNoDelay() throws SocketException {
        return mSocket.getTcpNoDelay();
    }

    @Override
    public void setSoLinger(boolean on, int linger) throws SocketException {
        mSocket.setSoLinger(on, linger);
    }

    @Override
    public int getSoLinger() throws SocketException {
        return mSocket.getSoLinger();
    }

    @Override
    public void sendUrgentData(int data) throws IOException {
        mSocket.sendUrgentData(data);
    }

    @Override
    public void setOOBInline(boolean on) throws SocketException {
        mSocket.setOOBInline(on);
    }

    @Override
    public boolean getOOBInline() throws SocketException {
        return mSocket.getOOBInline();
    }

    @Override
    public synchronized void setSoTimeout(int timeout) throws SocketException {
        mSocket.setSoTimeout(timeout);
    }

    @Override
    public synchronized int getSoTimeout() throws SocketException {
        return mSocket.getSoTimeout();
    }

    @Override
    public synchronized void setSendBufferSize(int size) throws SocketException {
        mSocket.setSendBufferSize(size);
    }

    @Override
    public synchronized int getSendBufferSize() throws SocketException {
        return mSocket.getSendBufferSize();
    }

    @Override
    public synchronized void setReceiveBufferSize(int size) throws SocketException {
        mSocket.setReceiveBufferSize(size);
    }

    @Override
    public synchronized int getReceiveBufferSize() throws SocketException {
        return mSocket.getReceiveBufferSize();
    }

    @Override
    public void setKeepAlive(boolean on) throws SocketException {
        mSocket.setKeepAlive(on);
    }

    @Override
    public boolean getKeepAlive() throws SocketException {
        return mSocket.getKeepAlive();
    }

    @Override
    public void setTrafficClass(int tc) throws SocketException {
        mSocket.setTrafficClass(tc);
    }

    @Override
    public int getTrafficClass() throws SocketException {
        return mSocket.getTrafficClass();
    }

    @Override
    public void setReuseAddress(boolean on) throws SocketException {
        mSocket.setReuseAddress(on);
    }

    @Override
    public boolean getReuseAddress() throws SocketException {
        return mSocket.getReuseAddress();
    }

    @Override
    public synchronized void close() throws IOException {
        mSocket.close();
    }

    @Override
    public void shutdownInput() throws IOException {
        mSocket.shutdownInput();
    }

    @Override
    public void shutdownOutput() throws IOException {
        mSocket.shutdownOutput();
    }

    @Override
    public String[] getSupportedCipherSuites() {
        return mSocket.getSupportedCipherSuites();
    }

    @Override
    public String[] getEnabledCipherSuites() {
        return mSocket.getEnabledCipherSuites();
    }

    @Override
    public void setEnabledCipherSuites(String[] suites) {
        mSocket.setEnabledCipherSuites(suites);
    }

    @Override
    public String[] getSupportedProtocols() {
        return mSocket.getSupportedProtocols();
    }

    @Override
    public String[] getEnabledProtocols() {
        return mSocket.getEnabledProtocols();
    }

    @Override
    public void setEnabledProtocols(String[] protocols) {
        mSocket.setEnabledProtocols(protocols);
    }

    @Override
    public SSLSession getSession() {
        return mSocket.getSession();
    }

    @Override
    public void addHandshakeCompletedListener(HandshakeCompletedListener listener) {
        mSocket.addHandshakeCompletedListener(listener);
    }

    @Override
    public void removeHandshakeCompletedListener(HandshakeCompletedListener listener) {
        mSocket.removeHandshakeCompletedListener(listener);
    }

    @Override
    public void startHandshake() throws IOException {
        final long start = SystemClock.elapsedRealtime();
        try {
            mSocket.startHandshake();
            TrafficConnectReporter.onHandshakeCompleted(true, mHost, mPort,
                    (SystemClock.elapsedRealtime() - start), mSocketInfo);
        } catch (SSLException e) {
            TrafficConnectReporter.onHandshakeCompleted(false, mHost, mPort,
                    (SystemClock.elapsedRealtime() - start), mSocketInfo);
            onHandshakeFailed(e);
            throw e;
        }
    }

    private void onHandshakeFailed(SSLException e) {
        if (mTrafficTrustManager != null) {
            mTrafficTrustManager.onHandshakeFailed(e);
        }
    }

    @Override
    public void setUseClientMode(boolean mode) {
        mSocket.setUseClientMode(mode);
    }

    @Override
    public boolean getUseClientMode() {
        return mSocket.getUseClientMode();
    }

    @Override
    public void setNeedClientAuth(boolean need) {
        mSocket.setNeedClientAuth(need);
    }

    @Override
    public boolean getNeedClientAuth() {
        return mSocket.getNeedClientAuth();
    }

    @Override
    public void setWantClientAuth(boolean want) {
        mSocket.setWantClientAuth(want);
    }

    @Override
    public boolean getWantClientAuth() {
        return mSocket.getWantClientAuth();
    }

    @Override
    public void setEnableSessionCreation(boolean flag) {
        mSocket.setEnableSessionCreation(flag);
    }

    @Override
    public boolean getEnableSessionCreation() {
        return mSocket.getEnableSessionCreation();
    }

    @Override
    public String toString() {
        return "TrafficSSLSocket[" + mSocket + "]";
    }

    @Override
    public boolean isConnected() {
        return mSocket.isConnected();
    }

    @Override
    public boolean isBound() {
        return mSocket.isBound();
    }

    @Override
    public boolean isClosed() {
        return mSocket.isClosed();
    }

    @Override
    public boolean isInputShutdown() {
        return mSocket.isInputShutdown();
    }

    @Override
    public boolean isOutputShutdown() {
        return mSocket.isOutputShutdown();
    }

    @Override
    public void setPerformancePreferences(int connectionTime, int latency, int bandwidth) {
        mSocket.setPerformancePreferences(connectionTime, latency, bandwidth);
    }

    @TargetApi(Build.VERSION_CODES.N)
    @Override
    public SSLSession getHandshakeSession() {
        return mSocket.getHandshakeSession();
    }

    @Override
    public SSLParameters getSSLParameters() {
        return mSocket.getSSLParameters();
    }

    @Override
    public void setSSLParameters(SSLParameters params) {
        mSocket.setSSLParameters(params);
    }
}
