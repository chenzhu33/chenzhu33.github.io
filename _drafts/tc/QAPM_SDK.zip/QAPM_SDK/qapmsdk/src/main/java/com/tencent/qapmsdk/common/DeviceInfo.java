package com.tencent.qapmsdk.common;


import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.Service;
import android.content.Context;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.Size;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.opengl.GLES20;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.reporter.QCloudReporter;
import com.tencent.qapmsdk.reporter.ResultObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.List;

import static java.lang.System.currentTimeMillis;


/**
 * Created by nickyliu on 2018/1/8.
 */

public class DeviceInfo {
    private static final long intervalTime = 30 * 24 * 60 * 60 * 1000l;
    private static Context context;
    private static final String TAG = ILogUtil.getTAG(DeviceInfo.class);

    public static String gl_render = null;
    public static String gl_vender = null;
    public static String gl_version = null;

    public static long lastReportTime = -1;
    public static int cores = -1;

    public static void setContext(Context c){
        context = c;
    }

    public static void reportDevice() {
        if (canReport()){
            if (CollectStatus.whetherSamplingThisTime(Config.PLUGIN_QCLOUD_DEVICE_INFO)){
                try {
                    JSONObject params = getDeviceInfo();
                    params.put("data_time", String.valueOf(currentTimeMillis()));
                    params.put("plugin", Config.PLUGIN_QCLOUD_DEVICE_INFO);
                    ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, Magnifier.info.uin);

                    //拷贝了上报的逻辑断，处理避免因为用户没有命中采样导致无上报的情况
                    ro.params.put("p_id", Magnifier.productId);
                    ro.params.put("version", Magnifier.info.version);
                    ro.params.put("uin", ro.uin);
                    ro.params.put("manu", Build.MANUFACTURER);
                    ro.params.put("device", Build.MODEL);
                    ro.params.put("os", Build.VERSION.RELEASE);
                    ro.params.put("rdmuuid", Magnifier.info.uuid);
                    ro.params.put("deviceid", PhoneUtil.getDeviceId(Magnifier.sApp));

                    QCloudReporter QCloud_Reporter = new QCloudReporter();
                    QCloud_Reporter.report(ro, null);

                } catch (Exception e) {
                    Magnifier.ILOGUTIL.exception(TAG, e);
                    return;
                }
                CollectStatus.addCollectCount(Config.PLUGIN_QCLOUD_DEVICE_INFO);
            }
            noteReportTime();
        }
    }

    private static boolean canReport() {
        BufferedReader fread = null;
        boolean res = true;

        if (lastReportTime == -1) {
            File file = new File(FileUtil.getRootPath() + "/reportDeviceInfo");
            try {
                if (!file.exists()) {
                    file.createNewFile();
                    return res;
                }
                fread = new BufferedReader(new FileReader(file), 1024);
                String lastReportTimeString = fread.readLine();
                lastReportTime = Long.valueOf(lastReportTimeString);
            }
            catch (Throwable e) {
                res = false;
                ILogUtil.getThrowableMessage(e);
            }
            finally {
                if (fread != null){
                    try {
                        fread.close();
                    }
                    catch (Exception e){
                        res = false;
                    }
                }
            }
        }

        if (currentTimeMillis() - lastReportTime <= intervalTime) {
            res = false;
        }

        return res;
    }

    private static void noteReportTime() {
        File file = new File(FileUtil.getRootPath() + "/reportDeviceInfo");
        try {
            if (!file.exists()) {
                return;
            }
            long curTime = System.currentTimeMillis();
            BufferedWriter fwrite = new BufferedWriter(new FileWriter(file), 1024);
            fwrite.write(String.valueOf(curTime));
            fwrite.flush();
            lastReportTime = curTime;
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
    }



    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    private static JSONObject getDeviceInfo() throws JSONException {
        JSONObject deviceInfo = new JSONObject();
        String[] cm = getMaxCamera();   //这里需要用户的app被开启摄像头权限才能使用。
        long maxMemory = Runtime.getRuntime().maxMemory();
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ActivityManager am = (ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
        am.getMemoryInfo(mi);

        DisplayMetrics dm = new DisplayMetrics();
        WindowManager wm = (WindowManager)context.getSystemService(Context.WINDOW_SERVICE);
        Display ds = wm.getDefaultDisplay();

        if (Build.VERSION.SDK_INT > 16){
            ds.getRealMetrics(dm);
        }
        else{
            ds.getMetrics(dm);
        }


        EGLHelper mEGLHelper=new EGLHelper();
        if (mEGLHelper.eglInit(10,10)){
            gl_render = GLES20.glGetString(GLES20.GL_RENDERER);
            gl_vender = GLES20.glGetString(GLES20.GL_VENDOR);
            gl_version = GLES20.glGetString(GLES20.GL_VERSION);
            mEGLHelper.destroy();
        }

        //基础信息部分
        deviceInfo.put("plantform", "Android");
        deviceInfo.put("device_id", PhoneUtil.getDeviceId(Magnifier.sApp));
        deviceInfo.put("device_model", Build.MODEL);
        deviceInfo.put("product", Build.PRODUCT);
        deviceInfo.put("manu", Build.MANUFACTURER);
        deviceInfo.put("os_version", Build.VERSION.RELEASE);
        deviceInfo.put("hardware", Build.HARDWARE);
        if (Build.VERSION.SDK_INT >= 21){
            String[] abis = Build.SUPPORTED_ABIS;
            StringBuilder sb = new StringBuilder(abis.length * 20);
            for (String abi : abis){
                sb.append(abi).append(", ");
                deviceInfo.put("cpuabi", sb.toString());
            }

        }
        else{
            deviceInfo.put("cpuabi", Build.CPU_ABI);
        }

        deviceInfo.put("cpuabi2", Build.CPU_ABI2);

        deviceInfo.put("screen_size", String.valueOf(dm.widthPixels) + "*" + String.valueOf(dm.heightPixels));
        deviceInfo.put("screen_dpi", String.valueOf(dm.densityDpi));
        deviceInfo.put("screen_density", String.valueOf(dm.density));
        //内存信息
        deviceInfo.put("max_mem", String.valueOf(maxMemory/(1024*1024)));
        deviceInfo.put("low_mem",  String.valueOf(mi.threshold/(1024*1024)));
        deviceInfo.put("total_mem",  String.valueOf(mi.totalMem/(1024*1024)));
        //gpu信息
        deviceInfo.put("gl_vender", gl_vender);
        deviceInfo.put("gl_render", gl_render);
        deviceInfo.put("gl_version", gl_version);
        //cpu信息
        deviceInfo.put("cpu_max_hz", getMaxCpuFreq());
        deviceInfo.put("cpu_min_hz", getMinCpuFreq());
        deviceInfo.put("cpu_name",getCpuModelName());

        deviceInfo.put("availy_core", String.valueOf(Runtime.getRuntime().availableProcessors()));
        deviceInfo.put("avaliable_cpu_scheduler", StringUtil.replaceBlank(FileUtil.readOutputFromFile(Constants.scaling_available_governors)));
        deviceInfo.put("current_cpu_scheduler", StringUtil.replaceBlank(FileUtil.readOutputFromFile(Constants.scaling_governor)));
        deviceInfo.put("number_soft_core", String.valueOf(getNumCoure()));
        //摄像头信息
        deviceInfo.put("main_camera_size", cm[0]);
        deviceInfo.put("camera_size", cm[1]);
        deviceInfo.put("all_camera_size", getAllCameraSize());
        deviceInfo.put("media_codec", getMediaCodec());
        //deviceInfo.put("ioscheduler", replaceBlank(getCurrentIOScheduler()));
        //io信息
        deviceInfo.put("available_io_scheduler", StringUtil.replaceBlank(getAvailableIOScheduler())); //当前所使用的I/O调度算法
        deviceInfo.put("read_ahead", getReadAhead());   //一次提前读多少内容
        deviceInfo.put("data_block_size", String.valueOf(getBlockSizeData()));
        deviceInfo.put("sdcard_block_size", String.valueOf(getBlockSizeSDCARD()));
        //网络信息
        deviceInfo.put("default_receive_windows", FileUtil.readOutputFromFile(Constants.default_recive_window));
        deviceInfo.put("default_send_windows", FileUtil.readOutputFromFile(Constants.default_send_window));

        deviceInfo.put("other1", "");
        deviceInfo.put("other2", "");
        deviceInfo.put("other3", "");
        deviceInfo.put("other4", "");
        deviceInfo.put("other5", "");
        deviceInfo.put("other6", "");
        deviceInfo.put("other7", "");
        deviceInfo.put("other8", "");
        //deviceInfo.put("cpuschedule", replaceBlank(getAvailableGovernors()));

        return deviceInfo;
    }

    public static String getMacAddr(Context ctx) {

        String defaultMacAddr = "02:00:00:00:00:00";
        WifiManager wifiManager = (WifiManager) ctx.getSystemService(Service.WIFI_SERVICE);
        if (wifiManager == null)
            return null;
        WifiInfo wifiInfo;
        try {
            wifiInfo = wifiManager.getConnectionInfo();
        } catch(SecurityException e){
            wifiInfo = null;
        }

        if (wifiInfo == null)
            return null;

        String macAddr = null;
        if (wifiInfo.getMacAddress() == null || wifiInfo.getMacAddress().equals("")
                || wifiInfo.getMacAddress().equals(defaultMacAddr)) {

            macAddr = FileUtil.readOutputFromFile(Constants.wlan_mac_address);
            if (TextUtils.isEmpty(macAddr)) {
                macAddr = FileUtil.readOutputFromFile(Constants.eth_mac_address);
            } else {
                return macAddr;
            }

            if (TextUtils.isEmpty(macAddr)) {
                Enumeration<NetworkInterface> interfaces = null;
                try {
                    interfaces = NetworkInterface.getNetworkInterfaces();
                } catch (SocketException e) {
                    return null;
                }
                if (interfaces == null)
                    return defaultMacAddr;
                while (interfaces.hasMoreElements()) {
                    NetworkInterface iF = interfaces.nextElement();
                    byte[] addr = null;// new byte[0];
                    try {
                        addr = iF.getHardwareAddress();
                    } catch (SocketException e) {
                        return null;
                    }
                    if (addr == null || addr.length == 0) {
                        continue;
                    }
                    StringBuilder buf = new StringBuilder();
                    for (byte b : addr) {
                        buf.append(String.format("%02X:", b));
                    }
                    if (buf.length() > 0) {
                        buf.deleteCharAt(buf.length() - 1);
                    }
                    if (iF.getName().equals("wlan0")) {
                        return buf.toString();
                    }
                }
            } else {
                return macAddr;
            }
        } else {
            return wifiInfo.getMacAddress();
        }
        return defaultMacAddr;
    }

    private static String getAllCameraSize(){
        Camera camera = null;
        try{
            camera = Camera.open();
            Parameters parameters = camera.getParameters();
            List<Size> supportedPreviewSizes = parameters.getSupportedPreviewSizes();
            List<Size> supportedPictureSizes = parameters.getSupportedPictureSizes();
            StringBuilder builder = new StringBuilder("{\"PictureSizes\":[");
            for(Size size1:supportedPictureSizes)
            {
                builder.append(size1.width + "x" + size1.height);
                builder.append(",");
            }
            builder.deleteCharAt(builder.length()-1);
            builder.append("],");
            builder.append("{\"PreviewSizes\":[");
            for(Size size1:supportedPreviewSizes)
            {
                builder.append(size1.width + "x" + size1.height);
                builder.append(",");
            }
            builder.deleteCharAt(builder.length()-1);
            builder.append("]}");
            return builder.toString();
        }
        catch(Exception ex){
            Magnifier.ILOGUTIL.exception(TAG, ex);
            return "";
        }
        finally{
            if (camera != null){
                camera.release();
            }
        }
    }

    private static String[] getMaxCamera(){
        Camera  camera = null;
        try{
            camera = Camera.open();
            Parameters parameters = camera.getParameters();
            List<Size> supportedPreviewSizes = parameters.getSupportedPreviewSizes();
            List<Size> supportedPictureSizes = parameters.getSupportedPictureSizes();
            int height = supportedPictureSizes.get(supportedPictureSizes.size() - 1).height;
            int weight = supportedPictureSizes.get(supportedPictureSizes.size() - 1).width;
            try{
                int height1 = supportedPreviewSizes.get(supportedPreviewSizes.size() - 1).height;
                int weight1 = supportedPreviewSizes.get(supportedPreviewSizes.size() - 1).width;
                String[] strs = {height + "x" + weight ,height1 + "x" + weight1};
                return strs;
            }
            catch(Exception ex)
            {
                Magnifier.ILOGUTIL.exception(TAG, ex);
                String[] strs = {height + "x" + weight ,0 + "x" + 0};
                return strs;
            }
        }
        catch(Exception ex){
            Magnifier.ILOGUTIL.exception(TAG, ex);
            String[] strs = {"" ,""};
            return strs;
        }
        finally{
            if (camera != null){
                camera.stopPreview();
                camera.release();
                camera = null;
            }
        }
    }



    private static String getMaxCpuFreq() {// 获取cpu最大频率
        String max_freq = FileUtil.readOutputFromFile(Constants.cpuinfo_max_freq);
        if(max_freq.isEmpty()){
            return "";
        }
        int res = Integer.valueOf(max_freq) / 1000;
        return String.valueOf(res);

    }

    private static String getMinCpuFreq() {// 获取cpu最小频率
        String min_freq = FileUtil.readOutputFromFile(Constants.cpuinfo_min_freq);
        if(min_freq.isEmpty()){
            return "";
        }
        int res = Integer.valueOf(min_freq) / 1000;
        return String.valueOf(res);
    }

    private static String getCpuModelName() {
        BufferedReader reader = null;
        try {
            String line;
            String modelName = null;
            String hardware = null;
            reader = new BufferedReader(new InputStreamReader(
                    new FileInputStream(new File("/proc/cpuinfo"))), 1024);
            while ((line = reader.readLine()) != null) {
                if (modelName == null && line.startsWith("model name")) {
                    modelName = line;
                    break;
                }
                if (hardware == null && line.startsWith("Hardware")) {
                    hardware = line;
                }
            }
            if (modelName != null) {
                int idx = modelName.indexOf(':');
                if (idx != -1) {
                    return modelName.substring(idx + 1).trim();
                }
            } else if (hardware != null) {
                int idx = hardware.indexOf(':');
                if (idx != -1) {
                    return hardware.substring(idx + 1).trim();
                }
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException ie) {
                    //Log.e(LOG_TAG, ie.getLocalizedMessage(), ie);
                }
            }
        }
        return "";
    }

//    public static String getCpuInfo()// 获取cpu型号
//    {
//        String str1 = "/proc/cpuinfo";
//        String str2 = "";
//        String[] cupinfo = { "", "" };
//        String[] arrayOfString;
//        try {
//            FileReader reader = new FileReader(str1);
//            BufferedReader buffer = new BufferedReader(reader, 8192);
//            str2 = buffer.readLine();
//            arrayOfString = str2.split("\\s+");
//            for (int i = 2; i < arrayOfString.length; i++) {
//                cupinfo[0] = cupinfo[0] + arrayOfString[i] + "";
//            }
//            reader.close();
//            buffer.close();
//        } catch (Exception e) {
//            return "N/A";
//        }
//        return cupinfo[0];
//    }

    public static int getNumCores() {// 获取cpu核心数
        if (cores > 0){
            return cores;
        }
        try {
            int configuredProcessors = (int) SysConf.getScNProcessorsConf(-1);
            if (configuredProcessors < 0){
                File dir = new File("/sys/devices/system/cpu/");
                if (!dir.exists() || !dir.isDirectory()) {
                    return 0;
                }

                File[] cpuFiles = dir.listFiles(
                                new FilenameFilter() {
                                    @Override
                                    public boolean accept(File dir, String name) {
                                        return name.matches("cpu\\d+");
                                    }
                                });
                configuredProcessors = cpuFiles.length;
            }
            cores = configuredProcessors;
            return configuredProcessors;
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
            return 0;
        }
    }

    private static int getNumCoure()// 转换核心数
    {
        int result = 0;
        if (getNumCores() == 1) {
            result = 1;
        } else if (getNumCores() == 2) {
            result = 2;
        } else if (getNumCores() == 4) {
            result = 4;
        } else if (getNumCores() == 8) {
            result = 8;
        }
        else
        {
            result = 0;
        }
        return result;
    }



    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    private static long getBlockSizeData()
    {
        try {
            File path = Environment.getDataDirectory();
            StatFs stat = new StatFs(path.getPath());
            long blockSize = stat.getBlockSizeLong();
            return blockSize;
        }
        catch (NoSuchMethodError error)
        {
            try
            {
                File path = Environment.getDataDirectory();
                StatFs stat = new StatFs(path.getPath());
                long blockSize = (long)stat.getBlockSize();
                return blockSize;
            }
            catch(NoSuchMethodError error1)
            {
                Magnifier.ILOGUTIL.exception(TAG, error1);
            }
        }
        return 0;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    private static long getBlockSizeSDCARD()
    {
        try {
            File path = Environment.getExternalStorageDirectory();
            StatFs stat = new StatFs(path.getPath());
            long blockSize = stat.getBlockSizeLong();
            return blockSize;
        }
        catch (NoSuchMethodError error)
        {
            try
            {
                File path = Environment.getExternalStorageDirectory();
                StatFs stat = new StatFs(path.getPath());
                long blockSize = (long)stat.getBlockSize();
                return blockSize;
            }
            catch(NoSuchMethodError error1)
            {
                Magnifier.ILOGUTIL.exception(TAG, error1);
            }
        }
        return 0;
    }


    private static String getMediaCodec()
    {
        StringBuilder sb = new StringBuilder(50);
        try {
            int numCodecs = MediaCodecList.getCodecCount();
            for (int i = 0; i < numCodecs; i++) {
                MediaCodecInfo codecInfo = MediaCodecList.getCodecInfoAt(i);

                if (!codecInfo.isEncoder()) {
                    continue;
                }
                sb.append(codecInfo.getName()).append(":");
            }
        }
        catch (Exception ex)
        {
            //MediaCodecList mediaCodecList = new MediaCodecList(MediaCodecList.ALL_CODECS);
            //MediaCodecInfo[] mediaCodecInfo = mediaCodecList.getCodecInfos();
            Magnifier.ILOGUTIL.exception(TAG, ex);
        }
        catch (NoClassDefFoundError error)
        {
            Magnifier.ILOGUTIL.exception(TAG, error);
        }
        return sb.toString();
    }


    private static final String getAvailableIOScheduler() {
        String schedulerPath = null;
        if (new File(Constants.available_schedulers).exists()) {
            schedulerPath = Constants.available_schedulers;

        } else if (new File(Constants.available_schedulers_path).exists()) {
            schedulerPath = Constants.available_schedulers_path;
			/*
			 * Some devices don't have mmcblk0 block device so we instead use
			 * mtdblock0 to read the available schedulers
			 */
        } else if (new File(Constants.ioscheduler_mtd).exists()) {
            schedulerPath = Constants.ioscheduler_mtd;
        } else {
            return "";
			/*
			 * need to return an empty string and not a null because the wheel
			 * widget would just crash if a null value is returned
			 */
        }
        String currentScheduler = null;
        String[] schedulers = FileUtil.readOutputFromFile(schedulerPath).split(" ");
        for (String string : schedulers) {
            if (string.contains("[")) {
                currentScheduler = string;
            }
        }
        if (currentScheduler != null) {
            return currentScheduler.substring(1, currentScheduler.length() - 1);
        } else{
            return "";
        }

    }



    private static String getReadAhead() {
        String res = new String("");
        for (int i = 0; i < 2; i++) {
            File device = new File(Constants.available_blockdevices + "mmcblk"
                    + i);
            if (device.exists()) {
                device = new File(Constants.available_blockdevices + "mmcblk"
                        + i + "/queue/read_ahead_kb");
                res = FileUtil.readOutputFromFile(device.getAbsolutePath());
            }
        }
        return res;

    }





    public class Constants {
        public final static String cpufreq_sys_dir = "/sys/devices/system/cpu/cpu0/cpufreq/";
        public final static String scaling_min_freq = cpufreq_sys_dir + "scaling_min_freq";
        public final static String cpuinfo_min_freq = cpufreq_sys_dir + "cpuinfo_min_freq";
        public final static String scaling_max_freq = cpufreq_sys_dir + "scaling_max_freq";

        public final static String cpuinfo_max_freq = cpufreq_sys_dir + "cpuinfo_max_freq";
        public final static String scaling_cur_freq = cpufreq_sys_dir + "scaling_cur_freq";
        public final static String cpuinfo_cur_freq = cpufreq_sys_dir + "cpuinfo_cur_freq";
        public final static String scaling_governor = cpufreq_sys_dir + "scaling_governor";
        public final static String scaling_available_freq = cpufreq_sys_dir + "scaling_available_frequencies";
        public final static String scaling_available_governors = cpufreq_sys_dir + "scaling_available_governors";
        public final static String available_blockdevices = "/sys/block/";
        public final static String available_schedulers = "/sys/block/mmcblk0/queue/scheduler";
        public final static String available_schedulers_path = "/sys/block/mmcblk1/queue/scheduler";
        public static final String time_in_states = "/sys/devices/system/cpu/cpu0/cpufreq/stats/time_in_state";
        public final static String ioscheduler_mtd = "/sys/block/mtdblock0/queue/scheduler";
        public final static String default_recive_window = "/proc/sys/net/core/rmem_default";
        public final static String default_send_window = "/proc/sys/net/core/wmem_default";
        public final static String wlan_mac_address = "/sys/class/net/wlan0/address";
        public final static String eth_mac_address = "/sys/class/net/eth1/address";

    }

}
