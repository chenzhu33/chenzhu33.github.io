package com.tencent.qapmsdk.common;

import com.tencent.qapmsdk.Magnifier;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Created by nickyliu on 2018/12/21.
 */

public class SSLFactory {
    static private final String TAG = "SSLFactory";
    static volatile private SSLSocketFactory sslSocketFactory = null;

    public static SSLSocketFactory getDefaultSSLSocketFactory() {
        if (sslSocketFactory == null){
            synchronized (SSLFactory.class){
                if (sslSocketFactory == null){
                    try {
                        SSLContext sslContext = SSLContext.getInstance("TLS");
                        sslContext.init(null, new TrustManager[]{
                                new X509TrustManager() {
                                    public void checkClientTrusted(
                                            X509Certificate[] x509Certificates,
                                            String s) throws CertificateException {
                                    }

                                    public void checkServerTrusted(
                                            X509Certificate[] x509Certificates,
                                            String s) throws CertificateException {
                                        try {
                                            if (x509Certificates == null ||
                                                    x509Certificates.length == 0 ||
                                                    s == null ||
                                                    s.length() == 0) {
                                                throw new IllegalArgumentException("null or zero-length parameter");
                                            }
                                        }
                                        catch (Exception e) {
                                            throw new CertificateException("error in validating certificate" , e);
                                        }

                                    }

                                    public X509Certificate[] getAcceptedIssuers() {
                                        return new X509Certificate[0];
                                    }
                                }
                        }, null);
                        sslSocketFactory = sslContext.getSocketFactory();
                    } catch (Throwable e) {
                        Magnifier.ILOGUTIL.exception(TAG, e);
                    }
                }
            }

        }
        return sslSocketFactory;

    }
}