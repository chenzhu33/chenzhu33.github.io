package com.tencent.qapmsdk.memory;

import android.app.ActivityManager.RunningAppProcessInfo;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.FileUtil;
import com.tencent.qapmsdk.common.ILogUtil;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * 内存处理
 *
 * @author jinmyshen
 */
public class DumpMemInfoHandler {
    private static final String TAG = ILogUtil.getTAG(DumpMemInfoHandler.class);
    private final static String LOG_PATH = FileUtil.getRootPath() + "/Log/";

    private static final String HeapName[] = new String[]{"NATIVE", "DALVIK", "CURSOR", "ASHMEM", "OTHER_DEV", "SO_MMAP", "JAR_MMAP", "APK_MMAP", "TTF_MMAP", "DEX_MMAP", "OTHER_MMAP", "UNKNOWN"};
    private static final int NATIVE = 0;
    private static final int DALVIK = NATIVE + 1;
    private static final int CURSOR = DALVIK + 1;
    private static final int ASHMEM = CURSOR + 1;
    private static final int OTHER_DEV = ASHMEM + 1;
    private static final int SO_MMAP = OTHER_DEV + 1;
    private static final int JAR_MMAP = SO_MMAP + 1;
    private static final int APK_MMAP = JAR_MMAP + 1;
    private static final int TTF_MMAP = APK_MMAP + 1;
    private static final int DEX_MMAP = TTF_MMAP + 1;
    private static final int OTHER_MMAP = DEX_MMAP + 1;
    private static final int UNKNOWN = OTHER_MMAP + 1;
    private static final int COUNT = UNKNOWN + 1;

    private static boolean sHaveLoadMiniDump = false;
    private static boolean singleton = false;

    static {
        File file = new File(LOG_PATH);
        if (!(file.exists() && file.isDirectory())) {
            file.mkdirs();
        }
    }

    /**
     * 生成hprof文件
     *
     * @param tag
     * @return
     */
//    要避免出现内存泄露、内存触顶同时调用，会出现signal 11的错误
    public static Object[] generateHprof(String tag) {
        boolean success = false;
        String hprofPath = "";
        if (!singleton) {
            synchronized (DumpMemInfoHandler.class) {
                if (!singleton) {
                    singleton = true;
                } else {
                    return new Object[]{success, hprofPath};
                }
            }
        } else {
            return new Object[]{success, hprofPath};
        }

        if (!sHaveLoadMiniDump) {
            if (MiniDumpConfig.getInstance() != null) {
                Magnifier.ILOGUTIL.d(TAG, "minidump load success!");
            } else {
                Magnifier.ILOGUTIL.d(TAG, "minidump load failed!");
            }
        } else {
            Magnifier.ILOGUTIL.d(TAG, "minidump have load");
        }
        sHaveLoadMiniDump = true;

        Magnifier.ILOGUTIL.d(TAG, "ReportLog dumpHprof: ", tag);
        String createTime = getFormatTime(System.currentTimeMillis(), "yy-MM-dd_HH.mm.ss");
        String state = android.os.Environment.getExternalStorageState();
        // 判断SdCard是否存在并且是可用的
        if (android.os.Environment.MEDIA_MOUNTED.equals(state)) {
            File file = new File(LOG_PATH);
            if (!file.exists()) {
                file.mkdirs();
            }
            hprofPath = file.getAbsolutePath();
            if (!hprofPath.endsWith("/")) {
                hprofPath += "/";
            }

            hprofPath += "dump_" + tag + "_" + createTime + ".hprof";
            try {
                android.os.Debug.dumpHprofData(hprofPath);
                success = true;
            } catch (Throwable th) {
                Magnifier.ILOGUTIL.exception(TAG, th);
                singleton = false;
            }
        }
        singleton = false;
        return new Object[]{success, hprofPath};
    }

    @NonNull
    public static String generateThreadTrace() {
        String createTime = getFormatTime(System.currentTimeMillis(), "yy-MM-dd_HH.mm.ss");
        //写进来
        String filename = LOG_PATH + "thread_" + createTime + ".trace";

        int total = Thread.activeCount();
        if (total == 0) {
            return "";
        }

        Thread[] ths = new Thread[total];
        Thread.enumerate(ths);
        StringBuilder sb = new StringBuilder(total * 1024);
        for (int k = 0; k < total; k++) {
            Thread t = ths[k];
            if (t == null)
                continue;
            if (t.isAlive()) {
                sb.append("thread name: ");
                sb.append(t.getName());
                sb.append("\n");
                StackTraceElement[] history = t.getStackTrace();
                if (history != null) {
                    // 暂时只打印堆栈5层
                    for (int i = 0; i < history.length; i++) {
                        // if (i<2)//前2个为系统thread gettrace调用，忽略
                        // continue;
                        // if (i>9)
                        // break;
                        sb.append(" at ");
                        sb.append(history[i].toString());
                        sb.append("\n");
                    }
                }
            }
            sb.append("\n");
        }
        FileWriter fw = null;
        try {
            fw = new FileWriter(filename, false);
            fw.write(sb.toString());
            fw.close();
        } catch (IOException e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        } finally {
            if (fw != null){
                try {
                    fw.close();
                }
                catch (Exception e){
                    Magnifier.ILOGUTIL.exception(TAG, e);
                }
            }
        }
        return filename;
    }

    public static String generateTraces() {
        boolean success = false;
        for (int i = 0; i < 3 && !success; i++) {
            try {
                //先尝试把老的traces.txt删掉
                Runtime.getRuntime().exec("chmod 777 /data/anr");
                Runtime.getRuntime().exec("rm /data/anr/traces.txt");
                //traces.txt
                Runtime.getRuntime().exec("kill -3 " + android.os.Process.myPid());
                success = true;
            } catch (IOException e) {
                Magnifier.ILOGUTIL.e(TAG, "generateTraces exception: ", e.toString());
            }
        }
        return "/data/anr/traces.txt";
    }

    public static String generateDetailMemory(@NonNull RunningAppProcessInfo procInfo, String createTime) {
        try {
            String pidFilePath = "/proc/" + procInfo.pid + "/smaps";

            List<StatFields> statFields = new ArrayList<StatFields>(COUNT);
            List<Map<String, Integer>> detailMemoryTable = new ArrayList<Map<String, Integer>>(COUNT);

            for (int i = 0; i < COUNT; i++) {
                StatFields st = new StatFields();
                Map<String, Integer> detail = new HashMap<String, Integer>();
                statFields.add(st);
                detailMemoryTable.add(detail);
            }
            int pss = readMapinfo(pidFilePath, statFields, detailMemoryTable);

            if (pss > 0) {
                return writeMapinfoToLog(procInfo.processName, statFields, detailMemoryTable, pss, createTime);
            }
            return "";
        } catch (Throwable e) {
            Magnifier.ILOGUTIL.e(TAG, "generateDetailMemory exception: ", e.toString());
            return null;
        }
    }

    private static int readMapinfo(@NonNull String filepath, @NonNull List<StatFields> statFields, @NonNull List<Map<String, Integer>> detailMemoryTable) throws IOException {
        int totalPss = 0;
        int len, nameLen;
        boolean skip, done = false;
        int pss = 0;
        int shared_dirty = 0;
        int private_dirty = 0;
        int temp;
        long start;
        long end = 0;
        long prevEnd = 0;
        String name = "", prevName = "";
        int name_pos;
        int whichHeap = UNKNOWN;
        int prevHeap = UNKNOWN;
        int timeCount = 0;
        File file = null;
        boolean fileExist = false;
        do {
            file = new File(filepath);
            if (file.exists()) {
                fileExist = true;
                break;
            } else {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                }
            }
        } while (timeCount++ < 10);

        if (!fileExist) {
            return 0;
        }

        FileReader fileread = new FileReader(filepath);
        BufferedReader bfr = new BufferedReader(fileread);

        String sLine = bfr.readLine();
        while (!done) {
            prevHeap = whichHeap;
            prevEnd = end;
            whichHeap = UNKNOWN;
            skip = false;

            if (sLine == null) {
                done = true;
                continue;
            }

            len = sLine.length();
            if (len < 1) {
                continue;
            }
            if (sLine.length() > 30 && sLine.charAt(8) == '-' && sLine.charAt(17) == ' ') {
                String[] field = sLine.split(" ");

                String[] addrField = field[0].split("-");
                start = Long.parseLong(addrField[0], 16);
                end = Long.parseLong(addrField[1], 16);

                name_pos = 5;
                while (name_pos < field.length && field[name_pos].equals("")) {
                    name_pos++;
                }
                if (name_pos < field.length) {
                    name = field[name_pos];
                } else {
                    name = "";
                }

                nameLen = name.length();

                if (name.equals("[heap]")) {
                    whichHeap = NATIVE;
                } else if (name.startsWith("/dev/ashmem/dalvik-")) {
                    whichHeap = DALVIK;
                } else if (name.startsWith("/dev/ashmem/CursorWindow")) {
                    whichHeap = CURSOR;
                } else if (name.startsWith("/dev/ashmem/")) {
                    whichHeap = ASHMEM;
                } else if (name.startsWith("/dev/")) {
                    whichHeap = OTHER_DEV;
                } else if (name.endsWith(".so")) {
                    whichHeap = SO_MMAP;
                } else if (name.endsWith(".jar")) {
                    whichHeap = JAR_MMAP;
                } else if (name.endsWith(".apk")) {
                    whichHeap = APK_MMAP;
                } else if (name.endsWith(".ttf")) {
                    whichHeap = TTF_MMAP;
                } else if (name.endsWith(".dex")) {
                    whichHeap = DEX_MMAP;
                } else if (nameLen > 0) {
                    whichHeap = OTHER_MMAP;
                } else if (start == prevEnd && prevHeap == SO_MMAP) {
                    // bss section of a shared library.
                    whichHeap = SO_MMAP;
                    name = prevName;
                }
            } else {
                skip = true;
            }

            while (true) {
                if ((sLine = bfr.readLine()) == null) {
                    done = true;
                    break;
                }

                String[] field = sLine.split(" ");
                String sizeName = field[0];
                temp = 0;
                try {
                    name_pos = 1;
                    while (name_pos < field.length && field[name_pos].equals("")) {
                        name_pos++;
                    }
                    if (name_pos < field.length) {
                        temp = Integer.parseInt(field[name_pos]);
                    } else {
                        temp = 0;
                    }

                } catch (Exception ex) {
                }

                if (sizeName.equals("Size:")) {
                } else if (sizeName.equals("Rss:")) {
                } else if (sizeName.equals("Pss:")) {
                    pss = temp;
                } else if (sizeName.equals("Shared_Clean:")) {
                } else if (sizeName.equals("Shared_Dirty:")) {
                    shared_dirty = temp;
                } else if (sizeName.equals("Private_Clean:")) {
                } else if (sizeName.equals("Private_Dirty:")) {
                    private_dirty = temp;
                } else if (sizeName.equals("Referenced:")) {
                } else if (sLine.length() > 30 && sLine.charAt(8) == '-' && sLine.charAt(17) == ' ') {
                    // looks like a new mapping
                    // example: "10000000-10001000 ---p 10000000 00:00 0"
                    System.out.println(sLine);
                    break;
                }
            }

            if (!skip) {
                prevName = name;
                int index = whichHeap;
                Map<String, Integer> memTable = detailMemoryTable.get(index);
                if (memTable.containsKey(name)) {
                    int tsize = memTable.get(name) + pss;
                    memTable.put(name, tsize);
                } else {
                    memTable.put(name, pss);
                }
                statFields.get(index).pss += pss;
                statFields.get(index).privateDirty += private_dirty;
                statFields.get(index).sharedDirty += shared_dirty;
                totalPss += pss;
            }
        }
        bfr.close();
        return totalPss;
    }

    @Nullable
    private static String writeMapinfoToLog(String procName, List<StatFields> statFields, @NonNull List<Map<String, Integer>> detailMemoryTable, int totalPss, String createTime){
        StringBuffer strBuf = new StringBuffer();
        strBuf.append("\n====== [" + procName + " " + createTime + " smaps begin] =======\n");
        strBuf.append(String.format("TotalPss%8dK\n", totalPss));
        for (int i = 0; i < statFields.size(); i++) {
            strBuf.append(String.format("\n\n%-11s    %dK\n", HeapName[i], statFields.get(i).pss));
            if (detailMemoryTable.get(i).size() > 0) {
                Map.Entry<?, ?>[] set = getSortedHashtableByValue(detailMemoryTable.get(i));
                for (int j = 0; j < set.length; j++) {
                    strBuf.append(String.format("%10dK    %s\n", set[j].getValue(), set[j].getKey()));
                }
            }
        }
        strBuf.append("\n====== [" + procName + " smaps end] =======\n");
        String content = strBuf.toString();
        Magnifier.ILOGUTIL.i(TAG, content);
        String filename = LOG_PATH + "dump_" + getProcFileName(procName) + "_" + createTime + ".smaps";
        BufferedWriter bfr = null;
        try {
            FileWriter filewrite = new FileWriter(filename);
            bfr = new BufferedWriter(filewrite);
            bfr.write(content);
            bfr.close();
        }
        catch (IOException e){
            filename = null;
            Magnifier.ILOGUTIL.exception(TAG, e);
        } finally {
            try {
                if (bfr != null){
                    bfr.close();
                }
            }
            catch (IOException e){
                Magnifier.ILOGUTIL.exception(TAG, e);
            }
        }

        return filename;
    }

    private static String getProcFileName(@Nullable String procName) {
        if (procName == null) {
            return "";
        }
        String[] nameField = procName.split(":");
        String[] fNameArray = nameField[0].split("\\.");
        String outName = fNameArray[fNameArray.length - 1];
        if (nameField.length > 1) {
            outName += "_" + nameField[1];
        }
        return outName;
    }

    /**
     * @param logFiles
     * @param tag
     * @return
     */
    public static Object[] zipFiles(@NonNull List<String> logFiles, String tag) {
        String createTime = getFormatTime(System.currentTimeMillis(), "yy-MM-dd_HH.mm.ss");
        String compressFilePath = LOG_PATH + "dump_" + tag + "_" + createTime + ".zip";
        boolean success = FileUtil.zipFiles(logFiles, compressFilePath);
        return new Object[]{success, compressFilePath};
    }

    /**
     * 方法名称：getSortedHashtable
     * 参数：Hashtable h 引入被处理的散列表
     * 描述：将引入的hashtable.entrySet进行排序，并返回
     */
    @NonNull
    private static Map.Entry<?, ?>[] getSortedHashtableByValue(Map<?, ?> h) {
        Set<?> set = h.entrySet();
        Map.Entry<?, ?>[] entries = (Map.Entry[]) set.toArray(new Map.Entry[set.size()]);
        Arrays.sort(entries, new Comparator<Object>() {

            @Override
            public int compare(@NonNull Object arg0, @NonNull Object arg1) {
                int value1 = (Integer) ((Map.Entry<?, ?>) arg0).getValue();
                int value2 = (Integer) ((Map.Entry<?, ?>) arg1).getValue();
                if (value1 == value2) {
                    return 0;
                } else if (value1 < value2) {
                    return 2;
                } else {
                    return -1;
                }
            }
        });
        return entries;
    }

    @SuppressWarnings("unused")
    private static class StatFields {
        private long pss;
        long privateDirty;
        long sharedDirty;
    }

    private static String getFormatTime(long time, @NonNull String format) {
        if (time <= 0) {
            return null;
        }
        Date data = new Date(time);
        SimpleDateFormat dateformat1 = new SimpleDateFormat(format, Locale.US);
        return dateformat1.format(data);
    }
}