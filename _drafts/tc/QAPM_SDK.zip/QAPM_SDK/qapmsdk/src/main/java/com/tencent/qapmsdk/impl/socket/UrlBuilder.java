package com.tencent.qapmsdk.impl.socket;

public class UrlBuilder {
    private String hostAddress;
    private String hostname;
    private String httpPath = "/";
    private Scheme scheme = null;
    private int hostPort = -1;
    private boolean directConnect = false;


    public UrlBuilder() {
    }

    public String getHostAddress() {
        return this.hostAddress;
    }

    public String getHostname() {
        return this.hostname;
    }

    public int getHostPort() {
        return this.hostPort;
    }

    public void setHostPort(int hostPort) {
        if (hostPort > 0) {
            this.hostPort = hostPort;
        }

    }

    public void setDirectConnect(boolean directConnect) {
        this.directConnect = directConnect;
    }

    public void setHostAddress(String var1) {
        this.hostAddress = var1;
    }

    public void setHostname(String var1) {
        this.hostname = var1;
    }

    public void setHttpPath(String var1) {
        if (var1 != null) {
            this.httpPath = var1;
        }

    }

    public String getHttpPath() {
        return this.httpPath;
    }

    public void setScheme(Scheme scheme) {
        this.scheme = scheme;
    }

    public Scheme getScheme() {
        return this.scheme;
    }

    private String getHostNameWithDefault() {
        String hostname = "unknown-host";
        if (this.hostname != null) {
            hostname = this.hostname;
        }

        return hostname;
    }

    public boolean checkScheme(String url) {
        return url != null && (url.regionMatches(true, 0, "http:", 0, 5) || url.regionMatches(true, 0, "https:", 0, 6));
    }

    public String getUrl() {
        String hostNameWithDefault = this.getHostNameWithDefault();
        if (this.directConnect) {
            return this.getUrl(hostNameWithDefault, this.hostPort);
        } else {
            String httpPath = this.httpPath;
            String schemeInfo = "";
            if (this.checkScheme(httpPath)) {
                return httpPath;
            } else {
                if (this.scheme != null) {
                    schemeInfo = schemeInfo + this.scheme.name + ":";
                }

                if (httpPath.startsWith("//")) {
                    return schemeInfo + httpPath;
                } else {
                    schemeInfo = schemeInfo + "//";
                    if (httpPath.startsWith(hostNameWithDefault)) {
                        return schemeInfo + httpPath;
                    } else {
                        String portInfo = "";
                        if (this.hostPort > 0 && (this.scheme == null || this.scheme.port != this.hostPort)) {
                            String port = ":" + this.hostPort;
                            if (!hostNameWithDefault.endsWith(port)) {
                                portInfo = port;
                            }
                        }

                        return schemeInfo + hostNameWithDefault + portInfo + httpPath;
                    }
                }
            }
        }
    }

    private String getUrl(String url, int port) {
        if (port > 0) {
            String end = ":" + port;
            if (!url.endsWith(end)) {
                return url + end;
            }
        }

        return url;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("hostAddress: " + this.hostAddress);
        sb.append("hostname: " + this.hostname);
        sb.append("httpPath: " + this.httpPath);
        sb.append("scheme: " + this.scheme);
        sb.append("hostPort: " + this.hostPort);
        return sb.toString();
    }

    public static enum Scheme {
        HTTP("http", 80),
        HTTPS("https", 443);

        private String name;
        private int port;

        private Scheme(String name, int port) {
            this.name = name;
            this.port = port;
        }

        public String getName() {
            return this.name;
        }

        public int getPort() {
            return this.port;
        }
    }

}
