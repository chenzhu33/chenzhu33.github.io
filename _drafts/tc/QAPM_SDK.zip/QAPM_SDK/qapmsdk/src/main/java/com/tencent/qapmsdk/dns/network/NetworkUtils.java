package com.tencent.qapmsdk.dns.network;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;

public class NetworkUtils {

    private static final String TAG = "QAPM_DNS_NetworkUtils";

    private static WifiManager sWifiManager;

    private static ConnectivityManager sConnectivityManager;

    enum NetworkType {
        DISCONNECTED,
        MOBILE,
        WIFI,
        OTHER;
    }

    public static void init(Context context) {
        if (sWifiManager == null) {
            try {
                sWifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            } catch (Exception ignored) {
                // 在某些Android 5.0/6.0手机上会抛NPE
                Magnifier.ILOGUTIL.exception(TAG, "get WifiManager failed", ignored);
            }
        }
        if (sConnectivityManager == null) {
            try {
                sConnectivityManager = (ConnectivityManager) context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            } catch (Exception ignored) {
                // java.lang.NullPointerException:missing IConnectivityManager
                // 某些旧系统会抛异常
                Magnifier.ILOGUTIL.exception(TAG, "get ConnectivityManager failed", ignored);
            }
        }
    }

    public static NetworkType getActiveNetworkType() {
        final ConnectivityManager cm;
        final NetworkInfo info;
        final int type;
        try {
            cm = sConnectivityManager;
            info = cm.getActiveNetworkInfo();
            if (!info.isConnected()) return NetworkType.DISCONNECTED;
            type = info.getType();
        } catch (Exception e) {
            // 无连接
            return NetworkType.DISCONNECTED;
        }
        if (type == ConnectivityManager.TYPE_WIFI) {
            // wifi
            return NetworkType.WIFI;
        } else if (type == ConnectivityManager.TYPE_MOBILE) {
            // mobiile
            return NetworkType.MOBILE;
        } else {
            return NetworkType.OTHER;
        }
    }

    public static boolean isWifi() {
        return getActiveNetworkType() == NetworkType.WIFI;
    }

    public static String getWifiSsid() {
        String ssid = null;
        if (isWifi()) {
            final WifiManager wifiManager = sWifiManager;
            WifiInfo wifiInfo;
            try {
                wifiInfo = wifiManager.getConnectionInfo();
                ssid = wifiInfo.getSSID();
            } catch (Throwable ignored) {
            }
        }
        return ssid;
    }

    public static boolean isValidSSID(String ssid) {
        return !TextUtils.isEmpty(ssid) && !"<unknown ssid>".equals(ssid);
    }
}
