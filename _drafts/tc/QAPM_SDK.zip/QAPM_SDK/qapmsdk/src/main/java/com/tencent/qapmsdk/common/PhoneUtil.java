package com.tencent.qapmsdk.common;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.Application;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Debug;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.SparseArray;
import android.widget.TextView;

import com.tencent.qapmsdk.Magnifier;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class PhoneUtil {
    private static final String TAG = ILogUtil.getTAG(PhoneUtil.class);
    private static SparseArray<String> mProcessMap = new SparseArray<String>();
    public static String getProcessName(Context ctx) {
        int pid = android.os.Process.myPid();
        String procName = mProcessMap.get(pid);
        if (procName != null) {
            return procName;
        }
        BufferedReader cmdlineReader = null;
        try {
            cmdlineReader = new BufferedReader(new InputStreamReader(new FileInputStream("/proc/" + pid + "/cmdline"), "iso-8859-1"));
            int c;
            StringBuilder processName = new StringBuilder(128);
            while ((c = cmdlineReader.read()) > 0) {
                processName.append((char) c);
            }
            procName = processName.toString();
            mProcessMap.put(pid, procName);
            return procName;
        } catch (Exception e) {
        } finally {
            if (cmdlineReader != null) {
                try {
                    cmdlineReader.close();
                } catch (IOException e) {
                    Magnifier.ILOGUTIL.exception(TAG, e);
                }
            }
        }
        if (ctx != null) {
            ActivityManager manager = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            List<RunningAppProcessInfo> procList = manager.getRunningAppProcesses();
            if (procList != null && procList.size() > 0) {
                for (RunningAppProcessInfo processInfo : manager.getRunningAppProcesses()) {
                    if (processInfo.pid == pid) {
                        procName = processInfo.processName;
                        mProcessMap.put(pid, procName);
                        break;
                    }
                }
            }
        }
        return procName;
    }

    public static ComponentName getActiveComponent(Context ctx) {
        ActivityManager am;
        try {
            am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
            return null;
        }
        List<ActivityManager.RunningAppProcessInfo> runningProcesses = am.getRunningAppProcesses();
        if (null == runningProcesses){
            return null;
        }
        for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses) {
            if (processInfo.importance != ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                continue;
            }
            for (String activeProcess : processInfo.pkgList) {
                if (activeProcess.equals(ctx.getPackageName()) && processInfo.importanceReasonComponent != null) {
                    ComponentName component = processInfo.importanceReasonComponent;
                    return component;
                }
            }
        }
        return null;
    }

    private static Object[] hasPermissions(Application app, String[] permissionList) {
        if (app == null) return new Object[]{ false, "app == null" };
        PackageManager pm = app.getPackageManager();
        if (pm == null) return new Object[]{ false, "pm == null" };
        String pkgName = app.getPackageName();
        boolean hasPermission;
        synchronized (PhoneUtil.class) {
            for (String permission : permissionList) {
                try {
                    // 可能发生Package manager has died，因此改为单线程。
                    hasPermission = (PackageManager.PERMISSION_GRANTED == pm.checkPermission(permission, pkgName));
                } catch (Throwable t) {
                    hasPermission = false;
                }
                if (!hasPermission) return new Object[]{ false, permission };
            }
            return new Object[]{ true, "" };
        }
    }
    
    private static int checkReadPhoneStateFlag = -1;
    private static boolean hasReadPhoneStateFlag(Application app) {
        if (checkReadPhoneStateFlag == -1) {
            String[] ps = {"android.permission.READ_PHONE_STATE"};
            Object[] result = hasPermissions(app, ps);
            boolean hasPermission = (Boolean) result[0];
            if (hasPermission) checkReadPhoneStateFlag = 1;
            else checkReadPhoneStateFlag = 0;
            return hasPermission;
        } else {
            return checkReadPhoneStateFlag > 0;
        }
    }

    private static String deviceId = "";
    public static String getDeviceId(Application app) {
        //私有云专用，用来单独处理
        if (!TextUtils.isEmpty(Magnifier.info.deviceId)){
            return Magnifier.info.deviceId;
        }
        if (!TextUtils.isEmpty(deviceId)) {
            return deviceId;
        }
        String tempId = "";
        Context context = app.getApplicationContext();
        String Manu = android.os.Build.BRAND;
        String Model = android.os.Build.MODEL;
        String macAddress = DeviceInfo.getMacAddr(context);
        if (TextUtils.isEmpty(macAddress)){
            macAddress = "";
        }
        String androidId = "";
        try {
            androidId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        }
        catch (Throwable t){
            androidId = "";
        }
        String imei = "";
        try {
            imei = ((TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE)).getDeviceId();
        } catch (SecurityException e) {
            imei = "0";
        } catch (Throwable t){
            imei = "0";
        }
        tempId = Manu + Model + androidId + macAddress + imei;

        deviceId = MD5Util.getMD5(tempId);
        return deviceId;
    }
    
    public static long getMemory(int pid) {
        try {
            ActivityManager aManager = (ActivityManager) Magnifier.sApp.getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
            int[] pids = new int[] { pid };
            Debug.MemoryInfo[] myMemoryInfo = aManager.getProcessMemoryInfo(pids);
            if (myMemoryInfo != null && myMemoryInfo.length > 0) {
                return (long)myMemoryInfo[0].getTotalPss() * 1024;
            }
        } catch (Exception ex) {
        }
        return 60 * 1024 * 1024;
    }
    
    private static final String[] permissionsNeeded = {"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"};
    public static Object[] hasAllPermissions(Application app) {
        return hasPermissions(app, permissionsNeeded);
    }
}