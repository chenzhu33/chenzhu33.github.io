package com.tencent.qapmsdk.reporter;

import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.config.CollectStatus.CurrentRecord;
import com.tencent.qapmsdk.persist.DBHandler.Status;
import com.tencent.qapmsdk.persist.DBHelper;
import com.tencent.qapmsdk.reporter.IReporter.ReportResultCallback;
import com.tencent.qapmsdk.common.FileUtil;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.NetworkWatcher;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.common.ThreadManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * 项目名称：MagnifierAndroidSDK
 * 类描述：上报器整个入口
 * 创建人：janksenhu janksen@foxmail.com
 * 创建时间：2016/2/18 17:04
 * 修改人：janksenhu
 * 修改时间：2016/2/18 17:04
 * 修改备注：
 */
public class ReporterMachine {
    private static final String TAG = ILogUtil.getTAG(ReporterMachine.class);
    public static final int SOCKET_TIMEOUT_MILLI = 30000;
    static final int ERROR_OOM = 600;
    static final int ERROR_TIMEOUT = ERROR_OOM + 1;
    static final int ERROR_OTHER = 700;
    static final String PREFIX_KEY_OF_FILE = "fileObj";

    @Nullable
    private volatile static ReporterMachine rm = null;
    @Nullable
    private static IReporter QCloud_Reporter = null;
    @Nullable
    private static Handler mHandler;

    public static boolean report_flag = false;
    @NonNull
    private static Queue<String> deleteQueue = new ConcurrentLinkedQueue<>();
    private static boolean isStarted = false;
    private static final int cacheSize = 120;
    @NonNull
    private static List<ResultObject> objCache = new ArrayList<>(cacheSize);
    
    private ReporterMachine() {
        mHandler = new Handler(ThreadManager.getReporterThreadLooper());
        QCloud_Reporter = new QCloudReporter();
    }

    @Nullable
    public static ReporterMachine getInstance() {
        if (null == rm) {
            synchronized (ReporterMachine.class) {
                if (null == rm){
                    rm = new ReporterMachine();
                }
            }
        }
        return rm;
    }

    private static void reportAtOnce(ResultObject resObj, final ReportResultCallback callback) throws JSONException {
        int plugin = resObj.params.getInt("plugin");
        if (Config.OtherPlugins.contains(plugin)) {
            if (CollectStatus.sample_reported > Config.MAX_RESOURCE_REPORT_NUM) return;
        } else {
            if (CollectStatus.reported > Config.MAX_REPORT_NUM) return;
        }

        resObj.params.put("p_id", Magnifier.productId);
        resObj.params.put("version", Magnifier.info.version);
        resObj.params.put("uin", resObj.uin);
        resObj.params.put("manu", Build.MANUFACTURER);
        resObj.params.put("device", Build.MODEL);
        resObj.params.put("os", Build.VERSION.RELEASE);
        resObj.params.put("rdmuuid", Magnifier.info.uuid);
        resObj.params.put("deviceid", PhoneUtil.getDeviceId(Magnifier.sApp));
        
        if (QCloud_Reporter != null) {
            QCloud_Reporter.report(resObj, new ReportResultCallback() {
                @Override
                public void onSuccess(int id) {
                    if (callback != null){
                        callback.onSuccess(id);
                    }
                    Magnifier.dbHandler.update(DBHelper.TABLE_RESULT_OBJECTS, id, Status.SENT);
                }

                @Override
                public void onFailure(int plugin, long uploadtime, int error_code, String error_msg, String http_get) {
                    if (callback != null){
                        callback.onFailure(plugin, uploadtime, error_code, error_msg, http_get);
                    }
                }
            });
        }
        if (Config.OtherPlugins.contains(plugin)) {
            CollectStatus.sample_reported++;
            if (CollectStatus.sample_reported % 5 == 0 && Magnifier.editor != null) {
                Magnifier.editor.putInt(CollectStatus.KEY_COUNT_TODAY_SAMPLE_REPORTED, CollectStatus.sample_reported).commit();
            }
        } else {
            CollectStatus.reported++;
            if (CollectStatus.reported % 10 == 0 && Magnifier.editor != null) {
                Magnifier.editor.putInt(CollectStatus.KEY_COUNT_TODAY_REPORTED, CollectStatus.reported).commit();
            }
        }
    }

    private static class InsertRunnable implements Runnable {
        private ResultObject resObj;

        public InsertRunnable(ResultObject ro) {
            resObj = ro;
        }

        @Override
        public void run() {
            if (Magnifier.dbHandler != null) {
                Magnifier.dbHandler.insertResultObject(resObj, PhoneUtil.getProcessName(Magnifier.sApp), Magnifier.productId, Magnifier.info.version);
            }
        }
    }

    public static void addResultObj(ResultObject resObj, final ReportResultCallback callback) {
        if (resObj.isRealTime && NetworkWatcher.isWifiAvailable()) {
            try {
                reportAtOnce(resObj, callback);
            } catch (Exception e) {
                Magnifier.ILOGUTIL.exception(TAG, e);
            }
        } else if (mHandler != null) {
            InsertRunnable ir = new InsertRunnable(resObj);
            mHandler.post(ir);
        } else {
            addCacheObj(resObj);
        }
    }

    public static void addResultObj(ResultObject resObj) {
        addResultObj(resObj, null);
    }

    public static void addCacheObj(ResultObject resObj) {
        synchronized (ReporterMachine.class) {
            //不对cache做扩容
            if (objCache.size() < cacheSize){
                objCache.add(resObj);
            }

        }
    }

    public static void clearCachObj(int plugin){
        Iterator<ResultObject> resIterator = objCache.iterator();
        while (resIterator.hasNext()) {
            try {
                int resPlugin = resIterator.next().params.getInt("plugin");
                if (resPlugin == plugin){
                    resIterator.remove();
                }
            }
            catch (Exception e) {
                Magnifier.ILOGUTIL.exception(TAG, e);
            }
        }
    }

    private class ReportRunnable implements Runnable {
        private static final int DELAY_NEXT_ITEM = 500;
        private static final int DELAY_NEXT_TRY = 2 * 60 * 60 * 1000;
        private List<ResultObject> roList;
        private int listIndex = 0;

        @Override
        public void run() {
            if (CollectStatus.reported > Config.MAX_REPORT_NUM) {
                Magnifier.ILOGUTIL.i(TAG, "[YunYingReport]:End, reported ", String.valueOf(CollectStatus.reported), " max_report_num ", String.valueOf(Config.MAX_REPORT_NUM));
                if (Magnifier.dbHandler != null) {
                    Magnifier.dbHandler.clearResultObjects();
                }
                if (Magnifier.editor != null) {
                    Magnifier.editor.putInt(CollectStatus.KEY_COUNT_TODAY_REPORTED, CollectStatus.reported).commit();
                }
                return;
            } else if (Magnifier.dbHandler == null || NetworkWatcher.isWifiAvailable() == false) {
                Magnifier.ILOGUTIL.i(TAG, "[YunYingReport]:Next try, because Magnifier.dbHandler == null || NetworkWatcher.isWifiAvailable() == false");
                mHandler.postDelayed(this, DELAY_NEXT_TRY);
            } else if (roList != null && !roList.isEmpty()) {
                try {
                    ResultObject resObj = roList.get(listIndex);
                    reportAtOnce(resObj, null);
                } catch (Exception e) {
                }
                listIndex = listIndex + 1;
                if (listIndex < roList.size()) {
                    mHandler.postDelayed(this, DELAY_NEXT_ITEM);
                } else {
                    Magnifier.dbHandler.deleteAllSentOrOvertime(DBHelper.TABLE_RESULT_OBJECTS, true);
                    if (roList != null && roList.size() > 0)
                        roList.clear();
                    listIndex = 0;
                    mHandler.postDelayed(this, DELAY_NEXT_TRY);
                    
                    // synchronize CurrentRecord to shared preference
                    int size = CollectStatus.mRecord.size();
                    if (Magnifier.editor != null) {
                        for (int index = 0; index < size; index++) {
                            int key = CollectStatus.mRecord.keyAt(index);
                            if (key > 100) {
                                CurrentRecord cr = CollectStatus.mRecord.get(key);
                                if (cr == null) continue;
                                Magnifier.editor.putInt(CollectStatus.KEY_COUNT_PLUGIN_PREFIX + String.valueOf(key), cr.mCollectCount);
                            }
                        }
                        //apply会将等待时间转嫁到主线程，导致anr
                        Magnifier.editor.commit();
                    }
                }
            } else {
                roList = Magnifier.dbHandler.getAllResultObjects(PhoneUtil.getProcessName(Magnifier.sApp), Magnifier.productId, Magnifier.info.version, true);
                if (!objCache.isEmpty()) {
                    roList.addAll(objCache);
                    objCache.clear();
                }
                listIndex = 0;
                if (roList == null || roList.isEmpty()) {
                    // delete files already sent
                    for (String log : deleteQueue) {
                        try {
                            File logDir = new File(log);
                            if (logDir != null && logDir.isFile()) {
                                logDir.delete();
                            }
                        } catch (Exception e) {}
                    }
                    deleteQueue.clear();
                    mHandler.postDelayed(this, DELAY_NEXT_TRY);
                } else {
                    mHandler.postDelayed(this, DELAY_NEXT_ITEM);
                }
            }
        }
    }
    
    private static class getFileRunnable implements Runnable {
        @NonNull
        List<String> logFileList = new ArrayList<String>(3);
        
        public getFileRunnable() {
            String logPath1= "/Log/";
            String logPath2= "/dumpfile/";
            String logPath3= "/battery/";
            logFileList.add(FileUtil.getRootPath() + logPath1);
            logFileList.add(FileUtil.getRootPath() + logPath2);
            logFileList.add(FileUtil.getRootPath() + logPath3);
        }
        
        @Override
        public void run() {
            for (String log : logFileList) {
                File logDir = new File(log);
                if (logDir != null && logDir.exists() && logDir.isDirectory()) {
                    File[] files = logDir.listFiles();
                    if (files == null)
                        continue;
                    for (int i = 0; i < files.length; i++) {
                        String path = files[i].getPath();
                        if (path.contains(".txt") || path.contains(".zip")) { //避免处理到一些原始监控文件
                            try {
                                deleteQueue.add(path);
                            } catch (Exception e) {}
                        }
                    }
                }
            }
        }
    }

    private static class ReportCacheRunnable implements Runnable {
        private final String[] keys = {"p_id", "versionname", "uin", "manu", "model",
                "os", "rdmuuid", "deviceid", "api_ver", "device", "zone",
                "plugin", "plugin_ver", "client_identify"};
        @NonNull
        private List<String> keysList = Arrays.asList(keys);

        @Override
        public void run() {
            if (!objCache.isEmpty() && isStarted) {
                HashMap<String, ResultObject> eventMap = new HashMap<String, ResultObject>();
                synchronized (ReporterMachine.class) {
                    for (ResultObject obj : objCache) {
                        try {
                            String eventName = obj.eventName;
                            if (eventMap.containsKey(eventName)) {
                                JSONObject tempObj = obj.params;
                                JSONObject joInfo = new JSONObject();
                                JSONArray ja = eventMap.get(eventName).params.getJSONArray("metrics");
                                for (Iterator<String> interKey = tempObj.keys(); interKey.hasNext();) {
                                    String keyString = interKey.next();
                                    if (!keysList.contains(keyString)) {
                                        joInfo.put(keyString, tempObj.get(keyString));
                                    }
                                }
                                ja.put(joInfo);
                            } else {
                                JSONObject jo = new JSONObject();
                                JSONObject joInfo = new JSONObject();
                                JSONArray ja = new JSONArray();
                                JSONObject tempObj = obj.params;
                                for (Iterator<String> interKey = tempObj.keys(); interKey.hasNext();) {
                                    String keyString = interKey.next();
                                    if (keysList.contains(keyString)) {
                                        if (keyString.equals("plugin") && (tempObj.getInt(keyString) == 132 || tempObj.getInt(keyString) == 130)){
                                            jo.put(keyString, Config.VER_TYPE == 0 ? 132 : 130);
                                        }
                                        else {
                                            jo.put(keyString, tempObj.get(keyString));
                                        }
                                    } else {
                                        joInfo.put(keyString, tempObj.get(keyString));
                                    }
                                }
                                ja.put(joInfo);
                                jo.put("metrics", ja);
                                if (obj.params.has("plugin")) {
                                    if (obj.params.getInt("plugin") == 132 || obj.params.getInt("plugin") == 130){
                                        jo.put("plugin", Config.VER_TYPE == 0 ? 132 : 130);
                                    }
                                    else{
                                        jo.put("plugin", obj.params.getInt("plugin"));
                                    }
                                }
                                ResultObject ro = new ResultObject(
                                        obj.reportType,
                                        obj.eventName,
                                        obj.isSucceed,
                                        obj.elapse,
                                        obj.size,
                                        jo,
                                        obj.isRealTime,
                                        obj.isMerge,
                                        obj.uin);
                                eventMap.put(eventName, ro);
                            }
                        } catch (Exception e) {
                            Magnifier.ILOGUTIL.e(TAG, e.getMessage());
                        }
                    }
                    try {
                        for(String eventmap : eventMap.keySet()) {
                            reportAtOnce(eventMap.get(eventmap), null);
                        }
                    } catch (Exception e) {
                        Magnifier.ILOGUTIL.e(TAG, e.getMessage());
                    }
                    synchronized (ReporterMachine.class) {
                        ReporterMachine.report_flag = false;
                    }
                    eventMap.clear();
                    objCache.clear();
                }
            }
        }
    }

    /**
     * 启动上报
     * @return
     */
    public void startMachine() {
        if (!isStarted) {
            synchronized (this) {
                if (!isStarted && mHandler != null) {
                    ReportRunnable rr = new ReportRunnable();
                    getFileRunnable rFile = new getFileRunnable();
                    mHandler.postDelayed(rFile, 2 * 60 * 1000);
                    mHandler.postDelayed(rr, 5 * 60 * 1000);
                    isStarted = true;
                }
            }
        }
    }

    /**
     * 用于单元测试，即时上报
     */
    public static void startCacheReportAtOnce() {
        isStarted = true;
        ReportCacheRunnable cr = new ReportCacheRunnable();
        cr.run();
    }

    public static void startCacheReport() {
        if (mHandler != null) {
            ReportCacheRunnable cr = new ReportCacheRunnable();
            mHandler.postDelayed(cr, Config.VER_TYPE == 0 ? 120 * 1000 : 30 * 1000);
        }
        else{
            report_flag = false;
        }
    }
}