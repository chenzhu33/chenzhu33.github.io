package com.tencent.qapmsdk.impl.instrumentation;

import android.text.TextUtils;

import com.avos.avoscloud.LogUtil;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.api.data.TransactionData;
import com.tencent.qapmsdk.impl.harvest.HttpLibType;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMCountingInputStream;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMCountingOutputStream;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMStreamCompleteEvent;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMStreamCompleteListener;
import com.tencent.qapmsdk.impl.model.HttpDataModel;
import com.tencent.qapmsdk.impl.util.StringUtil;
import com.tencent.qapmsdk.impl.util.TraceUtil;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.security.Permission;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class QAPMHttpURLConnectionExtension extends HttpURLConnection {
    private final static String TAG = "QAPM_Impl_QAPMHttpURLConnectionExtension";
    private HttpURLConnection impl;
    private QAPMTransactionState transactionState;
    QAPMCountingInputStream qapmCountingInputStream;

    public QAPMHttpURLConnectionExtension(HttpURLConnection impl) {
        super(impl.getURL());
        this.impl = impl;
        this.getTransactionState();
        if (impl != null && TraceUtil.getCanMonitorHttp()) {
            this.getTransactionState();
            this.transactionState.setAppPhase(0);
//            QAPMTransactionStateUtil.setCrossProcessHeader(impl);
        }

    }

    public void addRequestProperty(String field, String newValue) {
        this.impl.addRequestProperty(field, newValue);
    }

    public void disconnect() {
        if (this.transactionState != null && !this.transactionState.isComplete()) {
            this.addTransactionAndErrorData(this.transactionState);
        }

        this.impl.disconnect();
    }

    public boolean usingProxy() {
        return this.impl.usingProxy();
    }

    public void connect() throws IOException {
        this.getTransactionState();

        try {
            this.impl.connect();
        } catch (IOException e) {
            this.error(e);
            throw e;
        }
    }

    public boolean getAllowUserInteraction() {
        return this.impl.getAllowUserInteraction();
    }

    public int getConnectTimeout() {
        return this.impl.getConnectTimeout();
    }

    public Object getContent() throws IOException {
        this.getTransactionState();

        Object obj;
        try {
            obj = this.impl.getContent();
        } catch (IOException e) {
            this.error(e);
            throw e;
        }

        int contentLength = this.impl.getContentLength();
        if (contentLength >= 0) {
            QAPMTransactionState qapmTransactionState = this.getTransactionState();
            if (!qapmTransactionState.isComplete()) {
                qapmTransactionState.setBytesReceived((long)contentLength);
                this.addTransactionAndErrorData(qapmTransactionState);
            }
        }

        return obj;
    }

    public Object getContent(Class[] types) throws IOException {
        this.getTransactionState();

        Object obj;
        try {
            obj = this.impl.getContent(types);
        } catch (IOException e) {
            this.error(e);
            throw e;
        }

        this.checkResponse();
        return obj;
    }

    public String getContentEncoding() {
        this.getTransactionState();
        String contentEncoding = this.impl.getContentEncoding();
        this.checkResponse();
        return contentEncoding;
    }

    public int getContentLength() {
        this.getTransactionState();
        int contentLength = this.impl.getContentLength();
        this.checkResponse();
        return contentLength;
    }

    public String getContentType() {
        this.getTransactionState();
        String contentType = this.impl.getContentType();
        this.checkResponse();
        return contentType;
    }

    public long getDate() {
        this.getTransactionState();
        long date = this.impl.getDate();
        this.checkResponse();
        return date;
    }

    public long getHeaderFieldDate(String field, long defaultValue) {
        this.getTransactionState();
        long headerFieldDate = this.impl.getHeaderFieldDate(field, defaultValue);
        this.checkResponse();
        return headerFieldDate;
    }

    public boolean getInstanceFollowRedirects() {
        return this.impl.getInstanceFollowRedirects();
    }

    public Permission getPermission() throws IOException {
        return this.impl.getPermission();
    }

    public String getRequestMethod() {
        QAPMTransactionState qapmTransactionState = this.getTransactionState();
        String requestMethod = this.impl.getRequestMethod();
        QAPMTransactionStateUtil.setRequestMethod(qapmTransactionState, requestMethod);
        this.transactionState.setHttpLibType(HttpLibType.URLConnection);
        return requestMethod;
    }

    public int getResponseCode() throws IOException {
        this.getTransactionState();

        int responseCode;
        try {
            responseCode = this.impl.getResponseCode();
        } catch (IOException e) {
            this.error(e);
            throw e;
        }

        this.checkResponse();
        return responseCode;
    }

    public String getResponseMessage() throws IOException {
        this.getTransactionState();

        String responseMessage;
        try {
            responseMessage = this.impl.getResponseMessage();
        } catch (IOException e) {
            this.error(e);
            throw e;
        }

        this.checkResponse();
        return responseMessage;
    }

    public void setChunkedStreamingMode(int chunkLength) {
        this.impl.setChunkedStreamingMode(chunkLength);
    }

    public void setFixedLengthStreamingMode(int contentLength) {
        this.impl.setFixedLengthStreamingMode(contentLength);
    }

    public void setInstanceFollowRedirects(boolean followRedirects) {
        this.impl.setInstanceFollowRedirects(followRedirects);
    }

    public void setRequestMethod(String method) throws ProtocolException {
        this.getTransactionState();

        try {
            this.impl.setRequestMethod(method);
            this.transactionState.setMethodType(method);
            this.transactionState.setHttpLibType(HttpLibType.URLConnection);
            QAPMTransactionStateUtil.setRequestMethod(this.getTransactionState(), method);
        } catch (ProtocolException e) {
            this.error(e);
            throw e;
        }
    }

    public boolean getDefaultUseCaches() {
        return this.impl.getDefaultUseCaches();
    }

    public boolean getDoInput() {
        return this.impl.getDoInput();
    }

    public boolean getDoOutput() {
        return this.impl.getDoOutput();
    }

    public long getExpiration() {
        this.getTransactionState();
        long expiration = this.impl.getExpiration();
        this.checkResponse();
        return expiration;
    }

    public String getHeaderField(int pos) {
        this.getTransactionState();
        String headerField = this.impl.getHeaderField(pos);
        this.checkResponse();
        return headerField;
    }

    public String getHeaderField(String key) {
        this.getTransactionState();
        String headerField = this.impl.getHeaderField(key);
        this.checkResponse();
        return headerField;
    }

    public int getHeaderFieldInt(String field, int defaultValue) {
        this.getTransactionState();
        int headerFieldInt = this.impl.getHeaderFieldInt(field, defaultValue);
        this.checkResponse();
        return headerFieldInt;
    }

    public String getHeaderFieldKey(int posn) {
        this.getTransactionState();
        String headerFieldKey = this.impl.getHeaderFieldKey(posn);
        this.checkResponse();
        return headerFieldKey;
    }

    public Map<String, List<String>> getHeaderFields() {
        this.getTransactionState();
        Map headerFields = this.impl.getHeaderFields();
        this.checkResponse();
        return headerFields;
    }

    public long getIfModifiedSince() {
        this.getTransactionState();
        long ifModifiedSince = this.impl.getIfModifiedSince();
        this.checkResponse();
        return ifModifiedSince;
    }

    public InputStream getInputStream() throws IOException {
        final QAPMTransactionState state = this.getTransactionState();
        QAPMCountingInputStream inputStream = null;

        try {
            inputStream = new QAPMCountingInputStream(this.impl.getInputStream());
            QAPMTransactionStateUtil.inspectAndInstrumentResponse(state, this.impl);
        } catch (IOException e) {
            this.error(e);
            throw e;
        }

        if (inputStream != null) {
            inputStream.addStreamCompleteListener(new QAPMStreamCompleteListener() {
                public void streamError(QAPMStreamCompleteEvent e) {
                    Magnifier.ILOGUTIL.e(TAG, "streamError:" , e.toString());
                    if (!state.isComplete()) {
                        state.setBytesReceived(e.getBytes());
                    }

                    try {
                        int responseCode = QAPMHttpURLConnectionExtension.this.impl.getResponseCode();
                        state.setStatusCode(responseCode);
                    } catch (IOException e1) {
                    }

                    QAPMHttpURLConnectionExtension.this.error(e.getException());
                }

                public void streamComplete(QAPMStreamCompleteEvent e) {
                    if (!state.isComplete()) {
                        long contentLength = (long)QAPMHttpURLConnectionExtension.this.impl.getContentLength();
                        long bytes = e.getBytes();
                        if (contentLength >= 0L) {
                            bytes = contentLength;
                        }

                        state.setBytesReceived(bytes);

                        try {
                            int statusCode = QAPMHttpURLConnectionExtension.this.impl.getResponseCode();
                            state.setStatusCode(statusCode);
                        } catch (IOException e3) {
                        }

                        QAPMHttpURLConnectionExtension.this.addTransactionAndErrorData(state);
                    }

                }
            });
        }

        return inputStream;
    }

    public InputStream getErrorStream() {
        this.getTransactionState();
        if (this.qapmCountingInputStream != null) {
            return this.qapmCountingInputStream;
        } else {
            try {
                this.qapmCountingInputStream = new QAPMCountingInputStream(this.impl.getErrorStream(), true);
            } catch (Exception ex) {
                Magnifier.ILOGUTIL.d(TAG, "errorStream :" , ex.toString());
                return this.impl.getErrorStream();
            }

            this.qapmCountingInputStream.addStreamCompleteListener(new QAPMStreamCompleteListener() {
                public void streamError(QAPMStreamCompleteEvent e) {
                    Magnifier.ILOGUTIL.d(TAG, "streamError:" , e.toString());
                    if (!QAPMHttpURLConnectionExtension.this.transactionState.isComplete()) {
                        QAPMHttpURLConnectionExtension.this.transactionState.setBytesReceived(e.getBytes());
                    }

                    QAPMHttpURLConnectionExtension.this.error(e.getException());
                }

                public void streamComplete(QAPMStreamCompleteEvent e) {
                    if (!QAPMHttpURLConnectionExtension.this.transactionState.isComplete()) {
                        int code = 0;

                        try {
                            code = QAPMHttpURLConnectionExtension.this.impl.getResponseCode();
                            QAPMHttpURLConnectionExtension.this.transactionState.setStatusCode(code);
                        } catch (IOException var7) {
                        }

                        long exceptionBytes = e.getBytes();
                        if (code != 206) {
                            long contentLength = (long)QAPMHttpURLConnectionExtension.this.impl.getContentLength();
                            exceptionBytes = contentLength >= 0L ? contentLength : exceptionBytes;
                        }

                        QAPMHttpURLConnectionExtension.this.transactionState.setBytesReceived(exceptionBytes);
                        QAPMHttpURLConnectionExtension.this.addTransactionAndErrorData(QAPMHttpURLConnectionExtension.this.transactionState);
                    }

                }
            });
            return this.qapmCountingInputStream;
        }
    }

    public long getLastModified() {
        this.getTransactionState();
        long lastModified = this.impl.getLastModified();
        this.checkResponse();
        return lastModified;
    }

    public OutputStream getOutputStream() throws IOException {
        QAPMCountingOutputStream qapmCountingOutputStream;
        try {
            qapmCountingOutputStream = new QAPMCountingOutputStream(this.impl.getOutputStream());
        } catch (IOException ex) {
            this.error(ex);
            throw ex;
        }

        if (qapmCountingOutputStream != null) {
            qapmCountingOutputStream.addStreamCompleteListener(new QAPMStreamCompleteListener() {
                public void streamError(QAPMStreamCompleteEvent e) {
                    QAPMTransactionState transactionState = QAPMHttpURLConnectionExtension.this.getTransactionState();
                    if (!transactionState.isComplete()) {
                        transactionState.setBytesSent(e.getBytes());
                    }

                    try {
                        int responseCode = QAPMHttpURLConnectionExtension.this.impl.getResponseCode();
                        transactionState.setStatusCode(responseCode);
                    } catch (IOException ex2) {
                    }

                    QAPMHttpURLConnectionExtension.this.error(e.getException());
                }

                public void streamComplete(QAPMStreamCompleteEvent e) {
                    QAPMTransactionState transactionState = QAPMHttpURLConnectionExtension.this.getTransactionState();
                    if (!transactionState.isComplete()) {
                        String contentLen = QAPMHttpURLConnectionExtension.this.impl.getRequestProperty("content-length");
                        long byteLen = e.getBytes();
                        if (contentLen != null) {
                            try {
                                byteLen = Long.parseLong(contentLen);
                            } catch (NumberFormatException ex4) {
                            }
                        }

                        transactionState.setBytesSentAfterComplete(byteLen);
                    }

                }
            });
        }

        return qapmCountingOutputStream;
    }

    public int getReadTimeout() {
        return this.impl.getReadTimeout();
    }

    public Map<String, List<String>> getRequestProperties() {
        return this.impl.getRequestProperties();
    }

    public String getRequestProperty(String field) {
        return this.impl.getRequestProperty(field);
    }

    public URL getURL() {
        return this.impl.getURL();
    }

    public boolean getUseCaches() {
        return this.impl.getUseCaches();
    }

    public void setAllowUserInteraction(boolean newValue) {
        this.impl.setAllowUserInteraction(newValue);
    }

    public void setConnectTimeout(int timeoutMillis) {
        this.impl.setConnectTimeout(timeoutMillis);
    }

    public void setDefaultUseCaches(boolean newValue) {
        this.impl.setDefaultUseCaches(newValue);
    }

    public void setDoInput(boolean newValue) {
        this.impl.setDoInput(newValue);
    }

    public void setDoOutput(boolean newValue) {
        this.impl.setDoOutput(newValue);
    }

    public void setIfModifiedSince(long newValue) {
        this.impl.setIfModifiedSince(newValue);
    }

    public void setReadTimeout(int timeoutMillis) {
        this.impl.setReadTimeout(timeoutMillis);
    }

    public void setRequestProperty(String field, String newValue) {
        this.impl.setRequestProperty(field, newValue);
    }

    public void setUseCaches(boolean newValue) {
        this.impl.setUseCaches(newValue);
    }

    public String toString() {
        return this.impl.toString();
    }

    private void checkResponse() {
        if (!this.getTransactionState().isComplete()) {
            QAPMTransactionStateUtil.inspectAndInstrumentResponse(this.getTransactionState(), this.impl);
        }

    }

    private QAPMTransactionState getTransactionState() {
        if (this.transactionState == null) {
            this.transactionState = new QAPMTransactionState();
            QAPMTransactionStateUtil.setUrlAndCarrier(this.transactionState, this.impl);
        }

        return this.transactionState;
    }

    private void error(Exception e) {
        try {
            if (!TraceUtil.getCanMonitorHttp()) {
                return;
            }

            QAPMTransactionState qapmTransactionState = this.getTransactionState();

            try {
                qapmTransactionState.setContentType(StringUtil.contentType(this.impl.getContentType()));
            } catch (Exception ex3) {
                Magnifier.ILOGUTIL.exception(TAG, "QAPMTransactionStateUtil. getcontenttype occur an error", ex3);
            }

            try {
                if (qapmTransactionState != null && !qapmTransactionState.hasParseUrlParams) {
                    QAPMTransactionStateUtil.processUrlParams(qapmTransactionState, this.impl);
                }
            } catch (Exception exception) {
                Magnifier.ILOGUTIL.exception(TAG, "QAPMTransactionStateUtil.processUrlParams occur an error", exception);
            }

            QAPMTransactionStateUtil.setErrorCodeFromException(qapmTransactionState, e);
            if (!qapmTransactionState.isComplete()) {
                String exceptionInfo = "";
                if (qapmTransactionState.getException() != null) {
                    exceptionInfo = qapmTransactionState.getException();
                }

                Magnifier.ILOGUTIL.d(TAG, "error message:" , exceptionInfo);
                TransactionData transactionData = qapmTransactionState.end();
                Magnifier.ILOGUTIL.d(TAG, "isError:" , String.valueOf(qapmTransactionState.isError()));
                if (qapmTransactionState.isError()) {
                    //todo:存储数据
                    HttpDataModel.collectData(transactionData, exceptionInfo);
                    //com.networkbench.agent.impl.g.h.a(qapmTransactionState.getUrl(), qapmTransactionState.getFormattedUrlParams(), qapmTransactionState.getAllGetRequestParams(), qapmTransactionState.getStatusCode(), exceptionString, qapmTransactionState.getRequestMethodType(), transactionData.h(), transactionData.f(), transactionData.w(), transactionData.l(), transactionData.d());
                }
                else{
                    HttpDataModel.collectData(transactionData);
                }

                //k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
            }
        } catch (Exception exception) {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMHttpURLConnectionExtension error had an error :" , exception);
        }

    }

    private void addTransactionAndErrorData(QAPMTransactionState transactionState) {
        try {
            if (!TraceUtil.getCanMonitorHttp()) {
                return;
            }


            try {
                transactionState.setContentType(StringUtil.contentType(this.impl.getContentType()));
            } catch (Exception e) {
                Magnifier.ILOGUTIL.exception(TAG, "QAPMTransactionStateUtil. getcontenttype occur an error", e);
            }

            TransactionData transactionData = transactionState.end();
            if (transactionData == null) {
                return;
            }

            //k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
            if (transactionState.isError()) {
                StringBuilder stringBuilder = new StringBuilder();

                try {
                    InputStream errorStream = this.getErrorStream();
                    if (errorStream instanceof QAPMCountingInputStream) {
                        stringBuilder.append(((QAPMCountingInputStream)errorStream).getBufferAsString());
                    }
                } catch (Exception e) {
                    Magnifier.ILOGUTIL.e(TAG, e.toString());
                }

                TreeMap treeMap = new TreeMap();

                try {
                    if (this.impl.getHeaderFields() != null && this.impl.getHeaderFields().size() > 0) {
                        Map headerFields = this.impl.getHeaderFields();
                        Iterator iterator = headerFields.keySet().iterator();

                        while(iterator.hasNext()) {
                            String str = (String)iterator.next();
                            if (!TextUtils.isEmpty(str)) {
                                treeMap.put(str, ((List)headerFields.get(str)).get(0));
                            }
                        }
                    }
                } catch (Exception var12) {
                }

                String exceptionInfo = "";
                if (transactionState.getException() != null) {
                    exceptionInfo = transactionState.getException();
                }

                Magnifier.ILOGUTIL.d(TAG, "error message:" , exceptionInfo);
                //todo:存储数据
                HttpDataModel.collectData(transactionData, treeMap, exceptionInfo);
                //com.networkbench.agent.impl.g.h.a(transactionData.o(), transactionData.s(), transactionData.c(), transactionData.q(), stringBuilder.toString(), treeMap, exceptionInfo, transactionState.getRequestMethodType(), transactionData.h(), transactionData.f(), transactionData.w(), transactionData.l(), transactionData.d());
            }
            else{
                HttpDataModel.collectData(transactionData);
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG,"QAPMHttpURLConnectionExtension addTransactionAndErrorData has an error : ", e);
        }

    }
}
