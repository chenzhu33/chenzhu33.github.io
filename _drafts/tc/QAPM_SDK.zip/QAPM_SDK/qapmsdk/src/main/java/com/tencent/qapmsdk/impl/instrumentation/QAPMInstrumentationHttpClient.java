package com.tencent.qapmsdk.impl.instrumentation;

import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.impl.api.data.TransactionData;
import com.tencent.qapmsdk.impl.instrumentation.httpclient.QAPMResponseHandlerImpl;
import com.tencent.qapmsdk.impl.model.HttpDataModel;
import com.tencent.qapmsdk.impl.util.TraceUtil;

import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.RequestLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HttpContext;

import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;

public class QAPMInstrumentationHttpClient {
    private final static String TAG = "QAPM_Impl_QAPMInstrumentationHttpClient";

    public QAPMInstrumentationHttpClient() {
    }

    @QAPMReplaceCallSite(
            isStatic = true
    )
    public static HttpResponse execute(HttpClient httpClient, HttpHost target, HttpRequest request, HttpContext context) throws IOException {
        if (!TraceUtil.getCanMonitorHttp()) {
            return httpClient.execute(target, request, context);
        } else {
            Magnifier.ILOGUTIL.d(TAG, "httpClient execute gather  begin !!");
            QAPMTransactionState state = new QAPMTransactionState();

            try {
                state.setAppPhase(0);
                request = dispatchHttpClientRequest(request, state);
            } catch (Exception e) {
                Magnifier.ILOGUTIL.e(TAG, "error set transaction e:" , e.getMessage());
            }

            try {
                request = QAPMHttpClientUtil.setHttpClientCrossProcessHeader(request);
                return doExec(httpClient.execute(target, doExec(target, request, state), context), state);
            } catch (IOException e1) {
                httpClientError(state, e1);
                throw e1;
            }
        }
    }

    @QAPMReplaceCallSite
    public static <T> T execute(HttpClient httpClient, HttpHost target, HttpRequest request, ResponseHandler<? extends T> responseHandler, HttpContext context) throws IOException, ClientProtocolException {
        if (!TraceUtil.getCanMonitorHttp()) {
            return httpClient.execute(target, request, responseHandler, context);
        } else {
            Magnifier.ILOGUTIL.d(TAG, "httpClient execute gather  begin !!");
            QAPMTransactionState state = new QAPMTransactionState();

            try {
                state.setAppPhase(0);
                request = dispatchHttpClientRequest(request, state);
            } catch (Exception e) {
                Magnifier.ILOGUTIL.e(TAG, "error set transaction e:" , e.getMessage());
            }

            try {
                request = QAPMHttpClientUtil.setHttpClientCrossProcessHeader(request);
                return httpClient.execute(target, doExec(target, request, state), doExec(responseHandler, state), context);
            } catch (ClientProtocolException ex1) {
                httpClientError(state, ex1);
                throw ex1;
            } catch (IOException e2) {
                httpClientError(state, e2);
                throw e2;
            }
        }
    }

    @QAPMReplaceCallSite
    public static <T> T execute(HttpClient httpClient, HttpHost target, HttpRequest request, ResponseHandler<? extends T> responseHandler) throws IOException, ClientProtocolException {
        if (!TraceUtil.getCanMonitorHttp()) {
            return httpClient.execute(target, request, responseHandler);
        } else {
            Magnifier.ILOGUTIL.d(TAG, "httpClient execute gather  begin !!");
            QAPMTransactionState state = new QAPMTransactionState();

            try {
                state.setAppPhase(0);
                request = dispatchHttpClientRequest(request, state);
            } catch (Exception e) {
                Magnifier.ILOGUTIL.e(TAG, "error set transaction e:" , e.getMessage());
            }

            try {
                request = QAPMHttpClientUtil.setHttpClientCrossProcessHeader(request);
                return httpClient.execute(target, doExec(target, request, state), doExec(responseHandler, state));
            } catch (ClientProtocolException e1) {
                httpClientError(state, e1);
                throw e1;
            } catch (IOException e2) {
                httpClientError(state, e2);
                throw e2;
            }
        }
    }

    @QAPMReplaceCallSite
    public static HttpResponse execute(HttpClient httpClient, HttpHost target, HttpRequest request) throws IOException {
        if (!TraceUtil.getCanMonitorHttp()) {
            return httpClient.execute(target, request);
        } else {
            Magnifier.ILOGUTIL.d(TAG, "httpClient execute gather  begin !!");
            QAPMTransactionState state = new QAPMTransactionState();

            try {
                state.setAppPhase(0);
                request = dispatchHttpClientRequest(request, state);
            } catch (Exception e) {
                Magnifier.ILOGUTIL.e(TAG, "error set transaction e:" , e.getMessage());
            }

            try {
                request = QAPMHttpClientUtil.setHttpClientCrossProcessHeader(request);
                return doExec(httpClient.execute(target, doExec(target, request, state)), state);
            } catch (IOException e1) {
                httpClientError(state, e1);
                throw e1;
            }
        }
    }

    @QAPMReplaceCallSite
    public static HttpResponse execute(HttpClient httpClient, HttpUriRequest request, HttpContext context) throws IOException {
        if (!TraceUtil.getCanMonitorHttp()) {
            return httpClient.execute(request, context);
        } else {
            Magnifier.ILOGUTIL.d(TAG, "httpClient execute gather  begin !!");
            QAPMTransactionState state = new QAPMTransactionState();

            try {
                state.setAppPhase(0);
                request = (HttpUriRequest)dispatchHttpClientRequest(request, state);
            } catch (Exception e) {
                Magnifier.ILOGUTIL.e(TAG, "error set transaction e:" , e.getMessage());
            }

            try {
                request = (HttpUriRequest)QAPMHttpClientUtil.setHttpClientCrossProcessHeader(request);
                return doExec(httpClient.execute(doExec(request, state), context), state);
            } catch (IOException e1) {
                httpClientError(state, e1);
                throw e1;
            }
        }
    }

    @QAPMReplaceCallSite
    public static <T> T execute(HttpClient httpClient, HttpUriRequest request, ResponseHandler<? extends T> responseHandler, HttpContext context) throws IOException, ClientProtocolException {
        if (!TraceUtil.getCanMonitorHttp()) {
            return httpClient.execute(request, responseHandler, context);
        } else {
            Magnifier.ILOGUTIL.d(TAG, "httpClient execute gather  begin !!");
            QAPMTransactionState state = new QAPMTransactionState();

            try {
                state.setAppPhase(0);
                request = (HttpUriRequest)dispatchHttpClientRequest(request, state);
            } catch (Exception e) {
                Magnifier.ILOGUTIL.e(TAG, "error set transaction e:" , e.getMessage());
            }

            try {
                request = (HttpUriRequest)QAPMHttpClientUtil.setHttpClientCrossProcessHeader(request);
                return httpClient.execute(doExec(request, state), doExec(responseHandler, state), context);
            } catch (ClientProtocolException e1) {
                httpClientError(state, e1);
                throw e1;
            } catch (IOException e2) {
                httpClientError(state, e2);
                throw e2;
            }
        }
    }

    @QAPMReplaceCallSite
    public static <T> T execute(HttpClient httpClient, HttpUriRequest request, ResponseHandler<? extends T> responseHandler) throws IOException, ClientProtocolException {
        if (!TraceUtil.getCanMonitorHttp()) {
            return httpClient.execute(request, responseHandler);
        } else {
            Magnifier.ILOGUTIL.d(TAG, "httpClient execute gather  begin !!");
            QAPMTransactionState state = new QAPMTransactionState();

            try {
                state.setAppPhase(0);
                request = (HttpUriRequest)dispatchHttpClientRequest(request, state);
            } catch (Exception e) {
                Magnifier.ILOGUTIL.e(TAG, "error set transaction e:" , e.getMessage());
            }

            try {
                request = (HttpUriRequest)QAPMHttpClientUtil.setHttpClientCrossProcessHeader(request);
                return httpClient.execute(doExec(request, state), doExec(responseHandler, state));
            } catch (ClientProtocolException e1) {
                httpClientError(state, e1);
                throw e1;
            } catch (IOException e2) {
                httpClientError(state, e2);
                throw e2;
            }
        }
    }

    @QAPMReplaceCallSite
    public static HttpResponse execute(HttpClient httpClient, HttpUriRequest request) throws IOException {
        if (!TraceUtil.getCanMonitorHttp()) {
            return httpClient.execute(request);
        } else {
            Magnifier.ILOGUTIL.d(TAG, "httpClient execute gather  begin !!");
            QAPMTransactionState state = new QAPMTransactionState();

            try {
                state.setAppPhase(0);
                request = (HttpUriRequest)dispatchHttpClientRequest(request, state);
            } catch (Exception e) {
                Magnifier.ILOGUTIL.e(TAG, "error set transaction e:" , e.getMessage());
            }

            try {
                request = (HttpUriRequest)QAPMHttpClientUtil.setHttpClientCrossProcessHeader(request);
                return doExec(httpClient.execute(doExec(request, state)), state);
            } catch (IOException e1) {
                httpClientError(state, e1);
                throw e1;
            }
        }
    }

    private static HttpUriRequest doExec(HttpUriRequest request, QAPMTransactionState transactionState) {
        return QAPMHttpClientUtil.inspectAndInstrument(transactionState, request);
    }

    private static HttpRequest doExec(HttpHost host, HttpRequest request, QAPMTransactionState transactionState) {
        return QAPMHttpClientUtil.inspectAndInstrument(transactionState, host, request);
    }

    @QAPMReplaceCallSite
    public static DefaultHttpClient initDefaultHttpClient() {
        DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
        return defaultHttpClient;
    }

    private static HttpResponse doExec(HttpResponse response, QAPMTransactionState transactionState) {
        return QAPMHttpClientUtil.inspectAndInstrument(transactionState, response);
    }

    private static <T> ResponseHandler<? extends T> doExec(ResponseHandler<? extends T> handler, QAPMTransactionState transactionState) {
        return QAPMResponseHandlerImpl.wrap(handler, transactionState);
    }

    private static HttpRequest dispatchHttpClientRequest(HttpRequest request, QAPMTransactionState transactionState) {
        return request;
//        RequestLine requestLine = request.getRequestLine();
//        String uri = requestLine.getUri();
//        String host = null;
//
//        try {
//            URL url = new URL(uri);
//            host = url.getHost();
//        } catch (MalformedURLException var10) {
//            Magnifier.ILOGUTIL.e(TAG, "dispatchHttpClientRequest error!" , var10.getMessage() , uri);
//        }
//
//        if (TextUtils.isEmpty(host)) {
//            return request;
//        } else if (TextUtils.isEmpty(host)) {
//            return request;
//        } else {
//            try {
//                long var11 = System.currentTimeMillis();
//                InetAddress[] var7 = InetAddress.getAllByName(host);
//                int dnsTime = (int)(System.currentTimeMillis() - var11);
//                transactionState.setDnsElapse(dnsTime);
//                if (transactionState != null) {
//                    transactionState.setAddressAllStr(i.a(var7));
//                }
//
//                return request;
//            } catch (UnknownHostException var9) {
//                Magnifier.ILOGUTIL.e(TAG, "dispatchHttpClientRequest error ! getByName the hostName is " , host);
//                return request;
//            }
//        }
    }

    private static void httpClientError(QAPMTransactionState transactionState, Exception e) {
        try {
            if (!TraceUtil.getCanMonitorHttp()) {
                return;
            }

            if (!transactionState.isComplete()) {
                QAPMHttpClientUtil.setErrorCodeFromException(transactionState, e);
                TransactionData transactionData = transactionState.end();
//                QAPMAndroidAgentImpl var3 = QAPMAgent.getImpl();
//                if (var3 == null) {
//                    return;
//                }
//
//                HarvestConfiguration var4 = var3.n();
//                if (var4 == null) {
//                    return;
//                }

                if (transactionData == null) {
                    Magnifier.ILOGUTIL.d(TAG, "transactionData is null");
                    return;
                }

//                k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
                if (transactionState.isError()) {
                    String exceptionInfo = "";
                    if (transactionState.getException() != null) {
                        exceptionInfo = transactionState.getException();
                    }

                    Magnifier.ILOGUTIL.d(TAG, "error message:" , exceptionInfo);
                    //todo:整理数据
                    HttpDataModel.collectData(transactionData, exceptionInfo);
                    //com.networkbench.agent.impl.g.h.a(transactionState.getUrl(), transactionState.getFormattedUrlParams(), transactionState.getAllGetRequestParams(), transactionState.getStatusCode(), exceptionInfo, transactionState.getRequestMethodType(), transactionData.h(), transactionData.f(), transactionData.w(), transactionData.l(), transactionData.d());
                }
                else{
                    HttpDataModel.collectData(transactionData);
                }
            }
        } catch (Exception ex1) {
            Magnifier.ILOGUTIL.e(TAG, "error httpClientError e:" , ex1.getMessage());
        }

    }
}
