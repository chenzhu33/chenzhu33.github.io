package com.tencent.qapmsdk.impl.instrumentation;

public abstract interface MetricEventListener
{
    public abstract void enterMethod(QAPMTraceUnit metricName);

    public abstract void exitMethod();

    public abstract void exitMethodCustom(String metricName);

    public abstract void asyncEnterMethod(QAPMTraceUnit metricName);

}