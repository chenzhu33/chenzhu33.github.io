package com.tencent.qapmsdk.impl.instrumentation;

import android.os.Looper;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.harvest.HarvestAdapter;
import com.tencent.qapmsdk.impl.harvest.MetricCategory;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class QAPMTraceEngine extends HarvestAdapter {
    private final static String TAG = "QAPM_Impl_QAPMTraceEngine";

    private static List<MetricEventListener> metricEventListeners = new CopyOnWriteArrayList();

    public static List<MetricEventListener> getMetricEventListeners()
    {
        return metricEventListeners;
    }

    public static void registerListener(MetricEventListener metricEventListener)
    {
        if (metricEventListener == null) {
            return;
        }
        if (metricEventListeners.contains(metricEventListener)) {
            return;
        }
        metricEventListeners.add(metricEventListener);
    }

    public static void removeListener(MetricEventListener metricEventListener)
    {
        if (metricEventListener == null) {
            return;
        }
        metricEventListeners.remove(metricEventListener);
    }

    public static void notifyObserverEnterMethod(QAPMTraceUnit traceUnit)
    {
        for (MetricEventListener localMetricEventListener : metricEventListeners) {
            localMetricEventListener.enterMethod(traceUnit);
        }
    }

    public static void notifyObserverExitMethod()
    {
        for (MetricEventListener localMetricEventListener : metricEventListeners) {
            localMetricEventListener.exitMethod();
        }
    }

    public static void notifyObserverExitMethodCustom(String name)
    {
        for (MetricEventListener localMetricEventListener : metricEventListeners) {
            localMetricEventListener.exitMethodCustom(name);
        }
    }

    public static void notifyObserverAsyncEnterMethod(QAPMTraceUnit traceUnit)
    {
        for (MetricEventListener localMetricEventListener : metricEventListeners) {
            localMetricEventListener.asyncEnterMethod(traceUnit);
        }
    }


    public static void startTracing(String name)
    {
        QAPMAppInstrumentation.activityCreateBeginIns(name);
    }

    public static void startTracingInFragment(String name) {}

    public static void enterMethod(String name, ArrayList<String> categoryParams)
    {
        try
        {
            enterMethod(null, name, categoryParams);
        }
        catch (Throwable localThrowable)
        {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMTraceEngine  enterMethod has an error :" , localThrowable);
        }
    }

    public static void enterMethod(QAPMTraceUnit trace, String name, ArrayList<String> annotationParams)
    {
        try
        {
            if (!shouldInvokeMethod(name)) {
                return;
            }
            //todo: 处理添加记录
            // b.a(new QAPMTraceUnit(name));
            if (Looper.myLooper() == Looper.getMainLooper()) {
                notifyObserverEnterMethod(new QAPMTraceUnit(name, getSegmentType(annotationParams).getValue()));
            } else {
                notifyObserverAsyncEnterMethod(new QAPMTraceUnit(name, getSegmentType(annotationParams).getValue()));
            }
        }
        catch (Throwable localThrowable)
        {
            Magnifier.ILOGUTIL.exception(TAG, "error happend in enterMethod:", localThrowable);
        }
    }

    private static boolean shouldInvokeMethod(String name)
    {
        if ((name != null) && (!name.endsWith("#onCreate"))) {
            return true;
        }
        return false;
    }

    public static void exitMethod()
    {
        try
        {
            //todo:匹配处理记录
            //b.b();

            notifyObserverExitMethod();
        }
        catch (Throwable localThrowable)
        {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMTraceEngine  exitMethod has an error :", localThrowable);
        }
    }

    public static void exitCustomApiMethod(String name)
    {
        try
        {
            Magnifier.ILOGUTIL.d(TAG, "exitCustomApiMethod");

            //todo:匹配处理记录
            // b.a(name);

            notifyObserverExitMethodCustom(name);
        }
        catch (Throwable localThrowable)
        {
            Magnifier.ILOGUTIL.exception(TAG, "QAPMTraceEngine  exitCustomApiMethod has an error :", localThrowable);
        }
    }



    public static TraceType.CATEGORY getSegmentType(List<String> annotationParams) {
        if (annotationParams != null && annotationParams.size() == 3) {
            String var1 = (String)annotationParams.get(2);
            if (var1.equalsIgnoreCase(MetricCategory.IMAGE.getCategoryName())) {
                return TraceType.CATEGORY.IMAGE;
            }

            if (var1.equalsIgnoreCase(MetricCategory.JSON.getCategoryName())) {
                return TraceType.CATEGORY.JSON;
            }

            if (var1.equalsIgnoreCase(MetricCategory.NETWORK.getCategoryName())) {
                return TraceType.CATEGORY.NETWORK;
            }

            if (var1.equalsIgnoreCase("DATABASE")) {
                return TraceType.CATEGORY.DATABASE;
            }

            if (var1.equalsIgnoreCase(MetricCategory.CUSTOMEVENT.getCategoryName())) {
                return TraceType.CATEGORY.CUSTOMEVENT;
            }
        }

        return TraceType.CATEGORY.OTHER;
    }

}
