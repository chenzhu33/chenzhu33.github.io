package com.tencent.qapmsdk.impl.httpOprate;

import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.harvest.HttpLibType;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionState;
import com.tencent.qapmsdk.impl.util.StringUtil;
import com.tencent.qapmsdk.impl.util.TraceUtil;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class QAPMHTTPInterceptor implements Interceptor {
    private final static String TAG = "QAM_Impl_QAPMHTTPInterceptor";
    private final IDataCollect dataCollect = new HttpDataCollect();
    private final AtomicInteger c = new AtomicInteger(0);

    public QAPMHTTPInterceptor() {
        Magnifier.ILOGUTIL.d(TAG, "OkHttpInstrumentation3 - wrapping Instructor");
    }

    public Response intercept(Interceptor.Chain chain) throws IOException {
        Request request = chain.request();
        if (request != null && TraceUtil.getCanMonitorHttp()) {
            QAPMTransactionState qapmTransactionState = new QAPMTransactionState();

            try {
                qapmTransactionState.setAppPhase(0);
                qapmTransactionState.setHttpLibType(HttpLibType.OkHttp);
                if (this.dataCollect.isCanCollect() || request != null) {
                    try {
                        request = this.getQueueTime(request, qapmTransactionState);
                        request = this.restoreHead(request);
                        this.dataCollect.collectRequest(request, qapmTransactionState);
                    } catch (Exception e) {
                        Magnifier.ILOGUTIL.exception(TAG, "okhttp3.0 -> setCrossProcessHeader occur an error", e);
                    }
                }
            } catch (Exception e) {
                Magnifier.ILOGUTIL.exception(TAG, "okhttp3 intercept error", e);
            }

            Response response;
            try {
                response = chain.proceed(request);

                try {
                    String contentType = response.header("Content-Type");
                    qapmTransactionState.setContentType(StringUtil.contentType(contentType));
                } catch (Exception e) {
                    Magnifier.ILOGUTIL.exception(TAG, "QAPMOkHttp3Interceptor_. getContentType occur an error", e);
                }
            } catch (IOException exception) {
                IOException ioException = exception;
                if (this.dataCollect.isCanCollect()) {
                    try {
                        this.dataCollect.collectException(qapmTransactionState, ioException);
                    } catch (Exception e) {
                        Magnifier.ILOGUTIL.e(TAG, "QAPMOkHttp3Interceptor_  intercept() --->httpError has an error : " , e.toString());
                    }
                }

                throw exception;
            }

            if (this.dataCollect.isCanCollect() || response != null) {
                try {
                    this.dataCollect.collectResponse(response, qapmTransactionState);
                } catch (Exception e) {
                    Magnifier.ILOGUTIL.e(TAG, "QAPMOkHttp3Interceptor_  intercept()---> responseFinished  has an error : " , e.toString());
                }
            }

            return response;
        } else {
            return chain.proceed(request);
        }
    }

    private Request getQueueTime(Request request, QAPMTransactionState qapmTransactionState) {
        try {
            Request.Builder builder = request.newBuilder();
            if (qapmTransactionState == null) {
                qapmTransactionState = new QAPMTransactionState();
            }

            qapmTransactionState.setQueueTime(this.getQueueTime(request, qapmTransactionState.getStartTime()));
//            String var4 = h.j().T();
//            if (!TextUtils.isEmpty(var4) && h.j().S()) {
//                int var5 = h.U();
//                String var6 = h.a(var4, var5);
//                qapmTransactionState.setTyIdRandomInt(var5);
//                builder.addHeader("X-Tingyun-Id", var6);
//            }

            return builder.build();
        } catch (Exception e) {
            Magnifier.ILOGUTIL.e(TAG, "QAPMOkHttp3Interceptor_  setCrossProcessHeader---> has an error : " , e.toString());
            return request;
        }
    }

    private int getQueueTime(Request request, long startTime) {
        int queueTime = 0;

        try {
            queueTime = (int)(startTime - Long.parseLong(request.header("X-QAPM-Qt")));
            request.newBuilder().removeHeader("X-QAPM-Qt");
        } catch (Exception e) {
            Magnifier.ILOGUTIL.e(TAG, "getQueueTime error:" , e.getMessage());
        }

        return queueTime;
    }

    private Request restoreHead(Request request) {
        Request bakRequest = request;

        try {
            if (!TextUtils.isEmpty(request.header("X-QAPM-Qt"))) {
                bakRequest = request.newBuilder().removeHeader("X-QAPM-Qt").build();
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.e(TAG, "dropQtHeader error:" , e.getMessage());
        }

        return bakRequest;
    }
}
