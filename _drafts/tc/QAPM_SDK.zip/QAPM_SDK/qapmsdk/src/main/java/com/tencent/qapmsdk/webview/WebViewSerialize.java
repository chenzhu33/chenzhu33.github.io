package com.tencent.qapmsdk.webview;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.config.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

public class WebViewSerialize {
    public WebViewX5Proxy webViewX5Proxy;
    public List<JSONObject> metrics = Collections.synchronizedList(new ArrayList<JSONObject>());
    public List<JSONObject> singletons = Collections.synchronizedList(new ArrayList<JSONObject>());

    private long threshold = Config.S_FIRSTSCREEN_THR;
    private final List<String> JSON_INT_TYPE = Arrays.asList(WebViewDataType.APN_TYPE, WebViewDataType.PROXY_TYPE,
            WebViewDataType.HOST_COUNT, WebViewDataType.LAYER_NUM, WebViewDataType.IS_SYSTEM_KERNEL);
    private final List<String> JSON_STRING_TYPE = Arrays.asList(WebViewDataType.URL, WebViewDataType.REFERER,
            WebViewDataType.MAIN_RESOURCE, WebViewDataType.VERSION, WebViewDataType.BREAD_CRUMB_ID);
    private final List<String> JSON_LONG_TYPE = Arrays.asList(WebViewDataType.PAGE_START, WebViewDataType.FIRST_BYTE_STAMP,
            WebViewDataType.FIRST_WORD, WebViewDataType.FIRST_WORD_STAMP, WebViewDataType.FIRST_SCREEN, WebViewDataType.FIRST_SCREEN_STAMP,
            WebViewDataType.DOM_LOADING, WebViewDataType.LAYOUT_ELAPSED, WebViewDataType.PAGE_FINISH, WebViewDataType.QPROXY_STRATEGY,
            WebViewDataType.RENDER_ELAPSED, WebViewDataType.PARSER_ELSPSED, WebViewDataType.DOM_INTERACTIVE, WebViewDataType.DOM_CONTENT_LOADED_EVENT_START,
            WebViewDataType.DOM_CONTENT_LOADED_EVENT_END, WebViewDataType.DOM_COMPLETE, WebViewDataType.FRAME_START_TIME,
            WebViewDataType.FRAME_END_TIME, WebViewDataType.TOTAL_LAYER_MEM, WebViewDataType.BASE_TIME
            );
    private final List<String> JSON_DOUBLE_TYPE = Arrays.asList(WebViewDataType.SOCKET_REUSE_PO, WebViewDataType.QUIC_PRO,
            WebViewDataType.MIN_LAYER_SIZE, WebViewDataType.MAX_LAYER_SIZE);
    private final List<String> JSON_ARRAY_TYPE = Arrays.asList(WebViewDataType.FPS_JSON_ARR, WebViewDataType.CPU_INFO_JSON_ARR,
            WebViewDataType.MEMORY_INFO_JSON_ARR, WebViewDataType.NETWORK_INFO_JSON_ARR, WebViewDataType.GPU_INFO_JSON_ARR);

    private static WebViewSerialize instance = null;

    public WebViewSerialize(){
        this.webViewX5Proxy = WebViewX5Proxy.getInstance();
    }

    public static WebViewSerialize getInstance() {
        if (null == instance) {
            synchronized(WebViewSerialize.class) {
                if (null == instance) {
                    instance = new WebViewSerialize();
                }
            }
        }
        return instance;
    }

    public void setThreshold(long threshold){
        this.threshold = threshold;
    }


    public void clearCache(){
        this.metrics.clear();
        this.singletons.clear();

    }

    public void doSerialize(){
        ConcurrentLinkedQueue<JSONObject> rawDatas = this.webViewX5Proxy.getMonitorData();
        try {
            while (!rawDatas.isEmpty()){
                JSONObject data = rawDatas.poll();
                boolean needSingle = false;
                long page_start_time = Long.valueOf(data.getString(WebViewDataType.PAGE_START));
                long page_finish_time= Long.valueOf(data.getString(WebViewDataType.PAGE_FINISH));
                long page_load_during = page_finish_time - page_start_time;
                if (page_load_during > threshold){
                    needSingle = true;
                }
                JSONObject metricsJson = serializeMetrics(data, page_start_time, page_finish_time);
                if (metricsJson != null){
                    metrics.add(metricsJson);
                }
                if (needSingle){
                    JSONObject singletonsJson = serializeSingletons(data);
                    if (singletonsJson != null){
                        singletons.add(singletonsJson);
                    }
                }


            }
        }
        catch (JSONException e){
            Magnifier.ILOGUTIL.exception("webview ", e);
        }
        finally {
            this.webViewX5Proxy.clear();
        }

    }

    private void packageJson(JSONObject rawJson, JSONObject targetJson, String key) throws JSONException{
        if (JSON_INT_TYPE.contains(key)){
            targetJson.put(key, Integer.valueOf(rawJson.getString(key)).intValue());
        }
        else if (JSON_STRING_TYPE.contains(key)){
            targetJson.put(key, rawJson.getString(key));
        }
        else if (JSON_DOUBLE_TYPE.contains(key)){
            targetJson.put(key, Double.valueOf(rawJson.getString(key)).doubleValue());
        }
        else if (JSON_LONG_TYPE.contains(key)){
            targetJson.put(key, Long.valueOf(rawJson.getString(key)).longValue());
        }
    }

    private JSONObject serializeMetrics(JSONObject rawJson, long page_start_time, long page_finish_time){
        JSONObject metricsJson = new JSONObject();
        try {
            metricsJson.put("category", "webview_x5_metrics");
            metricsJson.put("is_slow", page_finish_time - page_start_time > threshold ? 1 : 0);
            metricsJson.put(WebViewDataType.URL, rawJson.getString(WebViewDataType.URL));
            metricsJson.put(WebViewDataType.APN_TYPE, Integer.valueOf(rawJson.getString(WebViewDataType.APN_TYPE)).longValue());
            metricsJson.put(WebViewDataType.FIRST_WORD, Long.valueOf(rawJson.getString(WebViewDataType.FIRST_WORD)) - page_start_time);
            metricsJson.put(WebViewDataType.FIRST_SCREEN, Long.valueOf(rawJson.getString(WebViewDataType.FIRST_SCREEN)) - page_start_time);
            metricsJson.put(WebViewDataType.PAGE_FINISH, page_finish_time - page_start_time);
            metricsJson.put(WebViewDataType.DOM_LOADING, Long.valueOf(rawJson.getString(WebViewDataType.DOM_LOADING)).longValue());
            metricsJson.put(WebViewDataType.DOM_INTERACTIVE, Long.valueOf(rawJson.getString(WebViewDataType.DOM_INTERACTIVE)).longValue());
            metricsJson.put(WebViewDataType.DOM_CONTENT_LOADED_EVENT, Long.valueOf(rawJson.getString(WebViewDataType.DOM_CONTENT_LOADED_EVENT_END)) - Long.valueOf(rawJson.getString(WebViewDataType.DOM_CONTENT_LOADED_EVENT_START)));
            metricsJson.put(WebViewDataType.DOM_COMPLETE, Long.valueOf(rawJson.getString(WebViewDataType.DOM_COMPLETE)).longValue());
        }
        catch (JSONException e){
            metricsJson = null;
        }
        return metricsJson;
    }

    private JSONObject serializeSingletons(JSONObject rawJson){
        JSONObject singletonJson = new JSONObject();
        try {
            singletonJson.put("category", "webview_x5_singleton");
            Iterator<String>iterator = rawJson.keys();
            while (iterator.hasNext()){
                String key = iterator.next();
                if (key.equals(WebViewDataType.SUB_RESOURCE_JSON_ARR)){
                    JSONArray subResource = rawJson.getJSONArray(WebViewDataType.SUB_RESOURCE_JSON_ARR);
                    JSONArray afterFilterResource = new JSONArray();
                    for (int i = 0; i < subResource.length(); i++) {
                        boolean filter = false;
                        String str = (String) subResource.get(i);
                        for (String host : Config.whiteHttpHosts){
                            if (str.contains(host)){
                                filter = true;
                                break;
                            }
                        }
                        if (filter){
                            continue;
                        }
                        afterFilterResource.put(str);
                    }

                    singletonJson.put(WebViewDataType.SUB_RESOURCE_JSON_ARR, afterFilterResource);
                }
                else {
                    if (key.equals(WebViewDataType.PAGE_START)){
                        singletonJson.put(WebViewDataType.START_MONITOR_TIME, rawJson.getLong(key));
                    }
                    if (key.equals(WebViewDataType.PAGE_FINISH)){
                        singletonJson.put(WebViewDataType.STOP_MONITOR_TIME, rawJson.getLong(key));
                    }
                    packageJson(rawJson, singletonJson, key);
                }
            }
            for(String jsonArrKey : JSON_ARRAY_TYPE){
                singletonJson.put(jsonArrKey, new JSONArray());
            }

        }catch (JSONException e){
            singletonJson = null;
        }
        return singletonJson;

    }
}
