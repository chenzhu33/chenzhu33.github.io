package com.tencent.qapmsdk.impl.harvest;

public class HarvestAdapter
        implements HarvestLifecycleAware
{
    public void onHarvestStart() {}

    public void onHarvestStop() {}

    public void onHarvestBefore() {}

    public void onHarvest() {}

    public void onHarvestFinalize() {}

    public void onHarvestError() {}

    public void onHarvestSendFailed() {}

    public void onHarvestComplete() {}

    public void onHarvestConnected() {}

    public void onHarvestDisconnected() {}

    public void onHarvestDisabled() {}

    public void onHarvestDeviceIdError() {}

    public void onHarvestFilter() {}
}
