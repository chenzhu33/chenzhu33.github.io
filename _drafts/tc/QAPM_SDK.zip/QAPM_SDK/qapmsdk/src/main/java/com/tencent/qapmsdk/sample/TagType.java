package com.tencent.qapmsdk.sample;

public class TagType{
    public static final int BEGINTAG = 0;
    public static final int ENDTAG = 1;

}