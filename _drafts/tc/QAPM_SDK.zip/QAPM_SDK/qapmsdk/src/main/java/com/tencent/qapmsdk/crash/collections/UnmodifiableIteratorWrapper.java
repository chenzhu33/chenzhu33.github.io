package com.tencent.qapmsdk.crash.collections;

import java.util.Iterator;

class UnmodifiableIteratorWrapper<E> implements Iterator<E> {
    private final Iterator<E> mIterator;

    UnmodifiableIteratorWrapper(Iterator<E> mIterator) {
        this.mIterator = mIterator;
    }

    @Override
    public boolean hasNext() {
        return mIterator.hasNext();
    }

    @Override
    public E next() {
        return mIterator.next();
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }
}
