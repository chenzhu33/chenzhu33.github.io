package com.tencent.qapmsdk.webview;

import com.tencent.qapmsdk.common.BaseListener;

import org.json.JSONObject;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class WebViewBreadCrumb
{
    private final ReentrantReadWriteLock reentrantLock = new ReentrantReadWriteLock();
    private static WebViewBreadCrumb instance;


    public static WebViewBreadCrumb getInstance() {
        if (null == instance) {
            synchronized(WebViewBreadCrumb.class) {
                if (null == instance) {
                    instance = new WebViewBreadCrumb();
                }
            }
        }
        return instance;
    }

    public interface WebViewBreadCrumbListener extends BaseListener {
        public Object saveWebView();
    }

}
