package com.tencent.qapmsdk.io.util;

import java.io.File;
import org.json.JSONObject;

import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.reporter.ResultObject;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.common.FileUtil;
import com.tencent.qapmsdk.common.PhoneUtil;

class ObjectForCallback {
    /*
     * args: o是 I/O文件保存的路径 
     * 
     * */
    @Override
    public boolean equals(Object o) {
        if (!CollectStatus.canCollect(Config.PLUGIN_QCLOUD_FILE_IO)) {
            return false;
        }
        CollectStatus.addCollectCount(Config.PLUGIN_QCLOUD_FILE_IO);
        String filePath = (String)o;
        String newFileAbsoPath = filePath;
        File tempFile = new File(filePath);
        try {
            if (tempFile != null && tempFile.exists() && tempFile.isDirectory()) {
                String dir = tempFile.getParent();
                long curTime = System.currentTimeMillis();
                String outputName = "out_" + String.valueOf(curTime) + ".zip";
                String fullPath = dir + "/" + outputName;
                FileUtil.zipFiles(filePath, fullPath);
                newFileAbsoPath = fullPath;
                if (newFileAbsoPath.length() == 0) {
                    return false;
                } else {
                    FileUtil.deleteAllFilesOfDir(tempFile);
                }
            }
            JSONObject params = new JSONObject();
            params.put("processname", PhoneUtil.getProcessName(Magnifier.sApp));
            params.put("fileObj", newFileAbsoPath);
            params.put("plugin", Config.PLUGIN_QCLOUD_FILE_IO);
            ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, false, true, Magnifier.info.uin);
            ReporterMachine.addResultObj(ro);
        } catch (Exception e) {}
        return true;
    }
}