package com.tencent.qapmsdk.impl.appstate;

public enum AppState {
    INIT(0),
    FIRSTSTART(1),
    COLDSTART(2),
    HOTSTART(3),
    COMMONRESTART(8),
    f(9);

    private int value;

    private AppState(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }
}