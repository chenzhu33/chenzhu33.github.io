package com.tencent.qapmsdk.crash.util;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.os.Process;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.crash.builder.LastActivityManager;

import java.util.List;

public class ProcessFinisher {

    private final Context context;
    private final LastActivityManager lastActivityManager;
    private static final String LOG_TAG = ILogUtil.getTAG(ProcessFinisher.class);
    private final Boolean stopServiceOnCrash;
    public ProcessFinisher(@NonNull Context context, @NonNull Boolean stopServiceOnCrash, @NonNull LastActivityManager lastActivityManager) {
        this.context = context;
        this.lastActivityManager = lastActivityManager;
        this.stopServiceOnCrash = stopServiceOnCrash;
    }

    public void endApplication() {
        stopServices();
        killProcessAndExit();
    }

    public void finishLastActivity(@Nullable Thread uncaughtExceptionThread) {
        Magnifier.ILOGUTIL.i(LOG_TAG, "Finishing activities prior to killing the Process");
        boolean wait = false;
        for(final Activity activity : lastActivityManager.getLastActivities()) {
            final boolean isMainThread = uncaughtExceptionThread == activity.getMainLooper().getThread();
            final Runnable finisher = new Runnable() {
                @Override
                public void run() {
                    activity.finish();
                    Magnifier.ILOGUTIL.d(LOG_TAG, "Finished " + activity.getClass());
                }
            };

            if (isMainThread) {
                finisher.run();
            } else {
                // A crashed activity won't continue its lifecycle. So we only wait if something else crashed
                wait = true;
                activity.runOnUiThread(finisher);
            }
        }
        if (wait) {
            lastActivityManager.waitForAllActivitiesDestroy(100);
        }
        lastActivityManager.clearLastActivities();
    }

    private void stopServices() {
        if (stopServiceOnCrash) {
            Magnifier.ILOGUTIL.i(LOG_TAG, "Stopping all active services.");
            try {
                final ActivityManager activityManager = SystemServices.getActivityManager(context);
                final List<ActivityManager.RunningServiceInfo> runningServices = activityManager.getRunningServices(Integer.MAX_VALUE);
                final int pid = Process.myPid();
                for (ActivityManager.RunningServiceInfo serviceInfo : runningServices) {
                    // kill service. 注意排除上报service
//                    if (serviceInfo.pid == pid && !LegacySenderService.class.getName().equals(serviceInfo.service.getClassName()) && !JobSenderService.class.getName().equals(serviceInfo.service.getClassName())) {
                      if(serviceInfo.pid == pid) {
                        try {
                            final Intent intent = new Intent();
                            intent.setComponent(serviceInfo.service);
                            context.stopService(intent);
                        } catch (SecurityException e) {
                            Magnifier.ILOGUTIL.e(LOG_TAG, "Unable to stop Service " + serviceInfo.service.getClassName() + ". Permission denied.");
                        }
                    }
                }
            } catch (SystemServices.ServiceNotReachedException e) {
                Magnifier.ILOGUTIL.exception(LOG_TAG, "Unable to stop services", e);
            }
        }
    }

    private void killProcessAndExit() {
        Magnifier.ILOGUTIL.w(LOG_TAG, "kill process and exit.");
        Process.killProcess(Process.myPid());
        System.exit(10);
    }
}
