package com.tencent.qapmsdk.crash.collector;

import android.content.Context;
import android.support.annotation.NonNull;

import com.tencent.qapmsdk.crash.builder.ReportBuilder;
import com.tencent.qapmsdk.crash.config.CoreConfiguration;
import com.tencent.qapmsdk.crash.data.CrashReportData;
import com.tencent.qapmsdk.crash.plugins.Plugin;

public interface Collector extends Plugin {

    /**
     * Execute collection
     *
     * @param context         a context
     * @param config          current Configuration
     * @param reportBuilder   current ReportBuilder
     * @param crashReportData put results here
     * @throws CollectorException if collection failed
     */
    void collect(@NonNull Context context, @NonNull CoreConfiguration config, @NonNull ReportBuilder reportBuilder, @NonNull CrashReportData crashReportData) throws CollectorException;

    /**
     * @return when this collector should be called compared to other collectors
     */
    @NonNull
    Order getOrder();

    enum Order {
        FIRST,
        EARLY,
        NORMAL,
        LATE,
        LAST
    }
}
