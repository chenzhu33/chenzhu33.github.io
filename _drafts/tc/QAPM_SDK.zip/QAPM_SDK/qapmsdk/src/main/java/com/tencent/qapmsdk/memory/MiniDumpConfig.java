package com.tencent.qapmsdk.memory;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.VersionUtils;

class MiniDumpConfig {
    @Nullable
    private volatile static MiniDumpConfig sInstance = null;
    private native void loadMiniDump(int apilevel);
    @NonNull
    private static String TAG = ILogUtil.getTAG(MiniDumpConfig.class);

    private boolean init() {
        if (VersionUtils.checkFileIOCompatibility()) {
            try {
                loadMiniDump(Build.VERSION.SDK_INT);
                return true;            
            } catch (Exception e) {
                Magnifier.ILOGUTIL.exception(TAG, e);
            } catch (UnsatisfiedLinkError e) {
                Magnifier.ILOGUTIL.exception(TAG, e);
            }            
        } else {
            Magnifier.ILOGUTIL.e(TAG, "minidump don't support version: " + Build.VERSION.SDK_INT);
        }
        return false;
    }

    @Nullable
    static MiniDumpConfig getInstance() {
        if (sInstance == null) {
            synchronized (MiniDumpConfig.class) {
                if (sInstance == null) {
                    sInstance = new MiniDumpConfig();
                    if (sInstance.init()) {
                        Magnifier.ILOGUTIL.d(TAG, "minidump load success!");
                    } else {
                        Magnifier.ILOGUTIL.e(TAG, "minidump load failed!");
                        sInstance = null;
                    }
                }
            }
        }
        return sInstance;
    }
}