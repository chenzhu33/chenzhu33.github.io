package com.tencent.qapmsdk.impl.instrumentation;

import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.api.data.TransactionData;
import com.tencent.qapmsdk.impl.harvest.HttpLibType;
import com.tencent.qapmsdk.impl.harvest.RequestMethodType;
import com.tencent.qapmsdk.impl.socket.SocketError;
import com.tencent.qapmsdk.impl.socket.UrlBuilder;
import com.tencent.qapmsdk.impl.util.StringUtil;
import com.tencent.qapmsdk.socket.util.NetworkUtils;

import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

public final class QAPMTransactionState {
    private final static String TAG = "QAPM_Impl_QAPMTransactionState";
    public volatile boolean hasParseUrlParams = false;
    public static final int URLLIMIT = 1024;
    private String url;
    private String methodType;
    private int statusCode;
    private int errorCode;
    private long bytesSent;
    private long bytesReceived;
    private long startTime;
    private long endTime;
    private String appData;
    private String carrier;
    private State state;
    private String contentType;
    private TransactionData transactionData;
    private String exception = null;
    private String formattedUrlParams = null;
    private String urlParams = null;
    private UrlBuilder urlBuilder = new UrlBuilder();
    private String addressAllStr = "";
    private boolean inQueue = false;
    private RequestMethodType requestMethod;
    private HttpLibType httpLibType;
    private int tyIdRandomInt;
    private int dnsElapse;
    private String ipList;
    private String ipAddress;
    private int port;
    private int tcpHandShakeTime;
    private int firstPacketPeriod = -1;
    private int sslHandShakeTime;
    private boolean isStatusCodeCalled;
    private boolean controllerDispatch;
    private int connectType;
    private String cdnVendorName;
    private long requestEndTime;
    private long responseStartTime;
    private int appPhase;
    private String userActionId;
    private int queueTime;
    private long queueTimeStamp;
    private String allGetRequestParams;
    public ConcurrentHashMap<String, String> requestHeaderParam = new ConcurrentHashMap();
    public HashMap<String, Object> responseHeaderParam = new HashMap();

    public void setDnsElapse(int dnsElapse) {
        this.dnsElapse = dnsElapse;
    }

    public void setQueueTime(int queueTime) {
        this.queueTime = queueTime;
    }

    public int getQueueTime() {
        return this.queueTime;
    }

    public long getQueueTimeStamp() {
        return this.queueTimeStamp;
    }

    public void setQueueTimeStamp(long queueTimeStamp) {
        this.queueTimeStamp = queueTimeStamp;
    }

    public String getAllGetRequestParams() {
        return this.allGetRequestParams;
    }

    public void setAllGetRequestParams(String allGetRequestParams) {
        this.allGetRequestParams = allGetRequestParams;
    }

    public String getUserActionId() {
        return this.userActionId;
    }

    public void setUserActionId(String userActionId) {
        this.userActionId = userActionId;
    }

    public int getAppPhase() {
        return this.appPhase;
    }

    public void setAppPhase(int appPhase) {
        this.appPhase = appPhase;
    }

    public int getConnectType() {
        return this.connectType;
    }

    public void setConnectType(int connectType) {
        this.connectType = connectType;
    }

    public String getCdnVendorName() {
        return this.cdnVendorName;
    }

    public void setCdnVendorName(String cdnVendorName) {
        this.cdnVendorName = cdnVendorName;
    }

    public boolean isControllerDispatch() {
        return this.controllerDispatch;
    }

    public void setControllerDispatch(boolean controllerDispatch) {
        this.controllerDispatch = controllerDispatch;
    }

    public void setRequestMethod(RequestMethodType request) {
        this.requestMethod = request;
    }

    public String getRequestMethod() {
        return this.requestMethod.name();
    }

    public RequestMethodType getRequestMethodType() {
        return this.requestMethod;
    }

    public String getUrlParams() {
        return this.urlParams;
    }

    public void setUrlParams(String urlParams) {
        this.urlParams = urlParams;
    }

    public String getFormattedUrlParams() {
        return this.formattedUrlParams;
    }

    public long getStartTime() {
        return this.startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public void setFormattedUrlParams(String formattedUrlParams) {
        if (this.urlParams != null && !this.urlParams.isEmpty()) {
            if (!formattedUrlParams.isEmpty()) {
                formattedUrlParams = this.urlParams + "&" + formattedUrlParams;
            } else {
                formattedUrlParams = this.urlParams;
            }
        }

        if (formattedUrlParams.endsWith("&")) {
            formattedUrlParams = formattedUrlParams.substring(0, formattedUrlParams.length() - 1);
        }

        if (formattedUrlParams != null && formattedUrlParams.length() > 1024) {
            this.formattedUrlParams = formattedUrlParams.substring(0, 1024);
        } else {
            this.formattedUrlParams = formattedUrlParams;
        }

        this.hasParseUrlParams = true;
    }

    public String toString() {
        StringBuilder var1 = new StringBuilder();
        var1.append("url:" + this.url);
        var1.append("statusCode:" + this.statusCode);
        var1.append("errorCode:" + this.errorCode);
        var1.append("bytesSent:" + this.bytesSent);
        var1.append("bytesReceived:" + this.bytesReceived);
        var1.append("startTime:" + this.startTime);
        var1.append("endTime:" + this.endTime);
        var1.append("appData:" + this.appData);
        var1.append("carrier:" + this.carrier);
        var1.append("state:" + this.state.ordinal());
        var1.append("contentType:" + this.contentType);
        if (this.transactionData != null) {
            var1.append("trancastionData:" + this.transactionData.toString());
        }

        if (this.formattedUrlParams != null) {
            var1.append("formattedUrlParams:" + this.formattedUrlParams);
        }

        var1.append("Requestmethodtype:" + this.requestMethod);
        var1.append("httplibType:" + this.httpLibType);
        var1.append("urlBuilder:" + this.urlBuilder);
        return var1.toString();
    }

    public QAPMTransactionState() {
        try {
            this.startTime = System.currentTimeMillis();
            this.tcpHandShakeTime = -1;
            this.sslHandShakeTime = -1;
            this.carrier = "Other";
            this.state = State.READY;
            this.errorCode = SocketError.OK.getExceptionValue();
            this.requestMethod = RequestMethodType.GET;
            this.httpLibType = HttpLibType.URLConnection;
            this.dnsElapse = 0;
            this.ipList = "";
            this.ipAddress = "";
            this.isStatusCodeCalled = false;
            Magnifier.ILOGUTIL.d(TAG, "QAPMTransactionState : ID----- " , String.valueOf(Thread.currentThread().getId()) , ">..<" , "name : " , Thread.currentThread().getName());
//            this.setTraces();
        } catch (Exception e2) {
            Magnifier.ILOGUTIL.e(TAG, "error init QAPMTransactionState e:" , e2.getMessage());
        }

    }

    public QAPMTransactionState(boolean type) {
        try {
            this.startTime = System.currentTimeMillis();
            this.tcpHandShakeTime = -1;
            this.sslHandShakeTime = -1;
            this.carrier = "Other";
            this.state = State.READY;
            this.errorCode = SocketError.OK.getExceptionValue();
            this.requestMethod = RequestMethodType.GET;
            this.httpLibType = HttpLibType.URLConnection;
            this.dnsElapse = 0;
            this.ipList = "";
            this.ipAddress = "";
            this.isStatusCodeCalled = false;
            if (!type) {
//                this.setTraces();
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.e(TAG, "error init QAPMTransactionState e:" , e.getMessage());
        }

    }

//    public void setTraces() {
//        QAPMTraceUnit var1 = new QAPMTraceUnit("", e.b.ordinal());
//        this.userActionId = com.networkbench.agent.impl.b.a.b.b(var1);
//        QAPMTraceEngine.notifyObserverAsyncEnterMethod(var1);
//    }

    public State getState() {
        return this.state;
    }

    public void setState(int st) {
        if (st == State.READY.ordinal()) {
            this.state = State.READY;
        } else if (st == State.SENT.ordinal()) {
            this.state = State.SENT;
        } else if (st == State.COMPLETE.ordinal()) {
            this.state = State.COMPLETE;
        }

    }

    public void setCarrier(String carrier) {
        if (!this.isSent()) {
            this.carrier = carrier;
        } else {
            Magnifier.ILOGUTIL.e(TAG, "setCarrier(...) called on TransactionState in " , this.state.toString() , " state");
        }

    }

    public void setAppData(String appData) {
        if (!this.isComplete()) {
            this.appData = appData;
            if ("".equals(appData)) {
                return;
            }
        } else {
            Magnifier.ILOGUTIL.e(TAG, "setAppData(...) called on TransactionState in " , this.state.toString() , " state");
        }

    }

    public String getAppData() {
        return this.appData;
    }

    public int getTcpHandShakeTime() {
        return this.tcpHandShakeTime;
    }

    public void setTcpHandShakeTime(int tcpHandShakeTime) {
        this.tcpHandShakeTime = tcpHandShakeTime;
    }

    public int getSslHandShakeTime() {
        return this.sslHandShakeTime;
    }

    public void setSslHandShakeTime(int sslHandShakeTime) {
        this.sslHandShakeTime = sslHandShakeTime;
    }

    public int getFirstPacketRecived() {
        return (int)(this.responseStartTime - this.requestEndTime);
    }

    public String getMethodType() {
        return this.methodType;
    }

    public void setMethodType(String methodType) {
        this.methodType = methodType;
    }

    public void setAddress(String address) {
        this.urlBuilder.setHostAddress(address);
    }

    public void setAddressAllStr(String addressAllStr) {
        this.addressAllStr = addressAllStr;
    }

    public String getAddressAllStr() {
        return this.addressAllStr;
    }

    public void setPort(int port) {
        this.urlBuilder.setHostPort(port);
    }

    public void setHttpPath(String httpPath) {
        this.urlBuilder.setHttpPath(httpPath);
    }

    public void setScheme(UrlBuilder.Scheme scheme) {
        this.urlBuilder.setScheme(scheme);

    }

    public String getScheme() {
        return this.urlBuilder.getScheme().getName();
    }

    public String getHttpPath() {
        return this.urlBuilder.getHttpPath();
    }

    public void setHost(String host) {
        this.urlBuilder.setHostname(host);
    }

    public void setUrlValue(String url) {
        if (url == null) {
            this.url = "";
        } else {
            this.url = url;
        }

    }

    public void setUrl(String urlString) {
        String url = StringUtil.changeUrl(urlString);
        if (url != null) {
            if (url != null && url.length() > 1024) {
                url = url.substring(0, 1024);
            }

            if (!this.isSent()) {
                this.url = url;
            } else {
                Magnifier.ILOGUTIL.e(TAG, "setUrl(...) called on TransactionState in " , this.state.toString() , " state");
            }

        }
    }

    public String getUrl() {
        return this.url;
    }

    public boolean isSent() {
        return this.state.ordinal() >= State.SENT.ordinal();
    }

    public boolean isComplete() {
        return this.state.ordinal() >= State.COMPLETE.ordinal();
    }

    public void setStatusCode(int statusCode) {
        if (!this.isComplete()) {
            this.statusCode = statusCode;
            if (statusCode == 200) {
                Magnifier.ILOGUTIL.d(TAG, "set status code:" , String.valueOf(statusCode));
            }
        } else {
            this.statusCode = statusCode;
            Magnifier.ILOGUTIL.e(TAG, "setStatusCode(...) called on TransactionState in " , this.state.toString() , " state");
        }

    }

    public void markAsEnqueue() {
        this.inQueue = true;
    }

    public boolean ifInQueue() {
        return this.inQueue;
    }

    public int getStatusCode() {
        return this.statusCode;
    }

    public boolean isError() {
        return this.statusCode >= 400 || this.statusCode == -1;
    }

    public void setErrorCode(int errorCode, String exception) {
        if (!this.isComplete()) {
            this.errorCode = errorCode;
            this.exception = exception;
            Magnifier.ILOGUTIL.d(TAG, "errorCode:" , String.valueOf(this.errorCode) , ", errorInfo:" , this.exception);
        } else {
            if (this.transactionData != null) {
                this.transactionData.setErrorCode(errorCode);
            }

            Magnifier.ILOGUTIL.e(TAG, "setErrorCode(...) called on TransactionState in " , this.state.toString() , " state");
        }

    }

    public int getErrorCode() {
        return this.errorCode;
    }

    public long getBytesSent() {
        return this.bytesSent;
    }

    public void setBytesSent(long bytesSent) {
        if (!this.isComplete()) {
            Magnifier.ILOGUTIL.d(TAG, String.valueOf(bytesSent) , " bytes sent");
            this.bytesSent = bytesSent;
            this.state = State.SENT;
        } else {
            Magnifier.ILOGUTIL.e(TAG, "setBytesSent(...) called on TransactionState in " , this.state.toString() , " state");
        }

    }

    public void setBytesSentAfterComplete(long bytesSent) {
        Magnifier.ILOGUTIL.d(TAG, "After Complete " , String.valueOf(bytesSent) , " bytes sent.");
        this.bytesSent = bytesSent;
        this.state = State.SENT;
    }

    public void setBytesReceived(long bytesReceived) {
        if (!this.isComplete()) {
            this.bytesReceived = bytesReceived;
            Magnifier.ILOGUTIL.d(TAG, String.valueOf(bytesReceived) , "bytes received");
        } else {
            Magnifier.ILOGUTIL.e(TAG, "setBytesReceived(...) called on TransactionState in " , this.state.toString() , " state");
        }

    }

    public long getBytesReceived() {
        return this.bytesReceived;
    }

    public HttpLibType getHttpLibType() {
        return this.httpLibType;
    }

    public void setHttpLibType(HttpLibType httpLibType) {
        this.httpLibType = httpLibType;
    }

    public TransactionData end() {
        if (!this.isComplete()) {
            this.state = State.COMPLETE;
            this.endTime = System.currentTimeMillis();
        }

        return this.toTransactionData();
    }

    private TransactionData toTransactionData() {
        if (!this.isComplete()) {
            Magnifier.ILOGUTIL.e(TAG, "toTransactionData() called on incomplete TransactionState");
        }

        if (this.url == null) {
            Magnifier.ILOGUTIL.d(TAG, "Attempted to convert a TransactionState instance with no URL into a TransactionData");
            return null;
        } else {
            if (this.transactionData == null) {
                this.transactionData = new TransactionData(this.url, this.carrier, this.startTime, (int)(this.endTime - this.startTime), this.statusCode, this.errorCode, this.bytesSent, this.bytesReceived, this.appData, this.formattedUrlParams, this.urlParams, this.requestMethod, this.httpLibType, this.dnsElapse, this.ipAddress, this.tcpHandShakeTime, this.sslHandShakeTime, this.firstPacketPeriod, this.cdnVendorName, this.contentType, this.appPhase, this.userActionId, this.allGetRequestParams, this.queueTime);
            }

            this.setOtherTimeInfo(this.transactionData);
            return this.transactionData;
        }
    }

    private void setOtherTimeInfo(TransactionData actionData) {
        if (null != actionData && this.url != null) {
            //todo:整合数据
            String host = StringUtil.getHostFromUrl(this.url);
//            if (this.url.startsWith("https") && !TextUtils.isEmpty(host)) {
//                actionData.setSslHandShakeTime(q.b(host));
//            }
//
//            Integer var3 = q.a(host);
//            if (var3 != null) {
//                actionData.setDnsElapse(var3);
//                actionData.addTime(var3);
//            }
//
//            if (!TextUtils.isEmpty(host)) {
//                actionData.setConnectPeriod(p.a(host));
//            }
//
//            if (!TextUtils.isEmpty(host)) {
//                actionData.setHostAddress(p.b(host));
//                actionData.setFirstPackageTime(q.a().c(host));
//                actionData.setTotalSocketTime(q.a().d(host));
//            }
//
//            if (this.httpLibType == HttpLibType.HttpClient) {
//                actionData.setHostAddress(p.c(this.addressAllStr));
//                m var4 = q.a().e(this.addressAllStr);
//                if (null != var4) {
//                    actionData.setfirstPackageTime(var4.a());
//                    actionData.setTotalSocketTime(var4.b());
//                }
//
//                actionData.setHostAddress(p.d(this.addressAllStr));
//            }

            this.checkActionData(host, actionData);
        }
    }

    private void checkActionData(String host, TransactionData actionData) {
        if (actionData.getSslHandShakeTime() > actionData.getTime()) {
            actionData.setSslHandShakeTime(-1);
        }

        if (actionData.getTcpHandShakeTime() > actionData.getTime()) {
            actionData.setTcpHandShakeTime(-1);
        }

        if (this.countHttpTime(actionData)) {
            actionData.setSslHandShakeTime(-1);
            actionData.setTcpHandShakeTime(-1);
            actionData.setDnsElapse(-1);
            if (actionData.getTime() < actionData.getFirstPackageTime()) {
                actionData.setFirstPackageTime(actionData.getTime());
            }
        }

    }

    private boolean countHttpTime(TransactionData actionData) {
        if (actionData == null) {
            return false;
        } else {
            return actionData.getSslHandShakeTime() + actionData.getTcpHandShakeTime() + actionData.getFirstPackageTime() + actionData.getDnsElapse() >= actionData.getTime();
        }
    }

    public String getContentType() {
        return this.contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getException() {
        return this.exception;
    }

    public void setException(String exception) {
        this.exception = exception;
    }

    public int getTyIdRandomInt() {
        return this.tyIdRandomInt;
    }

    public void setTyIdRandomInt(int tyIdRandomInt) {
        this.tyIdRandomInt = tyIdRandomInt;
    }

    public void setNewUrlParams(String newUrlParams) {
        this.urlParams = newUrlParams;
    }

    private static enum State {
        READY,
        SENT,
        COMPLETE;
    }
}
