/*
 * Copyright (c) 2017, weishu
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tencent.qapmsdk.io.art;

import android.os.Build;
import android.support.annotation.NonNull;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.io.art.arch.Arm64;
import com.tencent.qapmsdk.io.art.arch.Arm64ForM;
import com.tencent.qapmsdk.io.art.arch.ShellCode;
import com.tencent.qapmsdk.io.art.arch.Thumb2;
import com.tencent.qapmsdk.io.art.method.ArtMethod;
import com.tencent.qapmsdk.common.VersionUtils;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Hook Center.
 */
public final class MethodHook {
    private static final String TAG = "MethodHook";

    private static final Map<String, ArtMethod> backupMethodsMapping = new ConcurrentHashMap<String, ArtMethod>();

    private static final Map<Long, MethodInfo> originSigs = new ConcurrentHashMap<Long, MethodInfo>();

    private static final Map<Long, Trampoline> scripts = new HashMap<Long, Trampoline>();


    private static ShellCode ShellCode;
    public static boolean epicHook = false;

    static {
        boolean isArm = true; // TODO: 17/11/21 TODO
        int apiLevel = Build.VERSION.SDK_INT;
        if (isArm) {
            if (VersionUtils.is64Bit()) {
                switch (apiLevel) {
                    case 23:
                        ShellCode = new Arm64ForM();
                        epicHook = true;
                        break;
                    case 24:
                    case 25:
                    case 26:
                        ShellCode = new Arm64();
                        epicHook = true;
                        break;
                }
            } else if (VersionUtils.isThumb2()) {
                ShellCode = new Thumb2();
                epicHook = true;
            } else {
                // todo ARM32
            }
        }
        if (ShellCode == null) {
            Magnifier.ILOGUTIL.e(TAG, "Do not support this ARCH now!! API LEVEL:" + apiLevel);
        }
//        MagnifierSDK.ILOGUTIL.i(TAG, "Using: " + ShellCode.getName());
    }

    public static boolean hookMethod(Constructor<?> origin) {
        return hookMethod(ArtMethod.of(origin));
    }

    public static boolean hookMethod(Method origin) {
        ArtMethod artOrigin = ArtMethod.of(origin);
        return hookMethod(artOrigin);
    }

    private static boolean hookMethod(ArtMethod artOrigin) {

        MethodInfo methodInfo = new MethodInfo();
        methodInfo.isStatic = Modifier.isStatic(artOrigin.getModifiers());
        final Class<?>[] parameterTypes = artOrigin.getParameterTypes();
        if (parameterTypes != null) {
            methodInfo.paramNumber = parameterTypes.length;
            methodInfo.paramTypes = parameterTypes;
        } else {
            methodInfo.paramNumber = 0;
            methodInfo.paramTypes = new Class<?>[0];
        }

        methodInfo.returnType = artOrigin.getReturnType();
        methodInfo.method = artOrigin;
        originSigs.put(artOrigin.getAddress(), methodInfo);

        artOrigin.ensureResolved();

        //String identifier = artOrigin.getIdentifier();

        long originEntry = artOrigin.getEntryPointFromQuickCompiledCode();
        if (originEntry == ArtMethod.getQuickToInterpreterBridge()) {
            Magnifier.ILOGUTIL.w(TAG, "this method is not compiled, compile it now. current entry: 0x" + Long.toHexString(originEntry));
            boolean ret = artOrigin.compile();
            if (ret) {
                originEntry = artOrigin.getEntryPointFromQuickCompiledCode();
                Magnifier.ILOGUTIL.i(TAG, "compile method success, new entry: 0x" + Long.toHexString(artOrigin.getEntryPointFromQuickCompiledCode()));
            } else {
                Magnifier.ILOGUTIL.e(TAG, "compile method failed...");
                return false;
                // return hookInterpreterBridge(artOrigin);
            }
        }

        ArtMethod backupMethod = artOrigin.backup();

//        Magnifier.ILOGUTIL.i(TAG, "backup method address:" + Debug.addrHex(backupMethod.getAddress()));
//        Magnifier.ILOGUTIL.i(TAG, "backup method entry :" + Debug.addrHex(backupMethod.getEntryPointFromQuickCompiledCode()));

        ArtMethod backupList = getBackMethod(artOrigin);
        if (backupList == null) {
            setBackMethod(artOrigin, backupMethod);
        }


        final SafeLock lock = SafeLock.obtain(originEntry);
        synchronized (lock){
            if (!scripts.containsKey(originEntry)) {
                scripts.put(originEntry, new Trampoline(ShellCode, artOrigin));
            }
            Trampoline trampoline = scripts.get(originEntry);

            boolean ret = trampoline.install(artOrigin);
            return ret;
        }


    }

    /*
    private static boolean hookInterpreterBridge(ArtMethod artOrigin) {

        String identifier = artOrigin.getIdentifier();
        ArtMethod backupMethod = artOrigin.backup();

        MagnifierSDK.ILOGUTIL.d(TAG, "backup method address:" + Debug.addrHex(backupMethod.getAddress()));
        MagnifierSDK.ILOGUTIL.d(TAG, "backup method entry :" + Debug.addrHex(backupMethod.getEntryPointFromQuickCompiledCode()));

        List<ArtMethod> backupList = backupMethodsMapping.get(identifier);
        if (backupList == null) {
            backupList = new LinkedList<ArtMethod>();
            backupMethodsMapping.put(identifier, backupList);
        }
        backupList.add(backupMethod);

        long originalEntryPoint = ShellCode.toMem(artOrigin.getEntryPointFromQuickCompiledCode());
        MagnifierSDK.ILOGUTIL.d(TAG, "originEntry Point(bridge):" + Debug.addrHex(originalEntryPoint));

        originalEntryPoint += 16;
        MagnifierSDK.ILOGUTIL.d(TAG, "originEntry Point(offset8):" + Debug.addrHex(originalEntryPoint));

        if (!scripts.containsKey(originalEntryPoint)) {
            scripts.put(originalEntryPoint, new Trampoline(ShellCode, artOrigin));
        }
        Trampoline trampoline = scripts.get(originalEntryPoint);

        boolean ret = trampoline.install();
        MagnifierSDK.ILOGUTIL.i(TAG, "hook Method result:" + ret);
        return ret;

    }*/

    public synchronized static ArtMethod getBackMethod(ArtMethod origin) {
        String identifier = origin.getIdentifier();
        return backupMethodsMapping.get(identifier);
    }

    public static synchronized void setBackMethod(ArtMethod origin, ArtMethod backup) {
        String identifier = origin.getIdentifier();
        backupMethodsMapping.put(identifier, backup);
    }


    public static MethodInfo getMethodInfo(long address) {
        return originSigs.get(address);
    }

//    public static int getQuickCompiledCodeSize(ArtMethod method) {

//        long entryPoint = ShellCode.toMem(method.getEntryPointFromQuickCompiledCode());
//        long sizeInfo1 = entryPoint - 4;
//        byte[] bytes = MethodHookNative.get(sizeInfo1, 4);
//        int size = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).getInt();
//        MagnifierSDK.ILOGUTIL.d(TAG, "getQuickCompiledCodeSize: " + size);
//        return size;
//    }

    public static class MethodInfo {
        public boolean isStatic;
        public int paramNumber;
        public Class<?>[] paramTypes;
        public Class<?> returnType;
        public ArtMethod method;

        @Override
        public String toString() {
            return method.toGenericString();
        }
    }



    public static class SafeLock{
        @NonNull
        static Map<Long, SafeLock> sLockPool = new ConcurrentHashMap<>();

        static synchronized SafeLock obtain(long entry){
            if (sLockPool.containsKey(entry)){
                return sLockPool.get(entry);
            }
            else{
                SafeLock lock = new SafeLock();
                sLockPool.put(entry, lock);
                return lock;
            }
        }
    }


}