package com.tencent.qapmsdk.socket.handler;

import android.support.annotation.NonNull;

import com.tencent.qapmsdk.socket.model.SocketInfo;

public interface ITrafficOutputStreamHandler {
    void onOutput(@NonNull byte[] b, int off, int len, SocketInfo socketInfo);
}

