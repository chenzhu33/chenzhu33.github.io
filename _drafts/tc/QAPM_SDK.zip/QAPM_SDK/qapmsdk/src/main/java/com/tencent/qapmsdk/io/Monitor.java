package com.tencent.qapmsdk.io;

abstract class Monitor {
    abstract void start();
    abstract void stop();
}