package com.tencent.qapmsdk.io;

import android.support.annotation.NonNull;

class SQLInfo {
    private long timeStamp;        //时间戳
    private String dbName;         //数据库名称
    private String processName;    //进程名称
    private String threadName;     //线程名称
    private long costTime;         //打开时间
    private String sqlInfo;        //sql语句
    private String stackTrace;     //堆栈信息
    SQLInfo(long time, String db, String process, String thread, long costtime, String sql, String stack) {
        timeStamp = time;
        dbName = db;
        processName = process;
        threadName = thread;
        costTime = costtime;
        sqlInfo = sql.replace(",", "#").replaceAll("[\r\n]", "");
        if (sqlInfo.length() > 256) {
            sqlInfo = sqlInfo.substring(0, 256);
        }
        stackTrace = stack;
    }
    
    @NonNull
    @Override
    public String toString() {
        return new StringBuilder(1500).append(timeStamp).append(",").append(dbName).append(",").append(processName).append(",").append(threadName).append(",").append(costTime).append(",").append(sqlInfo).append(",").append(stackTrace).append("\r\n").toString();
    } 
}