package com.tencent.qapmsdk.crash.plugins;

import android.support.annotation.NonNull;

import com.tencent.qapmsdk.crash.config.CoreConfiguration;

public interface Plugin {

    /**
     * controls if this instance is active
     *
     * @param config the current config
     * @return if this instance should be called
     */
     boolean enabled(@NonNull CoreConfiguration config);
}
