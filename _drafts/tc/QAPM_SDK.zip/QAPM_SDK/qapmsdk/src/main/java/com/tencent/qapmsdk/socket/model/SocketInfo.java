package com.tencent.qapmsdk.socket.model;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.NetworkWatcher;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionStateUtil;

import org.apache.http.auth.AuthenticationException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpResponseException;
import org.apache.http.conn.ConnectTimeoutException;

import java.io.IOException;
import java.net.ConnectException;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.SSLException;

public class SocketInfo {
    private static final String TAG = "QAPM_Socket_SocketInfo";

    public boolean ssl;
    public String url = "";
    public String protocol;
    public String host;
    public String ip = "";
    public int port;
    public String version;
    public String method = "";
    public String path;
    public String fd;
    public int implHashCode;
    public long threadId;
    public String networkType;
    public String contentType = "";
    public long startTimeStamp;
    public long sslTime;
    public long dnsTime;
    public long tcpTime;
    public long duringTime;
    public long firstPacketPeriod;
    public long totalConnectPeriod;
    public long lastWriteStamp;
    public long sendBytes;
    public long receivedBytes;
    public boolean gzip;
    public boolean chunked;
    public long contentLength;
    public int errorCode = 0;
    public int statusCode = 0;
    public int apnType= NetworkWatcher.getApn();

    public Exception exception = null;
    public boolean isEnd;
    public boolean hasSaved = false;

    public Map<String, String> mRequestHeaders = new HashMap<>();
    public Map<String, String> mResponseHeaders = new HashMap<>();


    public static int getErrorCode(Exception e) {
        if (e instanceof IOException) {
            if (QAPMTransactionStateUtil.isSocketECONNRESET(e)) {
                return 911;
            }

            String exceptionMessage = e.getMessage();
            if (e != null && exceptionMessage != null && exceptionMessage.contains("ftruncate failed: ENOENT (No such file or directory)")) {
                return 917;
            }
        }

        if (e instanceof UnknownHostException) {
            return 901;
        } else if (!(e instanceof SocketTimeoutException) && !(e instanceof ConnectTimeoutException)) {
            if (e instanceof ConnectException) {
                return 902;
            } else if (e instanceof MalformedURLException) {
                return 900;
            } else if (e instanceof SSLException) {
                return 908;
            } else if (e instanceof HttpResponseException) {
                return (((HttpResponseException)e).getStatusCode());
            } else if (e instanceof ClientProtocolException) {
                return 904;
            } else if (e instanceof AuthenticationException) {
                return 907;
            } else {
                return -1;
            }
        } else {
            return 903;
        }

    }


    public void resetForOutput() {
        gzip = false;
        chunked = false;
        contentLength = 0;
        mRequestHeaders = new HashMap<>();
        mResponseHeaders = new HashMap<>();
    }

    public void resetForInput() {
        gzip = false;
        chunked = false;
        contentLength = 0;
    }

    public void writeStamp(long lastWriteStamp) {
        this.lastWriteStamp = lastWriteStamp;
        this.isEnd = false;
    }

    public void readStamp(long firstReadTime) {
        if (firstReadTime <= this.lastWriteStamp) {
            Magnifier.ILOGUTIL.d(TAG, "get first package firstReadTime:" , String.valueOf(firstReadTime) , ", lastWriteStamp:" , String.valueOf(this.lastWriteStamp) , ", hostName:" , this.host);
        } else if (firstReadTime - this.lastWriteStamp >= 20000L) {
            Magnifier.ILOGUTIL.d(TAG, "first package is too big, firstReadTime:" , String.valueOf(firstReadTime) , ", lastWriteStamp:" , String.valueOf(this.lastWriteStamp) , ", hostName:" , this.host);
        } else {
            if (!this.isEnd) {
                this.isEnd = true;
                this.firstPacketPeriod = (int)(firstReadTime - this.lastWriteStamp);
            }
            this.totalConnectPeriod = firstReadTime - this.lastWriteStamp;
        }
    }
}

