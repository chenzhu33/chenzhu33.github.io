package com.tencent.qapmsdk.impl.appstate;

public class ConfigurationName {
    public static String betaOn = "betaOn";
    public static String appVersion = "appVersion";

    public ConfigurationName() {
    }
}