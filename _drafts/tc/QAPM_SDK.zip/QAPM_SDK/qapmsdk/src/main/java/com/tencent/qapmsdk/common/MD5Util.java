package com.tencent.qapmsdk.common;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * <b>类描述：</b>通过网络，需要拉取很多的监控app的配置情况,全部以json字符串下发，通过计算字符串的md5值来比较字符串是否相当     <br/>
 * <b>创建人：</b>janksenhu(QQ:799423779)      <br/>
 * <b>修改时间：</b>2013-11-19 下午3:24:56    <br/>
 *
 * @version 1.0.0    <br/>
 */
public class MD5Util {


    public static String getMD5(String source) {
        String result = "";
        if (source == null) {
            return result;
        }
        
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(source.getBytes());
            result = StringUtil.bytes2HexStr(digest.digest());
        } catch (NoSuchAlgorithmException e) {
        }
        return result;
    }
     

}