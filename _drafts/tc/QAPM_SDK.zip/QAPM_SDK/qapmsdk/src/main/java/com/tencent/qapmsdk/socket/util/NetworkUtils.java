package com.tencent.qapmsdk.socket.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.tencent.qapmsdk.socket.TrafficMonitor;

public class NetworkUtils {

    public static String getNetworkType() {
        Context context = TrafficMonitor.config().getApplicationContext();
        if (context == null) {
            return "undefined";
        }
        final ConnectivityManager cm;
        final NetworkInfo info;
        final int type;
        try {
            cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            info = cm.getActiveNetworkInfo();
            if (!info.isConnected()) throw new RuntimeException();
            type = info.getType();
            if (type == ConnectivityManager.TYPE_WIFI) {
                return "wifi";
            } else {
                return "mobile";
            }
        } catch (Throwable tr) {
            return "undefined";
        }
    }
}

