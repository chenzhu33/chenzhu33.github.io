package com.tencent.qapmsdk.sample;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

/**
 * Created by nickyliu on 2018/5/29.
 */

public class BatteryChangedReceiver extends BroadcastReceiver {
    static volatile double temperature = Double.NaN;
    @Override
    public void onReceive(Context context, @Nullable Intent intent) {
        // TODO Auto-generated method stub
        if(intent != null && Intent.ACTION_BATTERY_CHANGED == intent.getAction()){

            temperature = (intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -10000) * 1.0 / 10);
        }
    }

    @NonNull
    public static IntentFilter getFilter() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_BATTERY_CHANGED);
        return filter;
    }

}