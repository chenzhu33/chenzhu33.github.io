package com.tencent.qapmsdk.common;

import android.os.Environment;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * 
 * <b>类描述：</b> 自定义一个Log类，发布的时候只需要设置Debug为false就不会再打印log了    <br/> 
 * <b>创建人：</b>janksenhu(QQ:799423779)      <br/>  
 * <b>修改时间：</b>2016-2-18 下午7:26:19    <br/>
 * @version 1.0.0    <br/>  
 *
 */
public class ILogUtil {
    private volatile static ILogUtil ilu;
    private static final String TAG = ILogUtil.getTAG(ILogUtil.class);
    private static final String LINE_SEPARATOR = System.getProperty("line.separator");
    private static int logQueueSize = 1024;
    

    public static boolean debug = false;
    private static boolean threadRunning = false;
    
    //记录日志写入文件
    @Nullable
    private static BlockingQueue<String> logQueue = null;
    @NonNull
    private static SimpleDateFormat logTimeFormatter = new SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US);
    public native static void setDebugNative(boolean isDebug);
    private ILogUtil(int logLevel) {
        setLogLevel(logLevel);
    }


    //日志级别
    public static int logLevel = 0;
    public static int OFF = 0;
    public static int ERROR = 1;
    public static int WARN = 2;
    public static int INFO = 3;
    public static int DEBUG = 4;
    public static int VERBOS = 5;
    
    public static void setLogLevel(int level) {
        level = (level < OFF) ? OFF : level;
        level = (level > VERBOS) ? VERBOS : level;
        debug = level == DEBUG;
        logLevel = level;

        if (logLevel > OFF) {
            if (threadRunning == false) {
                startWriteLogThread();
            }
            if (logQueue == null) {
                logQueue = new LinkedBlockingQueue<String>(logQueueSize);
            }
        }
    }

    
    /**
     * 单例
     * @param logLevel
     * @return
     */
    public static ILogUtil getInstance(int logLevel) {
        if (null == ilu) {
            synchronized(ILogUtil.class) {
                if (null == ilu) {
                    ilu = new ILogUtil(logLevel);
                }
            }
        }
        return ilu;
    }
    
    public static String getTAG(Class<?> clazz) {
        return "QAPM_" + clazz.getSimpleName();
    }
    
    /**
     * verbose 级别日志
     */
    public void v(@NonNull String ...args) {
        if (logLevel >= VERBOS) {
            if (args.length == 0)
                return;
            String tag = args[0];
            if (tag == null || args.length <= 1) return;
            StringBuilder logS = new StringBuilder(256);
            for (int i = 1; i < args.length; i++) {
                logS.append(args[i]);
            }
            String msg = logS.toString();
            Log.v(tag, msg);
            logS.delete(0, logS.length());
            logS.append(logTimeFormatter.format(System.currentTimeMillis())).append("    V/").append(tag).append(":    ").append(msg);
            try {
                logQueue.offer(logS.toString());
            } catch (Throwable tr) {
                tr.printStackTrace();
            }
        }
    }

    /**
     * debug 级别日志
     */
    public void d(@NonNull String ...args) {
        if (logLevel >= DEBUG) {
            if (args.length == 0)
                return;
            String tag = args[0];
            if (tag == null || args.length <= 1) return;
            StringBuilder logS = new StringBuilder(256);
            for (int i = 1; i < args.length; i++) {
                logS.append(args[i]);
            }
            String msg = logS.toString();
            Log.d(tag, msg);
            logS.delete(0, logS.length());
            logS.append(logTimeFormatter.format(System.currentTimeMillis())).append("    V/").append(tag).append(":    ").append(msg);
            try {
                logQueue.offer(logS.toString());
            } catch (Throwable tr) {
                tr.printStackTrace();
            }
        }
    }


    /**
     * info 级别日志
     */
    public void i(@NonNull String ...args) {
        if (logLevel >= INFO) {
            if (args.length == 0)
                return;
            String tag = args[0];
            if (tag == null || args.length <= 1) return;
            StringBuilder logS = new StringBuilder(256);
            for (int i = 1; i < args.length; i++) {
                logS.append(args[i]);
            }
            String msg = logS.toString();
            Log.i(tag, msg);
            logS.delete(0, logS.length());
            logS.append(logTimeFormatter.format(System.currentTimeMillis())).append("    V/").append(tag).append(":    ").append(msg);
            try {
                logQueue.offer(logS.toString());
            } catch (Throwable tr) {
                tr.printStackTrace();
            }
        }
    }

    /**
     * warning 级别日志
     */
        public void w(@NonNull String ...args) {
        if (logLevel >= WARN) {
            if (args.length == 0)
                return;
            String tag = args[0];
            if (tag == null || args.length <= 1) return;
            StringBuilder logS = new StringBuilder(256);
            for (int i = 1; i < args.length; i++) {
                logS.append(args[i]);
            }
            String msg = logS.toString();
            Log.w(tag, msg);
            logS.delete(0, logS.length());
            logS.append(logTimeFormatter.format(System.currentTimeMillis())).append("    V/").append(tag).append(":    ").append(msg);
            try {
                logQueue.offer(logS.toString());
            } catch (Throwable tr) {
                tr.printStackTrace();
            }
        }
    }

    /**
     * error 级别日志
     * @param args
     */
    public void e(@NonNull String ...args) {
        if (logLevel >= ERROR) {
            if (args.length == 0)
                return;
            String tag = args[0];
            if (tag == null || args.length <= 1) return;
            StringBuilder logS = new StringBuilder(256);
            for (int i = 1; i < args.length; i++) {
                logS.append(args[i]);
            }
            String msg = logS.toString();
            Log.e(tag, msg);
            logS.delete(0, logS.length());
            logS.append(logTimeFormatter.format(System.currentTimeMillis())).append("    V/").append(tag).append(":    ").append(msg);
            try {
                logQueue.offer(logS.toString());
            } catch (Throwable tr) {
                tr.printStackTrace();
            }
        }
    }

    /**
     *
     * <b>方法描述：</b>可以调用打印异常信息到logcat    <br/>
     * @param tag
     * @param e
     * @exception    <br/>
     * @since  1.0.0
     */
    public void exception(@Nullable String tag, @Nullable Throwable e) {
        if (tag == null || e == null) return;
        if (logLevel >= ERROR) {
            String exc = getThrowableMessage(e);
            Log.e(tag, exc);
            try {
                logQueue.offer(logTimeFormatter.format(System.currentTimeMillis()) + "    Exception/" + tag + ":    " + exc);
            } catch (Throwable tr) {
                tr.printStackTrace();
            }
        }
    }

    /**
     * <b>方法描述：</b>可以调用打印异常信息到logcat    <br/>
     * @param tag
     * @param msg
     * @param e
     */
    public void exception(@Nullable String tag, @Nullable String msg,  @Nullable Throwable e) {
        if (tag == null || e == null) return;
        if (logLevel >= ERROR) {
            Log.e(tag, msg, e);
            try {
                logQueue.offer(logTimeFormatter.format(System.currentTimeMillis()) + "    Exception/" + tag + ":    " + msg + " " + getThrowableMessage(e));
            } catch (Throwable tr) {
                tr.printStackTrace();
            }
        }
    }

    /**
     * 获取异常的堆栈信息
     * @param e
     * @return
     */
    public static String getThrowableMessage(@Nullable Throwable e) {
        if (e == null) return "";
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        return sw.toString();
    }
    
    /**
     * 启动写入日志到文件流程
     * @return
     */
    private static void startWriteLogThread() {
        Handler h = new Handler(ThreadManager.getLogThreadLooper());
        h.post(new Runnable() {
            @Override
            public void run() {
                boolean externalStorageWritable = true;
                try{
                    String state = Environment.getExternalStorageState();
                    if (state.equals(Environment.MEDIA_MOUNTED)) {
                    } else if (state.equals(Environment.MEDIA_MOUNTED) || state.equals(Environment.MEDIA_MOUNTED_READ_ONLY)) {
                        externalStorageWritable = false;
                    } else {
                        externalStorageWritable = false;
                    }
                } catch (Exception e){
                    externalStorageWritable = false;
                }

                if (!externalStorageWritable) {
                    Log.e(TAG, "sdcard could not write");
                    return;
                }

                File logDir = new File(FileUtil.getRootPath() + "/Log");
                if (!logDir.exists()) {
                    logDir.mkdirs();
                }
                
                long lastTimeMillis = 0;
                BufferedWriter writer = null;
                threadRunning = true;
                //每隔2小时创建一个日志文件
                long currentTimeMillis = 0;
                while (logLevel > 0) {
                    try {
                        currentTimeMillis = System.currentTimeMillis();
                        String logItem = logQueue.take();
                        if (null != logItem) {
                            if (currentTimeMillis - lastTimeMillis > 2*3600*1000) {
                                try {
                                    SimpleDateFormat timeFormatter = new SimpleDateFormat("MM.dd.HH", Locale.US);
                                    File logFile = new File(logDir, timeFormatter.format(currentTimeMillis) + ".log");
                                    if (logFile != null && !logFile.exists()) {
                                        logFile.createNewFile();
                                    }
                                    writer = new BufferedWriter(new FileWriter(logFile, true));
                                } catch (Throwable e) {
                                    Log.e(TAG, getThrowableMessage(e));
                                }
                                lastTimeMillis = currentTimeMillis;
                            }
                            if (null != writer) {
                                writer.write(logItem + "\r\n");
                                writer.flush();
                            }
                        } else {
                            Thread.sleep(30 * 1000);
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "write to file occurs exception: " + e.getStackTrace().toString());
                        if (null != writer) {
                            try {
                                writer.close();
                            } catch (IOException e1) {
                                Log.e(TAG, "close log write stream error: " + e1.getStackTrace().toString());
                            }
                        }
                        try {
                            Thread.sleep(5 * 60 * 1000);
                        } catch (InterruptedException e1) {
                        }
                    }
                }
                threadRunning = false;
            }
        });
    }
}