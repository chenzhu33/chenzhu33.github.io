package com.tencent.qapmsdk.sample;

import android.support.annotation.NonNull;

import java.io.IOException;

/**
 * Created by nickyliu on 2018/10/11.
 */

public class StateCollector {

    protected boolean mIsValid = true;
    protected boolean mReachedEof = false;
    protected boolean mHasPeeked = false;
    protected int mChar;
    protected int bufferLen = 1536; //1.5k
    @NonNull
    protected byte[] bufferBytes = new byte[bufferLen];
    protected int curIndex = 0;



    protected long readNumber() {
        boolean complete = false;
        boolean triggered = false;

        long result = 0;
        while (!complete && read()) {
            if (Character.isDigit(mChar)) {
                result = result * 10 + (mChar - '0');
                triggered = true;
            } else {
                complete = true;
            }
        }

        softAssert(triggered);
        return result;
    }

    protected int readHash() {
        boolean complete = false;
        boolean triggered = false;

        int hash = 0;
        while (!complete && read()) {
            if (mChar != ' ') {
                hash = 31 * hash + mChar; // Based off string
                triggered = true;
            } else {
                complete = true;
            }
        }

        softAssert(triggered);
        return hash;
    }

    protected void skipPast(char ch) {
        boolean complete = false;
        while (!complete && read()) {
            if (mChar == ch) {
                complete = true;
            }
        }

        softAssert(complete);
    }


    protected boolean peek() {
        read();
        mHasPeeked = true;
        return !mReachedEof;
    }

    protected boolean read() {
        if (mHasPeeked) {
            mHasPeeked = false;
            return !mReachedEof;
        }

        if (curIndex >= bufferLen){
            return false;
        }
        mChar = bufferBytes[curIndex] != -1 ? bufferBytes[curIndex] & 0xff : -1;
        curIndex++;
        mReachedEof = mChar == -1;
        return !mReachedEof;
    }

    protected boolean softAssert(boolean test) {
        mIsValid &= test;
        return mIsValid;
    }

}
