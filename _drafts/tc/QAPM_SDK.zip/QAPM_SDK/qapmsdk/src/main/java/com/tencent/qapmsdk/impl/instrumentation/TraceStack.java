package com.tencent.qapmsdk.impl.instrumentation;

import java.util.Stack;

public class TraceStack<T> extends Stack<T> {
    private static final long serialVersionUID = -2599047099967913529L;

    public TraceStack() {
    }
}