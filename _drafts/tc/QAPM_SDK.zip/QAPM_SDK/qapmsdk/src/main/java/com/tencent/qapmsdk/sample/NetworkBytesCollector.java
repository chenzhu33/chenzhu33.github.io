package com.tencent.qapmsdk.sample;

import android.annotation.SuppressLint;
import android.support.annotation.Nullable;
import android.support.annotation.VisibleForTesting;

import com.tencent.qapmsdk.Magnifier;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;

/**
 * Created by nickyliu on 2018/6/6.
 */

class NetworkBytesCollector extends StateCollector {

    private static final String TAG = "NetworkBytesCollector";
    private static final String STATS_PATH = "/proc/net/xt_qtaguid/stats";
    private static final long UID = android.os.Process.myUid();

    private static final long WLAN0_HASH = "wlan0".hashCode();
    private static final long[] LOCAL_IFACE_HASHES = { "dummy0".hashCode(), "lo".hashCode(),};

    private RandomAccessFile mQTagUidStatsFile;


    protected void finalize() {
        closeFile();
    }


    @Nullable
    public synchronized long[] getTotalBytes() {
        if (!mIsValid) {
            return null;
        }
        long[] bytes = new long[4];
        Arrays.fill(bytes, 0);


        try {
            if (mQTagUidStatsFile == null) {
                mQTagUidStatsFile = openFile();
            }
            mQTagUidStatsFile.seek(0);
            Arrays.fill(bufferBytes, (byte) -1);
            mQTagUidStatsFile.read(bufferBytes, 0, bufferBytes.length);
            curIndex = 0;

            mReachedEof = false;


            // Skip headers.
            skipPast('\n');

            while (!mReachedEof && mIsValid && peek()) {
                skipPast(' '); // idx
                int ifaceHash = readHash(); // interface
                skipPast(' '); // tag
                long uid = readNumber(); // uid

                boolean isWifi = ifaceHash == WLAN0_HASH;
                boolean isMobile = !isWifi && !isLocalInterface(ifaceHash);

                if (uid != UID || !(isWifi || isMobile)) { // can read other uids for old android versions
                    skipPast('\n');
                    continue;
                }
                skipPast(' '); //cntset

                bytes[0] += readNumber(); //rt_bytes
                bytes[1] += readNumber(); //rt_package
                bytes[2] += readNumber(); //tx_bytes
                bytes[3] += readNumber(); //tx_package
                curIndex += 23; //这里按照最小的模式推算的
                skipPast('\n');
            }
        } catch (Exception ioe) {
            mIsValid = true;
            Magnifier.ILOGUTIL.exception(TAG, ioe);
            closeFile();
            return null;
        }
        mIsValid = true;
        return bytes;


    }

    @VisibleForTesting
    @SuppressLint("InstanceMethodCanBeStatic")
    private RandomAccessFile openFile() throws FileNotFoundException {
        return new RandomAccessFile(STATS_PATH, "r");
    }


    private void closeFile() {
        mIsValid = false;
        if (mQTagUidStatsFile != null) {
            try {
                mQTagUidStatsFile.close();
            } catch (IOException ignored) {
                // Ignore
            }
        }
    }

    private static boolean isLocalInterface(int ifaceHash) {
        for (int i = 0; i < LOCAL_IFACE_HASHES.length; i++) {
            if (ifaceHash == LOCAL_IFACE_HASHES[i]) {
                return true;
            }
        }
        return false;
    }
}
