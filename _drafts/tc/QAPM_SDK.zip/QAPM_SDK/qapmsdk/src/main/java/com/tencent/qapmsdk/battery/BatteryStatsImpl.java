package com.tencent.qapmsdk.battery;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.TrafficStats;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiManager.WifiLock;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Pair;

import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.reporter.ResultObject;
import com.tencent.qapmsdk.battery.HighFrequencyDetector.Action;
import com.tencent.qapmsdk.io.dexposed.DexposedBridge;
import com.tencent.qapmsdk.io.dexposed.XC_MethodHook;
import com.tencent.qapmsdk.io.util.NativeMethodHook;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.common.FileUtil;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.common.ProcessStats;
import com.tencent.qapmsdk.common.ThreadManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class BatteryStatsImpl extends BatteryStats implements Handler.Callback {
    @Nullable
    private volatile static BatteryStatsImpl sInstance = null;
    private static final String TAG = ILogUtil.getTAG(BatteryStatsImpl.class);
    private static boolean DEBUG_ALARM = true;

    private GPS gpsMonitor;
    private CMD cmdMonitor;
    private LOG logMonitor;
    @NonNull
    private Map<String, Integer> logWhiteMap = new HashMap<String, Integer>();
    @NonNull
    private Map<String, Integer> cmdWhiteMap = new HashMap<String, Integer>();

    @Nullable
    public static BatteryStatsImpl getInstance() {
        if (sInstance != null) {
            return sInstance;
        }
        synchronized (BatteryStatsImpl.class) {
            if (sInstance == null) {
                sInstance = new BatteryStatsImpl();
            }
            return sInstance;
        }
    }
    
    public void start() {
        if (subHandler != null) {
            subHandler.sendEmptyMessage(MSG_INIT);
            subHandler.sendEmptyMessage(MSG_HOOK_READY);
        }
    }

    @Nullable
    private Handler subHandler;
    private List<BatteryUsageItem> batteryUsageList;

//    /**
//     * 监控类型
//     */
//    private static final int TYPE_CPU = 0;
//    private static final int TYPE_TRAFFIC = 1;
//    private static final int TYPE_LOG = 2;
//    private static final int TYPE_CMD = 3;
//    private static final int TYPE_WAKE_LOCK = 4;
//    private static final int TYPE_WIFI = 5;
//    private static final int TYPE_GPS = 6;
//
//    private static final String[] TYPE_STRINGS = new String[] { "CPU", "流量", "日志", "命令字", "WakeLock", "WIFI", "GPS" };
//    /**
//     * 异常类型
//     */
//    private static final int EXCEPTION_HIGH_FREQUENCY = 0;
//    private static final int EXCEPTION_TIMEOUT = 1;
//    private static final int EXCEPTION_NOT_CLOSE = 2;
//
//    /**
//     * 严重程度
//     */
//    private static final int LEVEL_LIGHT = 0;
//    private static final int LEVEL_HEAVY = 1;
    /**
     * 开始监控时间
     */
    private long appStartTime;
    private boolean hasAppBg5Min = false;
    
    /**
     * 监控状态相关
     */
    private static final int STATUS_UNINIT = -1;
    private static final int STATUS_NOT_MONITOR = 0;
    private static final int STATUS_RUNNING = 1;
    private int status = STATUS_UNINIT;

    private static final boolean DEBUG_MONITOR_TIME = false;

    private BatteryStatsImpl() {
        subHandler = new Handler(ThreadManager.getBatteryThreadLooper(), this);
    }

    public void setLogWhite(@NonNull List<String> whiteName) {
        for (String white : whiteName) {
            if (white != null && white != "")
                logWhiteMap.put(white,0);
        }
    }

    public void setCmdWhite(@NonNull List<String> whiteName) {
        for (String white : whiteName) {
            if (white != null && white != "")
                cmdWhiteMap.put(white,0);
        }
    }

    // 监控高频LOG时，用户需要自行在打LOG的方法里调用onWriteLog
    public void onWriteLog(String tag, String msg) {
        if (status == STATUS_RUNNING) {
            if (logMonitor != null)
                logMonitor.onWriteLog(tag, msg);
        }
    }

    // 监控高频命令字时，用户需要自行在发送命令字的方法里调用onCmdRequest
    public void onCmdRequest(String cmd) {
        if (status == STATUS_RUNNING) {
            if (cmdMonitor != null)
                cmdMonitor.onCmdRequest(cmd);
        }
    }

    private boolean isHookReady = false;
    private boolean isBackground = false;
    
    // 应用切后台时，手工调用该方法。
    @Override
    public void onAppBackground() {
        if (isBackground) {
            return;
        }
        isBackground = true;
        if (status == STATUS_RUNNING) {
            for (BatteryUsageItem item : batteryUsageList) {
                item.onAppBackground();
            }
            if (!hasAppBg5Min) {
                subHandler.sendEmptyMessageDelayed(MSG_BG_5_MIN, DEBUG_MONITOR_TIME ? 2 * 60 * 1000l : 5 * 60 * 1000l);
            }
        }
        if (!hasCleanLog) {
            subHandler.sendEmptyMessageDelayed(MSG_REPORT_CLEAN_LOG, 200l);
        }
    }
    
    // 应用切前台时，手工调用该方法。
    @Override
    public void onAppForeground() {
        isBackground = false;
        if (status == STATUS_RUNNING) {
            for (BatteryUsageItem item : batteryUsageList) {
                item.onAppForeground();
            }
            subHandler.removeMessages(MSG_BG_5_MIN);
        }
    }

    private static final String ARRAY_SEPERATOR = "\\|";
    private static final String SUB_SEPERATOR = ";";
    private static final String MIN_SEPERATOR = ",";
    private static final int MSG_INIT = 0;
    private static final int MSG_HOOK_READY = 1;
    private static final int MSG_REPORT_CLEAN_LOG = 2;
    private static final int MSG_STOP_MONITOR = 3;
    private static final int MSG_RUN_30_MIN = 4;
    private static final int MSG_BG_5_MIN = 5;
    private static final String KEY_LAST_RANDOM_TIMESTAMP = "last_rand_timestamp";
    private static final String KEY_LAST_RANDOM_FACTOR = "rand_factor";
    private static final String KEY_RANDOM_RESULT = "rand_result";
    private static final String KEY_LAST_REPORT_TIMESTAMP = "battery_report_timestamp";
    private boolean hasCleanLog = false;
    private static final long REPORT_INTERVAL = ILogUtil.debug ? 4 * 60 * 60 * 1000l : 24 * 60 * 60 * 1000l;
    private static final int GRAY_ENLARGE_RATIO = 50;
    // 正式版本，APM上报新架构，统一在底层采样1%。这里放大采样率，目标上报量为75w左右
    private static final int PUB_ENLARGE_RATIO = 300;
    // Sever配置
    //    >19
    //    0.02;0.000025;1;3600;5|5,30,60;5,0;5,1|5,30,60;5,1|2,200,300,20|2,30,40,20|30;3,10;10,120|3,15;10,300|3,15,10,300|1800|1800#0.02;0.000025;#0.06;0.000075
    //    <=19
    //    0.06;0.000075;1;3600;5|5,30,60;5,0;5,1|5,30,60;5,1|2,200,300,20|2,30,40,20|30;3,10;10,120|3,15;10,300|3,15,10,300|1800|1800#0.02;0.000025;#0.06;0.000075|0.1,0.001,10,15,1
    private static final String DEBUG_CONFIG = "1.0;1.0;1;3600;10|5,30,60;5,0;5,1|5,30,60;5,1|2,200,800,20|2,30,40,20|30;3,10;10,120|3,15;10,300|3,15,10,300|1800|1800|" + BackgroundCpuMonitor.DEBUG_CFG + "|#0.02;0.000025;#0.06;0.000075;#";

    @Override
    public boolean handleMessage(@NonNull Message msg) {
        if (msg.what == MSG_INIT) {
            if (status == STATUS_UNINIT) {
                appStartTime = System.currentTimeMillis();
                /**
                 * config的定义<br>
                 * 整体配置(灰度版采样率;正式版采样率;是否上报文件;最大监控时长)|cpu配置|流量配置|日志配置|命令字配置|WakeLock配置|Wifi配置|GPS配置
                 */
                String config = DEBUG_CONFIG;
                boolean enableStats = false;
                String[] cfgArray = null;
                String[] globalCfgs = null;
                try {
                    cfgArray = config.split(ARRAY_SEPERATOR);
                    globalCfgs = cfgArray[0].split(SUB_SEPERATOR);
                    /**
                     * 采样命中逻辑：
                     * 1，外网用户24H采样一次，命中则24H不再重新随机，直到下发配置变更
                     * 2，debug版本用户默认命中，除非文件关闭到监控开关
                     */
                    // 上次采样相关数据
                    long lastRandomTimeStamp = 0l;
                    String lastRandomFactor = "";
                    boolean lastRandomResult = false;
                    if (Magnifier.QAPM_SP != null) {
                        lastRandomTimeStamp = Magnifier.QAPM_SP.getLong(KEY_LAST_RANDOM_TIMESTAMP, 0l);
                        lastRandomFactor = Magnifier.QAPM_SP.getString(KEY_LAST_RANDOM_FACTOR, "");
                        lastRandomResult = Magnifier.QAPM_SP.getBoolean(KEY_RANDOM_RESULT, false);
                    }
                    // dpc配置下发数据
                    String newRandomFactor = ILogUtil.debug ? globalCfgs[0] : globalCfgs[1];
                    // 外发版放大采样倍数：1，更多的json上报；2，文件上报量保持不变
                    try {
                        float factor = Float.valueOf(newRandomFactor);
                        if (ILogUtil.debug) {
                            factor = factor * GRAY_ENLARGE_RATIO;
                        } else {
                            factor = factor * PUB_ENLARGE_RATIO;
                        }
                        newRandomFactor = String.valueOf(factor);
                    } catch(Exception e) {
                        Magnifier.ILOGUTIL.exception(TAG, e);
                    }
                    // 对染色用户增加采样倍数
                    int clrRatio = 1;
                    try {
                        if (ILogUtil.debug) {
                            clrRatio = Integer.valueOf(globalCfgs[4]);
                        }
                    } catch (Exception e) {
                    }
                    // 如果上次采样时间是在24H以前，或者采样率有所变化，都要做重新采样
                    if (Math.abs(System.currentTimeMillis() - lastRandomTimeStamp) > REPORT_INTERVAL || !lastRandomFactor.equals(newRandomFactor)) {
                        enableStats = Math.random() < clrRatio * Float.valueOf(newRandomFactor);
                        Magnifier.editor.putLong(KEY_LAST_RANDOM_TIMESTAMP, System.currentTimeMillis()).putString(KEY_LAST_RANDOM_FACTOR, newRandomFactor).putBoolean(KEY_RANDOM_RESULT, enableStats).commit();
                    } else {
                        enableStats = lastRandomResult;
                    }
                    if (new File(FileUtil.getRootPath() + "/disableBatteryStats").exists() || new File(FileUtil.getRootPath() + "/AutoTestFlag_01").exists()) {
                        enableStats = false;
                    }
                } catch (Exception e) {
                    enableStats = false;
                }
                
                if (enableStats) {
                    batteryUsageList = new ArrayList<BatteryUsageItem>(10);
                    batteryUsageList.add(new CPU(cfgArray[1]));
                    logMonitor = new LOG(cfgArray[3]);
                    batteryUsageList.add(logMonitor);
                    cmdMonitor = new CMD(cfgArray[4]);
                    batteryUsageList.add(cmdMonitor);
                    batteryUsageList.add(new WAKE_LOCK(cfgArray[5]));
                    batteryUsageList.add(new WIFI(cfgArray[6]));
                    gpsMonitor = new GPS(cfgArray[7]);
                    batteryUsageList.add(gpsMonitor);
                    batteryUsageList.add(new NetworkTraffic(cfgArray[2]));
                    BatteryLog.init(PhoneUtil.getProcessName(Magnifier.sApp), appStartTime);
                    for (BatteryUsageItem usageItem : batteryUsageList) {
                        usageItem.onProcessStart();
                        if (isHookReady) {
                            usageItem.onHookReady();
                        }
                    }
                    status = STATUS_RUNNING;
                    // 监控倒计时
                    long monitorTime = Long.parseLong(globalCfgs[3]);
                    monitorTime = (monitorTime + 60) * 1000l;
                    subHandler.sendEmptyMessageDelayed(MSG_STOP_MONITOR, monitorTime);
                    // 30min倒计时
                    subHandler.sendEmptyMessageDelayed(MSG_RUN_30_MIN, DEBUG_MONITOR_TIME ? 3 * 60 * 1000l : 30 * 60 * 1000l);
                } else {
                    status = STATUS_NOT_MONITOR;
                }
            }
        } else if (msg.what == MSG_HOOK_READY) {
            isHookReady = true;
			if (NativeMethodHook.hooksoLoadSign && batteryUsageList != null) {
                for (BatteryUsageItem usageItem : batteryUsageList) {
                    usageItem.onHookReady();
                }
            }
        } else if (msg.what == MSG_REPORT_CLEAN_LOG) {
            String config = DEBUG_CONFIG;
            String[] cfgArray = config.split(ARRAY_SEPERATOR);
            String[] globalCfgs = cfgArray[0].split(SUB_SEPERATOR);
            if (globalCfgs.length >= 3 && globalCfgs[2].equals("1")) {
                // 一段时间上报一次，防止过多文件碎片
                long lastReportTime = 0l;
                if (Magnifier.QAPM_SP != null) {
                    lastReportTime = Magnifier.QAPM_SP.getLong(KEY_LAST_REPORT_TIMESTAMP, 0l);
                }
                // 这里逻辑有点绕。背景：由于json上报量较大，所以监控采样是在之前文件上报的基础上放到了N倍
                // 影响：这里的上报逻辑需要做控制，json必然上报，文件上报需要采样。只要json上报成功则修改时间戳
                if (Math.abs(System.currentTimeMillis() - lastReportTime) > REPORT_INTERVAL) {
                    long timeEnd = appStartTime != 0 ? appStartTime - 60*1000l : System.currentTimeMillis();
                    // 只要超过上报周期，必然上报json文件
                    doQuickJsonReport(lastReportTime, timeEnd);
                    // 文件是否上报，通过采样决定
                    float reportFileRatio = 1.0f;
                    if (ILogUtil.debug) {
                        reportFileRatio = (float) (1.0 / GRAY_ENLARGE_RATIO);
                    } else {
                        reportFileRatio = (float) (1.0 / PUB_ENLARGE_RATIO);
                    }
                    if (Math.random() < reportFileRatio) {
                        Pair<Long, File> toReportRs = BatteryLog.getCommonLogFileForReport(lastReportTime, timeEnd, 10, 3000);
                        if (toReportRs != null && toReportRs.second != null) {
                            Magnifier.ILOGUTIL.i(TAG, "report battery log: ", toReportRs.second.getName());
                            // do report
                            try {
                                JSONObject params = new JSONObject();
                                params.put("fileObj", toReportRs.second.getAbsolutePath());
                                params.put("plugin", Config.PLUGIN_QCLOUD_BATTERY);
                                ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, Magnifier.info.uin);
                                ReporterMachine.addResultObj(ro);
                            } catch (Exception e) {
                                Magnifier.ILOGUTIL.exception(TAG, e);
                            }
                        } else {
                            Magnifier.ILOGUTIL.i(TAG, "no battery log to report");
                        }
                    }
                    // 修改上报时间戳
                    if (Magnifier.editor != null){
                        Magnifier.editor.putLong(KEY_LAST_REPORT_TIMESTAMP, timeEnd).commit();
                    }

                } else {
                    Magnifier.ILOGUTIL.i(TAG, "report interval is short");
                }
            } else {
                Magnifier.ILOGUTIL.i(TAG, "report switch is off");
            }
            BatteryLog.cleanStorage(appStartTime - 2*24*60*60*1000l);
            hasCleanLog = true;
        } else if (msg.what == MSG_STOP_MONITOR) {
            if (batteryUsageList != null) {
                for (BatteryUsageItem usageItem : batteryUsageList) {
                    usageItem.stop();
                }
            }
            status = STATUS_NOT_MONITOR;
        } else if (msg.what == MSG_RUN_30_MIN) {
            if (batteryUsageList != null) {
                try {
                    for (BatteryUsageItem item : batteryUsageList) {
                        item.onProcessRun30Min();
                    }
                } catch (Exception e) {
                    Magnifier.ILOGUTIL.exception(TAG, e);
                }
            }
        } else if (msg.what == MSG_BG_5_MIN) {
            if (batteryUsageList != null) {
                try {
                    for (BatteryUsageItem item : batteryUsageList) {
                        item.onProcessBG5Min();
                    }
                } catch(Exception e) {
                    Magnifier.ILOGUTIL.exception(TAG, e);
                }
            }
            hasAppBg5Min = true;
        }
        return true;
    }
    
    private final void doQuickJsonReport(long lastReportTime, long timeEnd) {
        List<File> reportLogFile = BatteryLog.getReportLogFile(lastReportTime, timeEnd, 200);
        if (reportLogFile == null) {
            Magnifier.ILOGUTIL.e(TAG, "doQuickJsonReport, reportLogFile is null");
            return;
        }
        JSONObject rootJson = new JSONObject();
        int reportFG30MinCount = 0;
        int reportBG5MinCount = 0;
        // 上报tdw，只上报指标项，且只上报一次
        HashMap<String, String> map = new HashMap<String, String>(40);
        try {
            rootJson.put("device", android.os.Build.MODEL);
            rootJson.put("sdk", android.os.Build.VERSION.SDK_INT);
            rootJson.put("uin", Magnifier.info.uin);

            final int MAX_REPORT_COUNT = ILogUtil.debug ? 3 : 2;
            int maxReadLineCount = 500;
            final int MAX_NOT_RELEASE_COUNT = 10;
            int notRelaseCount = 0;
            for (File file : reportLogFile) {
                InputStream is = null;
                BufferedReader br = null;
                try {
                    is = new FileInputStream(file);
                    br = new BufferedReader(new InputStreamReader(is));
                    String line = null;
                    while ((line = br.readLine()) != null) {
                        if (--maxReadLineCount <= 0) {
                            break;
                        }
                        String[] array = line.split("\\|");
                        try {
                            String tag = array[1];
                            // 控制fg上报次数
                            if (tag.startsWith("fg30") && reportFG30MinCount > MAX_REPORT_COUNT) {
                                continue;
                            }
                            // 控制bg上报次数
                            if (tag.startsWith("bg5") && reportBG5MinCount > MAX_REPORT_COUNT) {
                                continue;
                            }
                            // check json array
                            JSONArray jsonArray = null;
                            if (!rootJson.has(tag)) {
                                jsonArray = new JSONArray();
                                rootJson.put(tag, jsonArray);
                            } else {
                                jsonArray = rootJson.getJSONArray(tag);
                            }
                            int timeSec = (int) (Long.valueOf(array[0])/1000);
                            if (tag.equals(CPU.FG_30_CPU) || tag.equals(CPU.BG_5_CPU)) {
                                if (tag.equals(CPU.FG_30_CPU)) {
                                    reportFG30MinCount++;
                                } else if (tag.equals(CPU.BG_5_CPU)) {
                                    reportBG5MinCount++;
                                }
                                JSONObject obj = new JSONObject();
                                obj.put("main", array[2]);
                                obj.put("device", array[3]);
                                obj.put("time", timeSec);
                                if (array.length >= 5) {
                                    obj.put("other", array[3]);
                                }
                                jsonArray.put(obj);

                                if (!map.containsKey(tag + "_main")) {
                                    map.put(tag + "_time", String.valueOf(timeSec));
                                    map.put(tag + "_main", array[2]);
                                    map.put(tag + "_device", array[3]);
                                    int ratio = -1;
                                    try {
                                        long mainJiffies = Long.valueOf(array[2]);
                                        long deviceJiffies = Long.valueOf(array[3]);
                                        ratio = (int) (mainJiffies * 100 / deviceJiffies);
                                    } catch(Exception e) {
                                        Magnifier.ILOGUTIL.exception(TAG, e);
                                    }
                                    map.put(tag + "_ratio", String.valueOf(ratio));
                                }
                            } else if (tag.equals(NetworkTraffic.FG_30_TRF) || tag.equals(NetworkTraffic.BG_5_TRF)) {
                                JSONObject obj = new JSONObject();
                                obj.put("time", timeSec);
                                obj.put("qqRecv", array[2]);
                                obj.put("qqSend", array[3]);
                                obj.put("devRecv", array[4]);
                                obj.put("devSend", array[5]);
                                jsonArray.put(obj);

                                if (!map.containsKey(tag + "_time")) {
                                    map.put(tag + "_time", String.valueOf(timeSec));
                                    map.put(tag + "_qqRecv", array[2]);
                                    map.put(tag + "_qqSend", array[3]);
                                    map.put(tag + "_devRecv", array[4]);
                                    map.put(tag + "_devSend", array[5]);
                                }
                            } else if (tag.equals(CMD.FG_30_CMD_COUNT) || tag.equals(CMD.BG_5_CMD_COUNT)
                                    || tag.equals(LOG.FG_30_LOG_COUNT) || tag.equals(LOG.BG_5_LOG_COUNT)
                                    || tag.equals(GPS.BG_5_SDK_COUNT) || tag.equals(GPS.BG_5_SYS_COUNT)
                                    || tag.equals(GPS.FG_30_SDK_COUNT) || tag.equals(GPS.FG_30_SYS_COUNT)
                                    || tag.equals(WIFI.FG_30_WF_SCAN_COUNT) || tag.equals(WIFI.BG_5_WF_SCAN_COUNT)) {
                                JSONObject obj = new JSONObject();
                                obj.put("time", timeSec);
                                obj.put("count", array[2]);
                                jsonArray.put(obj);

                                if (!map.containsKey(tag + "_count")) {
                                    map.put(tag + "_count", array[2]);
                                    map.put(tag + "_time", String.valueOf(timeSec));
                                }
                            } else if (tag.equals(CMD.FG_30_CMD_ALARM) || tag.equals(CMD.BG_5_CMD_ALARM)
                                    || tag.equals(LOG.FG_30_LOG_ALARM) || tag.equals(LOG.BG_5_LOG_ALARM)) {
                                JSONObject obj = new JSONObject();
                                // log需要特殊处理
                                String content = combineString(array, 2, array.length - 2);
                                if (tag.equals(LOG.FG_30_LOG_ALARM) || tag.equals(LOG.BG_5_LOG_ALARM)) {
                                    obj.put("log", content);
                                } else {
                                    obj.put("cmd", content);
                                }
                                JSONArray detail = new JSONArray();
                                obj.put("detail", detail);
                                String[] subStrArray = array[array.length - 1].split("#");
                                for (String subStr : subStrArray) {
                                    String[] occurArray = subStr.split(",");
                                    if (occurArray != null && occurArray.length > 1) {
                                        JSONObject occurObj = new JSONObject();
                                        occurObj.put("time", Long.valueOf(occurArray[0])/1000);
                                        occurObj.put("count", occurArray[1]);
                                        detail.put(occurObj);
                                    }
                                }
                                jsonArray.put(obj);
                            } else if (tag.equals(WAKE_LOCK.RPT_FG_30_WL_COUNT)
                                    || tag.equals(WAKE_LOCK.RPT_BG_5_WL_COUNT)
                                    || tag.equals(WIFI.FG_30_WF_LOCK_COUNT)
                                    || tag.equals(WIFI.BG_5_WF_LOCK_COUNT)) {
                                JSONObject obj = new JSONObject();
                                obj.put("count", array[2]);
                                obj.put("time", timeSec);
                                obj.put("useTime", Long.valueOf(array[3])/1000);
                                obj.put("useBatteryTime", Long.valueOf(array[4])/1000);
                                jsonArray.put(obj);

                                if (!map.containsKey(tag + "_count")) {
                                    map.put(tag + "_count", array[2]);
                                    map.put(tag + "_time", String.valueOf(timeSec));
                                    map.put(tag + "_useTime", String.valueOf(Long.valueOf(array[3])/1000));
                                    map.put(tag + "_useBatteryTime", String.valueOf(Long.valueOf(array[4])/1000));
                                }
                            } else if (tag.equals(WAKE_LOCK.RPT_BG_5_WL_USE) || tag.equals(WAKE_LOCK.RPT_FG_30_WL_USE)
                                    || tag.equals(WIFI.FG_30_WF_LOCK_DETAIL) || tag.equals(WIFI.BG_5_WF_LOCK_DETAIL)) {
                                JSONObject obj = new JSONObject();
                                obj.put("time", timeSec);
                                obj.put("tag", array[2]);
                                obj.put("useBattery", array[3].equals("1"));
                                obj.put("stack", array[4]);
                                JSONArray detail = new JSONArray();
                                obj.put("detail", detail);
                                String[] subStrArray = array[5].split("#");
                                for (String subStr : subStrArray) {
                                    String[] occurArray = subStr.split(",");
                                    if (occurArray != null && occurArray.length > 1) {
                                        JSONObject occurObj = new JSONObject();
                                        occurObj.put("time", Long.valueOf(occurArray[0])/1000);
                                        occurObj.put("duration", Long.valueOf(occurArray[1])/1000);
                                        detail.put(occurObj);
                                    }
                                }
                                jsonArray.put(obj);
                            } else if (tag.equals(WAKE_LOCK.RPT_WL_NOT_RELEASE) || tag.equals(WAKE_LOCK.RPT_WL_TIMEOUT)
                                    || tag.equals(WIFI.WF_LOCK_NOT_RELEASE)) {
                                if (notRelaseCount > MAX_NOT_RELEASE_COUNT) {
                                    continue;
                                }
                                notRelaseCount ++;
                                JSONObject obj = new JSONObject();
                                obj.put("tag", array[3]);
                                obj.put("stack", array[2]);
                                obj.put("flag", array[4]);
                                obj.put("time", timeSec);
                                obj.put("duration", Long.valueOf(array[5])/1000);
                                jsonArray.put(obj);
                            } else if (tag.equals(GPS.BG_5_SDK_DETAIL) || tag.equals(GPS.BG_5_SYS_DETAIL)
                                    || tag.equals(GPS.FG_30_SDK_DETAIL) || tag.equals(GPS.FG_30_SYS_DETAIL)
                                    || tag.equals(WIFI.FG_30_WF_SCAN_DETAIL) || tag.equals(WIFI.BG_5_WF_SCAN_DETAIL)) {
                                JSONObject obj = new JSONObject();
                                obj.put("tag", array[2]);
                                JSONArray timeArray = new JSONArray();
                                obj.put("timeList", timeArray);
                                String[] subStrArray = array[3].split("#");
                                for (String subStr : subStrArray) {
                                    timeArray.put(Long.valueOf(subStr)/1000);
                                }
                                jsonArray.put(obj);
                            }
                        } catch (Exception e) {
                            Magnifier.ILOGUTIL.e(TAG, "bad line = ", String.valueOf(line), " | ", e.toString());
                        }
                    }
                } catch (Exception e) {
                    Magnifier.ILOGUTIL.exception(TAG, e);
                } finally {
                    if (is != null) {
                        try {
                            is.close();
                        } catch (Exception e1) {
                        }
                    }
                    if (br != null) {
                        try {
                            br.close();
                        } catch (Exception e2) {
                        }
                    }
                }

                if (reportFG30MinCount >= MAX_REPORT_COUNT && reportBG5MinCount >= MAX_REPORT_COUNT) {
                    break;
                }
            }
        } catch (Throwable t) {
            Magnifier.ILOGUTIL.exception(TAG, t);
        }

        if (reportFG30MinCount > 0 || reportBG5MinCount > 0) {
            try {
                JSONObject params = new JSONObject();
                params.put("plugin", Config.PLUGIN_QCLOUD_NEW_BATTERY);
                params.put("batterydata", rootJson);
                ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, Magnifier.info.uin);
                ReporterMachine.addResultObj(ro);
            } catch (Exception e) {
                Magnifier.ILOGUTIL.exception(TAG, e);
            }
        }
    }
    
    private final String combineString(String[] array, int startPos, int endPos) {
        if (startPos == endPos) {
            return array[startPos];
        }
        StringBuilder sb = new StringBuilder((endPos - startPos) * 10);
        for (int i = startPos; i < endPos + 1; i ++) {
            sb.append(array[i]);
            if (i != endPos) {
                sb.append("|");
            }
        }
        return sb.toString();
    }
    
    private void writeReportLog(String...strs) {
        if (status == STATUS_RUNNING) {
            BatteryLog.writeReportLog(System.currentTimeMillis(), strs);
        }
    }

    private void writeCommonLog(int processId, String... strs) {
        if (status != STATUS_RUNNING) {
            return;
        }
        long startupInterval = (System.currentTimeMillis() - appStartTime) / 1000;
        BatteryLog.writeCommonLog(Magnifier.info.uin, processId, startupInterval, strs);
    }
    
    private static final String KEY_ACTION = "key_action";
    private static final int ACTION_CPU = 0;
    private static final int ACTION_GPS_SDK_USE = ACTION_CPU + 1;
    private static final int ACTION_GPS_SYS_USE = ACTION_GPS_SDK_USE + 1;
    private static final int ACTION_WL_USE = ACTION_GPS_SYS_USE + 1;
    private static final int ACTION_WL_NOT_RELEASE = ACTION_WL_USE + 1;
    private static final int ACTION_WL_TIMEOUT = ACTION_WL_NOT_RELEASE + 1;
    private static final int ACTION_LOG_ALARM = ACTION_WL_TIMEOUT + 1;
    private static final int ACTION_CMD_ALARM = ACTION_LOG_ALARM + 1;
    private static final int ACTION_WIFI_SCAN = ACTION_CMD_ALARM + 1;
    private static final int ACTION_WIFI_LOCK_USE = ACTION_WIFI_SCAN + 1;
    private static final int ACTION_WIFI_LOCK_NOT_RELEASE = ACTION_WIFI_LOCK_USE + 1;
    //private static final int ACTION_WIFI_LOCK_TIMEOUT = ACTION_WIFI_LOCK_NOT_RELEASE + 1;
    
    void onOtherProcReport(Bundle params) {
        if (status != STATUS_RUNNING) {
            return;
        }
        try {
            for (BatteryUsageItem usageItem : batteryUsageList) {
                usageItem.onOtherProcReport(params);
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
    }

    public interface IBatteryStatsCallback {
        void onPrintLog(String log);
        void onUsageAlarm(String monitorType, String message, String description);
    }

    private IBatteryStatsCallback callback;

    public void setCallback(IBatteryStatsCallback _callback) {
        callback = _callback;
    }

    private class BatteryUsageItem {
        protected boolean isRunning = true;
        @Nullable
        protected String[][] configArray = null;
        protected boolean isBeforeRun30Min = true;
        protected boolean isAppBackground = false;
        protected boolean isInFirstBG5min = false;

        public BatteryUsageItem(String config) {
            String[] subCfgs = config.split(SUB_SEPERATOR);
            configArray = new String[subCfgs.length][];
            for (int i = 0; i < subCfgs.length; i ++) {
                configArray[i] = subCfgs[i].split(MIN_SEPERATOR);
            }
        }

        public void onProcessStart() {
        }

        public void onAppBackground() {
            isAppBackground = true;
            if (!hasAppBg5Min) {
                isInFirstBG5min = true;
            }
        }

        public void onAppForeground() {
            isAppBackground = false;
            isInFirstBG5min = false;
        }

        public void onHookReady() {
        }
        
        public void onOtherProcReport(Bundle params) {
        }
        
        public void onProcessRun30Min() {
            isBeforeRun30Min = false;
        }
        
        public void onProcessBG5Min() {
            isInFirstBG5min = false;
        }
        
        public void stop() {
            isRunning = false;
        }
    }

    @SuppressLint("UseSparseArrays")
    @SuppressWarnings("unused")
    private class CPU extends BatteryUsageItem implements Handler.Callback {
        // 配置项
        private long DUMP_QQPROC_INTERVAL_1 = 5 * 60 * 1000l;
        private long DUMP_QQPROC_INTERVAL_2 = 30 * 60 * 1000l;
        private long DUMP_QQPROC_INTERVAL_3 = 60 * 60 * 1000l;
        private long DUMP_QQBG_INTERVAL = 5 * 60 * 1000l;
        private int bgCollectCount = 1;
        private long DUMP_OTHER_PROC_INTERVAL = 3 * 60 * 1000l;
        private boolean DUMP_OTHER_PROC_CYCLING = true;

        @Nullable
        private Handler subHandler;
        private long qqBaseUsage;
        private long deviceBaseUsage;
        private long qqBaseUsageOnEnterBg;
        private long deviceBaseUsageOnEnterBg;
        private long enterBGTimeStamp;
        @NonNull
        private Map<Integer, ProcCpu> otherProcMap = new HashMap<Integer, ProcCpu>();
        
        public static final String FG_30_CPU = "fg30Cpu";
        public static final String BG_5_CPU = "bg5Cpu";
        
        private class ProcCpu {
            public int monitorSecs;
            public long cpuUsage;
        }

        public CPU(@NonNull String config) {
            super(config);
            subHandler = new Handler(ThreadManager.getBatteryThreadLooper(), this);
            // 配置示例：5,30,60;5,0;5,1(主进程配置|子进程配置|主进程后台配置)
            if (configArray.length >= 1 && configArray[0].length >= 3) {
                DUMP_QQPROC_INTERVAL_1 = Integer.valueOf(configArray[0][0])*60*1000l;
                DUMP_QQPROC_INTERVAL_2 = Integer.valueOf(configArray[0][1])*60*1000l;
                DUMP_QQPROC_INTERVAL_3 = Integer.valueOf(configArray[0][2])*60*1000l;
            }
            
            if (configArray.length >= 2 && configArray[1].length >= 2) {
                DUMP_QQBG_INTERVAL = Integer.valueOf(configArray[1][0])*60*1000l;
                DUMP_OTHER_PROC_CYCLING = configArray[1][1].equals("1");
            }
            
            if (configArray.length >= 3 && configArray[2].length >= 1) {
                DUMP_QQBG_INTERVAL = Integer.valueOf(configArray[2][0])*60*1000l;
                bgCollectCount = Integer.valueOf(configArray[2][1]);
            }
        }

        @Override
        public void onProcessStart() {
            qqBaseUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
            deviceBaseUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
            Message msg = subHandler.obtainMessage(MSG_FG_TIMER, DUMP_QQPROC_INTERVAL_1);
            subHandler.sendMessageDelayed(msg, DUMP_QQPROC_INTERVAL_1);
            msg = subHandler.obtainMessage(MSG_FG_TIMER, DUMP_QQPROC_INTERVAL_2);
            subHandler.sendMessageDelayed(msg, DUMP_QQPROC_INTERVAL_2);
            msg = subHandler.obtainMessage(MSG_FG_TIMER, DUMP_QQPROC_INTERVAL_3);
            subHandler.sendMessageDelayed(msg, DUMP_QQPROC_INTERVAL_3);
        }

        @Override
        public void onAppBackground() {
            super.onAppBackground();
            if (bgCollectCount > 0) {
                enterBGTimeStamp = System.currentTimeMillis();
                qqBaseUsageOnEnterBg = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
                deviceBaseUsageOnEnterBg = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
                subHandler.sendEmptyMessageDelayed(MSG_BG_TIMER, DUMP_QQBG_INTERVAL);
            }
        }

        @Override
        public void onAppForeground() {
            super.onAppForeground();
            subHandler.removeMessages(MSG_BG_TIMER);
        }
        
        private static final String KEY_PROCESS_ID = "key_process_id";
        private static final String KEY_CPU_USAGE = "key_cpu_usage";
        private static final String KEY_MONITOR_SECS = "key_monitor_secs";
        @Override
        public void onOtherProcReport(@NonNull Bundle params) {
            super.onOtherProcReport(params);
            int action = params.getInt(KEY_ACTION);
            if (action == ACTION_CPU) {
                int processId = params.getInt(KEY_PROCESS_ID);
                long cpuUsage = params.getLong(KEY_CPU_USAGE);
                int monitorSecs = params.getInt(KEY_MONITOR_SECS);
                synchronized(otherProcMap) {
                    ProcCpu procCpu = otherProcMap.get(processId);
                    if (procCpu == null) {
                        procCpu = new ProcCpu();
                        otherProcMap.put(processId, procCpu);
                    }
                    procCpu.cpuUsage += cpuUsage;
                    procCpu.monitorSecs += monitorSecs;
                }
            }
        }

        private static final int MSG_FG_TIMER = 0;
        private static final int MSG_BG_TIMER = 3;

        @Override
        public boolean handleMessage(@NonNull Message msg) {
            if (msg.what == MSG_FG_TIMER) {
                long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
                long deviceUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
                StringBuilder otherProcDes = BatteryLog.getReuseStringBuilder();
                synchronized(otherProcMap) {
                    otherProcDes.ensureCapacity(otherProcMap.size() * 10);
                    for (Integer pid : otherProcMap.keySet()) {
                        if (otherProcDes.length() > 0) {
                            otherProcDes.append("#");
                        }
                        otherProcDes.append("[").append(pid).append(",").append(otherProcMap.get(pid).monitorSecs)
                                .append(",").append(otherProcMap.get(pid).cpuUsage).append("]");
                    }
                }
                int timeSecs = (int) (((Long)msg.obj)/1000);
                Magnifier.ILOGUTIL.i(TAG, "cpu, onStartup " + timeSecs + "sec: " + (appUsage - qqBaseUsage) + "|" + (deviceUsage - deviceBaseUsage) + "|" + otherProcDes.toString());
                writeCommonLog(Magnifier.processId, "cpu|fg|", String.valueOf(timeSecs), "|", String.valueOf(appUsage - qqBaseUsage), "|",
                        String.valueOf(deviceUsage - deviceBaseUsage), "|", otherProcDes.toString());
                if (timeSecs == 30 * 60) {
                    writeReportLog(FG_30_CPU, "|", String.valueOf(appUsage - qqBaseUsage), "|",
                            String.valueOf(deviceUsage - deviceBaseUsage), "|", otherProcDes.toString());
                }
            } else {
                bgCollectCount--;
                if (System.currentTimeMillis() - enterBGTimeStamp < DUMP_QQBG_INTERVAL + 5 * 1000) {
                    long appUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_APP);
                    long deviceUsage = ProcessStats.collectCpuUsage(ProcessStats.ID_DEV);
                    int timeSecs = (int) (DUMP_QQBG_INTERVAL/1000);
                    Magnifier.ILOGUTIL.i(TAG, "cpu, bg" + timeSecs + "sec: " + (appUsage - qqBaseUsageOnEnterBg) + "/"
                            + (deviceUsage - deviceBaseUsageOnEnterBg));
                    writeCommonLog(Magnifier.processId, "cpu|bg|", String.valueOf(timeSecs), "|",
                            String.valueOf(appUsage - qqBaseUsageOnEnterBg), "|",
                            String.valueOf(deviceUsage - deviceBaseUsageOnEnterBg));
                    if (timeSecs == 5 * 60) {
                        writeReportLog(BG_5_CPU, "|", String.valueOf(appUsage - qqBaseUsage), "|",
                                String.valueOf(deviceUsage - deviceBaseUsage));
                    }
                }
            }
            return false;
        }
    }
    
    /**
     * 流量监控不能区分uid，所以子进程不做统计</br> 监控场景：1,主进程前台启动后5分钟/半小时/一小时应用收发流量；2，手Q后台期间流量消耗
     */
    private class NetworkTraffic extends BatteryUsageItem implements Handler.Callback {
        @Nullable
        private Handler subHandler;
        // 配置项
        private long DUMP_QQPROC_INTERVAL_1 = 5 * 60 * 1000l;
        private long DUMP_QQPROC_INTERVAL_2 = 30 * 60 * 1000l;
        private long DUMP_QQPROC_INTERVAL_3 = 60 * 60 * 1000l;
        private long DUMP_QQBG_INTERVAL = 5 * 60 * 1000l;
        private int bgCollectCount = 1;
        public static final String FG_30_TRF = "fg30Trf";
        public static final String BG_5_TRF = "bg5Trf";

        public NetworkTraffic(@NonNull String config) {
            super(config);
            subHandler = new Handler(ThreadManager.getBatteryThreadLooper(), this);
            // 配置示例：5,30,60;5,1
            if (configArray.length >= 1 && configArray[0].length >= 3) {
                DUMP_QQPROC_INTERVAL_1 = Integer.valueOf(configArray[0][0])*60*1000l;
                DUMP_QQPROC_INTERVAL_2 = Integer.valueOf(configArray[0][1])*60*1000l;
                DUMP_QQPROC_INTERVAL_3 = Integer.valueOf(configArray[0][2])*60*1000l;
            }
            if (configArray.length >= 2 && configArray[1].length >= 1) {
                DUMP_QQBG_INTERVAL = Integer.valueOf(configArray[1][0])*60*1000l;
                bgCollectCount = Integer.valueOf(configArray[1][1]);
            }
        }

        private int uid;
        private long qqRxBytesOnAppStart;
        private long qqTxBytesOnAppStart;
        private long deviceRxBytesOnAppStart;
        private long deviceTxBytesOnAppStart;
        private long qqRxBytesOnEnterBG;
        private long qqTxBytesOnEnterBG;
        private long deviceRxBytesOnEnterBG;
        private long deviceTxBytesOnEnterBG;
        private long enterBGTimeStamp;

        @Override
        public void onProcessStart() {
            super.onProcessStart();
            try {
                PackageManager pm = Magnifier.sApp.getPackageManager();
                String pkgName = Magnifier.sApp.getPackageName();
                ApplicationInfo ai = pm.getApplicationInfo(pkgName, PackageManager.GET_META_DATA);
                uid = ai.uid;
            } catch (Throwable t) {
                Magnifier.ILOGUTIL.exception(TAG, t);
            }
            if (uid != 0) {
                qqRxBytesOnAppStart = TrafficStats.getUidRxBytes(uid);
                qqTxBytesOnAppStart = TrafficStats.getUidTxBytes(uid);
                deviceRxBytesOnAppStart = TrafficStats.getTotalRxBytes();
                deviceTxBytesOnAppStart = TrafficStats.getTotalTxBytes();
                Message msg = subHandler.obtainMessage(MSG_FG_TIMER, DUMP_QQPROC_INTERVAL_1);
                subHandler.sendMessageDelayed(msg, DUMP_QQPROC_INTERVAL_1);
                msg = subHandler.obtainMessage(MSG_FG_TIMER, DUMP_QQPROC_INTERVAL_2);
                subHandler.sendMessageDelayed(msg, DUMP_QQPROC_INTERVAL_2);
                msg = subHandler.obtainMessage(MSG_FG_TIMER, DUMP_QQPROC_INTERVAL_3);
                subHandler.sendMessageDelayed(msg, DUMP_QQPROC_INTERVAL_3);
            }
        }

        @Override
        public void onAppBackground() {
            super.onAppBackground();
            if (uid != 0 && bgCollectCount > 0) {
                enterBGTimeStamp = System.currentTimeMillis();
                qqRxBytesOnEnterBG = TrafficStats.getUidRxBytes(uid);
                qqTxBytesOnEnterBG = TrafficStats.getUidTxBytes(uid);
                deviceRxBytesOnEnterBG = TrafficStats.getTotalRxBytes();
                deviceTxBytesOnEnterBG = TrafficStats.getTotalTxBytes();
                subHandler.sendEmptyMessageDelayed(MSG_BG_TIMER, DUMP_QQBG_INTERVAL);
            }
        }

        @Override
        public void onAppForeground() {
            super.onAppForeground();
            subHandler.removeMessages(MSG_BG_TIMER);
        }

        private static final int MSG_FG_TIMER = 0;
        private static final int MSG_BG_TIMER = 3;

        @Override
        public boolean handleMessage(@NonNull Message msg) {
            if (uid == 0) {
                return false;
            }
            if (msg.what == MSG_FG_TIMER) {
                long qqRxBytes = TrafficStats.getUidRxBytes(uid) - qqRxBytesOnAppStart;
                long qqTxBytes = TrafficStats.getUidTxBytes(uid) - qqTxBytesOnAppStart;
                long deviceRxBytes = TrafficStats.getTotalRxBytes() - deviceRxBytesOnAppStart;
                long deviceTxBytes = TrafficStats.getTotalTxBytes() - deviceTxBytesOnAppStart;
                int timeSec = (int) (((Long)msg.obj)/1000);
                StringBuilder sb = new StringBuilder(50);
                sb.append("on startup ").append(timeSec);
                sb.append("secs, network:");
                sb.append(qqRxBytes / 1000).append("/").append(deviceRxBytes / 1000).append("|");
                sb.append(qqTxBytes / 1000).append("/").append(deviceTxBytes / 1000);
                Magnifier.ILOGUTIL.i(TAG, sb.toString());
                writeCommonLog(Magnifier.processId, "nt|fg|", String.valueOf(timeSec), "|", String.valueOf(qqRxBytes), "|",
                        String.valueOf(qqTxBytes), "|", String.valueOf(deviceRxBytes), "|",
                        String.valueOf(deviceTxBytes));
                
                if (timeSec == 30 * 60) {
                    writeReportLog(FG_30_TRF, "|", String.valueOf(qqRxBytes), "|", String.valueOf(qqTxBytes), "|",
                            String.valueOf(deviceRxBytes), "|", String.valueOf(deviceTxBytes));
                }
            } else if (msg.what == MSG_BG_TIMER) {
                bgCollectCount--;
                // 排除系统休眠情况
                if (System.currentTimeMillis() - enterBGTimeStamp < DUMP_QQBG_INTERVAL + 2 * 1000) {
                    long qqRxBytes = TrafficStats.getUidRxBytes(uid) - qqRxBytesOnEnterBG;
                    long qqTxBytes = TrafficStats.getUidTxBytes(uid) - qqTxBytesOnEnterBG;
                    long deviceRxBytes = TrafficStats.getTotalRxBytes() - deviceRxBytesOnEnterBG;
                    long deviceTxBytes = TrafficStats.getTotalTxBytes() - deviceTxBytesOnEnterBG;
                    int timeSecs = (int) (DUMP_QQBG_INTERVAL/1000);
                    StringBuilder sb = new StringBuilder(50);
                    sb.append("onBG").append(timeSecs).append("secs, network:");
                    sb.append(qqRxBytes / 1000).append("/").append(deviceRxBytes / 1000).append("|");
                    sb.append(qqTxBytes / 1000).append("/").append(deviceTxBytes / 1000);
                    Magnifier.ILOGUTIL.i(TAG, sb.toString());
                    writeCommonLog(Magnifier.processId, "nt|bg|", String.valueOf(timeSecs), "|", String.valueOf(qqRxBytes), "|",
                            String.valueOf(qqTxBytes), "|", String.valueOf(deviceRxBytes), "|",
                            String.valueOf(deviceTxBytes));
                    
                    if (timeSecs == 5 * 60) {
                        writeReportLog(BG_5_TRF, "|", String.valueOf(qqRxBytes), "|", String.valueOf(qqTxBytes), "|",
                                String.valueOf(deviceRxBytes), "|", String.valueOf(deviceTxBytes));
                    }
                }
            }
            return false;
        }
    }

    @SuppressWarnings("unused")
    private class LOG extends BatteryUsageItem {
        private int maintainCount = 20;
        private int alarmWriteTime = 50;
        private int alarmBigWriteTime = 100;
        private long monitorInterval = 2000l;

        private HighFrequencyStringDetector detector;
        @NonNull
        private Map<String, HashSet<Pair<Long, Integer>>> fg30MinMap = new HashMap<String, HashSet<Pair<Long, Integer>>>();
        @NonNull
        private Map<String, HashSet<Pair<Long, Integer>>> bg5MinMap = new HashMap<String, HashSet<Pair<Long, Integer>>>();

        private static final String FG_30_LOG_COUNT = "fg30LogCount";
        private static final String FG_30_LOG_ALARM = "fg30LogAlarm";
        private static final String BG_5_LOG_COUNT = "bg5LogCount";
        private static final String BG_5_LOG_ALARM = "bg5LogAlarm";
        
        public LOG(@NonNull String config) {
            super(config);
            // 配置示例：2,40,20
            if (configArray.length >= 1 && configArray[0].length >= 4) {
                monitorInterval = Integer.valueOf(configArray[0][0]) * 1000l;
                alarmWriteTime = Integer.valueOf(configArray[0][1]);
                alarmBigWriteTime = Integer.valueOf(configArray[0][2]);
                maintainCount = Integer.valueOf(configArray[0][3]);
            }
            detector = new HighFrequencyStringDetector(maintainCount, alarmWriteTime);
            logWhiteMap.put("MSF.D.MonitorSocket", 0);
            logWhiteMap.put("Q.msg.MsgProxy|addMsgQueue", 0);
            logWhiteMap.put("Q.db.Cache|writeRunable", 0);
            logWhiteMap.put("Q.msg.MsgProxy|writeRunable", 0);
            logWhiteMap.put("Q.db.Cache|addMsgQueue", 0);
            logWhiteMap.put("SQLiteOpenHelper| getWritableDatabase",0);
            logWhiteMap.put("SQLiteOpenHelper| getReadableDatabase",0);
        }

        private long startMonitorTimeStamp = 0l;

        public void onWriteLog(String tag, String msg) {
            if (!isRunning) {
                detector.clear();
                return;
            }
            if (startMonitorTimeStamp == 0l) {
                startMonitorTimeStamp = SystemClock.uptimeMillis();
            }
            // TODO:看下仅使用msg够不够
            detector.putString(tag + "|" + msg);
            if (SystemClock.uptimeMillis() - startMonitorTimeStamp > monitorInterval) {
                Map<String, Integer> map = detector.getHighFrequencyString();
                startMonitorTimeStamp = 0l;
                detector.clear();
                // 去除白名单日志
                if (map != null) {
                    for (String whiteLog : logWhiteMap.keySet()) {
                        for (Iterator<String> iter = map.keySet().iterator(); iter.hasNext(); ) {
                            if (iter.next().contains(whiteLog)) {
                                iter.remove();
                            }
                        }
                    }
                }
                
                if (map != null && map.size() > 0) {
                    StringBuilder sb = new StringBuilder(map.size() * 20 + 10);
                    int maxCount = 0;
                    String maxLog = null;
                    for (String key : map.keySet()) {
                        if (sb.length() > 0) {
                            sb.append("#");
                        }
                        sb.append("[").append(key).append(",").append(map.get(key)).append("]");
                        if (map.get(key) > maxCount) {
                            maxCount = map.get(key);
                            maxLog = key;
                        }
                        
                        Bundle bundle = new Bundle();
                        bundle.putInt(KEY_ACTION, ACTION_LOG_ALARM);
                        bundle.putString(KEY_LOG, key);
                        bundle.putInt(KEY_COUNT, map.get(key));
                        this.onOtherProcReport(bundle);
                    }
                    writeCommonLog(Magnifier.processId, "log|", sb.toString());
                } else {
                    if (callback != null) {
                        Magnifier.ILOGUTIL.i(TAG, "No high frequnecy log in last 2seconds");
                    }
                }
            }
        }

        private static final String KEY_LOG = "key_log";
        private static final String KEY_COUNT = "key_count";
        @Override
        public void onOtherProcReport(@NonNull Bundle params) {
            if (!isRunning) {
                return;
            }
            int action = params.getInt(KEY_ACTION);
            if (action == ACTION_LOG_ALARM) {
                String log = params.getString(KEY_LOG);
                int count = params.getInt(KEY_COUNT);
                synchronized (fg30MinMap) {
                    if (isBeforeRun30Min) {
                        HashSet<Pair<Long, Integer>> set = fg30MinMap.get(log);
                        if (set == null) {
                            set = new HashSet<Pair<Long, Integer>>();
                            fg30MinMap.put(log, set);
                        }
                        set.add(new Pair<Long, Integer>(System.currentTimeMillis(), count));
                    }
                    if (isAppBackground && isInFirstBG5min) {
                        HashSet<Pair<Long, Integer>> set = bg5MinMap.get(log);
                        if (set == null) {
                            set = new HashSet<Pair<Long, Integer>>();
                            bg5MinMap.put(log, set);
                        }
                        set.add(new Pair<Long, Integer>(System.currentTimeMillis(), count));
                    }
                }
            }
        }
        
        @Override
        public void onAppBackground() {
            super.onAppBackground();
            synchronized (fg30MinMap) {
                bg5MinMap.clear();
            }
        }

        @Override
        public void onProcessRun30Min() {
            super.onProcessRun30Min();
            if (isRunning) {
                synchronized (fg30MinMap) {
                    // 计算高频次数
                    int count = 0;
                    for (HashSet<?> set : fg30MinMap.values()) {
                        count += set.size();
                    }
                    writeReportLog(FG_30_LOG_COUNT, "|", String.valueOf(count));
                    for (String key : fg30MinMap.keySet()) {
                        StringBuilder sb = BatteryLog.getReuseStringBuilder();
                        HashSet<Pair<Long, Integer>> set = fg30MinMap.get(key);
                        int index = 0;
                        for (Pair<Long, Integer> pair : set) {
                            sb.append(pair.first).append(",").append(pair.second);
                            if (++index < set.size()) {
                                sb.append("#");
                            }
                        }
                        writeReportLog(FG_30_LOG_ALARM, "|", key, "|", sb.toString());
                    }
                    fg30MinMap.clear();
                }
            }
        }
        
        @Override
        public void onProcessBG5Min() {
            super.onProcessBG5Min();
            if (isRunning) {
                synchronized (fg30MinMap) {
                    // 计算高频次数
                    int count = 0;
                    for (HashSet<?> set : bg5MinMap.values()) {
                        count += set.size();
                    }
                    writeReportLog(BG_5_LOG_COUNT, "|", String.valueOf(count));
                    for (String key : bg5MinMap.keySet()) {
                        HashSet<Pair<Long, Integer>> set = bg5MinMap.get(key);
                        StringBuilder sb = BatteryLog.getReuseStringBuilder();
                        int index = 0;
                        for (Pair<Long, Integer> pair : set) {
                            sb.append(pair.first).append(",").append(pair.second);
                            if (++index < set.size()) {
                                sb.append("#");
                            }
                        }
                        writeReportLog(BG_5_LOG_ALARM, "|", key, "|", sb.toString());
                    }
                    bg5MinMap.clear();
                }
            }
        }
    }

    private class CMD extends BatteryUsageItem {
        private int maintainCount = 20;
        private int alarmSendTime = 30;
        private int alarmMaxSendTime = 40;
        private long monitorInterval = 2000l;

        private HighFrequencyStringDetector detector;
        @NonNull
        private Map<String, HashSet<Pair<Long, Integer>>> fg30MinMap = new HashMap<String, HashSet<Pair<Long, Integer>>>();
        @NonNull
        private Map<String, HashSet<Pair<Long, Integer>>> bg5MinMap = new HashMap<String, HashSet<Pair<Long, Integer>>>();
        
        private static final String FG_30_CMD_COUNT = "fg30CmdCount";
        private static final String FG_30_CMD_ALARM = "fg30CmdAlarm";
        private static final String BG_5_CMD_COUNT = "bg5CmdCount";
        private static final String BG_5_CMD_ALARM = "bg5CmdAlarm";

        public CMD(@NonNull String config) {
            super(config);
            // 配置示例：2,10,20
            if (configArray.length >= 1 && configArray[0].length >= 4) {
                monitorInterval = Integer.valueOf(configArray[0][0]) * 1000l;
                alarmSendTime = Integer.valueOf(configArray[0][1]);
                alarmMaxSendTime = Integer.valueOf(configArray[0][2]);
                maintainCount = Integer.valueOf(configArray[0][3]);
                alarmSendTime = alarmSendTime * 3;
                alarmMaxSendTime = alarmMaxSendTime * 8;
            }
            detector = new HighFrequencyStringDetector(maintainCount, alarmSendTime);
            // 有超过600个讨论组的情况，聚合也减少不了
            cmdWhiteMap.put("OidbSvc.0x58b_0", 150);
            // 头像是有可能连续多次请求的，但是目前没有聚合能力，先加入白名单
            cmdWhiteMap.put("IncreaseURLSvr.QQHeadUrlReq", 100);
            cmdWhiteMap.put("AvatarInfoSvr.QQHeadUrlReq", 100);
            // 这里涉及业务过多，后台不合理的push短时间改不了
            cmdWhiteMap.put("OnlinePush.RespPush", 120);
            cmdWhiteMap.put("CliLogSvc.UploadReq", 50);
            // 群相关
            cmdWhiteMap.put("OidbSvc.0x787_1", 90);
            cmdWhiteMap.put("friendlist.getTroopMemberList", 40);
            // 离线消息
            cmdWhiteMap.put("MessageSvc.PbDeleteMsg", 100);
        }

        private long startMonitorTimeStamp = 0l;

        public void onCmdRequest(String cmd) {
            if (!isRunning) {
                detector.clear();
                return;
            }
            if (startMonitorTimeStamp == 0l) {
                startMonitorTimeStamp = SystemClock.uptimeMillis();
            }
            detector.putString(cmd);
            if (SystemClock.uptimeMillis() - startMonitorTimeStamp > monitorInterval) {
                Map<String, Integer> map = detector.getHighFrequencyString();
                if (map != null) {
                    if (ILogUtil.debug && DEBUG_ALARM) {
                        // 过滤白名单
                        for (String whiteCmd : cmdWhiteMap.keySet()) {
                            if (map.containsKey(whiteCmd) && map.get(whiteCmd) < cmdWhiteMap.get(whiteCmd)) {
                                map.remove(whiteCmd);
                            }
                        }
                    }
                }
                if (map != null && map.size() > 0) {
                    StringBuilder sb = new StringBuilder(map.size() * 20);
                    int maxCount = 0;
                    for (String key : map.keySet()) {
                        if (sb.length() > 0) {
                            sb.append("#");
                        }
                        sb.append("[").append(key).append(",").append(map.get(key)).append("]");
                        if (map.get(key) > maxCount) {
                            maxCount = map.get(key);
                        }
                        
                        Bundle bundle = new Bundle();
                        bundle.putInt(KEY_ACTION, ACTION_CMD_ALARM);
                        bundle.putString(KEY_CMD, key);
                        bundle.putInt(KEY_COUNT, map.get(key));
                        this.onOtherProcReport(bundle);
                    }
                    writeCommonLog(Magnifier.processId, "cmd|", sb.toString());
                } else {
                    if (callback != null) {
                        Magnifier.ILOGUTIL.i(TAG, "No high frequnecy cmd in last 2seconds");
                    }
                }
                startMonitorTimeStamp = 0l;
                detector.clear();
            }
        }
        
        private static final String KEY_CMD = "key_log";
        private static final String KEY_COUNT = "key_count";
        @Override
        public void onOtherProcReport(@NonNull Bundle params) {
            if (!isRunning) {
                return;
            }
            int action = params.getInt(KEY_ACTION);
            if (action == ACTION_CMD_ALARM) {
                String log = params.getString(KEY_CMD);
                int count = params.getInt(KEY_COUNT);
                Magnifier.ILOGUTIL.i(TAG, "CMD.onOtherProcReport:", log, ", count:" + count);
                synchronized (fg30MinMap) {
                    if (isBeforeRun30Min) {
                        HashSet<Pair<Long, Integer>> set = fg30MinMap.get(log);
                        if (set == null) {
                            set = new HashSet<Pair<Long, Integer>>();
                            fg30MinMap.put(log, set);
                        }
                        set.add(new Pair<Long, Integer>(System.currentTimeMillis(), count));
                    }
                    if (isAppBackground && isInFirstBG5min) {
                        HashSet<Pair<Long, Integer>> set = bg5MinMap.get(log);
                        if (set == null) {
                            set = new HashSet<Pair<Long, Integer>>();
                            bg5MinMap.put(log, set);
                        }
                        set.add(new Pair<Long, Integer>(System.currentTimeMillis(), count));
                    }
                }
            }
        }
        
        @Override
        public void onAppBackground() {
            super.onAppBackground();
            synchronized (fg30MinMap) {
                bg5MinMap.clear();
            }
        }

        @Override
        public void onProcessRun30Min() {
            super.onProcessRun30Min();
            if (isRunning) {
                synchronized (fg30MinMap) {
                    // 计算高频次数
                    int count = 0;
                    for (HashSet<?> set : fg30MinMap.values()) {
                        count += set.size();
                    }
                    writeReportLog(FG_30_CMD_COUNT, "|", String.valueOf(count));
                    for (String key : fg30MinMap.keySet()) {
                        HashSet<Pair<Long, Integer>> set = fg30MinMap.get(key);
                        StringBuilder sb = BatteryLog.getReuseStringBuilder();
                        int index = 0;
                        for (Pair<Long, Integer> pair : set) {
                            sb.append(pair.first).append(",").append(pair.second);
                            if (++index < set.size()) {
                                sb.append("#");
                            }
                        }
                        writeReportLog(FG_30_CMD_ALARM, "|", key, "|", sb.toString());
                    }
                    fg30MinMap.clear();
                }
            }
        }
        
        @Override
        public void onProcessBG5Min() {
            super.onProcessBG5Min();
            if (isRunning) {
                synchronized (fg30MinMap) {
                    // 计算高频次数
                    int count = 0;
                    for (HashSet<?> set : bg5MinMap.values()) {
                        count += set.size();
                    }
                    writeReportLog(BG_5_CMD_COUNT, "|", String.valueOf(count));
                    for (String key : bg5MinMap.keySet()) {
                        HashSet<Pair<Long, Integer>> set = bg5MinMap.get(key);
                        StringBuilder sb = BatteryLog.getReuseStringBuilder();
                        int index = 0;
                        for (Pair<Long, Integer> pair : set) {
                            sb.append(pair.first).append(",").append(pair.second);
                            if (++index < set.size()) {
                                sb.append("#");
                            }
                        }
                        writeReportLog(BG_5_CMD_ALARM, "|", key, "|", sb.toString());
                    }
                    bg5MinMap.clear();
                }
            }
        }
    }

    private class WAKE_LOCK extends BatteryUsageItem implements Handler.Callback {
        private class WakeLockEntity {
            // WakeLock基本信息
            public int levelAndFlags;
            public String tag;
            public String createStack;
            public String uuid;
            // acquire/release堆栈
            @NonNull
            private Map<String, Integer> callStackMap = new HashMap<String, Integer>();
            private long firstAcquireTimeStamp = 0l;
            // 高频检测
            private HighFrequencyDetector detector1;
            private HighFrequencyDetector detector2;
            
            private long holdTime = 0l;

            public WakeLockEntity() {
                detector1 = new HighFrequencyDetector(maxCallTimeInShortTime, shortTime);
                detector2 = new HighFrequencyDetector(maxCallTimeInLongTime, longTime);
            }
            
            /**
             * 获取堆栈index，用于减流量
             * @param stack
             * @return - first：是否为新id；second：id
             */
            @NonNull
            public Pair<Boolean, Integer> getCallStackIndex(String stack) {
                synchronized(callStackMap) {
                    if (callStackMap.containsKey(stack)) {
                        return new Pair<Boolean, Integer>(false, callStackMap.get(stack));
                    } else {
                        int index = callStackMap.size();
                        callStackMap.put(stack, index);
                        return new Pair<Boolean, Integer>(true, index);
                    }
                }
            }

            /**
             * WakeLock被调用acquire
             * 
             * @param timeout
             * @return - first:是否触发wakelock真正发生；second：是否高频，如果高频返回调用列表
             */
            @NonNull
            public Pair<Boolean, List<Action>> onAcquire(@NonNull WakeLock wl, String stack, long timeout) {
                boolean isFirstAcquire = false;
                if (!wl.isHeld()) {
                    isFirstAcquire = true;
                    firstAcquireTimeStamp = SystemClock.uptimeMillis();
                }
                List<Action> frequentlyList = detector1.onAction(stack);
                frequentlyList = detector2.onAction(stack);
                return new Pair<Boolean, List<Action>>(isFirstAcquire, frequentlyList);
            }

            /**
             * WakeLock被调用release
             * 
             * @param flags
             * @return - true:引用次数为0
             */
            @NonNull
            public Pair<Boolean, Long> onRelease(@NonNull WakeLock wl, int flags) {
                boolean hasNoneRef = false;
                long holdInterval = 0l;
                if (!wl.isHeld() && firstAcquireTimeStamp != 0l) {
                    hasNoneRef = true;
                    holdInterval = SystemClock.uptimeMillis() - firstAcquireTimeStamp;
                    firstAcquireTimeStamp = 0l;
                    holdTime = holdInterval;
                }
                return new Pair<Boolean, Long>(hasNoneRef, holdInterval);
            }

            public void destroy() {
                detector1.trimCache();
                detector2.trimCache();
            }
            
            public boolean isHeld() {
                return firstAcquireTimeStamp != 0l;
            }
            
            public long getHoldTime() {
                if (isHeld()) {
                    return SystemClock.uptimeMillis() - firstAcquireTimeStamp;
                } else {
                    return holdTime;
                }
            }
        }

        private HashMap<WeakReference<WakeLock>, WakeLockEntity> map;
        @Nullable
        private Handler subHandler;
        /**
         * WakeLock最长持有时间，支持后台配置下发
         */
        private long maxAcquireTime = 30000l;
        private int maxCallTimeInShortTime = 3;
        private long shortTime = 10 * 60 * 1000l;
        private int maxCallTimeInLongTime = 10;
        private long longTime = 2 * 60 * 60 * 1000l;

        private static final String METHOD_NEW_WAKELOCK = "newWakeLock";
        private static final String METHOD_ACQUIRE = "acquire";
        private static final String METHOD_RELEASE = "release";
        private static final String WAKELOCK_USAGE = "wl_usg";
        private static final String WAKELOCK_ALARM = "wl_alm";
        private static final String WAKELOCK_TIME = "wl_tm";
        
        public static final String RPT_FG_30_WL_COUNT = "fg30WlCount";
        public static final String RPT_FG_30_WL_USE = "fg30WlUse";
        public static final String RPT_BG_5_WL_COUNT = "bg5WlCount";
        public static final String RPT_BG_5_WL_USE = "bg5WlUse";
        public static final String RPT_WL_NOT_RELEASE = "wlNotRelease";
        public static final String RPT_WL_TIMEOUT = "wlTimeout";
        
        private class ReportEntity {
            @Nullable
            public String tag;
            public int flag;
            @NonNull
            public HashSet<Pair<Long, Long>> useList = new HashSet<Pair<Long, Long>>();
        }
        
        @NonNull
        private HashMap<String, ReportEntity> fg30MinMap = new HashMap<String, ReportEntity>();
        @NonNull
        private HashMap<String, ReportEntity> bg5MinMap = new HashMap<String, ReportEntity>();

        public WAKE_LOCK(@NonNull String config) {
            super(config);
            map = new HashMap<WeakReference<WakeLock>, WakeLockEntity>();
            subHandler = new Handler(ThreadManager.getBatteryThreadLooper(), this);
            // 配置示例：30;3,10;10,120
            if (configArray.length >= 1 && configArray[0].length >= 1) {
                maxAcquireTime = Integer.valueOf(configArray[0][0]) * 1000l;
                maxAcquireTime = maxAcquireTime * 10;
            }
            if (configArray.length >= 2 && configArray[1].length >= 2) {
                maxCallTimeInShortTime = Integer.valueOf(configArray[1][0]);
                shortTime = Integer.valueOf(configArray[1][1]) * 60 * 1000l;
            }
            if (configArray.length >= 3 && configArray[2].length >= 2) {
                maxCallTimeInLongTime = Integer.valueOf(configArray[2][0]);
                longTime = Integer.valueOf(configArray[2][1]) * 60 * 1000l;
            }
        }

        @Override
        public void onHookReady() {
            if (!isRunning) {
                return;
            }
            try {

				doHook();

            } catch (Throwable t) {
                Magnifier.ILOGUTIL.exception(TAG, t);
            }
        }
  

		public void doHook() {
			DexposedBridge.findAndHookMethod(PowerManager.class, "newWakeLock", int.class, String.class, new XC_MethodHook() {
				@Override
				public void beforeHookedMethod(MethodHookParam param) {

				}

				@Override
				public void afterHookedMethod(@NonNull MethodHookParam param) {
					onHook("newWakeLock", param.thisObject,param.args, param.getResult());
				}
			});

			DexposedBridge.findAndHookMethod(WakeLock.class, "acquire", new XC_MethodHook() {
				@Override
				public void beforeHookedMethod(@NonNull MethodHookParam param) {
					onHook("acquire",param.thisObject,param.args,null);
				}

				@Override
				public void afterHookedMethod(MethodHookParam param) {
//					super.afterHookedMethod(param);
				}
			});


			DexposedBridge.findAndHookMethod(WakeLock.class, "acquire", long.class, new XC_MethodHook() {
				@Override
				public void beforeHookedMethod(@NonNull MethodHookParam param) {
					onHook("acquire",param.thisObject,param.args,null);
				}

				@Override
				public void afterHookedMethod(MethodHookParam param) {
//					super.afterHookedMethod(param);
				}
			});


			DexposedBridge.findAndHookMethod(WakeLock.class, "release", int.class, new XC_MethodHook() {
				@Override
				public void beforeHookedMethod(MethodHookParam param) {
//					super.beforeHookedMethod(param);
				}

				@Override
				public void afterHookedMethod(@NonNull MethodHookParam param) {
					onHook("release", param.thisObject, param.args, param.getResult());
				}
			});
		}
    

        private void onHook(String methodName, Object thisObject, @Nullable Object[] args, Object retObj) {
            if (!isRunning) {
                subHandler.removeMessages(MSG_TIMEOUT);
                return;
            }
            /**
             * WakeLock相关上报<br>
             * newWakeLock|距离启动时间(秒)|wakelock对象uid|levelAndFlags|tag|创建堆栈;
             * wl_usage |uid|对象释放时缺失release次数|{acquire堆栈1|次数|acquire堆栈2|
             * 次数...}|{release堆栈1|次数|release堆栈2|次数...}; wl_alarm|距离启动时间(秒)|uid|0
             */
            synchronized (map) {
                if (METHOD_NEW_WAKELOCK.equals(methodName)) {
                    WeakReference<WakeLock> wakelockRef = new WeakReference<WakeLock>((WakeLock) retObj);
                    WakeLockEntity entity = new WakeLockEntity();
                    entity.levelAndFlags = (Integer) args[0];
                    entity.tag = (String) args[1];
                    entity.createStack = getAppStack().toString();
                    entity.uuid = String.valueOf(entity.hashCode());
                    map.put(wakelockRef, entity);
                    // 日志记录newWakeLock操作
                    writeCommonLog(Magnifier.processId, methodName, "|", entity.uuid, "|", String.valueOf(entity.levelAndFlags), "|",
                            entity.tag, "|", entity.createStack);
                } else if (METHOD_ACQUIRE.equals(methodName)) {
                    String callStack = getAppStack().toString();
                    for (Iterator<WeakReference<WakeLock>> iter = map.keySet().iterator(); iter.hasNext();) {
                        WeakReference<WakeLock> ref = iter.next();
                        WakeLockEntity entity = map.get(ref);
                        if (ref.get() == thisObject) {
                            long timeout = (args == null || args.length == 0) ? -1 : (Long) args[0];
                            Pair<Boolean, Integer> stackRs = entity.getCallStackIndex(callStack);
                            writeCommonLog(Magnifier.processId, WAKELOCK_USAGE, "|", entity.uuid, "|0|", stackRs.first ? callStack : "",
                                    "|", String.valueOf(stackRs.second), "|", String.valueOf(timeout));
                            Pair<Boolean, List<Action>> rs = entity.onAcquire((WakeLock)thisObject, callStack, timeout);
                            if (rs.first) {
                                Message msg = subHandler.obtainMessage(MSG_TIMEOUT);
                                msg.obj = ref;
                                subHandler.sendMessageDelayed(msg, maxAcquireTime);
                            } else if (timeout >= maxAcquireTime) {
                                writeCommonLog(Magnifier.processId, WAKELOCK_ALARM, "|", entity.uuid, "|0|", String.valueOf(stackRs.second));
                            }
                        } else if (ref.get() == null) {
                            if (entity.isHeld()) {
                                writeCommonLog(Magnifier.processId, WAKELOCK_ALARM, "|", entity.uuid, "|1");
                                doReport(entity, ACTION_WL_NOT_RELEASE);
                            }
                            entity.destroy();
                            iter.remove();
                        }
                    }
                } else if (METHOD_RELEASE.equals(methodName)) {
                    String callStack = getAppStack().toString();
                    for (Iterator<WeakReference<WakeLock>> iter = map.keySet().iterator(); iter.hasNext();) {
                        WeakReference<WakeLock> ref = iter.next();
                        WakeLockEntity entity = map.get(ref);
                        if (ref.get() == thisObject) {
                            int flags = (args == null || args.length == 0) ? -1 : (Integer) args[0];
                            Pair<Boolean, Long> result = entity.onRelease((WakeLock)thisObject, flags);
                            if (result.first) {
                                subHandler.removeMessages(MSG_TIMEOUT, ref);
                                writeCommonLog(Magnifier.processId, WAKELOCK_TIME, "|", entity.uuid, "|", String.valueOf(result.second));
                                doReport(entity, ACTION_WL_USE);
                            }
                            Pair<Boolean, Integer> stackRs = entity.getCallStackIndex(callStack);
                            writeCommonLog(Magnifier.processId, WAKELOCK_USAGE, "|", entity.uuid, "|1|", stackRs.first ? callStack : "",
                                    "|", String.valueOf(stackRs.second), "|", String.valueOf(flags));
                        } else if (ref.get() == null) {
                            // wakelock对象被释放后打印使用详细信息
                            if (entity.isHeld()) {
                                writeCommonLog(Magnifier.processId, WAKELOCK_ALARM, "|", entity.uuid, "|1");
                                doReport(entity, ACTION_WL_NOT_RELEASE);
                            }
                            entity.destroy();
                            iter.remove();
                        }
                    }
                }
            }
        }
        
        private final void doReport(WakeLockEntity entity, int action) {
            Bundle bundle = new Bundle();
            bundle.putInt(KEY_ACTION, action);
            bundle.putString(KEY_STACK, entity.createStack);
            bundle.putString(KEY_TAG, entity.tag);
            bundle.putInt(KEY_FLAG, entity.levelAndFlags);
            bundle.putLong(KEY_TIME, entity.getHoldTime());
            this.onOtherProcReport(bundle);
        }
        
        @Override
        public void onAppBackground() {
            super.onAppBackground();
            synchronized (fg30MinMap) {
                bg5MinMap.clear();
            }
        }

        private static final String KEY_TAG = "key_tag";
        private static final String KEY_STACK = "key_stack";
        private static final String KEY_TIME = "key_time";
        private static final String KEY_FLAG = "key_flag";
        
        @Override
        public void onOtherProcReport(@NonNull Bundle params) {
            super.onOtherProcReport(params);
            int action = params.getInt(KEY_ACTION);
            if (isRunning && (action == ACTION_WL_USE || action == ACTION_WL_NOT_RELEASE || action == ACTION_WL_TIMEOUT)) {
                Magnifier.ILOGUTIL.i(TAG, "WakeLock.onOtherProcReport:action=", String.valueOf(action), ", tag=", params.getString(KEY_TAG),
                            ", stack=", params.getString(KEY_STACK), ", time=", String.valueOf(params.getLong(KEY_TIME)));
                String stack = params.getString(KEY_STACK);
                if (action == ACTION_WL_USE) {
                    synchronized(fg30MinMap) {
                        if (isBeforeRun30Min) {
                            ReportEntity entity = fg30MinMap.get(stack);
                            if (entity == null) {
                                entity = new ReportEntity();
                                entity.flag = params.getInt(KEY_FLAG);
                                entity.tag = params.getString(KEY_TAG);
                                fg30MinMap.put(stack, entity);
                            }
                            entity.useList.add(new Pair<Long, Long>(System.currentTimeMillis(), params.getLong(KEY_TIME)));
                        }
                        
                        if (isAppBackground && isInFirstBG5min) {
                            ReportEntity entity = bg5MinMap.get(stack);
                            if (entity == null) {
                                entity = new ReportEntity();
                                entity.flag = params.getInt(KEY_FLAG);
                                entity.tag = params.getString(KEY_TAG);
                                bg5MinMap.put(stack, entity);
                            }
                            entity.useList.add(new Pair<Long, Long>(System.currentTimeMillis(), params.getLong(KEY_TIME)));
                        }
                    }
                } else if (action == ACTION_WL_NOT_RELEASE) {
                    writeReportLog(RPT_WL_NOT_RELEASE, "|", params.getString(KEY_STACK), "|",
                            params.getString(KEY_TAG), "|", params.getInt(KEY_FLAG) + "", "|", params.getLong(KEY_TIME) + "");
                } else if (action == ACTION_WL_TIMEOUT) {
                    writeReportLog(RPT_WL_TIMEOUT, "|", params.getString(KEY_STACK), "|",
                            params.getString(KEY_TAG), "|", params.getInt(KEY_FLAG) + "", "|", params.getLong(KEY_TIME) + "");
                }
            }
        }

        @Override
        public void onProcessRun30Min() {
            super.onProcessRun30Min();
            if (isRunning && isHookReady) {
                writeReport(true);
            }
        }
        
        private final void writeReport(boolean is30Min) {
            synchronized (fg30MinMap) {
                int useCount = 0;
                long useTime = 0l;
                long useBatteryTime = 0l;
                HashMap<String, ReportEntity> map = is30Min ? fg30MinMap : bg5MinMap;
                for (ReportEntity entity : map.values()) {
                    useCount += entity.useList.size();
                    boolean consumeBattery = (entity.flag & PowerManager.PARTIAL_WAKE_LOCK) > 0;
                    for (Pair<Long, Long> pair : entity.useList) {
                        useTime += pair.second;
                        if (consumeBattery) {
                            useBatteryTime += pair.second;
                        }
                    }
                }
                writeReportLog(is30Min ? RPT_FG_30_WL_COUNT : RPT_BG_5_WL_COUNT, "|", String.valueOf(useCount), "|",
                        String.valueOf(useTime), "|", String.valueOf(useBatteryTime));
                for (String key : map.keySet()) {
                    ReportEntity entity = map.get(key);
                    StringBuilder sb = BatteryLog.getReuseStringBuilder();
                    int index = 0;
                    for (Pair<Long, Long> pair : entity.useList) {
                        sb.append(String.valueOf(pair.first)).append(",").append(String.valueOf(pair.second));
                        if (++index < entity.useList.size()) {
                            sb.append("#");
                        }
                    }
                    writeReportLog(is30Min ? RPT_FG_30_WL_USE : RPT_BG_5_WL_USE, "|",
                            entity.tag.replace("|", "_"), "|",
                            (entity.flag & PowerManager.PARTIAL_WAKE_LOCK) > 0 ? "1" : "0", "|", key, "|",
                            sb.toString());
                }
                map.clear();
            }
        }

        @Override
        public void onProcessBG5Min() {
            super.onProcessBG5Min();
            if (isRunning && isHookReady) {
                writeReport(false);
            }
        }

        private static final int MSG_TIMEOUT = 1;

        @SuppressWarnings("unchecked")
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            if (msg.what == MSG_TIMEOUT) {
                synchronized (map) {
                    WeakReference<WakeLock> ref = (WeakReference<WakeLock>) msg.obj;
                    WakeLockEntity entity = map.get(ref);
                    if (entity != null) {
                        doReport(entity, ACTION_WL_TIMEOUT);
                        writeCommonLog(Magnifier.processId, WAKELOCK_ALARM, "|", entity.uuid, "|0|0");
                    } else {
                        Magnifier.ILOGUTIL.e(TAG, "wake lock is lost ?");
                    }
                }
            }
            return false;
        }
    }

    @SuppressWarnings("unused")
    private class WIFI extends BatteryUsageItem {
        private HighFrequencyDetector detector1;
        private HighFrequencyDetector detector2;

        private int maxCallTimeInShortTime = 3;
        private long shortTime = 15 * 60 * 1000l;
        private int maxCallTimeInLongTime = 10;
        private long longTime = 5 * 60 * 60 * 1000l;
        // wifi scan
        public static final String FG_30_WF_SCAN_COUNT = "fg30WFSCount";
        public static final String FG_30_WF_SCAN_DETAIL = "fg30WFSDetail";
        public static final String BG_5_WF_SCAN_COUNT = "bg5WFSCount";
        public static final String BG_5_WF_SCAN_DETAIL = "bg5WFSDetail";
        // wifi lock
        public static final String FG_30_WF_LOCK_COUNT = "fg30WFLCount";
        public static final String FG_30_WF_LOCK_DETAIL = "fg30WFLDetail";
        public static final String BG_5_WF_LOCK_COUNT = "bg5WFLCount";
        public static final String BG_5_WF_LOCK_DETAIL = "bg5WFLDetail";
        public static final String WF_LOCK_NOT_RELEASE = "wflNotRelease";
        
        @NonNull
        private HashMap<WeakReference<WifiLock>, WifiLockEntity> map = new HashMap<WeakReference<WifiLock>, WifiLockEntity>();
        
        private class WifiLockEntity {
            public String uuid;
            public String tag;
            public String createStack;
            public long firstAcquireTimeStamp = 0l;
        }
        
        private class ReportEntity {
            @Nullable
            public String tag;
            @Nullable
            public String createStack;
            @NonNull
            public HashSet<Pair<Long, Long>> useList = new HashSet<Pair<Long, Long>>();
        }
        
        @NonNull
        private HashMap<String, ReportEntity> fg30MinLockMap = new HashMap<String, ReportEntity>();
        @NonNull
        private HashMap<String, ReportEntity> bg5MinLockMap = new HashMap<String, ReportEntity>();
        @NonNull
        private HashMap<String, HashSet<Long>> fg30MinScanMap = new HashMap<String, HashSet<Long>>();
        @NonNull
        private HashMap<String, HashSet<Long>> bg5MinScanMap = new HashMap<String, HashSet<Long>>();

        
        public WIFI(@NonNull String config) {
            super(config);
            detector1 = new HighFrequencyDetector(maxCallTimeInShortTime, shortTime);
            detector2 = new HighFrequencyDetector(maxCallTimeInLongTime, longTime);
            // 配置示例：3,15;10,300
            if (configArray.length >= 1 && configArray[0].length >= 2) {
                maxCallTimeInShortTime = Integer.valueOf(configArray[0][0]);
                shortTime = Integer.valueOf(configArray[0][1]) * 60 * 1000l;
            }
            if (configArray.length >= 2 && configArray[1].length >= 2) {
                maxCallTimeInLongTime = Integer.valueOf(configArray[1][0]);
                longTime = Integer.valueOf(configArray[1][1]) * 60 * 1000l;
            }
        }

        @Override
        public void onHookReady() {
            if (!isRunning) {
                return;
            }
            try {

				doHook();
                     
            } catch (Throwable t) {
                Magnifier.ILOGUTIL.exception(TAG, t);
            }
        }
        
		
				public void doHook() {
			DexposedBridge.findAndHookMethod(WifiManager.class, "startScan", new XC_MethodHook() {
				@Override
				public void beforeHookedMethod(@NonNull MethodHookParam param) {
//					super.beforeHookedMethod(param);
					beforeHookedMethodHandler("startScan",param.thisObject,param.args);
				}

				@Override
				public void afterHookedMethod(@NonNull MethodHookParam param) {
//					super.afterHookedMethod(param);
					afterHookedMethodHandler("startScan",param.thisObject,param.args,param.getResult());
				}
			});

			DexposedBridge.findAndHookMethod(WifiManager.class, "createWifiLock", int.class, String.class, new XC_MethodHook() {
				@Override
				public void beforeHookedMethod(@NonNull MethodHookParam param) {
//					super.beforeHookedMethod(param);
					beforeHookedMethodHandler("createWifiLock",param.thisObject,param.args);
				}

				@Override
				public void afterHookedMethod(@NonNull MethodHookParam param) {
//					super.afterHookedMethod(param);
					afterHookedMethodHandler("createWifiLock",param.thisObject,param.args,param.getResult());
				}
			});

			DexposedBridge.findAndHookMethod(WifiManager.class, "createWifiLock",String.class, new XC_MethodHook() {
				@Override
				public void beforeHookedMethod(@NonNull MethodHookParam param) {
//					super.beforeHookedMethod(param);
					beforeHookedMethodHandler("createWifiLock",param.thisObject,param.args);
				}

				@Override
				public void afterHookedMethod(@NonNull MethodHookParam param) {
//					super.afterHookedMethod(param);
					afterHookedMethodHandler("createWifiLock",param.thisObject,param.args,param.getResult());
				}
			});

			DexposedBridge.findAndHookMethod(WifiLock.class, "acquire", new XC_MethodHook() {
				@Override
				public void beforeHookedMethod(@NonNull MethodHookParam param) {
//					super.beforeHookedMethod(param);
					beforeHookedMethodHandler("acquire",param.thisObject,param.args);
				}

				@Override
				public void afterHookedMethod(@NonNull MethodHookParam param) {
//					super.afterHookedMethod(param);
					afterHookedMethodHandler("acquire",param.thisObject,param.args,param.getResult());
				}
			});

			DexposedBridge.findAndHookMethod(WifiLock.class, "release", new XC_MethodHook() {
				@Override
				public void beforeHookedMethod(@NonNull MethodHookParam param) {
//					super.beforeHookedMethod(param);
					beforeHookedMethodHandler("release",param.thisObject,param.args);
				}

				@Override
				public void afterHookedMethod(@NonNull MethodHookParam param) {
//					super.afterHookedMethod(param);
					afterHookedMethodHandler("release",param.thisObject,param.args,param.getResult());
				}
			});
		}
		

        
        @Override
        public void onAppBackground() {
            super.onAppBackground();
            synchronized (fg30MinScanMap) {
                bg5MinScanMap.clear();
            }
            synchronized (fg30MinLockMap) {
                bg5MinLockMap.clear();
            }
        }

        private static final String KEY_STACK = "key_stack";
        private static final String KEY_TAG = "key_tag";
        private static final String KEY_DURATION = "key_duration";
        
        @Override
        public void onOtherProcReport(@NonNull Bundle params) {
            super.onOtherProcReport(params);
            if (!isRunning) {
                return;
            }
            int action = params.getInt(KEY_ACTION);
            String stack = params.getString(KEY_STACK);
            String tag = params.getString(KEY_TAG);
            long duration = params.getLong(KEY_DURATION);
            if (action == ACTION_WIFI_SCAN) {
                Magnifier.ILOGUTIL.i(TAG, "WiFi.onOtherProcReport: scan:", stack );
                synchronized (fg30MinScanMap) {
                    if (isBeforeRun30Min) {
                        HashSet<Long> set = fg30MinScanMap.get(stack);
                        if (set == null) {
                            set = new HashSet<Long>();
                            fg30MinScanMap.put(stack, set);
                        }
                        set.add(System.currentTimeMillis());
                    }
                    if (isAppBackground && isInFirstBG5min) {
                        HashSet<Long> set = bg5MinScanMap.get(stack);
                        if (set == null) {
                            set = new HashSet<Long>();
                            bg5MinScanMap.put(stack, set);
                        }
                        set.add(System.currentTimeMillis());
                    }
                }
            } else if (action == ACTION_WIFI_LOCK_USE) {
                synchronized (fg30MinLockMap) {
                    if (isBeforeRun30Min) {
                        ReportEntity entity = fg30MinLockMap.get(stack);
                        if (entity == null) {
                            entity = new ReportEntity();
                            entity.tag = tag;
                            entity.createStack = stack;
                            fg30MinLockMap.put(stack, entity);
                        }
                        entity.useList.add(new Pair<Long, Long>(System.currentTimeMillis(), duration));
                    }
                    if (isAppBackground && isInFirstBG5min) {
                        ReportEntity entity = bg5MinLockMap.get(stack);
                        if (entity == null) {
                            entity = new ReportEntity();
                            entity.tag = tag;
                            entity.createStack = stack;
                            bg5MinLockMap.put(stack, entity);
                        }
                        entity.useList.add(new Pair<Long, Long>(System.currentTimeMillis(), duration));
                    }
                }
            } else if (action == ACTION_WIFI_LOCK_NOT_RELEASE) {
                writeReportLog(WF_LOCK_NOT_RELEASE, "|", stack, "|", tag, "|0|0");
            }
        }

        @Override
        public void onProcessRun30Min() {
            super.onProcessRun30Min();
            if (isRunning && isHookReady) {
                synchronized (fg30MinScanMap) {
                    int count = 0;
                    for (HashSet<?> set : fg30MinScanMap.values()) {
                        count += set.size();
                    }
                    writeReportLog(FG_30_WF_SCAN_COUNT, "|", String.valueOf(count));
                    for (String key : fg30MinScanMap.keySet()) {
                        StringBuilder sb = BatteryLog.getReuseStringBuilder();
                        HashSet<Long> set = fg30MinScanMap.get(key);
                        int index = 0;
                        for (Long time : set) {
                            sb.append(time);
                            if (++index < set.size()) {
                                sb.append("#");
                            }
                        }
                        writeReportLog(FG_30_WF_SCAN_DETAIL, "|", key, "|", sb.toString());
                    }
                    fg30MinScanMap.clear();
                }
                writeLockReport(true);
            }
        }
        
        private final void writeLockReport(boolean is30Min) {
            synchronized (fg30MinLockMap) {
                int useCount = 0;
                long useTime = 0;
                HashMap<String, ReportEntity> map = is30Min ? fg30MinLockMap : bg5MinLockMap;
                for (ReportEntity entity : map.values()) {
                    useCount += entity.useList.size();
                    for (Pair<Long, Long> pair : entity.useList) {
                        useTime += pair.second;
                    }
                }
                writeReportLog(is30Min ? FG_30_WF_LOCK_COUNT : BG_5_WF_LOCK_COUNT, "|", String.valueOf(useCount), "|", String.valueOf(useTime), "|0");
                for (String key : map.keySet()) {
                    ReportEntity entity = map.get(key);
                    StringBuilder sb = BatteryLog.getReuseStringBuilder();
                    int index = 0;
                    for (Pair<Long, Long> pair : entity.useList) {
                        sb.append(String.valueOf(pair.first)).append(",").append(String.valueOf(pair.second));
                        if (++index < entity.useList.size()) {
                            sb.append("#");
                        }
                    }
                    writeReportLog(is30Min ? FG_30_WF_LOCK_DETAIL : BG_5_WF_SCAN_DETAIL, "|", 
                            entity.tag == null ? "" : entity.tag.replace("|", "_"), "|0|", key, "|", sb.toString());
                }
                map.clear();
            }
        }
        
        @Override
        public void onProcessBG5Min() {
            super.onProcessBG5Min();
            if (isRunning && isHookReady) {
                synchronized (fg30MinScanMap) {
                    int count = 0;
                    for (HashSet<Long> set : bg5MinScanMap.values()) {
                        count += set.size();
                    }
                    writeReportLog(BG_5_WF_SCAN_COUNT, "|", String.valueOf(count));
                    for (String key : bg5MinScanMap.keySet()) {
                        StringBuilder sb = BatteryLog.getReuseStringBuilder();
                        HashSet<Long> set = bg5MinScanMap.get(key);
                        int index = 0;
                        for (Long time : set) {
                            sb.append(time);
                            if (++index < set.size()) {
                                sb.append("#");
                            }
                        }
                        writeReportLog(BG_5_WF_SCAN_DETAIL, "|", key, "|", sb.toString());
                    }
                    bg5MinScanMap.clear();
                }
                writeLockReport(false);
            }
        }

        private void afterHookedMethodHandler(String methodName, @NonNull Object thisObject, @Nullable Object[] args, @Nullable Object returnValue) {
            if (!isRunning) {
                return;
            }
            try {
                String callStack = getAppStack().toString();
                if ("release".equals(methodName)) {
                    synchronized (map) {
                        for (Iterator<WeakReference<WifiLock>> iter = map.keySet().iterator(); iter.hasNext();) {
                            WeakReference<WifiLock> ref = iter.next();
                            WifiLockEntity entity = map.get(ref);
                            if (ref.get() == thisObject) {
                                writeCommonLog(Magnifier.processId, "wf_rl|", entity.uuid, "|", callStack);
                                if (!((WifiLock) thisObject).isHeld()) {
                                    writeCommonLog(Magnifier.processId, "wf_time|", entity.uuid, "|", String.valueOf(SystemClock.uptimeMillis() - entity.firstAcquireTimeStamp));
                                    iter.remove();
                                }
                                doLockReport(entity, ACTION_WIFI_LOCK_USE);
                            } else if (ref.get() == null) {
                                writeCommonLog(Magnifier.processId, "wf_alarm|", entity.uuid);
                                iter.remove();
                                doLockReport(entity, ACTION_WIFI_LOCK_NOT_RELEASE);
                            }
                        }
                    }
                } else if ("createWifiLock".equals(methodName) && returnValue != null ) {
                    WeakReference<WifiLock> ref = new WeakReference<WifiLock>((WifiLock) returnValue);
                    WifiLockEntity entity = new WifiLockEntity();
                    entity.uuid = String.valueOf(entity.hashCode());
                    entity.createStack = callStack;
                    if (args == null || args.length < 1) {
                        return;
                    } else if (args.length == 2) {
                        entity.tag = (String) args[1];
                    } else if (args.length == 1) {
                        entity.tag = (String) args[0];
                    }
                    map.put(ref, entity);
                    if (args.length == 1) {
                        writeCommonLog(Magnifier.processId, "wf_new|", entity.uuid, "|0|", String.valueOf(args[0]));
                    } else {
                        writeCommonLog(Magnifier.processId, "wf_new|", entity.uuid, "|", String.valueOf(args[0]), "|",
                                String.valueOf(args[1]));
                    }
                }
            } catch(Throwable t) {
                Magnifier.ILOGUTIL.exception(TAG, t);
            }
        }
        
        private final void doLockReport(WifiLockEntity entity, int action) {
            Bundle bundle = new Bundle();
            bundle.putInt(KEY_ACTION, action);
            bundle.putString(KEY_STACK, entity.createStack);
            bundle.putString(KEY_TAG, entity.tag);
            if (action == ACTION_WIFI_LOCK_USE) {
                bundle.putLong(KEY_DURATION, SystemClock.uptimeMillis() - entity.firstAcquireTimeStamp);
            }
            this.onOtherProcReport(bundle);
        }

        private void beforeHookedMethodHandler(String methodName, @NonNull Object thisObject, Object[] args) {
            if (!isRunning) {
                return;
            }
            try {
                String callStack = getAppStack().toString();
                if ("startScan".equals(methodName)) {
                    writeCommonLog(Magnifier.processId, "wfScan", "|", callStack);
                    List<Action> actionList = detector1.onAction(callStack);
                    if (actionList != null && actionList.size() > 0) {
                        detector1.trimCache();
                    }
                    actionList = detector2.onAction(callStack);
                    if (actionList != null && actionList.size() > 0) {
                        detector2.trimCache();
                    }
                    
                    Bundle bundle = new Bundle();
                    bundle.putInt(KEY_ACTION, ACTION_WIFI_SCAN);
                    bundle.putString(KEY_STACK, callStack);
                    this.onOtherProcReport(bundle);
                } else if ("acquire".equals(methodName)) {
                    synchronized (map) {
                        for (Iterator<WeakReference<WifiLock>> iter = map.keySet().iterator(); iter.hasNext();) {
                            WeakReference<WifiLock> ref = iter.next();
                            WifiLockEntity entity = map.get(ref);
                            if (ref.get() == thisObject) {
                                writeCommonLog(Magnifier.processId, "wf_ac|", entity.uuid, "|", callStack);
                                if (!((WifiLock) thisObject).isHeld()) {
                                    entity.firstAcquireTimeStamp = SystemClock.uptimeMillis();
                                }
                            } else if (ref.get() == null) {
                                writeCommonLog(Magnifier.processId, "wf_alarm|", entity.uuid);
                                iter.remove();
                            }
                        }
                    }
                }
            } catch(Throwable t) {
                Magnifier.ILOGUTIL.exception(TAG, t);
            }
        }
    }

    private class GPS extends BatteryUsageItem {
        private HighFrequencyDetector detector1;
        private HighFrequencyDetector detector2;

        private int maxCallTimeInShortTime = 3;
        private long shortTime = 15 * 60 * 1000l;
        private int maxCallTimeInLongTime = 10;
        private long longTime = 5 * 60 * 60 * 1000l;

        @Nullable
        private LocationManager locationMgr;

        private static final String REQUEST_METHOD_0 = "requestLocationUpdates";
        private static final String REQUEST_METHOD_1 = "requestSingleUpdate";
        public static final String REQUEST_SOSO = "requestSoso";
        
        @NonNull
        private Map<String, HashSet<Long>> fg30MinSdkMap = new HashMap<String, HashSet<Long>>();
        @NonNull
        private Map<String, HashSet<Long>> fg30MinSysMap = new HashMap<String, HashSet<Long>>();
        @NonNull
        private Map<String, HashSet<Long>> bg5MinSdkMap = new HashMap<String, HashSet<Long>>();
        @NonNull
        private Map<String, HashSet<Long>> bg5MinSysMap = new HashMap<String, HashSet<Long>>();
        
        private static final String FG_30_SDK_COUNT = "fg30SdkCount";
        private static final String FG_30_SYS_COUNT = "fg30SysCount";
        private static final String BG_5_SDK_COUNT = "bg5SdkCount";
        private static final String BG_5_SYS_COUNT = "bg5SysCount";
        private static final String FG_30_SDK_DETAIL = "fg30SdkDetail";
        private static final String FG_30_SYS_DETAIL = "fg30SysDetail";
        private static final String BG_5_SDK_DETAIL = "bg5SdkDetail";
        private static final String BG_5_SYS_DETAIL = "bg5SysDetail";

        public GPS(@NonNull String config) {
            super(config);
            detector1 = new HighFrequencyDetector(maxCallTimeInShortTime, shortTime);
            detector2 = new HighFrequencyDetector(maxCallTimeInLongTime, longTime);
            locationMgr = (LocationManager) Magnifier.sApp.getSystemService(Context.LOCATION_SERVICE);
            // 配置示例：3,15;10,300
            if (configArray.length >= 1 && configArray[0].length >= 2) {
                maxCallTimeInShortTime = Integer.valueOf(configArray[0][0]);
                shortTime = Integer.valueOf(configArray[0][1]) * 60 * 1000l;
            }
            if (configArray.length >= 2 && configArray[1].length >= 2) {
                maxCallTimeInLongTime = Integer.valueOf(configArray[1][0]);
                longTime = Integer.valueOf(configArray[1][1]) * 60 * 1000l;
            }
        }
        
        private int getGPSState() {
            try {
                return locationMgr.isProviderEnabled(LocationManager.GPS_PROVIDER) ? 1 : 0;
            } catch (Throwable t) {
                Magnifier.ILOGUTIL.exception(TAG, t);
            }
            return -1;
        }

        public void onGPSScan(String methodName, @NonNull Object[] params) {
            if (!isRunning) {
                return;
            }
            String callStack = getAppStack().toString();
            /**
             * GPS相关上报格式<br>
             * gpsScan|方法类型|方法id|{参数0|参数1|[对象参数1，对象参数2,...]|...}|调用堆栈
             */
            String logHeader = "location|" + getGPSState() + "|";
            if (REQUEST_METHOD_0.equals(methodName)) {
                if (params.length == 5) {
                    if (params[2] instanceof Criteria) {
                        writeCommonLog(Magnifier.processId, logHeader, "0", "|", "0", "|", "{", params[0].toString(), "#",
                                params[1].toString(), "#", "[",
                                locationMgr.getBestProvider((Criteria) params[2], true), ",",
                                String.valueOf(((Criteria) params[2]).getAccuracy()), ",",
                                String.valueOf(((Criteria) params[2]).getPowerRequirement()), "]", "}", "|", callStack);
                    } else if (params[0] instanceof String) {
                        writeCommonLog(Magnifier.processId, logHeader, "0", "|", "1", "|", "{", params[0].toString(), "#",
                                params[1].toString(), "#", params[2].toString(), "}", "|", callStack);
                    } else {
                        writeCommonLog(Magnifier.processId, logHeader, "0", "|", "-1", "|", "{}", "|", callStack);
                    }
                } else if (params.length == 6) {
                    if (params[2] instanceof Criteria) {
                        writeCommonLog(Magnifier.processId, logHeader, "0", "|", "2", "|", "{", params[0].toString(), "#",
                                params[1].toString(), "#", "[",
                                locationMgr.getBestProvider((Criteria) params[2], true), ",",
                                String.valueOf(((Criteria) params[2]).getAccuracy()), ",",
                                String.valueOf(((Criteria) params[2]).getPowerRequirement()), "]", "}", "|", callStack);
                    } else if (params[0] instanceof String) {
                        writeCommonLog(Magnifier.processId, logHeader, "0", "|", "3", "|", "{", params[0].toString(), "#",
                                params[1].toString(), "#", params[2].toString(), "}", "|", callStack);
                    } else {
                        writeCommonLog(Magnifier.processId, logHeader, "0", "|", "-1", "|", "{}", "|", callStack);
                    }
                }
                Bundle bundle = new Bundle();
                bundle.putInt(KEY_ACTION, ACTION_GPS_SYS_USE);
                bundle.putString(KEY_STACK, callStack);
                this.onOtherProcReport(bundle);
            } else if (REQUEST_METHOD_1.equals(methodName)) {
                if (params[0] instanceof String) {
                    writeCommonLog(Magnifier.processId, logHeader, "1", "|", "0", "|", "{", params[0].toString(), "}", "|", callStack);
                } else if (params[0] instanceof Criteria) {
                    writeCommonLog(Magnifier.processId, logHeader, "1", "|", "1", "|", "{", "[",
                            locationMgr.getBestProvider((Criteria) params[0], true), ",",
                            String.valueOf(((Criteria) params[0]).getAccuracy()), ",",
                            String.valueOf(((Criteria) params[0]).getPowerRequirement()), "]", "}", "|", callStack);
                } else {
                    writeCommonLog(Magnifier.processId, logHeader, "1", "|", "-1", "|", "{}", "|", callStack);
                }
                Bundle bundle = new Bundle();
                bundle.putInt(KEY_ACTION, ACTION_GPS_SYS_USE);
                bundle.putString(KEY_STACK, callStack);
                this.onOtherProcReport(bundle);
            } else if (REQUEST_SOSO.equals(methodName)) {
                String caller = params[2] == null ? "none" : params[2].toString();
                writeCommonLog(Magnifier.processId, logHeader, "2", "|", "0", "|", "{", params[0].toString(), "#", params[1].toString(),
                        "#", caller, "#", params[3] == null ? "-1" : params[3].toString(), "#", params[4] == null ? "-1" : params[4].toString(), "#",
                        params[5].toString(), "}", "|", callStack);
                Bundle bundle = new Bundle();
                bundle.putInt(KEY_ACTION, ACTION_GPS_SDK_USE);
                bundle.putString(KEY_TYPE, caller);
                this.onOtherProcReport(bundle);
            }

            List<Action> actionList = detector1.onAction(callStack);
            if (actionList != null && actionList.size() > 0) {
                detector1.trimCache();
            }
            actionList = detector2.onAction(callStack);
            if (actionList != null && actionList.size() > 0) {
                detector2.trimCache();
            }
        }
        
        @Override
        public void onAppBackground() {
            super.onAppBackground();
            synchronized (fg30MinSdkMap) {
                bg5MinSdkMap.clear();
                bg5MinSysMap.clear();
            }
        }

        private static final String KEY_TYPE = "key_type";
        private static final String KEY_STACK = "key_stack";
        @Override
        public void onOtherProcReport(@NonNull Bundle params) {
            super.onOtherProcReport(params);
            int action = params.getInt(KEY_ACTION);
            if (action == ACTION_GPS_SDK_USE || action == ACTION_GPS_SYS_USE) {
                Magnifier.ILOGUTIL.i(TAG, "GPS.onOtherProcReport:action=", String.valueOf(action) + ", type=", params.getString(KEY_TYPE), ", stack=", params.getString(KEY_STACK));
                if (isRunning) {
                    synchronized (fg30MinSdkMap) {
                        String key = action == ACTION_GPS_SDK_USE ? params.getString(KEY_TYPE) : params.getString(KEY_STACK);
                        if (isBeforeRun30Min) {
                            Map<String, HashSet<Long>> map = action == ACTION_GPS_SDK_USE ? fg30MinSdkMap : fg30MinSysMap;
                            HashSet<Long> set = map.get(key);
                            if (set == null) {
                                set = new HashSet<Long>();
                                map.put(key, set);
                            }
                            set.add(System.currentTimeMillis());
                        }
                        
                        if (isAppBackground && isInFirstBG5min) {
                            Map<String, HashSet<Long>> map = action == ACTION_GPS_SDK_USE ? bg5MinSdkMap : bg5MinSysMap;
                            HashSet<Long> set = map.get(key);
                            if (set == null) {
                                set = new HashSet<Long>();
                                map.put(key, set);
                            }
                            set.add(System.currentTimeMillis());
                        }
                    }
                }
            }
        }

        @Override
        public void onProcessRun30Min() {
            super.onProcessRun30Min();
            if (isRunning) {
                synchronized (fg30MinSdkMap) {
                    int sdkCount = 0;
                    int sysCount = 0;
                    for (HashSet<Long> set : fg30MinSdkMap.values()) {
                        sdkCount += set.size();
                    }
                    for (HashSet<Long> set : fg30MinSysMap.values()) {
                        sysCount += set.size();
                    }
                    writeReportLog(FG_30_SDK_COUNT, "|", String.valueOf(sdkCount));
                    if (isHookReady) {
                        writeReportLog(FG_30_SYS_COUNT, "|", String.valueOf(sysCount));
                    }
                    
                    for (String key : fg30MinSdkMap.keySet()) {
                        HashSet<Long> set = fg30MinSdkMap.get(key);
                        StringBuilder sb = BatteryLog.getReuseStringBuilder();
                        int index = 0;
                        for (Long time : set) {
                            sb.append(time);
                            if (++index < set.size()) {
                                sb.append("#");
                            }
                        }
                        writeReportLog(FG_30_SDK_DETAIL, "|", key, "|", sb.toString());
                    }
                    
                    for (String key : fg30MinSysMap.keySet()) {
                        HashSet<Long> set = fg30MinSysMap.get(key);
                        StringBuilder sb = BatteryLog.getReuseStringBuilder();
                        for (Long time : set) {
                            sb.append(time).append("|");
                        }
                        writeReportLog(FG_30_SYS_DETAIL, "|", key, "|", sb.toString());
                    }
                    fg30MinSdkMap.clear();
                    fg30MinSysMap.clear();
                }
            }
        }

        @Override
        public void onProcessBG5Min() {
            super.onProcessBG5Min();
            if (isRunning) {
                synchronized (fg30MinSdkMap) {
                    int sdkCount = 0;
                    int sysCount = 0;
                    for (HashSet<Long> set : bg5MinSdkMap.values()) {
                        sdkCount += set.size();
                    }
                    for (HashSet<Long> set : bg5MinSysMap.values()) {
                        sysCount += set.size();
                    }
                    writeReportLog(BG_5_SDK_COUNT, "|", String.valueOf(sdkCount));
                    if (isHookReady) {
                        writeReportLog(BG_5_SYS_COUNT, "|", String.valueOf(sysCount));
                    }
                    
                    for (String key : bg5MinSdkMap.keySet()) {
                        HashSet<Long> set = bg5MinSdkMap.get(key);
                        StringBuilder sb = BatteryLog.getReuseStringBuilder();
                        int index = 0;
                        for (Long time : set) {
                            sb.append(time);
                            if (++ index < set.size()) {
                                sb.append("#");
                            }
                        }
                        writeReportLog(BG_5_SDK_DETAIL, "|", key, "|", sb.toString());
                    }
                    
                    for (String key : bg5MinSysMap.keySet()) {
                        HashSet<Long> set = bg5MinSysMap.get(key);
                        StringBuilder sb = BatteryLog.getReuseStringBuilder();
                        for (Long time : set) {
                            sb.append(time).append("|");
                        }
                        writeReportLog(BG_5_SYS_DETAIL, "|", key, "|", sb.toString());
                    }
                    bg5MinSdkMap.clear();
                    bg5MinSysMap.clear();
                }
            }
        }

        @Override
        public void onHookReady() {
            if (!isRunning) {
                return;
            }
            try {
                // api level 1的放前边

				doHook();

            } catch (Throwable t) {
                Magnifier.ILOGUTIL.exception(TAG, t);
            }
        }
        
			public void doHook() {
		DexposedBridge.findAndHookMethod(LocationManager.class, "requestLocationUpdates", String.class, long.class, float.class, LocationListener.class, new XC_MethodHook() {
			@Override
			public void beforeHookedMethod(@NonNull MethodHookParam param) {
//				super.beforeHookedMethod(param);
				onGPSScan("requestLocationUpdates",param.args);
			}

			@Override
			public void afterHookedMethod(MethodHookParam param) {
//				super.afterHookedMethod(param);
			}
		});

		DexposedBridge.findAndHookMethod(LocationManager.class, "requestLocationUpdates", String.class, long.class, float.class, LocationListener.class, Looper.class, new XC_MethodHook() {
			@Override
			public void beforeHookedMethod(@NonNull MethodHookParam param) {
//				super.beforeHookedMethod(param);
				onGPSScan("requestLocationUpdates",param.args);
			}

			@Override
			public void afterHookedMethod(MethodHookParam param) {
//				super.afterHookedMethod(param);
			}
		});


		DexposedBridge.findAndHookMethod(LocationManager.class, "requestLocationUpdates", String.class, long.class, float.class, PendingIntent.class, new XC_MethodHook() {
			@Override
			public void beforeHookedMethod(@NonNull MethodHookParam param) {
//				super.beforeHookedMethod(param);
				onGPSScan("requestLocationUpdates",param.args);
			}

			@Override
			public void afterHookedMethod(MethodHookParam param) {
//				super.afterHookedMethod(param);
			}
		});

		DexposedBridge.findAndHookMethod(LocationManager.class, "requestLocationUpdates", long.class, float.class, Criteria.class, LocationListener.class, Looper.class, new XC_MethodHook() {
			@Override
			public void beforeHookedMethod(@NonNull MethodHookParam param) {
//				super.beforeHookedMethod(param);
				onGPSScan("requestLocationUpdates",param.args);
			}

			@Override
			public void afterHookedMethod(MethodHookParam param) {
//				super.afterHookedMethod(param);
			}
		});

		DexposedBridge.findAndHookMethod(LocationManager.class, "requestLocationUpdates", long.class, float.class, Criteria.class, PendingIntent.class, new XC_MethodHook() {
			@Override
			public void beforeHookedMethod(@NonNull MethodHookParam param) {
//				super.beforeHookedMethod(param);
				onGPSScan("requestLocationUpdates",param.args);
			}

			@Override
			public void afterHookedMethod(MethodHookParam param) {
//				super.afterHookedMethod(param);
			}
		});

		DexposedBridge.findAndHookMethod(LocationManager.class, "requestSingleUpdate", String.class, PendingIntent.class, new XC_MethodHook() {
			@Override
			public void beforeHookedMethod(@NonNull MethodHookParam param) {
//				super.beforeHookedMethod(param);
				onGPSScan("requestLocationUpdates",param.args);
			}

			@Override
			public void afterHookedMethod(MethodHookParam param) {
//				super.afterHookedMethod(param);
			}
		});

		DexposedBridge.findAndHookMethod(LocationManager.class, "requestSingleUpdate", String.class, LocationListener.class, Looper.class, new XC_MethodHook() {
			@Override
			public void beforeHookedMethod(@NonNull MethodHookParam param) {
//				super.beforeHookedMethod(param);
				onGPSScan("requestLocationUpdates",param.args);
			}

			@Override
			public void afterHookedMethod(MethodHookParam param) {
//				super.afterHookedMethod(param);
			}
		});

		DexposedBridge.findAndHookMethod(LocationManager.class, "requestSingleUpdate", Criteria.class, LocationListener.class, Looper.class, new XC_MethodHook() {
			@Override
			public void beforeHookedMethod(@NonNull MethodHookParam param) {
//				super.beforeHookedMethod(param);
				onGPSScan("requestLocationUpdates",param.args);
			}

			@Override
			public void afterHookedMethod(MethodHookParam param) {
//				super.afterHookedMethod(param);
			}
		});

		DexposedBridge.findAndHookMethod(LocationManager.class, "requestSingleUpdate", Criteria.class, PendingIntent.class, new XC_MethodHook() {
			@Override
			public void beforeHookedMethod(@NonNull MethodHookParam param) {
//				super.beforeHookedMethod(param);
				onGPSScan("requestLocationUpdates",param.args);
			}

			@Override
			public void afterHookedMethod(MethodHookParam param) {
//				super.afterHookedMethod(param);
			}
		});
	}
		

    }

    @NonNull
    private static String[] sSysFramePrefixs = new String[] { "android.", "com.android.", "dalvik.", "com.google.", "sun.", "com.qihoo360", "com.lbe", "java." };
    @NonNull
    private static String[] sAppIgnoreFrameDict = new String[] { BatteryStatsImpl.class.getName() };

    private static boolean isAppStackFrame(@NonNull String frame) {
        for (String sysPrefix : sSysFramePrefixs) {
            if (frame.startsWith(sysPrefix)) {
                return false;
            }
        }
        for (String ignoreFrame : sAppIgnoreFrameDict) {
            if (frame.contains(ignoreFrame)) {
                return false;
            }
        }
        return true;
    }

    private static StringBuilder getAppStack() {
        StringBuilder sb = BatteryLog.getReuseStringBuilder();
        StackTraceElement[] elements = Thread.currentThread().getStackTrace();
        for (int i = elements.length - 1; i >= 0; i--) {
            String frame = elements[i].toString();
            if (isAppStackFrame(frame)) {
                if (sb.length() == 0) {
                    sb.append("[");
                } else {
                    sb.append(",");
                }
                sb.append(frame);
            }
        }
        if (sb.length() > 0) {
            sb.append("]");
        }
        return sb;
    }
}