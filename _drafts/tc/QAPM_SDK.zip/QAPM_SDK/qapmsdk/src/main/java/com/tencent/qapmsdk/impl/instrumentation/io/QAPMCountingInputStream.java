package com.tencent.qapmsdk.impl.instrumentation.io;

import com.tencent.qapmsdk.Magnifier;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

public class QAPMCountingInputStream extends InputStream
        implements QAPMStreamCompleteListenerSource
{
    private final static String TAG = "QAPM_Impl_QAPMCountingInputStream";
    private final InputStream impl;
    private long count = 0L;
    private final QAPMStreamCompleteListenerManager listenerManager = new QAPMStreamCompleteListenerManager();
    private final ByteBuffer buffer;
    private boolean enableBuffering = false;


    public QAPMCountingInputStream(InputStream impl) {
        this.impl = impl;

        if (this.enableBuffering) {
            this.buffer = ByteBuffer.allocate(1024);
            fillBuffer();
        } else {
            this.buffer = null;
        }
    }

    public QAPMCountingInputStream(InputStream impl, boolean enableBuffering) {
        this.impl = impl;
        this.enableBuffering = enableBuffering;

        if (enableBuffering) {
            this.buffer = ByteBuffer.allocate(1024);
            fillBuffer();
        } else {
            this.buffer = null;
        }
    }

    public void addStreamCompleteListener(QAPMStreamCompleteListener streamCompleteListener) {
        this.listenerManager.addStreamCompleteListener(streamCompleteListener);
    }

    public void removeStreamCompleteListener(QAPMStreamCompleteListener streamCompleteListener) {
        this.listenerManager.removeStreamCompleteListener(streamCompleteListener);
    }

    public int read()
            throws IOException
    {
        if (this.enableBuffering) {
            synchronized (this.buffer) {
                if (bufferHasBytes(1L)) {
                    int n = readBuffer();
                    if (n >= 0) {
                        this.count += 1L;
                    }
                    return n;
                }
            }
        }
        try
        {
            int n = this.impl.read();
            if (n >= 0)
                this.count += 1L;
            else {
                notifyStreamComplete();
            }
            return n;
        } catch (IOException e) {
            notifyStreamError(e);
            throw e;
        }
    }

    public int read(byte[] b) throws IOException
    {
        int n = 0;
        int numBytesFromBuffer = 0;
        int inputBufferRemaining = b.length;

        if (this.enableBuffering) {
            synchronized (this.buffer)
            {
                if (bufferHasBytes(inputBufferRemaining)) {
                    n = readBufferBytes(b);
                    if (n >= 0) {
                        this.count += n;
                    }
                    else {
                        throw new IOException("readBufferBytes failed");
                    }
                    return n;
                }

                int remaining = this.buffer.remaining();
                if (remaining > 0)
                {
                    numBytesFromBuffer = readBufferBytes(b, 0, remaining);
                    if (numBytesFromBuffer < 0)
                        throw new IOException("partial read from buffer failed");
                    inputBufferRemaining -= numBytesFromBuffer;
                    this.count += numBytesFromBuffer;
                }
            }
        }

        try
        {
            n = this.impl.read(b, numBytesFromBuffer, inputBufferRemaining);
            if (n >= 0) {
                this.count += n;
                return n + numBytesFromBuffer;
            }
            if (numBytesFromBuffer <= 0) {
                notifyStreamComplete();
                return n;
            }
            return numBytesFromBuffer;
        }
        catch (IOException e) {
            Magnifier.ILOGUTIL.e(TAG, e.toString());
            System.out.println("NOTIFY STREAM ERROR: " + e);
            e.printStackTrace();
            notifyStreamError(e);
            throw e;
        }
    }

    public int read(byte[] b, int off, int len) throws IOException {
        int n = 0;
        int numBytesFromBuffer = 0;
        int inputBufferRemaining = len;

        if (this.enableBuffering) {
            synchronized (this.buffer)
            {
                if (bufferHasBytes(inputBufferRemaining)) {
                    n = readBufferBytes(b, off, len);
                    if (n >= 0) {
                        this.count += n;
                    }
                    else {
                        throw new IOException("readBufferBytes failed");
                    }
                    return n;
                }

                int remaining = this.buffer.remaining();
                if (remaining > 0)
                {
                    numBytesFromBuffer = readBufferBytes(b, off, remaining);
                    if (numBytesFromBuffer < 0)
                        throw new IOException("partial read from buffer failed");
                    inputBufferRemaining -= numBytesFromBuffer;
                    this.count += numBytesFromBuffer;
                }
            }
        }

        try
        {
            n = this.impl.read(b, off + numBytesFromBuffer, inputBufferRemaining);
            if (n >= 0) {
                this.count += n;
                return n + numBytesFromBuffer;
            }
            if (numBytesFromBuffer <= 0) {
                notifyStreamComplete();
                return n;
            }
            return numBytesFromBuffer;
        }
        catch (IOException e) {
            notifyStreamError(e);
            throw e;
        }
    }

    public long skip(long byteCount) throws IOException {
        long toSkip = byteCount;

        if (this.enableBuffering) {
            synchronized (this.buffer) {
                if (bufferHasBytes(byteCount)) {
                    this.buffer.position((int)byteCount);
                    this.count += byteCount;
                    return byteCount;
                }

                toSkip = byteCount - this.buffer.remaining();
                if (toSkip > 0L)
                    this.buffer.position(this.buffer.remaining());
                else {
                    throw new IOException("partial read from buffer (skip) failed");
                }
            }
        }
        try
        {
            long n = this.impl.skip(toSkip);
            this.count += n;
            return n;
        } catch (IOException e) {
            notifyStreamError(e);
            throw e;
        }
    }

    public int available() throws IOException {
        int remaining = 0;

        if (this.enableBuffering) {
            remaining = this.buffer.remaining();
        }
        try
        {
            return remaining + this.impl.available();
        } catch (IOException e) {
            notifyStreamError(e);
            throw e;
        }
    }

    public void close() throws IOException {
        try {
            this.impl.close();
            notifyStreamComplete();
        } catch (IOException e) {
            notifyStreamError(e);
            throw e;
        }
    }

    public void mark(int readlimit) {
        if (!markSupported())
            return;
        this.impl.mark(readlimit);
    }

    public boolean markSupported() {
        return this.impl.markSupported();
    }

    public void reset() throws IOException {
        if (!markSupported())
            return;
        try
        {
            this.impl.reset();
        } catch (IOException e) {
            notifyStreamError(e);
            throw e;
        }
    }

    private int readBuffer() {
        if (bufferEmpty())
            return -1;
        return this.buffer.get();
    }

    private int readBufferBytes(byte[] bytes) {
        return readBufferBytes(bytes, 0, bytes.length);
    }

    private int readBufferBytes(byte[] bytes, int offset, int length) {
        if (bufferEmpty()) {
            return -1;
        }
        int remainingBefore = this.buffer.remaining();
        this.buffer.get(bytes, offset, length);
        return remainingBefore - this.buffer.remaining();
    }

    private boolean bufferHasBytes(long num) {
        return this.buffer.remaining() >= num;
    }

    private boolean bufferEmpty() {
        if (this.buffer.hasRemaining()) {
            return false;
        }
        return true;
    }

    public void fillBuffer() {
        if (this.buffer != null) {
            if (!this.buffer.hasArray()) {
                return;
            }
            synchronized (this.buffer) {
                int bytesRead = 0;
                try {
                    bytesRead = this.impl.read(this.buffer.array(), 0, this.buffer.capacity());
                } catch (IOException e) {
                    Magnifier.ILOGUTIL.e(TAG, e.toString());
                }
                if (bytesRead <= 0) {
                    this.buffer.limit(0);
                }
                else if (bytesRead < this.buffer.capacity())
                    this.buffer.limit(bytesRead);
            }
        }
    }

    private void notifyStreamComplete()
    {
        if (!this.listenerManager.isComplete())
            this.listenerManager.notifyStreamComplete(new QAPMStreamCompleteEvent(this, this.count));
    }

    private void notifyStreamError(Exception e)
    {
        if (!this.listenerManager.isComplete())
            this.listenerManager.notifyStreamError(new QAPMStreamCompleteEvent(this, this.count, e));
    }

    public void setBufferingEnabled(boolean enableBuffering)
    {
        this.enableBuffering = enableBuffering;
    }

    public String getBufferAsString() {
        if (this.buffer != null) {
            synchronized (this.buffer) {
                byte[] buf = new byte[this.buffer.limit()];
                for (int i = 0; i < this.buffer.limit(); i++) {
                    buf[i] = this.buffer.get(i);
                }
                return new String(buf);
            }
        }
        return "";
    }
}
