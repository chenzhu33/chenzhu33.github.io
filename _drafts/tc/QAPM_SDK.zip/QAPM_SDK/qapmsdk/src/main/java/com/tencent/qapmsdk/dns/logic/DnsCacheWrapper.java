package com.tencent.qapmsdk.dns.logic;

import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Patterns;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.dns.HttpDns;
import com.tencent.qapmsdk.dns.policy.IpPolicy;
import com.tencent.qapmsdk.dns.utils.Utils;

/**
 * Created by nicorao on 2017/11/30.
 */

public class DnsCacheWrapper extends LinkedHashMap {

    private static final String TAG = "QAPM_DNS_DnsCacheWrapper";

    private Field mField_AddressCacheKey_Hostname;
    private Field mField_AddressCacheEntry_Value;
    private Field mField_AddressCacheEntry_ExpiryNanos;
    private Constructor<?> mConstructor_AddressCacheEntry;

    private Field mField_InetAddress_Hostname;
    private Field mField_InetAddress$InetAddressHolder_Hostname;
    private Method mMethod_InetAddress_Holder;

    private long mStartTime;

    // <AddressCacheKey, AddressCacheEntry> or <String, AddressCacheEntry> on Android 4.4 and below
    public DnsCacheWrapper() throws Exception {
        // 获取AddressCacheKey中的host
        try {
            Class<?> clzAddressCacheKey = Class.forName("java.net.AddressCache$AddressCacheKey");
            Field fHostname = clzAddressCacheKey.getDeclaredField("mHostname");
            fHostname.setAccessible(true);
            mField_AddressCacheKey_Hostname = fHostname;
        } catch (Throwable ignored) {
            // Android 4.4及以下没有AddressCacheKey，此时的key为String，即host
        }

        // 获取AddressCacheEntry中的value，是一个InetAddress[]
        Class<?> clzAddressCacheEntry = Class.forName("java.net.AddressCache$AddressCacheEntry");
        Field fValue = clzAddressCacheEntry.getDeclaredField("value");
        fValue.setAccessible(true);
        mField_AddressCacheEntry_Value = fValue;

        // 获取AddressCacheEntry中的expiryNanos
        Field fExpiryNanos = clzAddressCacheEntry.getDeclaredField("expiryNanos");
        fExpiryNanos.setAccessible(true);
        mField_AddressCacheEntry_ExpiryNanos = fExpiryNanos;

        // 获取AddressCacheEntry的构造函数
        try {
            Constructor<?> constructorAddressCacheEntry = clzAddressCacheEntry.getDeclaredConstructor(Object.class);
            constructorAddressCacheEntry.setAccessible(true);
            mConstructor_AddressCacheEntry = constructorAddressCacheEntry;
        } catch (Exception ignored) {
            // Android 4.0是两个参数的构造函数
            Constructor<?> constructorAddressCacheEntry = clzAddressCacheEntry.getDeclaredConstructor(Object.class, long.class);
            constructorAddressCacheEntry.setAccessible(true);
            mConstructor_AddressCacheEntry = constructorAddressCacheEntry;
        }

        try {
            Field fHostName = InetAddress.class.getDeclaredField("hostName");
            fHostName.setAccessible(true);
            mField_InetAddress_Hostname = fHostName;
        } catch (Exception e) {
            // Android 7.0以上，hostName移入InetAddress$InetAddressHolder中
            Class<?> clzInetAddressHolder = Class.forName("java.net.InetAddress$InetAddressHolder");
            Field fHostName = clzInetAddressHolder.getDeclaredField("hostName");
            fHostName.setAccessible(true);
            mField_InetAddress$InetAddressHolder_Hostname = fHostName;

            Method mHolder = InetAddress.class.getDeclaredMethod("holder");
            mHolder.setAccessible(true);
            mMethod_InetAddress_Holder = mHolder;
        }
    }

    @Override
    public Object get(Object key) {
        // key为AddressCacheKey（Android 4.4及以下为String），需要返回AddressCacheEntry，
        // AddressCacheEntry中包含一个InetAddress[]和一个ttl，
        // 这里的ttl设为最大，真正的ttl由内部cache决定
        try {
            String host = (String) (mField_AddressCacheKey_Hostname != null ? mField_AddressCacheKey_Hostname.get(key) : key);
            InetAddress[] inetAddresses = lookup(host);
            if (inetAddresses != null && inetAddresses.length > 0) {
                // 构造需要返回AddressCacheEntry
                Object entry;
                if (mConstructor_AddressCacheEntry.getParameterTypes().length == 1) {
                    entry = mConstructor_AddressCacheEntry.newInstance((Object) inetAddresses);
                } else {
                    // Android 4.0是两个参数的构造函数
                    entry = mConstructor_AddressCacheEntry.newInstance((Object) inetAddresses, Long.MAX_VALUE);
                }
                // 将超时时间设为最大，真正的生命周期由DnsCacheManager管理
                mField_AddressCacheEntry_ExpiryNanos.set(entry, Long.MAX_VALUE);
                return entry;
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, "return AddressCacheEntry failed", e);
        }
        // 在get中记录开始时间，在put中计算耗时
        mStartTime = SystemClock.elapsedRealtime();
        return null;
    }

    @Override
    public Object put(Object key, Object value) {
        // key为AddressCacheKey（Android 4.4及以下为String），value为需要返回AddressCacheEntry，
        // AddressCacheEntry中的value可能是InetAddress[]，也可能是String的错误信息，忽略后者
        try {
            final String host = (String) (mField_AddressCacheKey_Hostname != null ? mField_AddressCacheKey_Hostname.get(key) : key);
            final Object entryValue = mField_AddressCacheEntry_Value.get(value);
            if (entryValue instanceof InetAddress[]) {
                InetAddress[] inetAddresses = (InetAddress[]) entryValue;
                final long cost = SystemClock.elapsedRealtime() - mStartTime;
                Utils.getAsyncCallbackWrapper().onResolveDns(HttpDns.DnsType.SYSTEM, host, inetAddresses, cost);
                Magnifier.ILOGUTIL.i(TAG, "[systemdns] " , host , ", cost: " , String.valueOf(cost) , "ms");
                List<String> ipList = getIps(inetAddresses);
                if (ipList != null && ipList.size() > 0) {
                    DnsCacheManager.getInstance().update(host, ipList, 600, DnsCacheManager.FROM_SYSTEM_DNS);
                }
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, "update system dns cache failed", e);
        }
        return null;
    }

    /**
     * 解析DNS，优先处理本地设置的域名-IP映射，再处理httpdns，这里的入参域名一定不为空，且不为IP，
     * 返回null，则走系统DNS
     *
     * @param host 待DNS的域名
     * @return
     */
    private InetAddress[] lookup(String host) {
        Magnifier.ILOGUTIL.i(TAG, "try to lookup: " + host);
        // 先处理本地有设置ip的域名
        long sTime = SystemClock.elapsedRealtime();
        List<String> localIpList = LocalDnsManager.getInstance().getIpList(host);
        if (localIpList != null && localIpList.size() > 0) {
            InetAddress[] inetAddresses = getSortedInetAddresses(host, localIpList);
            final long cost = SystemClock.elapsedRealtime() - sTime;
            Utils.getAsyncCallbackWrapper().onResolveDns(HttpDns.DnsType.LOCAL, host, inetAddresses, cost);
            Magnifier.ILOGUTIL.d(TAG, "[localdns] " , host  , ", cost: " , String.valueOf(cost) , "ms");
            return inetAddresses;
        }
        // 如果有系统proxy，则使用systemdns
        final String httpProxy = System.getProperty("http.proxyHost");
        final String httpsProxy = System.getProperty("https.proxyHost");
        if (!TextUtils.isEmpty(httpProxy) || !TextUtils.isEmpty(httpsProxy)) {
            Magnifier.ILOGUTIL.d(TAG, "has system proxy, http: " + httpProxy + ", https: " + httpsProxy + ", fallback to system dns");
            return null;
        }
        // 再次判断是否ip，有少量案例似乎有ip进来
        if (Patterns.IP_ADDRESS.matcher(host).matches()) {
            Magnifier.ILOGUTIL.d(TAG, "host is ip! host: " , host , ", fallback to system dns");
            return null;
        }
        // 检查cache，如果有则使用
        List<String> cacheIpList = DnsCacheManager.getInstance().getIpList(host);
        if (cacheIpList != null && cacheIpList.size() > 0) {
            InetAddress[] inetAddresses = getSortedInetAddresses(host, cacheIpList);
            final long cost = SystemClock.elapsedRealtime() - sTime;
            Utils.getAsyncCallbackWrapper().onResolveDns(HttpDns.DnsType.CACHE, host, inetAddresses, cost);
            Magnifier.ILOGUTIL.d(TAG, "[cachedns] " , host , ", cost: " , String.valueOf(cost) , "ms");
            return inetAddresses;
        }
//        List<String> ipList = HttpDnsManager.getInstance().getIpList(host);
//        if (ipList != null && ipList.size() > 0) {
//            InetAddress[] inetAddresses = getSortedInetAddresses(host, ipList);
//            final long cost = SystemClock.elapsedRealtime() - sTime;
//            Utils.getAsyncCallbackWrapper().onResolveDns(HttpDns.DnsType.HTTP, host, inetAddresses, cost);
//            HLog.i(TAG, "[httpdns] " + host + " ===> " + Utils.dumpInetAddresses(inetAddresses) + ", cost: " + cost + "ms");
//            return inetAddresses;
//        }
        Magnifier.ILOGUTIL.d(TAG, host , " fallback to system dns");
        return null;
    }

    @Nullable
    private InetAddress[] getSortedInetAddresses(String host, List<String> ipList) {
        ipList = IpPolicy.getPolicy().sort(host, ipList);
        return getInetAddresses(host, ipList.toArray(new String[ipList.size()]));
    }

    private InetAddress[] getInetAddresses(String host, String...ips) {
        if (ips == null || ips.length == 0) return null;
        List<InetAddress> list = new ArrayList<>();
        for (String ip : ips) {
            if (Utils.isIp(ip)) {
                try {
                    InetAddress ia = InetAddress.getByName(ip);
                    if (ia != null) {
                        if (mField_InetAddress_Hostname != null) {
                            mField_InetAddress_Hostname.set(ia, host);
                        } else if (mField_InetAddress$InetAddressHolder_Hostname != null && mMethod_InetAddress_Holder != null) {
                            mField_InetAddress$InetAddressHolder_Hostname.set(mMethod_InetAddress_Holder.invoke(ia), host);
                        }
                        list.add(ia);
                    } else {
                        Magnifier.ILOGUTIL.w(TAG, "getByName null, ip: " , ip);
                    }
                } catch (Exception e) {
                    // do nothing but log
                    Magnifier.ILOGUTIL.exception(TAG, "getByName failed, ip: " + ip, e);
                }
            }
        }
        Magnifier.ILOGUTIL.d(TAG, "getInetAddresses, ipSize: " , String.valueOf(ips.length) , ", ips: " , Arrays.toString(ips) , ", InetAddressSize: " , String.valueOf(list.size()));
        return list.size() == 0 ? null : list.toArray(new InetAddress[list.size()]);
    }

    private List<String> getIps(InetAddress[] inetAddresses) {
        if (inetAddresses == null || inetAddresses.length == 0) return null;
        List<String> ips = new ArrayList<>();
        for (InetAddress ia : inetAddresses) {
            if (ia == null) continue;
            String ip = ia.getHostAddress();
            if (!TextUtils.isEmpty(ip)) ips.add(ip);
        }
        return ips;
    }
}
