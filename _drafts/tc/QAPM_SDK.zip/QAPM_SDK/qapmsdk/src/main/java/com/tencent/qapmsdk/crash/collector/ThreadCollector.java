package com.tencent.qapmsdk.crash.collector;

import android.content.Context;
import android.support.annotation.NonNull;

import com.tencent.qapmsdk.crash.builder.ReportBuilder;
import com.tencent.qapmsdk.crash.config.CoreConfiguration;
import com.tencent.qapmsdk.crash.config.ReportField;
import com.tencent.qapmsdk.crash.data.CrashReportData;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public final class ThreadCollector extends BaseReportFieldCollector {

    public ThreadCollector() {
        super(ReportField.THREAD_DETAILS);
    }

    @NonNull
    @Override
    public Order getOrder() {
        return Order.LATE;
    }

    @Override
    void collect(@NonNull ReportField reportField, @NonNull Context context, @NonNull CoreConfiguration config, @NonNull ReportBuilder reportBuilder, @NonNull CrashReportData target) throws Exception {
        switch (reportField) {
            case THREAD_DETAILS:
                final Thread t = reportBuilder.getUncaughtExceptionThread();
                target.put(ReportField.THREAD_DETAILS, getThreadDetail(t));
                break;
            case THREAD_ALL:
                Map<Thread, JSONObject> threadsDetail = new HashMap<>();
                for(Thread thread: getAllThread()){
                    JSONObject result = getThreadDetail(thread);
                    threadsDetail.put(thread, result);
                }target.put(ReportField.THREAD_ALL, threadsDetail);

                break;
            default:
                //will not happen if used correctly
                throw new IllegalArgumentException();
        }

    }

    @NonNull
    private Set<Thread>  getAllThread() {
        return Thread.getAllStackTraces().keySet();
    }

    private JSONObject getThreadDetail(Thread t) throws JSONException {
        if (t != null) {
            final JSONObject result = new JSONObject();
            result.put("id", t.getId());
            result.put("name", t.getName());
            result.put("priority", t.getPriority());
            if (t.getThreadGroup() != null) {
                result.put("groupName", t.getThreadGroup().getName());
            }
            return result;
        }
        return  null;
    }

    @Override
    public boolean enabled(@NonNull CoreConfiguration config) {
        return true;
    }
}
