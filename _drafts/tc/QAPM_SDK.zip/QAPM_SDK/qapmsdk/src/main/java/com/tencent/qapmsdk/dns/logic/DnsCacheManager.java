package com.tencent.qapmsdk.dns.logic;


import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.dns.model.DnsCacheObj;
import com.tencent.qapmsdk.dns.model.DnsInfo;
import com.tencent.qapmsdk.dns.model.IpCachedItem;
import com.tencent.qapmsdk.dns.network.NetworkUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author nicorao
 */
public class DnsCacheManager {
    
    private static final String TAG = "QAPM_DNS_DnsCacheManager";

    static final int FROM_HTTP_DNS = 1;
    static final int FROM_SYSTEM_DNS = 2;

    private static DnsCacheManager sInstance = new DnsCacheManager();

    private Map<String, DnsCacheObj> mDnsCache = new ConcurrentHashMap<>();

    private DnsCacheManager() {}

    public static DnsCacheManager getInstance() {
        return sInstance;
    }
    
    List<String> getIpList(final String host) {
        DnsCacheObj obj = mDnsCache.get(host);
        List<String> result = null;
        if (obj != null) {
            if (System.currentTimeMillis() - obj.updateTime > obj.ttl * 1000){
                //超时则删除处理
                mDnsCache.remove(host);
                DnsInfo.remove(host);
                return null;
            }
            result = new ArrayList<>(obj.getIpList());
        }
        return result;
    }

    public void update(String host, List<String> ipList, long ttl, int from) {
        DnsCacheObj obj = mDnsCache.get(host);
        if (obj == null || !(obj.from == FROM_HTTP_DNS && from == FROM_SYSTEM_DNS)) {
            synchronized (this) {
                obj = mDnsCache.get(host);
                if (obj == null || !(obj.from == FROM_HTTP_DNS && from == FROM_SYSTEM_DNS)) {
                    Magnifier.ILOGUTIL.d(TAG, "update cache, host: " , host , ", ipList: " + ipList , ", ttl: " , String.valueOf(ttl) , "s, from: " , (from == FROM_HTTP_DNS ? "httpdns" : "systemdns"));
                    obj = new DnsCacheObj();
                    obj.host = host;
                    obj.ttl = ttl;
                    obj.updateTime = System.currentTimeMillis();
                    obj.wifi = NetworkUtils.isWifi();
                    obj.ssid = DnsCacheObj.hash(NetworkUtils.getWifiSsid());
                    CopyOnWriteArrayList<IpCachedItem> ipCachedItems = new CopyOnWriteArrayList<>();
                    for (String ip : ipList) {
                        ipCachedItems.add(new IpCachedItem(ip));
                    }
                    obj.ipList = ipCachedItems;
                    obj.from = from;
                    mDnsCache.put(host, obj);
                } else {
                    Magnifier.ILOGUTIL.d(TAG, "no need to update cache: " , obj.host);
                }
            }
        } else {
            Magnifier.ILOGUTIL.d(TAG, "no need to update cache: " , obj.host);
        }
    }

    public DnsCacheObj getDnsCache(String host) {
        return mDnsCache.get(host);
    }

    public void invalidate() {
        for (String host : mDnsCache.keySet()) {
            DnsCacheObj obj = mDnsCache.get(host);
            if (obj != null) obj.ttl = 0;
        }
    }

    public void clear() {
        mDnsCache.clear();
        DnsInfo.clear();
    }
}
