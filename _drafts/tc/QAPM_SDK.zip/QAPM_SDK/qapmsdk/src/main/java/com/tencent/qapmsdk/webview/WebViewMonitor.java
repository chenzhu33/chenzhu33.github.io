package com.tencent.qapmsdk.webview;

public class WebViewMonitor {
    private WebViewReport webViewReport;

    public WebViewMonitor(int threshold){
        webViewReport = new WebViewReport(true, threshold);
    }

    public void start(){
        if (webViewReport != null){
            webViewReport.monitor();
        }
    }

    public void stop(){
        webViewReport.setMonitorStatue(false);
    }
}
