package com.tencent.qapmsdk.impl.httpOprate;

import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionState;

import java.io.IOException;

import okhttp3.Request;
import okhttp3.Response;

public interface IDataCollect {
    boolean isCanCollect();

    void collectException(QAPMTransactionState qapmTransactionState, IOException exception) throws Exception;

    void collectRequest(Request request, QAPMTransactionState qapmTransactionState) throws Exception;

    void collectResponse(Response response, QAPMTransactionState qapmTransactionState) throws Exception;

    boolean canCollect();
}
