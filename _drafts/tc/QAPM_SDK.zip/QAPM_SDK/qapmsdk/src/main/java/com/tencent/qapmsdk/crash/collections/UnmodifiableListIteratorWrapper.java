package com.tencent.qapmsdk.crash.collections;

import java.util.ListIterator;

class UnmodifiableListIteratorWrapper<E> implements ListIterator<E> {
    private final ListIterator<E> mIterator;

    UnmodifiableListIteratorWrapper(ListIterator<E> mIterator) {
        this.mIterator = mIterator;
    }

    @Override
    public void add(E object) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean hasNext() {
        return mIterator.hasNext();
    }

    @Override
    public boolean hasPrevious() {
        return mIterator.hasPrevious();
    }

    @Override
    public E next() {
        return mIterator.next();
    }

    @Override
    public int nextIndex() {
        return mIterator.nextIndex();
    }

    @Override
    public E previous() {
        return mIterator.previous();
    }

    @Override
    public int previousIndex() {
        return mIterator.previousIndex();
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void set(E object) {
        throw new UnsupportedOperationException();
    }
}


