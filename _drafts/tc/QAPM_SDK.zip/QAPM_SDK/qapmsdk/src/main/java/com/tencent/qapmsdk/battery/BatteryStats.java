package com.tencent.qapmsdk.battery;

class BatteryStats {
    public void onProcessStart() {
    }

    public void onHookReady() {
    }
    
    public void onAppBackground() {
    }
    
    public void onAppForeground() {
    }
}