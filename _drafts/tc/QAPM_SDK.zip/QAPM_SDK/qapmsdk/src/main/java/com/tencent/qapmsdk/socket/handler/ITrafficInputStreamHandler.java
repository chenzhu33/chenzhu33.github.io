package com.tencent.qapmsdk.socket.handler;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.socket.model.SocketInfo;


public interface ITrafficInputStreamHandler {
    void onInput(@NonNull byte[] b, int off, int len, int read, @Nullable SocketInfo socketInfo);
    void onClose();
}
