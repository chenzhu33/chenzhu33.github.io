package com.tencent.qapmsdk.crash.builder;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.crash.collections.WeakStack;

import java.util.ArrayList;
import java.util.List;

public final class LastActivityManager {

    private static final String LOG_TAG = ILogUtil.getTAG(LastActivityManager.class);
    @NonNull
    private final WeakStack<Activity> activityStack = new WeakStack<>();

    /**
     * Create and register a new instance
     *
     * @param application the application to attach to
     */
    public LastActivityManager(@NonNull Application application) {

        application.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {

            @Override
            public void onActivityCreated(@NonNull Activity activity, Bundle savedInstanceState) {
                Magnifier.ILOGUTIL.d(LOG_TAG, "onActivityCreated " + activity.getClass());
                activityStack.add(activity);
            }

            @Override
            public void onActivityStarted(@NonNull Activity activity) {
                Magnifier.ILOGUTIL.d(LOG_TAG, "onActivityStarted " + activity.getClass());
            }

            @Override
            public void onActivityResumed(@NonNull Activity activity) {
                Magnifier.ILOGUTIL.d(LOG_TAG, "onActivityResumed " + activity.getClass());
            }

            @Override
            public void onActivityPaused(@NonNull Activity activity) {
                Magnifier.ILOGUTIL.d(LOG_TAG, "onActivityPaused " + activity.getClass());
            }

            @Override
            public void onActivityStopped(@NonNull Activity activity) {
                Magnifier.ILOGUTIL.d(LOG_TAG, "onActivityStopped " + activity.getClass());
            }

            @Override
            public void onActivitySaveInstanceState(@NonNull Activity activity, Bundle outState) {
                Magnifier.ILOGUTIL.d(LOG_TAG, "onActivitySaveInstanceState " + activity.getClass());
            }

            @Override
            public void onActivityDestroyed(@NonNull Activity activity) {
                Magnifier.ILOGUTIL.d(LOG_TAG, "onActivityDestroyed " + activity.getClass());
                synchronized (activityStack) {
                    activityStack.remove(activity);
                    activityStack.notify();
                }
            }
        });
    }

    /**
     * @return last created activity, if any
     */
    @Nullable
    public Activity getLastActivity() {
        return activityStack.peek();
    }

    /**
     * @return a list of activities in the current process
     */
    @NonNull
    public List<Activity> getLastActivities() {
        return new ArrayList<>(activityStack);
    }

    /**
     * clear saved activities
     */
    public void clearLastActivities() {
        activityStack.clear();
    }

    /**
     * wait until the last activity is stopped
     *
     * @param timeOutInMillis timeout for wait
     */
    public void waitForAllActivitiesDestroy(int timeOutInMillis) {
        synchronized (activityStack) {
            long start = System.currentTimeMillis();
            long now = start;
            while (!activityStack.isEmpty() && start + timeOutInMillis > now) {
                try {
                    activityStack.wait(start - now + timeOutInMillis);
                } catch (InterruptedException ignored) {
                }
                now = System.currentTimeMillis();
            }
            Magnifier.ILOGUTIL.i(LOG_TAG, "now killed all activities.");
        }
    }
}
