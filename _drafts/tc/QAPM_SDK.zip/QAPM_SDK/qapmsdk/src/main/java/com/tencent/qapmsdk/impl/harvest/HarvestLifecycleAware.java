package com.tencent.qapmsdk.impl.harvest;

public abstract interface HarvestLifecycleAware
{
    public abstract void onHarvestStart();

    public abstract void onHarvestStop();

    public abstract void onHarvestBefore();

    public abstract void onHarvest();

    public abstract void onHarvestFinalize();

    public abstract void onHarvestError();

    public abstract void onHarvestSendFailed();

    public abstract void onHarvestComplete();

    public abstract void onHarvestConnected();

    public abstract void onHarvestDisconnected();

    public abstract void onHarvestDisabled();

    public abstract void onHarvestDeviceIdError();

    public abstract void onHarvestFilter();
}
