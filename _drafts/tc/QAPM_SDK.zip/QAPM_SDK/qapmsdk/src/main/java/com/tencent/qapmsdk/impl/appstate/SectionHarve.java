package com.tencent.qapmsdk.impl.appstate;

import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTraceUnit;
import com.tencent.qapmsdk.impl.instrumentation.QAPMUnit;
import com.tencent.qapmsdk.impl.instrumentation.TraceType;
import com.tencent.qapmsdk.impl.report.MonitorReport;
import com.tencent.qapmsdk.impl.util.TraceUtil;
import com.tencent.qapmsdk.sample.PerfCollector;
import com.tencent.qapmsdk.sample.TagType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

public class SectionHarve {
    protected final ConcurrentHashMap<UUID, QAPMUnit> c = new ConcurrentHashMap();
    public final Set<UUID> d = Collections.synchronizedSet(new HashSet());
    private long exitTimestamp;
    protected long entryTimestamp = System.currentTimeMillis();
    public QAPMTraceUnit unit;
    private boolean traceFinished = false;
    private TraceType.CONTEXT traceType;
    private long threshold = 0;

    public SectionHarve(QAPMTraceUnit unit, long threshold, TraceType.CONTEXT traceType) {
        this.unit = unit;
        this.unit.entryTimestamp = System.currentTimeMillis();
        this.unit.nodeType = 0;
        this.traceType = traceType;
        this.threshold = threshold;
    }

    public SectionHarve exitTrace() {
        if (this.traceFinished) {
            return null;
        } else {
            this.traceFinished = true;
            this.unit.exitTimestamp = System.currentTimeMillis();
            this.exitTimestamp = this.unit.exitTimestamp;
            return this;
        }
    }

    public void setEntryTimestamp(long entryTimestamp){
        this.unit.entryTimestamp = entryTimestamp;
        this.entryTimestamp = entryTimestamp;
    }

    public void setExitTimestamp(long exitTimestamp){
        this.unit.exitTimestamp = exitTimestamp;
        this.exitTimestamp = exitTimestamp;
    }

    public void readyToReport(QAPMMonitorThreadLocal qapmMonitorThreadLocal){
        MonitorReport monitorReport = MonitorReport.getInstance();
        long duringTime = this.unit.exitTimestamp - this.unit.entryTimestamp;
        monitorReport.addMonitorMetric(this.unit.entryTimestamp,
                this.unit.entryTimestamp,
                this.unit.exitTimestamp,
                this.unit.metricName,
                this.unit.subMetricName,
                duringTime > threshold);

        Vector<QAPMUnit> finishedMehods = qapmMonitorThreadLocal.getFinishedMethodThreadLocal().get();
        //空用户打点情况
        if (finishedMehods != null){
            for (QAPMUnit unit : finishedMehods){
                monitorReport.addMonitorMetric(this.unit.entryTimestamp,
                        unit.entryTimestamp,
                        unit.exitTimestamp,
                        unit.metricName,
                        unit.subMetricName,
                        false);
            }
        }
        //因为用的是102上报，所以得用102来开关控制
        if (duringTime > threshold && CollectStatus.canCollect(Config.PLUGIN_QCLOUD_LOOPER_STACK)){
            try {
                JSONArray ja = new JSONArray();
                ja.put(serializeEvent(this.unit.entryTimestamp, this.unit, true));
                ja.put(serializeEvent(this.unit.entryTimestamp, this.unit, false));
                for (QAPMUnit unit : finishedMehods){
                    ja.put(serializeEvent(this.unit.entryTimestamp, unit, true));
                    ja.put(serializeEvent(this.unit.entryTimestamp, unit, false));
                }
                JSONObject jo = new JSONObject();
                jo.put("manu_tags", ja);
                if (TraceUtil.LAUNCH_KATEGRORY.contains(this.unit.subMetricName)){
                    monitorReport.addMonitorSingle(duringTime, this.unit.entryTimestamp, this.unit.subMetricName, jo.toString());
                }
                else{
                    monitorReport.addMonitorSingle(duringTime, this.unit.entryTimestamp, this.unit.metricName, jo.toString());
                }

            }
            catch (JSONException e){
            }

        }
        monitorReport.doReport();
        qapmMonitorThreadLocal.clear();
    }

    private JSONObject serializeEvent(long tagId, QAPMUnit unit, boolean isBegin) throws JSONException{
        JSONObject jo = new JSONObject();
        jo.put("event_time", isBegin ? unit.entryTimestamp / 1000.0 : unit.exitTimestamp / 1000.0);
        jo.put("tag_id", tagId);
        jo.put("during_time", isBegin ? 0 : unit.exitTimestamp - unit.entryTimestamp);
        jo.put("type", isBegin ? TagType.BEGINTAG : TagType.ENDTAG);
        jo.put("stage", unit.metricName);
        jo.put("sub_stage", unit.subMetricName);
        jo.put("extra_info", "");
        jo.put("process_name", "");
        jo.put("is_slow", 0);
        return jo;
    }

}
