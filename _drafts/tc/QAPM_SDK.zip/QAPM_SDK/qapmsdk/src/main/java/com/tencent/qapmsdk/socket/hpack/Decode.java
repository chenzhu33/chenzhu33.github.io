package com.tencent.qapmsdk.socket.hpack;

import com.tencent.qapmsdk.Magnifier;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import okio.Buffer;
import okio.BufferedSource;
import okio.Okio;
import okio.Source;
import okio.Timeout;

import static com.tencent.qapmsdk.socket.hpack.Http2.FLAG_COMPRESSED;
import static com.tencent.qapmsdk.socket.hpack.Http2.FLAG_END_HEADERS;
import static com.tencent.qapmsdk.socket.hpack.Http2.FLAG_END_STREAM;
import static com.tencent.qapmsdk.socket.hpack.Http2.FLAG_PADDED;
import static com.tencent.qapmsdk.socket.hpack.Http2.FLAG_PRIORITY;
import static com.tencent.qapmsdk.socket.hpack.Http2.INITIAL_MAX_FRAME_SIZE;
import static com.tencent.qapmsdk.socket.hpack.Http2.TYPE_CONTINUATION;
import static com.tencent.qapmsdk.socket.hpack.Http2.TYPE_DATA;
import static com.tencent.qapmsdk.socket.hpack.Http2.TYPE_HEADERS;
import static com.tencent.qapmsdk.socket.hpack.Http2.TYPE_PRIORITY;
import static com.tencent.qapmsdk.socket.hpack.Http2.frameLog;
import static com.tencent.qapmsdk.socket.hpack.Http2.ioException;
import static com.tencent.qapmsdk.socket.hpack.Http2Reader.lengthWithoutPadding;

public class Decode {
    private static final String TAG = "HTTP2Decode";
    private BufferedSource source;
    private Decode.ContinuationSource continuation;
    private Hpack.Reader hpackReader;

    public Decode(InputStream inputStream){
        source = Okio.buffer(Okio.source(inputStream));
        continuation = new Decode.ContinuationSource(this.source);
        hpackReader = new Hpack.Reader(4096, continuation);

    }

    public boolean readFrame(Http2Reader.Handler handler) throws IOException{
        try {
            source.require(9); // Frame header size
        } catch (IOException e) {
            return false; // This might be a normal socket close.
        }
        //  0                   1                   2                   3
        //  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
        // +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
        // |                 Length (24)                   |
        // +---------------+---------------+---------------+
        // |   Type (8)    |   Flags (8)   |
        // +-+-+-----------+---------------+-------------------------------+
        // |R|                 Stream Identifier (31)                      |
        // +=+=============================================================+
        // |                   Frame Payload (0...)                      ...
        // +---------------------------------------------------------------+
        int length = readMedium(source);
        if (length < 0 || length > INITIAL_MAX_FRAME_SIZE) {
            throw ioException("FRAME_SIZE_ERROR: %s", length);
        }
        byte type = (byte) (source.readByte() & 0xff);
        byte flags = (byte) (source.readByte() & 0xff);
        int streamId = (source.readInt() & 0x7fffffff); // Ignore reserved bit.
        Magnifier.ILOGUTIL.d(TAG, frameLog(true, streamId, length, type, flags));

        switch (type) {
            case TYPE_DATA:
                readData(handler, length, flags, streamId);
                break;

            case TYPE_HEADERS:
                readHeaders(handler, length, flags, streamId);
                break;

            case TYPE_PRIORITY:
                readPriority(handler, length, flags, streamId);
                break;
//
//            case TYPE_RST_STREAM:
//                readRstStream(handler, length, flags, streamId);
//                break;
//
//            case TYPE_SETTINGS:
//                readSettings(handler, length, flags, streamId);
//                break;
//
//            case TYPE_PUSH_PROMISE:
//                readPushPromise(handler, length, flags, streamId);
//                break;
//
//            case TYPE_PING:
//                readPing(handler, length, flags, streamId);
//                break;
//
//            case TYPE_GOAWAY:
//                readGoAway(handler, length, flags, streamId);
//                break;
//
//            case TYPE_WINDOW_UPDATE:
//                readWindowUpdate(handler, length, flags, streamId);
//                break;

            default:
                // Implementations MUST discard frames that have unknown or unsupported types.
                source.skip(length);
        }
        return true;
    }


    private void readHeaders(Http2Reader.Handler handler, int length, byte flags, int streamId)
            throws IOException {
        if (streamId == 0) throw ioException("PROTOCOL_ERROR: TYPE_HEADERS streamId == 0");

        boolean endStream = (flags & FLAG_END_STREAM) != 0;
        boolean endHeader = (flags & FLAG_END_HEADERS) != 0;

        short padding = (flags & FLAG_PADDED) != 0 ? (short) (source.readByte() & 0xff) : 0;

        if ((flags & FLAG_PRIORITY) != 0) {
            readPriority(handler, streamId);
            length -= 5; // account for above read.
        }

        length = lengthWithoutPadding(length, flags, padding);

        List<Header> headerBlock = readHeaderBlock(length, padding, flags, streamId);
        handler.headers(endStream, endHeader, streamId, -1, headerBlock);
    }

    private List<Header> readHeaderBlock(int length, short padding, byte flags, int streamId)
            throws IOException {
        continuation.length = continuation.left = length;
        continuation.padding = padding;
        continuation.flags = flags;
        continuation.streamId = streamId;

        // TODO: Concat multi-value headers with 0x0, except COOKIE, which uses 0x3B, 0x20.
        // http://tools.ietf.org/html/draft-ietf-httpbis-http2-17#section-8.1.2.5
        hpackReader.readHeaders();
        return hpackReader.getAndResetHeaderList();
    }

    private void readData(Http2Reader.Handler handler, int length, byte flags, int streamId)
            throws IOException {
        if (streamId == 0) throw ioException("PROTOCOL_ERROR: TYPE_DATA streamId == 0");

        // TODO: checkState open or half-closed (local) or raise STREAM_CLOSED
        boolean inFinished = (flags & FLAG_END_STREAM) != 0;
        boolean gzipped = (flags & FLAG_COMPRESSED) != 0;
        if (gzipped) {
            throw ioException("PROTOCOL_ERROR: FLAG_COMPRESSED without SETTINGS_COMPRESS_DATA");
        }

        short padding = (flags & FLAG_PADDED) != 0 ? (short) (source.readByte() & 0xff) : 0;
        length = lengthWithoutPadding(length, flags, padding);

        handler.data(inFinished, streamId, source, length);
        source.skip(padding);
    }

    private void readPriority(Http2Reader.Handler handler, int length, byte flags, int streamId)
            throws IOException {
        if (length != 5) throw ioException("TYPE_PRIORITY length: %d != 5", length);
        if (streamId == 0) throw ioException("TYPE_PRIORITY streamId == 0");
        readPriority(handler, streamId);
    }

    private void readPriority(Http2Reader.Handler handler, int streamId) throws IOException {
        int w1 = source.readInt();
        boolean exclusive = (w1 & 0x80000000) != 0;
        int streamDependency = (w1 & 0x7fffffff);
        int weight = (source.readByte() & 0xff) + 1;
        handler.priority(streamId, streamDependency, weight, exclusive);
    }

    static final class ContinuationSource implements Source {
        private final BufferedSource source;

        int length;
        byte flags;
        int streamId;

        int left;
        short padding;

        ContinuationSource(BufferedSource source) {
            this.source = source;
        }

        @Override public long read(Buffer sink, long byteCount) throws IOException {
            while (left == 0) {
                source.skip(padding);
                padding = 0;
                if ((flags & FLAG_END_HEADERS) != 0) return -1;
                readContinuationHeader();
                // TODO: test case for empty continuation header?
            }

            long read = source.read(sink, Math.min(byteCount, left));
            if (read == -1) return -1;
            left -= read;
            return read;
        }

        @Override public Timeout timeout() {
            return source.timeout();
        }

        @Override public void close() throws IOException {
        }

        private void readContinuationHeader() throws IOException {
            int previousStreamId = streamId;

            length = left = readMedium(source);
            byte type = (byte) (source.readByte() & 0xff);
            flags = (byte) (source.readByte() & 0xff);
            Magnifier.ILOGUTIL.d(TAG, frameLog(true, streamId, length, type, flags));
            streamId = (source.readInt() & 0x7fffffff);
            if (type != TYPE_CONTINUATION) throw ioException("%s != TYPE_CONTINUATION", type);
            if (streamId != previousStreamId) throw ioException("TYPE_CONTINUATION streamId changed");
        }
    }


    static int readMedium(BufferedSource source) throws IOException {
        return (source.readByte() & 0xff) << 16
                | (source.readByte() & 0xff) << 8
                | (source.readByte() & 0xff);
    }

}
