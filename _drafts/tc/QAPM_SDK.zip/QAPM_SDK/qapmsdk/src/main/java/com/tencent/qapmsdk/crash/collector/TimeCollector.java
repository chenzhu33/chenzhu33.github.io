package com.tencent.qapmsdk.crash.collector;


import android.content.Context;
import android.support.annotation.NonNull;

import com.tencent.qapmsdk.crash.CrashConstants;
import com.tencent.qapmsdk.crash.builder.ReportBuilder;
import com.tencent.qapmsdk.crash.config.CoreConfiguration;
import com.tencent.qapmsdk.crash.config.ReportField;
import com.tencent.qapmsdk.crash.data.CrashReportData;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

public class TimeCollector extends BaseReportFieldCollector implements ApplicationStartupCollector {

    private final SimpleDateFormat dateFormat;
    private Calendar appStartDate;

    public TimeCollector() {
        super(ReportField.USER_APP_START_DATE, ReportField.USER_CRASH_DATE, ReportField.USER_APP_START_TIMESTAMP, ReportField.USER_CRASH_TIMESTAMP);
        dateFormat = new SimpleDateFormat(CrashConstants.DATE_TIME_FORMAT_STRING, Locale.ENGLISH);
    }

    @Override
    void collect(@NonNull ReportField reportField, @NonNull Context context, @NonNull CoreConfiguration config, @NonNull ReportBuilder reportBuilder, @NonNull CrashReportData target) {
        Calendar time = null;
        long timeMillis = 0;
        switch (reportField) {
            case USER_APP_START_DATE:
                time = appStartDate;
                break;
            case USER_CRASH_DATE:
                time = new GregorianCalendar();
                break;
            case USER_APP_START_TIMESTAMP:
                timeMillis = appStartDate.getTimeInMillis();
                break;
            case USER_CRASH_TIMESTAMP:
                timeMillis = System.currentTimeMillis();
                break;
            default:
                //will not happen if used correctly
                throw new IllegalArgumentException();
        }
        if(time!=null){
            target.put(reportField, getTimeString(time));
        }else if(timeMillis!=0) {
            target.put(reportField,String.valueOf(timeMillis));
        }


    }

    @Override
    public void collectApplicationStartUp(@NonNull Context context, @NonNull CoreConfiguration config) {
        appStartDate = new GregorianCalendar();
    }

    @Override
    boolean shouldCollect(@NonNull Context context, @NonNull CoreConfiguration config, @NonNull ReportField collect, @NonNull ReportBuilder reportBuilder) {
        return collect == ReportField.USER_CRASH_DATE || super.shouldCollect(context, config, collect, reportBuilder);
    }

    @NonNull
    private String getTimeString(@NonNull Calendar time) {
        return dateFormat.format(time.getTimeInMillis());
    }

    @NonNull
    @Override
    public Order getOrder() {
        return Order.NORMAL;
    }

    @Override
    public boolean enabled(@NonNull CoreConfiguration config) {
        return false;
    }
}
