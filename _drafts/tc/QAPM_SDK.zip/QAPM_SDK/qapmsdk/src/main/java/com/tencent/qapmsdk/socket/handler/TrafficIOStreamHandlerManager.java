package com.tencent.qapmsdk.socket.handler;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.report.TrafficMonitorReport;
import com.tencent.qapmsdk.impl.util.StringUtil;
import com.tencent.qapmsdk.socket.TrafficMonitor;
import com.tencent.qapmsdk.socket.hpack.Decode;
import com.tencent.qapmsdk.socket.hpack.Http2Reader;
import com.tencent.qapmsdk.socket.model.SocketInfo;
import com.tencent.qapmsdk.socket.model.SocketTracer;
import com.tencent.qapmsdk.socket.model.Utf8Checker;
import com.tencent.qapmsdk.socket.util.ArrayUtils;
import com.tencent.qapmsdk.socket.util.ThreadUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.zip.GZIPInputStream;

import okio.BufferedSource;


public class TrafficIOStreamHandlerManager {

    private static final Set<ITrafficInputStreamHandlerFactory> sInputStreamHandlersFactories = Collections.newSetFromMap(new ConcurrentHashMap<ITrafficInputStreamHandlerFactory, Boolean>());
    private static final Set<ITrafficOutputStreamHandlerFactory> sOutputStreamHandlersFactories = Collections.newSetFromMap(new ConcurrentHashMap<ITrafficOutputStreamHandlerFactory, Boolean>());

    static {
        sInputStreamHandlersFactories.add(new DefaultTrafficInputStreamHandlerFactory());
        sOutputStreamHandlersFactories.add(new DefaultTrafficOutputStreamHandlerFactory());
    }

    public static void addInputStreamHandlerFactory(ITrafficInputStreamHandlerFactory factory) {
        if (factory == null) return;
        sInputStreamHandlersFactories.add(factory);
    }

    public static void addOutputStreamHandlerFactory(ITrafficOutputStreamHandlerFactory factory) {
        if (factory == null) return;
        sOutputStreamHandlersFactories.add(factory);
    }

    public static void removeInputStreamHandlerFactory(ITrafficInputStreamHandlerFactory factory) {
        if (factory == null) return;
        sInputStreamHandlersFactories.remove(factory);
    }

    public static void removeOutputStreamHandlerFactory(ITrafficOutputStreamHandlerFactory factory) {
        if (factory == null) return;
        sOutputStreamHandlersFactories.remove(factory);
    }

    public static void clearInputStreamHandlerFactories() {
        sInputStreamHandlersFactories.clear();
    }

    public static void clearOutputStreamHandlerFactories() {
        sOutputStreamHandlersFactories.clear();
    }

    public static Set<ITrafficInputStreamHandlerFactory> getInputStreamHandlersFactories() {
        return sInputStreamHandlersFactories;
    }

    public static Set<ITrafficOutputStreamHandlerFactory> getOutputStreamHandlersFactories() {
        return sOutputStreamHandlersFactories;
    }

    private static class DefaultTrafficInputStreamHandlerFactory implements ITrafficInputStreamHandlerFactory {

        @Override
        public ITrafficInputStreamHandler create() {
            return new DefaultTrafficInputStreamHandler();
        }
    }

    private static class DefaultTrafficOutputStreamHandlerFactory implements ITrafficOutputStreamHandlerFactory {

        @Override
        public ITrafficOutputStreamHandler create() {
            return new DefaultTrafficOutputStreamHandler();
        }
    }

    private static class DefaultTrafficInputStreamHandler implements ITrafficInputStreamHandler {

        private static final String TAG = "QAPM_Socket_TrafficinputStream";

        private String mTag;
        private String mPath;
        private Package mPackage;
        private boolean finish;
        private boolean mCanHandleHttp1;
        private boolean mCanHandleHttp2;

        private List<Byte> mTempList = new ArrayList<>();

        private DumpInputStreamTask mDumpInputStreamTask;

        class DumpInputStreamTask implements Runnable {

            AtomicLong mTotal = new AtomicLong();

            DumpInputStreamTask acquire(int bytes) {
                mTotal.getAndAdd(bytes);
                return this;
            }

            @Override
            public void run() {
                Magnifier.ILOGUTIL.d(TAG, "[" , mTag , "] <=== read " , String.valueOf(mTotal.getAndSet(0)) , " bytes");
            }
        }

        DefaultTrafficInputStreamHandler() {
            mDumpInputStreamTask = new DumpInputStreamTask();
        }

        @Override
        public void onInput(@NonNull byte[] b, int off, int len, int read, @Nullable SocketInfo socketInfo) {
            if (socketInfo != null && (finish || TextUtils.isEmpty(mTag) || socketInfo.path != null && !socketInfo.path.equals(mPath))) {
                finish = false;
                mPath = socketInfo.path;
                socketInfo.resetForInput();
                mTag = makeTag(socketInfo);
                mPackage = new Package(false, socketInfo);
                mCanHandleHttp1 = socketInfo.version != null && socketInfo.version.startsWith("HTTP/1");
                mCanHandleHttp2 = socketInfo.version != null && socketInfo.version.startsWith("HTTP/2");
            }
            socketInfo.receivedBytes += len;
            if (TrafficMonitor.config().isVerbose() && read > 0 && mCanHandleHttp1 && mPackage != null) {
                Header header = mPackage.header;
                Body body = mPackage.body;
                if (!header.isCompleted) {
                    header.parse(b, off, read);
                    if (header.isCompleted) {
                        if (socketInfo != null) {
                            mTag = makeTag(socketInfo);
                            body.remain = socketInfo.contentLength;
                        }
                        byte[] buffer = header.baos.toByteArray();
                        // 从header.offset到结尾
                        body.parse(buffer, header.offset, buffer.length - header.offset);
                    }
                } else {
                    body.parse(b, off, read);
                }
                if (header.isCompleted && body.isCompleted && mCanHandleHttp1) {
                    // body完成
//                    Magnifier.ILOGUTIL.d(TAG, "read <<< [" , mTag , "]\n" , new String(mPackage.toByteArray()));
                    Magnifier.ILOGUTIL.d(TAG, "http1 read finished <<< ", mTag);
                    finish = true;
                }
            }

            if (TrafficMonitor.config().isVerbose() && len > 0 && mCanHandleHttp2) {
                InputStream inputStream = new ByteArrayInputStream(b);
                Decode decode = new Decode(inputStream);
                Header header = mPackage.header;
                Body body = mPackage.body;
                try {
                    decode.readFrame(new Http2Handle(mPackage));
                    if (header.isCompleted && body.isCompleted && mCanHandleHttp2) {
                        // body完成
                        Magnifier.ILOGUTIL.d(TAG, "http2 read finished <<< ", mTag);
                        finish = true;
                    }
                }
                catch (Exception e){

                }

            }

            if (read == 1) {
                // 避免上层在循环中调用read()，使得日志输出过多，这里合并一下，
                // 读出长度为1的，在下次len不为1时或close时输出
                mTempList.add(b[0]);
            } else if (read > 1) {
                ThreadUtils.replaceSingle(mDumpInputStreamTask.acquire(read), 500);
                if (TrafficMonitor.config().isVerbose() && !mCanHandleHttp1) {
                    byte[] buffer;
                    if (mPackage != null && mPackage.size() > 0 && !mCanHandleHttp2) {
                        buffer = mPackage.toByteArray();
                        mPackage.reset();
                    } else {
                        buffer = new byte[read];
                        System.arraycopy(b, off, buffer, 0, read);
                    }
                    if (!new Utf8Checker().isPlaintext(buffer)) {
                        buffer = ("binary " + buffer.length + "-bytes body omitted").getBytes();
                    }
                    Magnifier.ILOGUTIL.d(TAG, "read <<< [" , mTag , "]\n" , new String(buffer));
                }
                if (mTempList.size() > 0) {
                    ThreadUtils.replaceSingle(mDumpInputStreamTask.acquire(mTempList.size()), 500);
                    if (TrafficMonitor.config().isVerbose() && !mCanHandleHttp1) {
                        byte[] buffer;
                        if (mPackage != null && mPackage.size() > 0 && !mCanHandleHttp2) {
                            buffer = mPackage.toByteArray();
                            mPackage.reset();
                        } else {
                            buffer = ArrayUtils.toPrimitive(mTempList.toArray(new Byte[0]));
                        }
                        if (!new Utf8Checker().isPlaintext(buffer)) {
                            buffer = ("binary " + buffer.length + "-bytes body omitted").getBytes();
                        }
                        Magnifier.ILOGUTIL.d(TAG, "read <<< [" , mTag , "]\n" , new String(buffer));
                    }
                    mTempList.clear();
                }
            }
            if (finish){
                if (!socketInfo.hasSaved){
                    TrafficMonitorReport.getInstance().addSocketToQueue(socketInfo);
                    socketInfo.hasSaved = true;
                }
                SocketTracer.addSocketInfoToMap(socketInfo.protocol + "://" +socketInfo.host + socketInfo.path, socketInfo);
            }
        }

        @Override
        public void onClose() {
            if (mTempList.size() > 0) {
                ThreadUtils.replaceSingle(mDumpInputStreamTask.acquire(mTempList.size()), 500);
                if (TrafficMonitor.config().isVerbose() && !mCanHandleHttp1 && mPackage != null) {
                    Body body = mPackage.body;
                    if (body.baos.size() > 0) {
//                        Magnifier.ILOGUTIL.d(TAG, "read <<< [" , mTag + "]\n" , new String(mPackage.body.toByteArray()));
                        body.baos.reset();
                    } else {
//                        Magnifier.ILOGUTIL.d(TAG, "read <<< [" , mTag , "]\n" , new String(ArrayUtils.toPrimitive(mTempList.toArray(new Byte[0]))));
                    }
                    Magnifier.ILOGUTIL.d(TAG, "input stream close ", mTag);
                }
                mTempList.clear();
            }
        }
    }

    private static class DefaultTrafficOutputStreamHandler implements ITrafficOutputStreamHandler {

        private static final String TAG = "QAPM_Socket_TrafficOutputStream";

        private String mTag;
        private String mPath;
        private Package mPackage;
        private boolean finish;
        private boolean mCanHandleHttp1;
        private boolean mCanHandleHttp2;

        private DumpOutputStreamTask mDumpOutputStreamTask;

        class DumpOutputStreamTask implements Runnable {
            AtomicLong mTotal = new AtomicLong();

            DumpOutputStreamTask acquire(int bytes) {
                mTotal.getAndAdd(bytes);
                return this;
            }

            @Override
            public void run() {
                Magnifier.ILOGUTIL.d(TAG, "[" , mTag , "] ===> write " , String.valueOf(mTotal.getAndSet(0)) , " bytes");
            }
        }

        DefaultTrafficOutputStreamHandler() {
            mDumpOutputStreamTask = new DumpOutputStreamTask();
        }

        @Override
        public void onOutput(@NonNull byte[] b, int off, int len, SocketInfo socketInfo) {
            // 需要考虑okhttp中连接复用的问题
            if (finish || TextUtils.isEmpty(mTag) || socketInfo.path != null && !socketInfo.path.equals(mPath)) {
                finish = false;
                mPath = socketInfo.path;
                socketInfo.resetForOutput();
                mTag = makeTag(socketInfo);
                mPackage = new Package(true, socketInfo);
                mCanHandleHttp1 = socketInfo.version != null && socketInfo.version.startsWith("HTTP/1");
                mCanHandleHttp2 = socketInfo.version != null && socketInfo.version.startsWith("HTTP/2");
            }
            socketInfo.sendBytes += len;
            if (TrafficMonitor.config().isVerbose() && len > 0 && mCanHandleHttp1) {
                Header header = mPackage.header;
                Body body = mPackage.body;
                if (!header.isCompleted) {
                    header.parse(b, off, len);
                    if (header.isCompleted) {
                        mTag = makeTag(socketInfo);
                        body.remain = socketInfo.contentLength;
                        byte[] buffer = header.baos.toByteArray();
                        // 从header.offset到结尾
                        body.parse(buffer, header.offset, buffer.length - header.offset);
                    }
                } else {
                    body.parse(b, off, len);
                }
                if (header.isCompleted && body.isCompleted && mCanHandleHttp1) {
                    // body完成
//                    Magnifier.ILOGUTIL.d(TAG, "write >>> [" , mTag + "]\n" , new String(mPackage.toByteArray()));
                    Magnifier.ILOGUTIL.d(TAG, "http1 write finish >>>> ", mTag);
                    finish = true;
                }
            }
            if (TrafficMonitor.config().isVerbose() && len > 0 && mCanHandleHttp2) {
                InputStream inputStream = new ByteArrayInputStream(b);
                Decode decode = new Decode(inputStream);
                Header header = mPackage.header;
                Body body = mPackage.body;
                try {
                    decode.readFrame(new Http2Handle(mPackage));
                    if (header.isCompleted && body.isCompleted && mCanHandleHttp2) {
                        // body完成
                        Magnifier.ILOGUTIL.d(TAG, "http2 write finish >>>> ", mTag);
                        finish = true;
                    }
                }
                catch (Exception e){

                }

            }
            ThreadUtils.replaceSingle(mDumpOutputStreamTask.acquire(len), 500);
            if (TrafficMonitor.config().isVerbose() && !mCanHandleHttp1) {
                byte[] buffer;
                if (mPackage != null && mPackage.size() > 0 && !mCanHandleHttp2) {
                    buffer = mPackage.toByteArray();
                    mPackage.reset();
                } else {
                    buffer = new byte[len];
                    System.arraycopy(b, off, buffer, 0, len);
                }
                if (!new Utf8Checker().isPlaintext(buffer)) {
                    buffer = ("binary " + buffer.length + "-bytes body omitted").getBytes();
                }
                Magnifier.ILOGUTIL.d(TAG, "write >>> [" , mTag + "]\n" , new String(buffer));
            }

        }
    }

    private static class Package {
        Header header;
        Body body;

        Package(boolean isOutput, SocketInfo socketInfo) {
            this.header = new Header(isOutput, socketInfo);
            this.body = new Body(isOutput, socketInfo);
        }

        int size() {
            return header.baos.size() + body.baos.size();
        }

        void reset() {
            header.baos.reset();
            body.baos.reset();;
        }

        byte[] toByteArray() {
            byte[] headerBytes = header.toByteArray();
            byte[] bodyBytes = body.toByteArray();
            byte[] result = new byte[headerBytes.length + bodyBytes.length];
            System.arraycopy(headerBytes, 0, result, 0, headerBytes.length);
            System.arraycopy(bodyBytes, 0, result, headerBytes.length, bodyBytes.length);
            return result;
        }
    }

    private static class Data {
        boolean isOutput;
        SocketInfo socketInfo;
        boolean isCompleted;
        int offset;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        Data(boolean isOutput, SocketInfo socketInfo) {
            this.isOutput = isOutput;
            this.socketInfo = socketInfo;
        }

        String readLine(byte[] buffer) {
            for (int i = offset; i < buffer.length; i++) {
                if (buffer[i] == '\n') {
                    int start = offset;
                    int length = i - start;
                    int previous = i - 1;
                    if (previous >= 0 && buffer[previous] == '\r') {
                        length--;
                    }
                    byte[] result = new byte[length];
                    System.arraycopy(buffer, start, result, 0, length);
                    offset = i + 1;
                    return new String(result);
                }
            }
            return null;
        }

        byte[] readBytes(byte[] buffer, int byteCount) {
            int read = Math.min(buffer.length - offset, byteCount);
            byte[] result = new byte[read];
            System.arraycopy(buffer, offset, result, 0, read);
            offset += read;
            return result;
        }
    }

    private static class Header extends Data {

        Header(boolean isOutput, SocketInfo socketInfo) {
            super(isOutput, socketInfo);
        }

        byte[] toByteArray() {
            byte[] headerTmp = baos.toByteArray();
            byte[] headerBytes = new byte[offset];
            System.arraycopy(headerTmp, 0, headerBytes, 0, headerBytes.length);
            return headerBytes;
        }

        void parse(byte[] b, int offset, int len) {
            baos.write(b, offset, len);
            String line;
            byte[] tmp = baos.toByteArray();
            while ((line = readLine(tmp)) != null) {
                // 如果读到一行空行，则头部读完
                if (line.length() == 0) {
                    isCompleted = true;
                    break;
                }
                if (line.startsWith("Content-Encoding:")) {
                    String encoding = line.substring("Content-Encoding:".length(), line.length()).trim();
                    if ("gzip".equalsIgnoreCase(encoding)) {
                        socketInfo.gzip = true;
                    }
                } else if (line.startsWith("Transfer-Encoding:")) {
                    String encoding = line.substring("Transfer-Encoding:".length(), line.length()).trim();
                    if ("chunked".equalsIgnoreCase(encoding)) {
                        socketInfo.chunked = true;
                    }
                } else if (line.startsWith("Content-Length:")) {
                    String lenStr = line.substring("Content-Length:".length(), line.length()).trim();
                    try {
                        socketInfo.contentLength = Long.parseLong(lenStr);
                    } catch (Exception ignored) {}
                }
                else if (line.startsWith("Content-Type:")) {
                    String contentType = line.substring("Content-Type:".length(), line.length()).trim();
                    socketInfo.contentType = StringUtil.contentType(contentType);
                }
                else if (socketInfo.version != null && line.startsWith(socketInfo.version)){
                    String[] strs = line.split(" ");
                    if (strs.length > 2){
                        socketInfo.statusCode = Integer.decode(strs[1]);
                    }
                }
                // parse headers
                String[] parts = line.split(":");
                if (parts.length == 2) {
                    if (isOutput) {
                        socketInfo.mRequestHeaders.put(parts[0].trim(), parts[1].trim());
                    } else {
                        socketInfo.mResponseHeaders.put(parts[0].trim(), parts[1].trim());
                    }
                }
            }
        }

        void parse(List<com.tencent.qapmsdk.socket.hpack.Header> headerBlock){
            for (com.tencent.qapmsdk.socket.hpack.Header header : headerBlock){
                if (header.name.utf8().startsWith("content-encoding")){
                    if ("gzip".equalsIgnoreCase(header.value.utf8())) {
                        socketInfo.gzip = true;
                    }
                }
                else if (header.name.utf8().startsWith("transfer-encoding")) {
                    if ("chunked".equalsIgnoreCase(header.value.utf8())) {
                        socketInfo.chunked = true;
                    }
                } else if (header.name.utf8().startsWith("content-length")) {
                    try {
                        socketInfo.contentLength = Long.parseLong(header.value.utf8());
                    } catch (Exception ignored) {}
                }
                else if (header.name.utf8().startsWith("content-type")) {
                    socketInfo.contentType = StringUtil.contentType(header.value.utf8());
                }
                else if (header.name.utf8().equals(":status")) {
                    socketInfo.statusCode = Integer.decode(header.value.utf8());
                }
                else if (header.name.utf8().equals(":method")) {
                    socketInfo.method = header.value.utf8();
                }
                else if (header.name.utf8().equals(":scheme")) {
                    socketInfo.protocol = header.value.utf8();
                }
                else if (header.name.utf8().equals(":path")) {
                    socketInfo.path = header.value.utf8();
                }

                if (isOutput) {
                    socketInfo.mRequestHeaders.put(header.name.utf8(), header.value.utf8());
                } else {
                    socketInfo.mResponseHeaders.put(header.name.utf8(), header.value.utf8());
                }

            }
        }
    }

    private static class Body extends Data {

        private static final String TAG = "QAPM_Socket_Body";

        long remain;
        long chunkRemain;
        ByteArrayOutputStream chunkBaos = new ByteArrayOutputStream();
        Utf8Checker utf8Checker = new Utf8Checker();

        Body(boolean isOutput, SocketInfo socketInfo) {
            super(isOutput, socketInfo);
        }

        byte[] toByteArray() {
            byte[] bodyBytes = baos.toByteArray();
            if (socketInfo.gzip && bodyBytes.length > 0) {
                GZIPInputStream gzipIn = null;
                try {
                    gzipIn = new GZIPInputStream(new ByteArrayInputStream(bodyBytes));
                    ByteArrayOutputStream baosTmp = new ByteArrayOutputStream();
                    byte[] buffer = new byte[1024];
                    int read;
                    while ((read = gzipIn.read(buffer)) > 0) {
                        baosTmp.write(buffer, 0, read);
                    }
                    bodyBytes = baosTmp.toByteArray();
                } catch (Exception e) {
                    Magnifier.ILOGUTIL.exception(TAG, "resolve gzip failed", e);
                } finally {
                    if (gzipIn != null) {
                        try {
                            gzipIn.close();
                        } catch (IOException ignored) {}
                    }
                }
            }
            bodyBytes = HttpBodyLogInterceptor.intercept(bodyBytes, socketInfo);
            if (!utf8Checker.isPlaintext(bodyBytes)) {
                bodyBytes = ("binary " + bodyBytes.length + "-bytes body omitted").getBytes();
            }
            return bodyBytes;
        }

        void parse(byte[] b, int offset, int len) {
            if (socketInfo.chunked) {
                chunkBaos.write(b, offset, len);
                byte[] tmp = chunkBaos.toByteArray();
                while (this.offset < tmp.length) {
                    if (chunkRemain == 0) {
                        String line = readLine(tmp);
                        if (!TextUtils.isEmpty(line)) {
                            long value = 0;
                            // "30" -> '0'
                            String hexLength = line.split(";")[0];
                            for (int i = 0; i < hexLength.length(); i++) {
                                byte[] bytes = hexLength.getBytes();
                                byte bTmp = bytes[i];
                                int digit;
                                if (bTmp >= '0' && bTmp <= '9') {
                                    digit = bTmp - '0';
                                } else if (bTmp >= 'a' && bTmp <= 'f') {
                                    digit = bTmp - 'a' + 10;
                                } else if (bTmp >= 'A' && bTmp <= 'F') {
                                    digit = bTmp - 'A' + 10; // We never write uppercase, but we support reading it.
                                } else {
                                    break;
                                }
                                value <<= 4;
                                value |= digit;
                            }
                            if (value == 0) isCompleted = true;
                            chunkRemain = value;
                        }
                    }
                    if (isCompleted) break;
                    if (chunkRemain != 0) {
                        byte[] bytes = readBytes(tmp, (int) chunkRemain);
                        baos.write(bytes, 0, bytes.length);
                        chunkRemain -= bytes.length;
                    }
                }
            } else {
                baos.write(b, offset, len);
                remain -= len;
                if (remain == 0) isCompleted = true;
            }
        }
    }

    private static class Http2Handle implements Http2Reader.Handler {
        private Package mPackage;

        public Http2Handle(Package pkg){
            mPackage = pkg;
        }

        public void data(boolean inFinished, int streamId, BufferedSource source, int length)
                throws IOException{
            if (inFinished){
                mPackage.header.isCompleted = true;
            }
            mPackage.body.isCompleted = inFinished;
        }

        public void headers(boolean inFinishedStream, boolean inFinishedHeader, int streamId, int associatedStreamId,
                     List<com.tencent.qapmsdk.socket.hpack.Header> headerBlock){
            if (inFinishedStream){
                mPackage.body.isCompleted = true;
            }
            mPackage.header.isCompleted = inFinishedStream || inFinishedHeader;
            mPackage.header.parse(headerBlock);
        }

        public void priority(int streamId, int streamDependency, int weight, boolean exclusive){

        }
    }

    private static String makeTag(SocketInfo socketInfo) {
        IPathResolver pathResolver = PathResolver.getPathResolver();
        String protocol;
        if (socketInfo.version != null) {
            protocol = socketInfo.ssl ? "https" : "http";
        } else {
            protocol = socketInfo.ssl ? "ssl" : "tcp";
        }
        socketInfo.protocol = protocol;
        return socketInfo.host + "/" + socketInfo.ip +":" + socketInfo.port
                + ", " + (pathResolver != null ? pathResolver.resolve(socketInfo.path) : socketInfo.path)
                + ", " + socketInfo.version
                + ", " + socketInfo.method
                + ", " + protocol
                + ", " + socketInfo.networkType
                + (socketInfo.gzip ? ", gzip" : "")
                + (socketInfo.chunked ? ", chunked" : "")
                + ", " + socketInfo.fd + ", impl[@" + socketInfo.implHashCode
                + "], tid[" + socketInfo.threadId + "]";
    }
}

