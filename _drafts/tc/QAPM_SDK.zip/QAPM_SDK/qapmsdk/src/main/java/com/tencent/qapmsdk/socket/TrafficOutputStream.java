package com.tencent.qapmsdk.socket;

import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.RestrictTo;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.socket.handler.TrafficOutputStreamHandlerDispatcher;
import com.tencent.qapmsdk.socket.model.SocketInfo;
import com.tencent.qapmsdk.socket.util.NetworkUtils;

import java.io.IOException;
import java.io.OutputStream;


/**
 * Created by nicorao on 2017/12/6.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY)
public class TrafficOutputStream extends OutputStream {

    private static final String TAG = "QAPM_Socket_TrafficOutputStream";

    private static final String[] METHODS = {"GET", "POST", "PATCH", "PUT", "DELETE", "MOVE", "PROPPATCH", "REPORT", "HEAD", "PROPFIND", "CONNECT", "OPTIONS", "TRACE", "PRI"};

    private byte mTemp[] = new byte[1];

    private OutputStream mOut;

    private TrafficOutputStreamHandlerDispatcher mHandlerDispatcher;

    private SocketInfo mSocketInfo;

    public TrafficOutputStream(OutputStream out, SocketInfo socketInfo) {
        mOut = out;
        if (socketInfo != null) {
            mSocketInfo = socketInfo;
        }
    }

    public void initData(boolean ssl, String host, String ip, int port, String fd, int implHashCode) {
        mSocketInfo.ssl = ssl;
        mSocketInfo.host = host;
        mSocketInfo.ip = ip;
        mSocketInfo.port = port;
        mSocketInfo.fd = fd;
        mSocketInfo.implHashCode = implHashCode;
        mSocketInfo.threadId = Thread.currentThread().getId();
        mSocketInfo.networkType = NetworkUtils.getNetworkType();
        mHandlerDispatcher = new TrafficOutputStreamHandlerDispatcher();
    }

    @Override
    public void write(int b) throws IOException {
        mTemp[0] = (byte) b;
        write(mTemp, 0, 1);
    }

    @Override
    public void write(@NonNull byte[] b) throws IOException {
        write(b, 0, b.length);
    }

    @Override
    public void write(@NonNull byte[] b, int off, int len) throws IOException {
        long start = SystemClock.elapsedRealtime();
        String header = new String(b, 0, len);
        for (String method : METHODS) {
            if (header.startsWith(method)) {
                int begin = 0;
                int end = header.indexOf(" ");
                if (end != -1) {
                    mSocketInfo.method = header.substring(begin, end);
                    begin = end + 1;
                    end = header.indexOf(" ", begin);
                    if (end != -1) {
                        mSocketInfo.path = header.substring(begin, end);
                        begin = end + 1;
                        end = begin + "HTTP/1.1".length();
                        mSocketInfo.version = header.substring(begin, end);
                    }
                }
                break;
            }
        }
        if (TrafficMonitor.config().isVerbose()) {
            Magnifier.ILOGUTIL.v(TAG, "finish match, cost: " , (SystemClock.elapsedRealtime() - start) + "ms, method: " , mSocketInfo.method , ", version: " , mSocketInfo.version , ", path: " , mSocketInfo.path);
        }
        mHandlerDispatcher.dispatchWrite(b, off, len, mSocketInfo);
        mOut.write(b, off, len);
    }

    @Override
    public void flush() throws IOException {
        mOut.flush();
    }

    @Override
    public void close() throws IOException {
        mOut.close();
    }

    public void setSocketInfo(SocketInfo socketInfo) {
        mSocketInfo = socketInfo;
    }

}

