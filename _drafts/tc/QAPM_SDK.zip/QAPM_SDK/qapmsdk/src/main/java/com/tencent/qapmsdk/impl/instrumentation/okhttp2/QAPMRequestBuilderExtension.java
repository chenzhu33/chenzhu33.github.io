package com.tencent.qapmsdk.impl.instrumentation.okhttp2;

import com.squareup.okhttp.CacheControl;
import com.squareup.okhttp.Headers;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Request.Builder;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionState;

import java.net.URL;

public class QAPMRequestBuilderExtension extends Builder {
    private Builder impl;
    private QAPMTransactionState transactionState;

    public QAPMRequestBuilderExtension(Builder impl) {
        this.impl = impl;
    }

    public Builder url(String url) {
        return this.impl.url(url);
    }

    public Builder url(URL url) {
        return this.impl.url(url);
    }

    public Builder header(String name, String value) {
        return this.impl.header(name, value);
    }

    public Builder addHeader(String name, String value) {
        return this.impl.addHeader(name, value);
    }

    public Builder removeHeader(String name) {
        return this.impl.removeHeader(name);
    }

    public Builder headers(Headers headers) {
        return this.impl.headers(headers);
    }

    public Builder cacheControl(CacheControl cacheControl) {
        return this.impl.cacheControl(cacheControl);
    }

    public Builder get() {
        return this.impl.get();
    }

    public Builder head() {
        return this.impl.head();
    }

    public Builder post(RequestBody body) {
        return this.impl.post(body);
    }

    public Builder delete() {
        return this.impl.delete();
    }

    public Builder put(RequestBody body) {
        return this.impl.put(body);
    }

    public Builder patch(RequestBody body) {
        return this.impl.patch(body);
    }

    public Builder method(String method, RequestBody body) {
        return this.impl.method(method, body);
    }

    public Builder tag(Object tag) {
        return this.impl.tag(tag);
    }

    public Request build() {
        return this.impl.build();
    }
}
