package com.tencent.qapmsdk.socket.handler;

public interface ITrafficInputStreamHandlerFactory {
    ITrafficInputStreamHandler create();
}