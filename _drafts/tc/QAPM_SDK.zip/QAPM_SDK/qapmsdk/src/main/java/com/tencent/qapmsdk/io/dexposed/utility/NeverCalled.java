package com.tencent.qapmsdk.io.dexposed.utility;

import android.util.Log;

/**
 * This Class is used for get the art_quick_to_interpreter_bridge address
 * Do not call this forever!!!
 */
public class NeverCalled {
    @SuppressWarnings("unused")
    private void fake(int a) {
        Log.i(getClass().getSimpleName(), a + "Do not inline me!!");
    }
}