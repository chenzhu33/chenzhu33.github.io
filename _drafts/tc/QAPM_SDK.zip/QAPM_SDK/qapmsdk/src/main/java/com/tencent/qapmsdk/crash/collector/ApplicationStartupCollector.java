package com.tencent.qapmsdk.crash.collector;

import android.content.Context;
import android.support.annotation.NonNull;

import com.tencent.qapmsdk.crash.config.CoreConfiguration;

public interface ApplicationStartupCollector extends Collector {
    /**
     * collect startup data
     *
     * @param context a context
     * @param config  the config
     */
    void collectApplicationStartUp(@NonNull Context context, @NonNull CoreConfiguration config);
}
