package com.tencent.qapmsdk.socket;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;

import com.tencent.qapmsdk.socket.handler.TrafficInputStreamHandlerDispatcher;
import com.tencent.qapmsdk.socket.model.SocketInfo;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by nicorao on 2017/12/6.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY)
public class TrafficInputStream extends InputStream {

    private byte mTemp[] = new byte[1];

    private InputStream mIn;

    private SocketInfo mSocketInfo;

    private TrafficInputStreamHandlerDispatcher mHandlerDispatcher;

    public TrafficInputStream(InputStream in, SocketInfo socketInfo) {
        mIn = in;
        mHandlerDispatcher = new TrafficInputStreamHandlerDispatcher();
        if (socketInfo != null) {
            mSocketInfo = socketInfo;
        }
    }

    @Override
    public int read() throws IOException {
        int n = read(mTemp, 0, 1);
        if (n <= 0) {
            return -1;
        }
        return mTemp[0] & 0xff;
    }

    @Override
    public int read(@NonNull byte[] b) throws IOException {
        return read(b, 0, b.length);
    }

    @Override
    public int read(@NonNull byte[] b, int off, int len) throws IOException {
        int result = mIn.read(b, off, len);
        mHandlerDispatcher.dispatchRead(b, off, len, result, mSocketInfo);
        return result;
    }

    @Override
    public long skip(long n) throws IOException {
        return mIn.skip(n);
    }

    @Override
    public int available() throws IOException {
        return mIn.available();
    }

    @Override
    public void close() throws IOException {
        mHandlerDispatcher.dispatchClose();
        mIn.close();
    }

    @Override
    public synchronized void mark(int readlimit) {
        mIn.mark(readlimit);
    }

    @Override
    public synchronized void reset() throws IOException {
        mIn.reset();
    }

    @Override
    public boolean markSupported() {
        return mIn.markSupported();
    }

    public void setSocketInfo(SocketInfo socketInfo) {
        mSocketInfo = socketInfo;
    }
}
