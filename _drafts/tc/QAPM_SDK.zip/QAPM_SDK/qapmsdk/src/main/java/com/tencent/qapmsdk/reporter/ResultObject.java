package com.tencent.qapmsdk.reporter;

import android.support.annotation.Nullable;

import com.tencent.qapmsdk.common.RecyclablePool;

import java.io.Serializable;
import org.json.JSONObject;

public final class ResultObject extends RecyclablePool.Recyclable implements Serializable {
    
    /**  
     * serialVersionUID:TODO（用一句话描述这个变量表示什么）  
     *  
     * @since 1.0.0  
     */  
    
    private static final long serialVersionUID = -1219845830201712069L;
    
    // only to save id in db, do not use it.
    public int dbId = 0;
    public int reportType = 0;
    public String eventName = "";
    public boolean isSucceed = true;
    public long elapse = 0;
    public long size = 0;
    @Nullable
    public JSONObject params = null;
    public boolean isRealTime = false;
    public boolean isMerge = false;
    public String uin = "10000";

    public ResultObject() {}

    public ResultObject(int reportType, String eventName, boolean isSucceed, long elapse, long size, JSONObject params, boolean isRealTime, boolean isMerge, String uin) {
        this.reportType = reportType;
        this.eventName = eventName;
        this.isSucceed = isSucceed;
        this.elapse = elapse;
        this.size = size;
        this.params = params;
        this.isRealTime = isRealTime;
        this.isMerge = isMerge;
        this.uin = uin;
    }
}