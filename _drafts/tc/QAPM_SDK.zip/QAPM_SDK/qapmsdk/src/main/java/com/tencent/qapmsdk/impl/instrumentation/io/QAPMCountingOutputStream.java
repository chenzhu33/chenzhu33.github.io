package com.tencent.qapmsdk.impl.instrumentation.io;

import java.io.IOException;
import java.io.OutputStream;

public class QAPMCountingOutputStream extends OutputStream
        implements QAPMStreamCompleteListenerSource
{
    private final OutputStream impl;
    private long count = 0L;
    private final QAPMStreamCompleteListenerManager listenerManager = new QAPMStreamCompleteListenerManager();

    public QAPMCountingOutputStream(OutputStream impl) {
        this.impl = impl;
    }

    public void addStreamCompleteListener(QAPMStreamCompleteListener streamCompleteListener) {
        this.listenerManager.addStreamCompleteListener(streamCompleteListener);
    }

    public void removeStreamCompleteListener(QAPMStreamCompleteListener streamCompleteListener) {
        this.listenerManager.removeStreamCompleteListener(streamCompleteListener);
    }

    public long getCount() {
        return this.count;
    }

    public void write(int oneByte) throws IOException
    {
        try {
            this.impl.write(oneByte);
            this.count += 1L;
        }
        catch (IOException e) {
            notifyStreamError(e);
            throw e;
        }
    }

    public void write(byte[] buffer) throws IOException
    {
        try {
            this.impl.write(buffer);
            this.count += buffer.length;
        }
        catch (IOException e) {
            notifyStreamError(e);
            throw e;
        }
    }

    public void write(byte[] buffer, int offset, int count) throws IOException
    {
        try {
            this.impl.write(buffer, offset, count);
            this.count += count;
        }
        catch (IOException e) {
            notifyStreamError(e);
            throw e;
        }
    }

    public void flush() throws IOException
    {
        try {
            this.impl.flush();
        }
        catch (IOException e) {
            notifyStreamError(e);
            throw e;
        }
    }

    public void close() throws IOException
    {
        try {
            this.impl.close();
            notifyStreamComplete();
        }
        catch (IOException e) {
            notifyStreamError(e);
            throw e;
        }
    }

    private void notifyStreamComplete() {
        if (!this.listenerManager.isComplete())
            this.listenerManager.notifyStreamComplete(new QAPMStreamCompleteEvent(this, this.count));
    }

    private void notifyStreamError(Exception e)
    {
        if (!this.listenerManager.isComplete())
            this.listenerManager.notifyStreamError(new QAPMStreamCompleteEvent(this, this.count, e));
    }
}

