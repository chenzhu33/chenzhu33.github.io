package com.tencent.qapmsdk.impl.instrumentation.okhttp2;

import android.text.TextUtils;

import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.Interceptor;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import com.squareup.okhttp.Request.Builder;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.api.data.TransactionData;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionState;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionStateUtil;
import com.tencent.qapmsdk.impl.model.HttpDataModel;
import com.tencent.qapmsdk.impl.util.StringUtil;
import com.tencent.qapmsdk.impl.util.TraceUtil;

import java.io.IOException;
import java.util.Iterator;

public class QAPMCallExtension extends Call {

    private final static String TAG = "QAPM_Impl_QAPMCallExtension";
    private QAPMTransactionState transactionState;
    private Request request;
    private Call impl;
    private boolean isOkhttp2 = true;

    QAPMCallExtension(OkHttpClient client, Request request) {
        super(client, request);
        this.request = this.a(request, client);
        this.impl = client.newCall(this.request);
    }

    private Request a(Request request, OkHttpClient okHttpClient) {
        try {
            if (request != null && TraceUtil.getCanMonitorHttp()) {
//                k.a(request.url().getHost());
                if (this.transactionState == null) {
                    this.transactionState = new QAPMTransactionState(this.isOkhttp2);
                }

                this.addInterceptor(okHttpClient);
                this.transactionState.setAppPhase(0);
                Builder builder = request.newBuilder();
//                String var4 = h.j().T();
//                if (!TextUtils.isEmpty(var4) && h.j().S()) {
//                    int var5 = h.U();
//                    String var6 = h.a(var4, var5);
//                    this.transactionState.setTyIdRandomInt(var5);
//                    var3.addHeader("X-Tingyun-Id", var6);
//                }

                Request newRequest = builder.build();
                QAPMOkHttp2TransactionStateUtil.inspectAndInstrument(this.transactionState, newRequest);
                return newRequest;
            } else {
                return request;
            }
        } catch (Exception e) {
            return request;
        }
    }

    public Response execute() throws IOException {
        Response response = null;

        try {
//            this.getTransactionState().setTraces();
            response = this.impl.execute();
        } catch (IOException e) {
            this.doFailure((Exception)e, (Response)response);
            throw e;
        }

        this.doResponse(response);
        return response;
    }

    public void enqueue(Callback responseCallback) {
        try {
            this.getTransactionState().setQueueTimeStamp(System.currentTimeMillis());
        } catch (Exception e) {
            Magnifier.ILOGUTIL.e(TAG, "add enqueue time in ok3 enqueue error:" , e.getMessage());
        }

        this.impl.enqueue(new QAPMCallbackExtension(responseCallback, this.getTransactionState()));
    }

    public void cancel() {
        this.impl.cancel();
    }

    public boolean isCanceled() {
        return this.impl.isCanceled();
    }

    private void doResponse(Response response) {
        try {
            if (!TraceUtil.getCanMonitorHttp()) {
                return;
            }

            if (!this.getTransactionState().isComplete()) {
                QAPMOkHttp2TransactionStateUtil.inspectAndInstrumentResponse(this.getTransactionState(), response);
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.e(TAG, "QAPMCallExtension checkResponse() : " , e.toString());
        }

    }

    private QAPMTransactionState getTransactionState() {
        if (this.transactionState == null) {
            this.transactionState = new QAPMTransactionState(this.isOkhttp2);
        }

        return this.transactionState;
    }

    private void doFailure(Exception exception, Response var2) {
        try {
            if (!TraceUtil.getCanMonitorHttp()) {
                return;
            }

            QAPMTransactionState state = this.getTransactionState();
            QAPMTransactionStateUtil.setErrorCodeFromException(state, exception);
            if (!state.isComplete()) {
                TransactionData transactionData = state.end();
                if (transactionData == null) {
                    return;
                }

//                QAPMAndroidAgentImpl var5 = QAPMAgent.getImpl();
//                if (var5 == null) {
//                    return;
//                }
//
//                HarvestConfiguration var6 = var5.n();
//                if (var6 == null) {
//                    return;
//                }

                if (var2 != null) {
                    String contentType = var2.header("Content-Type");
                    state.setContentType(StringUtil.contentType(contentType));
                }

                //k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
                if (state.isError()) {
                    String exceptionInfo = "";
                    if (state.getException() != null) {
                        exceptionInfo = state.getException();
                    }

                    Magnifier.ILOGUTIL.d(TAG, "error message:" , exceptionInfo);
                    if (state.isError()) {
                        //todo:整理数据
                        HttpDataModel.collectData(transactionData, exceptionInfo);
                        //com.networkbench.agent.impl.g.h.a(state.getUrl(), state.getFormattedUrlParams(), state.getAllGetRequestParams(), state.getStatusCode(), exceptionInfo, state.getRequestMethodType(), transactionData.h(), transactionData.f(), transactionData.w(), transactionData.l(), transactionData.d());
                    }
                }
                else{
                    HttpDataModel.collectData(transactionData);
                }
            }
        } catch (Exception ex) {
            Magnifier.ILOGUTIL.e(TAG, "QAPMCallExtension error() har an error :" , ex.toString());
        }

    }

    private void addInterceptor(OkHttpClient httpClient) {
        try {
            Iterator iterator = httpClient.interceptors().iterator();

            while(iterator.hasNext()) {
                Interceptor interceptor = (Interceptor)iterator.next();
                if (interceptor instanceof QAPMOKhttp2Interceptor) {
                    return;
                }
            }

            httpClient.interceptors().add(new QAPMOKhttp2Interceptor());
        } catch (Exception e) {
            Magnifier.ILOGUTIL.e(TAG, "error add interceptor in ok2 " , e.getMessage());
        }

    }
}
