package com.tencent.qapmsdk.common;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import android.content.Context;
import android.nfc.Tag;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;

import com.tencent.qapmsdk.Magnifier;

public class FileUtil {
    private static final String TAG = ILogUtil.getTAG(FileUtil.class);
    private static String QAPM_ROOT = "";
    
    public static long nextFileTime = 0L;
    /**
     * 根据路径删除指定的目录或文件，无论存在与否
     * @param path 要删除的目录或文件
     */
    public static void deleteAllFilesOfDir(File path) {
        if (!path.exists())
            return;
        if (path.isFile()) {
            path.delete();
            return;
        }  
        File[] files = path.listFiles();
        if (files == null){
            return;
        }
        for (int i = 0; i < files.length; i++) {
            deleteAllFilesOfDir(files[i]);
        }  
        path.delete();
    }

    public static ArrayList<File> getFiles(@NonNull String filePath , @NonNull String reg){
        File path = new File(filePath);
        if (!path.exists()){
            return null;
        }
        File[] files = path.listFiles();
        ArrayList<File> arrayFiles = new ArrayList<File>();
        if (TextUtils.isEmpty(reg)){
            Collections.addAll(arrayFiles, files);
        }
        else{
            for (int i = 0; i < files.length; i++) {
                if(Pattern.matches(reg, files[i].getName())){
                    arrayFiles.add(files[i]);
                }
            }
        }
        return arrayFiles;
    }
    
    /**
     * 追加内容到指定的文件中
     * @param fileName 要追加的文件
     * @param message 追加的内容
     */
//    public static void appendDataToFile(String fileName, String message) {
//        File mFile = new File(fileName);
//        if (!mFile.exists() || !mFile.isFile()) {
//            System.err.println("file not exists:" + fileName);
//            return;
//        }
//        try {
//            BufferedWriter mWriter = new BufferedWriter(new FileWriter(mFile, true));
//            mWriter.write(message);
//            mWriter.flush();
//            mWriter.close();
//        } catch (IOException e) {
//            Magnifier.ILOGUTIL.exception(TAG, e);
//        }
//    }
    
    /**
     * 循环检查文件是否存在且大小不为0
     */
//    public static boolean checkFileExists(String filePath, long timeOutSecond) {
//        long time0 = System.currentTimeMillis();
//        long timeOut = timeOutSecond * 1000;
//        File file = new File(filePath);
//        while (System.currentTimeMillis() - time0 < timeOut) {
//            if (file.exists() && file.length() > 0) {
//                return true;
//            } else {
//                try {
//                    Thread.sleep(500);
//                } catch (InterruptedException e) {
//                    Magnifier.ILOGUTIL.exception(TAG, e);
//                }
//            }
//        }
//        return false;
//    }
    
    /**
     * <b>方法描述：</b>兼容4.2，4.3版本的操作系统的获取存储目录    <br/>
     *
     * @return
     * @exception    <br/>
     * @since 1.0.0
     */
    @Nullable
    private static String SDPath = null;
    @Nullable
    private static String getExternalStorageDirectory() {
        if (!TextUtils.isEmpty(SDPath)) {
            return SDPath;
        }
        // http://rdm.oa.com/RdmRefactor/issueDetail?productId=61&platformId=1&mergeId=100578803&packageId=com.tencent.qqmusic
        try {
            File outPath = Magnifier.sApp.getApplicationContext().getExternalFilesDir("/Tencent/QAPM");
            SDPath = outPath.getAbsolutePath();
        } catch (Exception e1) {
            Magnifier.ILOGUTIL.exception(TAG, "get sdpath last fail 1 ", e1);
            try {
                File outPath = Magnifier.sApp.getApplicationContext().getDir("Tencent_QAPM", Context.MODE_PRIVATE);
                SDPath = outPath.getAbsolutePath();
            }
            catch (Exception e2){
                Magnifier.ILOGUTIL.exception(TAG, "get sdpath last fail 2 ", e2);
                SDPath = "";
            }

        }
        return SDPath;
    }

    public static String getRootPath(){
        if(QAPM_ROOT == null || QAPM_ROOT.isEmpty()){
            QAPM_ROOT = getExternalStorageDirectory();
        }
        return QAPM_ROOT;
    }

    public static String readOutputFromFile(String pathToFile) {
        File file = new File(pathToFile);
        BufferedReader br;
        StringBuffer sb = new StringBuffer(1024);
        if (!(file.exists())) {
            return "";
        }
        if (file.canRead()) {
            try {

                br = new BufferedReader(new FileReader(file), 1024);
                String s;
                while ((s = br.readLine()) != null) {
                    sb.append(s);
                }
            } catch (Exception e) {
                Magnifier.ILOGUTIL.exception(TAG, "filePath: " + pathToFile, e);
            }

            return sb.toString();

        }
        return "";

    }
    /**
     * 
     * @param allFiles 压缩文件的列表
     * @param outputPath 输出zip文件的路径
     * @return 压缩是否成功
     */
    public static boolean zipFiles(@NonNull List<String> allFiles, @NonNull String outputPath) {
        boolean result = false;
        try {
            FileOutputStream outStream = new FileOutputStream(new File(outputPath));
            ZipOutputStream zipStream = new ZipOutputStream(new BufferedOutputStream(outStream));
            try {
                for (String file : allFiles) {
                    File sourceFile = new File(file);
                    if (sourceFile.exists()) {
                        zipStream.putNextEntry(new ZipEntry(sourceFile.getName()));
                        zipStream.setLevel(9);
                        FileInputStream in = new FileInputStream(sourceFile);
                        try {
                            byte[] buffer = new byte[20480];
                            int len = -1;
                            while ((len = in.read(buffer, 0, 20480)) != -1) {
                                zipStream.write(buffer, 0, len); // 耗时操作
                            }
                        } finally {
                            in.close();
                            zipStream.flush();
                            zipStream.closeEntry();
                        }
                    }
                }
                result = true;
            } catch (IOException e) {
                Magnifier.ILOGUTIL.exception(TAG, "outputPath: " + outputPath, e);
            } finally {
                if (zipStream != null) {
                    try {
                        zipStream.close();
                    } catch (IOException e) {
                        Magnifier.ILOGUTIL.exception(TAG, "zipStream exception: ", e);
                    }
                }
                if (outStream != null) {
                    try {
                        outStream.close();
                    } catch (IOException e) {
                        Magnifier.ILOGUTIL.exception(TAG, "outStream exception: ", e);
                    }
                }
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
        return result;
    }
    
    /**
     * 
     * @param dir 压缩路径
     * @param outputPath 输出zip文件的路径
     * @return 压缩是否成功
     */
    public static boolean zipFiles(@NonNull String dir, @NonNull String outputPath) {
        boolean result = false;
        try {
            FileOutputStream outStream = new FileOutputStream(new File(outputPath));
            ZipOutputStream zipStream = new ZipOutputStream(new BufferedOutputStream(outStream));
            try {
                File path = new File(dir);
                File[] allFiles = path.listFiles();
                for (File sourceFile : allFiles) {
                    if (sourceFile.exists() && sourceFile.isFile()) {
                        zipStream.putNextEntry(new ZipEntry(sourceFile.getName()));
                        zipStream.setLevel(9);
                        FileInputStream in = new FileInputStream(sourceFile);
                        try {
                            byte[] buffer = new byte[20480];
                            int len = -1;
                            while ((len = in.read(buffer, 0, 20480)) != -1) {
                                zipStream.write(buffer, 0, len); // 耗时操作
                            }
                        } finally {
                            in.close();
                            zipStream.flush();
                            zipStream.closeEntry();
                        }
                    }
                }
                result = true;
            } catch (IOException e) {
                Magnifier.ILOGUTIL.exception(TAG, "outputPath: " + outputPath, e);
            } finally {
                if (zipStream != null) {
                    try {
                        zipStream.close();
                    } catch (IOException e) {
                        Magnifier.ILOGUTIL.exception(TAG, "zipStream exception: ", e);
                    }
                }
                if (outStream != null) {
                    try {
                        outStream.close();
                    } catch (IOException e) {
                        Magnifier.ILOGUTIL.exception(TAG, "outStream exception: ", e);
                    }
                }    
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
        return result;
    }


    /**
     * 加载so
     * @param soPath
     * @return
     */
    public static boolean loadLibrary(String soPath){
        if (VersionUtils.isX86CPU()) {
            return false;
        }
        try {
            System.loadLibrary(soPath);
        } catch (Throwable e){
            Magnifier.ILOGUTIL.exception(TAG, e);
            return false;
        }
        return true;
    }
}