package com.tencent.qapmsdk.impl.instrumentation.io;

import java.util.ArrayList;
import java.util.List;

public class QAPMStreamCompleteListenerManager {
    private boolean streamComplete = false;
    private ArrayList<QAPMStreamCompleteListener> streamCompleteListeners = new ArrayList();

    public boolean isComplete() {
        synchronized (this) {
            return this.streamComplete;
        }
    }

    public void addStreamCompleteListener(QAPMStreamCompleteListener streamCompleteListener) {
        synchronized (this.streamCompleteListeners) {
            this.streamCompleteListeners.add(streamCompleteListener);
        }
    }

    public void removeStreamCompleteListener(QAPMStreamCompleteListener streamCompleteListener) {
        synchronized (this.streamCompleteListeners) {
            this.streamCompleteListeners.remove(streamCompleteListener);
        }
    }

    public void notifyStreamComplete(QAPMStreamCompleteEvent ev) {
        if (!checkComplete())
            for (QAPMStreamCompleteListener listener : getStreamCompleteListeners())
                listener.streamComplete(ev);
    }

    public void notifyStreamError(QAPMStreamCompleteEvent ev)
    {
        if (!checkComplete())
            for (QAPMStreamCompleteListener listener : getStreamCompleteListeners())
                listener.streamError(ev);
    }

    private boolean checkComplete()
    {
        boolean streamComplete;
        synchronized (this) {
            streamComplete = isComplete();
            if (!streamComplete) this.streamComplete = true;
        }
        return streamComplete;
    }

    private List<QAPMStreamCompleteListener> getStreamCompleteListeners()
    {
        ArrayList listeners;
        synchronized (this.streamCompleteListeners) {
            listeners = new ArrayList(this.streamCompleteListeners);
            this.streamCompleteListeners.clear();
        }
        return listeners;
    }
}

