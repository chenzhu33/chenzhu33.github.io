package com.tencent.qapmsdk.sample;

import java.util.HashMap;

/**
 * Created by nickyliu on 2018/9/30.
 */

public class TagItem {
    public double eventTime = Double.NaN;
    public long tagId = Long.MAX_VALUE;
    public int type = -1;
    public double duringTime = Double.NaN;
    public String stage = "";
    public String subStage = "";
    public String extraInfo = "";
    public long netFllowRecvBytes = Long.MAX_VALUE;
    public long netFllowSendBytes = Long.MAX_VALUE;
    public long netFllowPackets = Long.MAX_VALUE;
    public long ioCount = Long.MAX_VALUE;
    public long ioBytes = Long.MAX_VALUE;
    public boolean isSlow = false;
}
