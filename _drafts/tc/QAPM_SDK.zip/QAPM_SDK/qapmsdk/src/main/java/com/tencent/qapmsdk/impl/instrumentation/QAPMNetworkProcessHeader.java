package com.tencent.qapmsdk.impl.instrumentation;

public interface QAPMNetworkProcessHeader {
    String getFilterHeader(String var1);
}