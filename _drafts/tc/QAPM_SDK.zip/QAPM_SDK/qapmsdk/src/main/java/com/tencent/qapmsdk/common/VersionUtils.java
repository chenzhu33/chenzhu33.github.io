package com.tencent.qapmsdk.common;

import android.os.Build;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.io.art.method.ArtMethod;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;

public final class VersionUtils {
    private static boolean isCheckedHookSupport = false;
    private static boolean isHookSupportable = false;

    @Nullable
    private volatile static Boolean isThumb2 = null;
    @Nullable
    private volatile static Boolean g64 = null;

    /**
     * 版本是否在4.0之后（API 14)
     * 
     * @return
     */
    public static boolean isIceScreamSandwich() {
        return Build.VERSION.SDK_INT >= 14;
    }
    
    /**
     * 版本是否再4.1之后(API 16)
     * @return
     */
    public static boolean isJellyBean() {
        return Build.VERSION.SDK_INT >= 16;
    }
    
    /**
     * 版本是否再5.0之后(API 21)
     * @return
     */
    public static boolean isLollipop() {
        return Build.VERSION.SDK_INT >= 21;
    }
    
    /**
     * 版本是否在6.0之后(API 23)
     * @return
     */
//    public static boolean isMarshmallow() {
//        return Build.VERSION.SDK_INT >= 23;
//    }
    
    /**
     * 版本是否在7.0之后(API 24)
     * @return
     */
//    public static boolean isNougat() {
//        return Build.VERSION.SDK_INT >= 24;
//    }
    
    /**
     * 版本是否在8.0之后(API 26)
     * @return
     */
    public static boolean isO() {
        return Build.VERSION.SDK_INT >= 26;
    }

    public static boolean isP() {
        return Build.VERSION.SDK_INT >= 27;
    }
    
    //supported_abis: armeabi，armeabi-v7a，x86，mips，arm64-v8a，mips64，x86_64
//    @TargetApi(21)
//    @SuppressWarnings("deprecation")
//    public static boolean isSpecificArm(String keyword) {
//        if (isLollipop()) {
//            String[] abis = Build.SUPPORTED_ABIS;
//            for (String abi : abis) {
//                if (abi.toLowerCase(Locale.US).contains(keyword)) {
//                    return true;
//                }
//            }
//        } else {
//            return Build.CPU_ABI.toLowerCase(Locale.US).contains(keyword);
//        }
//        return false;
//    }
    
    private static String sVmVersion;
    private static boolean sIsART;
    public static boolean isART() {
        if (sVmVersion == null) {
            sVmVersion = System.getProperty("java.vm.version");
            sIsART = (sVmVersion != null && sVmVersion.startsWith("2"));
        }
        return sIsART;
    }
    

    public static boolean is64Bit() {
        if (g64 == null) {
            try {
                g64 = (Boolean) Class.forName("dalvik.system.VMRuntime").getDeclaredMethod("is64Bit").invoke(Class.forName("dalvik.system.VMRuntime").getDeclaredMethod("getRuntime").invoke(null));
            } catch (Exception e) {
                g64 = Boolean.FALSE;
            }
        }
        return g64;
    }

    public static boolean isThumb2() {
        if (isThumb2 != null){
            return isThumb2;
        }
        try {
            Method method = String.class.getDeclaredMethod("hashCode");
            ArtMethod artMethodStruct = ArtMethod.of(method);
            long entryPointFromQuickCompiledCode = artMethodStruct.getEntryPointFromQuickCompiledCode();
            isThumb2 = ((entryPointFromQuickCompiledCode & 1)) == 1;
        } catch (Throwable e) {
            Magnifier.ILOGUTIL.e("isThumb2, error:" + e.getMessage());
            return true;
        }
        return isThumb2;
    }

    public static boolean isX86CPU() {
        String value = null;
        try {
            Class<?> clazz = Class.forName("android.os.SystemProperties");
            Method get = clazz.getMethod("get", String.class, String.class);
            value = (String)(get.invoke(clazz, "ro.product.cpu.abi", ""));
        }
        catch (Exception e){
            Magnifier.ILOGUTIL.e(e.getMessage());
            return false;
        }
        return value != null && value.contains("x86");
    }

    private static boolean isYunOS() {
        String s1 = null;
        String s2 = null;
        try {
            Method m = Class.forName("android.os.SystemProperties").getMethod("get", String.class);
            s1 = (String) m.invoke(null, "ro.yunos.version");
            s2 = (String) m.invoke(null, "java.vm.name");
        } catch (NoSuchMethodException a) {
        } catch (ClassNotFoundException b) {
        } catch (IllegalAccessException c) {
        } catch (InvocationTargetException d) {
        }
        return (s2 != null && s2.toLowerCase(Locale.US).contains("lemur")) || (s1 != null && s1.trim().length() > 0);
    }

    public static synchronized boolean isHookSupport() {
        // return memory checked value.
        try {
            if (isCheckedHookSupport)
                return isHookSupportable;
            /* 对于一些国产山寨手机如红米note，会采用类似art的方式，将系统的一些jar包预编译成jex文件，提升运行效率。但是这种技术与hook技术不兼容，会导致hook的方法在被调用时crash，因此需要对其进行屏蔽。 */
            isHookSupportable = !isX86CPU() && !isYunOS() && checkFileIOCompatibility() && !is64Bit() && !new File("/system/framework/core.jar.jex").exists()
                    && Build.VERSION.SDK_INT >= 14 && Build.VERSION.SDK_INT <= 23;
        } finally {
            Magnifier.ILOGUTIL.d("hotpatch", "device support is " + isCheckedHookSupport + "checked" + isCheckedHookSupport);
            isCheckedHookSupport = true;
        }
        return isHookSupportable;
    }


    /**
     * 用来检查是否支持文件IO测试
     * 支持Android7.1及之下
     * @return
     */
    public static boolean checkFileIOCompatibility() {
        boolean isMX4Art = (Build.MODEL.contains("MX4") || Build.MODEL.contains("MX 4"))  && isART();
        return !isMX4Art && !Build.BRAND.equals("asus") && Build.VERSION.SDK_INT <= 25 && !is64Bit();
    }
    
    public static boolean inHprofBlackList() {
       return isO();
    }
}