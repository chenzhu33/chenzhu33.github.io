package com.tencent.qapmsdk.impl.instrumentation;

public @interface QAPMReplaceCallSite {
    boolean isStatic() default false;

    String scope() default "";
}