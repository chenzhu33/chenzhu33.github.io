package com.tencent.qapmsdk.impl.api.data;

import com.tencent.qapmsdk.impl.harvest.HttpLibType;
import com.tencent.qapmsdk.impl.harvest.RequestMethodType;
import com.tencent.qapmsdk.impl.instrumentation.TraceType;

public class TransactionData {
    private final long startTimeStamp;
    private final long timestamp;
    private final String url;
    private final String carrier;
    private int time;
    private final int eee;
    private int statusCode;
    private int errorCode;
    private final Object lock = new Object();
    private final long byteSent;
    private final long bytesRecieved;
    private final String appData;
    private RequestMethodType requestmethodtype;
    private HttpLibType httpLibType;
    private final String formattedUrlParams;
    private int queueTime;
    private int totalSocketTime = -1;
    private String allGetRequestParams;
    private int dnsElapse;
    private String hostAddress;
    private int tcpHandShakeTime;
    private int sslHandShakeTime;
    private int firstPackageTime;
    private String contentType;
    private String cdnHeaderName = "";
    private TraceType.b traceType;
    private String userActionId;

    public void setTotalSocketTime(int totalSocketTime) {
        this.totalSocketTime = totalSocketTime;
    }

    public int getTotalSocketTime() {
        return this.totalSocketTime;
    }

    public int getQueueTime() {
        return this.queueTime;
    }

    public String getAllGetRequestParams() {
        return this.allGetRequestParams;
    }

    public void setDnsElapse(int dnsElapse) {
        this.dnsElapse = dnsElapse;
    }

    public String getUserActionId() {
        return this.userActionId;
    }

    public void setUserActionId(String userActionId) {
        this.userActionId = userActionId;
    }

    public String getContentType() {
        return this.contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getCdnHeaderName() {
        return this.cdnHeaderName;
    }

    public void setCdnHeaderName(String cdnHeaderName) {
        this.cdnHeaderName = cdnHeaderName;
    }

    public int getDnsElapse() {
        return this.dnsElapse;
    }

    public String getHostAddress() {
        return this.hostAddress;
    }

    public void setHostAddress(String hostAddress) {
        this.hostAddress = hostAddress;
    }

    public int getTcpHandShakeTime() {
        return this.tcpHandShakeTime;
    }

    public int getSslHandShakeTime() {
        return this.sslHandShakeTime;
    }

    public void setSslHandShakeTime(int sslHandShakeTime) {
        this.sslHandShakeTime = sslHandShakeTime;
    }

    public void setTcpHandShakeTime(int tcpHandShakeTime) {
        this.tcpHandShakeTime = tcpHandShakeTime;
    }

    public void setFirstPackageTime(int firstPackageTime) {
        this.firstPackageTime = firstPackageTime;
    }

    public int getFirstPackageTime() {
        return this.firstPackageTime;
    }

    public int l() {
        return this.eee;
    }

    public TraceType.b getTraceType() {
        return this.traceType;
    }

    public void setTraceType(TraceType.b traceType) {
        this.traceType = traceType;
    }

    private String trimmedUrl(String var1) {
        int index = var1.indexOf("?");
        if (index < 0) {
            index = var1.indexOf(";");
            if (index < 0) {
                index = var1.length();
            }
        }

        return var1.substring(0, index);
    }

    public TransactionData(String url, String carrier, long startTime, int var3, int var4, int var5, long var6, long var8, String var10, String var11, String var12, RequestMethodType var13, HttpLibType var14, int var15, String var16, int var17, int var18, int var19, String var20, String var21, int var22, String var23, String var24, int var25) {
        this.url = this.trimmedUrl(url);
        this.carrier = carrier;
        this.startTimeStamp = startTime;
        this.time = var3;
        this.statusCode = var4;
        this.errorCode = var5;
        this.byteSent = var6;
        this.bytesRecieved = var8;
        this.appData = var10;
        this.timestamp = System.currentTimeMillis();
        this.formattedUrlParams = var11;
        this.requestmethodtype = var13;
        this.httpLibType = var14;
        this.dnsElapse = var15;
        this.hostAddress = var16;
        this.tcpHandShakeTime = var17;
        this.sslHandShakeTime = var18;
        this.firstPackageTime = var19;
        this.cdnHeaderName = var20;
        this.contentType = var21;
        this.eee = var22;
        this.traceType = this.traceType;
        this.userActionId = var23;
        this.allGetRequestParams = var24;
        this.queueTime = var25;
    }

    public void setRequestmethodtype(RequestMethodType requestmethodtype) {
        this.requestmethodtype = requestmethodtype;
    }

    public RequestMethodType getRequestmethodtype() {
        return this.requestmethodtype;
    }

    public String getUrl() {
        return this.url;
    }

    public String getCarrier() {
        return this.carrier;
    }

    public int getStatusCode() {
        return this.statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public int getErrorCode() {
        synchronized(this.lock) {
            return this.errorCode;
        }
    }

    public String getFormattedUrlParams() {
        return this.formattedUrlParams;
    }

    public void setErrorCode(int errorCode) {
        synchronized(this.lock) {
            this.errorCode = errorCode;
        }
    }

    public long getByteSent() {
        return this.byteSent;
    }

    public long getBytesRecieved() {
        return this.bytesRecieved;
    }

    public String getAppData() {
        return this.appData;
    }

    public HttpLibType getHttpLibType() {
        return this.httpLibType;
    }

    public void setHttpLibType(HttpLibType httpLibType) {
        this.httpLibType = httpLibType;
    }

    public long getTimestamp() {
        return this.timestamp;
    }

    public int getTime() {
        return this.time;
    }

    public void addTime(int time) {
        if (time > 0) {
            this.time += time;
        }

    }

    public long getStartTimeStamp(){
        return this.startTimeStamp;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("url:" + this.url).append(" carrier:" + this.carrier).append(" time:" + this.time).append(" statusCode:" + this.statusCode).append(" errorCode:" + this.errorCode).append(" byteSent:" + this.byteSent).append(" bytesRecieved:" + this.bytesRecieved).append(" appData:" + this.appData).append(" formattedUrlParams:" + this.formattedUrlParams).append(" requestmethodtype:" + this.requestmethodtype).append(" cdnHeaderName :" + this.cdnHeaderName).append("contentType : " + this.contentType);
        return sb.toString();
    }
}
