package com.tencent.qapmsdk.impl.httpOprate;

import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.util.TraceUtil;

import java.io.IOException;
import java.lang.reflect.Field;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class QAPMHttpCall implements Call {
    private final static String TAG = "QAPM_Impl_Call";
    private Call mCall;

    public QAPMHttpCall(OkHttpClient client, Request request) {
        this.mCall = client.newCall(request);
    }

    public Request request() {
        return this.mCall.request();
    }

    public Response execute() throws IOException {
        return this.mCall.execute();
    }

    public void enqueue(Callback callback) {
        try {
            this.setQuitTime(this.mCall.request(), System.currentTimeMillis());
        } catch (Exception e) {
            Magnifier.ILOGUTIL.e(TAG, "addHeaderRequest error:");
        }

        this.mCall.enqueue(callback);
    }

    public void cancel() {
        this.mCall.cancel();
    }

    public boolean isExecuted() {
        return this.mCall.isExecuted();
    }

    public boolean isCanceled() {
        return this.mCall.isCanceled();
    }

    public Call clone() {
        return this.mCall.clone();
    }

    private Request setQuitTime(Request request, long time) {
        Request apmRequst = request;

        try {
            if (!TraceUtil.getCanMonitorHttp()) {
                return request;
            }

            if (TextUtils.isEmpty(request.header("X-QAPM-Qt"))) {
                Field originalRequest = this.mCall.getClass().getDeclaredField("originalRequest");
                originalRequest.setAccessible(true);
                Request tmp = (Request)originalRequest.get(this.mCall);
                apmRequst = tmp.newBuilder().addHeader("X-QAPM-Qt", String.valueOf(time)).build();
                originalRequest.set(this.mCall, apmRequst);
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, "error ok3 addHeaderRequest e:", e);
        }

        return apmRequst;
    }

}
