package com.tencent.qapmsdk.impl.instrumentation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target({ElementType.METHOD})
public @interface QAPMWrapReturn {
    String className();

    String methodName();

    String methodDesc();
}
