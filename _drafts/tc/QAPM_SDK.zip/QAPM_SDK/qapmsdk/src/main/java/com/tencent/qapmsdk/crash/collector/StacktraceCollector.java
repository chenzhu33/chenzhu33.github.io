package com.tencent.qapmsdk.crash.collector;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.crash.builder.ReportBuilder;
import com.tencent.qapmsdk.crash.config.CoreConfiguration;
import com.tencent.qapmsdk.crash.config.ReportField;
import com.tencent.qapmsdk.crash.data.CrashReportData;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;

public final class StacktraceCollector extends BaseReportFieldCollector {

    public StacktraceCollector() {
        super(ReportField.STACK_TRACE, ReportField.STACK_TRACE_HASH, ReportField.STACK_TRACE_NAME, ReportField.STACK_TRACE_MESSAGE);
    }

    @NonNull
    @Override
    public Order getOrder() {
        return Order.FIRST;
    }

    @Override
    void collect(@NonNull ReportField reportField, @NonNull Context context, @NonNull CoreConfiguration config, @NonNull ReportBuilder reportBuilder, @NonNull CrashReportData target) {
        switch (reportField) {
            case STACK_TRACE:
                target.put(ReportField.STACK_TRACE, getStackTraceRows(reportBuilder.getMessage(), reportBuilder.getException()));
                break;
            case STACK_TRACE_HASH:
                target.put(ReportField.STACK_TRACE_HASH, getStackTraceHash(reportBuilder.getException()));
                break;
            case STACK_TRACE_NAME:
                target.put(ReportField.STACK_TRACE_NAME, getStackTraceName(reportBuilder.getException()));
                break;
            case STACK_TRACE_MESSAGE:
                target.put(ReportField.STACK_TRACE_MESSAGE, reportBuilder.getException().getMessage());
                break;
            case STACK_TRACE_ALL:
                target.put(ReportField.STACK_TRACE_ALL, getAllThreadStackTrace());
                break;
            default:
                //will not happen if used correctly
                throw new IllegalArgumentException();
        }
    }

    @Override
    boolean shouldCollect(@NonNull Context context, @NonNull CoreConfiguration config, @NonNull ReportField collect, @NonNull ReportBuilder reportBuilder) {
        return collect == ReportField.STACK_TRACE || super.shouldCollect(context, config, collect, reportBuilder);
    }

    @NonNull
    private String getStackTrace(@Nullable String msg, @Nullable Throwable th) {
//        final Writer result = new StringWriter();
//        try (final PrintWriter printWriter = new PrintWriter(result)) {
//            if (msg != null && !TextUtils.isEmpty(msg)) {
//                printWriter.println(msg);
//            }
//            if (th != null) {
//                th.printStackTrace(printWriter);
//            }
//            return result.toString();
//        }
        if(th!=null){
            StackTraceElement[] stacks = th.getStackTrace();
            return Arrays.toString(stacks);
        }
        return "";
    }

    private Throwable getCauseStack(Throwable t, ArrayList<String> stackStr, int deep) {
        if (t==null||deep<=0){
            return null;
        }
        StackTraceElement[] stacks = t.getStackTrace();
        for (StackTraceElement stack1 : stacks) {
            String stack = stack1.toString();
            stackStr.add(stack);
        }
        Throwable cause = t.getCause();
        return getCauseStack(cause, stackStr, --deep);
    }

    // 这里获得causeStack 是为了兼容Native层
    @NonNull
    private ArrayList<String> getStackTraceRows(@Nullable String msg, @Nullable Throwable th) {
        ArrayList<String> stackStr = new ArrayList<>();

        if (th != null) {
            StackTraceElement[] stacks = th.getStackTrace();
            for (StackTraceElement stack1 : stacks) {
                String stack = stack1.toString();
                stackStr.add(stack);
            }
            if (stacks.length<=0) {
                getCauseStack(th, stackStr, 3);
            }
        }

        return stackStr;
    }

    @NonNull
    private String getStackTraceName(@Nullable Throwable th) {
        String result = "unknown";
        if (th != null) {
            result = th.getClass().getName();
        }
        return result;
    }

    @NonNull
    private String getStackTraceHash(@Nullable Throwable th) {
        final StringBuilder res = new StringBuilder();
        Throwable cause = th;
        while (cause != null) {
            final StackTraceElement[] stackTraceElements = cause.getStackTrace();
            for (final StackTraceElement e : stackTraceElements) {
                res.append(e.getClassName());
                res.append(e.getMethodName());
            }
            cause = cause.getCause();
        }

        return Integer.toHexString(res.toString().hashCode());
    }

    @NonNull
    private Map<Thread, StackTraceElement[]> getAllThreadStackTrace() {

        return Thread.getAllStackTraces();
    }

    @Override
    public boolean enabled(@NonNull CoreConfiguration config) {
        return true;
    }
}
