package com.tencent.qapmsdk.socket.handler;

import android.os.SystemClock;
import android.support.annotation.NonNull;

import com.tencent.qapmsdk.socket.model.SocketInfo;

public class FirstPackageOutputFactory implements ITrafficOutputStreamHandlerFactory {
    private FirstPackageOutputMonitor firstPackageOutputMonitor = new FirstPackageOutputMonitor();

    public ITrafficOutputStreamHandler create(){
        if (firstPackageOutputMonitor == null){
            firstPackageOutputMonitor = new FirstPackageOutputMonitor();
        }
        return firstPackageOutputMonitor;
    }

    private class FirstPackageOutputMonitor implements ITrafficOutputStreamHandler {
        public void onOutput(@NonNull byte[] b, int off, int len, SocketInfo socketInfo){
            socketInfo.writeStamp(SystemClock.elapsedRealtime());
        }
    }
}
