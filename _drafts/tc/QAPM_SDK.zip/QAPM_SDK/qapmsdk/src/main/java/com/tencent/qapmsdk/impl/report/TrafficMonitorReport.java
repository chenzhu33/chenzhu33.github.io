package com.tencent.qapmsdk.impl.report;

import android.os.Handler;

import com.tencent.qapmsdk.common.ThreadManager;
import com.tencent.qapmsdk.impl.util.TraceUtil;
import com.tencent.qapmsdk.socket.model.SocketInfo;

import java.util.concurrent.ConcurrentLinkedQueue;

public class TrafficMonitorReport {
    private final ConcurrentLinkedQueue<SocketInfo> httpQueue = new ConcurrentLinkedQueue<SocketInfo>();
    private final ConcurrentLinkedQueue<SocketInfo> socketQueue = new ConcurrentLinkedQueue<SocketInfo>();
    private final static int QUEUELEN = 30;
    static volatile boolean hasReport = false;
    private static volatile TrafficMonitorReport instance = null;


    public static TrafficMonitorReport getInstance(){
        if (instance == null){
            synchronized (TrafficMonitorReport.class){
                if (instance == null){
                    instance = new TrafficMonitorReport();
                }
            }
        }
        return instance;
    }


    public void addSocketToQueue(SocketInfo socketInfo){
        if (socketQueue.size() > QUEUELEN){
            socketQueue.poll();
        }
        socketQueue.add(socketInfo);
    }

    public void addHttpToQueue(SocketInfo socketInfo){
        if (httpQueue.size() > QUEUELEN){
            httpQueue.poll();
        }
        httpQueue.add(socketInfo);
    }

    public ConcurrentLinkedQueue<SocketInfo> getSocketToQueue(){
        return socketQueue;
    }

    public ConcurrentLinkedQueue<SocketInfo> getHttpQueue(){
        return httpQueue;
    }

    public void doReport(){
        if (!hasReport){
            Handler h = new Handler(ThreadManager.getMonitorThreadLooper());
            TrafficReportRunnable reportRunnable = TrafficReportRunnable.getInstance();
            //todo: 调整上报频率
            h.postDelayed(reportRunnable, TraceUtil.HTTP_MONITOR_REPORT_THRESHOLD);
            hasReport = true;
        }
    }
}
