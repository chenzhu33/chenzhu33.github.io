package com.tencent.qapmsdk.crash.config;

import android.support.annotation.NonNull;

import com.tencent.qapmsdk.crash.CrashConstants;
import com.tencent.qapmsdk.crash.collections.ImmutableList;
import com.tencent.qapmsdk.crash.collector.Collector;
import com.tencent.qapmsdk.crash.collector.CustomDataCollector;
import com.tencent.qapmsdk.crash.collector.DropBoxCollector;
import com.tencent.qapmsdk.crash.collector.LogCatCollector;
import com.tencent.qapmsdk.crash.collector.StacktraceCollector;
import com.tencent.qapmsdk.crash.collector.ThreadCollector;
import com.tencent.qapmsdk.crash.collector.TimeCollector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.tencent.qapmsdk.crash.config.ReportField.*;

public enum  CoreConfiguration {
    INSTANCE;
    public Boolean alsoReportToAndroidFramework = true;
    public Boolean logcatFilterByPid = true;
    public Boolean logcatReadNonBlocking = false;
    public Boolean isSendNow = false;
    private Boolean isSendJsonByFiles = true;
    private Boolean isSendCrashDetail = false;
    private Boolean isNativeCatch = true;  // 默认开启native crash 捕获
    public String[] logcatArguments = {"-t", "" + CrashConstants.DEFAULT_LOG_LINES, "-v", "threadtime"};
    private List<Collector> collectors = new ArrayList<>();
    private ReportField[] defaultFields = {STACK_TRACE, STACK_TRACE_MESSAGE, STACK_TRACE_HASH, STACK_TRACE_NAME, USER_CRASH_TIMESTAMP, LOGCAT, THREAD_DETAILS, CUSTOM_DATA};

    private ImmutableList<ReportField> collectFields = new ImmutableList<>(defaultFields);

    final public static int DROP_BOX_COLLECTOR=1, STACKTRACE_COLLECTOR = 2, TIME_COLLECTOR = 4, LOG_CAT_COLLECTOR = 8, THREAD_COLLECTOR=16, CUSTOM_DATA_COLLECTOR=32;
    final public static int ALL_COLLECTOR = DROP_BOX_COLLECTOR|STACKTRACE_COLLECTOR | TIME_COLLECTOR | LOG_CAT_COLLECTOR | THREAD_COLLECTOR | CUSTOM_DATA_COLLECTOR;
    final public static int DEFAULT_COLLECTOR = STACKTRACE_COLLECTOR | TIME_COLLECTOR | LOG_CAT_COLLECTOR | THREAD_COLLECTOR | CUSTOM_DATA_COLLECTOR;

//    @NonNull
//    private final PluginLoader pluginLoader;

    public CoreConfiguration init(int type){

        // DropBoxCollector 系统日志收集器
        if ((type & DROP_BOX_COLLECTOR)!=0) {
            Collector collector = new DropBoxCollector();
            collectors.add(collector);
        }
        // stackTrace收集
        if ((type & STACKTRACE_COLLECTOR)!=0) {
            Collector collector = new StacktraceCollector();
            collectors.add(collector);
        }
        // 进程启动时间和crash发生时间收集
        if((type & TIME_COLLECTOR)!=0){
            Collector collector = new TimeCollector();
            collectors.add(collector);
        }
        // LOG_CAT
        if((type & LOG_CAT_COLLECTOR)!=0){
            Collector collector = new LogCatCollector();
            collectors.add(collector);
        }

        // thread info
        if((type & THREAD_COLLECTOR)!=0){
            Collector collector = new ThreadCollector();
            collectors.add(collector);
        }

        // custom data
        if((type & CUSTOM_DATA_COLLECTOR)!=0){
            Collector collector = new CustomDataCollector();
            collectors.add(collector);
        }
        return this;
    }

    public CoreConfiguration setCollectFields(ReportField[] fields) {

        this.collectFields = new ImmutableList<ReportField>(fields);
        return this;
    }

    public ImmutableList<ReportField> getCollectFields() {

        return collectFields;
    }

    public List<Collector> getCollectors() {

        return collectors;
    }

    public CoreConfiguration setIsSendNow(Boolean isSendNow) {
        this.isSendNow = isSendNow;
        return this;
    }

    public CoreConfiguration setIsSendJsonByFiles(Boolean isSendJsonByFiles){
        this.isSendJsonByFiles = isSendJsonByFiles;
        return this;
    }

    public CoreConfiguration setIsSendCrashDetail(Boolean isSendCrashDetail){

        this.isSendCrashDetail = isSendCrashDetail;
        return this;
    }

    public Boolean isSendNow() {

        return isSendNow;
    }

    public Boolean isSendJsonByFiles() {
        return isSendJsonByFiles;
    }

    public Boolean logcatFilterByPid(){
        return logcatFilterByPid;
    }

    public CoreConfiguration setIsNativeCatch(Boolean isNativeCatch){
        this.isNativeCatch = isNativeCatch;
        return this;
    }

    public Boolean isNativeCatch() {
        return isNativeCatch;
    }

    @NonNull
    public List<String> logcatArguments() {
        return Arrays.asList(logcatArguments);
    }

    @NonNull
    public Boolean logcatReadNonBlocking() {
        return logcatReadNonBlocking;
    }

    @NonNull
    public Boolean isSendCrashDetail() {

        return isSendCrashDetail;
    }

    @NonNull
    public static CoreConfiguration getInstance() {
        return CoreConfiguration.INSTANCE;
    }
}
