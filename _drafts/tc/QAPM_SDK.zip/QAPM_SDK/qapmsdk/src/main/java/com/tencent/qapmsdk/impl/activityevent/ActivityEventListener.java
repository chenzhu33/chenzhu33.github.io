package com.tencent.qapmsdk.impl.activityevent;

import com.tencent.qapmsdk.impl.instrumentation.MetricEventListener;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTraceUnit;

public class ActivityEventListener implements MetricEventListener {
    public  void enterMethod(QAPMTraceUnit metricName){

    }

    public  void exitMethod(){

    }

    public  void exitMethodCustom(String metricName){

    }

    public  void asyncEnterMethod(QAPMTraceUnit metricName){

    }
}
