package com.tencent.qapmsdk.socket.handler;

import android.support.annotation.Nullable;

public interface IPathResolver {
    String resolve(@Nullable String path);
}
