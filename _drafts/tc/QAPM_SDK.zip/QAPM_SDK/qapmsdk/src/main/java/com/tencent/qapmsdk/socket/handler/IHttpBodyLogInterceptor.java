package com.tencent.qapmsdk.socket.handler;


import com.tencent.qapmsdk.socket.model.SocketInfo;

public interface IHttpBodyLogInterceptor {
    byte[] intercept(byte[] body, SocketInfo socketInfo);
}