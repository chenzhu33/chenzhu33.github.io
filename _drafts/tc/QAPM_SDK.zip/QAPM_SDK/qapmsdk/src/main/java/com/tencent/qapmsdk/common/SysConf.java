package com.tencent.qapmsdk.common;

import android.annotation.SuppressLint;
import android.os.Build;
import android.system.Os;
import android.system.OsConstants;

/**
 * Created by nickyliu on 2018/5/30.
 */

public class SysConf {
    private static final String TAG = "Sysconf";

    @SuppressLint("ObsoleteSdkInt")
    public static long getScClkTck(long fallback) {
        long result = fallback;
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                result = Os.sysconf(OsConstants._SC_CLK_TCK);
            }
            catch (Exception e){
                result = 0;
            }
        }
        return result > 0 ? result : fallback;
    }

    @SuppressLint("ObsoleteSdkInt")
    public static long getScPageSize(long fallback) {
        long result = fallback;
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                result = Os.sysconf(OsConstants._SC_PAGESIZE);
                if (result <= 0){
                    result = Os.sysconf(OsConstants._SC_PAGE_SIZE);
                }
            }
            catch (Exception e){
                result = 0;
            }

        }
        return result > 0 ? result : fallback;
    }

    @SuppressLint("ObsoleteSdkInt")
    public static long getScNProcessorsConf(long fallback) {
        long result = fallback;
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                result = Os.sysconf(OsConstants._SC_NPROCESSORS_CONF);
            }
            catch (Exception e){
                result = 0;
            }
        }
        return result;
    }

}
