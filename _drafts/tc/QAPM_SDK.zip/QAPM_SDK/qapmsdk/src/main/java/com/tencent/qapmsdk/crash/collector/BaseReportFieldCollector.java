package com.tencent.qapmsdk.crash.collector;

import android.content.Context;
import android.support.annotation.NonNull;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.crash.builder.ReportBuilder;
import com.tencent.qapmsdk.crash.config.CoreConfiguration;
import com.tencent.qapmsdk.crash.config.ReportField;
import com.tencent.qapmsdk.crash.data.CrashReportData;

abstract class BaseReportFieldCollector implements Collector {
    private static final String LOG_TAG = ILogUtil.getTAG(BaseReportFieldCollector.class);
    private final ReportField[] reportFields;

    /**
     * create a new Collector that is able to collect these reportFields
     *
     * @param firstField   the first supported field (split away to ensure each collector supports at least one field)
     * @param reportFields the supported reportFields
     */
    BaseReportFieldCollector(@NonNull ReportField firstField, @NonNull ReportField... reportFields) {
        this.reportFields = new ReportField[reportFields.length + 1];
        this.reportFields[0] = firstField;
        if (reportFields.length > 0) {
            System.arraycopy(reportFields, 0, this.reportFields, 1, reportFields.length);
        }
    }

    /**
     * this should check if the config contains the field, but may add additional checks like permissions etc.
     *
     * @param context       a context
     * @param config        current configuration
     * @param collect       the field to collect
     * @param reportBuilder the current reportBuilder
     * @return if this field should be collected now
     */
    boolean shouldCollect(@NonNull Context context, @NonNull CoreConfiguration config, @NonNull ReportField collect, @NonNull ReportBuilder reportBuilder) {

        return config.getCollectFields().contains(collect);
    }

    /**
     * {@link #collect(ReportField, Context, CoreConfiguration, ReportBuilder, CrashReportData)} if it returned true
     */
    @Override
    public final void collect(@NonNull Context context, @NonNull CoreConfiguration config, @NonNull ReportBuilder reportBuilder, @NonNull CrashReportData target) throws CollectorException {
        for (ReportField field : reportFields) {
            try {
                if (shouldCollect(context, config, field, reportBuilder)) {
//                    Magnifier.ILOGUTIL.d(LOG_TAG, field.name() + " is collecting.");
                    collect(field, context, config, reportBuilder, target);
                }else {
//                    Magnifier.ILOGUTIL.d(LOG_TAG, field.name() + " not collect.");
                }
            } catch (Exception t) {
                target.put(field, (String) null);
                throw new CollectorException("Error while retrieving " + field.name() + " data:" + t.getMessage(), t);
            }
        }
    }

    /**
     * Collect a ReportField
     *
     * @param reportField the reportField to collect
     * @param context a context
     * @param config current Configuration
     * @param reportBuilder current ReportBuilder
     * @param target put results here
     * @throws Exception if collection failed
     */
    abstract void collect(@NonNull ReportField reportField, @NonNull Context context, @NonNull CoreConfiguration config, @NonNull ReportBuilder reportBuilder, @NonNull CrashReportData target) throws Exception;
}
