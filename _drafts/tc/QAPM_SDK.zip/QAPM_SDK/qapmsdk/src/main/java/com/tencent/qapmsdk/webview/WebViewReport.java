package com.tencent.qapmsdk.webview;

import android.annotation.TargetApi;
import android.os.Build;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ThreadManager;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.reporter.ResultObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public class WebViewReport {
    private WebViewSerialize webViewSerialize;
    private boolean canMonitorX5WebView;
    private ScheduledExecutorService reportSchedule;

//    class ReportThreadFactory implements ThreadFactory{
//        @Override
//        public Thread newThread(Runnable r){
//            return ThreadManager.getReporterThreadLooper().getThread();
//        }
//    }


    public WebViewReport(boolean canMonitorX5WebView, int monitorThreshold){
        this.webViewSerialize = WebViewSerialize.getInstance();
        this.webViewSerialize.setThreshold(monitorThreshold);
        this.canMonitorX5WebView = canMonitorX5WebView;
        this.webViewSerialize.webViewX5Proxy.setWebViewX5MonitorState(canMonitorX5WebView);
        this.reportSchedule = Executors.newSingleThreadScheduledExecutor();
    }

    public void setMonitorStatue(boolean canMonitorX5WebView){
        this.canMonitorX5WebView = canMonitorX5WebView;
        this.webViewSerialize.webViewX5Proxy.setWebViewX5MonitorState(canMonitorX5WebView);
        if(!canMonitorX5WebView && this.reportSchedule != null && !this.reportSchedule.isShutdown()){
            this.reportSchedule.shutdown();
        }
    }



    public void monitor(){
        if (this.canMonitorX5WebView && this.reportSchedule != null){
            this.reportSchedule.scheduleWithFixedDelay(new Runnable() {
                @Override
                public void run() {
                    report();
                }
            }, Config.S_WEBVIEW_REPORT_INTERVAL, Config.S_WEBVIEW_REPORT_INTERVAL, TimeUnit.SECONDS);
        }
    }

    @TargetApi(19)
    private void report(){

        if(!CollectStatus.canCollect(Config.PLUGIN_QCLOUD_WEB_VIEW)){
            //两个层的数据都清理下，避免泄漏
            this.webViewSerialize.clearCache();
            this.webViewSerialize.webViewX5Proxy.clear();
            //这里没有办法收集就直接停止定时任务吧。如果x5还在回调那么那里最多20个队列上限也泄漏不多。
            this.setMonitorStatue(false);
            return;
        }

        this.webViewSerialize.doSerialize();
        if (this.webViewSerialize.metrics.size() + this.webViewSerialize.singletons.size() == 0){
            return;
        }

        try{
            JSONObject reportJson = new JSONObject();
            ArrayList<JSONObject> tmp = new ArrayList<>(this.webViewSerialize.metrics);
            tmp.addAll(this.webViewSerialize.singletons);
            JSONArray parts = new JSONArray(tmp);

            reportJson.put("p_id", Magnifier.productId);
            reportJson.put("version", Magnifier.info.version);
            reportJson.put("uin", Magnifier.info.uin);
            reportJson.put("manu", Build.MANUFACTURER);
            reportJson.put("device", Build.MODEL);
            reportJson.put("os", Build.VERSION.RELEASE);
            reportJson.put("rdmuuid", Magnifier.info.uuid);
            reportJson.put("plugin",  Config.PLUGIN_QCLOUD_WEB_VIEW);
            reportJson.put("sdk_ver", Config.SDK_VERSION);
            reportJson.put("parts", parts);
            ResultObject ro = new ResultObject(0, "webViewMonitor", true, 1, 1, reportJson, true, false, Magnifier.info.uin);
            ReporterMachine.addResultObj(ro);

        }
        catch (JSONException e){
            Magnifier.ILOGUTIL.exception("WebViewReport", e);

        }
        finally {
            CollectStatus.addCollectCount(Config.PLUGIN_QCLOUD_WEB_VIEW);
            this.webViewSerialize.clearCache();
        }

    }
}
