package com.tencent.qapmsdk.memory;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.app.Instrumentation;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.BaseListener;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.common.RecyclablePool;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.reporter.ResultObject;

import org.json.JSONObject;

import java.io.File;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Activity检查泄漏
 * @author acolorzhang
 *
 */
public class LeakInspector {
    private static final String TAG = ILogUtil.getTAG(LeakInspector.class);

    private Handler mHandler;
    private InspectorListener mListener;
    private static LeakInspector sInspector;
    
    /**
     * 泄漏时是否要自动dump，为true的时候，会调用接口的onBeforeDump和onFinishDump，最后会生成一个zip包用于自动化测试
     */
    private static boolean sAutoDump = false;
    private static boolean sMonitoring = false;
    @Nullable
    private static Object sCurrentActivityThread = null;
    @Nullable
    private static Instrumentation sOldInstr = null;

    private static RecyclablePool sPool;
    /**
     * 检查泄漏的最大次数
     */
    private static int LOOP_MAX_COUNT = 100;


    public interface InspectorListener extends BaseListener {
        /**
         * 这个接口可以自己定义一些不想被检查的类
         * @param willCheckedObj: 将要检测的对象
         */
        boolean onFilter(Object willCheckedObj);

        /**
         *
         * @param currentWaitSecond Activity onDestroy后已经等待的时间(s)，LeakInspect最大等待500s, 此处传入值为5的倍数。
         * @param objInfo 检测对象的信息
         */
        void onCheckingLeaked(int currentWaitSecond, String objInfo);

        /**
         * 判定发生泄漏后执行的回调，可用来提前展示泄漏相关信息，也可以通过返回值认为此次并非泄漏
         * @param uuid:包含被监控对象相关信息
         * @return boolean: 默认为true，认为这是一次泄漏并开始dump，为false时认为这不是泄漏
         */
        boolean onLeaked(InspectUUID uuid);

        /**
         * 这个接口通知要dump内存，可以在这里实现Toast提醒或转圈等逻辑，因为dump的过程比较耗时而且会卡住进程
         * @param objInfo -- 对象信息
         * @return 最终上报的zip包中所需要的其他文件
         */
        List<String> onPrepareDump(String objInfo);
        
        /**
         * dump完成，可以把菊花dismiss掉了
         */
        void onFinishDump(boolean isSuccess, String objInfo, String zipPath);
    }
    
    private LeakInspector(Handler h, InspectorListener listener) {
        mHandler = h;
        mListener = listener;
    }

    public static void initInspector(Handler h, InspectorListener listener) {
        if (sInspector != null) {
            return;
        }
        sInspector = new LeakInspector(h, listener);
        sPool = new RecyclablePool(InspectUUID.class, 20);
    }

    /**
     * 开启Activity泄漏检测
     */
    @TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
    public static boolean startActivityInspect(@NonNull Application sApp) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
            sApp.registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
                @Override
                public void onActivityCreated(Activity activity, Bundle savedInstanceState) {}

                @Override
                public void onActivityStarted(Activity activity) {}

                @Override
                public void onActivityResumed(Activity activity) {}

                @Override
                public void onActivityPaused(Activity activity) {}

                @Override
                public void onActivityStopped(Activity activity) {}

                @Override
                public void onActivitySaveInstanceState(Activity activity, Bundle outState) {}

                @Override
                public void onActivityDestroyed(@NonNull Activity activity) {
                    afterOnDestroy(activity);
                }
            });
            return true;
        } else {
            return replaceInstrumentation();
        }
    }
    
    private static boolean replaceInstrumentation() {
        boolean success = false;
        if (sMonitoring) {
            return false;
        }
        try {
            {
                Class<?> clazz = Class.forName("android.app.ActivityThread");
                Method method = clazz.getDeclaredMethod("currentActivityThread");
                method.setAccessible(true);
                Object arg = null;
                sCurrentActivityThread = method.invoke(arg, arg);

                if (sCurrentActivityThread == null) {
                    throw new IllegalStateException("Failed to invoke currentActivityThread");
                }
            }

            {
                Field field = sCurrentActivityThread.getClass().getDeclaredField("mInstrumentation");
                field.setAccessible(true);
                Instrumentation ins = (Instrumentation) field.get(sCurrentActivityThread);

                if (ins == null) {
                    throw new IllegalStateException("Failed to get mInstrumentation.");
                }

                if (!(ins.getClass().equals(Instrumentation.class))) {
                    throw new IllegalStateException("Not an Instrumentation instance. Maybe something is modified in this system.");
                }
                
             // 表示已经被hack过了，不需要再搞一次
                if (ins.getClass().equals(MonitorInstrumentation.class)) {
                    throw new RuntimeException("Buddy you already hacked the system.");
                }

                sOldInstr = ins;
            }

            {
                Field field = sCurrentActivityThread.getClass().getDeclaredField("mInstrumentation");
                field.setAccessible(true);
                field.set(sCurrentActivityThread, new MonitorInstrumentation());
            }

            sMonitoring = true;
            success = true;
        } catch (ClassNotFoundException cnfe) {
            Magnifier.ILOGUTIL.exception(TAG, cnfe);
        } catch (NoSuchMethodException nsme) {
            Magnifier.ILOGUTIL.exception(TAG, nsme);
        } catch (IllegalArgumentException iae) {
            Magnifier.ILOGUTIL.exception(TAG, iae);
        } catch (IllegalAccessException iae) {
            Magnifier.ILOGUTIL.exception(TAG, iae);
        } catch (InvocationTargetException ite) {
            Magnifier.ILOGUTIL.exception(TAG, ite);
        } catch (NoSuchFieldException nsfe) {
            Magnifier.ILOGUTIL.exception(TAG, nsfe);
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
        return success;
    }
    
    /**
     * 在发生内存泄漏时，是否自动生成dump，可以在{@link InspectorListener#onPrepareDump}的返回值里添加log文件等信息
     * @param enable
     */
    public static void enableAutoDump(boolean enable) {
        sAutoDump = enable;
    }

    /**
     * 
     * @param suspiciousObj
     * @param digest
     */
    public static void startInspect(@NonNull Object suspiciousObj, String digest) {
        if (sInspector == null) {
            Magnifier.ILOGUTIL.e(TAG, "Please call initInspector before this");
            return;
        }
        if (sInspector.mListener == null) {
            Magnifier.ILOGUTIL.e(TAG, "Please init a listener first!");
            return;
        }
        sInspector.newInspect(suspiciousObj, digest);
    }
    
    private void newInspect(@NonNull Object obj, String digest) {
        if (sInspector.mListener.onFilter(obj)) {
            return;
        }
        InspectorRunner ir = new InspectorRunner(generateInspectUUID(obj, digest), 0);
        mHandler.post(ir);
    }

    @Nullable
    private InspectUUID generateInspectUUID(@NonNull Object obj, String digest) {
        InspectUUID uuid = (InspectUUID)sPool.obtain(InspectUUID.class);
        uuid.weakObj = new WeakReference<Object>(obj);
        uuid.uuid = UUID.randomUUID().toString().toCharArray();
        uuid.digest = digest;
        uuid.classname = obj.getClass().getSimpleName();
        return uuid;
    }

    public static class InspectUUID extends RecyclablePool.Recyclable {
        @Nullable
        private WeakReference<Object> weakObj;
        private String classname = "";
        private String digest = "";
        @Nullable
        private char[] uuid = null;
        @NonNull
        private String toString = "";

        @Override
        public void recycle() {
            weakObj = null;
            digest = "";
            uuid = null;
            classname = "";
            toString = "";
        }

        @NonNull
        @Override
        public String toString() {
            if (TextUtils.isEmpty(toString)) {
                StringBuilder sb = new StringBuilder(64);
                sb.append(classname);
                sb.append("@");
                if (uuid != null)
                    sb.append(uuid);
                if (!TextUtils.isEmpty(digest)) {
                    sb.append("_");
                    sb.append(digest);
                }
                toString = sb.toString();
            }
            return toString;
        }
    }
    
    private static final int CHECK_PIVOT = 5000;
    private static long lastTimeGC = 0l;
    private static void doGC() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastTimeGC >= CHECK_PIVOT) {
            System.runFinalization();
            Runtime.getRuntime().gc();
            lastTimeGC = currentTime;
        }
    }

    private class InspectorRunner implements Runnable {
        private int retryCount = 0;
        private InspectUUID uuid;
        private long occurTime = System.currentTimeMillis();
        
        InspectorRunner(InspectUUID uuid, int retryCount) {
            this.retryCount = retryCount;
            this.uuid = uuid;
        }
        
        @Override
        public void run() {
            String digest;
            if (uuid != null)
                digest = uuid.toString();
            else
                digest = "";
            try {
                Magnifier.ILOGUTIL.d(TAG, "Inspecting ", digest, " Time=", String.valueOf(System.currentTimeMillis()), " count=", String.valueOf(retryCount));
                if (uuid.weakObj.get() != null) {//还没有释放
//                    Magnifier.ILOGUTIL.d(TAG, "retry", String.valueOf(retryCount));
                    if (++retryCount < LOOP_MAX_COUNT) {
                        doGC();
                        mListener.onCheckingLeaked((retryCount-1)*CHECK_PIVOT/1000, digest);
                        mHandler.postDelayed(this, CHECK_PIVOT);
                        return;
                    }

                    //到这里是检查完毕了，回调一下通知结果
                    if (!mListener.onLeaked(uuid)) {
                        sPool.recycle(uuid);
                        return;
                    }

                    List<String> allFiles = new ArrayList<String>();
                    String zipPath = "";

                    //dump之前回调一下，因为整个过程比较耗时耗资源，最好在外面转圈等待一下
                    //如果要保存LOGCAT或者traces.txt，放在onPrepareDump里做
                    List<String> prepareFiles = mListener.onPrepareDump(digest);
                    //自动生成dump还要把一些附加信息带到ZIP包里面
                    if (prepareFiles != null && prepareFiles.size() > 0) {
                        allFiles.addAll(prepareFiles);
                    }

                    String tag = uuid.classname + "_leak";
                    Boolean success = false;
                    if (sAutoDump) {
                        Object[] result = DumpMemInfoHandler.generateHprof(digest);
                        success = (Boolean)result[0];
                        if (success) {
                            String hprofPath = (String)result[1];
                            allFiles.add(hprofPath);
                        } else {
                            Magnifier.ILOGUTIL.e(TAG, "generateHprof error ", digest);
                        }
                    }
                    Object[] zipRet = DumpMemInfoHandler.zipFiles(allFiles, tag);
                    success = (Boolean)zipRet[0];
                    zipPath = (String)zipRet[1];
                    //这条log供Magnifier检测使用，格式不要修改
                    Magnifier.ILOGUTIL.d(TAG, "leakFlag=true,ZipFile=", String.valueOf(success), ",leakName=", digest, ",dumpPath=", zipPath);
                    //回调完成了dump压缩
                    mListener.onFinishDump(success, digest, zipPath);

                    JSONObject params = new JSONObject();
                    params.put("processname", PhoneUtil.getProcessName(Magnifier.sApp));
                    params.put("event_time", occurTime);
                    params.put("fileObj", zipPath);
                    params.put("plugin", Config.PLUGIN_QCLOUD_LEAK_HPROF);
                    ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, Magnifier.info.uin);
                    ReporterMachine.addResultObj(ro);


                    //删除一下所有在zipfiles里面的文件。
                    String delPath;
                    File delFile;
                    for (int i = 0; i < allFiles.size(); i++) {
                        delPath = allFiles.get(i);
                        delFile = new File(delPath);
                        if (delFile != null && delFile.isFile() && delFile.exists()) {
                            delFile.delete();
                        }
                    }

                } else {
                    Magnifier.ILOGUTIL.d(TAG, "inspect ", digest, " finished no leak");
                    sPool.recycle(uuid);
                }
            } catch (Throwable th) {
                Magnifier.ILOGUTIL.e(TAG, "error, ", digest, " Time=", String.valueOf(System.currentTimeMillis()), " count=", String.valueOf(retryCount), " Throwable: ", ILogUtil.getThrowableMessage(th));
                sPool.recycle(uuid);
            }
        }
    }

    private static class MonitorInstrumentation extends Instrumentation {
        @Override
        public void callActivityOnDestroy(@NonNull Activity activity) {
            sOldInstr.callActivityOnDestroy(activity);
            afterOnDestroy(activity);
        }
    }
    
    private static void afterOnDestroy(@NonNull Activity activity) {
        ActivityLeakSolution.fixInputMethodManagerLeak(activity);
        ActivityLeakSolution.fixAudioManagerLeak(activity);
        //ActivityLeakSolution.unbindDrawables(activity);
        try {
            if (!CollectStatus.canCollect(Config.PLUGIN_QCLOUD_LEAK_HPROF)) {
                return;
            }
            CollectStatus.addCollectCount(Config.PLUGIN_QCLOUD_LEAK_HPROF);
            startInspect(activity, "");
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
    }
}