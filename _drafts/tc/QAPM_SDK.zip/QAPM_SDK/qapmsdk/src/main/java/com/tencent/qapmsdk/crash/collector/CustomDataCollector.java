package com.tencent.qapmsdk.crash.collector;

import android.content.Context;
import android.support.annotation.NonNull;

import com.tencent.qapmsdk.crash.builder.ReportBuilder;
import com.tencent.qapmsdk.crash.config.CoreConfiguration;
import com.tencent.qapmsdk.crash.config.ReportField;
import com.tencent.qapmsdk.crash.data.CrashReportData;

import org.json.JSONObject;

public final class CustomDataCollector extends BaseReportFieldCollector {
    public CustomDataCollector(){
        super(ReportField.CUSTOM_DATA);
    }

    @Override
    void collect(@NonNull ReportField reportField, @NonNull Context context, @NonNull CoreConfiguration config, @NonNull ReportBuilder reportBuilder, @NonNull CrashReportData target) {
        target.put(ReportField.CUSTOM_DATA, new JSONObject(reportBuilder.getCustomData()));
    }

    @NonNull
    @Override
    public Order getOrder() {
        return Order.LATE;
    }

    @Override
    public boolean enabled(@NonNull CoreConfiguration config) {
        return true;
    }
}
