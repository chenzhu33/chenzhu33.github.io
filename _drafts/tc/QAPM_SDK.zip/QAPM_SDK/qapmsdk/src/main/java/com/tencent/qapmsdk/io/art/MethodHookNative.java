/*
 * Copyright (c) 2017, weishu twsxtd@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tencent.qapmsdk.io.art;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.io.dexposed.XposedHelpers;

import java.lang.reflect.Member;

public final class MethodHookNative {
    private static native long mmap(int length);
    private static native boolean munmap(long address, int length);
    private static native void memcpy(long src, long dest, int length);
    private static native void memput(byte[] bytes, long dest);
    @NonNull
    private static native byte[] memget(long src, int length);
    private static native boolean changeprotect(long addr, boolean protect);
    public static native long getMethodAddress(Member method);
    static native boolean cacheflush(long addr, long len);
    public static native boolean munprotect(long addr, long len);
    static native long malloc(int sizeOfPtr);
    public static native void free(long ptr);
    @NonNull
    public static native Object getObject(long self, long address);
    public static native void deleteObject(long self, Object address);
    private static native boolean compileMethod(Member method, long self);
    public static native void memSetInt(long addr, int pos, int value);
    @NonNull
    public static native byte[] createJump(long addr);
    static native boolean activateNative(long jumpToAddress, long pc, long sizeOfTargetJump, long sizeOfBridgeJump, byte[] code);

    /**
     * suspend all running thread momently
     * @return a handle to resume all thread, used by {@link #resumeAll(long)}
     */
    static native long suspendAll();

    /**
     * resume all thread which are suspend by {@link #suspendAll()}
     * only work abobe Android N
     * @param cookie the cookie return by {@link #suspendAll()}
     */
    static native void resumeAll(long cookie);

    //private static final String TAG = "MethodHookNative";

    private MethodHookNative() {
    }

    public static boolean compileMethod(Member method) {
        final long nativePeer = XposedHelpers.getLongField(Thread.currentThread(), "nativePeer");
        return compileMethod(method, nativePeer);
    }

//    public static Object getObject(long address) {
//        final long nativePeer = XposedHelpers.getLongField(Thread.currentThread(), "nativePeer");
//        return getObject(nativePeer, address);
//    }

    public static long map(int length) {
        long m = mmap(length);
//        MagnifierSDK.ILOGUTIL.i(TAG, "Mapped memory of size " + length + " at " + addrHex(m));
        return m;
    }

    static boolean unmap(long address, int length) {
//        MagnifierSDK.ILOGUTIL.d(TAG, "Removing mapped memory of size " + length + " at " + addrHex(address));
        return munmap(address, length);
    }

    public static void put(byte[] bytes, long dest) {
//        if (Debug.DEBUG) {
//            MagnifierSDK.ILOGUTIL.d(TAG, "Writing memory to: " + addrHex(dest));
//            MagnifierSDK.ILOGUTIL.d(TAG, Debug.hexdump(bytes, dest));
//        }
        memput(bytes, dest);
    }

    @NonNull
    public static byte[] get(long src, int length) {
//        MagnifierSDK.ILOGUTIL.d(TAG, "Reading " + length + " bytes from: " + addrHex(src));
        byte[] bytes = memget(src, length);
//        MagnifierSDK.ILOGUTIL.d(TAG, Debug.hexdump(bytes, src));
        return bytes;
    }

    static boolean unprotect(long addr) {
//        MagnifierSDK.ILOGUTIL.d(TAG, "Disabling mprotect from " + addrHex(addr));
        return changeprotect(addr, false);
    }

    static boolean protect(long addr) {
//        MagnifierSDK.ILOGUTIL.d(TAG, "Disabling mprotect from " + addrHex(addr));
        return changeprotect(addr, true);
    }

    public static void cleanWeakRef(MethodHook.MethodInfo originMethodInfo, @Nullable Object receiver, long self, Object[] arguments){
        boolean isStatic = originMethodInfo.isStatic;
        int numberOfArgs = originMethodInfo.paramNumber;
        Class<?>[] typeOfArgs = originMethodInfo.paramTypes;
        if (!isStatic && receiver!=null){
            Magnifier.ILOGUTIL.i("hook", "cleanWeakRef, receiver: 0x" + Integer.toHexString(System.identityHashCode(receiver)));
            deleteObject(self, receiver);
        }
        for (int i = 0; i < numberOfArgs; i++) {
            final Class<?> typeOfArg = typeOfArgs[i];
            if (!typeOfArg.isPrimitive()){
                deleteObject(self, arguments[i]);
            }
        }

    }

//    public static void copy(long src, long dst, int length) {
//        memcpy(src, dst, length);
//    }
}