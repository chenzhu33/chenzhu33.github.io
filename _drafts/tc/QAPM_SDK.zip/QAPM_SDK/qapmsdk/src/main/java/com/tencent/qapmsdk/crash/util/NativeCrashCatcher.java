package com.tencent.qapmsdk.crash.util;

import android.app.Application;
import android.content.Context;
import android.os.Looper;
import android.support.annotation.Keep;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.crash.CrashHandleListener;
import com.tencent.qapmsdk.crash.builder.ReportExecutor;

import java.io.File;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class NativeCrashCatcher {

    private final static String LOG_TAG = ILogUtil.getTAG(NativeCrashCatcher.class);
    private Application app;
    private static ThreadGroup systemThreadGroup;

    public NativeCrashCatcher(Application app) {
        this.app = app;
        try {
            Class<?> threadGroupClass = Class.forName("java.lang.ThreadGroup");
            Field systemThreadGroupField = threadGroupClass.getDeclaredField("systemThreadGroup");
            systemThreadGroupField.setAccessible(true);
            systemThreadGroup = (ThreadGroup) systemThreadGroupField.get(null);
        } catch (ClassNotFoundException e) {
            Magnifier.ILOGUTIL.exception(LOG_TAG, e.getMessage(), e);
        } catch (NoSuchFieldException e) {
            Magnifier.ILOGUTIL.exception(LOG_TAG, e.getMessage(), e);
        } catch (IllegalAccessException e) {
            Magnifier.ILOGUTIL.exception(LOG_TAG, e.getMessage(), e);
        }
    }

    /**
     * 根据线程名获得线程对象，native层会调用该方法，不能混淆
     * @param threadName
     * @return
     */
    @Keep
    public static Thread getThreadByName(String threadName) {
        if (TextUtils.isEmpty(threadName)) {
            return null;
        }
        Thread theThread = null;
        if(threadName.equals("main")){
            theThread = Looper.getMainLooper().getThread();
        }else {
            Thread[] threadArray = new Thread[]{};
            try {
                Set<Thread> threadSet = getAllStackTraces().keySet();
                threadArray = threadSet.toArray(new Thread[threadSet.size()]);
            } catch (Exception e) {
                Magnifier.ILOGUTIL.exception(LOG_TAG, "dump thread Traces", e);
            }

            for(Thread thread : threadArray) {
                if (thread.getName().equals(threadName)) {
                    theThread = thread;
                    Magnifier.ILOGUTIL.d(LOG_TAG, "find it." + threadName);
                }
            }
        }

        Magnifier.ILOGUTIL.i(LOG_TAG, "threadName: " + threadName, ", thread: " + theThread);
        return theThread;
    }

    @Keep
    private static Map<Thread, StackTraceElement[]> getAllStackTraces() {
        if (systemThreadGroup == null) {
            return Thread.getAllStackTraces();
        } else {
            Map<Thread, StackTraceElement[]> map = new HashMap<Thread, StackTraceElement[]>();

            // Find out how many live threads we have. Allocate a bit more
            // space than needed, in case new ones are just being created.
            int count = systemThreadGroup.activeCount();
            Thread[] threads = new Thread[count + count / 2];
            Magnifier.ILOGUTIL.d(LOG_TAG, "activeCount: " + count);

            // Enumerate the threads and collect the stacktraces.
            count = systemThreadGroup.enumerate(threads);
            for (int i = 0; i < count; i++) {
                try {
                    map.put(threads[i], threads[i].getStackTrace());
                } catch (Throwable e) {
                    Magnifier.ILOGUTIL.exception(LOG_TAG, "fail threadName: " + threads[i].getName(), e);
                }
            }

            return map;
        }
    }

    public void init(int id,CrashHandleListener callback){
        String tombstoneDirPath = ReportExecutor.logPath + "/log.log";
        nativeInit(app.getPackageName(), tombstoneDirPath, callback);
        nativeSetup(id);
    }

    @Keep
    private static native void nativeInit(String packageName, String tombstoneFilePath, CrashHandleListener crashHandleListener);

    @Keep
    private static native void nativeSetup(int id);
}
