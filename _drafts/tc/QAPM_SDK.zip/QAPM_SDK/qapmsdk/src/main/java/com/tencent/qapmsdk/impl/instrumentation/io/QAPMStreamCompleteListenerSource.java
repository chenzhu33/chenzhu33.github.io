package com.tencent.qapmsdk.impl.instrumentation.io;

public interface QAPMStreamCompleteListenerSource {
    void addStreamCompleteListener(QAPMStreamCompleteListener qapmStreamCompleteListener);

    void removeStreamCompleteListener(QAPMStreamCompleteListener qapmStreamCompleteListener);
}
