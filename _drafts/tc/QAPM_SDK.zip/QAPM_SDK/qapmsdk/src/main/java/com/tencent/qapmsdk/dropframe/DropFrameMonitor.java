package com.tencent.qapmsdk.dropframe;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.common.ThreadManager;
import com.tencent.qapmsdk.common.VersionUtils;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.config.Config;

import java.util.Arrays;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN)
public class DropFrameMonitor {
    private final static String TAG = ILogUtil.getTAG(DropFrameMonitor.class);
    
    private static final int DROP_RANGE_0 = 0;
    private static final int DROP_RANGE_1 = 1;
    private static final int DROP_RANGE_2_4 = 2;
    private static final int DROP_RANGE_4_8 = 3;
    private static final int DROP_RANGE_8_15 = 4;
    private static final int DROP_RANGE_OVER_15 = 5;
    private static final int MSG_ON_FRAME_RENDERED = 1;
    
    private static boolean mStarted = false;
    private long mLastFrameTimeNs = 0L;
    @Nullable
    private android.view.Choreographer.FrameCallback mFPSMeasuringCallback;
    private android.view.Choreographer mChoreographer;
    private long mFrameIntervalNanos;
    private volatile static DropFrameMonitor instance;
    @Nullable
    private Handler calHandler;
    private int dropTotalCount = 0;
    private static String mCurrentScene = "";
    @NonNull
    private DropResultObject dropitem = new DropResultObject();
    private static int currentState = 0;
        
    public static DropFrameMonitor getInstance() {
        if (null == instance) {
            synchronized(DropFrameMonitor.class) {
                if (null == instance) {
                    try {
                        instance = new DropFrameMonitor();
                    } catch (Throwable th) {
                        instance = new DropFrameMonitor(true);
                    }
                }
            }
        }
        return instance;
    }
    
    private DropFrameMonitor(boolean error) {
    }

    private DropFrameMonitor() {
        if (false == VersionUtils.isJellyBean()) return;

        mChoreographer = android.view.Choreographer.getInstance();
        calHandler = new Handler(ThreadManager.getMonitorThreadLooper(), new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message msg) {
                if (msg.what == MSG_ON_FRAME_RENDERED) {
                    long nanoSecondDelay = (Long) msg.obj;
                    int skipFrame = (int)(nanoSecondDelay / mFrameIntervalNanos) - 1;
                    if (skipFrame < 0) {
                        if (Config.AB_TYPE == 0){
                            skipFrame = 0;
                        }
                        else {
                            return false;
                        }
                    }
                    int rangeIndex = getRangeIndex(skipFrame);
                    dropitem.dropIntervals[rangeIndex]++;
                    dropitem.dropcount += skipFrame;
                    dropitem.duration += nanoSecondDelay;
                }
                return false;
            }
        });

        mFrameIntervalNanos = 16666667L;
        mFPSMeasuringCallback = new android.view.Choreographer.FrameCallback() {
            @Override
            public void doFrame(long frameTimeNanos) {
                if (mChoreographer == null || CollectStatus.canCollect(Config.PLUGIN_QCLOUD_DROPFRAME) == false) {
                    return;
                }
                try {
                    mChoreographer.postFrameCallback(mFPSMeasuringCallback);
                } catch (Throwable t) {
                    Magnifier.ILOGUTIL.exception(TAG, t);
                }
                if (frameTimeNanos < mLastFrameTimeNs || mLastFrameTimeNs == 0) {
                    mLastFrameTimeNs = frameTimeNanos;
                    return;
                }
                long nanoSecondDelay = frameTimeNanos - mLastFrameTimeNs;
                mLastFrameTimeNs = frameTimeNanos;
                Message msg = calHandler.obtainMessage();
                msg.what = MSG_ON_FRAME_RENDERED;
                msg.obj = nanoSecondDelay;
                calHandler.sendMessage(msg);
            }
        };
    }


    /**
     * 启动监控
     */
    public void start(String scene) {
        if (start()) {
            if (!TextUtils.isEmpty(scene)) {
                mCurrentScene = scene;
            }
            else {
                mCurrentScene = Magnifier.getCurrentActivityName();
            }
        }
    }
    
    private boolean start() {
        if (null == mChoreographer || mStarted) {
            return false;
        }
        mChoreographer.removeFrameCallback(mFPSMeasuringCallback);
        mChoreographer.postFrameCallback(mFPSMeasuringCallback);
        mStarted = true;
        return true;
    }

    /**
     * 结束监控
     */
    public void stop() {
        if (null == mChoreographer) {
            return;
        }

        try {
            mChoreographer.removeFrameCallback(mFPSMeasuringCallback);
        } catch (Throwable t) {
            Magnifier.ILOGUTIL.exception(TAG, t);
        }

        mLastFrameTimeNs = 0;
        String key = "";
        if ("".equals(mCurrentScene)) {
            String scene = Magnifier.getCurrentActivityName();
            key = scene + "," + currentState;
        } else {
            key = mCurrentScene + "," + currentState;
        }

        if (checkValidData(dropitem)) { // 数据合法才插入drop_frame表
            //打印本次滑动丢帧情况
            Magnifier.ILOGUTIL.i(TAG,
                "DropFrame, scene: ", key,
                ", state: ", String.valueOf(dropitem.state),
                " , dropTotalCount: ", Integer.toString(dropTotalCount),
                " , duration: ", Float.toString(dropitem.duration),
                " , dropCount: ", Arrays.toString(dropitem.dropIntervals));
            InsertRunnable ir = new InsertRunnable(Magnifier.info.uin, mCurrentScene, dropitem);
            calHandler.post(ir);
        } else { // 数据不合法也得恢复到原始状态
            dropitem.reset();
        }
        
        mCurrentScene = "";
        mStarted = false;
    }
    
    private boolean checkValidData(DropResultObject item) {
        if (item.dropcount < 0 || item.duration <= 1E-9) {
            return false;
        }
        long sum = 0;
        long[] data = item.dropIntervals;
        for(int i = 0; i < data.length; i++) {
            if (data[i] < 0) return false;
            sum += data[i];
        }
        return sum > 0;
    }
    
    private final int getRangeIndex(int dropCount) {
        int rangeIndex = DROP_RANGE_0;
        if (dropCount <= 0) {
            rangeIndex = DROP_RANGE_0;
        } else if (dropCount == 1) {
            rangeIndex = DROP_RANGE_1;
        } else if (dropCount < 4) {
            rangeIndex = DROP_RANGE_2_4;
        } else if (dropCount < 8) {
            rangeIndex = DROP_RANGE_4_8;
        } else if (dropCount < 15) {
            rangeIndex = DROP_RANGE_8_15;
        } else {
            rangeIndex = DROP_RANGE_OVER_15;
        }
        return rangeIndex;
    }
    
    private static class InsertRunnable implements Runnable {
        private String uin;
        private String scene;
        private DropResultObject item;
        
        private InsertRunnable(String uin, String scene, DropResultObject item) {
            this.uin = uin;
            this.scene = scene;
            this.item = item;
        }

        @Override
        public void run() {
            if (Magnifier.dbHandler != null) {
                Magnifier.dbHandler.insertDropFrame(uin, scene, item, PhoneUtil.getProcessName(Magnifier.sApp), Magnifier.productId, Magnifier.info.version);
                item.reset();
                mCurrentScene = "";
            }
        }
    }
}