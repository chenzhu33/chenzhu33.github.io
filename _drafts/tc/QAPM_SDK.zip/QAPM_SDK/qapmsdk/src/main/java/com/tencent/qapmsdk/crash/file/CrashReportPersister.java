package com.tencent.qapmsdk.crash.file;

import android.support.annotation.NonNull;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.crash.data.CrashReportData;
import com.tencent.qapmsdk.crash.util.StreamReader;

import org.json.JSONException;

import java.io.File;
import java.io.IOException;

import static com.tencent.qapmsdk.crash.util.StreamReader.writeStringToFile;

public final class CrashReportPersister {
    private static final String LOG_TAG = ILogUtil.getTAG(CrashReportPersister.class);
    /**
     * Loads properties from the specified {@code File}.
     *
     * @param file Report file from which to load the CrashData.
     * @return CrashReportData read from the supplied File.
     * @throws IOException   if error occurs during reading from the {@code File}.
     * @throws JSONException if the stream cannot be parsed as a JSON object.
     */
    @NonNull
    public CrashReportData load(@NonNull File file) throws IOException, JSONException {
        return new CrashReportData(new StreamReader(file).read());
    }

    /**
     * Stores the mappings in this Properties to the specified OutputStream,
     * putting the specified comment at the beginning. The output from this
     * method is suitable for being read by the load() method.
     *
     * @param crashData CrashReportData to save.
     * @param file      File into which to store the CrashReportData.
     * @throws IOException   if the CrashReportData could not be written to the OutputStream.
     * @throws JSONException if the crashData could not be converted to JSON.
     */
    public void store(@NonNull CrashReportData crashData, @NonNull File file) throws IOException, JSONException {
        String json = crashData.toJSON();
        Magnifier.ILOGUTIL.d(LOG_TAG, json);
        writeStringToFile(file, json);
    }
}
