package com.tencent.qapmsdk.impl.instrumentation.okhttp2;

import com.squareup.okhttp.Headers;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.NetworkWatcher;
import com.tencent.qapmsdk.impl.api.data.TransactionData;
import com.tencent.qapmsdk.impl.harvest.HttpLibType;
import com.tencent.qapmsdk.impl.instrumentation.QAPMNetworkProcessHeader;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionState;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionStateUtil;
import com.tencent.qapmsdk.impl.model.HttpDataModel;
import com.tencent.qapmsdk.impl.util.StringUtil;

import java.util.Iterator;
import java.util.TreeMap;

public class QAPMOkHttp2TransactionStateUtil extends QAPMTransactionStateUtil {
    private final static String TAG = "QAPM_Impl_QAPMOkHttp2TransactionStateUtil";
    private static final String NO_BODY_TEXT = "Response BODY not found.";

    public QAPMOkHttp2TransactionStateUtil() {
    }

    public static void inspectAndInstrument(QAPMTransactionState transactionState, Request request) {
        String url = request.urlString();
        String params = null;
        if (url != null && url.contains("?")) {
            int index = url.indexOf("?");
            String host = url.substring(0, index);
            params = url.substring(index + 1);
            url = host;
        }

        transactionState.setUrl(url);
        transactionState.setUrlParams(params);
        transactionState.setAllGetRequestParams(params);
        transactionState.setMethodType(request.method());
        QAPMTransactionStateUtil.setRequestMethod(transactionState, request.method());
        transactionState.setCarrier(NetworkWatcher.activeNetworkCarrier());
        transactionState.setHttpLibType(HttpLibType.OkHttp);
        if (url != null) {
            processParamsAndHeader(transactionState, request);
        }

    }

    private static void processParamsAndHeader(QAPMTransactionState qapmTransactionState, final Request request) {
        QAPMTransactionStateUtil.processParamsFilter(qapmTransactionState, qapmTransactionState.getUrlParams());
        QAPMNetworkProcessHeader var2 = new QAPMNetworkProcessHeader() {
            public String getFilterHeader(String filterHeader) {
                return request != null && filterHeader != null ? request.header(filterHeader) : "";
            }
        };
        QAPMTransactionStateUtil.processHeaderParam(qapmTransactionState.getUrl(), var2, qapmTransactionState);
    }

    public static void inspectAndInstrumentResponse(QAPMTransactionState transactionState, Response response) {
        if (response == null) {
            Magnifier.ILOGUTIL.d(TAG, "okhttp2.0 ->CallBack.onResponse(response) response is null ");
        } else {
//            if (Harvest.isCdn_enabled()) {
//                QAPMAndroidAgentImpl var2 = QAPMAgent.getImpl();
//                if (var2 != null) {
//                    String var3 = var2.n().getCdnHeaderName();
//                    Magnifier.ILOGUTIL.d(TAG, "cdnHeaderName  key : " + var3);
//                    if (var3 != null && !var3.isEmpty()) {
//                        String var4 = response.header(var3);
//                        transactionState.setCdnVendorName(var4 == null ? "" : var4);
//                        Magnifier.ILOGUTIL.d(TAG, "cdnHeaderName  value : " + var4);
//                    }
//                }
//            }

            String data = response.header("X-QAPM-Tx-Data");
            int responseCode = response.code();

            try {
                long contentLength = response.body().contentLength();
                inspectAndInstrumentResponse(transactionState, data, (int)contentLength, responseCode);
                addTransactionAndErrorData(transactionState, response);
            } catch (Exception e) {
            }

        }
    }

    private static void addTransactionAndErrorData(QAPMTransactionState state, Response var1) {
//        QAPMAndroidAgentImpl var2 = QAPMAgent.getImpl();
//        if (var2 != null) {
//            HarvestConfiguration var3 = var2.n();
//            if (var3 != null) {
                try {
                    String contentType = var1.header("Content-Type");
                    state.setContentType(StringUtil.contentType(contentType));
                } catch (Exception ex) {
                    Magnifier.ILOGUTIL.e(TAG, "QAPMOkHttp2TransactionStateUtil content-type has an error ");
                }

                TransactionData data = state.end();
                if (data != null) {
                    //k.a(var11, new com.networkbench.agent.impl.g.b.a(var11));
                    if ((long)state.getStatusCode() >= 400L) {
                        TreeMap treeMap = new TreeMap();
                        Headers headers = var1.headers();
                        if (headers != null && headers.size() > 0) {
                            Iterator iterator = headers.names().iterator();

                            while(iterator.hasNext()) {
                                String str = (String)iterator.next();
                                String heard = headers.get(str);
                                if (!str.startsWith("X-QAPM-Qt") && heard != null) {
                                    treeMap.put(str, heard);
                                }
                            }
                        }

                        String exceptionInfo = "";
                        if (state.getException() != null) {
                            exceptionInfo = state.getException();
                        }
                        //todo:整理数据
                        HttpDataModel.collectData(data, treeMap, exceptionInfo);
                        //h.a(data.o(), data.s(), data.c(), data.q(), var1.message(), treeMap, exceptionInfo, data.n(), data.h(), data.f(), data.w(), data.l(), data.d());
                    }
                    else{
                        HttpDataModel.collectData(data);
                    }

                }

//            }
//        }
    }

    public static void inspectAndInstrument(QAPMTransactionState transactionState, String url, String httpMethod) {
        transactionState.setUrl(url);
        transactionState.setMethodType(httpMethod);
        transactionState.setCarrier(NetworkWatcher.activeNetworkCarrier());
    }

    public static void inspectAndInstrumentResponse(QAPMTransactionState transactionState, String appData, int contentLength, int statusCode) {
        if (appData != null && !"".equals(appData)) {
            transactionState.setAppData(appData);
        }

        transactionState.setStatusCode(statusCode);
        if (contentLength >= 0) {
            transactionState.setBytesReceived((long)contentLength);
        } else {
            transactionState.setBytesReceived(0L);
        }

    }

}
