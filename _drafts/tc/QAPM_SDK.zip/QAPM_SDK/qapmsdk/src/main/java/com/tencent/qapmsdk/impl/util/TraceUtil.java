package com.tencent.qapmsdk.impl.util;

import android.content.Context;

import com.tencent.qapmsdk.impl.appstate.AppState;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class TraceUtil {

    public static final int S_PAGE_THR = 7000;
    public static final int S_FIRSTPAINT_THR = 1400;

    public static final int S_DOM_THR = 2100;
    public static int HOT_START_THRESHOLD = 180;
    public static final int SLOW_START_THRESHOLD = 3000;
    public static final long SLOW_USER_ACTION_THRESHOLD = 3000L;
    public static final int ANR_THRESHOLD = 5000;
    public static final int ANR_ACTIONS_MAX_COUNT = 20;
    public static final int REPORT_THRESHOLD = 5000;
    public static final int HTTP_MONITOR_REPORT_THRESHOLD = 10000;
    public static final String FIRST_TIME_LAUNCH = "FIRST_TIME_LAUNCH";
    public static final String COLD_LAUNCH = "COLD_LAUNCH";
    public static final String WARM_LAUNCH = "WARM_LAUNCH";
    public static final String LAUNCH_APPLICATION_INIT = "LAUNCH_APPLICATION_INIT";
    public static final String LAUNCH_MAIN_ACTIVITY_INIT = "LAUNCH_MAIN_ACTIVITY_INIT";
    public static final String LAUNCH_ACTIVITY_LOAD = "LAUNCH_ACTIVITY_LOAD";

    public static final List<String> LAUNCH_KATEGRORY = Arrays.asList(FIRST_TIME_LAUNCH, COLD_LAUNCH, WARM_LAUNCH);
    public static AtomicInteger appState = new AtomicInteger(AppState.INIT.getValue());
    public static boolean canInstrumentMonitor = true;
    public static int versionCode = 0;

    private static final Random random = new Random();
    private static Context context;
    private static boolean firstVisit = true;

    private static boolean canMonitortHttp = false;


    public static Random getRandom(){
        return random;
    }

    public static void saveContext(Context context){
        TraceUtil.context = context;
    }

    public static Context getContext(){
        return TraceUtil.context;
    }

    public static void setFirstVisit(int visit){
        TraceUtil.firstVisit = visit == 0;
    }

    public static boolean getFirstVisit(){
        return TraceUtil.firstVisit;
    }

    public static void setCanMonitortHttp(boolean monitortHttp){
        canMonitortHttp = monitortHttp;
    }

    public static boolean getCanMonitorHttp(){
        return canMonitortHttp;
    }
}
