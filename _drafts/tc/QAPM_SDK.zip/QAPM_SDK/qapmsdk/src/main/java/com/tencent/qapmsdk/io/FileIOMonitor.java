package com.tencent.qapmsdk.io;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.io.util.NativeMethodHook;

public class FileIOMonitor extends Monitor {
    private int saveInfoType;
    @Nullable
    private NativeMethodHook hook = null;
    @Nullable
    private volatile static FileIOMonitor instance = null;
    @Nullable
    private String mVersion = null;
    private boolean isStarted = false;
    
    @Nullable
    static public FileIOMonitor getInstance() {
        if (instance == null) {
            synchronized(FileIOMonitor.class) {
                if (instance == null) {
                    instance = new FileIOMonitor();
                }
            }
        }
        return instance;
    }
    
    void setType(int type) {
        saveInfoType = type;
    }
    
    void setAppVersion(String version) {
        mVersion = version;
    }
    
    private FileIOMonitor() {}

    @Override
    void start() {
        hook = new NativeMethodHook();
        hook.startHook(saveInfoType, mVersion);
        isStarted = true;
    }
    
    @Override
    void stop() {
        if (hook != null) {
            hook.stopHook();
        }
        isStarted = false;
    }
    
    void saveNativeData() {
        if (hook != null) {
            hook.saveNativeData();
        }
    }

    public boolean getStartStatus() {
        return isStarted;
    }

    @NonNull
    public native static long[] getIOStatus();
}