package com.tencent.qapmsdk.dns.utils;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Process;

import java.lang.reflect.Method;
import java.net.InetAddress;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.dns.HttpDns;

public class Utils {

    private static final String TAG = "QAPM_DNS_Utils";

    private static Method sMethod_InetAddress_isNumeric;

    public static boolean isIp(String host) {
        // 先尝试使用InetAddress#isNumeric来判断，可支持ipv6和ipv4
        try {
            if (sMethod_InetAddress_isNumeric == null) {
                Method methodIsNumeric = InetAddress.class.getDeclaredMethod("isNumeric", String.class);
                methodIsNumeric.setAccessible(true);
                sMethod_InetAddress_isNumeric = methodIsNumeric;
            }
            return (boolean) sMethod_InetAddress_isNumeric.invoke(null, host);
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, "invoke isNumeric failed", e);
        }
        // 回退ipv4的正则匹配
        return android.util.Patterns.IP_ADDRESS.matcher(host).matches();
    }

    public static String dumpInetAddresses(InetAddress...inetAddresses) {
        if (inetAddresses == null || inetAddresses.length == 0) return null;
        StringBuilder sb = new StringBuilder(inetAddresses.length * 17 + 2);
        sb.append("[");
        for (int i = 0; i < inetAddresses.length; i++) {
            if (i != 0) sb.append(", ");
            sb.append(inetAddresses[i] != null ? inetAddresses[i].getHostAddress() : null);
        }
        sb.append("]");
        return sb.toString();
    }

    public static void setCallback(HttpDns.Callback callback) {
        sAsyncCallbackWrapper.setCallback(callback);
    }

    public static HttpDns.Callback getAsyncCallbackWrapper() {
        return sAsyncCallbackWrapper;
    }

    private static AsyncCallbackWrapper sAsyncCallbackWrapper = new AsyncCallbackWrapper();

    private static class AsyncCallbackWrapper implements HttpDns.Callback {

        private HttpDns.Callback mCallback;
        private Handler mHandler;

        synchronized void setCallback(HttpDns.Callback callback) {
            mCallback = callback;
            if (callback != null && mHandler == null) {
                // 为了不阻塞请求，callback异步触发
                // 去掉优先级 Process.THREAD_PRIORITY_BACKGROUND 避免太滞后处理
                HandlerThread thread = new HandlerThread("httpdns-callback");
                thread.start();
                mHandler = new Handler(thread.getLooper());
            }
        }

        @Override
        public void onHook(final boolean success, final Throwable tr) {
            final HttpDns.Callback callback = mCallback;
            final Handler handler = mHandler;
            if (callback != null && handler != null) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onHook(success, tr);
                    }
                });
            }
        }

        @Override
        public void onResolveDns(final HttpDns.DnsType type, final String host, final InetAddress[] inetAddresses, final long cost) {
            final HttpDns.Callback callback = mCallback;
            final Handler handler = mHandler;
            if (callback != null && handler != null) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onResolveDns(type, host, inetAddresses, cost);
                    }
                });
            }
        }
    }
}
