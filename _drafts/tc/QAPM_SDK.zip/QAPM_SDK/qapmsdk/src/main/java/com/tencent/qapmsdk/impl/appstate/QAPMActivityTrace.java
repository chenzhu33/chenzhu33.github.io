package com.tencent.qapmsdk.impl.appstate;

import com.tencent.qapmsdk.impl.util.TraceUtil;

public class QAPMActivityTrace extends CommonActivityTrace {
    private String activityName;
    public QAPMActivityTrace() {
    }

    public void onResumeEnterMethod(String activityName) {
        super.onResumeEnterMethod(activityName);
        this.activityName = activityName;
    }

    public SectionHarve onResumeExitMethod() {
        if (!TraceUtil.canInstrumentMonitor) {
            return null;
        } else {
            SectionHarve sectionHarve = super.onResumeExitMethod();
            if (sectionHarve != null) {
                QAPMMonitorThreadLocal qapmMonitorThreadLocal = this.eventListener.getQapmMonitorThreadLocal();
                sectionHarve.readyToReport(qapmMonitorThreadLocal);
            }

            return sectionHarve;
        }
    }

}
