package com.tencent.qapmsdk.socket;


import com.tencent.qapmsdk.socket.model.SocketInfo;

public class TrafficConnectReporter {

    private static IConnectListener sConnectListener;

    public static void setConnectListener(IConnectListener listener) {
        sConnectListener = listener;
    }

    public static void onConnected(boolean success, String host, int port, long costMillis, SocketInfo socketInfo) {
        if (sConnectListener != null) {
            sConnectListener.onConnected(success, host, port, costMillis, socketInfo);
        }
    }

    public static void onHandshakeCompleted(boolean success, String host, int port, long costMillis, SocketInfo socketInfo) {
        if (sConnectListener != null) {
            sConnectListener.onHandshakeCompleted(success, host, port, costMillis, socketInfo);
        }
    }

    public interface IConnectListener {
        void onConnected(boolean success, String host, int port, long costMillis, SocketInfo socketInfo);
        void onHandshakeCompleted(boolean success, String host, int port, long costMillis, SocketInfo socketInfo);
    }
}