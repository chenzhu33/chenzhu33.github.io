package com.tencent.qapmsdk.io.util;

public class IOConst {
    public static int ONLY_NATIVE_IO = 1;
    public static int ONLY_SQLITE_IO = 2;
    public static int BOTH_NATIVE_SQLITE = 3;
}