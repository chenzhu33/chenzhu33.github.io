package com.tencent.qapmsdk.common;

import android.os.Process;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.Magnifier;

import java.io.FileNotFoundException;
import java.io.RandomAccessFile;

public class ProcessStats {
    /**
     * cpu使用率上次更新时间，采用开机时间
     */
    //public static long sLastUpdateTime = 0L;
    /**
     * 本机较实时CPU使用率
     */
    //public static int sTotalCpuUsage = 0;
    /**
     * 主进程较实时CPU使用率
     */
    private static final String TAG = ILogUtil.getTAG(ProcessStats.class);
    private static final long INVALID_VALUE = -1;
    public static long collectCpuUsage(@NonNull String pid) {
        Object[] rs = collectProcessStats(pid);
        if (rs == null) {
            return INVALID_VALUE;
        } else {
            return (Long)rs[1] + (Long)rs[2];
        }
    }

    private static final int COUNT_SPLIT = 17;
    @NonNull
    private static int[] sWordIndexs = new int[COUNT_SPLIT];
    @NonNull
    private static int[] sWhiteIndexs = new int[COUNT_SPLIT];
    @Nullable
    private static Object[] collectProcessStats(@NonNull String pid) {
        RandomAccessFile rf = getReader(pid);
        byte[] byteLine = ByteArrayPool.getGenericInstance().getBuf(1024);
        Object[] ref = null;
        try {
            rf.seek(0);
            int readLen = rf.read(byteLine);
            int count = 0;
            int index = 0;
            while (index < readLen && count < COUNT_SPLIT) {
                while (index < readLen && byteLine[index] == ' ') {
                    ++index;
                }
                if (index < readLen) {
                    sWordIndexs[count] = index;
                }
                while (index < readLen && byteLine[index] != ' ') {
                    ++index;
                }
                if (index < readLen) {
                    sWhiteIndexs[count] = index;
                }
                ++count;
            }
            if (count == COUNT_SPLIT) {
                if (!ID_DEV.equals(pid)) {
                    String name = new String(byteLine, sWordIndexs[1] + 1, sWhiteIndexs[1] - sWordIndexs[1] - 1);
                    Long utime = Long.parseLong(
                            new String(byteLine, sWordIndexs[13], sWhiteIndexs[13] - sWordIndexs[13]))
                            + Long.parseLong(
                            new String(byteLine, sWordIndexs[15], sWhiteIndexs[15] - sWordIndexs[15]));
                    Long stime = Long.parseLong(
                            new String(byteLine, sWordIndexs[14], sWhiteIndexs[14] - sWordIndexs[14]))
                            + Long.parseLong(
                            new String(byteLine, sWordIndexs[16], sWhiteIndexs[16] - sWordIndexs[16]));
                    if (name != null) {
                        ref = new Object[]{name, utime, stime};
                    }
                } else {
                    Long baseTotalIdle = Long.parseLong(
                            new String(byteLine, sWordIndexs[4], sWhiteIndexs[4] - sWordIndexs[4]));
                    Long baseTotalCpu = Long.parseLong(
                            new String(byteLine, sWordIndexs[1], sWhiteIndexs[1] - sWordIndexs[1]))
                            + Long.parseLong(
                            new String(byteLine, sWordIndexs[2], sWhiteIndexs[2] - sWordIndexs[2]))
                            + Long.parseLong(
                            new String(byteLine, sWordIndexs[3], sWhiteIndexs[3] - sWordIndexs[3]))
                            + Long.parseLong(
                            new String(byteLine, sWordIndexs[5], sWhiteIndexs[5] - sWordIndexs[5]))
                            + Long.parseLong(
                            new String(byteLine, sWordIndexs[6], sWhiteIndexs[6] - sWordIndexs[6]))
                            + Long.parseLong(
                            new String(byteLine, sWordIndexs[7], sWhiteIndexs[7] - sWordIndexs[7]))
                            + Long.parseLong(
                            new String(byteLine, sWordIndexs[8], sWhiteIndexs[8] - sWordIndexs[8]));
                    ref = new Object[]{"device", baseTotalIdle, baseTotalCpu};
                }
            }
        } catch (Exception e) {
        } finally {
            ByteArrayPool.getGenericInstance().returnBuf(byteLine);
            try {
                rf.close();
            } catch (Exception e) {}
        }
        return ref;
    }

    public static final String ID_DEV = "-2";
    public static final String ID_APP = "-1";

    @Nullable
    private static final RandomAccessFile getReader(String id) {
        RandomAccessFile rf = null;
        try {
            if (id.equals(ID_DEV)) {
                rf = new RandomAccessFile("/proc/stat", "r");
            } else if (id.equals(ID_APP)) {
                rf = new RandomAccessFile("/proc/" + Process.myPid() + "/stat", "r");
            } else {
                rf = new RandomAccessFile("/proc/" + Process.myPid() + "/task/" + id + "/stat", "r");
            }
        } catch (FileNotFoundException e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
        return rf;
    }
}