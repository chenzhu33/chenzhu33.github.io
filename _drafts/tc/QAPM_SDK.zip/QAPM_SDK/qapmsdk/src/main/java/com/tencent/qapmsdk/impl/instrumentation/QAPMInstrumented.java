package com.tencent.qapmsdk.impl.instrumentation;

public @interface QAPMInstrumented {
}
