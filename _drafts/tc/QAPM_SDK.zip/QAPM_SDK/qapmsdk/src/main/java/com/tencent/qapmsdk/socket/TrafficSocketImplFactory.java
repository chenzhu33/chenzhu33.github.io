package com.tencent.qapmsdk.socket;

import android.os.Build;
import android.support.annotation.RestrictTo;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.socket.util.ReflectionHelper;

import java.lang.reflect.Constructor;
import java.net.Socket;
import java.net.SocketImpl;
import java.net.SocketImplFactory;


/**
 * Created by nicorao on 2017/12/6.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY)
public class TrafficSocketImplFactory implements SocketImplFactory {

    private static final String TAG = "QAPM_Socket_TrafficSocketImplFactory";

    private static Constructor<?> sConstructor_SocketImpl;

    private SocketImplFactory mOldFactory;

    public TrafficSocketImplFactory() throws Exception {
        Class<?> clzSocketImpl = ReflectionHelper.of(Socket.class).field("impl").get(new Socket()).getClass();
        try {
            sConstructor_SocketImpl = ReflectionHelper.of(clzSocketImpl).constructor();
        } catch (NoSuchMethodException e) {
            if (clzSocketImpl == TrafficSocketImpl.class) {
                // 很奇怪的一个case，为什么会已经是这个SocketImpl了？
                if (sConstructor_SocketImpl != null) {
                    // 如果这个构造函数不为空，那走下去没有问题
                } else {
                    // 如果构造函数为空，则强行指定
                    if (Build.VERSION.SDK_INT <= 23) {
                        sConstructor_SocketImpl = ReflectionHelper.of("java.net.PlainSocketImpl").constructor();
                    } else {
                        sConstructor_SocketImpl = ReflectionHelper.of("java.net.SocksSocketImpl").constructor();
                    }
                }
            }
        }
        Magnifier.ILOGUTIL.i(TAG, "TrafficSocketImplFactory init success, SocketImpl: " , clzSocketImpl.toString());
    }

    public TrafficSocketImplFactory(SocketImplFactory factory) {
        Magnifier.ILOGUTIL.i(TAG, "TrafficSocketImplFactory init, old SocketImplFactory: " , factory.toString());
        mOldFactory = factory;
    }

    @Override
    public SocketImpl createSocketImpl() {
        // 如果有旧的factory，使用它来创建真正的SocketImpl
        if (mOldFactory != null) {
            return new TrafficSocketImpl(mOldFactory.createSocketImpl());
        }
        // 如果原来没有factory，则使用原来的SocketImpl类直接创建一个
        try {
            return new TrafficSocketImpl((SocketImpl) sConstructor_SocketImpl.newInstance());
        } catch (Throwable tr) {
            Magnifier.ILOGUTIL.w(TAG, "create TrafficSocketImpl instance failed:" , tr.toString());
            ReflectionHelper.processException(tr);
        }
        return null;
    }
}
