package com.tencent.qapmsdk.impl.instrumentation;

public class TraceType {
    public TraceType() {
    }

    public static enum d {
        a,
        b,
        c;

        private d() {
        }
    }

    public static enum c {
        a(0),
        b(1),
        c(2),
        d(3),
        e(4),
        f(5),
        g(6),
        h(7),
        i(8),
        j(9);

        public final int value;

        private c(int value) {
            this.value = value;
        }
    }

    public static enum CONTEXT {
        OTHER(0),
        APP(1),
        ACTIVITY(2);

        private final int value;

        private CONTEXT(int value) {
            this.value = value;
        }

        public int getValue() {
            return this.value;
        }
    }

    public static enum b {
        a,
        b,
        c,
        d,
        e,
        f,
        g,
        h;

        private b() {
        }
    }

    public static enum THREAD_TYPE {
        MAIN(1),
        OTHER(2);

        private final int value;

        private THREAD_TYPE(int value) {
            this.value = value;
        }

        public int getValue() {
            return this.value;
        }
    }

    public static enum CATEGORY {
        OTHER(0),
        NETWORK(1),
        JSON(2),
        DATABASE(3),
        IMAGE(4),
        CUSTOMEVENT(9);

        private final int value;

        private CATEGORY(int value) {
            this.value = value;
        }

        public int getValue() {
            return this.value;
        }
    }
}
