/*
 * Copyright (c) 2017, weishu twsxtd@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tencent.qapmsdk.io.art.entry;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Pair;

import com.tencent.qapmsdk.io.art.MethodHook;
import com.tencent.qapmsdk.io.art.MethodHookNative;
import com.tencent.qapmsdk.io.dexposed.DexposedBridge;

import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@SuppressWarnings({"unused"})
public class Entry {
    private static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];

    //region ---------------callback---------------
    private static int onHookInt(Object artmethod, Object receiver, Object[] args) {
        return (Integer) DexposedBridge.handleHookedArtMethod(artmethod, receiver, args);
    }

    private static long onHookLong(Object artmethod, Object receiver, Object[] args) {
        return (Long) DexposedBridge.handleHookedArtMethod(artmethod, receiver, args);
    }

    private static double onHookDouble(Object artmethod, Object receiver, Object[] args) {
        return (Double) DexposedBridge.handleHookedArtMethod(artmethod, receiver, args);
    }

    private static char onHookChar(Object artmethod, Object receiver, Object[] args) {
        return (Character) DexposedBridge.handleHookedArtMethod(artmethod, receiver, args);
    }

    private static short onHookShort(Object artmethod, Object receiver, Object[] args) {
        return (Short) DexposedBridge.handleHookedArtMethod(artmethod, receiver, args);
    }

    private static float onHookFloat(Object artmethod, Object receiver, Object[] args) {
        return (Float) DexposedBridge.handleHookedArtMethod(artmethod, receiver, args);
    }

    @Nullable
    private static Object onHookObject(Object artmethod, Object receiver, Object[] args) {
        return DexposedBridge.handleHookedArtMethod(artmethod, receiver, args);
    }

    private static void onHookVoid(Object artmethod, Object receiver, Object[] args) {
        DexposedBridge.handleHookedArtMethod(artmethod, receiver, args);
    }

    private static boolean onHookBoolean(Object artmethod, Object receiver, Object[] args) {
        return (Boolean) DexposedBridge.handleHookedArtMethod(artmethod, receiver, args);
    }

    private static byte onHookByte(Object artmethod, Object receiver, Object[] args) {
        return (Byte) DexposedBridge.handleHookedArtMethod(artmethod, receiver, args);
    }
    //endregion

    //region ---------------bridge---------------
    private static void voidBridge(int r1, int self, int struct) {
        referenceBridge(r1, self, struct);
    }

    private static boolean booleanBridge(int r1, int self, int struct) {
        return (Boolean) referenceBridge(r1, self, struct);
    }

    private static byte byteBridge(int r1, int self, int struct) {
        return (Byte) referenceBridge(r1, self, struct);
    }

    private static short shortBridge(int r1, int self, int struct) {
        return (Short) referenceBridge(r1, self, struct);
    }

    private static char charBridge(int r1, int self, int struct) {
        return (Character) referenceBridge(r1, self, struct);
    }

    private static int intBridge(int r1, int self, int struct) {
        return (Integer) referenceBridge(r1, self, struct);
    }

    private static long longBridge(int r1, int self, int struct) {
        return (Long) referenceBridge(r1, self, struct);
    }

    private static float floatBridge(int r1, int self, int struct) {
        return (Float) referenceBridge(r1, self, struct);
    }

    private static double doubleBridge(int r1, int self, int struct) {
        return (Double) referenceBridge(r1, self, struct);
    }
    //endregion

    @Nullable
    private static Object referenceBridge(int r1, int self, int struct) {
//        MagnifierSDK.ILOGUTIL.w(TAG, "enter bridge function.");

        // struct {
        //     void* sp;
        //     void* r2;
        //     void* r3;
        //     void* sourceMethod
        // }
        // sp + 16 = r4

//        MagnifierSDK.ILOGUTIL.i(TAG, "struct:" + Long.toHexString(struct));

        final int sp = ByteBuffer.wrap(MethodHookNative.get(struct, 4)).order(ByteOrder.LITTLE_ENDIAN).getInt();

        // MagnifierSDK.ILOGUTIL.i(TAG, "stack:" + Debug.hexdump(MethodHookNative.get(sp, 96), 0));

        final byte[] rr1 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(r1).array();
        final byte[] r2 = MethodHookNative.get(struct + 4, 4);

        final byte[] r3 = MethodHookNative.get(struct + 8, 4);

//        MagnifierSDK.ILOGUTIL.d(TAG, "r1:" + Debug.hexdump(rr1, 0));
//        MagnifierSDK.ILOGUTIL.d(TAG, "r2:" + Debug.hexdump(r2, 0));
//        MagnifierSDK.ILOGUTIL.d(TAG, "r3:" + Debug.hexdump(r3, 0));

        final int sourceMethod = ByteBuffer.wrap(MethodHookNative.get(struct + 12, 4)).order(ByteOrder.LITTLE_ENDIAN).getInt();
//        MagnifierSDK.ILOGUTIL.i(TAG, "sourceMethod:" + Long.toHexString(sourceMethod));

        MethodHook.MethodInfo originMethodInfo = MethodHook.getMethodInfo(sourceMethod & 0x00000000FFFFFFFFL);
//        MagnifierSDK.ILOGUTIL.i(TAG, "originMethodInfo :" + originMethodInfo);

        final Pair<Object, Object[]> constructArguments = constructArguments(originMethodInfo, self, rr1, r2, r3, sp, struct);
        Object receiver = constructArguments.first;
        Object[] arguments = constructArguments.second;

//        MagnifierSDK.ILOGUTIL.i(TAG, "arguments:" + Arrays.toString(arguments));

        Class<?> returnType = originMethodInfo.returnType;
        Object artMethod = originMethodInfo.method;

//        MagnifierSDK.ILOGUTIL.w(TAG, "leave bridge function");

        if (returnType == void.class) {
            onHookVoid(artMethod, receiver, arguments);
            MethodHookNative.cleanWeakRef(originMethodInfo, receiver, self, arguments);
            return 0;
        } else if (returnType == char.class) {
            char res = onHookChar(artMethod, receiver, arguments);
            MethodHookNative.cleanWeakRef(originMethodInfo, receiver, self, arguments);
            return res;
        } else if (returnType == byte.class) {
            byte res = onHookByte(artMethod, receiver, arguments);
            MethodHookNative.cleanWeakRef(originMethodInfo, receiver, self, arguments);
            return res;
        } else if (returnType == short.class) {
            short res = onHookShort(artMethod, receiver, arguments);
            MethodHookNative.cleanWeakRef(originMethodInfo, receiver, self, arguments);
            return res;
        } else if (returnType == int.class) {
            int res = onHookInt(artMethod, receiver, arguments);
            MethodHookNative.cleanWeakRef(originMethodInfo, receiver, self, arguments);
            return res;
        } else if (returnType == long.class) {
            long res = onHookLong(artMethod, receiver, arguments);
            MethodHookNative.cleanWeakRef(originMethodInfo, receiver, self, arguments);
            return res;
        } else if (returnType == float.class) {
            float res = onHookFloat(artMethod, receiver, arguments);
            MethodHookNative.cleanWeakRef(originMethodInfo, receiver, self, arguments);
            return res;
        } else if (returnType == double.class) {
            double res = onHookDouble(artMethod, receiver, arguments);
            MethodHookNative.cleanWeakRef(originMethodInfo, receiver, self, arguments);
            return res;
        } else if (returnType == boolean.class) {
            boolean res = onHookBoolean(artMethod, receiver, arguments);
            MethodHookNative.cleanWeakRef(originMethodInfo, receiver, self, arguments);
            return res;
        } else {
            Object res = onHookObject(artMethod, receiver, arguments);
            MethodHookNative.cleanWeakRef(originMethodInfo, receiver, self, arguments);
            return res;
        }

    }

    /**
     * construct the method arguments from register r1, r2, r3 and stack
     * @param r1 register r1 value
     * @param r2 register r2 value
     * @param r3 register r3 value
     * @param sp stack pointer
     * @return arguments passed to the callee method
     */
    private static Pair<Object, Object[]> constructArguments(MethodHook.MethodInfo originMethodInfo, int self,
                                                             @NonNull byte[] r1, @NonNull byte[] r2, @NonNull byte[] r3, int sp, int struct) {
        boolean isStatic = originMethodInfo.isStatic;

        int numberOfArgs;
        Class<?>[] typeOfArgs;
        if (isStatic) {

            // static argument, r1, r2, r3, sp + 16

            // sp + 0 = ArtMethod (ourself)
            // sp + 4 = r1 (may be earased)
            // sp + 8 = r2 (may be earased)
            // sp + 12 = r3 (may be earased)
            // sp + 16 = r4, remain

            numberOfArgs = originMethodInfo.paramNumber;
            typeOfArgs = originMethodInfo.paramTypes;
        } else {
            // non-static, r1 = receiver; r2, r3, sp + 16 is arguments.

            // sp + 0 = ArtMethod (ourself)
            // sp + 4 = r1 = this (may be earased)
            // sp + 8 = r2 = first argument (may be earased)
            // sp + 12 = r3 = second argument (may be earased)
            // sp + 16 = third argument, remain
            numberOfArgs = 1 + originMethodInfo.paramNumber;
            typeOfArgs = new Class<?>[numberOfArgs];
            typeOfArgs[0] = Object.class; // this
            System.arraycopy(originMethodInfo.paramTypes, 0, typeOfArgs, 1, originMethodInfo.paramTypes.length);
        }

        Object[] arguments = new Object[numberOfArgs];

        int currentStackPosition = 4; // sp + 0 = ArtMethod, sp + 4... start store arguments.
        final int argumentStackBegin = 16; // sp + 4 = r1, sp + 8 = r2, sp + 12 = r3, sp + 16 start in stack.

        int[] argStartPos = new int[numberOfArgs];

        for (int i = 0; i < numberOfArgs; i++) {
            Class<?> typeOfArg = typeOfArgs[i];
            int typeLength = getTypeLength(typeOfArg);
            argStartPos[i] = currentStackPosition;
            currentStackPosition += typeLength;
        }

        int argTotalLength = currentStackPosition;
        byte[] argBytes = new byte[argTotalLength];

        do {
            if (argTotalLength <= 4) break;

            boolean align = Build.VERSION.SDK_INT >= 23 && numberOfArgs > 0 && getTypeLength(typeOfArgs[0]) == 8;
            if (align) {
                System.arraycopy(r2, 0, argBytes, 4, 4);
                System.arraycopy(r3, 0, argBytes, 8, 4);
                if (argTotalLength <= 12) break;
                System.arraycopy(MethodHookNative.get(sp + 12, 4), 0, argBytes, 12, 4);
            } else {
                System.arraycopy(r1, 0, argBytes, 4, 4);

                if (argTotalLength <= 8) break;
                System.arraycopy(r2, 0, argBytes, 8, 4);
                if (argTotalLength <= 12) break;
                System.arraycopy(r3, 0, argBytes, 12, 4);
            }

            if (argTotalLength <= 16) break;

            byte[] argInStack = MethodHookNative.get(sp + 16, argTotalLength - 16);
            System.arraycopy(argInStack, 0, argBytes, 16, argTotalLength - 16);
        } while (false);

        //region ---------------Process Arguments passing in Android M---------------
        if (Build.VERSION.SDK_INT == 23) {
            byte[] singleRegisterByte = MethodHookNative.get(struct + 16, 4);
            byte[] doubleRegisterByte = MethodHookNative.get(struct + 20, 4);
            int singleRegisterAddress = (int)wrapArgument(int.class, self, singleRegisterByte);
            int doubleRegisterAddress = (int)wrapArgument(int.class, self, doubleRegisterByte);


            int stackPos = 4;
            int registPos = 1;
            boolean firstRegist = true;

            int singleNum = 0;
            int doubleNum = 0;


            //全拷贝栈中的数据,用于后续处理
            byte[] argInStack_M = MethodHookNative.get(sp, argTotalLength);


            for (int i = 0; i < numberOfArgs; i++) {
                Class<?> typeOfArg = typeOfArgs[i];
                int typeLength = getTypeLength(typeOfArg);
                if (typeOfArg == float.class){
                    if (singleNum % 2 == 0){
                        singleNum = Math.max(singleNum, doubleNum * 2);
                    }

                    System.arraycopy(MethodHookNative.get(singleRegisterAddress + singleNum * 4, 4), 0, argBytes, stackPos, 4);
                    stackPos += 4;
                    singleNum++;
                }
                else if(typeOfArg == double.class){
                    doubleNum = Math.max(doubleNum, (singleNum + 1)/2);
                    System.arraycopy(MethodHookNative.get(doubleRegisterAddress + doubleNum * 8, 8), 0, argBytes, stackPos, 8);
                    stackPos += 8;
                    doubleNum++;
                }
                else{
                    if (registPos + typeLength / 4 <= 4){
                        if (firstRegist && typeLength == 8){
                            registPos++;
                        }
                        for (int j = 0; j < typeLength / 4; j++){
                            switch (registPos){
                                case 1:
                                    System.arraycopy(r1, 0, argBytes, stackPos, 4);
                                    break;
                                case 2:
                                    System.arraycopy(r2, 0, argBytes, stackPos, 4);
                                    break;
                                case 3:
                                    System.arraycopy(r3, 0, argBytes, stackPos, 4);
                                    break;

                            }
                            registPos++;
                            stackPos += 4;

                        }
                        firstRegist = false;
                    }
                    else{
                        System.arraycopy(argInStack_M, stackPos, argBytes, stackPos, typeLength);
                        registPos = 4; //非浮点一旦进入栈区域取值就不会再在寄存器取值了
                        stackPos += typeLength;
                    }
                }
            }
        }
        //endregion

//        MagnifierSDK.ILOGUTIL.d(TAG, "argBytes: " + Debug.hexdump(argBytes, 0));

        for (int i = 0; i < numberOfArgs; i++) {
            final Class<?> typeOfArg = typeOfArgs[i];
            final int startPos = argStartPos[i];
            final int typeLength = getTypeLength(typeOfArg);
            byte[] argWithBytes = Arrays.copyOfRange(argBytes, startPos, startPos + typeLength);
            arguments[i] = wrapArgument(typeOfArg, self, argWithBytes);
//            MagnifierSDK.ILOGUTIL.d(TAG, "argument[" + i + "], startPos:" + startPos + ", typeOfLength:" + typeLength);
//            MagnifierSDK.ILOGUTIL.d(TAG, "argWithBytes:" + Debug.hexdump(argWithBytes, 0) + ", value:" + arguments[i]);
        }

        Object thiz = null;
        Object[] parameters = EMPTY_OBJECT_ARRAY;
        if (isStatic) {
            parameters = arguments;
        } else {
            thiz = arguments[0];
            int argumentLength = arguments.length;
            if (argumentLength > 1) {
                parameters = Arrays.copyOfRange(arguments, 1, argumentLength);
            }
        }

        return Pair.create(thiz, parameters);
    }

    private static Object wrapArgument(Class<?> type, int self, byte[] value) {
        final ByteBuffer byteBuffer = ByteBuffer.wrap(value).order(ByteOrder.LITTLE_ENDIAN);
//        MagnifierSDK.ILOGUTIL.d(TAG, "wrapArgument: type:" + type);
        if (type.isPrimitive()) {
            if (type == int.class) {
                return byteBuffer.getInt();
            } else if (type == long.class) {
                return byteBuffer.getLong();
            } else if (type == float.class) {
                return byteBuffer.getFloat();
            } else if (type == short.class) {
                return byteBuffer.getShort();
            } else if (type == byte.class) {
                return byteBuffer.get();
            } else if (type == char.class) {
                return byteBuffer.getChar();
            } else if (type == double.class) {
                return byteBuffer.getDouble();
            } else if (type == boolean.class) {
                return byteBuffer.getInt() == 0;
            } else {
                throw new RuntimeException("unknown type:" + type);
            }
        } else {
            int address = byteBuffer.getInt();
            Object object = MethodHookNative.getObject(self, address);
            //Magnifier.ILOGUTIL.i("hook", "wrapArgument, address: 0x" + Long.toHexString(address) + ", value: 0x" + Integer.toHexString(System.identityHashCode(object)));
            return object;
        }
    }

    @NonNull
    private static Map<Class<?>, String> bridgeMethodMap = new HashMap<Class<?>, String>();

    static {
        Class<?>[] primitiveTypes = new Class[]{boolean.class, byte.class, char.class, short.class,
                int.class, long.class, float.class, double.class};
        for (Class<?> primitiveType : primitiveTypes) {
            bridgeMethodMap.put(primitiveType, primitiveType.getName() + "Bridge");
        }
        bridgeMethodMap.put(Object.class, "referenceBridge");
        bridgeMethodMap.put(void.class, "voidBridge");
    }

    public static Method getBridgeMethod(@NonNull Class<?> returnType) {
        try {
            final String bridgeMethod = bridgeMethodMap.get(returnType.isPrimitive() ? returnType : Object.class);
//            MagnifierSDK.ILOGUTIL.i(TAG, "bridge method:" + bridgeMethod + ", map:" + bridgeMethodMap);
            Method method = Entry.class.getDeclaredMethod(bridgeMethod, int.class, int.class, int.class);
            method.setAccessible(true);
            return method;
        } catch (Throwable e) {
            throw new RuntimeException("error", e);
        }
    }

    private static int getTypeLength(Class<?> clazz) {
        if (clazz == long.class || clazz == double.class) {
            return 8; // double & long are 8 bytes.
        } else {
            return 4;
        }
    }
}
