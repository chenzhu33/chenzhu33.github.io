package com.tencent.qapmsdk.impl.instrumentation.okhttp2;

import com.squareup.okhttp.Interceptor;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import com.squareup.okhttp.Interceptor.Chain;
import com.tencent.qapmsdk.Magnifier;

import java.io.IOException;

public class QAPMOKhttp2Interceptor implements Interceptor {
    private final static String TAG = "QAPM_Impl_QAPMOKhttp2Interceptor";

    public QAPMOKhttp2Interceptor() {
    }

    public Response intercept(Chain chain) throws IOException {
        long currentTimeMillis = System.currentTimeMillis();
        Response response = chain.proceed(chain.request());
        return this.setQuitTime(response, currentTimeMillis);
    }

    private Response setQuitTime(Response response, long time) {
        Response res = response;
        try {
            res = response.newBuilder().addHeader("X-QAPM-Qt", String.valueOf(time)).build();
        } catch (Exception e) {
            Magnifier.ILOGUTIL.e(TAG, "setQueueTime error:" , e.getMessage());
        }

        return res;
    }

    private Request setQuitTime(Request request, long time) {
        Request req = request;

        try {
            req = request.newBuilder().addHeader("X-QAPM-Qt", String.valueOf(time)).build();
        } catch (Exception e) {
            Magnifier.ILOGUTIL.e(TAG, "ok2 add header failed:" , e.getMessage());
        }

        return req;
    }
}
