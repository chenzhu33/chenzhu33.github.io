package com.tencent.qapmsdk.impl.instrumentation;

import android.annotation.TargetApi;
import android.os.Looper;

import com.tencent.qapmsdk.impl.util.TraceUtil;
import com.tencent.qapmsdk.impl.tracing.TracingInactiveException;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentSkipListSet;

public class QAPMUnit {

    public long entryTimestamp = 0L;
    public long exitTimestamp = 0L;
    public String metricName;
    public String subMetricName;
    protected volatile Set<UUID> children;
    public boolean isComplete = false;
    public UUID parentUUID;
    public final UUID myUUID;
    public long threadId = 0L;
    public String threadName = "main";

    public QAPMUnit()
    {
        this.parentUUID = null;
        this.metricName = "";
        this.subMetricName = "";
        initChildren();
        this.myUUID = new UUID(TraceUtil.getRandom().nextLong(), TraceUtil.getRandom().nextLong());
        this.threadId = Thread.currentThread().getId();
        this.threadName = Thread.currentThread().getName();
    }

    public void addChild(QAPMUnit trace)
    {
        this.children.add(trace.myUUID);
    }

    @TargetApi(9)
    private void initChildren()
    {
        if (this.children == null) {
            synchronized (this)
            {
                if (this.children == null) {
                    this.children = new ConcurrentSkipListSet();
                }
            }
        }
    }

    public void setUnitThreadWithUIThread()
    {
        this.threadId = Looper.getMainLooper().getThread().getId();
        this.threadName = Looper.getMainLooper().getThread().getName();
    }

    public Set<UUID> getChildren()
    {
        return this.children;
    }

    public boolean isComplete()
    {
        return this.isComplete;
    }

    public void complete()
    {
        this.exitTimestamp = System.currentTimeMillis();
        this.isComplete = true;
    }

    public String toString()
    {
        return "QAPMUnit{entryTimestamp=" + this.entryTimestamp + ", exitTimestamp=" + this.exitTimestamp + ", metricName='" + this.metricName + '\'' + ", children=" + this.children + ", isComplete=" + this.isComplete + ", parentUUID=" + this.parentUUID + ", myUUID=" + this.myUUID + ", threadId=" + this.threadId + ", threadName='" + this.threadName + '\'' + '}';
    }
}

