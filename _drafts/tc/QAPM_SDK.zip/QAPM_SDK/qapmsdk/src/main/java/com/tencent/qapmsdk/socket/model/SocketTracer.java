package com.tencent.qapmsdk.socket.model;

import android.text.TextUtils;

import com.tencent.qapmsdk.dns.model.DnsInfo;

import org.json.JSONObject;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

public class SocketTracer {
    private static final ConcurrentHashMap<String, SocketInfo> socketMap = new ConcurrentHashMap();


    public static void addSocketInfoToMap(String url, SocketInfo socketInfo){
        if (!TextUtils.isEmpty(url) && socketInfo != null){
            String hostName = socketInfo.host;
            long dnsElapse = DnsInfo.getDnsElapse(hostName);
            socketInfo.dnsTime = dnsElapse;
            if (socketMap.get(url) == null){
                socketMap.put(url, socketInfo);
            }
        }
    }

    public static SocketInfo getSocketInfoFromMap(String url){
        if (TextUtils.isEmpty(url)){
            return null;
        }
        return socketMap.get(url) == null ? socketMap.get(url + "/") : socketMap.get(url);
    }

    public static void removeSocketInfoFromMap(String url){
        if (TextUtils.isEmpty(url)){
            return;
        }
        SocketInfo socketInfo = socketMap.get(url);
        if (socketInfo != null){
            socketMap.remove(url);
        }
    }

}
