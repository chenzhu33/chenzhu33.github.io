package com.tencent.qapmsdk.socket.handler;

import android.text.TextUtils;

public class PathResolver {

    public static final IPathResolver DEFAULT = new DefaultPathResolver();

    private static IPathResolver sPathResolver = DEFAULT;

    private static class DefaultPathResolver implements IPathResolver {

        @Override
        public String resolve(String path) {
            if (TextUtils.isEmpty(path)) return path;
            String cgiPrefix = "/cgi-bin/";
            if (path.startsWith(cgiPrefix)) {
                int end = path.indexOf("?");
                if (end != -1) {
                    path = path.substring(cgiPrefix.length(), end);
                } else {
                    path = path.substring(cgiPrefix.length());
                }
            } else if (path.startsWith("/")) {
                int end = path.indexOf("?");
                if (end != -1) {
                    path = path.substring(1, end);
                } else {
                    path = path.substring(1);
                }
            }
            return path;
        }
    }

    public static void setPathResolver(IPathResolver pathResolver) {
        sPathResolver = pathResolver;
    }

    public static IPathResolver getPathResolver() {
        return sPathResolver;
    }
}

