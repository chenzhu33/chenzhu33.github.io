package com.tencent.qapmsdk.impl.instrumentation.okhttp2;

import com.avos.avoscloud.LogUtil;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.api.data.TransactionData;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionState;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionStateUtil;
import com.tencent.qapmsdk.impl.model.HttpDataModel;
import com.tencent.qapmsdk.impl.util.TraceUtil;

import java.io.IOException;

public class QAPMCallbackExtension implements Callback {
    private final static String TAG = "QAPM_Impl_QAPMCallbackExtension";
    private QAPMTransactionState transactionState;
    private Callback impl;

    public QAPMCallbackExtension(Callback impl, QAPMTransactionState transactionState) {
        this.impl = impl;
        this.transactionState = transactionState;
    }

    public void onFailure(Request request, IOException e) {
        try {
            this.doFailure((Exception)e);
        } catch (Exception ex) {
            Magnifier.ILOGUTIL.e(TAG, "QAPMCallbackExtension onFailure : " , ex.toString());
        }

        this.impl.onFailure(request, e);
    }

    public void onResponse(Response response) throws IOException {
        try {
            this.doResponse(response);
        } catch (Exception ex) {
            Magnifier.ILOGUTIL.e(TAG, "QAPMCallbackExtension onResponse " , ex.toString());
        }

        this.impl.onResponse(response);
    }

    private void doResponse(Response response) throws Exception {
        if (TraceUtil.getCanMonitorHttp()) {
            if (!this.getTransactionState().isComplete()) {
                this.getTransactionState().setQueueTime(this.getQueueTime(response, this.getTransactionState().getQueueTimeStamp()));
                QAPMOkHttp2TransactionStateUtil.inspectAndInstrumentResponse(this.getTransactionState(), response);
            }

        }
    }

    private int getQueueTime(Response response, long time) {
        int queueTime = 0;

        try {
            queueTime = (int)(Long.parseLong(response.header("X-QAPM-Qt")) - time);
        } catch (Exception e) {
            LogUtil.log.e("getQueueTime error:" + e.getMessage());
        }

        return queueTime;
    }

    private QAPMTransactionState getTransactionState() {
        return this.transactionState;
    }

    private void doFailure(Exception exception) throws Exception {
        if (TraceUtil.getCanMonitorHttp()) {
            QAPMTransactionState state = this.getTransactionState();
            QAPMTransactionStateUtil.setErrorCodeFromException(state, exception);
            if (!state.isComplete()) {
                TransactionData transactionData = state.end();
                if (transactionData == null) {
                    return;
                }

//                QAPMAndroidAgentImpl var4 = QAPMAgent.getImpl();
//                if (var4 == null) {
//                    return;
//                }
//
//                HarvestConfiguration var5 = var4.n();
//                if (var5 == null) {
//                    return;
//                }

                //k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
                if (state.isError()) {
                    String exceptionInfo = "";
                    if (state.getException() != null) {
                        exceptionInfo = state.getException();
                    }

                    Magnifier.ILOGUTIL.d(TAG, "error message:" , exceptionInfo);
                    //todo:整理数据
                    HttpDataModel.collectData(transactionData, exceptionInfo);
                    //h.a(state.getUrl(), state.getFormattedUrlParams(), state.getAllGetRequestParams(), state.getStatusCode(), exceptionInfo, state.getRequestMethodType(), transactionData.h(), transactionData.f(), transactionData.w(), transactionData.l(), transactionData.d());
                }
                else{
                    HttpDataModel.collectData(transactionData);
                }
            }

        }
    }
}
