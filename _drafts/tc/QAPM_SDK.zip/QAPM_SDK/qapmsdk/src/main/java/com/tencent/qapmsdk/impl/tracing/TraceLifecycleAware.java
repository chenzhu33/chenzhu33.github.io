package com.tencent.qapmsdk.impl.tracing;


public abstract interface TraceLifecycleAware
{
    public abstract void onEnterMethod();

    public abstract void onExitMethod();
}
