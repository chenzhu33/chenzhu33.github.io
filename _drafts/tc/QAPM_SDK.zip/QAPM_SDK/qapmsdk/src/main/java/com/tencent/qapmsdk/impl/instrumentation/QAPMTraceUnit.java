package com.tencent.qapmsdk.impl.instrumentation;

import android.os.Looper;

import com.tencent.qapmsdk.impl.tracing.TracingInactiveException;

public class QAPMTraceUnit extends QAPMUnit{
    private long invokeTimeFromAppStart;
    public int segmentType;
    public int callType;
    public int nodeType;
    public boolean isPageLoadEnd = false;

    public QAPMTraceUnit() {
        this.nodeType = 0;
        this.callType = 1;
        this.segmentType = 0;
    }

    public QAPMTraceUnit(String name, int segmentType) {
        this.callType = Looper.myLooper() == Looper.getMainLooper() ? TraceType.THREAD_TYPE.MAIN.getValue() : TraceType.THREAD_TYPE.OTHER.getValue();
        this.metricName = name;
        this.segmentType = segmentType;
        this.entryTimestamp = System.currentTimeMillis();
    }

    public QAPMTraceUnit(String name, String subName, long entryTime, long exitTime, int segmentType) {
        this.callType = Looper.myLooper() == Looper.getMainLooper() ? TraceType.THREAD_TYPE.MAIN.getValue() : TraceType.THREAD_TYPE.OTHER.getValue();
        this.metricName = name;
        this.subMetricName = subName;
        this.segmentType = segmentType;
        this.entryTimestamp = entryTime;
        this.exitTimestamp = exitTime;
    }

    public void complete()
    {
        super.complete();
    }
}
