package com.tencent.qapmsdk.impl.util;

import com.tencent.qapmsdk.Magnifier;

import java.net.MalformedURLException;
import java.net.URL;

public class StringUtil {
    private static String TAG = "QAPM_Impl_StringUtil";

    public static String contentType(String raw) {
        try {
            return raw == null ? "" : raw.split(";")[0];
        } catch (Exception e) {
            return "";
        }
    }

    public static String changeUrl(String rawUrl) {
        if (rawUrl == null) {
            return null;
        } else {
            URL url;
            try {
                url = new URL(rawUrl);
            } catch (MalformedURLException e) {
                return rawUrl;
            }

            StringBuffer sb = new StringBuffer();
            sb.append(url.getProtocol());
            sb.append("://");
            if (rawUrl.startsWith("file")) {
                sb.append("localfile");
            }

            sb.append(url.getHost());
            if (url.getPort() != -1) {
                sb.append(":");
                sb.append(url.getPort());
            }

            sb.append(url.getPath());
            return sb.toString();
        }
    }

    public static String getHostFromUrl(String rawUrl) {
        if (rawUrl == null) {
            return "";
        } else {
            try {
                URL url = new URL(rawUrl);
                return url.getHost();
            } catch (Exception e) {
                Magnifier.ILOGUTIL.e(TAG, "getHostFromUrl is error:" , e.getMessage() + ", url:" , rawUrl);
                return "";
            }
        }
    }
}
