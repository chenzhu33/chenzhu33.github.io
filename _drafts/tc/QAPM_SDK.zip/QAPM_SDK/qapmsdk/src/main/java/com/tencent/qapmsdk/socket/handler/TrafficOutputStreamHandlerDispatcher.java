package com.tencent.qapmsdk.socket.handler;

import android.support.annotation.NonNull;
import android.support.annotation.RestrictTo;

import com.tencent.qapmsdk.socket.model.SocketInfo;

import java.util.HashSet;
import java.util.Set;

@RestrictTo(RestrictTo.Scope.LIBRARY)
public class TrafficOutputStreamHandlerDispatcher {

    private Set<ITrafficOutputStreamHandler> mOutputStreamHandlers = new HashSet<>();

    public TrafficOutputStreamHandlerDispatcher() {
        for (ITrafficOutputStreamHandlerFactory factory : TrafficIOStreamHandlerManager.getOutputStreamHandlersFactories()) {
            mOutputStreamHandlers.add(factory.create());
        }
    }

    public void dispatchWrite(@NonNull byte[] b, int off, int len, SocketInfo socketInfo) {
        for (ITrafficOutputStreamHandler handler : mOutputStreamHandlers) {
            handler.onOutput(b, off, len, socketInfo);
        }
    }
}
