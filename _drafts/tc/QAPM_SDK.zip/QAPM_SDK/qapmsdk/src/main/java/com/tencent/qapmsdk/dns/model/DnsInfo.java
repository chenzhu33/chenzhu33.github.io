package com.tencent.qapmsdk.dns.model;

import android.text.TextUtils;

import com.squareup.okhttp.Dns;

import java.net.InetAddress;
import java.util.concurrent.ConcurrentHashMap;

public class DnsInfo {
    private static final ConcurrentHashMap<String, DNS> dnsMap = new ConcurrentHashMap();

    public static void setDns(String hostName, InetAddress[] inetAddresses, long time) {
        if (!TextUtils.isEmpty(hostName) && time >= 0) {
            if (dnsMap.get(hostName) == null) {
                dnsMap.put(hostName, new DNS(inetAddresses, time));
            }

        }
    }

    public static void clear(){
        dnsMap.clear();
    }

    public static void remove(String hostName){
        if (!TextUtils.isEmpty(hostName) && dnsMap.get(hostName) != null){
            dnsMap.remove(hostName);
        }
    }

    public static long getDnsElapse(String hostName){
        if (!TextUtils.isEmpty(hostName) && dnsMap.get(hostName) == null){
            return 0;
        }
        DNS dns = dnsMap.get(hostName);
        if (!dns.hasReport){
            dns.hasReport = true;
            dnsMap.put(hostName, dns);
            return dns.dnsTime;
        }
        return 0;
    }

    public static String getHostFromIp(String ip){
        for(String key : dnsMap.keySet()){
            DNS dns = dnsMap.get(key);
            for (InetAddress inetAddress : dns.inetAddresses){
                if (ip.equals(inetAddress.getHostAddress())){
                    return key;
                }
            }
        }
        return ip;
    }

    public static class DNS {
        public long dnsTime;
        public InetAddress[] inetAddresses;
        public boolean hasReport;

        public DNS(InetAddress[] inetAddresses, long dnsTime) {
            this.inetAddresses = inetAddresses;
            this.dnsTime = dnsTime;
            this.hasReport = false;
        }


    }

}

