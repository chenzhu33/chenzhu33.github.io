package com.tencent.qapmsdk.dns.network;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;


public class NetworkReceiver extends BroadcastReceiver {
    
    private static NetworkReceiver sInstance = new NetworkReceiver();
    
    public static void register(Context context) {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        context.registerReceiver(sInstance, filter);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        NetworkHandler.notifyNetworkChanged(context);
    }
}
