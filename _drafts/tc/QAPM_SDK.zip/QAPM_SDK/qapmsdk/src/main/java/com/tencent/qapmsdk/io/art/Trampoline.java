/*
 * Copyright (c) 2017, weishu twsxtd@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tencent.qapmsdk.io.art;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.io.art.arch.ShellCode;
import com.tencent.qapmsdk.io.art.entry.Entry;
import com.tencent.qapmsdk.io.art.entry.Entry64;
import com.tencent.qapmsdk.io.art.entry.Entry64ForM;
import com.tencent.qapmsdk.io.art.method.ArtMethod;
import com.tencent.qapmsdk.common.VersionUtils;

import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;

class Trampoline {
    private static final String TAG = "Trampoline";

    @NonNull
    private final ShellCode shellCode;
    private final long jumpToAddress;
    private final byte[] originalCode;
    private int trampolineSize;
    private long trampolineAddress;
    private boolean active;

    private ArtMethod artOrigin;
    @NonNull
    private Set<ArtMethod> segments = new HashSet<>();

    Trampoline(ShellCode shellCode, ArtMethod artMethod) {
        this.shellCode = shellCode;
        this.jumpToAddress = shellCode.toMem(artMethod.getEntryPointFromQuickCompiledCode());
        this.artOrigin = artMethod;
        this.artOrigin.setAccessible(true);
        this.originalCode = MethodHookNative.get(jumpToAddress, shellCode.sizeOfDirectJump());
    }

    public boolean install(ArtMethod originMethod){
        boolean modified = segments.add(originMethod);
        if (!modified) {
            return true;
        }

        byte[] page = create();
        if (page == null){
            return false;
        }
        MethodHookNative.put(page, getTrampolineAddress());

        // 这里是绝对不能改EntryPoint的，碰到GC就挂(GC暂停线程的时候，遍历所有线程堆栈，如果被hook的方法在堆栈上，那就GG)
        // source.setEntryPointFromQuickCompiledCode(script.getTrampolinePc());
        return activate();
    }

    private long getTrampolineAddress() {
        if (getSize() != trampolineSize) {
            alloc();
        }
        return trampolineAddress;
    }

    private long getTrampolinePc() {
        return shellCode.toPC(getTrampolineAddress());
    }

    private void alloc() {
        if (trampolineAddress != 0) {
            free();
        }
        trampolineSize = getSize();
        trampolineAddress = MethodHookNative.map(trampolineSize);
//        MagnifierSDK.ILOGUTIL.d(TAG, "Trampoline alloc:" + trampolineSize + ", addr: 0x" + Long.toHexString(trampolineAddress));
    }

    private void free() {
        if (trampolineAddress != 0) {
            MethodHookNative.unmap(trampolineAddress, trampolineSize);
            trampolineAddress = 0;
            trampolineSize = 0;
        }

        if (active) {
            MethodHookNative.put(originalCode, jumpToAddress);
        }
    }

    private int getSize() {
        //TODO:这里要和c层同步页大小
//        int count = 0;
//        count += shellCode.sizeOfBridgeJump();
//        count += shellCode.sizeOfCallOrigin();
//        count = (count / 4096 + 1) * 4096;
        return 4096; //与c层同步,map按照页处理
    }

    private byte[] create() {
        //此处是否需要segment作为循环处理需要再考虑，循环处理可能存在一些问题，重新hook的问题

        byte[] mainPage = new byte[getSize()];
        int offset = 0;

        byte[] script = createTrampoline(artOrigin);
        if (script == null){
            return null;
        }
        System.arraycopy(script, 0, mainPage, offset, script.length);
        offset += script.length;

        byte[] callOriginal = shellCode.createCallOrigin(jumpToAddress, originalCode);
        if (callOriginal == null){
            return null;
        }
        System.arraycopy(callOriginal, 0, mainPage, offset, callOriginal.length);
        return mainPage;
    }

    private boolean activate() {
        long pc = getTrampolinePc();
        synchronized (Trampoline.class) {
            return MethodHookNative.activateNative(jumpToAddress, pc, shellCode.sizeOfDirectJump(),
                    shellCode.sizeOfBridgeJump(), shellCode.createDirectJump(pc));
        }
    }

    @Override
    protected void finalize() throws Throwable {
        free();
        super.finalize();
    }

    @Nullable
    private byte[] createTrampoline(ArtMethod source){
        final MethodHook.MethodInfo methodInfo = MethodHook.getMethodInfo(source.getAddress());
        final Class<?> returnType = methodInfo.returnType;

        Method bridgeMethod = VersionUtils.is64Bit() ? (Build.VERSION.SDK_INT == 23 ? Entry64ForM.getBridgeMethod(methodInfo) : Entry64.getBridgeMethod(returnType))
                : Entry.getBridgeMethod(returnType);

        final ArtMethod target = ArtMethod.of(bridgeMethod);
        long targetAddress = target.getAddress();
        long targetEntry = target.getEntryPointFromQuickCompiledCode();
        long sourceAddress = source.getAddress();
        long structAddress = MethodHookNative.malloc(6);
        long singleRegister = MethodHookNative.malloc(32);
        long doubleRegister = MethodHookNative.malloc(32);

//        Magnifier.ILOGUTIL.d(TAG, "targetAddress:"+ Debug.longHex(targetAddress));
//        Magnifier.ILOGUTIL.d(TAG, "sourceAddress:"+ Debug.longHex(sourceAddress));
//        Magnifier.ILOGUTIL.d(TAG, "targetEntry:"+ Debug.longHex(targetEntry));
//        Magnifier.ILOGUTIL.d(TAG, "structAddress:"+ Debug.longHex(structAddress));

        return shellCode.createBridgeJump(targetAddress, targetEntry, sourceAddress, structAddress, singleRegister, doubleRegister);
    }
}
