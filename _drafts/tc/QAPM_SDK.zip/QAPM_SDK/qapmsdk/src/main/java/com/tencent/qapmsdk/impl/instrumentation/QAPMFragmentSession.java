package com.tencent.qapmsdk.impl.instrumentation;

import android.text.TextUtils;
import android.view.View;

import java.util.concurrent.ConcurrentHashMap;

public class QAPMFragmentSession {
    private static QAPMFragmentSession instance;

    public QAPMFragmentSession() {
    }


    public static void fragmentOnCreateEnd(String name) {
    }

    public static void fragmentOnCreateViewBegin(String instanceClassName, String instrumentClassName) {

    }


    public static void fragmentOnCreateViewEnd(String name, View container, String instrumentClassName) {

    }

    public void fragmentSessionStarted(String fragmentName, String instrumentClassName) {

    }

    public static void fragmentStartEnd(String fragmentName, String instrumentClassName) {


    }

    public static void fragmentSessionResumeBegin(String name, String instrumentClassName) {

    }

    public static void fragmentSessionResumeEnd(String name, String instrumentClassName) {

    }

    public void fragmentSessionPause(String fragmentName, boolean visible) {

    }

    public static QAPMFragmentSession getInstance() {
        if (instance == null) {
            instance = new QAPMFragmentSession();
        }

        return instance;
    }
}
