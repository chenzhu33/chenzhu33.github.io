package com.tencent.qapmsdk.crash.collections;

import android.support.annotation.NonNull;
import java.lang.ref.WeakReference;
import java.util.*;

public class WeakStack<T> extends AbstractCollection<T> {

    private final List<WeakReference<T>> contents = new ArrayList<>();

    private void cleanup() {
        for (WeakReference<T> weakReference : contents) {
            if (weakReference.get() == null) contents.remove(weakReference);
        }
    }

    @NonNull
    @Override
    public Iterator<T> iterator() {
        return new WeakIterator<>(contents.iterator());
    }

    @Override
    public int size() {
        cleanup();
        return contents.size();
    }

    @Override
    public boolean contains(Object o) {
        if (o != null) {
            for (WeakReference<T> weakReference : contents) {
                if (o.equals(weakReference.get())) return true;
            }
        }
        return false;
    }

    @Override
    public boolean add(T t) {
        return contents.add(new WeakReference<T>(t));
    }

    @Override
    public boolean remove(Object o) {
        if (o != null) {
            for (int i = 0; i < contents.size(); i++) {
                if (o.equals(contents.get(i).get())) {
                    contents.remove(i);
                    return true;
                }
            }
        }
        return false;
    }

    public T peek() {
        for (int i = contents.size() - 1; i >= 0; i--) {
            T result = contents.get(i).get();
            if (result != null) return result;
        }
        throw new EmptyStackException();
    }

    public T pop() {
        T result = peek();
        remove(result);
        return result;
    }

    @Override
    public void clear() {
        contents.clear();
    }

    private static class WeakIterator<T> implements Iterator<T> {
        private final Iterator<WeakReference<T>> iterator;
        private T next;

        private WeakIterator(Iterator<WeakReference<T>> iterator) {
            this.iterator = iterator;
        }

        @Override
        public boolean hasNext() {
            if (next != null) return true;
            while (iterator.hasNext()) {
                T t = iterator.next().get();
                if (t != null) {
                    //to ensure next() can't throw after hasNext() returned true, we need to dereference this
                    next = t;
                    return true;
                }
            }
            return false;
        }

        @Override
        public T next() {
            T result = next;
            next = null;
            while (result == null) {
                result = iterator.next().get();
            }
            return result;
        }

        @Override
        public void remove() {
            iterator.remove();
        }
    }
}
