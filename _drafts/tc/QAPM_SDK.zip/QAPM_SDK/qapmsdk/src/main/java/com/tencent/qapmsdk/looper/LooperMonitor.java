package com.tencent.qapmsdk.looper;

import java.util.HashMap;

import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.looper.MonitorInfo.IMonitorCallback;

public class LooperMonitor {
    @NonNull
    static HashMap<String, MonitorInfo> monitorMap = new HashMap<String, MonitorInfo>();

    @NonNull
    private static IMonitorCallback sMonitorCallback = new IMonitorCallback() {
        @Override
        public void onMonitorEnd() {
            Looper.getMainLooper().setMessageLogging(null);
        }
    };
    
    public static boolean setMonitoredThread(@Nullable Thread t, IMonitorCallback callback) {
        if (t == null) {
            return false;
        }
        
        String name = t.getName();
        synchronized(LooperMonitor.class) {
            MonitorInfo mi = monitorMap.get(name);
            if (mi != null) {
                if (mi.stackGetter == null) {
                    mi.stackGetter = new GetStackRunnable(t);
                    Thread getStackThread = new Thread(mi.stackGetter, "get-stack-" + name);
                    getStackThread.start();
                    mi.stackGetterInited = true;
                    mi.callback = callback;
                    return true;
                } else {
                    return false;
                }
            } else {
                mi = new MonitorInfo();
                mi.stackGetter = new GetStackRunnable(t);
                mi.stackGetterInited = true;
                mi.callback = callback;
                monitorMap.put(name, mi);
                Thread getStackThread = new Thread(mi.stackGetter, "get-stack-" + name);
                getStackThread.start();
                return true;
            }
        }
    }
    
    public static void monitorMainLooper() {
        if (!CollectStatus.canCollect(Config.PLUGIN_QCLOUD_LOOPER_STACK)) {
            return;
        }
        Thread mainThread = Looper.getMainLooper().getThread();
        setMonitoredThread(mainThread, sMonitorCallback);
        LooperPrinter printer = new LooperPrinter(mainThread.getName());
        LooperPrinter.sLogThreshold = Config.mSampleConfigs.get(Config.PLUGIN_QCLOUD_LOOPER_STACK).threshold;
        Looper.getMainLooper().setMessageLogging(printer);
    }
}