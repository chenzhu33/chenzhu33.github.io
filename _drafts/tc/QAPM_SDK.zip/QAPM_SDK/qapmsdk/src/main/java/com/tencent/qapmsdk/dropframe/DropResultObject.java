package com.tencent.qapmsdk.dropframe;

public final class DropResultObject {
    public int state = 0;
    public int dropcount = 0;
    public float duration = 0.0f;
    public long[] dropIntervals = {0, 0, 0, 0, 0, 0};

    public DropResultObject() {
    }

    public DropResultObject(int dropcount, float duration, long[] dropIntervals) {
        this.dropcount = dropcount;
        this.duration = duration;
        this.dropIntervals = dropIntervals;
    }
    
    void reset() {
        dropcount = 0;
        duration = 0.0f;
        for (int i = 0; i < dropIntervals.length; i++) {
            dropIntervals[i] = 0;
        }
    }
}