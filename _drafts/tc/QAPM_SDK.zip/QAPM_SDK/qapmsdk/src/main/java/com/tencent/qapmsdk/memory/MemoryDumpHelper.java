package com.tencent.qapmsdk.memory;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.reporter.ResultObject;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.NetworkWatcher;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.common.VersionUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * Created by acolorzhang on 2016/9/6.
 */
public class MemoryDumpHelper {
    private static final String TAG = ILogUtil.getTAG(MemoryDumpHelper.class);
    @Nullable
    private volatile static MemoryDumpHelper sInstance = null;
    @NonNull
    private static HashMap<String, String> extraInfoMap = new HashMap<String, String>();

    private MemoryDumpHelper() {
    }

    @Nullable
    public static MemoryDumpHelper getInstance() {
        if (sInstance == null) {
            synchronized (MemoryDumpHelper.class) {
                if (sInstance == null) {
                    sInstance = new MemoryDumpHelper();
                }
            }
        }
        return sInstance;
    }

    /**
     * 导出内存
     *
     * @param tag
     */
    public void startDumpingMemory(final String tag) {
        try {
            if (!needShowDumpWarning()) {
                return;
            }
            dump(tag);
        } catch (Exception ex) {
            Magnifier.ILOGUTIL.exception(TAG, ex);
        }
    }

    private boolean needShowDumpWarning() {
        if (!NetworkWatcher.isWifiAvailable()) {
            Magnifier.ILOGUTIL.d(TAG, "network is not wifi, don't dump");
            return false;
        }
        // 7.0以上不dump
        if (!VersionUtils.checkFileIOCompatibility()) {
            Magnifier.ILOGUTIL.d(TAG, "isRuntimeART don't dump");
            return false;
        }
        // 每个用户只dump一次
        if (Magnifier.QAPM_SP != null && Magnifier.editor != null) {
            int dumpCount = Magnifier.QAPM_SP.getInt(Magnifier.info.version, 0);
            if (dumpCount < 1) {
                Magnifier.editor.putInt(Magnifier.info.version, dumpCount + 1);
                Magnifier.editor.commit();
                Magnifier.ILOGUTIL.d(TAG, "this user don't have dumped");
                return true;
            }
        }
       // MagnifierSDK.ILOGUTIL.d(TAG, "this user have dumped");
        return false;
    }

    /**
     * 灰度版本（内存泄漏和触顶）只取dump，如果hook框架加载失败，就什么都不做
     * 研发流程内，内存触顶只取dump，内存泄露取dump、trace、log等信息。
     */
    private void dump(final String dgst) {
        List<String> files = new ArrayList<String>();
        //如果要保存LOGCAT或者traces.txt，放在onPrepareDump里做
        List<String> prepareFiles = MemoryMonitor.getInstance().memoryCellingListener.onBeforeDump(dgst);
        //自动生成dump还要把一些附加信息带到ZIP包里面
        if (prepareFiles != null && prepareFiles.size() > 0) {
            files.addAll(prepareFiles);
        } else {
            Magnifier.ILOGUTIL.e(TAG, "prepareFiles is none");
            return;
        }
        Object[] zipRet = DumpMemInfoHandler.zipFiles(files, dgst);
        final String curActivityName = Magnifier.getCurrentActivityName();
        if (!(Boolean) zipRet[0]) {
            Magnifier.ILOGUTIL.e(TAG, "dump other file failed!");
            return;
        }

        //dump完毕
        MemoryMonitor.getInstance().memoryCellingListener.onAfterDump();
        
        if (!CollectStatus.canCollect(Config.PLUGIN_QCLOUD_CEILING_HPROF)) {
            return;
        }
        CollectStatus.addCollectCount(Config.PLUGIN_QCLOUD_CEILING_HPROF);

        try {
            JSONObject params = new JSONObject();
            params.put("fileObj", zipRet[1]);
            params.put("stage", curActivityName);
            params.put("Activity", curActivityName);
            params.put("UIN", Magnifier.info.uin);
            params.put("Model", Build.MODEL);
            params.put("OS", Build.VERSION.RELEASE);
            params.put("Threshold", Config.mSampleConfigs.get(Config.PLUGIN_QCLOUD_CEILING_HPROF).threshold * Runtime.getRuntime().maxMemory() / 100);
            params.put("plugin", Config.PLUGIN_QCLOUD_CEILING_HPROF);
            ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, Magnifier.info.uin);
            ReporterMachine.addResultObj(ro);
        } catch (JSONException e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
    }

    public void onReportToYunYing(final long memory, final long threshold, final String activity, final String uin) {
        if (!CollectStatus.canCollect(Config.PLUGIN_QCLOUD_CEILING_VALUE)) {
            return;
        }
        CollectStatus.addCollectCount(Config.PLUGIN_QCLOUD_CEILING_VALUE);
        try {
            JSONObject params = new JSONObject();
            JSONObject data = new JSONObject();
            data.put("vcname", activity);
            data.put("singleMemory", memory);
            data.put("threshold", threshold);
            params.put("processname", PhoneUtil.getProcessName(Magnifier.sApp));
            params.put("minidumpdata", data);
            params.put("plugin", Config.PLUGIN_QCLOUD_CEILING_VALUE);
//          上传用户自定义字段
            if (extraInfoMap != null && !extraInfoMap.isEmpty()) {
                for (String key : extraInfoMap.keySet()) {
                    params.put(key, extraInfoMap.get(key));
                }
            }
            ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, Magnifier.info.uin);
            ReporterMachine.addResultObj(ro);
        } catch (JSONException e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
    }

    //    上报额外上报字段、信息
    public void setExtraInfo(@Nullable String field, @Nullable String content) {
        if (extraInfoMap == null) {
            Magnifier.ILOGUTIL.d(TAG, "extraInfoMap need init");
            return;
        }
        if (field == null || content == null) {
            Magnifier.ILOGUTIL.d(TAG, "field and content must be not null");
            return;
        }
        extraInfoMap.put(field, content);
    }
}