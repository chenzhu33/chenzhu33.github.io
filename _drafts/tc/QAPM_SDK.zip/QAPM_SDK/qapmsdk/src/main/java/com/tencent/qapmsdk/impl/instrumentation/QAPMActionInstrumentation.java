package com.tencent.qapmsdk.impl.instrumentation;

import android.view.View;

public class QAPMActionInstrumentation {

    public QAPMActionInstrumentation() {
    }

    public static void onClickEventEnter(View view, Object owner) {

    }

    public static void onClickEventExit() {

    }

    public static void onLongClickEventEnter(View view, Object owner) {

    }

    public static void onLongClickEventExit() {

    }

    public static void onKeyDownAction(int keycode, String owner) {

    }

    public static void onItemClickEnter(View view, int paramInt, Object owner) {

    }

    public static void onItemClickExit() {

    }

    public static void onItemSelectedEnter(View view, int position, Object owner) {

    }

    public static void onItemSelectedExit() {

    }

    public static void onPageSelectedEnter(int paramInt, Object owner) {

    }

    public static void onPageSelectedExit() {

    }

    public static void onMenuItemClickEnter(Object paramObject, Object owner) {

    }

    public static void onMenuItemClickExit() {

    }

    public static void onOptionsItemSelectedEnter(Object paramObject, Object owner) {

    }

    public static void onOptionsItemSelectedExit() {

    }
}
