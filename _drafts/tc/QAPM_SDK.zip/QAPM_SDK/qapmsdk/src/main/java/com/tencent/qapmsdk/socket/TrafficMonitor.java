package com.tencent.qapmsdk.socket;

import android.content.Context;
import android.util.Log;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.report.TrafficMonitorReport;
import com.tencent.qapmsdk.socket.handler.FirstPackageInputFactory;
import com.tencent.qapmsdk.socket.handler.FirstPackageOutputFactory;
import com.tencent.qapmsdk.socket.handler.HttpBodyLogInterceptor;
import com.tencent.qapmsdk.socket.handler.IHttpBodyLogInterceptor;
import com.tencent.qapmsdk.socket.handler.IPathResolver;
import com.tencent.qapmsdk.socket.handler.ITrafficInputStreamHandlerFactory;
import com.tencent.qapmsdk.socket.handler.ITrafficOutputStreamHandlerFactory;
import com.tencent.qapmsdk.socket.handler.PathResolver;
import com.tencent.qapmsdk.socket.handler.TrafficIOStreamHandlerManager;
import com.tencent.qapmsdk.socket.model.SocketInfo;
import com.tencent.qapmsdk.socket.util.HookUtils;


/**
 * <pre>
 * 网络流量的监控器
 *
 * </pre>
 */
public class TrafficMonitor {

    private static final String TAG = "QAPM_Socket_TrafficMonitor";
    private static FirstPackageInputFactory firstPackageInputFactory = new FirstPackageInputFactory();
    private static FirstPackageOutputFactory firstPackageOutputFactory = new FirstPackageOutputFactory();


    public static void install() {
        Magnifier.ILOGUTIL.i(TAG, "install TrafficMonitor");
        config().addInputStreamHandlerFactory(firstPackageInputFactory);
        config().addOutputStreamHandlerFactory(firstPackageOutputFactory);
        config().setConnectListener(new TrafficConnectReporter.IConnectListener() {
            @Override
            public void onConnected(boolean success, String host, int port, long costMillis, SocketInfo socketInfo) {
                socketInfo.tcpTime = costMillis;
                if (!success && socketInfo.exception != null){
                    socketInfo.errorCode = SocketInfo.getErrorCode(socketInfo.exception);
                }
                if (!socketInfo.hasSaved){
                    TrafficMonitorReport.getInstance().addSocketToQueue(socketInfo);
                    socketInfo.hasSaved = true;
                }
            }

            @Override
            public void onHandshakeCompleted(boolean success, String host, int port, long costMillis, SocketInfo socketInfo) {
                if (success && socketInfo != null){
                    socketInfo.sslTime = costMillis;
                }

            }
        });
        HookUtils.hook();
    }

    public static TrafficConfig config() {
        return TrafficConfig.sInstance;
    }

    public static class TrafficConfig {

        private static TrafficConfig sInstance = new TrafficConfig();

        private Context mApplicationContext;

        private boolean mVerbose = true;

        private boolean isEnableNetwork = true;

        private long mPeriod = 60 * 1000; // 默认周期为1分钟

        public TrafficConfig verbose(boolean enable) {
            mVerbose = enable;
            return this;
        }

        public boolean isVerbose() {
            return mVerbose;
        }


        public long getPeriod() {
            return mPeriod;
        }

        public TrafficConfig applicationContext(Context context) {
            this.mApplicationContext = context.getApplicationContext();
            return this;
        }

        public TrafficConfig addInputStreamHandlerFactory(ITrafficInputStreamHandlerFactory factory) {
            TrafficIOStreamHandlerManager.addInputStreamHandlerFactory(factory);
            return this;
        }

        public TrafficConfig addOutputStreamHandlerFactory(ITrafficOutputStreamHandlerFactory factory) {
            TrafficIOStreamHandlerManager.addOutputStreamHandlerFactory(factory);;
            return this;
        }

        public TrafficConfig setPathResolver(IPathResolver pathResolver) {
            PathResolver.setPathResolver(pathResolver);
            return this;
        }

        public TrafficConfig setConnectListener(TrafficConnectReporter.IConnectListener listener) {
            TrafficConnectReporter.setConnectListener(listener);
            return this;
        }

        public TrafficConfig setHttpBodyLogInterceptor(IHttpBodyLogInterceptor interceptor) {
            HttpBodyLogInterceptor.setInterceptor(interceptor);
            return this;
        }

        public TrafficConfig enableNetwork(boolean enable) {
            isEnableNetwork = enable;
            return this;
        }

        public boolean isEnableNetwork() {
            return isEnableNetwork;
        }

        public Context getApplicationContext() {
            return mApplicationContext;
        }
    }



}


