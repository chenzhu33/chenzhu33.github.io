package com.tencent.qapmsdk.impl.tracing;

public class TracingInactiveException
        extends Exception
{}
