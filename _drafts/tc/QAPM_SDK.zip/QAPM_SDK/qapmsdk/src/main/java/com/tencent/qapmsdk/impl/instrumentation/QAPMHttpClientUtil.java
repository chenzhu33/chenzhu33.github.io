package com.tencent.qapmsdk.impl.instrumentation;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.common.NetworkWatcher;
import com.tencent.qapmsdk.impl.api.data.TransactionData;
import com.tencent.qapmsdk.impl.harvest.HttpLibType;
import com.tencent.qapmsdk.impl.harvest.RequestMethodType;
import com.tencent.qapmsdk.impl.instrumentation.httpclient.QAPMContentBufferingResponseEntityImpl;
import com.tencent.qapmsdk.impl.instrumentation.httpclient.QAPMHttpRequestEntityImpl;
import com.tencent.qapmsdk.impl.instrumentation.httpclient.QAPMHttpResponseEntityImpl;
import com.tencent.qapmsdk.impl.instrumentation.httpclient.QAPMHttpResponseEntityWrapperImpl;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMCountingInputStream;
import com.tencent.qapmsdk.impl.model.HttpDataModel;
import com.tencent.qapmsdk.impl.util.StringUtil;
import com.tencent.qapmsdk.impl.util.TraceUtil;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.RequestLine;
import org.apache.http.auth.AuthenticationException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.client.methods.HttpOptions;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpTrace;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.entity.HttpEntityWrapper;

import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.TreeMap;

import javax.net.ssl.SSLException;

public class QAPMHttpClientUtil {
    private final static String TAG = "QAPM_Impl_QAPMHttpClientUtil";
    public QAPMHttpClientUtil() {
    }

    public static HttpRequest setHttpClientCrossProcessHeader(HttpRequest request) {
//        try {
//            if (Harvest.isHttp_network_enabled() && request != null) {
//                String var1 = h.j().T();
//                if (!TextUtils.isEmpty(var1) && h.j().S()) {
//                    int var2 = h.U();
//                    String var3 = h.a(var1, var2);
//                    request.setHeader("X-Tingyun-Id", var3);
//                }
//            }
//        } catch (Exception var4) {
//            log.d("QAPMTransactionStateUtil setHttpClientCrossProcessHeader has an error " + var4);
//        }

        return request;
    }

    public static void getHttpClientRequest(QAPMTransactionState transaction, HttpRequest request) {
        if (request instanceof HttpOptions) {
            transaction.setRequestMethod(RequestMethodType.OPTIONS);
        } else if (request instanceof HttpGet) {
            transaction.setRequestMethod(RequestMethodType.GET);
        } else if (request instanceof HttpHead) {
            transaction.setRequestMethod(RequestMethodType.HEAD);
        } else if (request instanceof HttpPost) {
            transaction.setRequestMethod(RequestMethodType.POST);
        } else if (request instanceof HttpPut) {
            transaction.setRequestMethod(RequestMethodType.PUT);
        } else if (request instanceof HttpDelete) {
            transaction.setRequestMethod(RequestMethodType.DELETE);
        } else if (request instanceof HttpTrace) {
            transaction.setRequestMethod(RequestMethodType.TRACE);
        } else {
            transaction.setRequestMethod(RequestMethodType.GET);
        }

    }

    private static void processParamsAndHeader(QAPMTransactionState transaction, final HttpRequest request, String uriParam) {
        getHttpClientRequest(transaction, request);
        QAPMTransactionStateUtil.processParamsFilter(transaction, transaction.getUrlParams());
        QAPMNetworkProcessHeader qapmNetworkProcessHeader = new QAPMNetworkProcessHeader() {
            public String getFilterHeader(String filterHeader) {
                Header header = request.getFirstHeader(filterHeader);
                return null != header ? header.getValue() : "";
            }
        };
        QAPMTransactionStateUtil.processHeaderParam(transaction.getUrl(), qapmNetworkProcessHeader, transaction);
    }

    public static HttpRequest inspectAndInstrument(QAPMTransactionState transactionState, HttpHost httpHost, HttpRequest request) {
        if (request == null) {
            return request;
        } else {
            RequestLine requestLine = request.getRequestLine();
            String url = null;
            String param = null;
            if (requestLine != null) {
                url = requestLine.getUri();
                if (url.contains("?")) {
                    int index = url.indexOf("?");
                    String host = url.substring(0, index);
                    param = url.substring(index + 1);
                    url = host;
                }
            }

            transactionState.setUrl(url);
            transactionState.setUrlParams(param);
            transactionState.setAllGetRequestParams(param);
            transactionState.setHttpLibType(HttpLibType.HttpClient);
            processParamsAndHeader(transactionState, request, param);
            transactionState.setCarrier(NetworkWatcher.activeNetworkCarrier());
            wrapRequestEntity(transactionState, request);
            return request;
        }
    }

    private static void wrapRequestEntity(QAPMTransactionState transactionState, HttpRequest request) {
        if (request instanceof HttpEntityEnclosingRequest) {
            HttpEntityEnclosingRequest var2 = (HttpEntityEnclosingRequest)request;
            if (var2.getEntity() != null) {
                var2.setEntity(new QAPMHttpRequestEntityImpl(var2.getEntity(), transactionState));
            }
        }

    }

    public static HttpResponse inspectAndInstrument(QAPMTransactionState transactionState, HttpResponse response) {
        try {
            transactionState.setStatusCode(response.getStatusLine().getStatusCode());
//            Header[] var2 = response.getHeaders("X-QAPM-Tx-Data");
//            log.c("get X-QAPM-Tx-Data");
//            if (var2 != null && var2.length > 0 && !"".equals(var2[0].getValue())) {
//                log.c("header:" + var2[0].getValue());
//                transactionState.setAppData(var2[0].getValue());
//            }
//
//            Header[] var4;
//            if (Harvest.isCdn_enabled()) {
//                QAPMAndroidAgentImpl var3 = QAPMAgent.getImpl();
//                if (var3 != null) {
//                    var4 = response.getHeaders(var3.n().getCdnHeaderName());
//                    if (var4 != null && var4.length > 0) {
//                        log.a("cdnHeaderName key : " + var4[0]);
//                        log.a("cdnHeaderName value : " + var4[0].getValue());
//                        transactionState.setCdnVendorName(var4[0].getValue() == null ? "" : var4[0].getValue());
//                    }
//                }
//            }

            Header[] contentType = response.getHeaders("Content-Type");
            if (contentType != null && contentType.length > 0) {
                transactionState.setContentType(StringUtil.contentType(contentType[0].getValue()));
            }

            Header[] contentLen = response.getHeaders("Content-Length");
            long byteReceived = -1L;
            if (contentLen != null && contentLen.length > 0) {
                try {
                    byteReceived = Long.parseLong(contentLen[0].getValue());
                    transactionState.setBytesReceived(byteReceived);
                    HttpEntity responseEntity = response.getEntity();
                    if (responseEntity == null) {
                        response.setEntity((HttpEntity)null);
                    } else if (responseEntity instanceof HttpEntityWrapper) {
                        response.setEntity(new QAPMHttpResponseEntityWrapperImpl(response, transactionState, byteReceived));
                    } else {
                        response.setEntity(new QAPMHttpResponseEntityImpl(response, transactionState, byteReceived));
                    }
                } catch (NumberFormatException e) {
                    Magnifier.ILOGUTIL.e(TAG, "Failed to parse content length: " , e.toString());
                }
            } else if (response.getEntity() != null) {
                if (response.getEntity() instanceof HttpEntityWrapper) {
                    response.setEntity(new QAPMHttpResponseEntityWrapperImpl(response, transactionState, byteReceived));
                } else {
                    response.setEntity(new QAPMHttpResponseEntityImpl(response, transactionState, byteReceived));
                }
            } else {
                transactionState.setBytesReceived(0L);
                addTransactionAndErrorData(transactionState, (HttpResponse)null);
            }
        } catch (Exception e1) {
            Magnifier.ILOGUTIL.e(TAG, " java.lang.NoSuchMethodError: org.apache.http.HttpResponse.getHeaders" , e1.toString());
        }

        return response;
    }

    private static void addTransactionAndErrorData(QAPMTransactionState transactionState, HttpResponse response) {
        if (TraceUtil.getCanMonitorHttp()) {
            try {
//                QAPMAndroidAgentImpl var2 = QAPMAgent.getImpl();
//                if (var2 == null) {
//                    return;
//                }
//
//                HarvestConfiguration var3 = var2.n();
//                if (var3 == null) {
//                    return;
//                }

                TransactionData transactionData = transactionState.end();
                if (null == transactionData) {
                    Magnifier.ILOGUTIL.d(TAG, "HttpResponseEntityWrapperImpl transactionData is null!");
                    return;
                }

//                k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
                if (transactionState.isError()) {
                    StringBuilder sb = new StringBuilder();
                    if (response != null) {
                        try {
                            if (!(response.getEntity() instanceof QAPMHttpRequestEntityImpl)) {
                                response.setEntity(new QAPMContentBufferingResponseEntityImpl(response.getEntity()));
                            }

                            InputStream inputStream = response.getEntity().getContent();
                            if (inputStream instanceof QAPMCountingInputStream) {
                                sb.append(((QAPMCountingInputStream)inputStream).getBufferAsString());
                            } else {
                                Magnifier.ILOGUTIL.d(TAG, "Unable to wrap content stream for entity");
                            }
                        } catch (IllegalStateException e1) {
                            Magnifier.ILOGUTIL.e(TAG, e1.toString());
                        } catch (IOException e2) {
                            Magnifier.ILOGUTIL.e(TAG, e2.toString());
                        }
                    }

                    Map responseHeader = resolvingResponseHeader(response);
                    responseHeader.put("Content-Length", transactionState.getBytesReceived());
                    Magnifier.ILOGUTIL.d(TAG, "response body content:" , sb.toString());
                    String exceptionInfo = "";
                    if (transactionState.getException() != null) {
                        exceptionInfo = transactionState.getException();
                    }

                    Magnifier.ILOGUTIL.d(TAG, "error message:" , exceptionInfo);
                    //todo:整理数据
                    HttpDataModel.collectData(transactionData, exceptionInfo);
                    //com.networkbench.agent.impl.g.h.a(transactionData.o(), transactionState.getFormattedUrlParams(), transactionState.getAllGetRequestParams(), transactionData.q(), sb.toString(), responseHeader, exceptionInfo, transactionData.n(), transactionData.h(), transactionData.f(), transactionData.w(), transactionData.l(), transactionData.d());
                }
                else{
                    HttpDataModel.collectData(transactionData);
                }
            } catch (Exception e) {
                Magnifier.ILOGUTIL.exception(TAG, "addTransactionAndErrorData", e);
            }

        }
    }

    public static HttpUriRequest inspectAndInstrument(QAPMTransactionState transactionState, HttpUriRequest request) {
        if (request == null) {
            return request;
        } else {
            RequestLine requestLine = request.getRequestLine();
            String url = null;
            String param = null;
            if (requestLine != null) {
                url = requestLine.getUri();
                if (url.contains("?")) {
                    int index = url.indexOf("?");
                    String host = url.substring(0, index);
                    param = url.substring(index + 1);
                    url = host;
                }
            } else {
                url = request.getURI().toString();
            }

            transactionState.setUrl(url);
            transactionState.setCarrier(NetworkWatcher.activeNetworkCarrier());
            transactionState.setMethodType(request.getMethod());
            transactionState.setUrlParams(param);
            transactionState.setAllGetRequestParams(param);
            transactionState.setHttpLibType(HttpLibType.HttpClient);
            processParamsAndHeader(transactionState, request, param);
            wrapRequestEntity(transactionState, request);
            return request;
        }
    }

    public static void setErrorCodeFromException(QAPMTransactionState transactionState, Exception e) {
        if (e instanceof IOException) {
            if (QAPMTransactionStateUtil.isSocketECONNRESET(e)) {
                transactionState.setErrorCode(911, e.toString());
                transactionState.setStatusCode(911);
                return;
            }

            String exceptionMessage = e.getMessage();
            if (e != null && exceptionMessage != null && exceptionMessage.contains("ftruncate failed: ENOENT (No such file or directory)")) {
                transactionState.setErrorCode(917, e.toString());
                transactionState.setStatusCode(917);
                return;
            }
        }

        if (e instanceof UnknownHostException) {
            transactionState.setErrorCode(901, e.toString());
            transactionState.setStatusCode(901);
        } else if (!(e instanceof SocketTimeoutException) && !(e instanceof ConnectTimeoutException)) {
            if (e instanceof ConnectException) {
                transactionState.setErrorCode(902, e.toString());
                transactionState.setStatusCode(902);
            } else if (e instanceof MalformedURLException) {
                transactionState.setErrorCode(900, e.toString());
                transactionState.setStatusCode(900);
            } else if (e instanceof SSLException) {
                transactionState.setErrorCode(908, e.toString());
                transactionState.setStatusCode(908);
            } else if (e instanceof HttpResponseException) {
                transactionState.setStatusCode(((HttpResponseException)e).getStatusCode());
            } else if (e instanceof ClientProtocolException) {
                transactionState.setErrorCode(904, e.toString());
                transactionState.setStatusCode(904);
            } else if (e instanceof AuthenticationException) {
                transactionState.setErrorCode(907, e.toString());
                transactionState.setStatusCode(907);
            } else {
                transactionState.setErrorCode(-1, e.toString());
                transactionState.setStatusCode(-1);
            }
        } else {
            transactionState.setErrorCode(903, e.toString());
            transactionState.setStatusCode(903);
        }

    }

    public static Map<String, Object> resolvingResponseHeader(HttpResponse response) {
        TreeMap treeMap = new TreeMap();
        if (response != null) {
            Header[] headers = response.getAllHeaders();
            if (headers != null) {
                Header[] tmp = headers;
                int len = headers.length;

                for(int i = 0; i < len; ++i) {
                    Header header = tmp[i];
                    treeMap.put(header.getName(), header.getValue());
                }
            }
        }

        return treeMap;
    }
}