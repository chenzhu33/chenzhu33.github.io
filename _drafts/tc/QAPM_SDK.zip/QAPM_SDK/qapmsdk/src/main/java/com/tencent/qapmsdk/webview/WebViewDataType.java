package com.tencent.qapmsdk.webview;

public class WebViewDataType {
    public static final String DOM_LOADING = "dom_loading";
    public static final String URL = "url";
    public static final String PROXY_TYPE = "proxy_type";
    public static final String SOCKET_REUSE_PO = "socket_reuse_pro";
    public static final String REFERER = "referer";
    public static final String PAGE_START = "page_start";
    public static final String PAGE_FINISH = "page_finish";
    public static final String LAYOUT_ELAPSED = "layout_elapsed";
    public static final String FIRST_SCREEN = "first_screen";
    public static final String START_MONITOR_TIME = "start_monitor_time";
    public static final String STOP_MONITOR_TIME = "stop_monitor_time";

    public static final String QPROXY_STRATEGY = "qproxy_strategy";
    public static final String RENDER_ELAPSED = "render_elapsed";
    public static final String PARSER_ELSPSED = "parser_elapsed";
    public static final String APN_TYPE = "apn_type";
    public static final String HOST_COUNT = "hostcount";
    public static final String VERSION = "version";
    public static final String DOM_COMPLETE = "dom_complete";
    public static final String DOM_INTERACTIVE =  "dom_interactive";
    public static final String MAIN_RESOURCE = "main_resource";
    public static final String SUB_RESOURCE = "sub_resource";
    public static final String QUIC_PRO = "quic_pro";
    public static final String FIRST_WORD = "first_word";

    public static final String DOM_CONTENT_LOADED_EVENT_START = "dom_content_loaded_event_start";
    public static final String DOM_CONTENT_LOADED_EVENT_END = "dom_content_loaded_event_end";
    public static final String DOM_CONTENT_LOADED_EVENT = "dom_content_loaded_event";
    public static final String FIRST_WORD_STAMP = "first_word_stamp";
    public static final String FIRST_SCREEN_STAMP = "first_screen_stamp";
    public static final String FIRST_BYTE_STAMP = "first_byte_stamp";

    public static final String SUB_RESOURCE_JSON_ARR = "sub_resource_json_arr";
    public static final String FPS_JSON_ARR = "fps_json_arr";
    public static final String CPU_INFO_JSON_ARR = "cpu_info_json_arr";
    public static final String MEMORY_INFO_JSON_ARR = "memory_info_json_arr";
    public static final String NETWORK_INFO_JSON_ARR = "network_info_json_arr";
    public static final String GPU_INFO_JSON_ARR = "gpu_info_json_arr";

    public static final String BASE_TIME = "base_time";
    public static final String IS_SYSTEM_KERNEL = "is_system_kernel";

    public static final String FRAME_START_TIME = "frame_start_time";
    public static final String FRAME_END_TIME = "frame_end_time";
    public static final String LAYER_NUM = "layer_num";
    public static final String TOTAL_LAYER_MEM = "total_layer_mem";
    public static final String MIN_LAYER_SIZE = "min_layer_size";
    public static final String MAX_LAYER_SIZE = "max_layer_size";

    public static final String BREAD_CRUMB_ID = "bread_crumb_id";

}
