package com.tencent.qapmsdk.common;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Handler;
import android.support.annotation.NonNull;

/**
 * Created by anthonytan on 2018/8/15.
 */

public class AsyncSPEditor {
    private Editor e;

    public AsyncSPEditor(Editor editor) {
        e = editor;
    }

    @NonNull
    public AsyncSPEditor putBoolean(String key, boolean value) {
        if (e != null) {
            e.putBoolean(key, value);
        }
        return this;
    }

    @NonNull
    public AsyncSPEditor putInt(String key, int value) {
        if (e != null) {
            e.putInt(key, value);
        }
        return this;
    }

    @NonNull
    public AsyncSPEditor putLong(String key, long value) {
        if (e != null) {
            e.putLong(key, value);
        }
        return this;
    }

    @NonNull
    public AsyncSPEditor putFloat(String key, float value) {
        if (e != null) {
            e.putFloat(key, value);
        }
        return this;
    }

    @NonNull
    public AsyncSPEditor putString(String key, String value) {
        if (e != null) {
            e.putString(key, value);
        }
        return this;
    }

    public boolean commit() {
        Handler h = new Handler(ThreadManager.getMonitorThreadLooper());
        h.post(new CommitRunnable(e));
        return true;
    }

    public void apply() {
        commit();
    }

    private class CommitRunnable implements Runnable {
        private Editor edit;

        public CommitRunnable(Editor editor) {
            edit = editor;
        }

        @Override
        public void run() {
            try {
                edit.commit();
            }
            catch (Exception e)
            {

            }

        }
    }
}
