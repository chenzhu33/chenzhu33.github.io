package com.tencent.qapmsdk.crash.util;

public interface Predicate<T> {
    boolean apply(T t);
}
