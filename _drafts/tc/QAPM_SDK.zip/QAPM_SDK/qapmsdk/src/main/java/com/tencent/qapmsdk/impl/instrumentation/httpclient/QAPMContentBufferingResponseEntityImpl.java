package com.tencent.qapmsdk.impl.instrumentation.httpclient;

import com.tencent.qapmsdk.impl.instrumentation.io.QAPMCountingInputStream;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.http.Header;
import org.apache.http.HttpEntity;

public class QAPMContentBufferingResponseEntityImpl implements HttpEntity {
    final HttpEntity httpEntity;
    private QAPMCountingInputStream contentStream;

    public QAPMContentBufferingResponseEntityImpl(HttpEntity impl) {
        if (impl == null) {
            throw new IllegalArgumentException("Missing wrapped entity");
        } else {
            this.httpEntity = impl;
        }
    }

    public void consumeContent() throws IOException {
        this.httpEntity.consumeContent();
    }

    public InputStream getContent() throws IOException, IllegalStateException {
        if (this.contentStream != null) {
            return this.contentStream;
        } else {
            this.contentStream = new QAPMCountingInputStream(this.httpEntity.getContent(), true);
            return this.contentStream;
        }
    }

    public Header getContentEncoding() {
        return this.httpEntity.getContentEncoding();
    }

    public long getContentLength() {
        return this.httpEntity.getContentLength();
    }

    public Header getContentType() {
        return this.httpEntity.getContentType();
    }

    public boolean isChunked() {
        return this.httpEntity.isChunked();
    }

    public boolean isRepeatable() {
        return this.httpEntity.isRepeatable();
    }

    public boolean isStreaming() {
        return this.httpEntity.isStreaming();
    }

    public void writeTo(OutputStream outputStream) throws IOException {
        this.httpEntity.writeTo(outputStream);
    }
}
