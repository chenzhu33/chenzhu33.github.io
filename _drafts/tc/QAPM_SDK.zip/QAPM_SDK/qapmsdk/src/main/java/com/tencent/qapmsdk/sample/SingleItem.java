package com.tencent.qapmsdk.sample;

public class SingleItem {
    public double eventTime = Double.NaN;
    public double costTime = Double.NaN;
    public String stage = "";
    public String stack = "";
    public String extraData = "";
}
