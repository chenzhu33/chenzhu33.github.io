package com.tencent.qapmsdk.sample;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.AppInfo;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.SysConf;
import com.tencent.qapmsdk.common.ThreadManager;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.impl.appstate.QAPMMonitorThreadLocal;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTraceUnit;
import com.tencent.qapmsdk.impl.instrumentation.TraceType;
import com.tencent.qapmsdk.io.FileIOMonitor;
import com.tencent.qapmsdk.io.util.NativeMethodHook;

import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by nickyliu on 2017/11/6.
 */

public class PerfCollector {
    private static final String TAG = ILogUtil.getTAG(PerfCollector.class);
    private static int uid = 0;
    @Nullable
    private volatile static PerfCollector perfCollector = null;
    private final ConcurrentHashMap<String, TagItem> tagInfoCache = new ConcurrentHashMap<>();
    private static long memPageSize = SysConf.getScPageSize(0);
    public static final String APPLAUNCH = "APPLAUNCH";
    public static final String QAPM_APPLAUNCH = "QAPM_APPLAUNCH";
    public static final String RESOURCEMONITOR = "RESOURCEMONITOR";
    @NonNull
    private static NetworkBytesCollector networkBytesCollector = new NetworkBytesCollector();
    @NonNull
    private static StatFileInfoCollector statFileCollector = new StatFileInfoCollector();
    public static int globalMonitorCount = 0;
    public static final int IMMEDIATESIZE = 900;
    public static final int MANUESIZE = 100;
    @NonNull
    public static Vector<PerfItem> immediatePerfItems = new Vector<>(IMMEDIATESIZE);
    @NonNull
    public static Vector<TagItem> manuTagItems = new Vector<>(MANUESIZE);
    @Nullable
    private static volatile PerfItem lastPerfItem = null;
    private static volatile String gStage = "";
    private static volatile String gExtraInfo = "";

    public static final int OPENRESOUCE = 1;
    public static final int OPENRETAG = 2;
    public static final int OPENAUTO = 7;


    private QAPMMonitorThreadLocal qapmMonitorThreadLocal = QAPMMonitorThreadLocal.getInstance();


    @Nullable
    public static PerfCollector getInstance() {
        if (perfCollector == null) {
            synchronized (PerfCollector.class) {
                if (perfCollector == null) {
                    perfCollector = new PerfCollector();
                }
            }

        }
        return perfCollector;
    }


    @NonNull
    public PerfCollector setPackageInfo(@Nullable Context context) {
        if (context != null){
            Message msg = Message.obtain();
            msg.what = 0;
            msg.obj = context;
            Handler handler = new Handler(ThreadManager.getMonitorThreadLooper(), new Handler.Callback() {
                @Override
                public boolean handleMessage(@NonNull Message msg) {
                    try {
                        Context context =  (Context) msg.obj;
                        ApplicationInfo ai = context.getPackageManager().getApplicationInfo(context.getPackageName(), 0);
                        PerfCollector.uid = ai.uid;
                    } catch (Exception e) {
                        Magnifier.ILOGUTIL.exception(TAG, e);
                    }
                    return false;
                }
            });
            handler.sendMessage(msg);

        }
        return this;
    }

    public void start(String stage, String extraInfo) {
        long startTime = System.currentTimeMillis();
        if (TextUtils.isEmpty(stage) ||
                (!CollectStatus.canCollect(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT) &&
                        !QAPM_APPLAUNCH.equals(stage))) {
            return;
        }
        if (QAPM_APPLAUNCH.equals(stage)){
            qapmMonitorThreadLocal.push(new QAPMTraceUnit(
                stage,
                extraInfo,
                startTime,
                startTime,
                TraceType.CONTEXT.APP.getValue()
            ), Looper.myLooper() == Looper.getMainLooper());
            return;
        }

        String uni_scene = stage + extraInfo;
        TagItem startTagItem = tagInfoCache.get(uni_scene);
        if (startTagItem == null) {
            startTagItem = new TagItem();
        } else {
            return;  //如果已存在就不处理了,跳过。
        }
        startTagItem.eventTime = startTime / 1000.0;
        startTagItem.stage = stage;
        startTagItem.extraInfo = extraInfo;
        startTagItem.tagId = startTime;
        startTagItem.type = TagType.BEGINTAG;
        NetFlow netFlow = perfCollector.collectorNetFollow();
        startTagItem.netFllowRecvBytes = netFlow.rx_bytes;
        startTagItem.netFllowSendBytes = netFlow.tx_bytes;
        if (Long.MAX_VALUE == netFlow.rx_packets || Long.MAX_VALUE == netFlow.tx_packets){
            startTagItem.netFllowPackets = Long.MAX_VALUE;
        }
        else{
            startTagItem.netFllowPackets = netFlow.rx_packets + netFlow.tx_packets;
        }

        if (FileIOMonitor.getInstance().getStartStatus() && NativeMethodHook.iosoLoadSign) {
            long[] ioStatus = FileIOMonitor.getIOStatus();
            if (ioStatus.length == 2) {
                startTagItem.ioCount = ioStatus[0];
                startTagItem.ioBytes = ioStatus[1];
            }
        }
        gStage = stage;
        gExtraInfo = extraInfo;
        tagInfoCache.put(uni_scene, startTagItem);
        manuTagItems.add(startTagItem);
    }

    public void stop(String stage, String extraInfo) {
        long stopTime = System.currentTimeMillis();
        if (gStage.equals(stage)){
            gStage = "";
            if (gExtraInfo.equals(extraInfo)) {
                gExtraInfo = "";
            }
        }

        if (TextUtils.isEmpty(stage) ||
                (!CollectStatus.canCollect(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT) &&
                        !(APPLAUNCH.equals(extraInfo) || QAPM_APPLAUNCH.equals(stage)))) {
            return;
        }

        if (QAPM_APPLAUNCH.equals(stage)){
            qapmMonitorThreadLocal.pop(true);
            return;

        }
        if (APPLAUNCH.equals(extraInfo)) {
            TagItem stopTagItem = new TagItem();
            stopTagItem.duringTime = AppInfo.launchTime();
            stopTagItem.stage = stage;
            stopTagItem.extraInfo = extraInfo;
            stopTagItem.eventTime = stopTime / 1000.0;
            stopTagItem.tagId = stopTime;
            stopTagItem.type = TagType.ENDTAG;
            if (stopTagItem.duringTime > 0){
                manuTagItems.add(stopTagItem);
            }
        } else {
            String uni_stage = stage + extraInfo;
            TagItem startTagItem;

            if (!tagInfoCache.containsKey(uni_stage)) {
                return;
            } else {
                startTagItem = tagInfoCache.get(uni_stage);
            }

            if (startTagItem == null) {
                return;
            }

            TagItem stopTagItem = new TagItem();

            stopTagItem.stage = stage;
            stopTagItem.extraInfo = extraInfo;
            stopTagItem.eventTime = stopTime / 1000.0;
            stopTagItem.duringTime = (stopTagItem.eventTime - startTagItem.eventTime) * 1000;
            stopTagItem.tagId = startTagItem.tagId;
            stopTagItem.type = TagType.ENDTAG;

            if (startTagItem.netFllowSendBytes != Long.MAX_VALUE && startTagItem.netFllowRecvBytes != Long.MAX_VALUE){
                NetFlow netFlow = perfCollector.collectorNetFollow();
                if(Long.MAX_VALUE != netFlow.rx_bytes && Long.MAX_VALUE != netFlow.tx_packets){
                    stopTagItem.netFllowRecvBytes = netFlow.rx_bytes - startTagItem.netFllowRecvBytes;
                    stopTagItem.netFllowSendBytes = netFlow.tx_bytes - startTagItem.netFllowSendBytes;
                }

                if (Long.MAX_VALUE == netFlow.rx_packets || Long.MAX_VALUE == netFlow.tx_packets){
                    stopTagItem.netFllowPackets = Long.MAX_VALUE;
                }
                else{
                    stopTagItem.netFllowPackets = netFlow.rx_packets + netFlow.tx_packets - startTagItem.netFllowPackets;
                }
            }



            if (FileIOMonitor.getInstance().getStartStatus() && NativeMethodHook.iosoLoadSign) {
                long[] ioStatus = FileIOMonitor.getIOStatus();
                if (ioStatus.length == 2) {
                    stopTagItem.ioCount = ioStatus[0] - startTagItem.ioCount;
                    stopTagItem.ioBytes = ioStatus[1] - startTagItem.ioBytes;
                }
            }


            manuTagItems.add(stopTagItem);
            tagInfoCache.remove(uni_stage);

        }
        //手动标签到一定数目时候自动落地
        if (manuTagItems.size() > MANUESIZE){
            Handler h = new Handler(ThreadManager.getMonitorThreadLooper());
            DumpSampleFileRunnable dumpSampleFileRunnable = DumpSampleFileRunnable.getInstance();
            h.post(dumpSampleFileRunnable);
        }
        CollectStatus.addCollectCount(Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
    }

    public void startGlobalMonitor(String processName){
        //后台控制，如果配置为0（默认也为0），那么不开启
        if (globalMonitorCount == 0 && (Config.RES_TYPE & OPENRESOUCE) > 0){
            synchronized (PerfCollector.class){
                if (globalMonitorCount == 0){
                    Magnifier.ILOGUTIL.i(TAG, "SAMPLE: start global monitor to collect resource");
                    Handler h = new Handler(ThreadManager.getMonitorThreadLooper());
                    MonitorRunnable monitorRunnable = MonitorRunnable.getInstance(processName ,true);
                    h.post(monitorRunnable);
                }
                globalMonitorCount++;
            }
        }
    }

    public void stopGlobalMonitor(){
        if (globalMonitorCount > 0){
            synchronized (PerfCollector.class){
                if (globalMonitorCount > 0){
                    if (globalMonitorCount == 1){
                        Magnifier.ILOGUTIL.i(TAG, "SAMPLE: stop global monitor to collect resource");
                        Handler h = new Handler(ThreadManager.getMonitorThreadLooper());
                        MonitorRunnable monitorRunnable = MonitorRunnable.getInstance(null ,false);
                        h.removeCallbacks(monitorRunnable);
                        immediatePerfItems.clear();
                    }
                    globalMonitorCount--;
                }
            }
        }
    }

    @NonNull
    public PerfItem samplePerfValue(@NonNull PerfItem perfItem) {
        perfItem.mStage = gStage;
        perfItem.mExtraInfo = gExtraInfo;
        perfItem.mEventTime = System.currentTimeMillis() / 1000.0;

        StatInfo statInfo = perfCollector.collectStatInfo();
        perfItem.mCpuJiffies = statInfo.cpu_jiffies > 0 ? statInfo.cpu_jiffies : Long.MAX_VALUE;
        perfItem.mCpuSysJiffies = statInfo.cpu_sys_jiffies > 0 ? statInfo.cpu_sys_jiffies : Long.MAX_VALUE;
        perfItem.mCpuSysUsedJiffies = statInfo.cpu_sys_used_jiffies > 0 ? statInfo.cpu_sys_used_jiffies : Long.MAX_VALUE;
        perfItem.mMemory = memPageSize != 0 && statInfo.memory != Long.MAX_VALUE ? statInfo.memory * memPageSize : Long.MAX_VALUE;
        perfItem.mThread = statInfo.thread_num;
        perfItem.mTemperature = BatteryChangedReceiver.temperature;
        //perfItem.mCpuFrequency = perfCollector.collectCpuFrequency();

        if (lastPerfItem != null && perfItem.mEventTime - lastPerfItem.mEventTime < 5){
            lastPerfItem.mEventTime = perfItem.mEventTime;

            if (lastPerfItem.mCpuJiffies != Long.MAX_VALUE
                    && lastPerfItem.mCpuSysJiffies != Long.MAX_VALUE
                    && lastPerfItem.mCpuSysUsedJiffies != Long.MAX_VALUE){
                long diffCpuJiffies = perfItem.mCpuJiffies - lastPerfItem.mCpuJiffies;
                long diffSysCpuJiffies = perfItem.mCpuSysJiffies - lastPerfItem.mCpuSysJiffies;
                long diffSysUsedCpuJiffies = perfItem.mCpuSysUsedJiffies - lastPerfItem.mCpuSysUsedJiffies;
                // 除0风险
                if(diffSysCpuJiffies>0){
                    perfItem.mCpuRate = 1.0 * diffCpuJiffies /  diffSysCpuJiffies; //todo:存疑
                    perfItem.mSysCpuRate = 1.0 * diffSysUsedCpuJiffies / diffSysCpuJiffies;
                }

                //计算后小于0，则为0。
                perfItem.mCpuRate = perfItem.mCpuRate > 0 ? perfItem.mCpuRate : 0;
                perfItem.mSysCpuRate = perfItem.mSysCpuRate > 0 ? perfItem.mSysCpuRate : 0;

            }
            else{
                perfItem.mCpuRate = 0;
                perfItem.mSysCpuRate = 0;
            }


            NetFlow netFlow = perfCollector.collectorNetFollow();
            if (Long.MAX_VALUE == lastPerfItem.mNetFllowRecvBytes || Long.MAX_VALUE == lastPerfItem.mNetFllowSendBytes){
                perfItem.mNetFllowRecvBytes = 0;
                perfItem.mNetFllowSendBytes = 0;
            }
            else{
                perfItem.mNetFllowRecvBytes = netFlow.rx_bytes - lastPerfItem.mNetFllowRecvBytes;
                perfItem.mNetFllowSendBytes = netFlow.tx_bytes - lastPerfItem.mNetFllowSendBytes;

                //保证大于等于0
                perfItem.mNetFllowRecvBytes = perfItem.mNetFllowRecvBytes > 0 ? perfItem.mNetFllowRecvBytes : 0;
                perfItem.mNetFllowSendBytes = perfItem.mNetFllowSendBytes > 0 ? perfItem.mNetFllowSendBytes : 0;
            }

            if (Long.MAX_VALUE == netFlow.rx_packets || Long.MAX_VALUE == netFlow.tx_packets){
                perfItem.mNetFllowPackets = 0;
            }
            else{
                perfItem.mNetFllowPackets = netFlow.rx_packets + netFlow.tx_packets - lastPerfItem.mNetFllowPackets;
                perfItem.mNetFllowPackets = perfItem.mNetFllowPackets > 0 ? perfItem.mNetFllowPackets : 0;
                lastPerfItem.mNetFllowPackets = netFlow.rx_packets + netFlow.tx_packets;
            }



            // 没加载未置空
            if (FileIOMonitor.getInstance().getStartStatus() && NativeMethodHook.iosoLoadSign) {
                long[] ioStatus = FileIOMonitor.getIOStatus();
                if (ioStatus.length == 2) {
                    perfItem.mIOCount = ioStatus[0] - lastPerfItem.mIOCount;
                    perfItem.mIOBytes = ioStatus[1] - lastPerfItem.mIOBytes;
                    perfItem.mIOCount = perfItem.mIOCount > 0 ? perfItem.mIOCount : 0;
                    perfItem.mIOBytes = perfItem.mIOBytes > 0 ? perfItem.mIOBytes : 0;
                    lastPerfItem.mIOCount = ioStatus[0];
                    lastPerfItem.mIOBytes = ioStatus[1];
                }
            }


            lastPerfItem.mCpuJiffies = perfItem.mCpuJiffies;
            lastPerfItem.mCpuSysJiffies = perfItem.mCpuSysJiffies;
            lastPerfItem.mCpuSysUsedJiffies = perfItem.mCpuSysUsedJiffies;

            lastPerfItem.mNetFllowRecvBytes = netFlow.rx_bytes;
            lastPerfItem.mNetFllowSendBytes = netFlow.tx_bytes;


        }
        else{
            lastPerfItem = new PerfItem();
            lastPerfItem.mEventTime = perfItem.mEventTime;
            lastPerfItem.mCpuJiffies = perfItem.mCpuJiffies;
            lastPerfItem.mCpuSysJiffies = perfItem.mCpuSysJiffies;
            lastPerfItem.mCpuSysUsedJiffies = perfItem.mCpuSysUsedJiffies;
            lastPerfItem.mIOCount = 0;
            lastPerfItem.mIOBytes = 0;

            perfItem.mCpuRate = 0;
            perfItem.mSysCpuRate = 0;
            perfItem.mNetFllowPackets = 0;
            perfItem.mNetFllowRecvBytes = 0;
            perfItem.mNetFllowSendBytes = 0;
            perfItem.mIOCount = 0;
            perfItem.mIOBytes = 0;
        }
        //perfItem.mGC = perfCollector.collectorGC(isStart);

        return perfItem;
    }

    private long collectorCpuJiffices(long cpuIdeJiffices, long cpuUseJiffices) {
        long curPidCpuJiffices = cpuIdeJiffices + cpuUseJiffices;
        if (curPidCpuJiffices < 0) {
            return Long.MAX_VALUE;
        }
        return curPidCpuJiffices;
    }

    private long collectorSysCpuJiffices(String[] statInfo) {
        long curSysCpuJiffices = Long.parseLong(statInfo[2]) + Long.parseLong(statInfo[3]) + Long.parseLong(statInfo[4])
                + Long.parseLong(statInfo[5]) + Long.parseLong(statInfo[6]) + Long.parseLong(statInfo[7]) + Long.parseLong(statInfo[8]);
        if (curSysCpuJiffices < 0) {
            return Long.MAX_VALUE;
        }
        return curSysCpuJiffices;
    }

    @NonNull
    private NetFlow collectorNetFollow() {
        NetFlow netFlow = new NetFlow();
        if (uid == 0) {
            return netFlow;
        }

        try {

            long[] netBytes = networkBytesCollector.getTotalBytes();
            if (netBytes != null){
                netFlow.rx_bytes = netBytes[0];
                netFlow.rx_packets = netBytes[1];
                netFlow.tx_bytes = netBytes[2];
                netFlow.tx_packets = netBytes[3];
            }

        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
        return netFlow;
    }

    @NonNull
    private StatInfo collectStatInfo() {
        StatInfo statInfo = new StatInfo();
        try {

            long[] statBytes = statFileCollector.getStatInfo();
            if (statBytes != null){
                statInfo.cpu_sys_jiffies = statBytes[0];
                statInfo.cpu_sys_used_jiffies = statBytes[1];
                statInfo.cpu_jiffies = statBytes[2];
                statInfo.thread_num = statBytes[3];
                statInfo.memory = statBytes[4];
            }

        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
        return statInfo;
    }


//    @SuppressWarnings("deprecation")
//    private long collectorGC(boolean isBegin) {
//        long GCcount;
//        if (!isBegin && this.beginGCCount <= 0) {
//            return Long.MAX_VALUE;
//        }
//        if (isBegin && this.beginGCCount > 0) {
//            this.beginGCCount++;
//        }
//        if (isBegin && this.beginGCCount == 0) {
//            Debug.startAllocCounting();
//            Debug.resetAllCounts();
//            this.beginGCCount++;
//        }
//        if (!isBegin) {
//            this.beginGCCount--;
//            if (this.beginGCCount == 0) {
//                Debug.stopAllocCounting();
//            }
//        }
//        GCcount = Debug.getGlobalGcInvocationCount();
//        return GCcount;
//    }
//
//
//    private HashMap<String, Long> collectCpuFrequency() {
//        int cpuCore = DeviceInfo.getNumCores();
//        if (cpuFrequencyReader == null) {
//            cpuFrequencyReader = new ProcFileReader[cpuCore];
//        }
//        HashMap<String, Long> frequencyMap = new HashMap<>();
//        for(int core = 0; core < cpuCore; core++){
//            if (cpuFrequencyReader[core] == null) {
//                sb.delete(0, sb.length());
//                sb.append("/sys/devices/system/cpu/").append("cpu").append(core).append("/cpufreq/stats/time_in_state");
//                cpuFrequencyReader[core] = new ProcFileReader(sb.toString()).start();
//            } else {
//                cpuFrequencyReader[core].reset();
//            }
//
//            // A failure is mostly expected because files become inaccessible in case of
//            // the core being taken offline.
//            if (!cpuFrequencyReader[core].isValid()) {
//                continue;
//            }
//
//            try {
//                while (cpuFrequencyReader[core].hasNext()) {
//                    long lfrequency = cpuFrequencyReader[core].readNumber();
//                    if (!cpuFrequency.containsKey(lfrequency)){
//                        cpuFrequency.put(lfrequency, String.valueOf(lfrequency));
//                    }
//                    String sfrequency = cpuFrequency.get(lfrequency);
//                    cpuFrequencyReader[core].skipPast(' ');
//                    long frequencyTickTime = cpuFrequencyReader[core].readNumber();
//                    cpuFrequencyReader[core].skipPast('\n');
//                    if (frequencyMap.containsKey(sfrequency)){
//                        frequencyMap.put(sfrequency, frequencyTickTime + frequencyMap.get(sfrequency));
//                    }
//                    else{
//                        frequencyMap.put(sfrequency, frequencyTickTime);
//                    }
//
//                }
//            } catch (ProcFileReader.ParseException pe) {
//                return null;
//            }
//        }
//        return frequencyMap;
//    }


    private class NetFlow {
        private long rx_bytes = Long.MAX_VALUE;
        private long rx_packets = Long.MAX_VALUE;
        private long tx_bytes = Long.MAX_VALUE;
        private long tx_packets = Long.MAX_VALUE;
    }

    private class StatInfo {
        private long cpu_sys_jiffies = Long.MAX_VALUE;
        private long cpu_sys_used_jiffies = Long.MAX_VALUE;
        private long cpu_jiffies = Long.MAX_VALUE;
        private long thread_num = Long.MAX_VALUE;
        private long memory = Long.MAX_VALUE;
    }

//    private class ProcFileReader {
//
//        private final String mPath;
//        private final byte[] mBuffer;
//        private RandomAccessFile mFile;
//
//        private int mPosition = -1;
//        private int mBufferSize;
//
//        private char mChar;
//        private char mPrev;
//
//        private boolean mIsValid = true;
//        private boolean mRewound = false;
//
//        private ProcFileReader(String path) {
//            this(path, 512);
//        }
//
//        private ProcFileReader(String path, int bufferSize) {
//            mPath = path;
//            mBuffer = new byte[bufferSize];
//        }
//
//        public ProcFileReader start() {
//            return reset();
//        }
//
//        private ProcFileReader reset() {
//            // Be optimistic
//            mIsValid = true;
//
//            // First, try to move the pointer if a file exists
//            if (mFile != null) {
//                try {
//                    mFile.seek(0);
//                } catch (IOException ioe) {
//                    close();
//                }
//            }
//
//            // Otherwise try to open/reopen the file and fail
//            if (mFile == null) {
//                try {
//                    mFile = new RandomAccessFile(mPath, "r");
//                } catch (IOException ioe) {
//                    mIsValid = false;
//                    close();
//                }
//            }
//
//            if (mIsValid) {
//                mPosition = -1;
//                mBufferSize = 0;
//
//                mChar = 0;
//                mPrev = 0;
//
//                mRewound = false;
//            }
//
//            return this;
//        }
//
//        public boolean isValid() {
//            return mIsValid;
//        }
//
//        private boolean hasNext() {
//            if (!mIsValid || mFile == null || mPosition > mBufferSize - 1) {
//                return false;
//            }
//
//            if (mPosition < mBufferSize - 1) {
//                return true;
//            }
//
//            try {
//                mBufferSize = mFile.read(mBuffer);
//                mPosition = -1;
//            } catch (IOException ioe) {
//                mIsValid = false;
//                close();
//            }
//
//            return hasNext();
//        }
//
//
//        private void next() {
//            if (!hasNext()) {
//                throw new NoSuchElementException();
//            }
//
//            mPosition++;
//            mPrev = mChar;
//            mChar = (char) mBuffer[mPosition];
//
//            mRewound = false;
//        }
//
//        private void rewind() {
//            if (mRewound) {
//                throw new ParseException("Can only rewind one step!");
//            }
//
//            mPosition--;
//            mChar = mPrev;
//            mRewound = true;
//        }
//
//        private long readNumber() {
//            long result = 0;
//            boolean isFirstRun = true;
//
//            while (hasNext()) {
//                next();
//                if (Character.isDigit(mChar)) {
//                    result = result * 10 + (mChar - '0');
//                } else if (isFirstRun) {
//                    throw new ParseException("Couldn't read number!");
//                } else {
//                    rewind();
//                    break;
//                }
//
//                isFirstRun = false;
//            }
//
//            return result;
//        }
//
//
//        private void skipPast(char skipPast) {
//            boolean found = false;
//            while (hasNext()) {
//                next();
//
//                if (mChar == skipPast) {
//                    found = true;
//                } else if (found) {
//                    rewind();
//                    break;
//                }
//            }
//        }
//
//        public void close() {
//            if (mFile != null) {
//                try {
//                    mFile.close();
//                } catch (IOException ioe) {
//                    // Ignored
//                } finally {
//                    mFile = null;
//                }
//            }
//        }
//
//        private class ParseException extends RuntimeException {
//
//            private ParseException(String message) {
//                super(message);
//            }
//        }
//
//
//    }
}



