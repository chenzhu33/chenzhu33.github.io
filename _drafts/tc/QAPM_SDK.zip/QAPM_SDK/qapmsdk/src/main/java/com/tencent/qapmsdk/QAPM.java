package com.tencent.qapmsdk;

import android.app.Application;
import android.support.annotation.IntDef;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.config.ApmConst;
import com.tencent.qapmsdk.dropframe.DropFrameMonitor;
import com.tencent.qapmsdk.memory.LeakInspector;
import com.tencent.qapmsdk.memory.MemoryMonitor;
import com.tencent.qapmsdk.sample.PerfCollector;
import com.tencent.qapmsdk.webview.WebViewBreadCrumb;

import java.io.File;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by nickyliu on 2018/1/17.
 */

public class QAPM {
    private static final String TAG = "QAPM_QAPM";
    @NonNull
    private static QAPM apm = new QAPM();
    private static int userMode = ApmConst.ModeStable;

    public static final int PropertyKeyAppId = 101, PropertyKeyUserId = 102, PropertyKeyAppVersion = 103, PropertyKeySymbolId = 104, PropertyKeyLogLevel = 105,
            PropertyKeyHost = 106, PropertyKeyConfig = 107, PropertyKeyEventCon = 108, PropertyInspectorListener = 109, PropertyMemoryCellingListener = 110,
            PropertyKeyDeviceId = 111, PropertyWebViewBreadCrumbListener = 112;
    @IntDef({PropertyKeyAppId, PropertyKeyUserId, PropertyKeyAppVersion, PropertyKeySymbolId, PropertyKeyLogLevel, PropertyKeyHost, PropertyKeyConfig, PropertyKeyEventCon, PropertyKeyDeviceId})
    @Retention(RetentionPolicy.SOURCE)
    public @interface PropertyKeyStringValue {}
    @NonNull
    public static QAPM setProperty(@PropertyKeyStringValue int key, @NonNull String value) {
        if (!TextUtils.isEmpty(value)) {
            switch (key) {
                case PropertyKeySymbolId:
                    String regex = "^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$";
                    Matcher m = Pattern.compile(regex).matcher(value);
                    if (m.find()) {
                        Magnifier.info.uuid = value;
                    }
                    break;
                case PropertyKeyUserId:
                    if (Magnifier.QAPM_SP != null && "10000".equals(Magnifier.info.uin)) {
                        Magnifier.info.uin = Magnifier.QAPM_SP.getString(Magnifier.KEY_CONFIG_UIN, "10000");
                    }
                    if (!value.equals(Magnifier.info.uin)) {
                        Magnifier.info.uin = value;
                        if (Magnifier.editor != null) {
                            Magnifier.editor.putString(Magnifier.KEY_CONFIG_UIN, value).apply();
                        }
                        Magnifier.init(userMode, true);
                    }
                    break;
                case PropertyKeyHost:
                    Magnifier.info.host = value;
                    break;
                case PropertyKeyLogLevel:
                    try {
                        ILogUtil.setLogLevel(Integer.parseInt(value));
                    } catch (Throwable t) {
                        Magnifier.ILOGUTIL.exception(TAG, t);
                    }
                    break;
                case PropertyKeyAppId:
                    Magnifier.info.appId = value;
                    break;
                case PropertyKeyAppVersion:
                    Magnifier.info.version = value;
                    break;
                case PropertyKeyEventCon:
                    try {
                        Magnifier.isEventCon = Boolean.parseBoolean(value);
//                        if(Magnifier.isEventCon){
//                            EventCon.getInstance().setFunctionFlag(FunctionFlag.QAPM , true);
//                        }
                    } catch (Throwable t) {
                        Magnifier.ILOGUTIL.exception(TAG, t);
                    }
                    break;
                case PropertyKeyDeviceId:
                    Magnifier.info.deviceId = value;
                    break;
                default:
                    break;
            }
        }
        return apm;
    }

    public static final int PropertyKeyAppInstance = 201;
    @IntDef(PropertyKeyAppInstance)
    @Retention(RetentionPolicy.SOURCE)
    public @interface PropertyKeyObjectValue {}
    @NonNull
    public static QAPM setProperty(@PropertyKeyObjectValue int key, @Nullable Object value) {
        if (null != value) {
            switch (key) {
                case PropertyKeyAppInstance:
                    Magnifier.sApp = (Application)value;
                    if (!"android.app.Application".equals(value.getClass().getName())) {
                        Magnifier.ILOGUTIL.w(TAG, "AppInstance is not android.app.Application.");
                    }
                    break;
                case PropertyKeyLogLevel:
                    try {
                        ILogUtil.getInstance((int)value);
                        ILogUtil.setLogLevel((int)value);
                    } catch (Throwable t) {
                        Magnifier.ILOGUTIL.exception(TAG, t);
                    }
                    break;
                case PropertyKeyEventCon:
                    try {
                        Magnifier.isEventCon = (Boolean)value;
//                        if(Magnifier.isEventCon){
//                            EventCon.getInstance().setFunctionFlag(FunctionFlag.QAPM , true);
//                        }

                    }catch (Throwable t){
                        Magnifier.ILOGUTIL.exception(TAG, t);
                    }
                    break;
                case PropertyInspectorListener:
                    try {
                        Magnifier.info.iListener = (LeakInspector.InspectorListener) value;
                        break;
                    }catch (Throwable t){
                        Magnifier.ILOGUTIL.exception(TAG, t);
                    }
                case PropertyMemoryCellingListener:
                    try {
                        Magnifier.info.mcListener = (MemoryMonitor.MemoryCellingListener) value;
                    }catch (Throwable t){
                        Magnifier.ILOGUTIL.exception(TAG, t);
                    }
                    break;
                case PropertyWebViewBreadCrumbListener:
                    try {
                        Magnifier.info.wbListener = (WebViewBreadCrumb.WebViewBreadCrumbListener) value;
                    }
                    catch (Throwable t){
                        Magnifier.ILOGUTIL.exception(TAG, t);
                    }
                    break;
                default:
                    break;
            }
        }
        return apm;
    }

    public static final String SCENE_ALL = "SCENE_ALL";
    public static final int
            ModeLeakInspector = ApmConst.ModeLeakInspector,
            ModeFileIO = ApmConst.ModeFileIO,
            ModeDBIO = ApmConst.ModeDBIO,
            ModeLooper = ApmConst.ModeLooper,
            ModeCeiling = ApmConst.ModeCeiling,
            ModeBattery = ApmConst.ModeBattery,
            ModeResource = ApmConst.ModeResource,
            ModeDropFrame = ApmConst.ModeDropFrame,
            ModeANR = ApmConst.ModeANR,
            ModeCrash = ApmConst.ModeCrash,
            ModeWebView = ApmConst.ModeWebView,
            ModeHTTP = ApmConst.ModeHTTP,
            ModeAll = ApmConst.ModeAll,
            ModeStable = ApmConst.ModeStable;

    public static final int
            LevelOff = ApmConst.LevelOff,
            LevelError = ApmConst.LevelError,
            LevelWarn = ApmConst.LevelWarn,
            LevelInfo = ApmConst.LevelInfo,
            LevelDebug = ApmConst.LevelDebug,
            LevelVerbos = ApmConst.LevelVerbos;


    public static boolean beginScene(String sceneName, int mode) {
        return beginScene(sceneName, "", mode);
    }

    public static boolean beginScene(String sceneName, @Nullable String extraInfo, int mode) {
        if (extraInfo == null){
            extraInfo = "";
        }

        switch (mode) {
            case ModeResource:
                if (PerfCollector.APPLAUNCH.equals(extraInfo)){
                    return true;
                }
                if (PerfCollector.RESOURCEMONITOR.equals(extraInfo)){
                    if (Magnifier.sApp != null){
                        PerfCollector.getInstance().startGlobalMonitor(PhoneUtil.getProcessName(Magnifier.sApp));
                    }
                    else{
                        PerfCollector.getInstance().startGlobalMonitor("default");
                    }

                    return true;
                }
                PerfCollector.getInstance().start(sceneName, extraInfo);
                break;
            case ModeDropFrame:
                if (PerfCollector.RESOURCEMONITOR.equals(extraInfo)){
                    PerfCollector.getInstance().stopGlobalMonitor();
                    return true;
                }
                DropFrameMonitor.getInstance().start(sceneName);
                break;
            default:
                userMode = mode;
                Magnifier.init(mode ,false);
                break;
        }
        return true;
    }

    public static boolean endScene(String sceneName, int mode) {
        return endScene(sceneName, "", mode);
    }

    public static boolean endScene(String sceneName, @Nullable String extraInfo, int mode) {
        if (extraInfo == null){
            extraInfo = "";
        }
        switch (mode) {
            case ModeResource:
                if (PerfCollector.RESOURCEMONITOR.equals(extraInfo)){
                    PerfCollector.getInstance().stopGlobalMonitor();
                    return true;
                }
                PerfCollector.getInstance().stop(sceneName, extraInfo);
                break;
            case ModeDropFrame:
                DropFrameMonitor.getInstance().stop();
                break;
            default:
                userMode = mode;
                Magnifier.init(mode ,false);
                break;
        }
        return true;
    }
}