package com.tencent.qapmsdk.dns.policy;

import android.os.SystemClock;
import android.support.annotation.NonNull;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.dns.logic.DnsCacheManager;
import com.tencent.qapmsdk.dns.logic.LocalDnsManager;
import com.tencent.qapmsdk.dns.model.DnsCacheObj;
import com.tencent.qapmsdk.dns.model.IpCachedItem;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;


/**
 * Created by nicorao on 2017/11/24.
 */

public abstract class IpPolicy {

    private static final String TAG = "QAM_DNS_IpPolicy";

    public static final IpPolicy EMPTY = new IpPolicyDefault();
    public static final IpPolicy RANDOM = new IpPolicyRandom();
    public static final IpPolicy PRIORITY = new IpPolicyPriority();

    private static IpPolicy sPolicy = RANDOM;

    @NonNull
    public static IpPolicy getPolicy() {
        return sPolicy;
    }

    public static void setIpPolicy(IpPolicy policy) {
        if (policy == null) policy = EMPTY;
        sPolicy = policy;
    }

    public abstract List<String> sort(String host, List<String> ipList);

    private static class IpPolicyDefault extends IpPolicy {

        @Override
        public List<String> sort(String host, List<String> ipList) {
            return ipList;
        }
    }

    private static class IpPolicyRandom extends IpPolicy {

        @Override
        public List<String> sort(String host, List<String> ipList) {
            if (ipList == null || ipList.size() == 0) return ipList;
            int index = new Random().nextInt(ipList.size());
            List<String> sorted = new ArrayList<>();
            // 随机选一个放在最前面，很多网络请求框架只（或优先）选第一个
            sorted.add(ipList.get(index));
            for (int i = 0; i < ipList.size(); i++) {
                if (i == index) {
                    continue;
                }
                sorted.add(ipList.get(i));
            }
            return sorted;
        }
    }

    private static class IpPolicyPriority extends IpPolicy {

        private static final int[] SPEED_SECTION = {50, 150, 250, 350, 450, 550};

        @Override
        public List<String> sort(String host, List<String> ipList) {
            // 本地dns不走优选逻辑
            List<String> localIpList = LocalDnsManager.getInstance().getIpList(host);
            if (localIpList != null && localIpList.size() > 0) {
                return RANDOM.sort(host, ipList);
            }
            final long start = SystemClock.elapsedRealtime();
            DnsCacheObj obj = DnsCacheManager.getInstance().getDnsCache(host);
            final CopyOnWriteArrayList<IpCachedItem> itemList;
            if (obj == null || (itemList = obj.ipList) == null || itemList.size() == 0) return ipList;
            List<List<IpCachedItem>> sectionList = new ArrayList<>();
            for (int speed : SPEED_SECTION) {
                sectionList.add(new ArrayList<IpCachedItem>());
            }
            IpCachedItem resultItem = null;
            double min = Double.MAX_VALUE;
            for (IpCachedItem item : itemList) {
                int leftBound = 0;
                int rightBound = 0;
                // 遍历时间最小的
                if (item.avgElapse < min) {
                    min = item.avgElapse;
                    resultItem = item;
                }
                for (int i = 0; i < SPEED_SECTION.length; i++) {
                    rightBound = SPEED_SECTION[i];
                    if (item.avgElapse >= leftBound && item.avgElapse < rightBound) {
                        sectionList.get(i).add(item);
                        break;
                    }
                    leftBound += rightBound;
                }
            }
            // 顺序检查list
            for (List<IpCachedItem> list : sectionList) {
                final int size = list.size();
                if (size > 0) {
                    Random random = new Random();
                    int r = random.nextInt(size);
                    resultItem = list.get(r);
                    break;
                }
            }
            if (resultItem != null) {
                // 找出index
                int index = ipList.indexOf(resultItem.ip);
                List<String> sorted = new ArrayList<>();
                sorted.add(resultItem.ip);
                for (int i = 0; i < ipList.size(); i++) {
                    if (i == index) {
                        continue;
                    }
                    sorted.add(ipList.get(i));
                }
                return sorted;
            } else {
                return RANDOM.sort(host, ipList);
            }
        }
    }
}
