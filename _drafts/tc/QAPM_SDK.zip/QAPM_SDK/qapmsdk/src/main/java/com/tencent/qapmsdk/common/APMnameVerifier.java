package com.tencent.qapmsdk.common;

import com.tencent.qapmsdk.Magnifier;

import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

/**
 * Created by nickyliu on 2018/12/21.
 */

public class APMnameVerifier implements HostnameVerifier {

    private static volatile APMnameVerifier instance = null;
    public static APMnameVerifier getInstance(){
        if (instance == null){
            synchronized (APMnameVerifier.class){
                if (instance == null){
                    instance = new APMnameVerifier();
                }
            }
        }
        return instance;
    }

    @Override
    public boolean verify(String hostname,SSLSession session){
        try {
            URL url = new URL(Magnifier.info.host);
            if (hostname.equals(url.getHost())){
                return true;
            }
        }catch (MalformedURLException e){
            return false;
        }
        return false;
    }
}