package com.tencent.qapmsdk.impl.appstate;

import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.impl.instrumentation.QAPMAppInstrumentation;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTraceUnit;
import com.tencent.qapmsdk.impl.instrumentation.TraceType;
import com.tencent.qapmsdk.impl.util.TraceUtil;

public class CommonActivityTrace {


    protected MethodEventListener eventListener = new MethodEventListener();

    public CommonActivityTrace() {
    }

    public void onCreateOrOnRestartEnterMethod(String activityName, String methodName) {
        if (this.canMonitor()) {
            this.eventListener.registerEvent(activityName , Config.S_ACTIVITY_THR, TraceType.CONTEXT.ACTIVITY);
            this.eventListener.enterMethod(new QAPMTraceUnit(activityName + methodName, TraceType.CATEGORY.OTHER.getValue()));
//            this.c(activityName);
        }
    }

    public void onCreateOrOnRestartExitMethod() {
        if (this.canMonitor()) {
            this.eventListener.exitMethod();
        }
    }

    public void onStartEnterMethod(String activityName) {
        if (this.canMonitor()) {
            this.eventListener.enterMethod(new QAPMTraceUnit(activityName + "#onStart", TraceType.CATEGORY.OTHER.getValue()));
        }
    }

    public void onStartExitMethod() {
        if (this.canMonitor()) {
            this.eventListener.exitMethod();
        }
    }


    public void onResumeEnterMethod(String activityName) {
        if (this.canMonitor()) {
            this.eventListener.enterMethod(new QAPMTraceUnit(activityName + "#onResume", TraceType.CATEGORY.OTHER.getValue()));
        }
    }

    public SectionHarve onResumeExitMethod() {
        if (!this.canMonitor()) {
            return null;
        } else {
            this.eventListener.exitMethod();
            SectionHarve sectionHarve = this.eventListener.finishMonitor();
            return sectionHarve;
        }
    }
//
//    protected void c(String var1) {
//        try {
//            Looper.myQueue().addIdleHandler(com.networkbench.agent.impl.b.c.e.a(var1, this.e.a));
//        } catch (Exception var3) {
//            d.a("Looper.myQueue().addIdleHandler(new QAPMActivityIdleHandler(nbsSlowStartEngine))  has an error ", var3);
//        }
//    }

    protected boolean canMonitor() {
        return TraceUtil.canInstrumentMonitor && AppStateTimeInfo.hasStartEnd && !QAPMAppInstrumentation.isAppInBackground;
    }


}
