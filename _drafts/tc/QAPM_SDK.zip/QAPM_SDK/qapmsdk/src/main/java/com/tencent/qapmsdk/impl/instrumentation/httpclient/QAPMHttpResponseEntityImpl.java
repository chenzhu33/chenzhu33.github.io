package com.tencent.qapmsdk.impl.instrumentation.httpclient;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.impl.api.data.TransactionData;
import com.tencent.qapmsdk.impl.instrumentation.QAPMHttpClientUtil;
import com.tencent.qapmsdk.impl.instrumentation.QAPMTransactionState;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMCountingInputStream;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMCountingOutputStream;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMStreamCompleteEvent;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMStreamCompleteListener;
import com.tencent.qapmsdk.impl.instrumentation.io.QAPMStreamCompleteListenerSource;
import com.tencent.qapmsdk.impl.model.HttpDataModel;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.entity.HttpEntityWrapper;
import org.apache.http.message.AbstractHttpMessage;

public class QAPMHttpResponseEntityImpl implements QAPMStreamCompleteListener, HttpEntity {
    private final static String TAG = "QAPM_Impl_QAPMHttpResponseEntityImpl";
    private final HttpEntity impl;
    private final QAPMTransactionState transactionState;
    private final long contentLengthFromHeader;
    private QAPMCountingInputStream contentStream;
    private HttpResponse response;

    public QAPMHttpResponseEntityImpl(HttpResponse response, QAPMTransactionState transactionState, long contentLengthFromHeader) {
        this.response = response;
        this.impl = response.getEntity();
        this.transactionState = transactionState;
        this.contentLengthFromHeader = contentLengthFromHeader;
    }

    public void consumeContent() throws IOException {
        try {
            this.impl.consumeContent();
        } catch (IOException e) {
            QAPMHttpClientUtil.setErrorCodeFromException(this.transactionState, e);
            if (!this.transactionState.isComplete()) {
                TransactionData transactionData = this.transactionState.end();
//                k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
                if (this.transactionState.isError()) {
                    String exceptionInfo = "";
                    if (this.transactionState.getException() != null) {
                        exceptionInfo = this.transactionState.getException();
                    }
                    //todo:整理数据
                    HttpDataModel.collectData(transactionData, exceptionInfo);
                    //h.a(this.transactionState.getUrl(), this.transactionState.getFormattedUrlParams(), this.transactionState.getAllGetRequestParams(), this.transactionState.getStatusCode(), "", exceptionInfo, this.transactionState.getRequestMethodType(), transactionData.h(), transactionData.f(), transactionData.w(), transactionData.l(), transactionData.d());
                }
                else{
                    HttpDataModel.collectData(transactionData);
                }
            }

            throw e;
        }
    }

    public InputStream getContent() throws IOException, IllegalStateException {
        if (this.contentStream != null) {
            return this.contentStream;
        } else {
            try {
                boolean isChunked = true;
                if (this.impl instanceof AbstractHttpMessage) {
                    AbstractHttpMessage httpMessage = (AbstractHttpMessage)this.impl;
                    Header header = httpMessage.getLastHeader("Transfer-Encoding");
                    if (header != null && "chunked".equalsIgnoreCase(header.getValue())) {
                        isChunked = false;
                    }
                } else if (this.impl instanceof HttpEntityWrapper) {
                    isChunked = !this.impl.isChunked();
                }

                this.contentStream = new QAPMCountingInputStream(this.impl.getContent(), isChunked);
                this.contentStream.addStreamCompleteListener(this);
                return this.contentStream;
            } catch (IOException e) {
                QAPMHttpClientUtil.setErrorCodeFromException(this.transactionState, e);
                if (!this.transactionState.isComplete()) {
                    TransactionData transactionData = this.transactionState.end();
                    HttpDataModel.collectData(transactionData, e);
//                    k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
                }

                throw e;
            }
        }
    }

    public Header getContentEncoding() {
        return this.impl.getContentEncoding();
    }

    public long getContentLength() {
        return this.impl.getContentLength();
    }

    public Header getContentType() {
        return this.impl.getContentType();
    }

    public boolean isChunked() {
        return this.impl.isChunked();
    }

    public boolean isRepeatable() {
        return this.impl.isRepeatable();
    }

    public boolean isStreaming() {
        return this.impl.isStreaming();
    }

    public void writeTo(OutputStream outstream) throws IOException {
        if (!this.transactionState.isComplete()) {
            QAPMCountingOutputStream outputStream = new QAPMCountingOutputStream(outstream);

            try {
                this.impl.writeTo(outputStream);
            } catch (IOException e) {
                QAPMHttpClientUtil.setErrorCodeFromException(this.transactionState, e);
                if (!this.transactionState.isComplete()) {
                    this.transactionState.setBytesReceived(outputStream.getCount());
                    TransactionData transactionData = this.transactionState.end();
                    HttpDataModel.collectData(transactionData, e);
//                    k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
                }

                e.printStackTrace();
                throw e;
            }

            if (!this.transactionState.isComplete()) {
                if (this.contentLengthFromHeader >= 0L) {
                    this.transactionState.setBytesReceived(this.contentLengthFromHeader);
                } else {
                    this.transactionState.setBytesReceived(outputStream.getCount());
                }

                this.addTransactionAndErrorData(this.transactionState);
            }
        } else {
            this.impl.writeTo(outstream);
        }

    }

    public void streamComplete(QAPMStreamCompleteEvent e) {
        QAPMStreamCompleteListenerSource source = (QAPMStreamCompleteListenerSource)e.getSource();
        source.removeStreamCompleteListener(this);
        Magnifier.ILOGUTIL.d(TAG, "streamComplete");
        if (!this.transactionState.isComplete()) {
            Magnifier.ILOGUTIL.d(TAG, "transaction not complete");
            if (this.contentLengthFromHeader >= 0L) {
                this.transactionState.setBytesReceived(this.contentLengthFromHeader);
            } else {
                this.transactionState.setBytesReceived(e.getBytes());
            }

            this.addTransactionAndErrorData(this.transactionState);
        }

    }

    public void streamError(QAPMStreamCompleteEvent e) {
        QAPMStreamCompleteListenerSource source = (QAPMStreamCompleteListenerSource)e.getSource();
        source.removeStreamCompleteListener(this);
        QAPMHttpClientUtil.setErrorCodeFromException(this.transactionState, e.getException());
        if (!this.transactionState.isComplete()) {
            this.transactionState.setBytesReceived(e.getBytes());
        }

    }

    private void addTransactionAndErrorData(QAPMTransactionState state) {
        try {
//            QAPMAndroidAgentImpl var2 = QAPMAgent.getImpl();
//            if (var2 == null) {
//                return;
//            }
//
//            HarvestConfiguration var3 = var2.n();
//            if (var3 == null) {
//                return;
//            }

            TransactionData transactionData = state.end();
            if (null == transactionData) {
                Magnifier.ILOGUTIL.d(TAG, "HttpResponseEntityWrapperImpl transactionData is null!");
                return;
            }

//            k.a(transactionData, new com.networkbench.agent.impl.g.b.a(transactionData));
            if (state.isError()) {
                StringBuilder stringBuilder = new StringBuilder();

                try {
                    InputStream inputStream = this.getContent();
                    if (inputStream instanceof QAPMCountingInputStream) {
                        stringBuilder.append(((QAPMCountingInputStream)inputStream).getBufferAsString());
                    }
                } catch (Exception e1) {
                    Magnifier.ILOGUTIL.e(TAG, e1.toString());
                }

                Map responseHeader = QAPMHttpClientUtil.resolvingResponseHeader(this.response);
                responseHeader.put("Content-Length", state.getBytesReceived());
                String exceptionInfo = "";
                if (state.getException() != null) {
                    exceptionInfo = state.getException();
                }

                Magnifier.ILOGUTIL.d(TAG, "error message:" , exceptionInfo);
                //todo:整理数据
                HttpDataModel.collectData(transactionData, exceptionInfo);
                //h.a(transactionData, stringBuilder.toString(), responseHeader, exceptionInfo);
            }
            else{
                HttpDataModel.collectData(transactionData);
            }

        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG,"addTransactionAndErrorData", e);
        }

    }
}
