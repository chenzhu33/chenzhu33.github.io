package com.tencent.qapmsdk.sample;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.FileUtil;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.reporter.IReporter;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.reporter.ResultObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Vector;

/**
 * Created by nickyliu on 2018/10/8.
 */

public class DumpSampleFileRunnable implements Runnable {
    private static final String TAG = ILogUtil.getTAG(DumpSampleFileRunnable.class);
    @Nullable
    private static volatile DumpSampleFileRunnable instance = null;
    private static final String fileTemplateName = "APM_Resource_" + Magnifier.info.appId + "_";
    private static volatile Iterator<File> m_fileIterator = null;
    //限制上报最近的3个文件，避免因为文件过多导致问题
    private static final int MAXREPORTCOUNT = 3;
    @NonNull
    private SimpleDateFormat ft = new SimpleDateFormat("yyyyMMddhhmmss", Locale.CHINA);
    private long lastDumpFileTime = 0;
    @Nullable
    private String processName = null;
    private boolean canReport = false;

    @Nullable
    public static DumpSampleFileRunnable getInstance() {
        if(Magnifier.sApp != null){
            return getInstance(PhoneUtil.getProcessName(Magnifier.sApp));
        }
        else{
            return  getInstance("default");
        }
    }


    @Nullable
    public static DumpSampleFileRunnable getInstance(String processName) {
        if (instance == null){
            synchronized (MonitorRunnable.class){
                if (instance == null){
                    instance = new DumpSampleFileRunnable();
                }
            }
        }
        if (instance.processName == null){
            instance.processName = processName;
        }
        return instance;
    }

    public void setCanReport(boolean canReport){
        this.canReport = canReport;
    }


    @Override
    public void run() {
        //为了避免多个线程触发上报，导致短时间内同时做了两次上报，所以做下判断，如果与上一次落地时间间隔较短，小于5s那么就先不落地
        long curTime = System.currentTimeMillis();
        if (curTime - lastDumpFileTime < 5000){
            return;
        }

        //过了时间限制但是缓存中数据较小就直接返回.
        //todo:这里的逻辑要确认
        if (PerfCollector.manuTagItems.size() < 10 && PerfCollector.immediatePerfItems.size() < 10){
            return;
        }

        lastDumpFileTime = curTime;
        String fileName = fileTemplateName + ft.format(new Date());
        //备份后就将原始的清理了
        Vector<PerfItem> immediatePerfItems = (Vector<PerfItem>) PerfCollector.immediatePerfItems.clone();
        Vector<TagItem> manuTagItems = (Vector<TagItem>) PerfCollector.manuTagItems.clone();
        PerfCollector.immediatePerfItems.clear();
        PerfCollector.manuTagItems.clear();
        JSONObject params = new JSONObject();
        try{
            params.put("p_id", Magnifier.productId);
            params.put("version", Magnifier.info.version);
            params.put("uin", Magnifier.info.uin);
            params.put("manu", Build.MANUFACTURER);
            params.put("device", Build.MODEL);
            params.put("os", Build.VERSION.RELEASE);
            params.put("rdmuuid", Magnifier.info.uuid);
            params.put("plugin",  Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT);
            params.put("sdk_ver", Config.SDK_VERSION);

            if (Magnifier.sApp != null) {
                params.put("deviceid", PhoneUtil.getDeviceId(Magnifier.sApp));
            } else {
                params.put("deviceid", "0");
            }
            params.put("zone", "default");

            JSONArray immediates = new JSONArray();
            JSONArray manuTags = new JSONArray();

            for (PerfItem perfItem : immediatePerfItems){

                if (Double.isNaN(perfItem.mEventTime)){
                    continue;
                }
                JSONObject immediate = new JSONObject();

                immediate.put("event_time", perfItem.mEventTime);
                immediate.put("process_name", processName);
                immediate.put("stage", perfItem.mStage);
                immediate.put("sub_stage", "");
                immediate.put("extra_info", perfItem.mExtraInfo);
                if (Long.MAX_VALUE != perfItem.mCpuJiffies
                        || Long.MAX_VALUE != perfItem.mCpuSysJiffies
                        || Long.MAX_VALUE != perfItem.mThread
                        || !Double.isNaN(perfItem.mCpuRate)
                        || !Double.isNaN(perfItem.mSysCpuRate)) {
                    JSONObject cpuTage = new JSONObject();
                    if (Long.MAX_VALUE != perfItem.mCpuJiffies) {
                        cpuTage.put("app_jiffies", perfItem.mCpuJiffies);
                    }
                    if (Long.MAX_VALUE != perfItem.mCpuSysJiffies) {
                        cpuTage.put("sys_jiffies", perfItem.mCpuSysJiffies);
                    }
                    if (Long.MAX_VALUE != perfItem.mThread) {
                        cpuTage.put("thread_num", perfItem.mThread);
                    }
                    if (!Double.isNaN(perfItem.mCpuRate)){
                        cpuTage.put("cpu_rate", perfItem.mCpuRate);

                    }
                    if (!Double.isNaN(perfItem.mSysCpuRate)){
                        cpuTage.put("sys_cpu_rate", perfItem.mSysCpuRate);

                    }

                    immediate.put("cpu", cpuTage);
                }
                if (Long.MAX_VALUE != perfItem.mMemory || Long.MAX_VALUE != perfItem.mGC) {
                    JSONObject memoryTage = new JSONObject();
                    if (Long.MAX_VALUE != perfItem.mMemory) {
                        memoryTage.put("mem_used", perfItem.mMemory);
                    }
//                        if (Long.MAX_VALUE != perfItem.mGC) {
//                            memoryTage.put("gc_cnt", perfItem.mGC);
//                        }
                    immediate.put("memory", memoryTage);
                }
                if (Long.MAX_VALUE != perfItem.mIOCount || Long.MAX_VALUE != perfItem.mIOBytes) {
                    JSONObject ioTage = new JSONObject();
                    if (Long.MAX_VALUE != perfItem.mIOCount) {
                        ioTage.put("io_cnt", perfItem.mIOCount);
                    }
                    if (Long.MAX_VALUE != perfItem.mIOBytes) {
                        ioTage.put("io_sz", perfItem.mIOBytes);
                    }
                    immediate.put("io", ioTage);
                }
                if (Long.MAX_VALUE != perfItem.mNetFllowPackets ||
                        Long.MAX_VALUE != perfItem.mNetFllowRecvBytes ||
                        Long.MAX_VALUE != perfItem.mNetFllowSendBytes) {
                    JSONObject netTage = new JSONObject();
                    if (Long.MAX_VALUE != perfItem.mNetFllowPackets) {
                        netTage.put("net_packets", perfItem.mNetFllowPackets);
                    }
                    if (Long.MAX_VALUE != perfItem.mNetFllowRecvBytes) {
                        netTage.put("net_recv", perfItem.mNetFllowRecvBytes);
                    }
                    if (Long.MAX_VALUE != perfItem.mNetFllowSendBytes) {
                        netTage.put("net_send", perfItem.mNetFllowSendBytes);
                    }
                    immediate.put("network", netTage);
                }
                if (!Double.isNaN(perfItem.mTemperature) && perfItem.mTemperature > -100) {
                    JSONObject temperatureTage = new JSONObject();
                    temperatureTage.put("temperature", perfItem.mTemperature);
                    immediate.put("extra", temperatureTage);

                }
                immediates.put(immediate);

            }
            params.put("immediates", immediates);


            for (TagItem tagItem : manuTagItems){
                if (Double.isNaN(tagItem.eventTime) || tagItem.tagId == Long.MAX_VALUE){
                    continue;
                }
                JSONObject manuTag = new JSONObject();

                manuTag.put("event_time", tagItem.eventTime);
                manuTag.put("tag_id", tagItem.tagId);
                if (!Double.isNaN(tagItem.duringTime)){
                    manuTag.put("during_time", tagItem.duringTime);
                }
                manuTag.put("type", tagItem.type);
                manuTag.put("stage", tagItem.stage);
                manuTag.put("sub_stage", tagItem.subStage);
                manuTag.put("extra_info", tagItem.extraInfo);
                manuTag.put("process_name", processName);
                manuTag.put("is_slow", tagItem.isSlow ? 1 : 0);
                if (tagItem.type == TagType.ENDTAG){
                    if (Long.MAX_VALUE != tagItem.ioCount || Long.MAX_VALUE != tagItem.ioBytes) {
                        JSONObject ioTage = new JSONObject();
                        if (Long.MAX_VALUE != tagItem.ioCount) {
                            ioTage.put("io_cnt", tagItem.ioCount);
                        }
                        if (Long.MAX_VALUE != tagItem.ioBytes) {
                            ioTage.put("io_sz", tagItem.ioBytes);
                        }
                        manuTag.put("io", ioTage);
                    }
                    if (Long.MAX_VALUE != tagItem.netFllowPackets ||
                            Long.MAX_VALUE != tagItem.netFllowRecvBytes ||
                            Long.MAX_VALUE != tagItem.netFllowSendBytes) {
                        JSONObject netTage = new JSONObject();
                        if (Long.MAX_VALUE != tagItem.netFllowPackets) {
                            netTage.put("net_packets", tagItem.netFllowPackets);
                        }
                        if (Long.MAX_VALUE != tagItem.netFllowRecvBytes) {
                            netTage.put("net_recv", tagItem.netFllowRecvBytes);
                        }
                        if (Long.MAX_VALUE != tagItem.netFllowSendBytes) {
                            netTage.put("net_send", tagItem.netFllowSendBytes);
                        }
                        manuTag.put("network", netTage);
                    }
                }
                manuTags.put(manuTag);
            }
            params.put("manu_tags", manuTags);

            if (canReport){
                ResultObject ro = new ResultObject(0, "sample", true, 1, 1, params, true, false, Magnifier.info.uin);
                ReporterMachine.addResultObj(ro);
                reportDumpFile();
            }
            else {
                flushFile(fileName, params);
            }


        }
        catch (Exception e){
            Magnifier.ILOGUTIL.exception(TAG, e);
        }



    }


    private void flushFile(String fileName, @NonNull JSONObject jsonInfo){
        try{
            BufferedWriter bw = new BufferedWriter(new FileWriter(FileUtil.getRootPath()+"/"+fileName), 8 * 1024);
            try {
                String jsonString = jsonInfo.toString();
                bw.write(jsonString);
            }
            catch (Exception e){
                Magnifier.ILOGUTIL.exception(TAG, e);
            }
            finally {
                if (bw != null) {
                    try {
                        bw.close();
                    } catch (IOException e) {
                        Magnifier.ILOGUTIL.exception(TAG, "fileName: " + fileName, e);
                    }
                }
            }
        }
        catch (Exception e){
            Magnifier.ILOGUTIL.exception(TAG, "fileName: " + fileName, e);
        }

    }

    private void reportDumpFile(){
        ArrayList<File> dumpFiles = FileUtil.getFiles(FileUtil.getRootPath(), "APM_Resource_"+ Magnifier.info.appId +"_.*");
        if (dumpFiles == null  || dumpFiles.size() == 0){
            canReport = false;
            return;
        }
        Collections.sort(dumpFiles, new Comparator<File>() {
            @Override
            public int compare(File lhs, File rhs) {
                return -lhs.getName().compareTo(rhs.getName());
            }
        });

        if (m_fileIterator == null){
            //大于10个文件，则删除老的文件，不做上报了，避免文件积压。
            if (dumpFiles.size() > 10){
                List<File> earlierTenFiles = dumpFiles.subList(10, dumpFiles.size());
                for (File f : earlierTenFiles){
                    f.delete();
                }
            }
            m_fileIterator = dumpFiles.iterator();
            doFileJson(m_fileIterator, MAXREPORTCOUNT);
        }
        canReport = false;

    }

    private void doFileJson(final Iterator<File> fileIterator, final int remainReportCount){
        if (remainReportCount <= 0){
            m_fileIterator = null;
            return;
        }
        if (fileIterator.hasNext()){
            File file = fileIterator.next();
            InputStream is = null;
            BufferedReader br = null;
            try {
                String s;
                is = new FileInputStream(file);
                br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder(16 * 1024);
                while ((s = br.readLine()) != null) {
                    sb.append(s);
                }
                JSONObject jo = new JSONObject(sb.toString());
                ResultObject ro = new ResultObject(0, "sample", true, 1, 1, jo, true, false, Magnifier.info.uin);
                ReporterMachine.addResultObj(ro, new IReporter.ReportResultCallback(){
                    @Override
                    public void onSuccess(int id){
                        doFileJson(fileIterator, remainReportCount - 1);
                    }
                    @Override
                    public void onFailure(int plugin, long uploadtime, int error_code, String error_msg, String http_get){

                    }
                });
            }
            catch (Exception e){
                Magnifier.ILOGUTIL.exception(TAG, "remainReportCount: " + remainReportCount, e);
                doFileJson(fileIterator, remainReportCount);
            }
            finally {
                if (is != null) {
                    try {
                        is.close();
                    } catch (Exception e) {
                        Magnifier.ILOGUTIL.exception(TAG, "remainReportCount: " + remainReportCount, e);
                    }
                }
                if (br != null) {
                    try {
                        br.close();
                    } catch (Exception e) {
                        Magnifier.ILOGUTIL.exception(TAG, "remainReportCount: " + remainReportCount, e);
                    }
                }
                file.delete();

            }
        } else {
            m_fileIterator = null;
        }
    }

}
