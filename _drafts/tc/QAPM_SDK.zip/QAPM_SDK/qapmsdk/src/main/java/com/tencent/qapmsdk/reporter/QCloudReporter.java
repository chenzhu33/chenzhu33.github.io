package com.tencent.qapmsdk.reporter;

import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.Locale;

import org.json.JSONObject;

import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.MD5Util;
import com.tencent.qapmsdk.common.ThreadManager;
import com.tencent.qapmsdk.config.Config;

public class QCloudReporter implements IReporter {
    private static final String TAG = ILogUtil.getTAG(QCloudReporter.class);
    @NonNull
    private static String FILE_URL = String.format(Locale.US, "%s/entrance/%d/uploadFile/", Magnifier.info.host, Magnifier.productId);
    @NonNull
    private static String JSON_URL = String.format(Locale.US, "%s/entrance/%d/uploadJson/", Magnifier.info.host, Magnifier.productId);
    @Nullable
    private Handler mHandler;

    public QCloudReporter () {
        if (null == mHandler) {
            mHandler = new Handler(ThreadManager.getReporterThreadLooper());
        }
    }
    
//    public static void setHost(String h) {
//        FILE_URL = String.format(Locale.US, "https://%s/entrance/%d/uploadFile/", h, Magnifier.productId);
//        JSON_URL = String.format(Locale.US, "https://%s/entrance/%d/uploadJson/", h, Magnifier.productId);
//    }

    @Override
    public boolean report(@NonNull ResultObject ro, ReportResultCallback cb) {
        JSONObject jsonObj = ro.params;
        String filePath = jsonObj.optString(ReporterMachine.PREFIX_KEY_OF_FILE);
        try {
            int plugin = jsonObj.getInt("plugin");
            jsonObj.put("api_ver", 1);
            jsonObj.put("plugin_ver", 1);
            jsonObj.put("sdk_ver", Config.SDK_VERSION);
            //这里直接jsonObj.toString会分配大内存导致oom。但是如何做到上报去重?
            jsonObj.put("client_identify", MD5Util.getMD5(Magnifier.info.uuid + System.currentTimeMillis()));

            StringBuffer sb = new StringBuffer(1024);
            if (!TextUtils.isEmpty(filePath)) { //文件上报
                Iterator<?> ciKeys = jsonObj.keys();
                String key = (String)ciKeys.next();
                String value = jsonObj.getString(key);
                sb.append(key).append("=").append(URLEncoder.encode(value, "UTF-8"));
                while (ciKeys.hasNext()) {
                    key = (String)ciKeys.next();
                    value = jsonObj.getString(key);
                    sb.append("&").append(key).append("=").append(URLEncoder.encode(value, "UTF-8"));
                }
                sb.append("&a=1");
                String spec = FILE_URL + "?" + sb.toString();
                Magnifier.ILOGUTIL.i(TAG, "[qcloud_report] file url: ", spec);
                URL url = new URL(spec);
                QCloudFileUploadRunnable fileUpload = new QCloudFileUploadRunnable(url, filePath, jsonObj, cb, ro.dbId, mHandler);
                mHandler.post(fileUpload);
            } else { //无文件上报，纯json
                sb.append("p_id=").append(Magnifier.productId).append("&plugin=").append(plugin);
                sb.append("&version=").append(URLEncoder.encode(Magnifier.info.version, "UTF-8")).append("&a=1");
                String spec = JSON_URL + "?" + sb.toString();
                Magnifier.ILOGUTIL.i(TAG, "[qcloud_report] json url: ", spec, " jsonObj: ", jsonObj.toString());
                URL url = new URL(spec);
                JsonUploadRunnable jsonUpload = new JsonUploadRunnable(url, jsonObj, cb, ro.dbId, mHandler);
                mHandler.post(jsonUpload);
            }
            return true;
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
            return false;
        }
    }
}