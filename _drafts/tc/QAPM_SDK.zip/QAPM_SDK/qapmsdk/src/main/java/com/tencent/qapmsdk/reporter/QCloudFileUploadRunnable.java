package com.tencent.qapmsdk.reporter;

import android.os.Handler;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.APMnameVerifier;
import com.tencent.qapmsdk.common.Authorization;
import com.tencent.qapmsdk.common.FileUtil;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.NetworkWatcher;
import com.tencent.qapmsdk.common.SSLFactory;
import com.tencent.qapmsdk.reporter.IReporter.ReportResultCallback;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

class QCloudFileUploadRunnable extends BaseUploadRunnable {
    private static final int CHUNK_SIZE = 1024 * 1024;
    private static final String boundary = "27182818284590452353602874713526";
    private static final String contentType = "multipart/form-data;boundary=" + boundary;

    public static final int PROTOCOL_HTTP = 0, PROTOCOL_HTTPS = 1;

    private static final String TAG = ILogUtil.getTAG(QCloudFileUploadRunnable.class);
    @Nullable
    private URL url = null;
    @Nullable
    private JSONObject json = null;
    @Nullable
    private String originalPath = null;
    @Nullable
    private String disposition = null;
    @Nullable
    private String beforeStream = null;
    @Nullable
    private String afterStream = null;
    @Nullable
    private String reqBackup = null;
    @Nullable
    private File currentUploadFile = null;
    @Nullable
    private FileInputStream fStream = null;
    private int remainingRetry = 1;
    @Nullable
    private ReportResultCallback callback = null;
    private int maxCount = -1;
    private int dbId = -1;
    @Nullable
    private Handler mHandler = null;
    private boolean initFlag = false;

    private int protocol = PROTOCOL_HTTPS;    //

    QCloudFileUploadRunnable(final URL u, final String filePath, final JSONObject obj, ReportResultCallback cb, int id, Handler h) {
        url = u;
        originalPath = filePath;
        json = obj;
        callback = cb;
        dbId = id;
        mHandler = h;
    }
    
    private boolean init() {
        String absolutePath;
        File tempFile = new File(originalPath);
        if (tempFile != null && tempFile.isFile()) {
            absolutePath = originalPath;
        } else if (tempFile.isDirectory()) {
            String dir = tempFile.getParent();
            long curTime = System.currentTimeMillis();
            String outputName = "out_" + String.valueOf(curTime) + ".zip";
            String fullPath = dir + "/" + outputName;
            FileUtil.zipFiles(originalPath, fullPath);
            absolutePath = fullPath;
        } else {
            return false;
        }

        protocol = getProtocol(url);

        currentUploadFile = new File(absolutePath);
        StringBuilder sb = new StringBuilder(512);
        sb.append("Content-Disposition: form-data; name=\"uploadedfile\"; filename=\"").append(currentUploadFile.getName()).append("\"");
        disposition = sb.toString();
        sb.delete(0, sb.length());
        sb.append("--").append(boundary).append("\r\n").append(disposition).append("\r\n\r\n");
        beforeStream = sb.toString();
        sb.delete(0, sb.length());
        sb.append("\r\n--").append(boundary).append("\r\n");
        afterStream = sb.toString();
        sb.delete(0, sb.length());
//        sb.append("Content-Disposition: form-data; name=\"_json\"\r\n").append("Content-Type: application/json\r\n\r\n");
        sb.append("Content-Disposition: form-data; name=\"_json\"\r\n\r\n");
        sb.append(json.toString()).append("\r\n--").append(boundary).append("--\r\n");
        reqBackup = sb.toString();
        
        try {
            fStream = new FileInputStream(currentUploadFile);
        } catch (FileNotFoundException e) {
            releaseAll(true);
            return false;
        }
        return true;
    }
    
    private void releaseAll(boolean doDelete) {
        try {
            if (null != fStream) {
                fStream.close();
                fStream = null;
            }
            if (doDelete == true && currentUploadFile != null && currentUploadFile.isFile()) {
                currentUploadFile.delete();
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        }
    }

    @Override
    public void run() {
        if (initFlag == false) {
            initFlag = true;
            if (init() == false) return;
        }
        
        if (fStream == null) {
            Magnifier.ILOGUTIL.e(TAG, "[qcloud_report]: fstream == null");
            releaseAll(false);
            return;
        }

        boolean uploadOK = false;
        HttpURLConnection conn = null;
        DataOutputStream outStream = null;
        long uploadtime = System.currentTimeMillis();
        
        try {
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(ReporterMachine.SOCKET_TIMEOUT_MILLI);
            conn.setReadTimeout(ReporterMachine.SOCKET_TIMEOUT_MILLI);
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setChunkedStreamingMode(CHUNK_SIZE);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", contentType);
            conn.setRequestProperty("Connection", "Keep-Alive");

            if (TextUtils.isEmpty(Magnifier.token) && !Authorization.GetToken(Magnifier.info.appId,true)) {
                return;
            }
            conn.setRequestProperty("Authorize", Magnifier.token);
            if (protocol==PROTOCOL_HTTPS){
                //这里如果返回为空则setSSLSocketFactory会抛异常，会被catch捕获，所以不用判空
                ((HttpsURLConnection)conn).setSSLSocketFactory(SSLFactory.getDefaultSSLSocketFactory());
                ((HttpsURLConnection)conn).setHostnameVerifier(APMnameVerifier.getInstance());
                ((HttpsURLConnection)conn).connect();
            }

            outStream = new DataOutputStream(conn.getOutputStream());
            outStream.writeBytes(beforeStream);
            int bytesAvailable = fStream.available();
            int bufferSize = Math.min(bytesAvailable, CHUNK_SIZE);
            byte[] buffer = new byte[bufferSize];
            int bytesRead = fStream.read(buffer, 0, bufferSize);
            while (bytesRead > 0) {
                try {
                    outStream.write(buffer, 0, bufferSize);
                } catch (OutOfMemoryError e) {
                    Magnifier.ILOGUTIL.exception(TAG, e);
                }
                bytesAvailable = fStream.available();
                bufferSize = Math.min(bytesAvailable, CHUNK_SIZE);
                bytesRead = fStream.read(buffer, 0, bufferSize);
            }
            outStream.writeBytes(afterStream);
            outStream.writeBytes(reqBackup);

            InputStream in = new BufferedInputStream(conn.getInputStream());
            String resp = NetworkWatcher.readStream(in);
            Magnifier.ILOGUTIL.i(TAG, resp);
            uploadOK = isSucceeded(resp);
            if (callback != null) {
                if (uploadOK) {
                    callback.onSuccess(dbId);
                } else if (remainingRetry <= 0) {
                    callback.onFailure(0, uploadtime, ReporterMachine.ERROR_OTHER, resp, url.toString());
                } else;
            }
        } catch (Exception e) {
            Magnifier.ILOGUTIL.exception(TAG, e);
        } catch (OutOfMemoryError e) {
            remainingRetry = 0;
            if (callback != null) {
                callback.onFailure(0, uploadtime, ReporterMachine.ERROR_OOM, "OutOfMemoryError ", url.toString());
            }
        } catch (Throwable t) {
            Magnifier.ILOGUTIL.exception(TAG, t);
            remainingRetry = 0;
        } finally {
            if (outStream != null) {
                try {
                    outStream.close();
                    outStream = null;
                } catch (IOException e) {
                    Magnifier.ILOGUTIL.exception(TAG, e);
                }
            }
        }
        
        if (!uploadOK && remainingRetry > 0) {
            releaseAll(false);
            maxCount = maxCount + 1;
            remainingRetry = remainingRetry - 1;
            mHandler.postDelayed(this, 30 * 60 * 1000);
        } else {
            releaseAll(false);
        }
    }

    @Override
    public boolean isSucceeded(String resp) {
        try {
            // Server traffic overload.
            if (TextUtils.isEmpty(resp)) return true;
            JSONObject result = new JSONObject(resp);
            int status = result.getInt("status");
            if (status == 1000 || status == 1495) {
                return true;
            } else if(status == 1408){
                Authorization.GetToken(Magnifier.info.appId, false);
                return false;
            }else {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }

    private int getProtocol(URL url){
        if(url.getProtocol().equals("http")){
            return PROTOCOL_HTTP;
        }
        return PROTOCOL_HTTPS;
    }
}
