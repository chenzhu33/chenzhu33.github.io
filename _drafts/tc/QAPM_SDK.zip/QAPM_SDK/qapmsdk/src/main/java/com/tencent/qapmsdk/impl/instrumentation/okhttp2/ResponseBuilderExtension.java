package com.tencent.qapmsdk.impl.instrumentation.okhttp2;

import com.squareup.okhttp.Handshake;
import com.squareup.okhttp.Headers;
import com.squareup.okhttp.Protocol;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import com.squareup.okhttp.ResponseBody;
import com.squareup.okhttp.Response.Builder;
import com.tencent.qapmsdk.Magnifier;

import java.io.IOException;
import okio.Buffer;
import okio.BufferedSource;

public class ResponseBuilderExtension extends Builder {
    private final static String TAG = "QAPM_Impl_ResponseBuilderExtension";
    private Builder impl;

    public ResponseBuilderExtension(Builder impl) {
        this.impl = impl;
    }

    public Builder request(Request request) {
        return this.impl.request(request);
    }

    public Builder protocol(Protocol protocol) {
        return this.impl.protocol(protocol);
    }

    public Builder code(int code) {
        return this.impl.code(code);
    }

    public Builder message(String message) {
        return this.impl.message(message);
    }

    public Builder handshake(Handshake handshake) {
        return this.impl.handshake(handshake);
    }

    public Builder header(String name, String value) {
        return this.impl.header(name, value);
    }

    public Builder addHeader(String name, String value) {
        return this.impl.addHeader(name, value);
    }

    public Builder removeHeader(String name) {
        return this.impl.removeHeader(name);
    }

    public Builder headers(Headers headers) {
        return this.impl.headers(headers);
    }

    public Builder body(ResponseBody body) {
        try {
            if (body != null) {
                BufferedSource var2 = body.source();
                boolean var3 = false;
                if (var2 != null) {
                    Buffer var4 = new Buffer();
                    var2.readAll(var4);
                    return this.impl.body(new QAPMPrebufferedResponseBody(body, var4));
                }
            }
        } catch (IOException e1) {
            Magnifier.ILOGUTIL.exception(TAG, "IOException reading from source: ", e1);
        } catch (IllegalStateException e2) {
        }

        return this.impl.body(body);
    }

    public Builder networkResponse(Response networkResponse) {
        return this.impl.networkResponse(networkResponse);
    }

    public Builder cacheResponse(Response cacheResponse) {
        return this.impl.cacheResponse(cacheResponse);
    }

    public Builder priorResponse(Response priorResponse) {
        return this.impl.priorResponse(priorResponse);
    }

    public Response build() {
        return this.impl.build();
    }
}
