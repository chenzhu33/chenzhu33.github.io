package com.tencent.qapmsdk.impl.appstate;

import com.tencent.qapmsdk.impl.instrumentation.QAPMUnit;
import com.tencent.qapmsdk.impl.instrumentation.TraceStack;
import com.tencent.qapmsdk.impl.report.MonitorReport;

import java.util.Vector;

public class QAPMMonitorThreadLocal extends MonitorThreadLocal{
    protected ThreadLocal<Vector<QAPMUnit>> finishedMethodThreadLocal;
    private static QAPMMonitorThreadLocal instance;
    private final int METHODLISTMAX = 20;

    public QAPMMonitorThreadLocal(){
        this.finishedMethodThreadLocal = new ThreadLocal<Vector<QAPMUnit>>();
    }

    public static QAPMMonitorThreadLocal getInstance(){
        if (instance == null){
            synchronized (QAPMMonitorThreadLocal.class){
                if (instance == null){
                    instance = new QAPMMonitorThreadLocal();
                }
            }
        }
        return instance;
    }

    public ThreadLocal<Vector<QAPMUnit>> getFinishedMethodThreadLocal(){
        return finishedMethodThreadLocal;
    }

    public void pop(boolean checkTime){
        if (getFinishMethods() != null)
        {
            if (this.finishedMethodThreadLocal.get().size() < METHODLISTMAX){
                this.finishedMethodThreadLocal.set(getFinishMethods());
            }
            if (getTraceStack() != null && !getTraceStack().isEmpty())
            {
                if (checkTime){
                    getTraceStack().peek().complete();
                }
                getFinishMethods().add(getTraceStack().peek());
            }
        }
        super.pop();
    }

    public void clear(){
        if (this.finishedMethodThreadLocal.get() != null) {
            (this.finishedMethodThreadLocal.get()).clear();
        }
        super.clear();
    }

    private Vector<QAPMUnit> getFinishMethods()
    {
        Vector<QAPMUnit> finishedMethods = (Vector<QAPMUnit>)this.finishedMethodThreadLocal.get();
        if (finishedMethods == null) {
            finishedMethods = new Vector<QAPMUnit>();
        }
        return finishedMethods;
    }

}
