package com.tencent.qapmsdk.impl.report;

import android.os.Build;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.reporter.ResultObject;
import com.tencent.qapmsdk.socket.model.SocketInfo;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;

public class TrafficReportRunnable implements Runnable{
    private static final String TAG = "QAPM_Impl_TrafficReportRunnable";
    @Nullable
    private static volatile TrafficReportRunnable instance = null;
    @Nullable
    private String processName = null;

    @Nullable
    public static TrafficReportRunnable getInstance() {
        if(Magnifier.sApp != null){
            return getInstance(PhoneUtil.getProcessName(Magnifier.sApp));
        }
        else{
            return  getInstance("default");
        }
    }

    @Nullable
    public static TrafficReportRunnable getInstance(String processName) {
        if (instance == null){
            synchronized (TrafficReportRunnable.class){
                if (instance == null){
                    instance = new TrafficReportRunnable();
                }
            }
        }
        if (instance.processName == null){
            instance.processName = processName;
        }
        return instance;
    }

    @Override
    public void run() {
        reportTraffic();
        TrafficMonitorReport.hasReport = false;
    }

    private void reportTraffic(){
        if (!TrafficMonitorReport.getInstance().getHttpQueue().isEmpty() || !TrafficMonitorReport.getInstance().getSocketToQueue().isEmpty()){
            if(!CollectStatus.canCollect(Config.PLUGIN_QCLOUD_HTTP)){
                //两个层的数据都清理下，避免泄漏
                TrafficMonitorReport.getInstance().getSocketToQueue().clear();
                TrafficMonitorReport.getInstance().getSocketToQueue().clear();
                //这里考虑是否需要清理map和停止监控
                return;
            }
            JSONObject params = new JSONObject();
            try{
                params.put("p_id", Magnifier.productId);
                params.put("version", Magnifier.info.version);
                params.put("uin", Magnifier.info.uin);
                params.put("manu", Build.MANUFACTURER);
                params.put("device", Build.MODEL);
                params.put("os", Build.VERSION.RELEASE);
                params.put("rdmuuid", Magnifier.info.uuid);
                params.put("plugin",  Config.PLUGIN_QCLOUD_HTTP);
                params.put("sdk_ver", Config.SDK_VERSION);

                if (Magnifier.sApp != null) {
                    params.put("deviceid", PhoneUtil.getDeviceId(Magnifier.sApp));
                } else {
                    params.put("deviceid", "0");
                }

                JSONArray parts = new JSONArray();

                while (!TrafficMonitorReport.getInstance().getHttpQueue().isEmpty()){
                    SocketInfo socketInfo = TrafficMonitorReport.getInstance().getHttpQueue().poll();
                    if (TextUtils.isEmpty(socketInfo.host) || Config.whiteHttpHosts.contains(socketInfo.host)){
                        continue;
                    }
                    JSONObject httpJsonObject = new JSONObject();
                    httpJsonObject.put("category", "http");
                    httpJsonObject.put("url", socketInfo.url);
                    httpJsonObject.put("host_ip", socketInfo.ip);
                    httpJsonObject.put("http_method", socketInfo.method);
                    httpJsonObject.put("content_type", socketInfo.contentType);
                    httpJsonObject.put("bytes_sent", socketInfo.sendBytes);
                    httpJsonObject.put("bytes_received", socketInfo.receivedBytes);
                    httpJsonObject.put("start_time", socketInfo.startTimeStamp / 1000.0);
                    httpJsonObject.put("duration", socketInfo.duringTime);
                    httpJsonObject.put("ssl", socketInfo.sslTime);
                    httpJsonObject.put("tcp", socketInfo.tcpTime);
                    httpJsonObject.put("apn_type", socketInfo.apnType);
                    httpJsonObject.put("status_code", socketInfo.statusCode);
                    httpJsonObject.put("error_code", socketInfo.errorCode);
                    httpJsonObject.put("dns", socketInfo.dnsTime);
                    parts.put(httpJsonObject);
                }
                while (!TrafficMonitorReport.getInstance().getSocketToQueue().isEmpty()){
                    SocketInfo socketInfo = TrafficMonitorReport.getInstance().getSocketToQueue().poll();
                    if (TextUtils.isEmpty(socketInfo.host) || TextUtils.isEmpty(socketInfo.protocol) || Config.whiteHttpHosts.contains(socketInfo.host)){
                        continue;
                    }
                    JSONObject socketJsonObject = new JSONObject();
                    socketJsonObject.put("category", "socket");
                    socketJsonObject.put("url", socketInfo.protocol + "://" + socketInfo.host + (socketInfo.path == null ? "" : socketInfo.path));
                    socketJsonObject.put("host_ip", socketInfo.ip);
                    socketJsonObject.put("tcp", socketInfo.tcpTime);
                    socketJsonObject.put("apn_type", socketInfo.apnType);
                    socketJsonObject.put("error_code", socketInfo.errorCode);
                    socketJsonObject.put("dns", socketInfo.dnsTime);
                    parts.put(socketJsonObject);
                }
                if (parts.length() == 0){
                    return;
                }
                params.put("parts", parts);
                ResultObject ro = new ResultObject(0, "sample", true, 1, 1, params, true, false, Magnifier.info.uin);
                ReporterMachine.addResultObj(ro);
                CollectStatus.addCollectCount(Config.PLUGIN_QCLOUD_HTTP);
            }
            catch (Exception e){
                Magnifier.ILOGUTIL.exception(TAG, e);
            }
        }
    }
}
