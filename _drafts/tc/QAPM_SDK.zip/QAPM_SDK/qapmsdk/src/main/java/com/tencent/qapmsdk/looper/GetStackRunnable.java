package com.tencent.qapmsdk.looper;

import java.util.ArrayList;

import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.config.CollectStatus;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.ThreadManager;

import android.os.Handler;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

class GetStackRunnable implements Runnable {
    private final static String TAG = ILogUtil.getTAG(GetStackRunnable.class);
    private int CHECK_INTERVAL;
    private final int MAX_TIME_SPAN = 100000;
    private final int TIME_TOLARENCE = 10;
    private int RANDOM_RANGE;
    private ArrayList<String> mStackStorer;
    @NonNull
    private StringBuilder mStringBuilder = new StringBuilder(1024);
    private Thread mWatchingThread;
    private final String[] SYSTEM_STACK_ELEMENT_PREFIX = {"java.", "android.", "com.android.", "dalvik.", "com.google", "libcore.", "sun.", "com.qihoo360.", "com.lbe."};
    private final String WHITE_LIST = "android.support.v4."; // only have one, make it simple
    private final static int maxStackDepth = 100;
    private final static int maxStackLength = 30000;
    private final int WAIT_MORE_BEFORE_STACK = 200;
    @Nullable
    private static Handler h;
    
    GetStackRunnable(Thread t) {
        this.CHECK_INTERVAL = Config.mSampleConfigs.get(Config.PLUGIN_QCLOUD_LOOPER_STACK).threshold;
        int maxStackTimeSpan = 500;
        this.RANDOM_RANGE = maxStackTimeSpan - CHECK_INTERVAL;
        this.RANDOM_RANGE = this.RANDOM_RANGE > 0? this.RANDOM_RANGE: 4 * CHECK_INTERVAL;
        this.mStackStorer = new ArrayList<String>(maxStackDepth);
        mWatchingThread = t;
        h = new Handler(ThreadManager.getStackThreadLooper());
    }
    
    @Override
    public void run() {
        MonitorInfo mi = LooperMonitor.monitorMap.get(mWatchingThread.getName());
        if (mi == null) return;
        if (!CollectStatus.canCollect(Config.PLUGIN_QCLOUD_LOOPER_STACK)) {
            onThreadMonitorEnd(mi);
            return;
        }
        Step1Runnable s1 = new Step1Runnable(h, mi);
        h.postDelayed(s1, CHECK_INTERVAL);
    }
    
    private class Step1Runnable implements Runnable {
        private Handler h;
        private MonitorInfo mi;
        
        public Step1Runnable(Handler handler, MonitorInfo info) {
            h = handler;
            mi = info;
        }

        @Override
        public void run() {
            if (mi.lastStackRequestTime != 0) {
                long requestTimeRef = mi.lastStackRequestTime;
                long waitTime = SystemClock.uptimeMillis() - requestTimeRef - CHECK_INTERVAL;
                if (waitTime > MAX_TIME_SPAN) {
                    h.post(GetStackRunnable.this);
                    return;
                }
                if (waitTime < -TIME_TOLARENCE) {
                    Step2Runnable s2 = new Step2Runnable(h, mi, requestTimeRef);
                    h.postDelayed(s2, -waitTime);
                } else {
                    long span = SystemClock.uptimeMillis() - requestTimeRef;
                    if (span < CHECK_INTERVAL - TIME_TOLARENCE || span > MAX_TIME_SPAN) { // if last stack request is renewed, or reset, cancel the getting.
                        h.post(GetStackRunnable.this);
                        return;
                    }
                    // threshold reached, determine whether report
                    mi.whetherReportThisTime = CollectStatus.whetherSamplingThisTime(Config.PLUGIN_QCLOUD_LOOPER_STACK);
                    Step3Runnable s3 = new Step3Runnable(h, mi, requestTimeRef);
                    h.postDelayed(s3, WAIT_MORE_BEFORE_STACK);
                }
            } else {
                h.post(GetStackRunnable.this);
            }
        }
    }
    
    private class Step2Runnable implements Runnable {
        private Handler h;
        private MonitorInfo mi;
        private long requestTimeRef;
        
        public Step2Runnable(Handler handler, MonitorInfo info, long t) {
            h = handler;
            mi = info;
            requestTimeRef = t;
        }

        @Override
        public void run() {
            long span = SystemClock.uptimeMillis() - requestTimeRef;
            if (span < CHECK_INTERVAL - TIME_TOLARENCE || span > MAX_TIME_SPAN) { // if last stack request is renewed, or reset, cancel the getting.
                h.post(GetStackRunnable.this);
                return;
            }
            // threshold reached, determine whether report
            mi.whetherReportThisTime = CollectStatus.whetherSamplingThisTime(Config.PLUGIN_QCLOUD_LOOPER_STACK);
            Step3Runnable s3 = new Step3Runnable(h, mi, requestTimeRef);
            h.postDelayed(s3, WAIT_MORE_BEFORE_STACK);
        }
    }
    
    private class Step3Runnable implements Runnable {
        private Handler h;
        private MonitorInfo mi;
        private long requestTimeRef;
        
        public Step3Runnable(Handler handler, MonitorInfo info, long t) {
            h = handler;
            mi = info;
            requestTimeRef = t;
        }

        @Override
        public void run() {
            long span = SystemClock.uptimeMillis() - mi.lastStackRequestTime;
            if (requestTimeRef == mi.lastStackRequestTime && span >= CHECK_INTERVAL + WAIT_MORE_BEFORE_STACK - TIME_TOLARENCE && span < MAX_TIME_SPAN) { // 600ms normally
                mi.cacheRealStackTime = System.currentTimeMillis();
                String stack = getStack(true);
                mi.stack = stack;
            }
            mi.lastStackRequestTime = 0;
            h.post(GetStackRunnable.this);
        }
    }

    private String getStack(boolean raw) {
        try {
            mStackStorer.clear();
            StackTraceElement[] stack = mWatchingThread.getStackTrace();
            if (stack == null) {
                return null;
            }
            if (raw) {
                return java.util.Arrays.toString(stack);
            }
            //原理是：扎到最顶部的QQ堆栈簇，然后从底部往上取5个栈帧进行上报。
            boolean metNonSystemElement = false;
            for (int i = 0; i < stack.length; i ++) {
                StackTraceElement e = stack[i];
                String elementStr = e.toString();
                boolean isSystemElement = false;
                for (String prefix : SYSTEM_STACK_ELEMENT_PREFIX) {
                    if (elementStr.startsWith(prefix)) {
                        if (elementStr.startsWith(WHITE_LIST)) {
                            // not system api
                            break;
                        } else {
                            isSystemElement = true;
                            break;
                        }
                    }
                }
                if (isSystemElement) {
                    if (metNonSystemElement) {
                        break;
                    }
                } else {
                    if (!metNonSystemElement) {
                        metNonSystemElement = true;
                    }
                    mStackStorer.add(elementStr);
                }
            }
            if (mStackStorer.size() > 0) {
                mStringBuilder.setLength(0);
                for (int i = mStackStorer.size() - 1; i >= 0 && i > mStackStorer.size() - 1 - maxStackDepth && mStringBuilder.length()<maxStackLength; i --) {
                    mStringBuilder.append(mStackStorer.get(i)).append(",");
                }
                if (mStringBuilder.length() > 0) {
                    return mStringBuilder.toString();
                } else {
                    return null;
                }
            }
        } catch (Throwable t) {
            Magnifier.ILOGUTIL.exception(TAG, t);
        }
        return null;
    }
    
    private void onThreadMonitorEnd(MonitorInfo mi) {
        mi.whetherReportThisTime = false;
        mi.stackGetter = null;
        mi.stackGetterInited = false;
        mi.callback.onMonitorEnd();
    }
}
