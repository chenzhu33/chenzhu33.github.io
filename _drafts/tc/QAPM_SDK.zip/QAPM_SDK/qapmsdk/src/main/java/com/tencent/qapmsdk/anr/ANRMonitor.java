package com.tencent.qapmsdk.anr;

import android.os.Debug;
import android.os.Handler;
import android.os.Looper;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.ThreadManager;
import com.tencent.qapmsdk.common.PhoneUtil;
import java.util.ArrayList;


public class ANRMonitor {
    private final static String TAG = ILogUtil.getTAG(ANRMonitor.class);
    private static final int DEFAULT_ANR_TIMEOUT = 5000;
    private static ArrayList<String> mStackStorer;
    private final static int maxStackDepth = 100;
    private static boolean _ignoreDebugger = true;
    private static final Handler _uiHandler = new Handler(Looper.getMainLooper());


    public interface ANRListener {
        void onAppNotResponding(ANRError error);
    }

    public interface InterruptionListener {
        void onInterrupted(InterruptedException exception);
    }

    private static final ANRListener DEFAULT_ANR_LISTENER = new ANRListener() {
        @Override
        public void onAppNotResponding(ANRError error) {
            throw error;
        }
    };

    private static final InterruptionListener DEFAULT_INTERRUPTION_LISTENER = new InterruptionListener() {
        @Override
        public void onInterrupted(InterruptedException exception) {
            Magnifier.ILOGUTIL.i(TAG, "Interrupted: "+exception.getMessage());
        }
    };

    private static ANRListener _anrListener = DEFAULT_ANR_LISTENER;
    private static InterruptionListener _interruptionListener = DEFAULT_INTERRUPTION_LISTENER;

    //ANR线程tick
    private static int _tick = 0;
    private static final Runnable _ticker = new Runnable() {
        @Override
        public void run() {
            _tick = (_tick + 1) % Integer.MAX_VALUE;
        }
    };


    //ANR线程逻辑
    public static void initANRMonitor() {
        Handler h = new Handler(ThreadManager.getMonitorThreadLooper());
        h.post(new Runnable() {
            @Override
            public void run() {
                int lastTick;
                int lastIgnored = -1;
                Magnifier.ILOGUTIL.i(TAG, "ANRThread already started");
                while (true) {
                    lastTick = _tick;
                    _uiHandler.post(_ticker);
                    //Magnifier.ILOGUTIL.i(TAG, "lastTick = "+lastTick, " Thread Name: "+Thread.currentThread().getName());
                    try {
                        Thread.sleep(DEFAULT_ANR_TIMEOUT);
                    }
                    catch (InterruptedException e) {
                        _interruptionListener.onInterrupted(e);
                    return;
                    }

                    //发生ANR处理逻辑
                    if (_tick == lastTick) {
                        if (!_ignoreDebugger && Debug.isDebuggerConnected()) {
                            if (_tick != lastIgnored)
                                Magnifier.ILOGUTIL.i(TAG,"An ANR was detected but ignored because the debugger is connected (you can prevent this with setIgnoreDebugger(true))\"");
                            lastIgnored = _tick;
                            continue;
                        }
                        ANRError error;
                        error = ANRError.createANR();
                        InsertDB();
                        _anrListener.onAppNotResponding(error);
                        return;
                    }
                }
            }
        });
    }


    //插入数据库
    private static void InsertDB() {
        String stack = getstack();
        //Magnifier.ILOGUTIL.i(TAG, " ,processName : ", PhoneUtil.getProcessName(Magnifier.sApp), " version : ",Magnifier.info.version, " UIN : ",Magnifier.info.uin, " stack : ",stack);
        InsertRunnable ir = new InsertRunnable(Magnifier.info.uin,stack);
        ir.run();
    }


    //获取string stack
    private static String getstack() {
        mStackStorer = new ArrayList<String>(maxStackDepth);
        mStackStorer.clear();
        final Thread mainThread = Looper.getMainLooper().getThread();
        StackTraceElement[] mainStackTrace = mainThread.getStackTrace();
        for (int i = 0; i < mainStackTrace.length; i++) {
            StackTraceElement e = mainStackTrace[i];
            String elementStr = e.toString();
            mStackStorer.add(elementStr);
        }
        return String.valueOf(mStackStorer);
    }


    private static class InsertRunnable implements Runnable {
        private String uin;
        private String item;

        private InsertRunnable(String uin,String item) {
            this.uin = uin;
            this.item = item;
        }

        @Override
        public void run() {
            if (Magnifier.dbHandler != null) {
                Magnifier.dbHandler.insertANRStack(uin,item,PhoneUtil.getProcessName(Magnifier.sApp), Magnifier.productId, Magnifier.info.version);
                Magnifier.ILOGUTIL.i(TAG,"ANRStack already inserted into DB");
            }
        }
    }
}
