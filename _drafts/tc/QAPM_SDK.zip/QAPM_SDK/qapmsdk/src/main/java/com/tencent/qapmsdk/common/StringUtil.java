package com.tencent.qapmsdk.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by nickyliu on 2018/12/6.
 */

public class StringUtil {
    private static final char[] digits = new char[]{
            '0', '1', '2', '3', '4',//
            '5', '6', '7', '8', '9',//
            'a', 'b', 'c', 'd', 'e',//
            'f'};

    public static String bytes2HexStr(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return "";
        }
        char[] buf = new char[2 * bytes.length];
        for (int i = 0; i < bytes.length; i++) {
            byte b = bytes[i];
            buf[2 * i + 1] = digits[b & 0xF];
            b = (byte) (b >>> 4);
            buf[(2 * i)] = digits[b & 0xF];
        }
        return new String(buf);
    }

    public static long parseHex(String valueStr) {
        long result = 1L;
        try {
            result = Long.parseLong(valueStr, 16);
        } catch (Exception e) {
            return 0L;
        }
        return result;
    }

    public static String replaceBlank(String str) {
        String dest = "";
        if (str != null) {
            Pattern p = Pattern.compile("\t|\r|\n");
            Matcher m = p.matcher(str);
            dest = m.replaceAll("");
        }
        return dest;
    }
}
