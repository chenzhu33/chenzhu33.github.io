package com.tencent.qapmsdk.dns.network;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.dns.logic.DnsCacheManager;


public class NetworkHandler {
    
    private static final String TAG = "QAPM_DNS_NetworkHandler";

    private static INetworkHandler sNetworkHandler;
    
    private static long sDelay = 2000; // 默认对网络变化的处理延迟2秒，防止瞬间抖动

    public interface INetworkHandler {
        void onNetworkChanged();
    }
    
    /**
     * 默认网络变化处理策略，当网络状态变化时（如Wifi变成Mobile，或者Wifi的SSID变更），
     * 清理缓存数据，并对缓存的host重新请求IP 
     */
    private static final INetworkHandler DEFAULT_NETWORK_HANDLER = new DefaultNetworkHandler();
    
    public static void setNetworkHandler(INetworkHandler handler, long delay) {
        if (handler == null || delay < 0) Magnifier.ILOGUTIL.w(TAG, "Illegal Argument, handler is null or delay less than 0");
        sNetworkHandler = handler;
        sDelay = delay;
    }
    
    static void notifyNetworkChanged(Context context) {
        if (sNetworkHandler == null) {
            sNetworkHandler = DEFAULT_NETWORK_HANDLER;
        }
        try {
            sNetworkHandler.onNetworkChanged();
        } catch (Throwable e) {
            Magnifier.ILOGUTIL.exception(TAG, "onNetworkChanged handle error!!", e);
        }
    }
    
    // =================================================================================================
    
    private static final class DefaultNetworkHandler implements INetworkHandler {
        
        NetworkUtils.NetworkType mLastNetworkType;
        
        NetworkUtils.NetworkType mLastValidNetworkType;
        
        String mLastSSID;
        
        Handler mHandler;

        DefaultNetworkHandler() {
            HandlerThread thread = new HandlerThread("httpdns_networkchanged");
            thread.start();
            mHandler = new Handler(thread.getLooper());
        }
        
        @Override
        public void onNetworkChanged() {
            // 防止短时间内的网络抖动
            mHandler.removeCallbacks(mNetworkChangedTask);
            mHandler.postDelayed(mNetworkChangedTask, sDelay);
        }
        
        final Runnable mNetworkChangedTask = new Runnable() {
            
            @Override
            public void run() {
                // 当前网络状态
                final NetworkUtils.NetworkType curType = NetworkUtils.getActiveNetworkType();
                // 当前wifi ssid
                String curSSID = NetworkUtils.getWifiSsid();
                boolean connected = curType != NetworkUtils.NetworkType.DISCONNECTED;
                boolean typeChanged = mLastValidNetworkType != null && curType != mLastValidNetworkType;
                boolean wifiChanged = curType == mLastValidNetworkType && curType == NetworkUtils.NetworkType.WIFI
                        && (!NetworkUtils.isValidSSID(curSSID) || !NetworkUtils.isValidSSID(mLastSSID) || !curSSID.equals(mLastSSID));
                // 当前有效网络与上次有效网络不一样（WIFI-->Mobile or WIFI(SSID1)-->WIFI(SSID2)）
                if (connected && typeChanged) {
                    Magnifier.ILOGUTIL.i(TAG, "Network type changed, clear dns cache, curNetwork: " , String.valueOf(curType) , ", lastNetwork: " , String.valueOf(mLastNetworkType)
                            , ", lastValidNetwork: " , String.valueOf(mLastValidNetworkType) , ", curSSID: " , curSSID , ", lastSSID: " , mLastSSID);
                    DnsCacheManager.getInstance().clear();
                }
                // 由于在高版本Android上获取ssid需要授权，在没有授权下，无法准确判断wifi是否切换，
                // 所以这里不清除缓存，但置为失效
                if (connected && wifiChanged) {
                    DnsCacheManager.getInstance().invalidate();
                }
                // 保存网络状态
                mLastNetworkType = curType;
                if (connected) mLastValidNetworkType = curType;
                if (curType == NetworkUtils.NetworkType.WIFI) mLastSSID = curSSID;
            }
        };
    }
}
