package com.tencent.qapmsdk;

import android.app.Activity;
import android.app.Application.ActivityLifecycleCallbacks;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;

import com.tencent.qapmsdk.battery.BatteryStatsImpl;
import com.tencent.qapmsdk.common.DeviceInfo;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.PhoneUtil;
import com.tencent.qapmsdk.common.ThreadManager;
import com.tencent.qapmsdk.config.ApmConst;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.dropframe.DropResultObject;
import com.tencent.qapmsdk.sample.DumpSampleFileRunnable;

import java.lang.ref.WeakReference;
import java.text.DecimalFormat;
import java.util.HashMap;

class SDKLifecycleCallback implements ActivityLifecycleCallbacks {
    static WeakReference<Activity> sWeakActivity;
    static String sActivityName = "";
    private int foregroundCount = 0;
    private int bufferCount = 0;
    @NonNull
    private String TAG = "QAPM_SDKLifecycleCallback";
    private long last_time = 0;
    private long cur_time = 0;

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {

    }

    @Override
    public void onActivityDestroyed(Activity activity) {
        // TODO Auto-generated method stub
    }

    @Override
    public void onActivityPaused(Activity activity) {
    }

    @Override
    public void onActivityResumed(Activity activity) {
        sWeakActivity = new WeakReference<Activity>(activity);
        sActivityName = new String(sWeakActivity.get().getClass().getSimpleName());
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
        // TODO Auto-generated method stub
    }

    @Override
    public void onActivityStarted(Activity activity) {
        if (foregroundCount <= 0) {
            BatteryStatsImpl.getInstance().onAppForeground();
        }
        if (bufferCount < 0) {
            bufferCount++;
        } else {
            foregroundCount++;
        }
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
        if (activity.isChangingConfigurations()) {
            bufferCount--;
        } else {
            foregroundCount--;
            if (foregroundCount <= 0) {
                Magnifier.ILOGUTIL.i(TAG,"App back ground");
                BatteryStatsImpl.getInstance().onAppBackground();
                DeviceInfo.setContext(activity.getApplicationContext());
                Handler handler = new Handler(ThreadManager.getReporterThreadLooper());
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        DeviceInfo.reportDevice();
                    }
                });

                Handler h = new Handler(ThreadManager.getMonitorThreadLooper());
                DumpSampleFileRunnable dumpSampleFileRunnable = DumpSampleFileRunnable.getInstance();
                dumpSampleFileRunnable.setCanReport(true);
                h.post(dumpSampleFileRunnable);

                //开启debug模式且掉帧开关开启了则打印掉帧率数据
                if (ILogUtil.debug && (Config.STARTED_FUNC & ApmConst.ModeDropFrame) > 0 ){
                    cur_time = System.currentTimeMillis();
                    h.post(new Runnable() {
                        @Override
                        public void run() {
                            HashMap<String, DropResultObject> dropFrame = Magnifier.dbHandler.getDropFrame(PhoneUtil.getProcessName(Magnifier.sApp), Magnifier.productId, Magnifier.info.version, last_time, cur_time);
                            for(String scene : dropFrame.keySet()){
                                DropResultObject value = dropFrame.get(scene);
                                double silkyTime = 16.7 * value.dropIntervals[0]
                                        + 16.7 * 1.5 * value.dropIntervals[1]
                                        + 16.7 * 3 * value.dropIntervals[2]
                                        + 16.7 * 6 * value.dropIntervals[3];
                                double dropFrameRate = silkyTime / value.duration * 1000000 * 100.0;
                                Magnifier.ILOGUTIL.d(TAG, "scene:" + scene + " smooth rate:" + String.valueOf(new DecimalFormat("0.00").format(dropFrameRate)) + "%");

                            }
                            last_time = cur_time;
                        }
                    });

                }

            }
        }
    }
}