package com.tencent.qapmsdk.impl.instrumentation;

import android.webkit.JavascriptInterface;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.PhoneUtil;

public class QAPMJavaScriptBridge {
    private String breadCrumbId = "";
    private static volatile QAPMJavaScriptBridge javaScriptBridge;

    public QAPMJavaScriptBridge() {
    }

    public static QAPMJavaScriptBridge getInstance() {
        if (null == javaScriptBridge) {
            synchronized(QAPMJavaScriptBridge.class) {
                if (null == javaScriptBridge) {
                    javaScriptBridge = new QAPMJavaScriptBridge();
                }
            }
        }
        return javaScriptBridge;
    }

    @JavascriptInterface
    public String getUin() {
        return Magnifier.info.uin;
    }

    @JavascriptInterface
    public String getDeviceId() {
        return PhoneUtil.getDeviceId(Magnifier.sApp);
    }

    @JavascriptInterface
    public String getAppkey() {
        return Magnifier.info.appId + "-" +String.valueOf(Magnifier.productId);
    }

    @JavascriptInterface
    public void setBreadCrumbId(String id) {
        breadCrumbId = id;
    }

    public String getBreadCrumbId(){
        return breadCrumbId;
    }

}
