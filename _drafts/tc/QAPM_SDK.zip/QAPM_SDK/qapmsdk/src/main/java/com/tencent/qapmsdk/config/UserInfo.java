package com.tencent.qapmsdk.config;

import android.support.annotation.Nullable;

import com.tencent.qapmsdk.BuildConfig;
import com.tencent.qapmsdk.battery.BatteryLog.BatteryReportListener;
import com.tencent.qapmsdk.memory.LeakInspector.InspectorListener;
import com.tencent.qapmsdk.memory.MemoryMonitor.MemoryCellingListener;
import com.tencent.qapmsdk.webview.WebViewBreadCrumb.WebViewBreadCrumbListener;

/**
 * Created by anthonytan on 2018/2/26.
 */

public class UserInfo {
    public String host = BuildConfig.URL_DOMAIN;
    @Nullable
    public String uin = "10000";
    public String uuid = "0";
    public String appId = "";
    public String version = "";
    public String deviceId = "";
    @Nullable
    public InspectorListener iListener = null;
    @Nullable
    public MemoryCellingListener mcListener = null;
    @Nullable
    public BatteryReportListener brListener = null;
    @Nullable
    public WebViewBreadCrumbListener wbListener = null;
}
