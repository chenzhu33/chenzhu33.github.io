package com.tencent.qapmsdk.sample;

import android.os.Handler;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.common.ThreadManager;

/**
 * Created by nickyliu on 2018/10/8.
 */


public class MonitorRunnable implements Runnable {
    private boolean isRun;
    @Nullable
    private String processName = null;
    @Nullable
    private volatile static MonitorRunnable instance = null;

    private MonitorRunnable(String processName ,boolean isRun) {
        this.processName = processName;
        this.isRun = isRun;
    }

    private MonitorRunnable(boolean isRun) {
        this.isRun = isRun;
    }

    @Nullable
    public static MonitorRunnable getInstance(String processName, boolean isRun) {
        instance = getInstance(isRun);
        instance.setProcessName(processName);
        return instance;
    }

    @Nullable
    public static MonitorRunnable getInstance(boolean isRun) {
        if (instance == null){
            synchronized (MonitorRunnable.class){
                if (instance == null){
                    instance = new MonitorRunnable(isRun);
                }
            }
        }
        instance.setState(isRun);
        return instance;
    }

    private void setState(boolean isRun){
        this.isRun = isRun;
    }

    public void setProcessName(String processName){
        this.processName = processName;
    }

    @Override
    public void run() {
        if (isRun){
            PerfItem perfItem = PerfCollector.getInstance().samplePerfValue(new PerfItem());
            perfItem.mEventTime = System.currentTimeMillis() / 1000.0;
            PerfCollector.immediatePerfItems.add(perfItem);

            Handler h = new Handler(ThreadManager.getMonitorThreadLooper());
            MonitorRunnable monitorRunnable = MonitorRunnable.getInstance(true);
            h.postDelayed(monitorRunnable, 1000);

            if (PerfCollector.immediatePerfItems.size() > PerfCollector.IMMEDIATESIZE){
                DumpSampleFileRunnable dumpSampleFileRunnable = DumpSampleFileRunnable.getInstance();
                h.post(dumpSampleFileRunnable);
            }
        }
    }
}

