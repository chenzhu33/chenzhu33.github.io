package com.tencent.qapmsdk.io.util;

import android.os.Build;
import android.support.annotation.NonNull;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.FileUtil;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.VersionUtils;
/* 
 * 这个类是IO Hook的一个jni交互类
 */
public class NativeMethodHook {
    public static boolean iosoLoadSign = false;
    public static boolean hooksoLoadSign = false;
    @NonNull
    private static String LOG_TAG = ILogUtil.getTAG(NativeMethodHook.class);
    static {
        try {
            iosoLoadSign = FileUtil.loadLibrary("apmioFake");
            //这里存在一个问题,如果只启动io不启动数据库和电量没有启动,那么java hook的so也会加载。
            if(VersionUtils.isHookSupport()){
                if (VersionUtils.isART()) {
                    hooksoLoadSign = FileUtil.loadLibrary("apmart") && iosoLoadSign;
            } else {
                    hooksoLoadSign = FileUtil.loadLibrary("apmdalvik") && JavaMethodHook.initHook() && iosoLoadSign;
                }
            }

        } catch (UnsatisfiedLinkError e) {
            iosoLoadSign = false;
            hooksoLoadSign = false;
            Magnifier.ILOGUTIL.exception(LOG_TAG, e);
        }
    }
  
    private native void doHook(int saveInfoType, String appVersion, int SDKVersion, Object obj);
    private native void saveAllData();
    private native void stop();
    public native static void setDbName(String dbName);
    public native static void writehm();

    public void startHook(int saveInfoType, String appVersion) {
        if (!iosoLoadSign) return;
        try {
            doHook(saveInfoType, appVersion, Build.VERSION.SDK_INT, new ObjectForCallback());
        } catch (UnsatisfiedLinkError e) {
            Magnifier.ILOGUTIL.exception(LOG_TAG, e);
        }
    }

    public void stopHook() {
        stop();
    }
    
    public void saveNativeData() {
        if (!iosoLoadSign) return;
        try {
            saveAllData();
        } catch (UnsatisfiedLinkError e) {
            Magnifier.ILOGUTIL.exception(LOG_TAG, e);
        }
    }
}