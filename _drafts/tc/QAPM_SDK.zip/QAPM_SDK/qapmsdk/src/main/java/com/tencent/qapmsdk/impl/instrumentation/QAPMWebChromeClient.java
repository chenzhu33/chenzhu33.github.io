package com.tencent.qapmsdk.impl.instrumentation;

import android.annotation.TargetApi;
import android.os.Build;
import android.webkit.ValueCallback;
import android.webkit.WebView;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.webview.WebViewX5Proxy;

public class QAPMWebChromeClient {
    private final static String TAG = "QAPM_Impl_QAPMWebChromeClient";
    private static int injectMax = 0;
    public static int progressControl = 15;

    public static void initJSMonitor(WebView view, int newProgress)
    {
        if (Build.VERSION.SDK_INT >= 19) {
            if (newProgress >= progressControl) {
                try {

                    if (!WebViewX5Proxy.getInstance().getWebViewX5MonitorState()) {
                        return;
                    }

                    Magnifier.ILOGUTIL.i(TAG, "webview  initJSMonitor gather  begin !!");
                    if (view.getSettings().getJavaScriptEnabled()) {
                        Magnifier.ILOGUTIL.d(TAG, "javascript has enable!");
                    } else {
                        view.getSettings().setJavaScriptEnabled(true);
                    }

                } catch (Exception var3) {
                }

            }
        }
    }

    @TargetApi(19)
    private static void injectScriptFile(WebView view)
    {

    }
}
