package com.tencent.qapmsdk.io.util;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.io.dexposed.XC_MethodHook;
import com.tencent.qapmsdk.common.ILogUtil;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.HashMap;

public class JavaMethodHook {
    @NonNull
    private static String LOG_TAG = ILogUtil.getTAG(JavaMethodHook.class);
    private static boolean disableHooks = false;

    private static class AdditionalHookInfo {
        private XC_MethodHook callback;
        private final Class<?>[] parameterTypes;
        private final Class<?> returnType;
        
        private AdditionalHookInfo(XC_MethodHook callback, Class<?>[] parameterTypes, Class<?> returnType) {
            this.callback = callback;
            this.parameterTypes = parameterTypes;
            this.returnType = returnType;
        }

//        public void unhook() {
//            callback = null;
//        }
    }
    
    private static final HashMap<String, Field> fieldCache = new HashMap<String, Field>();
    /**
     * Look up a field in a class and set it to accessible. The result is cached.
     * If the field was not found, a {@link NoSuchFieldError} will be thrown.
     */
    private static Field findField(Class<?> clazz, String fieldName) {
        StringBuilder sb = new StringBuilder(clazz.getName());
        sb.append('#');
        sb.append(fieldName);
        String fullFieldName = sb.toString();
        
        if (fieldCache.containsKey(fullFieldName)) {
            Field field = fieldCache.get(fullFieldName);
            if (field == null)
                throw new NoSuchFieldError(fullFieldName);
            return field;
        }
        
        try {
            Field field = findFieldRecursiveImpl(clazz, fieldName);
            field.setAccessible(true);
            fieldCache.put(fullFieldName, field);
            return field;
        } catch (NoSuchFieldException e) {
            fieldCache.put(fullFieldName, null);
            throw new NoSuchFieldError(fullFieldName);
        }
    }
    
    private static Field findFieldRecursiveImpl(Class<?> clazz, String fieldName) throws NoSuchFieldException {
        try {
            return clazz.getDeclaredField(fieldName);
        } catch (NoSuchFieldException e) {
            while (true) {
                clazz = clazz.getSuperclass();
                if (clazz == null || clazz.equals(Object.class))
                    break;
                
                try {
                    return clazz.getDeclaredField(fieldName);
                } catch (NoSuchFieldException ignored) {}
            }
            throw e;
        }
    }
    
    private static int getIntField(Object obj, String fieldName) {
        try {
            return findField(obj.getClass(), fieldName).getInt(obj);
        } catch (IllegalAccessException e) {
            // should not happen
            Magnifier.ILOGUTIL.exception(LOG_TAG, e);
            throw new IllegalAccessError(e.getMessage());
        } catch (IllegalArgumentException e) {
            throw e;
        }
    }
    
    @Nullable
    public static AdditionalHookInfo dalvikJavaHook(Member hookMethod, XC_MethodHook callback)
    {
        if (!(hookMethod instanceof Method) && !(hookMethod instanceof Constructor<?>)) {
            throw new IllegalArgumentException("only methods and constructors can be hooked");
        }
        Class<?> declaringClass = hookMethod.getDeclaringClass();
        int slot = getIntField(hookMethod, "slot");
        Class<?>[] parameterTypes;
        Class<?> returnType;
        if (hookMethod instanceof Method) {
            parameterTypes = ((Method) hookMethod).getParameterTypes();
            returnType = ((Method) hookMethod).getReturnType();
        } else {
            parameterTypes = ((Constructor<?>) hookMethod).getParameterTypes();
            returnType = null;
        }

        AdditionalHookInfo additionalInfo = new AdditionalHookInfo(callback, parameterTypes, returnType);
        try
        {
            hookMethodNative(hookMethod, declaringClass, slot, additionalInfo);
        }
        catch (UnsatisfiedLinkError e) {
            Magnifier.ILOGUTIL.exception(LOG_TAG, e);
        }
        return additionalInfo;
    }
    
    /**
     * This method is called as a replacement for hooked methods.
     */
    @NonNull
    private static Object handleHookedMethod(Member method, int originalMethodId, Object additionalInfoObj, Object thisObject, Object[] args) throws Throwable {
        AdditionalHookInfo additionalInfo = (AdditionalHookInfo) additionalInfoObj;
        
        if (disableHooks || additionalInfo.callback == null) {
            try {
                return invokeOriginalMethodNative(method, originalMethodId, additionalInfo.parameterTypes, additionalInfo.returnType, thisObject, args);
            } catch (InvocationTargetException e) {
                throw e.getCause();
            }
        }
        XC_MethodHook callback = additionalInfo.callback;

        XC_MethodHook.MethodHookParam param = new XC_MethodHook.MethodHookParam();
        param.method = method;
        param.thisObject = thisObject;
        param.args = args;

        callback.beforeHookedMethod(param);
        Object retValue = new Object();
        try {
            retValue = invokeOriginalMethodNative(method, originalMethodId, additionalInfo.parameterTypes, additionalInfo.returnType, thisObject, args);
        } catch (InvocationTargetException e) {
            throw e.getCause();
        } catch (UnsatisfiedLinkError e) {
            Magnifier.ILOGUTIL.exception(LOG_TAG, e);
        }
        param.setResult(retValue);
        callback.afterHookedMethod(param);
        return retValue;
    }
    
    static boolean initHook() {
        boolean res = false;
        try {
            res = JavaMethodHook.initNative();
        } catch (UnsatisfiedLinkError e) {
            Magnifier.ILOGUTIL.exception(LOG_TAG, e);
        }
        return res;
    }
    
    private native static boolean initNative();
    //synchronized 
    private native static void hookMethodNative(Member method, Class<?> declaringClass, int slot, Object additionalInfo);
    @NonNull
    private native static Object invokeOriginalMethodNative(Member method, int methodId, Class<?>[] parameterTypes, Class<?> returnType, Object thisObject, Object[] args)
            throws IllegalAccessException, IllegalArgumentException, InvocationTargetException;
}