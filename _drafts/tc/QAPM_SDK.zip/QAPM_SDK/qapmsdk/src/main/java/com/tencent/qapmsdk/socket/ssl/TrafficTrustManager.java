package com.tencent.qapmsdk.socket.ssl;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLException;
import javax.net.ssl.X509TrustManager;

/**
 * Created by nicorao on 2018/1/17.
 */

public abstract class TrafficTrustManager implements X509TrustManager, Cloneable {

    private String mHost;

    public void setHost(String host) {
        mHost = host;
    }

    public abstract void checkServerTrusted(X509Certificate[] chain, String authType, String host) throws CertificateException;

    public abstract void onHandshakeFailed(String host, SSLException e);

    public String getHost() {
        return mHost;
    }

    @Override
    public final void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        checkServerTrusted(chain, authType, mHost);
    }

    @Override
    public final void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        throw new UnsupportedOperationException("Not in client mode?");
    }

    final void onHandshakeFailed(SSLException e) {
        onHandshakeFailed(mHost, e);
    }
}

