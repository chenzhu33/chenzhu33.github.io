package com.tencent.qapmsdk.crash;

import android.app.Application;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.annotation.NonNull;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.FileUtil;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.common.VersionUtils;
import com.tencent.qapmsdk.crash.builder.ReportExecutor;
import com.tencent.qapmsdk.crash.config.CoreConfiguration;
import com.tencent.qapmsdk.crash.util.NativeCrashCatcher;

import java.io.File;
import java.util.concurrent.atomic.AtomicBoolean;

public class CrashMonitor {

    private static String LOG_TAG = ILogUtil.getTAG(CrashMonitor.class);
    public CoreConfiguration config;
    private volatile static AtomicBoolean isLoad = new AtomicBoolean(false);
    private static int CRACH_CATCH_ID = 1;

    public CrashMonitor(@NonNull final Application app){

        config = CoreConfiguration.getInstance();
        config.init(CoreConfiguration.DEFAULT_COLLECTOR);

        final ErrorReporterImpl reporter = ErrorReporterImpl.getInstance(app, config);
        reporter.start();
        // 暂时关闭9.0之上的native crash捕获。测试jni反射是没有问题，但是堆栈似乎不是很准确，有很多垃圾堆栈。
        if(config.isNativeCatch() &&!isLoad.get() && !VersionUtils.is64Bit() && !VersionUtils.isP() && FileUtil.loadLibrary("apmcrash")){

            // 为了将该类加载在内存空间中
            NativeCrashCatcher nativeCrashCatcher = new NativeCrashCatcher(app);
            nativeCrashCatcher.init(CRACH_CATCH_ID, new CrashHandleListener() {
                @Override
                public void onCrash(int id, String threadName, Error e) {
                    Magnifier.ILOGUTIL.exception(LOG_TAG, "caught a native crash.", e);
                    Thread thread = NativeCrashCatcher.getThreadByName(threadName);
                    reporter.buildData(thread, e);
                }
            });
            isLoad.set(true);
        }
    }

    public CrashMonitor setReportCrash() {
        if(config.isSendJsonByFiles()) {
            Magnifier.ILOGUTIL.i(LOG_TAG, "ok should send file.");
            // 5 min后上报，防止刚刚启动太多任务上报导致出现问题

            HandlerThread thread = new HandlerThread("post_crash_files");
            thread.start();
            new Handler(thread.getLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    ReportExecutor.sendReportFromFiles(new File(ReportExecutor.logPath));
                }
            }, 5 * 60 * 1000);
        }
        return this;
    }
}
