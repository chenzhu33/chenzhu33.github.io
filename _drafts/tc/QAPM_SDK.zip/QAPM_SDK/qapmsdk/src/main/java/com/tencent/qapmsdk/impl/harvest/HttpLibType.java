package com.tencent.qapmsdk.impl.harvest;

public enum HttpLibType {
    URLConnection,
    URLSession,
    HttpClient,
    OkHttp,
    Webview,
    WebviewAJAX,
    ASIHTTP,
    AFNetworking,
    MKNetworkKit,
    WebViewResource,
    Other;

    private HttpLibType() {
    }
}
