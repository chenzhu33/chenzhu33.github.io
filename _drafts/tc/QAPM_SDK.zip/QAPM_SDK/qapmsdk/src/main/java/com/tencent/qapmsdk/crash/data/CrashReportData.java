package com.tencent.qapmsdk.crash.data;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.common.ILogUtil;
import com.tencent.qapmsdk.crash.collections.ImmutableSet;
import com.tencent.qapmsdk.crash.config.ReportField;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class CrashReportData {

    private static final String LOG_TAG = ILogUtil.getTAG(CrashReportData.class);

    private final JSONObject content;

    public CrashReportData() {
        content = new JSONObject();
    }

    public CrashReportData(String json) throws JSONException {
        content = new JSONObject(json);
    }

    @NonNull
    public String toJSON() throws JSONException {
        try {
            return StringFormat.APM_JSON.toFormattedString(this, ImmutableSet.<ReportField>empty(), "", "", false);
        } catch (JSONException e) {
            throw e;
        } catch (Exception e) {
            throw new JSONException(e.getMessage());
        }
    }

    public synchronized void put(@NonNull String key, boolean value) {
        try {
            content.put(key, value);
        } catch (JSONException e) {
            Magnifier.ILOGUTIL.w(LOG_TAG, "Failed to put value into CrashReportData: " + String.valueOf(value));
        }
    }

    public synchronized void put(@NonNull String key, double value) {
        try {
            content.put(key, value);
        } catch (JSONException e) {
            Magnifier.ILOGUTIL.w(LOG_TAG, "Failed to put value into CrashReportData: " + String.valueOf(value));
        }
    }

    public synchronized void put(@NonNull String key, int value) {
        try {
            content.put(key, value);
        } catch (JSONException e) {
            Magnifier.ILOGUTIL.w(LOG_TAG, "Failed to put value into CrashReportData: " + String.valueOf(value));
        }
    }

    public synchronized void put(@NonNull String key, long value) {
        try {
            content.put(key, value);
        } catch (JSONException e) {
            Magnifier.ILOGUTIL.w(LOG_TAG, "Failed to put value into CrashReportData: " + String.valueOf(value));
        }
    }

    public synchronized void put(@NonNull String key, @Nullable String value) {
        if (value == null) {
            putNA(key);
            return;
        }
        try {
            content.put(key, value);
        } catch (JSONException e) {
            Magnifier.ILOGUTIL.w(LOG_TAG, "Failed to put value into CrashReportData: " + value);
        }
    }

    public synchronized void put(@NonNull String key, @Nullable JSONObject value) {
        if (value == null) {
            putNA(key);
            return;
        }
        try {
            content.put(key, value);
        } catch (JSONException e) {
            Magnifier.ILOGUTIL.w(LOG_TAG, "Failed to put value into CrashReportData: " + String.valueOf(value));
        }
    }

    public synchronized void put(@NonNull String key, @Nullable JSONArray value) {
        if (value == null) {
            putNA(key);
            return;
        }
        try {
            content.put(key, value);
        } catch (JSONException e) {
            Magnifier.ILOGUTIL.w(LOG_TAG, "Failed to put value into CrashReportData: " + String.valueOf(value));
        }
    }

    public synchronized void put(@NonNull String key, @Nullable ArrayList<?> value) {
        try {
            content.put(key, value);
        } catch (JSONException e) {
            Magnifier.ILOGUTIL.w(LOG_TAG, "Failed to put value into CrashReportData: " + String.valueOf(value));
        }
    }

    public synchronized <T> void put(@NonNull String key, @Nullable T[] value){
        try {
            content.put(key, value);
        } catch (JSONException e) {
            Magnifier.ILOGUTIL.w(LOG_TAG, "Failed to put value into CrashReportData of array.");
        }
    }

    public synchronized void put(@NonNull String key, @Nullable Map<?,?> value) {
        try {
            content.put(key, value);
        } catch (JSONException e) {
            Magnifier.ILOGUTIL.w(LOG_TAG, "Failed to put value into CrashReportData: " + String.valueOf(value));
        }
    }

    public synchronized void put(@NonNull ReportField key, boolean value) {
        put(key.toString(), value);
    }

    public synchronized void put(@NonNull ReportField key, double value) {
        put(key.toString(), value);
    }

    public synchronized void put(@NonNull ReportField key, int value) {
        put(key.toString(), value);
    }

    public synchronized void put(@NonNull ReportField key, long value) {
        put(key.toString(), value);
    }

    public synchronized void put(@NonNull ReportField key, @Nullable String value) {
        put(key.toString(), value);
    }

    public synchronized void put(@NonNull ReportField key, @Nullable JSONObject value) {
        put(key.toString(), value);
    }

    public synchronized void put(@NonNull ReportField key, @Nullable JSONArray value) {
        put(key.toString(), value);
    }

    public synchronized void put(@NonNull ReportField key, @Nullable ArrayList<?> value) {
        put(key.toString(), value);
    }

    public synchronized <T> void put(@NonNull ReportField key, @Nullable T[] value) {
        put(key.toString(), value);
    }

    public synchronized void put(@NonNull ReportField key, @Nullable Map<?,?> value) {
        put(key.toString(), value);
    }

    private void putNA(@NonNull String key) {
        try {
            content.put(key, "N/A");
        } catch (JSONException ignored) {
        }
    }

    /**
     * Returns the property with the specified key.
     *
     * @param key the key of the property to find.
     * @return the keyd property value, or {@code null} if it can't be found.
     */
    public String getString(@NonNull ReportField key) {
        return content.optString(key.toString());
    }

    public Object get(@NonNull String key) {
        return content.opt(key);
    }

    public boolean containsKey(@NonNull String key) {
        return content.has(key);
    }

    public boolean containsKey(@NonNull ReportField key) {
        return containsKey(key.toString());
    }

    @NonNull
    public Map<String, Object> toMap() {
        final Map<String, Object> map = new HashMap<>(content.length());
        for (final Iterator<String> iterator = content.keys(); iterator.hasNext(); ) {
            final String key = iterator.next();
            map.put(key, get(key));
        }
        return map;
    }

    public void printData() {
        Magnifier.ILOGUTIL.d(LOG_TAG, this.content.toString());
    }

    public JSONObject getContent() {
        return content;
    }
}
