package com.tencent.qapmsdk.dns.utils;


import android.os.Build;


import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.dns.logic.DnsCacheWrapper;

import java.lang.reflect.Field;
import java.net.InetAddress;

/**
 * Created by nicorao on 2017/11/23.
 */
public class HookUtils {

    private static final String TAG = "QAPM_DNS_HookUtils";

    private static final DnsHookCompatImpl HOOK_IMPL;

    static {
        if (Build.VERSION.SDK_INT >= 24) {
            HOOK_IMPL = new DNSHookCompatImplV24();
        } else {
            HOOK_IMPL = new DNSHookCompatImplBase();
        }
    }

    public static void hook() {
        try {
            HOOK_IMPL.hook();
            Utils.getAsyncCallbackWrapper().onHook(true, null);
            Magnifier.ILOGUTIL.i(TAG, "hook success!");
        } catch (Throwable tr) {
            Utils.getAsyncCallbackWrapper().onHook(false, tr);
            Magnifier.ILOGUTIL.exception(TAG, "hook failed!", tr);
        }
    }

    private interface DnsHookCompatImpl {
        void hook() throws Exception;
    }

    private static class DNSHookCompatImplBase implements DnsHookCompatImpl {

        @Override
        public void hook() throws Exception {
            Field fAddressCache = InetAddress.class.getDeclaredField("addressCache");
            fAddressCache.setAccessible(true);
            Object oAddressCache = fAddressCache.get(null);

            Class<?> clzAddressCache = Class.forName("java.net.AddressCache");
            Field fCache = clzAddressCache.getDeclaredField("cache");
            fCache.setAccessible(true);
            Object oCache = fCache.get(oAddressCache);

            Class<?> clzBasicLruCache = Class.forName("libcore.util.BasicLruCache");
            Field fMap = clzBasicLruCache.getDeclaredField("map");
            fMap.setAccessible(true);
            fMap.set(oCache, new DnsCacheWrapper());
        }
    }

    private static class DNSHookCompatImplV24 implements DnsHookCompatImpl {

        @Override
        public void hook() throws Exception {
            Class<?> clzInet6AddressImpl = Class.forName("java.net.Inet6AddressImpl");
            Field fAddressCache = clzInet6AddressImpl.getDeclaredField("addressCache");
            fAddressCache.setAccessible(true);
            Object oAddressCache = fAddressCache.get(null);

            Class<?> clzAddressCache = Class.forName("java.net.AddressCache");
            Field fCache = clzAddressCache.getDeclaredField("cache");
            fCache.setAccessible(true);
            Object oCache = fCache.get(oAddressCache);

            Class<?> clzBasicLruCache = Class.forName("libcore.util.BasicLruCache");
            Field fMap = clzBasicLruCache.getDeclaredField("map");
            fMap.setAccessible(true);
            fMap.set(oCache, new DnsCacheWrapper());
        }
    }
}
