package com.tencent.qapmsdk.config;

import android.support.annotation.NonNull;
import android.util.SparseArray;

import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.sample.PerfCollector;

public class CollectStatus {
    private static final String KEY_LAST_START_DATE = "last_start_date";
    public static final String KEY_COUNT_TODAY_REPORTED = "count_today_reported";
    public static final String KEY_COUNT_TODAY_SAMPLE_REPORTED = "count_today_sample_reported";
    public static final String KEY_COUNT_TODAY_LOAD_CONFIG = "count_today_load_config";
    public static final String KEY_COUNT_PLUGIN_PREFIX = "count_plugin_";
    private static long startDate = Math.round(System.currentTimeMillis() / (24 * 60 * 60 * 1000));
    public static int reported = 0;
    public static int load_config_cnt = 0;
    public static int sample_reported = 0;
    
    public static class CurrentRecord {
        public long mLastTimestamp = 0;
        public int mCollectCount = 0;
        private boolean mCanCollect = true;
        
        private CurrentRecord(long ts, int count) {
            mLastTimestamp = ts;
            mCollectCount = count;
        }
    }
    
    @NonNull
    public static SparseArray<CurrentRecord> mRecord = new SparseArray<CurrentRecord>(Config.Plugins.size() + Config.OtherPlugins.size());

    static void init() {
        long lastReportTime;
        if (Magnifier.QAPM_SP != null) {
            lastReportTime = Magnifier.QAPM_SP.getLong(KEY_LAST_START_DATE, 0l);
        } else {
            lastReportTime = startDate;
        }
        if (startDate - lastReportTime > 0 && Magnifier.editor != null) {
            Magnifier.editor.putLong(KEY_LAST_START_DATE, startDate);
            Magnifier.editor.putInt(KEY_COUNT_TODAY_REPORTED, 0);
            Magnifier.editor.putInt(KEY_COUNT_TODAY_LOAD_CONFIG, 0);
            for (int key : Config.Plugins) {
                Magnifier.editor.putInt(KEY_COUNT_PLUGIN_PREFIX + key, 0);
                mRecord.append(key, new CurrentRecord(0, 0));
            }
            for (int key : Config.OtherPlugins) {
                Magnifier.editor.putInt(KEY_COUNT_PLUGIN_PREFIX + key, 0);
                mRecord.append(key, new CurrentRecord(0, 0));
            }
            Magnifier.editor.commit();
        } else if (Magnifier.QAPM_SP != null) {
            reported = Magnifier.QAPM_SP.getInt(KEY_COUNT_TODAY_REPORTED, 0);
            sample_reported = Magnifier.QAPM_SP.getInt(KEY_COUNT_TODAY_SAMPLE_REPORTED, 0);
            load_config_cnt = Magnifier.QAPM_SP.getInt(KEY_COUNT_TODAY_LOAD_CONFIG, 0);
            if (reported < Config.MAX_REPORT_NUM) {
                for (int key : Config.Plugins) {
                    int reported = Magnifier.QAPM_SP.getInt(KEY_COUNT_PLUGIN_PREFIX + key, 0);
                    mRecord.append(key, new CurrentRecord(0, reported));
                }
            }
            if (sample_reported < Config.MAX_RESOURCE_REPORT_NUM){
                for (int key : Config.OtherPlugins) {
                    int reported = Magnifier.QAPM_SP.getInt(KEY_COUNT_PLUGIN_PREFIX + key, 0);
                    mRecord.append(key, new CurrentRecord(0, reported));
                }
            }
        }
    }
    
    public static boolean canCollect(int plugin) {
        if (Config.OtherPlugins.contains(plugin)) {
            if (sample_reported > Config.MAX_RESOURCE_REPORT_NUM) {
                return false;
            }
            if (plugin == Config.PLUGIN_QCLOUD_NEW_RESOURCE_REPORT &&
                    ((Config.STARTED_FUNC & ApmConst.ModeResource) == 0 || (Config.RES_TYPE & PerfCollector.OPENRETAG) == 0)) {
                return false;
            }
        } else {
            if (reported > Config.MAX_REPORT_NUM) {
                return false;
            }
        }

        CurrentRecord cr = mRecord.get(plugin);
        if (cr == null) {
            return false;
        } else if (cr.mCanCollect) {
            int maxReportNum = Config.mSampleConfigs.get(plugin).maxReportNum;
            int reported = cr.mCollectCount;
            if (reported >= maxReportNum) {
                cr.mCanCollect = false;
            }
        }
        return cr.mCanCollect;
    }
    
    public static void addCollectCount(int plugin) {
        CurrentRecord cr = mRecord.get(plugin);
        if (cr == null) return;
        cr.mCollectCount += 1;
        //cr.mLastTimestamp = System.currentTimeMillis();
    }
    
    public static boolean whetherSamplingThisTime(int plugin) {
        if (!CollectStatus.canCollect(plugin)) {
            return false;
        } else {
            float familySampleRatio = Config.mSampleConfigs.get(plugin).eventSampleRatio;
            return Math.random() < familySampleRatio;
        }
    }
}