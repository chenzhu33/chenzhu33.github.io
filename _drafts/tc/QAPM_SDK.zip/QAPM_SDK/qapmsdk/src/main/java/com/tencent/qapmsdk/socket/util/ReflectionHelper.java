package com.tencent.qapmsdk.socket.util;

import android.support.annotation.NonNull;
import android.support.annotation.RestrictTo;
import android.text.TextUtils;

import com.tencent.qapmsdk.Magnifier;

import java.io.FileDescriptor;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


@RestrictTo(RestrictTo.Scope.LIBRARY)
public class ReflectionHelper {

    private static final String TAG = "QAPM_Socket_ReflectionHelper";

    private static final int MAGIC_NUMBER = 0xABCDEF;

    private static final Map<String, Class<?>> sClassCache = new ConcurrentHashMap<>();

    private static final Map<Class<?>, Cache> sClassReflectCache = new ConcurrentHashMap<>();

    public static class Cache {

        private Map<MethodKey, Method> mMethodCache = new ConcurrentHashMap<>();
        private Map<String, Field> mFieldCache = new ConcurrentHashMap<>();
        private Map<ConstructorKey, Constructor<?>> mConstructorCache = new ConcurrentHashMap<>();

        private Class<?> mClz;

        Cache(Class<?> clz) {
            mClz = clz;
        }

        public Constructor<?> constructor(Class<?>...types) throws NoSuchMethodException {
            ConstructorKey key = new ConstructorKey(types);
            Constructor constructor = mConstructorCache.get(key);
            if (constructor == null) {
                constructor = mClz.getDeclaredConstructor(types);
                constructor.setAccessible(true);
                mConstructorCache.put(key, constructor);
            }
            return constructor;
        }

        public Field field(String name) throws NoSuchFieldException {
            Field field = mFieldCache.get(name);
            if (field == null) {
                for (Class<?> c = mClz; c != null; c = c.getSuperclass()) {
                    try {
                        field = c.getDeclaredField(name);
                    } catch (NoSuchFieldException ignored) {
                        continue;
                    }
                    field.setAccessible(true);
                    mFieldCache.put(name, field);
                    return field;
                }
                throw new NoSuchFieldException("class: " + mClz + ", field: " + name);
            }
            return field;
        }

        @NonNull
        public Method method(String name, Class<?>...types) throws NoSuchMethodException {
            // 这里虽然每次都new对象，但花销较小，从综合考虑，这里不宜做cache，查找也需要时间
            MethodKey key = new MethodKey(name, types);
            Method method = mMethodCache.get(key);
            // 这里就不锁了，允许线程不安全，对结果影响不大
            if (method == null) {
                // 注意，这里不去找Object.class中的方法，没有必要
                for (Class<?> c = mClz; c != null; c = c.getSuperclass()) {
                    try {
                        method = c.getDeclaredMethod(name, types);
                    } catch (NoSuchMethodException ignored) {
                        continue;
                    }
                    method.setAccessible(true);
                    mMethodCache.put(key, method);
                    return method;
                }
                throw new NoSuchMethodException("class: " + mClz + ", method: " +  name + ", args: " + Arrays.toString(types));
            }
            return method;
        }
    }

    public static class RetrofitCache {
        private Object mInstance;

        RetrofitCache(Object instance) {
            mInstance = instance;
        }

        public RetrofitField field(String name) throws NoSuchFieldException, IllegalAccessException {
            return new RetrofitField(fieldValue(mInstance, name));
        }

        public RetrofitMethod method(String name, Class<?>...types) throws NoSuchMethodException {
            return new RetrofitMethod(mInstance, of(mInstance.getClass()).method(name, types));
        }
    }

    public static class RetrofitMethod {
        private Object mInstance;
        private Method mMethod;
        List<Object> mArgList;

        RetrofitMethod(Object instance, Method method) {
            mInstance = instance;
            mMethod = method;
        }

        public RetrofitMethod args(Object... args) throws InvocationTargetException, IllegalAccessException {
            if (mArgList == null) {
                mArgList = new ArrayList<>();
            }
            Collections.addAll(mArgList, args);
            return this;
        }

        public Object invoke() throws InvocationTargetException, IllegalAccessException {
            return mMethod.invoke(mInstance, mArgList != null ? mArgList.toArray(new Object[mArgList.size()]) : null);
        }
    }

    public static class RetrofitField {
        private Object mValue;

        RetrofitField(Object value) {
            mValue = value;
        }

        public Object get() throws IllegalAccessException {
            return mValue;
        }

        public RetrofitField field(String name) throws IllegalAccessException, NoSuchFieldException {
            return new RetrofitField(fieldValue(mValue, name));
        }

        public RetrofitMethod method(String name, Class<?>...types) throws NoSuchFieldException, IllegalAccessException, NoSuchMethodException {
            return new RetrofitMethod(mValue, of(mValue.getClass()).method(name, types));
        }
    }

    private static class MethodKey {
        String name;
        Class<?>[] types;

        MethodKey(String name, Class<?>[] types) {
            this.name = name;
            this.types = types;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == this) return true;
            if (obj instanceof MethodKey) {
                MethodKey key = (MethodKey) obj;
                return key.name.equals(name) && Arrays.equals(key.types, types);
            }
            return false;
        }

        @Override
        public int hashCode() {
            int result = 0;
            if (types != null && types.length > 0) {
                for (int i = 0; i < types.length; i++) {
                    result += (i + 1) * types[i].hashCode() * types[i].getName().hashCode() * MAGIC_NUMBER;
                }
            }
            result += name.hashCode();
            return result;
        }
    }

    private static class ConstructorKey {
        Class<?>[] types;

        ConstructorKey(Class<?>[] types) {
            this.types = types;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == this) return true;
            if (obj instanceof ConstructorKey) {
                ConstructorKey key = (ConstructorKey) obj;
                return Arrays.equals(key.types, types);
            }
            return false;
        }

        @Override
        public int hashCode() {
            int result = 0;
            if (types != null && types.length > 0) {
                for (int i = 0; i < types.length; i++) {
                    result += (i + 1) * types[i].hashCode() * types[i].getName().hashCode() * MAGIC_NUMBER;
                }
            }
            return result;
        }
    }

    public static Cache of(String clz) throws ClassNotFoundException {
        Class<?> clzz = sClassCache.get(clz);
        if (clzz == null) {
            clzz = Class.forName(clz);
            sClassCache.put(clz, clzz);
        }
        return of(clzz);
    }

    @NonNull
    public static Cache of(Class<?> clz) {
        Cache map = sClassReflectCache.get(clz);
        if (map == null) {
            synchronized (clz) {
                if ((map = sClassReflectCache.get(clz)) == null) {
                    map = new Cache(clz);
                    sClassReflectCache.put(clz, map);
                }
            }
        }
        return map;
    }

    public static RetrofitCache instance(Object instance) {
        return new RetrofitCache(instance);
    }

    public static Object fieldValue(Object instance, String name) throws NoSuchFieldException, IllegalAccessException {
        return of(instance.getClass()).field(name).get(instance);
    }

    private static String sOpenSSLPackageName;

    public static String getOpenSSLPackageName() {
        if (sOpenSSLPackageName == null) {
            String[] packageNames = {"com.android.org.conscrypt", "org.conscrypt", "org.apache.harmony.xnet.provider.jsse"};
            for (String packageName : packageNames) {
                try {
                    of(packageName + ".OpenSSLContextImpl");
                    sOpenSSLPackageName = packageName;
                    break;
                } catch (Exception ignored) {}
            }
            if (TextUtils.isEmpty(sOpenSSLPackageName)) {
                processException(new RuntimeException("cannot find OpenSSLContextImpl"));
            }
        }
        return sOpenSSLPackageName;
    }

    public static String printFd(Object fd) {
        if (fd instanceof FileDescriptor) {
            try {
                return "fd[" + of(FileDescriptor.class).field("descriptor").get(fd) + "]";
            } catch (Exception ignored) {}
        }
        return String.valueOf(fd);
    }

    public static void processException(Throwable tr) {
        Magnifier.ILOGUTIL.exception(TAG, tr);
    }
}

