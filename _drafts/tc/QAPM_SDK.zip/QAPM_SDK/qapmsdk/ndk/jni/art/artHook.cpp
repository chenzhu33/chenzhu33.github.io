/*
 * Original Copyright 2014-2015 Marvin Wißfeld
 * Modified work Copyright (c) 2017, weishu
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <jni.h>
#include <android/log.h>
#include <sys/mman.h>
#include <errno.h>
#include <unistd.h>
#include <dlfcn.h>
#include <cstdlib>
#include <sys/system_properties.h>
#include <map>
#include <list>
#include <pthread.h>
#include "hutils.h"

#define JNIHOOK_CLASS "com/tencent/qapmsdk/io/art/MethodHookNative"

jobject (*addWeakGloablReference)(JavaVM *, void *, void *);
jobject (*deleteWeakGloablReference)(JavaVM *, void *, jobject);
void (*JavaVmExtSetCheckJniEnabled)(JavaVM *,bool);
void (*JNiEnvExtSetCheckJniEnabled)(JNIEnv *,bool);
jboolean (*VMRuntimeIsCheckJniEnabled)(JNIEnv *,jobject);
void* (*decodeJobject)(void *, jobject);

void* (*jit_load_)(bool*) = NULL;
void* jit_compiler_handle_ = NULL;
bool (*jit_compile_method_)(void*, void*, void*, bool) = NULL;
void (*jit_unload_)(void*) = NULL;

class ScopedSuspendAll {};

void (*suspendAll)(ScopedSuspendAll*, char*) = NULL;
void (*resumeAll)(ScopedSuspendAll*) = NULL;

static int api_level;
static bool is_checkJni = JNI_TRUE;
pthread_mutex_t weakRefMutexLock;
std::map<long, std::list<std::map<long, jobject >>* > weakThreadRefMap;


void* __self() {

#ifdef __arm__
    register uint32_t r9 asm("r9");
    return (void*) r9;
#elif defined(__aarch64__)
    register uint64_t x19 asm("x19");
    return (void*) x19;
#else
#endif

};

void init_entries(JNIEnv *env) {

    char api_level_str[5];
    __system_property_get("ro.build.version.sdk", api_level_str);
    api_level = atoi(api_level_str);
    pthread_mutex_init(&weakRefMutexLock, NULL);


    if (api_level < 23) {
        // Android L, art::JavaVMExt::AddWeakGlobalReference(art::Thread*, art::mirror::Object*)
        void *handle = dlopen("libart.so", RTLD_LAZY | RTLD_GLOBAL);
        addWeakGloablReference = (jobject (*)(JavaVM *, void *, void *)) dlsym(handle,
                                                                               "_ZN3art9JavaVMExt22AddWeakGlobalReferenceEPNS_6ThreadEPNS_6mirror6ObjectE");
        deleteWeakGloablReference = (jobject (*)(JavaVM *, void *, jobject)) dlsym(handle,
                                                                               "_ZN3art9JavaVMExt19DeleteWeakGlobalRefEPNS_6ThreadEP8_jobject");
        decodeJobject = (void* (*)(void *, jobject)) dlsym(handle, "_ZNK3art6Thread13DecodeJObjectEP8_jobject");

        JavaVmExtSetCheckJniEnabled = (void (*)(JavaVM *, bool)) dlsym(handle, "_ZN3art9JavaVMExt18SetCheckJniEnabledEb");
        JNiEnvExtSetCheckJniEnabled = (void (*)(JNIEnv *, bool)) dlsym(handle, "_ZN3art9JNIEnvExt18SetCheckJniEnabledEb");
        VMRuntimeIsCheckJniEnabled = (jboolean (*)(JNIEnv *, jobject)) dlsym_abs("_ZN3artL27VMRuntime_isCheckJniEnabledEP7_JNIEnvP8_jobject", "/system/lib/libart.so");

    } else if (api_level < 24) {
        // Android M, art::JavaVMExt::AddWeakGlobalRef(art::Thread*, art::mirror::Object*)
        void *handle = dlopen("libart.so", RTLD_LAZY | RTLD_GLOBAL);
        addWeakGloablReference = (jobject (*)(JavaVM *, void *, void *)) dlsym(handle,
                                                                               "_ZN3art9JavaVMExt16AddWeakGlobalRefEPNS_6ThreadEPNS_6mirror6ObjectE");
        deleteWeakGloablReference = (jobject (*)(JavaVM *, void *, jobject)) dlsym(handle,
                                                                               "_ZN3art9JavaVMExt19DeleteWeakGlobalRefEPNS_6ThreadEP8_jobject");
        decodeJobject = (void* (*)(void *, jobject)) dlsym(handle, "_ZNK3art6Thread13DecodeJObjectEP8_jobject");

        JavaVmExtSetCheckJniEnabled = (void (*)(JavaVM *, bool)) dlsym(handle, "_ZN3art9JavaVMExt18SetCheckJniEnabledEb");
        JNiEnvExtSetCheckJniEnabled = (void (*)(JNIEnv *, bool)) dlsym(handle, "_ZN3art9JNIEnvExt18SetCheckJniEnabledEb");
        VMRuntimeIsCheckJniEnabled = (jboolean (*)(JNIEnv *, jobject)) dlsym_abs("_ZN3artL27VMRuntime_isCheckJniEnabledEP7_JNIEnvP8_jobject", "/system/lib/libart.so");

    } else if (api_level <= 26){
        // Android N and O, Google disallow us use dlsym;
        char *libartPath;
        char *compilerPath;
        // TODO:宏控制
        if (sizeof(void*) == sizeof(uint64_t)) {
            libartPath = "/system/lib64/libart.so";
            compilerPath = "/system/lib64/libart-compiler.so";
        } else {
            libartPath = "/system/lib/libart.so";
            compilerPath = "/system/lib/libart-compiler.so";
        }

        const char *addWeakGloablReferenceSymbol = api_level == 25
                                                   ? "_ZN3art9JavaVMExt16AddWeakGlobalRefEPNS_6ThreadEPNS_6mirror6ObjectE"
                                                   : "_ZN3art9JavaVMExt16AddWeakGlobalRefEPNS_6ThreadENS_6ObjPtrINS_6mirror6ObjectEEE";
        const char *deleteaddWeakGloablReferenceSymbol = "_ZN3art9JavaVMExt19DeleteWeakGlobalRefEPNS_6ThreadEP8_jobject";
        addWeakGloablReference = (jobject (*)(JavaVM *, void *, void *))dlsym_abs_for_a7(addWeakGloablReferenceSymbol, libartPath);
        deleteWeakGloablReference = (jobject (*)(JavaVM *, void *, jobject))dlsym_abs_for_a7(deleteaddWeakGloablReferenceSymbol, libartPath);
        decodeJobject =  (void* (*)(void *, jobject))dlsym_abs_for_a7("_ZNK3art6Thread13DecodeJObjectEP8_jobject", libartPath);
        JavaVmExtSetCheckJniEnabled = (void (*)(JavaVM *, bool)) dlsym_abs_for_a7("_ZN3art9JavaVMExt18SetCheckJniEnabledEb", libartPath);
        JNiEnvExtSetCheckJniEnabled = (void (*)(JNIEnv *, bool)) dlsym_abs_for_a7("_ZN3art9JNIEnvExt18SetCheckJniEnabledEb", libartPath);
        VMRuntimeIsCheckJniEnabled = (jboolean (*)(JNIEnv *, jobject)) dlsym_abs_for_a7("_ZN3artL27VMRuntime_isCheckJniEnabledEP7_JNIEnvP8_jobject", libartPath);

        jit_compile_method_ = (bool (*)(void *, void *, void *, bool)) dlsym_abs_for_a7("jit_compile_method",compilerPath);
        jit_load_ = reinterpret_cast<void* (*)(bool*)>(dlsym_abs_for_a7("jit_load",compilerPath));
        bool generate_debug_info = false;
        jit_compiler_handle_ = (jit_load_)(&generate_debug_info);

        suspendAll = reinterpret_cast<void (*)(ScopedSuspendAll*, char*)>(dlsym_abs_for_a7("_ZN3art16ScopedSuspendAllC1EPKcb",libartPath));
        resumeAll = reinterpret_cast<void (*)(ScopedSuspendAll*)>(dlsym_abs_for_a7("_ZN3art16ScopedSuspendAllD1Ev",libartPath));

    }

    LOGI("check get class and method is NULL. addWeakGloablReference: %i, deleteWeakGloablReference: %i, decodeJobject: %i, JavaVmExtSetCheckJniEnabled: %i, JNiEnvExtSetCheckJniEnabled: %i, VMRuntimeIsCheckJniEnabled: %i", addWeakGloablReference != NULL, deleteWeakGloablReference != NULL, decodeJobject != NULL, JavaVmExtSetCheckJniEnabled != NULL,
         JNiEnvExtSetCheckJniEnabled != NULL, VMRuntimeIsCheckJniEnabled != NULL);

    if (VMRuntimeIsCheckJniEnabled != NULL){
        is_checkJni = VMRuntimeIsCheckJniEnabled(env ,NULL);
        LOGD("check jni is %d", is_checkJni);
    }


}

jboolean hook_compile(JNIEnv *env, jclass, jobject method, jlong self) {
    //LOGD("self from native peer: %p, from register: %p", reinterpret_cast<void*>(self), __self());
    jlong art_method = (jlong) env->FromReflectedMethod(method);
    bool ret = jit_compile_method_(jit_compiler_handle_, reinterpret_cast<void*>(art_method), reinterpret_cast<void*>(self), false);
    return (jboolean)ret;
}

jlong hook_suspendAll(JNIEnv *, jclass) {
    ScopedSuspendAll *scopedSuspendAll = (ScopedSuspendAll *) malloc(sizeof(ScopedSuspendAll));
    suspendAll(scopedSuspendAll, "stop_jit");
    return reinterpret_cast<jlong >(scopedSuspendAll);
}

void hook_resumeAll(JNIEnv* env, jclass, jlong obj) {
    ScopedSuspendAll* scopedSuspendAll = reinterpret_cast<ScopedSuspendAll*>(obj);
    resumeAll(scopedSuspendAll);
}


jboolean hook_changeprotect(JNIEnv *env, jclass, jlong addr, jboolean protect) {
    long pagesize = sysconf(_SC_PAGESIZE);
    if (pagesize <= 0)
    {
        pagesize = 4096;
    }
    unsigned alignment = (unsigned)((unsigned long long)addr % pagesize);
    int i = protect ? mprotect((void *) (addr - alignment), 2 * pagesize, PROT_READ | PROT_EXEC) :  mprotect((void *) (addr - alignment), 2 * pagesize, PROT_READ | PROT_WRITE | PROT_EXEC);
    if (i == -1) {
       // LOGD("mprotect failed: %s (%d)", strerror(errno), errno);
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

jboolean hook_cacheflush(JNIEnv *env, jclass, jlong addr, jlong len) {
#if defined(__arm__)
    int i = cacheflush(addr, addr + len, 0);
   // LOGD("arm cacheflush for, %ul", addr);
    if (i == -1) {
        LOGE("cache flush failed: %s (%d)", strerror(errno), errno);
        return JNI_FALSE;
    }
#elif defined(__aarch64__)
    char* begin = reinterpret_cast<char*>(addr);
    __builtin___clear_cache(begin, begin + len);
   // LOGD("aarch64 __builtin___clear_cache, %p", (void*)begin);
#endif
    return JNI_TRUE;
}

void hook_memcpy(JNIEnv *env, jclass, jlong src, jlong dest, jint length) {
    char *srcPnt = (char *) src;
    char *destPnt = (char *) dest;
    for (int i = 0; i < length; ++i) {
        destPnt[i] = srcPnt[i];
    }
}

void hook_memput(JNIEnv *env, jclass, jbyteArray src, jlong dest) {

    jbyte *srcPnt = env->GetByteArrayElements(src, 0);
    jsize length = env->GetArrayLength(src);
    unsigned char *destPnt = (unsigned char *) dest;
    for (int i = 0; i < length; ++i) {
        // LOGV("put %d with %d", i, *(srcPnt + i));
        destPnt[i] = (unsigned char) srcPnt[i];
    }
    env->ReleaseByteArrayElements(src, srcPnt, 0);
}

jbyteArray hook_memget(JNIEnv *env, jclass, jlong src, jint length) {

    jbyteArray dest = env->NewByteArray(length);
    if (dest == NULL) {
        return NULL;
    }
    unsigned char *destPnt = (unsigned char *) env->GetByteArrayElements(dest, 0);
    unsigned char *srcPnt = (unsigned char *) src;
    for (int i = 0; i < length; ++i) {
        destPnt[i] = srcPnt[i];
    }
    env->ReleaseByteArrayElements(dest, (jbyte *) destPnt, 0);

    return dest;
}

jlong hook_mmap(JNIEnv *env, jclass, jint length) {
    void *space = mmap(0, (size_t) length, PROT_READ | PROT_WRITE | PROT_EXEC,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (space == MAP_FAILED) {
        LOGE("mmap failed: %d", errno);
        return 0;
    }
    return (jlong) space;
}

void hook_munmap(JNIEnv *env, jclass, jlong addr, jint length) {
    int r = munmap((void *) addr, (size_t) length);
    if (r == -1) {
        LOGE("munmap failed: %d", errno);
    }
}

jlong hook_malloc(JNIEnv *env, jclass, jint size) {
    size_t length = sizeof(void *) * size;
    void *ptr = malloc(length);
    //LOGE("malloc :%d of memory at: %p", (int) length, ptr);
    return (jlong) ptr;
}

void hook_free(JNIEnv *env, jclass, jlong ptr) {
    void* ptr_free = (void *) ptr;
    free(ptr_free);
    return;
}

jobject hook_getobject(JNIEnv *env, jclass clazz, jlong self, jlong address) {
    JavaVM *vm;
    env->GetJavaVM(&vm);
    //这里存在句柄泄漏，超过52000个弱引用会crash
    jobject object = addWeakGloablReference(vm, (void *) self, (void *) address);
    //可能有多线程问题，加个锁处理，可是查不到自旋锁，先用互斥锁来处理
    pthread_mutex_lock(&weakRefMutexLock);
    //map结构类似为{thread(self):[{address:jobject}]}
    std::list<std::map<long, jobject >>* refList;
    if(weakThreadRefMap.find(self) != weakThreadRefMap.end()){
        refList = weakThreadRefMap[self];
    }
    else{
        refList = new std::list<std::map<long, jobject >>();
    }

    std::map<long, jobject> objRefMap;
    objRefMap[address] = object;
    refList->push_front(objRefMap);
    weakThreadRefMap[self] = refList;
    pthread_mutex_unlock(&weakRefMutexLock);

    //LOGE("hook_getobject: %p, address: %p",(void*) object, (void*) address);
    return object;
}

void hook_deleteobject(JNIEnv *env, jclass clazz, jlong self, jobject object) {
    JavaVM *vm;
    env->GetJavaVM(&vm);

    //jobject类似于句柄，主要用于java层，因为在java中做参数传递后，这里jobject值（也就是句柄值）变化了，不是原有的在getobject中传回的句柄。
    // 所以不能直接用传下来的句柄来做delete。这里将下传的jobject获得相关地址，然后利用该地址找到之前分配的jobject，然后再清理这个我们创建的弱应用。很厉害吧！！！哈哈哈
    void *objectAddress = decodeJobject((void*) self, object);
    //LOGE("hook_deleteobject: %p, self: %p, object: %p, address: %p", vm, (void*) self, (void*) object, objectAddress);
    if(weakThreadRefMap.find(self) == weakThreadRefMap.end()){
        return;
    }
    //可能有多线程问题，加个锁处理，可是查不到自旋锁，先用互斥锁来处理
    pthread_mutex_lock(&weakRefMutexLock);
    std::list<std::map<long, jobject >>* refList = weakThreadRefMap[self];
//    if (is_checkJni == JNI_FALSE){
//        if (JavaVmExtSetCheckJniEnabled != NULL){
//            JavaVmExtSetCheckJniEnabled(vm, true);
//        }
//        if (JNiEnvExtSetCheckJniEnabled != NULL){
//            JNiEnvExtSetCheckJniEnabled(env, true);
//        }
//    }
    //LOGE("hook_deleteobject, %d", refList->size());
    for (std::list<std::map<long, jobject >>::iterator item = refList->begin(); item != refList->end(); ++item) {
        if(item->find((long)objectAddress) != item->end()){
//            deleteWeakGloablReference(vm, (void *) self, (*item)[(long)objectAddress]);
            //LOGE("hook_deleteobject: %p, address: %p",(void*) (*item)[(long)objectAddress], objectAddress);
            refList->erase(item);
            break;
        }
    }
    //LOGE("hook_deleteobject: %p, address: %p",(void*) object, (void*) objectAddress);
    if (refList->size() == 0){
        delete refList;
        weakThreadRefMap.erase(self);
    }

//    if (is_checkJni == JNI_FALSE){
//        if (JavaVmExtSetCheckJniEnabled != NULL){
//            JavaVmExtSetCheckJniEnabled(vm, false);
//        }
//        if (JNiEnvExtSetCheckJniEnabled != NULL){
//            JNiEnvExtSetCheckJniEnabled(env, false);
//        }
//    }
    pthread_mutex_unlock(&weakRefMutexLock);
}

jlong hook_getMethodAddress(JNIEnv *env, jclass clazz, jobject method) {
    jlong art_method = (jlong) env->FromReflectedMethod(method);
    return art_method;
}
void hook_memSetInt(JNIEnv *env, jclass clazz, jlong addr, jint pos, jint value){
    void* ptr = (void*) addr;
    *((int*)(ptr) + pos) = value;
    return;
}

jbyteArray hook_createJump(JNIEnv *env, jclass clazz, jlong addr){
    jbyteArray result;
    JumpInfo* jump_info = createJumpBlock((uint32_t)addr);
    if (jump_info == NULL)
    {
        return NULL;
    }
    result = (env)->NewByteArray(jump_info->array_len);
    if (result == NULL)
    {
        return NULL;
    }
    (env)->SetByteArrayRegion(result, 0, jump_info->array_len, jump_info->byte_array);
    if (jump_info->byte_array != NULL)
    {
        delete jump_info->byte_array;
    }
    delete jump_info;
    return result;
}

jboolean hook_munprotect(JNIEnv *env, jclass, jlong addr, jlong len) {
    long pagesize = sysconf(_SC_PAGESIZE);
    unsigned alignment = (unsigned)((unsigned long long)addr % pagesize);
    int i = mprotect((void *) (addr - alignment), (size_t) (alignment + len),
                     PROT_READ | PROT_WRITE | PROT_EXEC);
    if (i == -1) {
        LOGE("mprotect failed: %s (%d)", strerror(errno), errno);
        return JNI_FALSE;
    }
    return JNI_TRUE;
}


jboolean hook_activate(JNIEnv* env, jclass jclazz, jlong jumpToAddress, jlong pc, jlong sizeOfDirectJump,
                       jlong sizeOfBridgeJump, jbyteArray code) {

    // fetch the array, we can not call this when thread suspend(may lead deadlock)
    jbyte *srcPnt = env->GetByteArrayElements(code, 0);
    jsize length = env->GetArrayLength(code);

    jlong cookie = 0;
    bool isNougat = api_level >= 24;
    if (isNougat) {
        // We do thus things:
        // 1. modify the code mprotect
        // 2. modify the code

        // Ideal, this two operation must be atomic. Below N, this is safe, because no one
        // modify the code except ourselves;
        // But in Android N, When the jit is working, between our step 1 and step 2,
        // if we modity the mprotect of the code, and planning to write the code,
        // the jit thread may modify the mprotect of the code meanwhile
        // we must suspend all thread to ensure the atomic operation.

        cookie = hook_suspendAll(env, jclazz);
    }

    jboolean result = hook_munprotect(env, jclazz, jumpToAddress, sizeOfDirectJump);
    if (result) {
        unsigned char *destPnt = (unsigned char *) jumpToAddress;
        for (int i = 0; i < length; ++i) {
            destPnt[i] = (unsigned char) srcPnt[i];
        }
        jboolean ret = hook_cacheflush(env, jclazz, pc, sizeOfBridgeJump);
        if (!ret) {
            LOGE("cache flush failed!!");
        }
    } else {
        LOGE("Writing hook failed: Unable to unprotect memory at %d", jumpToAddress);
    }

    if (cookie != 0) {
        LOGI("resume all thread.");
        hook_resumeAll(env, jclazz, cookie);
    }

    env->ReleaseByteArrayElements(code, srcPnt, 0);
    return result;
}



static JNINativeMethod dexposedMethods[] = {

        {"mmap",              "(I)J",                          (void *) hook_mmap},
        {"munmap",            "(JI)Z",                         (void *) hook_munmap},
        {"memcpy",            "(JJI)V",                        (void *) hook_memcpy},
        {"memput",            "([BJ)V",                        (void *) hook_memput},
        {"memget",            "(JI)[B",                        (void *) hook_memget},
        {"munprotect",        "(JJ)Z",                         (void *) hook_munprotect},
        {"changeprotect",     "(JZ)Z",                         (void *) hook_changeprotect},
        {"getMethodAddress",  "(Ljava/lang/reflect/Member;)J", (void *) hook_getMethodAddress},
        {"cacheflush",        "(JJ)Z",                         (void *) hook_cacheflush},
        {"malloc",            "(I)J",                          (void *) hook_malloc},
        {"free",              "(J)V",                          (void *) hook_free},
        {"getObject",         "(JJ)Ljava/lang/Object;",        (void *) hook_getobject},
        {"deleteObject",      "(JLjava/lang/Object;)V",        (void *) hook_deleteobject},
        {"compileMethod",     "(Ljava/lang/reflect/Member;J)Z",(void *) hook_compile},
        {"suspendAll",        "()J",                           (void *) hook_suspendAll},
        {"resumeAll",         "(J)V",                          (void *) hook_resumeAll},
        {"memSetInt",         "(JII)V",                        (void *) hook_memSetInt},
        {"createJump",        "(J)[B",                         (void *) hook_createJump},
        {"activateNative",    "(JJJJ[B)Z",                     (void *) hook_activate},
};

static int registerNativeMethods(JNIEnv *env, const char *className,
                                 JNINativeMethod *gMethods, int numMethods) {

    jclass clazz = env->FindClass(className);
    if (clazz == NULL) {
        return JNI_FALSE;
    }

    if (env->RegisterNatives(clazz, gMethods, numMethods) < 0) {
        return JNI_FALSE;
    }

    return JNI_TRUE;
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {

    JNIEnv *env = NULL;

    if (vm->GetEnv((void **) &env, JNI_VERSION_1_6) != JNI_OK) {
        return -1;
    }

    if (!registerNativeMethods(env, JNIHOOK_CLASS, dexposedMethods,
                               sizeof(dexposedMethods) / sizeof(dexposedMethods[0]))) {
        return -1;
    }

    jclass logUtilClass = env->FindClass("com/tencent/qapmsdk/common/ILogUtil");
    if(logUtilClass!=NULL){
        jfieldID logLevel = env->GetStaticFieldID(logUtilClass, "logLevel", "I");
        if(logLevel!=NULL){
            jint level = env->GetStaticIntField(logUtilClass, logLevel);
            setNativeLogLevel(level);
        }
    }

    init_entries(env);
    return JNI_VERSION_1_6;
}