#include "headers/linklist.h"
#include <stdlib.h>
#include <unistd.h>
#include "hutils.h"

pfilestat createList()
{
	pfilestat head = (pfilestat)calloc(1,sizeof(struct filestat));
	if(head==NULL){
		LOGE("create list failed");
		return NULL;
	}
	head->fd=-1;
	head->next=NULL;
	return head;
}

pfilestat insertNode(pfilestat head, pfilestat node)
{
	if(head==NULL||node==NULL)
	{
		LOGE("insert linklist failed");
		return NULL;
	}
	pfilestat result=findNode(head,node->fd);
	if(result!=NULL){
//		memset(result->filePath,'\0',sizeof(result->filePath));
//		strcpy(result->filePath,node->filePath);
//		result->startTime=node->startTime;
//		result->readCount=0;
//		result->readBytes=0;
//		result->readTime=0;
//		result->writeCount=0;
//		result->writeBytes=0;
//		result->writeTime=0;
//	    memset(result->processName,'\0',sizeof(result->processName));
//	    strcpy(result->processName,node->processName);
//	    memset(result->threadName,'\0',sizeof(result->threadName));
//	    strcpy(result->threadName,node->threadName);
//		memset(result->stackTrace,'\0',sizeof(result->stackTrace));
//		strcpy(result->stackTrace,node->stackTrace);
		//多次使用memset会影响性能，这里我改为一次
		memset(result,0, sizeof(sizeof(struct filestat)- sizeof(pfilestat)));
		result->startTime=node->startTime;
		result->isSQL = node->isSQL;
		strcpy(result->filePath,node->filePath);
		strcpy(result->processName,node->processName);
		strcpy(result->threadName,node->threadName);
		strcpy(result->stackTrace,node->stackTrace);
		free(node);
		node=NULL;
		return result;
	}
	pfilestat temp=head;
	for(;temp->next!=NULL;temp=temp->next){

	}
	temp->next=node;
	return node;
}

int deleteNode(pfilestat head, int fd)
{
	if(head==NULL)
	{
		return -1;
	}
	pfilestat before=head;
	pfilestat cur=head->next;
	while(cur!=NULL){
		if(cur->fd==fd)
		{
			before->next=cur->next;
			//小心内存泄漏
//			free(cur);
			return 0;
		}
		before=cur;
		cur=cur->next;
	}
	return -1;
}
pfilestat findNode(pfilestat head, int fd)
{
	if(head==NULL||head->next==NULL)
	{
//		LOGE("find failed:linklist is null");
		return NULL;
	}
	pfilestat cur=head->next;
	while(cur!=NULL){
		if(cur->fd==fd)
		{
			return cur;
		}
		cur=cur->next;
	}
//	LOGE("find failed:have not this fd");
	return NULL;
}

int deleteList(pfilestat* phead)
{
	if(*phead==NULL)
	{
		LOGE("delete linklist success");
		return 0;
	}
	pfilestat temp=*phead;
	pfilestat var;
	while(temp!=NULL)
	{
		var=temp;
		temp=temp->next;
		free(var);
	}
	*phead=NULL;
	return 0;
}

pfilestat printList(pfilestat head){
//	LOGD("printList begin!");
	if(head==NULL||head->next==NULL)
	{
		LOGE("LinkList is NULL");
		return 0;
	}
	pfilestat temp=head->next;
	int size=0;
	while(temp!=NULL)
	{
		LOGD("printList:%d,%s",temp->fd,temp->filePath);
		temp=temp->next;
		size++;
	}
	LOGD("printList:List size:%d",size);
}

pfilestat makeNode(int fd, const char* filePath,long long startTime){
	pfilestat node=(pfilestat)calloc(1, sizeof(struct filestat));
	node->fd=fd;
	memset(node->filePath,'\0',sizeof(node->filePath));
	if(strlen(filePath)>=300)
	{
		strncpy(node->filePath,filePath,299);
	}else
	{
		strcpy(node->filePath,filePath);
	}
	node->startTime=startTime;
//    node->readCount=0;
//    node->readBytes=0;
//    node->readTime=0;
//    node->writeCount=0;
//    node->writeBytes=0;
//    node->writeTime=0;
//    memset(node->processName,'\0',sizeof(node->processName));
//    memset(node->threadName,'\0',sizeof(node->threadName));
//    memset(node->stackTrace,'\0',sizeof(node->stackTrace));
//    node->next=NULL;
	return node;
}
