#include <stdio.h>
#include "hutils.h"

#define MAX_DEPTH  20    //MAX_DEPTH  31
#define MAX_BACKTRACE_LINE_LENGTH   800
#define PATH "/system/lib/libcorkscrew.so"
#define MAX_THREAD_LEN 100              //线程名的长度 同步修改linklist.h的值
#define MAX_PROCESS_LEN 70              //进程名的长度   同步修改linklist.h的值
#define MAX_FILENAME_LEN 300            //文件名的长度
#define MAX_STACK_LEN 2048              //堆栈的最长长度   同步修改linklist.h的值
#define MAX_FILESIZE_UPLOAD 2000*1024   //文件上报长度
#define SQLINFO_LEN 350+2048            //SQL Detail I/O信息保存的最大长度
#define FILEINFO_LEN  2600              //文件 和 SQL Summary I/O信息保存的最大长度
#define SQLEXPLAIN_LEN 700	            //执行计划保存的最大长度
#define SQLINFO_COUNT 200               //SQL I/O(Detail and Summary)缓存队列的长度  200
#define MAX_LENGTH 200                  //文件IO缓冲队列保存的item长度  200
#define SQL_TYPE_WRITE 0
#define SQL_TYPE_READ 1
#define SUCCEED 0

#define SQLITE_STATUS_MEMORY_USED          0
#define SQLITE_STATUS_PAGECACHE_USED       1
#define SQLITE_STATUS_PAGECACHE_OVERFLOW   2
#define SQLITE_STATUS_SCRATCH_USED         3
#define SQLITE_STATUS_SCRATCH_OVERFLOW     4
#define SQLITE_STATUS_MALLOC_SIZE          5
#define SQLITE_STATUS_PARSER_STACK         6
#define SQLITE_STATUS_PAGECACHE_SIZE       7
#define SQLITE_STATUS_SCRATCH_SIZE         8
#define SQLITE_STATUS_MALLOC_COUNT         9

#define SQLITE_DBSTATUS_LOOKASIDE_USED       0
#define SQLITE_DBSTATUS_CACHE_USED           1
#define SQLITE_DBSTATUS_SCHEMA_USED          2
#define SQLITE_DBSTATUS_STMT_USED            3
#define SQLITE_DBSTATUS_LOOKASIDE_HIT        4
#define SQLITE_DBSTATUS_LOOKASIDE_MISS_SIZE  5
#define SQLITE_DBSTATUS_LOOKASIDE_MISS_FULL  6
#define SQLITE_DBSTATUS_CACHE_HIT            7
#define SQLITE_DBSTATUS_CACHE_MISS           8
#define SQLITE_DBSTATUS_CACHE_WRITE          9
#define SQLITE_DBSTATUS_DEFERRED_FKS        10
#define SQLITE_DBSTATUS_MAX                 10   /* Largest defined DBSTATUS */

#define PROPERTY_VALUE_MAX 92

int writefile_mmap(int savefile_fd, char* filename);
void writefile_orig(int savefile_fd);
void test_mmap();
void writeSQLDetailInfo();
void writeSQLExplainInfo();
void writeSQLSummaryInfo();
void writeSqlMiss();
void writeHitMissInfo();
int renameDirForUpload(char* path);
int checkAndCreatSQLiteDir();
int checkAndCreatFileDir();
int callbackForUpload(char* uploadPath);
int updateWriteToFile();
int getSqlite3Fun();
