#include "jni.h"
#include "android/log.h"
#include "stdio.h"
#include "stdlib.h"
#include <dlfcn.h>

#define ANDROID_SMP 0
#define HAVE_LITTLE_ENDIAN
#include "Common.h"
struct DvmDex;
struct Monitor;
#define INLINE
#include "DexProto.h"
#include "Object.h"
#include <string>
#include "Profile.h"
#include "Debugger.h"
#include "IndirectRefTable.h"
#include "ReferenceTable.h"
#include "Thread.h"
#include "Exception.h"
#include "hutils.h"

/*
 * 在5.0以上没有libdvm.so文件
 * 所以这里的只支持4.4以下系统
 */
#define  ITEMLEN 200
#define MAX_STACK_LEN 2048
#define MAX_THREAD_LEN 100
void *dvm_handle;
Thread* (*my_dvmThreadSelf)() = NULL;
std::string(*my_dvmGetThreadName)(Thread*) = NULL;
extern void *run_handle;
extern JNIEnv* (*getJNIEnvPoint)();
extern int SDK_VERSION;

int getJavaStackTrace(char *stacktrace, int len){

	dvm_handle = dlopen("libdvm.so", RTLD_NOW);
	if(dvm_handle == NULL){
		LOGE("dlopen:libdvm.so [%s]", dlerror());
		return -1;
	}

	void* (*dvmFillInStackTraceInternal)(Thread*, bool, size_t*);
	dvmFillInStackTraceInternal = (void*(*)(Thread*, bool, size_t*))dlsym(dvm_handle, "_Z27dvmFillInStackTraceInternalP6ThreadbPj");
	if(dvmFillInStackTraceInternal == NULL){
		LOGE("dlopen:dvmFillInStackTraceInternal [%s]", dlerror());
		return -1;
	}

	void (*dvmLockThreadList)(Thread*);
	dvmLockThreadList = (void(*)(Thread*))dlsym(dvm_handle, "_Z17dvmLockThreadListP6Thread");
	if(dvmLockThreadList == NULL){
		LOGE("dlopen:dvmLockThreadList [%s]", dlerror());
		return -1;
	}

	void (*dvmUnLockThreadList)();
	dvmUnLockThreadList = (void(*)())dlsym(dvm_handle, "_Z19dvmUnlockThreadListv");
	if(dvmUnLockThreadList == NULL){
		LOGE("dlopen:dvmUnLockThreadList [%s]", dlerror());
		return -1;
	}

	int (*dvmLineNumFromPC)(const Method*, u4);
	dvmLineNumFromPC = (int (*)(const Method*, u4))dlsym(dvm_handle, "dvmLineNumFromPC");
	if(dvmLineNumFromPC == NULL){
		LOGE("dlopen:dvmLineNumFromPC [%s]", dlerror());
		return -1;
	}

	if (my_dvmThreadSelf == NULL){
		my_dvmThreadSelf = (Thread*(*)())dlsym(dvm_handle, "_Z13dvmThreadSelfv");
	}
	if (my_dvmThreadSelf == NULL){
		LOGE("dlopen:my_dvmThreadSelf [%s]", dlerror());
		return -1;
	}

	std::string (*dvmHumanReadableDescriptor)(const char*);
	dvmHumanReadableDescriptor = (std::string (*)(const char*))dlsym(dvm_handle, "_Z26dvmHumanReadableDescriptorPKc");
	if(dvmHumanReadableDescriptor == NULL){
		LOGE("dlopen:dvmHumanReadableDescriptor [%s]", dlerror());
		return -1;
	}
	size_t stackDepth;
	int* traceBuf;
	//the implement of getTraceBuf
	Thread* self = my_dvmThreadSelf();
	if(self == NULL){
		return -1;
	}
	dvmLockThreadList(self);
	traceBuf = (int*)dvmFillInStackTraceInternal(self, false, &stackDepth);
	dvmUnLockThreadList();

	//dvmFillStackTraceElements:but not return to java
	const int* intVals = traceBuf;
	unsigned int i;
//	char stacktrace[2048];
	char tmpstackitem[ITEMLEN];
	int length = 0;
	memset(stacktrace, '\0', sizeof(stacktrace));
	for(i = 0; i < stackDepth; i++){
		if(length > len-ITEMLEN){
		//	LOGE("java stack get the limit");
			break;
		}
		Method* meth = (Method*) *intVals++;
		int pc = *intVals++;

		int lineNumber;
		if(pc == -1)
			lineNumber = 0;
		else
			lineNumber = dvmLineNumFromPC(meth, pc);

		std::string dotName(dvmHumanReadableDescriptor(meth->clazz->descriptor));
		const char* className = dotName.c_str();
		//if className has or not database or SQLiteDatabase
		char* result;
		result = (char*)strstr(className,"JavaMethodHook");
		if(result != NULL){
			memset(stacktrace, '\0', sizeof(stacktrace));
			length = 0;
			continue;
		}
		const char* methodName = meth->name;
		const char* fileName = meth->clazz->sourceFile;

		if(className == NULL)
			className = "<unknown class>";
		if(methodName == NULL)
			methodName = "<unknown method>";

		memset(tmpstackitem, '\0', sizeof(tmpstackitem));

		if(lineNumber == -2){
			snprintf(tmpstackitem, ITEMLEN, "%s.%s(Native Method)->\t", className,methodName);
		}
		else{
			if(fileName == NULL)
				snprintf(tmpstackitem, ITEMLEN,  "%s.%s(Unknown Source)->\t", className, methodName);
			else
				snprintf(tmpstackitem, ITEMLEN, "%s.%s(%s:%d)->\t", className, methodName, fileName, lineNumber);
		}
		strcat(stacktrace,tmpstackitem);
		length += strlen(tmpstackitem);

		if (dvmCheckException(self)) {
			LOGE("dvm exception");
			return -1;
		}
	}
	//free in fillStackTraceElements
	free(traceBuf);
	return 0;
}


/*
 * 获得当前线程名
 */
int getCurThreadName(char* threadName, int len){
	if (dvm_handle == NULL){
		dvm_handle = dlopen("libdvm.so", RTLD_NOW);
	}
	if (dvm_handle == NULL){
		LOGE("dlopen:libdvm.so [%s]", dlerror());
		return -1;
	}

	if (my_dvmThreadSelf == NULL){
		my_dvmThreadSelf = (Thread*(*)())dlsym(dvm_handle, "_Z13dvmThreadSelfv");
	}
	if (my_dvmThreadSelf == NULL){
		LOGE("dlopen:my_dvmThreadSelf [%s]", dlerror());
		return -1;
	}
	Thread* self = my_dvmThreadSelf();
	if (self == NULL){
		return -1;
	}
	if (my_dvmGetThreadName == NULL){
		my_dvmGetThreadName = (std::string(*)(Thread*))dlsym(dvm_handle, "_Z16dvmGetThreadNameP6Thread");
	}
	if (my_dvmGetThreadName == NULL){
		LOGE("dlopen:my_dvmFillInStackTraceInternal [%s]", dlerror());
		return -1;
	}


	std::string threadName_s(my_dvmGetThreadName(self));
    try {
        if(threadName_s.length()>0){
            strncpy(threadName, threadName_s.c_str(), len - 12);
        } else{
            return -1;
        }
    }catch (...){
        return -1;
    }

	u4 threadId = self->threadId;
	char tid2str[10];
	memset(tid2str, '\0', sizeof(tid2str));
	sprintf(tid2str, "&%d", threadId);
	strcat(threadName, tid2str);
	return 0;
}

/*
 * 5.0之上获得堆栈方法
 */
int artGetJavaStack(char * stackTrace){
	if(SDK_VERSION > 23){
        if(getJNIEnvPoint==NULL){
            getJNIEnvPoint = (JNIEnv* (*)())dlsym_abs_for_a7("_ZN7android14AndroidRuntime9getJNIEnvEv","/system/lib/libandroid_runtime.so");
        }
    }else{
    	if(run_handle==NULL){
			run_handle = dlopen("/system/lib/libandroid_runtime.so", RTLD_NOW);
			if(run_handle==NULL){
				LOGE("dlopen runtime.so error");
				return -1;
			}
			getJNIEnvPoint =(JNIEnv* (*)())dlsym(run_handle,"_ZN7android14AndroidRuntime9getJNIEnvEv");
		}
    }
	
	if(getJNIEnvPoint==NULL){
        LOGE("get getJNIEnv method is NULL");
        return -1;
    }
	JNIEnv* env = getJNIEnvPoint();
    if(env==NULL){
    	LOGE("env is NULL");
    	return -1;
    }
	try{
		jclass threadClass = env->FindClass("java/lang/Thread");
		if(threadClass==NULL)
		{
			LOGE("Find Class java/lang/Thread Failed");
			return -1;
		}
		jmethodID currentThreadMethod = env->GetStaticMethodID(threadClass,"currentThread","()Ljava/lang/Thread;");
		if(currentThreadMethod==NULL)
		{
			env->DeleteLocalRef(threadClass);
			return -1;
		}
		jobject curthread = (jobject)env->CallStaticObjectMethod(threadClass,currentThreadMethod);
		if(curthread==NULL)
		{
			env->DeleteLocalRef(threadClass);
			return -1;
		}

		jmethodID getstacktraceMethod = env->GetMethodID(threadClass, "getStackTrace", "()[Ljava/lang/StackTraceElement;");
		if(getstacktraceMethod==NULL)
		{
			env->DeleteLocalRef(curthread);
			env->DeleteLocalRef(threadClass);
			return -1;
		}
		//5.0之上pread64函数这里出现anr
		jobjectArray stacktraceList = (jobjectArray)env->CallObjectMethod(curthread, getstacktraceMethod);
		if(stacktraceList==NULL)
		{
			env->DeleteLocalRef(curthread);
			env->DeleteLocalRef(threadClass);
			return -1;
		}
		jsize length = env->GetArrayLength(stacktraceList);
		if(length==NULL || length==0)
		{
			LOGE("shit, stack length is zero");
			env->DeleteLocalRef(stacktraceList);
			env->DeleteLocalRef(curthread);
			env->DeleteLocalRef(threadClass);
			return -1;
		}
		env->DeleteLocalRef(curthread);
		env->DeleteLocalRef(threadClass);
		//获取StackTraceElement的类
		jclass classStackTraceElement = env->FindClass("java/lang/StackTraceElement");
		if(classStackTraceElement==NULL)
		{
			LOGE("Find java/lang/StackTraceElement Class Failed");
			env->DeleteLocalRef(stacktraceList);
			return -1;
		}
		jmethodID toStringMethod = env->GetMethodID(classStackTraceElement, "toString","()Ljava/lang/String;");
		if(toStringMethod==NULL)
		{
			env->DeleteLocalRef(stacktraceList);
			env->DeleteLocalRef(classStackTraceElement);
			return -1;
		}
		jsize i = 1;
		int size=0;
		env->DeleteLocalRef(classStackTraceElement);
		if(length>20)
			length=20;
		const char* content;
		jstring stackString;
		jobject element;
		for(;i<length;i++){
			element = env->GetObjectArrayElement(stacktraceList,i);
			stackString = (jstring)env->CallObjectMethod(element,toStringMethod);
			content = env->GetStringUTFChars(stackString,0);
			size+=strlen(content);
			if(size>1600){
				LOGE("java stack has get limit,now length is:%d",size);
				strcat(stackTrace,"->\t");
				break;
			}
			strcat(stackTrace,content);
			strcat(stackTrace,"->\t");
			env->ReleaseStringUTFChars(stackString, content);
			env->DeleteLocalRef(stackString);
			env->DeleteLocalRef(element);
		}
	}
	catch (...){
		return -1;
	}
    return 0;
}

/*
 * 5.0之上获得线程名称
 */
int artGetThreadName(char* threadName)
{
	if(SDK_VERSION > 23){
        if(getJNIEnvPoint==NULL){
            getJNIEnvPoint = (JNIEnv* (*)())dlsym_abs_for_a7("_ZN7android14AndroidRuntime9getJNIEnvEv","/system/lib/libandroid_runtime.so");
        }
    }else{
    	if(run_handle==NULL){
			run_handle = dlopen("/system/lib/libandroid_runtime.so", RTLD_NOW);
			if(run_handle==NULL){
				LOGE("dlopen runtime.so error");
				return -1;
			}
			getJNIEnvPoint =(JNIEnv* (*)())dlsym(run_handle,"_ZN7android14AndroidRuntime9getJNIEnvEv");
		}
    }
	if(getJNIEnvPoint==NULL){
		LOGE("get getJNIEnv method is NULL");
		return -1;
	}
	JNIEnv* env = getJNIEnvPoint();
    if(env==NULL){
    	LOGE("env is NULL");
    	return -1;
    }

	//begin to get thread name
    jthrowable exc = env->ExceptionOccurred();
    if(exc) {
        env->ExceptionDescribe();
        env->ExceptionClear();
        LOGE("dvm occur error");
		env->DeleteLocalRef(exc);
        return -1;
    }
	jclass threadClass = env->FindClass("java/lang/Thread");
	if(threadClass==NULL)
	{
		LOGE("Find Class java/lang/Thread Failed");
		return -1;
	}
	jmethodID currentThreadMethod = env->GetStaticMethodID(threadClass,"currentThread","()Ljava/lang/Thread;");
	if(currentThreadMethod==NULL)
	{
		env->DeleteLocalRef(threadClass);
		return -1;
	}
	jobject curthread = (jobject)env->CallStaticObjectMethod(threadClass,currentThreadMethod);
	if(curthread==NULL)
	{
		env->DeleteLocalRef(threadClass);
		return -1;
	}
	jmethodID getNameMethod = env->GetMethodID(threadClass,"getName","()Ljava/lang/String;");
	if(getNameMethod==NULL)
	{
		env->DeleteLocalRef(curthread);
		env->DeleteLocalRef(threadClass);
		return -1;
	}
	jmethodID getThreadId = env->GetMethodID(threadClass,"getId","()J");
	if(getThreadId==NULL)
	{
		env->DeleteLocalRef(curthread);
		env->DeleteLocalRef(threadClass);
		return -1;
	}
	env->DeleteLocalRef(threadClass);
	jstring Name=(jstring)env->CallObjectMethod(curthread,getNameMethod);
	if(Name==NULL)
	{
		env->DeleteLocalRef(curthread);
		return -1;
	}
	jlong tid = env->CallLongMethod(curthread,getThreadId);
	if(tid==NULL)
	{
		env->DeleteLocalRef(Name);
		env->DeleteLocalRef(curthread);
		return -1;
	}
	char tid2str[10];
	memset(tid2str,'\0',sizeof(tid2str));
	sprintf(tid2str,"&%ld",tid);
	const char* threadTemp = env->GetStringUTFChars(Name,0);
	if(threadTemp==NULL)
	{
		env->ReleaseStringUTFChars(Name, threadTemp);
		env->DeleteLocalRef(Name);
		env->DeleteLocalRef(curthread);
		return -1;
	}
	strncpy(threadName,threadTemp, MAX_THREAD_LEN-15);
	strcat(threadName,tid2str);
	env->ReleaseStringUTFChars(Name, threadTemp);
	env->DeleteLocalRef(Name);
	env->DeleteLocalRef(curthread);
	return 0;
}
