#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <dirent.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <sys/ptrace.h>
#include <unistd.h>
#include <dlfcn.h>

#include "relocate_a.h"
#include "inlinehook_a.h"
#include "innerdefs.h"
extern "C"{
#include "hutils.h"
}
static struct inlineHookInfo info = {0};

#ifdef __arm__

////清理缓存
//long cacheflush(uint32_t addr, size_t len){
//    void *end = (uint8_t*)addr + len;
//    return syscall(0xf0002, addr, end);
//}

static bool isExecutableAddr(uint32_t addr)
{
	FILE *fp;
	char line[1024];
	uint32_t start;
	uint32_t end;

	fp = fopen("/proc/self/maps", "r");
	if (fp == NULL) {
		return false;
	}

	while (fgets(line, sizeof(line), fp)) {
		if (strstr(line, "r-xp") || strstr(line, "rwxp")) {
			start = strtoul(strtok(line, "-"), NULL, 16);
			end = strtoul(strtok(NULL, " "), NULL, 16);
			if (addr >= start && addr <= end) {
				fclose(fp);
				return true;
			}
		}
	}

	fclose(fp);

	return false;
}

static struct inlineHookItem *findInlineHookItem(uint32_t target_addr)
{
	int i;

	for (i = 0; i < info.size; ++i) {
		if (info.item[i].target_addr == target_addr) {
			return &info.item[i];
		}
	}

	return NULL;
}

static struct inlineHookItem *addInlineHookItem() {
	struct inlineHookItem *item;

	if (info.size >= 1024) {
		return NULL;
	}

	item = &info.item[info.size];
	++info.size;

	return item;
}

static void deleteInlineHookItem(int pos)
{
	info.item[pos] = info.item[info.size - 1];
	--info.size;
}

static void doInlineUnHook(struct inlineHookItem *item, int pos)
{
	mprotect((void *) PAGE_START(CLEAR_BIT0(item->target_addr)), PAGE_SIZE*2, PROT_READ | PROT_WRITE | PROT_EXEC);
	memcpy((void *) CLEAR_BIT0(item->target_addr), item->orig_instructions, item->length);
	mprotect((void *) PAGE_START(CLEAR_BIT0(item->target_addr)), PAGE_SIZE*2, PROT_READ | PROT_EXEC);
	munmap(item->trampoline_instructions, PAGE_SIZE);
	free(item->orig_instructions);

	deleteInlineHookItem(pos);

	cacheflush(CLEAR_BIT0(item->target_addr), CLEAR_BIT0(item->target_addr) + item->length, 0);
}

static bool doInlineHook(struct inlineHookItem *item)
{
	mprotect((void *) PAGE_START(CLEAR_BIT0(item->target_addr)), PAGE_SIZE*2, PROT_READ | PROT_WRITE | PROT_EXEC);
	if (item->proto_addr != NULL) {
		*(item->proto_addr) = TEST_BIT0(item->target_addr) ? (uint32_t *) SET_BIT0((uint32_t) item->trampoline_instructions) : (uint32_t *)item->trampoline_instructions;
	}
	else{
		return false;
	}
	if (TEST_BIT0(item->target_addr)) {
		int i;

		i = 0;
		if (CLEAR_BIT0(item->target_addr) % 4 != 0) {
			((uint16_t *) CLEAR_BIT0(item->target_addr))[i++] = 0xBF00;  // NOP
		}
		((uint16_t *) CLEAR_BIT0(item->target_addr))[i++] = 0xF8DF;
		((uint16_t *) CLEAR_BIT0(item->target_addr))[i++] = 0xF000;	// LDR.W PC, [PC]
		((uint16_t *) CLEAR_BIT0(item->target_addr))[i++] = item->new_addr & 0xFFFF;
		((uint16_t *) CLEAR_BIT0(item->target_addr))[i++] = item->new_addr >> 16;
	}
	else {
		((uint32_t *) (item->target_addr))[0] = 0xe51ff004;	// LDR PC, [PC, #-4]
		((uint32_t *) (item->target_addr))[1] = item->new_addr;
	}

	mprotect((void *) PAGE_START(CLEAR_BIT0(item->target_addr)), PAGE_SIZE*2, PROT_READ | PROT_EXEC);


	item->status = HOOKED;

	cacheflush(CLEAR_BIT0(item->target_addr), CLEAR_BIT0(item->target_addr) + item->length, 0);
	return true;
}

static int registerInlineHook(uint32_t target_addr, uint32_t new_addr, uint32_t **proto_addr)
{
	struct inlineHookItem *item;

	if (!isExecutableAddr(target_addr) || !isExecutableAddr(new_addr)) {
		return E_I_A_NOT_EXECUTABLE;
	}

	item = findInlineHookItem(target_addr);
	if (item != NULL) {
		if (item->status == REGISTERED) {
			return E_I_A_ALREADY_REGISTERED;
		}
		else if (item->status == HOOKED) {
			return E_I_A_ALREADY_HOOKED;
		}
		else {
			return E_I_A_UNKNOWN;
		}
	}

	item = addInlineHookItem();

	item->target_addr = target_addr;
	item->new_addr = new_addr;
	item->proto_addr = proto_addr;

	item->length = TEST_BIT0(item->target_addr) ? 12 : 8;
	item->orig_instructions = malloc(item->length);
	memcpy(item->orig_instructions, (void*) CLEAR_BIT0(item->target_addr), item->length);

	//这里分为两部分处理，当oat_header_size不为0的时候表明是art用的inlinehook

	item->trampoline_instructions = mmap(NULL, PAGE_SIZE, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_ANONYMOUS | MAP_PRIVATE, 0, 0);

	if(item->trampoline_instructions == MAP_FAILED){
		return E_MMAPFAILED;
	}
	relocateInstruction(item->target_addr, item->orig_instructions, item->length, item->trampoline_instructions, item->orig_boundaries, item->trampoline_boundaries, &item->count);

	item->status = REGISTERED;

	return SUCCEED;
}


static JumpInfo*  generateJumpBlock(uint32_t target_addr){
	struct inlineHookItem *item;
	if (!isExecutableAddr(target_addr)) {
		LOGD("no executable");
		return NULL;
	}
	item = findInlineHookItem(target_addr);
	if (item != NULL) {
		if (item->status == REGISTERED) {
			return NULL;
		}
		else if (item->status == HOOKED) {
			return NULL;
		}
		else {
			return NULL;
		}
	}

	item = addInlineHookItem();
	item->target_addr = target_addr;
	item->length = TEST_BIT0(item->target_addr) ? 12 : 8;
	item->orig_instructions = malloc(item->length);
	memcpy(item->orig_instructions, (void*) CLEAR_BIT0(item->target_addr), item->length);

	item->trampoline_instructions = mmap(NULL, PAGE_SIZE, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_ANONYMOUS | MAP_PRIVATE, 0, 0);

	if(item->trampoline_instructions == MAP_FAILED){
		LOGE("mmap error, hook suspend");
		return NULL;
	}
	int trampoline_size = relocateInstruction(item->target_addr, item->orig_instructions, item->length, item->trampoline_instructions, item->orig_boundaries, item->trampoline_boundaries, &item->count);
	JumpInfo* ret = new JumpInfo();
	jbyte* byte_array = new jbyte[trampoline_size];
	for(int i = 0; i < trampoline_size; i++){
		byte_array[i] = ((jbyte*)item->trampoline_instructions)[i];
	}
	ret->byte_array = byte_array;
	ret->array_len = trampoline_size;

	item->status = REGISTERED;
	//清理内存环境
	for (int i = 0; i < info.size; ++i) {
		if (info.item[i].target_addr == target_addr && info.item[i].status == REGISTERED) {
			munmap(info.item[i].trampoline_instructions, PAGE_SIZE);
			info.item[i] = info.item[info.size - 1];
	        --info.size;
		}
	}
	return ret;
}

static int inlineHook(uint32_t target_addr)
{
	int i;
	struct inlineHookItem *item;

	item = NULL;
	for (i = 0; i < info.size; ++i) {
		if (info.item[i].target_addr == target_addr) {
			item = &info.item[i];
			break;
		}
	}

	if (item == NULL) {
		return E_I_A_NOT_REGISTERED;
	}

	if (item->status == REGISTERED) {

		doInlineHook(item);

		return SUCCEED;
	}
	else if (item->status == HOOKED) {
		return E_I_A_ALREADY_HOOKED;
	}
	else {
		return E_I_A_UNKNOWN;
	}
}

static int  inlineHookAll()
{
	int i;

	for (i = 0; i < info.size; ++i) {
		if (info.item[i].status == REGISTERED) {
			bool ok = doInlineHook(&info.item[i]);
			if(!ok)
			{
                return -1;				
			}
		}
	}
    return 0;
}

static int inlineUnHook(uint32_t target_addr)
{
	int i;
	for (i = 0; i < info.size; ++i) {
		if (info.item[i].target_addr == target_addr && info.item[i].status == HOOKED) {

			doInlineUnHook(&info.item[i], i);

			return SUCCEED;
		}
	}

	return E_I_A_NOT_HOOKED;
}

static void inlineUnHookAll()
{
	pid_t pid;
	int i;

	for (i = 0; i < info.size; ++i) {
		if (info.item[i].status == HOOKED) {
			doInlineUnHook(&info.item[i], i);
			--i;
		}
	}

}

#endif

extern "C" {
	int __attribute__ ((visibility ("default"))) registerInlineHook_a(uint32_t target_addr, uint32_t new_addr, uint32_t **proto_addr){
	#ifdef __arm__
		return registerInlineHook(target_addr, new_addr, proto_addr);
	#else
		return E_I_A_NOT_SUPPORT_X86;
	#endif
	
	}


	JumpInfo* __attribute__ ((visibility ("default"))) createJumpBlock(uint32_t target_addr){
		#ifdef __arm__
			return generateJumpBlock(target_addr);
		#else
			return NULL;
		#endif
	}
	
	int inlineHook_a(uint32_t target_addr){
	#ifdef __arm__
		return inlineHook(target_addr);
	#else
		return E_I_A_NOT_SUPPORT_X86;
	#endif
	}
	
	int __attribute__ ((visibility ("default"))) inlineHookAll_a(){
	#ifdef __arm__
		return inlineHookAll();
	#endif
	}
	
	int inlineUnHook_a(uint32_t target_addr){
	#ifdef __arm__
		return inlineUnHook(target_addr);
	#else
		return E_I_A_NOT_SUPPORT_X86;
	#endif
	}
	
	void inlineUnHookAll_a(){
	#ifdef __arm__
		inlineUnHookAll();
	#endif
	}

}
