#include <jni.h>
#include <stdio.h>
#include <string.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <vector>
#include "hutils.h"


#define DUMPHOOKSIZE 2
#define SUCCEED 0
char* dump_hook_func[] = {
	"_Z22hprofAddU1ListToRecordP14hprof_record_tPKhj",
	"_Z26hprofAddUtf8StringToRecordP14hprof_record_tPKc"
};
void *dump_old_fun[DUMPHOOKSIZE];

typedef uint8_t u1;
typedef uint32_t u4;

enum HprofHeapId {
	HPROF_HEAP_DEFAULT = 0,
	HPROF_HEAP_ZYGOTE = 'Z',
	HPROF_HEAP_APP = 'A'
};

struct hprof_record_t {
	unsigned char *body;
	u4 time;
	u4 length;
	size_t allocLen;
	u1 tag;
	bool dirty;
};

struct hprof_context_t {
	hprof_record_t curRec;

	u4 gcThreadSerialNumber;
	u1 gcScanState;
	HprofHeapId currentHeap;    // which heap we're currently emitting
	u4 stackTraceSerialNumber;
	size_t objectsInSegment;

	bool directToDdms;
	char *fileName;
	char *fileDataPtr;          // for open_memstream
	size_t fileDataSize;        // for open_memstream
	FILE *memFp;
	int fd;
};


class HprofRecord{

public:
    size_t alloc_length_;
    unsigned char* body_;

    FILE* fp_;
    uint8_t tag_;
    uint32_t time_;
    size_t length_;
    bool dirty_;
};

#define U4_TO_BUF_BE(buf, offset, value) \
do {\
	unsigned char *buf_ = (unsigned char *)(buf); \
	int offset_ = (int)(offset); \
	u4 value_ = (u4)(value); \
	buf_[offset_ + 0] = (unsigned char)(value_ >> 24); \
	buf_[offset_ + 1] = (unsigned char)(value_ >> 16); \
	buf_[offset_ + 2] = (unsigned char)(value_ >> 8); \
	buf_[offset_ + 3] = (unsigned char)(value_); \
} while (0)

int my_hprofAddU1ListToRecord(hprof_record_t *rec, const u1* values, size_t numValues){
	unsigned char* insert;
	u1 curLen[8] = { 55, 66, 77, 88, 0, 0, 0, 0 };
	insert = rec->body + rec->length - 5;
	memcpy(curLen + 4, (char*)insert, 4);

	numValues = 8;
	U4_TO_BUF_BE(insert, 0, (u4)numValues);
	return ((int(*)(hprof_record_t *, const u1*, size_t))dump_old_fun[0])(rec, curLen, numValues);
}

int my_hprofAddUtf8StringToRecord(hprof_record_t *rec, const char* str){
	return ((int(*)(hprof_record_t *, const u1*, size_t))dump_old_fun[0])(rec, (const u1*)str, strlen(str));
}

int (*old_AddU1List)(HprofRecord*,const uint8_t*,size_t) = NULL;
int my_AddU1List(HprofRecord* pHprofRecord,const uint8_t* values, size_t numValues)
{
    unsigned char* insert;
    u1 curLen[8] = { 55, 66, 77, 88, 0, 0, 0, 0 };
    insert = pHprofRecord->body_ + pHprofRecord->length_ - 5;
    memcpy(curLen + 4, (char*)insert, 4);
    numValues = 8;
    U4_TO_BUF_BE(insert, 0, (u4)numValues);
    return old_AddU1List(pHprofRecord,curLen,numValues);
}


class EndianOutput{
public:
    void* vtable;   //因为该类有虚函数，所以这里是虚表指针
    size_t length_;      // Current record size.
    size_t sum_length_;  // Size of all data.
    size_t max_length_;  // Maximum seen length.
    bool started_;       // Was StartRecord called?
    std::vector<uint8_t> buffer_;
};

void (*old_HandleU1List)(EndianOutput* pEndianOutput, uint8_t* values, size_t count) = NULL;
void my_HandleU1List(EndianOutput* pEndianOutput,uint8_t* values, size_t count)
{
    if(count<100)
    {
        old_HandleU1List(pEndianOutput,values,count);
        return;
    }
    uint8_t curLen[8] = {55, 66, 77, 88, 0, 0, 0, 0 };
    memcpy(curLen+4,&count, 4);

    //这里更改buffer length
    pEndianOutput->buffer_[pEndianOutput->buffer_.size()-5] = 0;
    pEndianOutput->buffer_[pEndianOutput->buffer_.size()-4] = 0;
    pEndianOutput->buffer_[pEndianOutput->buffer_.size()-3] = 0;
    pEndianOutput->buffer_[pEndianOutput->buffer_.size()-2] = 8;

    pEndianOutput->buffer_.insert(pEndianOutput->buffer_.end(), curLen, curLen + 8);
    //因为主调函数AddU1List会把length_ += count，minidump之后count降为8，但是参数count仍未改变，所以此处得-count然后+8，保证length正确
    pEndianOutput->length_ = pEndianOutput->length_ - count + 8;
}

void hookForMiniDump(int apilevel){
	//Android 5.0以下
	if(apilevel<21){
		void *handle;
		void *fun;
		int i;
		handle = dlopen("libdvm.so", RTLD_NOW);
		if (handle == NULL){
			LOGE("dlopen libdvm.so failed");
			return;
		}
		void *new_fun[DUMPHOOKSIZE];
		new_fun[0] = (void*)my_hprofAddU1ListToRecord;
		new_fun[1] = (void*)my_hprofAddUtf8StringToRecord;
		for (i = 0; i < DUMPHOOKSIZE; i++){
			fun = dlsym(handle, dump_hook_func[i]);
			if (fun == NULL){
				LOGE("dlsym fun[%s] failed", dump_hook_func[i]);
				return;
			}
			if (registerInlineHook_a((uint32_t)fun, (uint32_t)new_fun[i], (uint32_t **)(dump_old_fun + i)) != SUCCEED) {
				LOGE("registerInlineHook failed!");
				return;
			}
		}
	//Android 5.0 and 5.1
	}else if(apilevel<23){
		void* handle = dlopen("libart.so",RTLD_NOW);
		if (handle == NULL){
			LOGE("dlopen libart.so failed");
			return;
		}
		//这里AddU1List没有导出符号
		void* AddU1List = dlsym_abs("_ZN3art5hprof11HprofRecord9AddU1ListEPKhj","/system/lib/libart.so");

		if(AddU1List==NULL){
			LOGE("dlsym_abs AddU1List failed.");
			return;
		}
		if (registerInlineHook_a((uint32_t)AddU1List, (uint32_t)my_AddU1List, (uint32_t **)&old_AddU1List) != SUCCEED) {
			LOGE("registerInlineHook failed!");
			return;
		}
	//Android 6.0 and Android 7.0
	}else if(apilevel<26)
	{
		void* HandleU1List = NULL;
		if(apilevel<24)
		{
			HandleU1List = dlsym_abs("_ZN3art5hprof20EndianOutputBuffered12HandleU1ListEPKhj","/system/lib/libart.so");
		}else
		{
			HandleU1List = dlsym_abs_for_a7("_ZN3art5hprof20EndianOutputBuffered12HandleU1ListEPKhj","/system/lib/libart.so");
		}
		if(HandleU1List==NULL)
		{
			LOGE("connot find HandleU1List.");
			return;
		}
		if (registerInlineHook_a((uint32_t)HandleU1List, (uint32_t)my_HandleU1List, (uint32_t **)&old_HandleU1List) != SUCCEED) {
			LOGE("registerInlineHook failed!");
			return;
		}
	}else{
		LOGE("your phone not support minidump now.");
		return;
	}

	inlineHookAll_a();
}

void unhookForMiniDump(){
	inlineUnHookAll_a();
}

extern "C"{

	//加载miniDump
	JNIEXPORT void JNICALL Java_com_tencent_qapmsdk_memory_MiniDumpConfig_loadMiniDump(JNIEnv* env, jclass clazz,jint apilevel) {
		hookForMiniDump((int)apilevel);
		LOGD("hookForMiniDump called");
	}

	//卸载miniDump
	JNIEXPORT void JNICALL Java_com_tencent_qapmsdk_memory_MiniDumpConfig_unloadMiniDump(JNIEnv* env, jclass clazz) {
		unhookForMiniDump();
		LOGD("unload minidump");
	}
}
