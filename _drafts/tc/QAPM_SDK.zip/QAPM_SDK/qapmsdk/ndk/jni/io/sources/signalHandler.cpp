#include <stdio.h>
#include <android/log.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <pthread.h>
#include <dirent.h>
#include <fstream>
#include <stdlib.h>
#include <sys/stat.h>
#include "hutils.h"
#include "headers/signalHandler.h"
#include "headers/libunwind.h"
#include "headers/compiler.h"
/* Signals to be caught. */
#define SIG_CATCH_COUNT 2
static const int nativeSignalCatch[SIG_CATCH_COUNT + 1] = { SIGBUS, SIGSEGV, 0};
#define tdep_trace(cur,addr,n)		(-UNW_ENOINFO)

/* Global crash handler structure. */
NativeCodeGlobal   g_nativeCode = NATIVE_CODE_GLOBAL_INITIALIZER;
NativeCodeHandler* g_nativeCodeHandler = NULL;
pthread_key_t nativeCodeThread;
int (*Uarm_init_local)(unw_cursor_t *, unw_context_t *) = NULL;
int (*Uarm_get_reg)(unw_cursor_t *, int, unw_word_t *) = NULL;
int (*Uarm_step)(unw_cursor_t *) = NULL;


char crashFilePath[128] = {0};

static NativeCodeHandler* getCrashHandler() {
    return g_nativeCodeHandler;
}

/**
 * libname:函数所在的so文件名
 * symName:函数名称
 * pc:崩溃处的pc值
 * symAddr:崩溃处所属函数的地址
 */
void crashProtect(char* libName,char* symName,void* pc,void* symAddr)
{
	if(libName==NULL||pc==NULL)
	{
		return;
	}
	if(!strstr(libName,"libapmioFake.so")||!strstr(libName,"libapmart.so")||!strstr(libName,"libapmdalvik.so"))
	{
		//TODO:处理

		if(strlen(crashFilePath)==0)
		{
			return;
		}

		FILE *fp = NULL;
		fp = fopen(crashFilePath, "w+");
		if(fp == NULL)
		{
			LOGE("cannot create %s",crashFilePath);
			return;
		}
		fprintf(fp,"%s=%s\n", "crash", "1");
		fclose(fp);
	}
}

/*
 * 5.0之上系统使用libunwind.so文件，但是自己实现堆栈解析
 */
void coffee_getcontext(unw_context_t* puc, void* reserved)
{
    //platform specific voodoo to build a context for libunwind
    //cast/extract the necessary structures
    ucontext_t* context = (ucontext_t*)reserved;
    unw_tdep_context_t *unw_ctx = (unw_tdep_context_t*)puc;
    struct sigcontext* sig_ctx = &context->uc_mcontext;
    // we need to store all the general purpose registers so that libunwind can resolve
    // the stack correctly, so we read them from the sigcontext into the unw_context
    unw_ctx->regs[UNW_ARM_R0] = sig_ctx->arm_r0;
    unw_ctx->regs[UNW_ARM_R1] = sig_ctx->arm_r1;
    unw_ctx->regs[UNW_ARM_R2] = sig_ctx->arm_r2;
    unw_ctx->regs[UNW_ARM_R3] = sig_ctx->arm_r3;
    unw_ctx->regs[UNW_ARM_R4] = sig_ctx->arm_r4;
    unw_ctx->regs[UNW_ARM_R5] = sig_ctx->arm_r5;
    unw_ctx->regs[UNW_ARM_R6] = sig_ctx->arm_r6;
    unw_ctx->regs[UNW_ARM_R7] = sig_ctx->arm_r7;
    unw_ctx->regs[UNW_ARM_R8] = sig_ctx->arm_r8;
    unw_ctx->regs[UNW_ARM_R9] = sig_ctx->arm_r9;
    unw_ctx->regs[UNW_ARM_R10] = sig_ctx->arm_r10;
    unw_ctx->regs[UNW_ARM_R11] = sig_ctx->arm_fp;
    unw_ctx->regs[UNW_ARM_R12] = sig_ctx->arm_ip;
    unw_ctx->regs[UNW_ARM_R13] = sig_ctx->arm_sp;
    unw_ctx->regs[UNW_ARM_R14] = sig_ctx->arm_lr;
    unw_ctx->regs[UNW_ARM_R15] = sig_ctx->arm_pc;
}

//这里将PC值转化为PC所在的函数
Dl_info* PC2DLName(void * const addr) {
    if (addr != 0) {
        Dl_info* info = (Dl_info*)malloc(sizeof(Dl_info));
        if (dladdr(addr, info) != 0 && info->dli_fname != NULL) {
            return info;
        }
    }
    return NULL;
}

static ALWAYS_INLINE int slow_backtrace (void **buffer, int size, unw_context_t *uc)
{
    unw_cursor_t cursor;
    unw_word_t ip;
    unw_word_t sp;
    int n = 0;
    if(Uarm_init_local == NULL)
    {
        LOGE("cannot find Uarm_init_local.");
        return 0;
    }
    if (unlikely (Uarm_init_local(&cursor, uc) < 0)) {
        LOGD("unw_init_local error");
        return 0;
    }

    int stepRet = 0;
    int getRegRet = 0;
    uintptr_t preIp = 0;

    do {
        if (n >= size)
            return n;

        if(Uarm_get_reg == NULL)
        {
            LOGE("cannot find Uarm_get_reg.");
            return 0;
        }
        if ((getRegRet = Uarm_get_reg(&cursor, UNW_REG_IP, &ip)) < 0) {
            LOGE("Fail to read IP %d", getRegRet);
            return n;
        }

        if ((getRegRet = Uarm_get_reg(&cursor, UNW_REG_SP, &sp)) < 0) {
            LOGE("Fail to read SP %d", getRegRet);
            return n;
        }

        buffer[n++] = (void*)(uintptr_t)ip;
        Dl_info* info = PC2DLName((void*)ip);
        if(info!=NULL)
        {
//            LOGD("%s,%s", info->dli_fname,info->dli_sname);
        	crashProtect((char*)info->dli_fname,(char*)info->dli_sname,(void*)ip,(void*)info->dli_saddr);
        }

        free(info);
        //栈从高向低生长，所以上一层栈帧的pc必须位于更高地址
        if (preIp >= ip) {
            break;
        }
        //Fixme: unw_step有偶现的crash, 两次pc相差太大就停止解堆栈
        if (preIp != 0 && ip - preIp > 0xD00000) {
            LOGI("Stop cause gap is too large, ip: 0x%x preIp: 0x%x", ip, preIp);
            break;
        }

        preIp = ip;
    } while ((stepRet = Uarm_step(&cursor)) > 0);

    return n;
}

int getStackTrace(void **buffer, int size, void* sc){
    unw_cursor_t cursor;
    unw_context_t uc;
    int n = size;
    if(Uarm_init_local == NULL)
    {
        LOGE("Uarm_init_local is null.");
        return 0;
    }
    coffee_getcontext(&uc, sc);
    if (unlikely (Uarm_init_local(&cursor, &uc) < 0))
        return 0;

    if (unlikely (tdep_trace(&cursor, buffer, &n) < 0))
    {
        coffee_getcontext(&uc, sc);
        return slow_backtrace(buffer, size, &uc);
    }

    return n;
}

bool initUnwind()
{
    void* unwindHandle = dlopen("libunwind.so", RTLD_LAZY | RTLD_LOCAL);
    if(unwindHandle==NULL)
    {
        LOGE("cannot dlopen libunwind.so.");
        return false;
    }
    Uarm_init_local = (int(*)(unw_cursor_t *,unw_context_t *))dlsym(unwindHandle,"_Uarm_init_local");
    Uarm_get_reg = (int(*)(unw_cursor_t *, int, unw_word_t *))dlsym(unwindHandle,"_Uarm_get_reg");
    Uarm_step = (int(*)(unw_cursor_t* ))dlsym(unwindHandle,"_Uarm_step");
    if(!Uarm_init_local||!Uarm_get_reg||!Uarm_step)
    {
        LOGE("cannot find unwind functions.");
        return false;
    }
    return true;
}

/* Use libunwind to get a backtrace inside a signal handler.
   Will only return a non-zero code on Android >= 5 (with libunwind.so
   being shipped) */

ssize_t unwind_signal(void* sc, void** frames, size_t max_depth) {
    if(!initUnwind())
    {
        return 0;
    }
    return getStackTrace(frames, max_depth, sc);;
}


/*******************************************************************/

//5.0 系统之下
size_t backtrace_signal(siginfo_t* si, void* sc,
                        backtrace_frame_t* frames,
                        size_t ignore_depth,
                        size_t max_depth) {
    void *const libcorkscrew = dlopen("libcorkscrew.so", RTLD_LAZY | RTLD_LOCAL);
    if (libcorkscrew != NULL) {
        t_unwind_backtrace_signal_arch unwind_backtrace_signal_arch = (t_unwind_backtrace_signal_arch) dlsym(libcorkscrew, "unwind_backtrace_signal_arch");
        t_acquire_my_map_info_list acquire_my_map_info_list = (t_acquire_my_map_info_list) dlsym(libcorkscrew, "acquire_my_map_info_list");
        t_release_my_map_info_list release_my_map_info_list = (t_release_my_map_info_list) dlsym(libcorkscrew, "release_my_map_info_list");
        t_get_backtrace_symbols get_backtrace_symbols = (t_get_backtrace_symbols)dlsym(libcorkscrew,"get_backtrace_symbols");
        t_free_backtrace_symbols free_backtrace_symbols = (t_free_backtrace_symbols)dlsym(libcorkscrew,"free_backtrace_symbols");

        if (unwind_backtrace_signal_arch != NULL && acquire_my_map_info_list != NULL && release_my_map_info_list != NULL) {
            map_info_t*const info = acquire_my_map_info_list();
            const ssize_t size = unwind_backtrace_signal_arch(si, sc, info, frames, ignore_depth, max_depth);

            backtrace_symbol_t *symbles = (backtrace_symbol_t*)malloc(size* sizeof(backtrace_symbol_t));

            get_backtrace_symbols(frames,size,symbles);
            for(int i=0;i<size;i++)
            {
//                LOGD("%s,%s",symbles[i].map_name,symbles[i].symbol_name);
            	crashProtect((char*)symbles[i].map_name,(char*)symbles[i].symbol_name,(void*)symbles[i].relative_pc,(void*)symbles[i].relative_symbol_addr);
            }
            free_backtrace_symbols(symbles,size);
            free(symbles);
            release_my_map_info_list(info);
            return size >= 0 ? size : 0;
        } else {
            LOGE("symbols not found in libcorkscrew.so\n");
        }
        dlclose(libcorkscrew);
    } else {
        LOGE("libcorkscrew.so could not be loaded\n");
    }
    return 0;
}

/* Copy context infos (signal code, etc.) */
static void copyContext(NativeCodeHandler *const t,
                         const int code, siginfo_t *const si,
                         void *const sc) {
    t->code = code;
    t->si = *si;
    if (sc != NULL) {
        ucontext_t *const uc = (ucontext_t*) sc;
        t->uc = *uc;
    } else {
        memset(&t->uc, 0, sizeof(t->uc));
    }

    /* Frame buffer initial position. */
    t->frames_size = 0;

    //这里5.0之下和5.0之上分别处理，因为在5.0之下有libcorkscrew.so文件，到了5.0之上没有这个文件了

    /* Unwind frames (equivalent to backtrace()) */
    //因为在so加载的时候就实现了signal，这里java层还没有传过来SDK_VERSION,所以这里我直接通过能否打开so判断执行了。
	t->frames_size = unwind_signal(sc, t->uframes, BACKTRACE_FRAMES_MAX);
    if(t->frames_size==0)
    {
    	/* Use the corkscrew library to extract the backtrace. */
    	t->frames_size = backtrace_signal(si, sc, t->frames, 0, BACKTRACE_FRAMES_MAX);
    	return;
    }
	size_t i = 0;
	for(i = 0 ; i < t->frames_size ; i++) {
		 t->frames[i].absolute_pc = (uintptr_t)t->uframes[i];
		 t->frames[i].stack_top   = 0;
		 t->frames[i].stack_size  = 0;
	}
}

static void invalidateContext(NativeCodeHandler* const t) {
    /* Valid context ? */
    if (t != NULL && t->ctxIsSet) {
        /* Invalidate the context */
        t->ctxIsSet = false;
        t->frames_size = 0;
    }
}


/* Call the old handler. */
//直接用函数指针调用
static void callOldSignalHandler(const int code, siginfo_t *const si, void * const sc) {
    /* Call the "real" Java handler for JIT and internals. */
    if (code >= 0 && code < SIG_NUMBER_MAX) {
        int curInitCount = --g_nativeCode.initialized;
        if (g_nativeCode.sa_old[curInitCount][code].sa_sigaction != NULL) {
            g_nativeCode.sa_old[curInitCount][code].sa_sigaction(code, si, sc);
        } else if (g_nativeCode.sa_old[curInitCount][code].sa_handler != NULL) {
            g_nativeCode.sa_old[curInitCount][code].sa_handler(code);
        }
    }
}
/* Internal signal pass-through. Allows to peek the "real" crash before
 * calling the Java handler. Remember than Java needs many of the signals
 * (for the JIT, for test-free NullPointerException handling, etc.)
 * We record the siginfo_t context in this function each time it is being
 * called, to be able to know what error caused an issue.
 */
static void my_handler(int code, siginfo_t * si, void * sc) {
    NativeCodeHandler *v1;


    /* Available context ? */
    v1 = getCrashHandler();
    if (v1 != NULL) {

        copyContext(v1, code, si, sc);

        invalidateContext(v1);
    }
    //将信号传递给上层信号处理函数
    callOldSignalHandler(code, si, sc);
}


/* Internal globals initialization. */
//注册信号处理函数
static int globalHandlerSetup(int id) {
    int curInitCount = g_nativeCode.initialized;
    size_t i;
    struct sigaction sa;

    if (g_nativeCode.initialized++ == 0) {
        g_nativeCode.sa_old = (struct sigaction**)calloc(sizeof(struct sigaction*), MAX_SIGNAL_HANDLER_SETUP_TIMES);
        if (g_nativeCode.sa_old == NULL) {
            return -1;
        }
        g_nativeCode.id = (int*)calloc(sizeof(int), MAX_SIGNAL_HANDLER_SETUP_TIMES);
    }
    g_nativeCode.id[curInitCount] = id;

    if (g_nativeCode.initialized > g_nativeCode.maxInitialized) {
        g_nativeCode.maxInitialized = g_nativeCode.initialized;
        assert(g_nativeCode.maxInitialized <= MAX_SIGNAL_HANDLER_SETUP_TIMES);
    }

    /* Setup handler structure. */
    memset(&sa, 0, sizeof(sa));
    sigemptyset(&sa.sa_mask);
    sa.sa_sigaction = my_handler;  //这里是自定义信号处理函数
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK;

    /* Allocate */
    g_nativeCode.sa_old[curInitCount] = (struct sigaction*)calloc(sizeof(struct sigaction), SIG_NUMBER_MAX);
    if (g_nativeCode.sa_old[curInitCount] == NULL) {
        LOGE("calloc for sa_old failuer.");
        return -1;
    }

    /* Setup signal handlers for SIGABRT (Java calls abort()) and others. **/
    for (i = 0; nativeSignalCatch[i] != 0; i++) {
        const int sig = nativeSignalCatch[i];
        const struct sigaction * const action = &sa;
        assert(sig < SIG_NUMBER_MAX);
        if (sigaction(sig, action, &g_nativeCode.sa_old[curInitCount][sig]) != 0) {
            return -1;
        }
    }

    /* OK. */
    return 0;
}

static int freeNativeCodeHandler(NativeCodeHandler *const t) {
    int ret = 0;

    if (t == NULL) {
        return -1;
    }

    /* Restore previous alternative stack. */
    if (t->oldStack.ss_sp != NULL && sigaltstack(&t->oldStack, NULL) != 0) {
        ret = -1;
    }

    /* Free alternative stack */
    if (t->stackBuffer != NULL) {
        free(t->stackBuffer);
        t->stackBuffer = NULL;
        t->stackBufferSize = 0;
    }

    /* Free structure. */
    free(t);
    return ret;
}

/**
 * Create a native_code_handler_struct structure.
 * 申请堆栈
 **/
static NativeCodeHandler* initNativeCodeHandler() {
    stack_t stack;
    NativeCodeHandler *const v1 = (NativeCodeHandler*)calloc(sizeof(NativeCodeHandler), 1);

    if (v1 == NULL) {
        LOGE("calloc NativeCodeHanlder failure.");
        return NULL;
    }

    /* Initialize structure */
    v1->stackBufferSize = SIGSTKSZ;
    v1->stackBuffer = (char*)malloc(v1->stackBufferSize);
    if (v1->stackBuffer == NULL) {
        freeNativeCodeHandler(v1);
        LOGE("malloc stackBuffer failure.");
        return NULL;
    }

    /* Setup alternative stack. */
    memset(&stack, 0, sizeof(stack));
    stack.ss_sp = v1->stackBuffer;
    stack.ss_size = v1->stackBufferSize;
    stack.ss_flags = 0;

    /* Install alternative stack. This is thread-safe */
    if (sigaltstack(&stack, &v1->oldStack) != 0) {
        freeNativeCodeHandler(v1);
        return NULL;
    }

    return v1;
}

/**
 * Acquire the crash handler for the current thread.
 * The handler_cleanup() must be called to release allocated
 * resources.
 **/
static int handlerSetup(int setup_thread, int id) {
    int code = 0;
    /* Initialize globals. */
    if (pthread_mutex_lock(&g_nativeCode.mutex) != 0) {
        return -1;
    }

    code = globalHandlerSetup(id);

    if (pthread_mutex_unlock(&g_nativeCode.mutex) != 0) {
        return -1;
    }

    /* Global initialization failed. */
    if (code != 0) {
        return -1;
    }

    /* Initialize locals. */
    if (setup_thread && getCrashHandler() == NULL) {
        NativeCodeHandler *const t = initNativeCodeHandler();

        if (t == NULL) {
            return -1;
        }

        g_nativeCodeHandler = t;

    }

    /* OK. */
    return 0;
}

/**
 * Calls handler_setup(1) to setup a crash handler, mark the
 * context as valid, and return 0 upon success.
 */
int setupSignalHandler(int id) {
    if (handlerSetup(1, id) == 0) {
        NativeCodeHandler *const t = getCrashHandler();
        assert(t != NULL);
        t->ctxIsSet = true;
        return 0;
    } else
    {
        return -1;
    }
}

/* Unflag "on stack" */
static void recoverAlternateStack() {
    stack_t ss;
    if (sigaltstack(NULL, &ss) == 0) {
        ss.ss_flags &= ~SS_ONSTACK;
        sigaltstack (&ss, NULL);
    }
}

static int handlerCleanup() {
    /* Cleanup locals. */
    NativeCodeHandler *const t = getCrashHandler();
    if (t != NULL) {

        /* Erase thread-specific value now (detach). */
        if (pthread_setspecific(nativeCodeThread, NULL) != 0) {
            assert(! "pthread_setspecific() failed");
        }

        /* Free handler and reset slternate stack */
        if (freeNativeCodeHandler(t) != 0) {
            return -1;
        }

    }

    /* Cleanup globals. */
    if (pthread_mutex_lock(&g_nativeCode.mutex) != 0) {
        assert(! "pthread_mutex_lock() failed");
    }
    assert(g_nativeCode.maxInitialized != 0);
    if (g_nativeCode.initialized == 0) {

        size_t i;
        /* Restore signal handler. */
        for(i = 0; nativeSignalCatch[i] != 0; i++) {
            const int sig = nativeSignalCatch[i];
            assert(sig < SIG_NUMBER_MAX);
            //直接重置成最早一次设置信号处理函数时，所对应的旧信号处理函数
            if (sigaction(sig, &g_nativeCode.sa_old[0][sig], NULL) != 0) {
                return -1;
            }
        }

        /* Free old structure. */
        for (i = 0;i < g_nativeCode.maxInitialized;i++) {
            free(g_nativeCode.sa_old[i]);
            g_nativeCode.sa_old[i] = NULL;
        }

        /* Free old structure. */
        free(g_nativeCode.sa_old);
        g_nativeCode.sa_old = NULL;
        free(g_nativeCode.id);
        g_nativeCode.id = NULL;
        LOGD("cleanup signal handler");

        /* Delete thread var. */
        if (pthread_key_delete(nativeCodeThread) != 0) {
            assert(! "pthread_key_delete() failed");
        }
    }
    if (pthread_mutex_unlock(&g_nativeCode.mutex) != 0) {
        assert(! "pthread_mutex_unlock() failed");
    }

    return 0;
}

void registerSignalHandler()
{
	if(setupSignalHandler(1))
	{
		LOGE("registerSignalHandler failure.");
	}
}

void unregisterSignalHandler()
{
	recoverAlternateStack();
	NativeCodeHandler *const t = getCrashHandler();
	assert(t != NULL);
	t->ctxIsSet = false;
	handlerCleanup();
}
