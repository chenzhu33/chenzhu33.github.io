#include <stdio.h>
#include <pthread.h>

struct filestat{
	int fd;
	bool isSQL;
	long long startTime;
	int readCount;
	int writeCount;
	int readBytes;
	int writeBytes;
	int readTime;
	int writeTime;
	char filePath[300];
	char processName[50];
	char threadName[100];
	char stackTrace[2048];
	struct filestat * next;
};

typedef struct filestat * pfilestat;

typedef struct IoOperationStruct{
	long ioOperationCount; //IO操作次数
	long ioOperationBytes; //IO操作字节
}IoOperationInfo;

pfilestat createList();
pfilestat insertNode(pfilestat head, pfilestat node);
int deleteNode(pfilestat head, int fd);
pfilestat findNode(pfilestat head, int fd);
int deleteList(pfilestat* phead);
pfilestat printList(pfilestat head);
pfilestat makeNode(int fd,const char* filePath,long long startTime);
