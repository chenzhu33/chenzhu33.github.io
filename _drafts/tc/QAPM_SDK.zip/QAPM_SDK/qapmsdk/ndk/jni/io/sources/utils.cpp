﻿#include <jni.h>
#include <dlfcn.h>
#include <stdint.h>
#include <elf.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>

#include "headers/linker.h"
#include "headers/utils.h"
#include "hutils.h"

/**
 * 打印指定内存区块, 区块为: [ start_addr, start_addr+ALIGN(len, 4) )
 */
int print_binary(void * start_addr, uint32_t len)
{
	uint8_t * p = (uint8_t *)start_addr;
	uint32_t aligned_len = ALIGN(len, 4);
	for (int i = 0; i < aligned_len; i += 4) {
		LOGD("%p\t%08x", p + i, *(uint32_t *)(p + i));
	}
	return 0;
}


#define GETBUF(offset, fd, buf, size)	\
{	\
	lseek(fd, offset, SEEK_SET);	\
	read_len = read(fd, buf, size);	\
	if(read_len < size){	\
		return 0;	\
	}	\
}

Elf32_Addr dlsym_hidden(const char * sym, const char * libname)
{
	Elf32_Ehdr * pElf;

	pElf = (Elf32_Ehdr *)((char *)malloc(sizeof(Elf32_Ehdr)));
	int fd = open(libname, O_RDONLY);
	if(fd < 0){
		LOGI("Cannot open %s", libname);
		free(pElf);
		close(fd);
		return 0;
	}
	int read_len = read(fd, pElf, sizeof(Elf32_Ehdr));//读表头
	if(read_len < sizeof(Elf32_Ehdr)){
		LOGI("read Elf32_Ehdr failed");
		free(pElf);
		close(fd);
		return 0;
	}

	//计算表名地址
	int shnum = pElf->e_shnum;
	int py = pElf->e_shstrndx * sizeof(Elf32_Shdr);


	int offset = pElf->e_shoff + py;
	lseek(fd, offset, SEEK_SET);
	Elf32_Shdr shstrtab;
	read_len = read(fd, &shstrtab, sizeof(Elf32_Shdr));//读段名
	if(read_len < sizeof(Elf32_Shdr)){
		LOGI("read Elf32_Shdr failed");
		free(pElf);
		close(fd);
		return 0;
	}

	//Get Shdr Name
	offset = shstrtab.sh_offset;
	char * szShdrName = (char *)malloc(shstrtab.sh_size);
	lseek(fd, offset, SEEK_SET);
	read_len = read(fd, szShdrName, shstrtab.sh_size);
	if(read_len < shstrtab.sh_size){
		LOGI("read shstrtab failed");
		free(pElf);
		free(szShdrName);
		close(fd);
		return 0;
	}
	//获取整个section表
	Elf32_Shdr Shdr[shnum];
	offset = pElf->e_shoff;
	lseek(fd, offset, SEEK_SET);
	read_len = read(fd, Shdr, sizeof(Elf32_Shdr)*shnum);
	if(read_len < sizeof(Elf32_Shdr)*shnum){
		LOGI("read section failed");
		free(pElf);
		free(szShdrName);
		close(fd);
		return 0;
	}

	//获取符号表和字符串表
	Elf32_Shdr  symtab;
	Elf32_Shdr  strSh;
	Elf32_Shdr  dynsym;
	Elf32_Shdr  dynstr;

	bool bSymtab = false;
	bool bStrtab = false;
	bool bDynsym = false;
	bool bDynstr = false;
	Elf32_Addr addr = 0;

	for(int i = 0; i < shnum; i++){
		Elf32_Shdr mshdr = Shdr[i];
//        LOGI("%s",szShdrName + mshdr.sh_name);
		if(strcmp(szShdrName + mshdr.sh_name, ".symtab") == 0){
			symtab = mshdr;
			bSymtab = true;
		}
		if(strcmp(szShdrName + mshdr.sh_name, ".strtab") == 0){
			strSh = mshdr;
			bStrtab = true;
		}
		if(strcmp(szShdrName + mshdr.sh_name, ".dynsym") == 0){
			dynsym = mshdr;
			bDynsym = true;
		}
		if(strcmp(szShdrName + mshdr.sh_name, ".dynstr") == 0){
			dynstr = mshdr;
			bDynstr = true;
		}

		if(bSymtab && bStrtab)
			break;
	}
	//符号表和字符串表任何一个没找到就放弃，避免出错
	if(bSymtab && bSymtab){
		//把字符表读出来
		char * strtab = (char *)malloc(strSh.sh_size);
		offset = strSh.sh_offset;
		lseek(fd, offset, SEEK_SET);
		read_len = read(fd, strtab, strSh.sh_size);
		if(read_len < strSh.sh_size){
			free(pElf);
			free(szShdrName);
			free(strtab);
			close(fd);
			return 0;
		}
		Elf32_Sym *symb = NULL;
		Elf32_Sym *symbHead = NULL;
		if(bSymtab){
			symb = (Elf32_Sym *)((char *)malloc(symtab.sh_size));
			symbHead = symb;
			GETBUF(symtab.sh_offset, fd, symb, symtab.sh_size)
			int  symbSize = symtab.sh_size / sizeof(Elf32_Sym);

			for(int idex = 0; idex < symbSize; idex++){
				if(strcmp(symb->st_name + strtab, sym) == 0){
					addr = symb->st_value;
					break;
				}
				symb++;
			}
		}
		free(pElf);
		free(szShdrName);
		free(strtab);
		if(symbHead != NULL)
			free(symbHead);
	} else if(bDynstr&&bDynsym){
		//把字符表读出来
		char * strtab = (char *)malloc(dynstr.sh_size);
		offset = dynstr.sh_offset;
		lseek(fd, offset, SEEK_SET);
		read_len = read(fd, strtab, dynstr.sh_size);
		if(read_len < dynstr.sh_size){
			free(pElf);
			free(szShdrName);
			free(strtab);
			close(fd);
			return 0;
		}

		Elf32_Sym *symb = NULL;
		Elf32_Sym *symbHead = NULL;
		if(bDynsym){
			symb = (Elf32_Sym *)((char *)malloc(dynsym.sh_size));
			symbHead = symb;
			GETBUF(dynsym.sh_offset, fd, symb, dynsym.sh_size)
			int  symbSize = dynsym.sh_size / sizeof(Elf32_Sym);

			for(int idex = 0; idex < symbSize; idex++){
				if(strcmp(symb->st_name + strtab, sym) == 0){
					addr = symb->st_value;
					break;
				}
				symb++;
			}
		}
		free(pElf);
		free(szShdrName);
		free(strtab);
		if(symbHead != NULL)
			free(symbHead);
	} else{
		LOGE("Cannot found the symbol in symtab and strtab!");
		free(pElf);
		free(szShdrName);
		close(fd);
		return 0;
	}

	close(fd);
	return addr;
}

Elf32_Addr dlsym_base_addr(const char * libname){
	Elf32_Ehdr * pElf;

	pElf = (Elf32_Ehdr *)((char *)malloc(sizeof(Elf32_Ehdr)));
	int fd = open(libname, O_RDONLY);
	if(fd < 0){
		LOGI("Cannot open %s", libname);
		free(pElf);
		close(fd);
		return 0;
	}
	int read_len = read(fd, pElf, sizeof(Elf32_Ehdr));//读表头
	if(read_len < sizeof(Elf32_Ehdr)){
		LOGI("read Elf32_Ehdr failed");
		free(pElf);
		close(fd);
		return 0;
	}

	//计算表名地址
	int shnum = pElf->e_shnum;
	int py = pElf->e_shstrndx * sizeof(Elf32_Shdr);


	int offset = pElf->e_shoff + py;
	lseek(fd, offset, SEEK_SET);
	Elf32_Shdr shstrtab;
	read_len = read(fd, &shstrtab, sizeof(Elf32_Shdr));//读段名
	if(read_len < sizeof(Elf32_Shdr)){
		LOGI("read Elf32_Shdr failed");
		free(pElf);
		close(fd);
		return 0;
	}

	//Get Shdr Name
	offset = shstrtab.sh_offset;
	char * szShdrName = (char *)malloc(shstrtab.sh_size);
	lseek(fd, offset, SEEK_SET);
	read_len = read(fd, szShdrName, shstrtab.sh_size);
	if(read_len < shstrtab.sh_size){
		LOGI("read shstrtab failed");
		free(pElf);
		free(szShdrName);
		close(fd);
		return 0;
	}
	//获取整个section表
	Elf32_Shdr Shdr[shnum];
	offset = pElf->e_shoff;
	lseek(fd, offset, SEEK_SET);
	read_len = read(fd, Shdr, sizeof(Elf32_Shdr)*shnum);
	if(read_len < sizeof(Elf32_Shdr)*shnum){
		LOGI("read section failed");
		free(pElf);
		free(szShdrName);
		close(fd);
		return 0;
	}

	//获取符号表和字符串表
	Elf32_Shdr  text;
	bool bText = false;
	Elf32_Addr base_addr = 0;

	for(int i = 0; i < shnum; i++){
		Elf32_Shdr mshdr = Shdr[i];
		if(strcmp(szShdrName + mshdr.sh_name, ".text") == 0){
			text = mshdr;
			bText = true;
		}
		if(bText)
			break;
	}

	if (bText)
	{
		base_addr = text.sh_addr - text.sh_offset;
	}

	return base_addr;
}

void merge_file_maps_node(maps_info* file_maps_heard){
	maps_info* cur_info = file_maps_heard->next;
	maps_info* last_info = file_maps_heard;
	while(cur_info != NULL) {
		maps_info* next_info = cur_info->next;
		if (next_info != NULL)
		{
			if (cur_info->block_begin == next_info->block_end)
			{
				next_info->block_end = cur_info->block_end;
				last_info->next = next_info;
				delete cur_info;
			}
			else{
				last_info =cur_info;
			}
		}
		cur_info = next_info;

	}
}

void clean_file_maps_info(maps_info* file_maps_heard){
	maps_info* cur_info = file_maps_heard->next;
	maps_info* last_info = file_maps_heard;
	while(cur_info != NULL) {
		maps_info* next_info = cur_info->next;
		last_info->next = next_info;
		delete cur_info;
		cur_info = next_info;

	}
	delete file_maps_heard;
}

/**
 * 计算库文件 libname 中符号 sym 在内存里的绝对地址
 */
void * find_sym_addr_abs(const char * sym, const char * libname)
{
	void * pHandle = dlopen(libname, RTLD_NOW);
	if (pHandle == NULL){
		return NULL;
	}

	soinfo * info = (soinfo*)pHandle;

	void * symbol = dlsym(pHandle, sym);
	if (symbol == NULL){
		//LOGD("dlsym not find the symbol %s", sym);
		Elf32_Addr symAddr = dlsym_hidden(sym, libname);
		if(symAddr == 0){
			LOGE("dlsym_hidden not find the symbol %s", sym);
			return NULL;
		}
		
		symbol = (void*)(symAddr + info->load_bias);
//		LOGI("%s base addr is %02x, the symbol %s offset is %02x", libname, info->load_bias, sym, symAddr);
	}
		
	return symbol;
}

void* find_sym_addr_abs_for_a7(const char * sym, const char * libname){
	FILE* fd_maps=NULL;
	fd_maps=fopen("/proc/self/maps","r");

	char maps_line[1024]={0};
	void* offset_start,*offset_end,*base_addr;
	char property[256]={0};
	char not_care2[128]={0},not_care3[128]={0};
	char library_path[256]={0};
	int maps_column_num=0;
	void* symbol = 0;
	maps_info* file_maps_heard = new maps_info();
	file_maps_heard->next = NULL;
	if(fd_maps==NULL)
	{
		LOGE("cannot open fd_maps.");
		return NULL;
	}
	while(NULL!=fgets(maps_line,sizeof(maps_line),fd_maps))
	{
		maps_column_num=sscanf(maps_line,"%p-%p\t%s\t%p\t%s\t%s\t%s"
				,&offset_start
				,&offset_end
				,property
				,&base_addr
				,not_care2
				,not_care3
				,library_path);
		if(strcmp(libname ,library_path)==0){
			maps_info* file_maps_node = new maps_info();
			file_maps_node->block_begin = (uint32_t)offset_start;
			file_maps_node->block_end = (uint32_t)offset_end;
			file_maps_node->base_addr = (uint32_t)base_addr;
			file_maps_node->next = file_maps_heard->next;
			file_maps_heard->next = file_maps_node;
//			LOGD("beformerge is file is %s,  begin %x, end is %x, base is %x", libname, (uint32_t)offset_start, (uint32_t)offset_end, (uint32_t)base_addr);
		}


	}

	Elf32_Addr symAddr = dlsym_hidden(sym, libname);
	if(symAddr == 0){
		clean_file_maps_info(file_maps_heard);
		LOGE("dlsym_hidden not find the symbol %s", sym);
		return NULL;
	}
	Elf32_Addr baseAddr = dlsym_base_addr(libname);

	merge_file_maps_node(file_maps_heard);
	maps_info* cur_info = file_maps_heard->next;
	while(cur_info != NULL) {
//		LOGD("cur_info is file is %s,  begin %x, end is %x, base is %x", libname, (uint32_t)(cur_info->block_begin), (uint32_t)(cur_info->block_end), (uint32_t)(cur_info->base_addr));
		maps_info* next_info = cur_info->next;
		if (next_info != NULL)
		{
			if ((uint32_t)symAddr < (uint32_t)(cur_info->base_addr) && (uint32_t)symAddr > (uint32_t)(next_info->base_addr))
			{
				symbol = (void*)((uint32_t)symAddr + (uint32_t)(next_info->block_begin));
				break;
			}
		}
		else{
			symbol = (void*)((uint32_t)symAddr + (uint32_t)(cur_info->block_begin));
			break;
		}
	}
	symbol = (void*)((uint32_t)symbol - (uint32_t)baseAddr);
	clean_file_maps_info(file_maps_heard);
	fclose(fd_maps);
	return symbol;
}


/**
 * 设置内存区块为可读的
 * 区块为: [ ALIGN(start, pagesize), ALIGN(start, pagesize)+page_count*pagesize )
 */
int set_mem_writable(void * start, unsigned len)
{
	uint32_t pageProtectSize = __PAGESIZE;;
	void* pageStart = (void *)(((uint32_t)start) / pageProtectSize * pageProtectSize);
    if ((uint32_t)start + len > (uint32_t)pageStart + pageProtectSize){
		pageProtectSize += __PAGESIZE;
	}
	
	if(mprotect(pageStart, pageProtectSize, PROT_READ | PROT_WRITE | PROT_EXEC) == -1){
		return mprotect(pageStart, pageProtectSize, PROT_READ | PROT_WRITE);
	}
	
	return 0;
}

/**
 *取消内存区块写权限
 */
int reset_mem_priority(void * start, unsigned len)
{
	uint32_t pageProtectSize = __PAGESIZE;;
	void* pageStart = (void *)(((uint32_t)start) / pageProtectSize * pageProtectSize);
    if ((uint32_t)start + len > (uint32_t)pageStart + pageProtectSize){
		pageProtectSize += __PAGESIZE;
	}
	
	return mprotect(pageStart, pageProtectSize, PROT_READ | PROT_EXEC);
}

extern "C" {
	void* dlsym_abs(const char * sym, const char * libname){
		return find_sym_addr_abs(sym, libname);
	}

	void* dlsym_abs_for_a7(const char * sym, const char * libname){
		return find_sym_addr_abs_for_a7(sym, libname);
	}
	
	bool CheckWildPointer(void * pointer, int size)
	{
		static int nullfd = open("/dev/random", O_WRONLY);
		if(nullfd == -1)
			return false;
		if (write(nullfd, pointer, size==0?sizeof(pointer):size) < 0)
		{
			return true;
		}
		return false;
	}
}
