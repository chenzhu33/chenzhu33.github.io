#ifndef _RELOCATE_A_H
#define _RELOCATE_A_H

#include <stdio.h>

int relocateInstruction(uint32_t target_addr, void *orig_instructions, int length, void *trampoline_instructions, int *orig_boundaries, int *trampoline_boundaries, int *count);

#endif