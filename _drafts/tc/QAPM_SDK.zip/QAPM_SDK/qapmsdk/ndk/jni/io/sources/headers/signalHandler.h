#ifndef SIGNAL_HANDLER_H
#define SIGNAL_HANDLER_H
#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <android/log.h>
#include <dlfcn.h>
#include <setjmp.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <assert.h>
#include <string.h>
#include <errno.h>
#include <corkscrew/backtrace.h>
#include <corkscrew/map_info.h>

#define BACKTRACE_FRAMES_MAX 32
#define SIG_NUMBER_MAX 32
#define NATIVE_CODE_GLOBAL_INITIALIZER { 0, 0, PTHREAD_MUTEX_INITIALIZER, NULL, NULL}
#define MAX_SIGNAL_HANDLER_SETUP_TIMES 2

/* Process-wide crash handler structure. */
typedef struct _NativeCodeGlobalStruct {
    int maxInitialized;

    /* Initialized. */
    int initialized;

    /* Lock. */
    pthread_mutex_t mutex;

    /* Backup of sigaction. */
    struct sigaction** sa_old;

    int* id;
} NativeCodeGlobal,*pNativeCodeGlobal;

//typedef struct map_info_t map_info_t;
///*
// * 5.0之下系统使用
// */
///*********************************************/
////typedef struct map_info_t map_info_t;
///* Extracted from Android's include/corkscrew/backtrace.h */
//typedef struct{
//    uintptr_t absolute_pc;
//    uintptr_t stack_top;
//    size_t stack_size;
//}backtrace_frame_t;
//
//typedef struct{
//    uintptr_t relative_pc;
//    uintptr_t relative_symbol_addr;
//    char* map_name;
//    char* symbol_name;
//    char* demangled_name;
//} backtrace_symbol_t;

/* Extracted from Android's libcorkscrew/arch-arm/backtrace-arm.c */
typedef ssize_t (*t_unwind_backtrace_signal_arch)
        (siginfo_t* si, void* sc, const map_info_t* lst, backtrace_frame_t* bt,
         size_t ignore_depth, size_t max_depth);
typedef map_info_t* (*t_acquire_my_map_info_list)();
typedef void (*t_release_my_map_info_list)(map_info_t* milist);
typedef void (*t_get_backtrace_symbols)(const backtrace_frame_t* backtrace,
                                        size_t frames,
                                        backtrace_symbol_t* symbols);
typedef void (*t_free_backtrace_symbols)(backtrace_symbol_t* symbols,
                                         size_t frames);
/*********************************************/

/* Thread-specific crash handler structure. */
typedef struct _NativeCodeHandlerStruct {
    /* Restore point context. */
    sigjmp_buf ctx;
    bool ctxIsSet;
    /* Alternate stack. */
    char *stackBuffer;
    size_t stackBufferSize;
    stack_t oldStack;

    /* Signal code and info. */
    int code;
    siginfo_t si;
    ucontext_t uc;

    backtrace_frame_t frames[BACKTRACE_FRAMES_MAX];

    void*  uframes[BACKTRACE_FRAMES_MAX];
    size_t frames_size;

}NativeCodeHandler,*pNativeCodeHandler;

void registerSignalHandler();
void unregisterSignalHandler();

#endif
