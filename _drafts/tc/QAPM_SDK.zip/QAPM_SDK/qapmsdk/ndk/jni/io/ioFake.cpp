#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <dirent.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <jni.h>
#include <android/log.h>
#include <pthread.h>
#include <sys/syscall.h>
#include <corkscrew/backtrace.h>
#include <sys/system_properties.h>
#include <sys/time.h>
#include <stdarg.h>
#include <sys/mman.h>
#include <sqlitedef.h>
#include <string>
#include <map>
#include <errno.h>
#include <fstream>
#include <vector>
#include <elf.h>
#include "ioFake.h"
#include "sources/headers/signalHandler.h"
#include "sources/headers/linklist.h"

#include "hutils.h"
using std::string;
using std::map;
using std::vector;

extern int getJavaStackTrace(char *stacktrace, int len);
extern int getCurThreadName(char* threadName, int len);
//extern int getJavaStackAndThreadName(char * stackTrace, char* threadName);
extern int artGetJavaStack(char* stackTrace);
extern int artGetThreadName(char* threadName);

void *run_handle=NULL;

void* cheackJudgeop();


JNIEnv* (*getJNIEnvPoint)()=NULL;

vector<std::string> sqlfilePath;

pthread_mutex_t map_close_lock;
pthread_mutex_t map_open_lock;
pthread_mutex_t map_pread64_lock;
pthread_mutex_t map_pwrite64_lock;
pthread_mutex_t map_prepare16_v2_lock;


map<int,int> map_close;    //记录重入
map<int,int> map_open;
map<int,int> map_pread64;
map<int,int> map_pwrite64;
map<int,int> map_prepare16_v2;

void *func_sqlite3_step = NULL;
void *func_sqlite3_finalize = NULL;
void *func_sqlite3_column_text = NULL;
void *func_sqlite3_reset = NULL;
void *func_sqlite3_db_status = NULL;
void *func_sqlite3_status = NULL;
jobject objectforcallback = NULL;

bool ONSTART = false;
bool ONPAUSE = false;
bool USEMMAP = true;
bool HAVE_APP_VERSION = false;
bool CACHEHITSWITCH = false; //缓存命中率检查开关
char processName[MAX_PROCESS_LEN];  //进程Pid
char sdcardPath[128];
char dirForSQLiteUpload[300];
char dirForFileUpload[300];
char APP_VERSION[100];
char magnifierDumpDir[300];
char nameForFileIO[MAX_FILENAME_LEN];
bool haveInitFileIOName = false;
int SDK_VERSION;

pthread_mutex_t listlock;
pthread_mutex_t writeToFilelock;
pthread_mutexattr_t attr;
pthread_mutex_t sqlitelock;
pthread_mutex_t sqliteexplainlock;
pthread_mutex_t sqlitemisslock;
pthread_mutex_t sqlitesummarylock;
pfilestat head=NULL;
struct flock  lock;
struct flock fsqlsummarylock;
struct flock fsqlexpainlock;
struct flock fsqldetaillock;
int saveInfoType;

static int symState = 1;

extern char crashFilePath[128];

struct writeToFile{
	pfilestat writeToFileArray[MAX_LENGTH];
	int length;
};
struct writeToFile writeToFileList;

struct sqlWriteToFile{
	char sqlInfoArray[SQLINFO_COUNT][SQLINFO_LEN];
	int curlen;
};
struct sqlWriteToFile sqlInfoWriteToFile;

struct sqlExplainToFile{
	char sqlInfoArray[SQLINFO_COUNT][SQLEXPLAIN_LEN];
	int curlen;
};
struct sqlExplainToFile sqlInfoExplainToFile;

struct HitMiss{
	int cache_hit;
	int cache_miss;
	int cache_write;
	int cache_used;
};

//string lastDbName;
map<string, HitMiss> mapDbHitMiss;
map<string, int> mapSqllMiss;

typedef struct sqlSummaryStruct{
	string fileName;
	int indexInter;
	int indexLeaf;
	int tableInter;
	int tableLeaf;
	int overFlow;
	int readSize;
	int writeSize;
}sqlSummaryInfo;
map<string, sqlSummaryInfo>  sqlSummaryInfoMap;

static IoOperationInfo g_IoOperationInfo; //注：该结构体并非记录真实IO操作次数，而是落地的IO操作次数，内存中的未包括

//返回ms
long getTime(){
	struct timeval tv;
	gettimeofday(&tv,NULL);
	return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

unsigned long getFileSize(const char* path){
	unsigned long filesize=0;
	//unsigned long是不会等于-1的，等于-1系统会自动转化为最大值，后面的判断就有可能出错了
	struct stat statbuff;
	if(stat(path,&statbuff)<0){
		LOGE("get filesize error.%s",(char*)strerror(errno));
	}else{
		filesize=statbuff.st_size;
	}
	return filesize;
}

//返回进程Pid
void getN_ProcessName(char *processname) {
	char buf[MAX_PROCESS_LEN];
	memset(buf,'\0',sizeof(buf));
	char proc_pid_path[30];
	pid_t pid=getpid();
	sprintf(proc_pid_path, "/proc/%d/cmdline", pid);
	FILE* fp = fopen(proc_pid_path, "r");
	if(NULL != fp){
		if( fgets(buf, MAX_PROCESS_LEN-10, fp)== NULL ){
			fclose(fp);
		}
		fclose(fp);
	}
	char pid2str[10];
	memset(pid2str,'\0',sizeof(pid2str));
	sprintf(pid2str,"&%d",pid);
	strcpy(processname,buf);
	strcat(processname,pid2str);
}

int getAPMRoot(char * sdcardPath){
	if(SDK_VERSION > 23){
		getJNIEnvPoint = (JNIEnv* (*)())dlsym_abs_for_a7("_ZN7android14AndroidRuntime9getJNIEnvEv","/system/lib/libandroid_runtime.so");
		if(getJNIEnvPoint==NULL){
			LOGE("get getJNIEnv method is NULL");
			return -1;
		}
	}else{
		if(run_handle==NULL){
			run_handle = dlopen("/system/lib/libandroid_runtime.so", RTLD_NOW);
			if(run_handle==NULL){
				LOGE("dlopen runtime.so error");
				return -1;
			}

			getJNIEnvPoint =(JNIEnv* (*)())dlsym(run_handle,"_ZN7android14AndroidRuntime9getJNIEnvEv");
			if(getJNIEnvPoint==NULL){
				LOGE("get getJNIEnv method is NULL");
				return -1;
			}
		}
	}
	JNIEnv* env = getJNIEnvPoint();
	if(env==NULL){
		LOGE("env is NULL");
		return -1;
	}
	//begin to get thread name
	jthrowable exc = env->ExceptionOccurred();
	if(exc) {
		env->ExceptionDescribe();
		env->ExceptionClear();
		LOGE("dvm occur error");
		return -1;
	}
	jclass fileUtilClass = env->FindClass("com/tencent/qapmsdk/common/FileUtil");
	if(fileUtilClass == NULL)
		return -1;
	jmethodID getRootPathMethod = env->GetStaticMethodID(fileUtilClass,"getRootPath","()Ljava/lang/String;");
	if(getRootPathMethod == NULL)
		return -1;
	jstring stringPath = (jstring)env->CallStaticObjectMethod(fileUtilClass,getRootPathMethod);
	if(stringPath == NULL )
	{
		LOGE("stringPath is NULL");
		return -1;
	}
	const char* path = env->GetStringUTFChars(stringPath,0);
	if(path == NULL)
	{
		LOGE("path is NULL");
		return -1;
	}
	strcpy(sdcardPath, path);
	env->DeleteLocalRef(fileUtilClass);
	env->ReleaseStringUTFChars(stringPath, path);
	return 0;

}

//getAPMRoot接口替换getSdcardPath接口
//int getSdcardPath(char * sdcardPath){
//	if(SDK_VERSION > 23){
//		getJNIEnvPoint = (JNIEnv* (*)())dlsym_abs_for_a7("_ZN7android14AndroidRuntime9getJNIEnvEv","/system/lib/libandroid_runtime.so");
//		if(getJNIEnvPoint==NULL){
//			LOGE("get getJNIEnv method is NULL");
//			return -1;
//		}
//	}else{
//		if(run_handle==NULL){
//			run_handle = dlopen("/system/lib/libandroid_runtime.so", RTLD_NOW);
//			if(run_handle==NULL){
//				LOGE("dlopen runtime.so error");
//				return -1;
//			}
//
//			getJNIEnvPoint =(JNIEnv* (*)())dlsym(run_handle,"_ZN7android14AndroidRuntime9getJNIEnvEv");
//			if(getJNIEnvPoint==NULL){
//				LOGE("get getJNIEnv method is NULL");
//				return -1;
//			}
//		}
//	}
//	JNIEnv* env = getJNIEnvPoint();
//	if(env==NULL){
//		LOGE("env is NULL");
//		return -1;
//	}
//	//begin to get thread name
//	jthrowable exc = env->ExceptionOccurred();
//	if(exc) {
//		env->ExceptionDescribe();
//		env->ExceptionClear();
//		LOGE("dvm occur error");
//		return -1;
//	}
//	jclass environClass = env->FindClass("android/os/Environment");
//	if(environClass == NULL)
//		return -1;
//	jmethodID getexternalstorageMethod = env->GetStaticMethodID(environClass,"getExternalStorageDirectory","()Ljava/io/File;");
//	if(getexternalstorageMethod == NULL)
//		return -1;
//	jobject externalstoragefile = (jobject)env->CallStaticObjectMethod(environClass,getexternalstorageMethod);
//	if(externalstoragefile == NULL)
//		return -1;
//	jclass fileClass = env->GetObjectClass(externalstoragefile);
//	if(fileClass ==NULL)
//		return -1;
//	jmethodID absolutepathMethod = env->GetMethodID(fileClass, "getAbsolutePath", "()Ljava/lang/String;");
//	if(absolutepathMethod == NULL)
//		return -1;
//	jstring stringPath = (jstring)env->CallObjectMethod(externalstoragefile, absolutepathMethod);
//	if(stringPath == NULL )
//	{
//		LOGE("stringPath is NULL");
//		return -1;
//	}
//	const char* path = env->GetStringUTFChars(stringPath,0);
//	if(path == NULL)
//	{
//		LOGE("path is NULL");
//		return -1;
//	}
//	strcpy(sdcardPath, path);
//	env->DeleteLocalRef(environClass);
//	env->DeleteLocalRef(fileClass);
//	env->ReleaseStringUTFChars(stringPath, path);
//	return 0;
//}

#define HOOKSIZE 10
const char *hook_fun[] = {
		"close",
		"read",
		"write",
		"open",
		"pread",
		"pread64",
		"pwrite",
		"pwrite64",
		"sqlite3_prepare16_v2",
		"sqlite3_open_v2"
};
void *old_fun[HOOKSIZE];

void *old_db_status[2];

/*
* 对于一些系统的内部的读写操作如果等锁，可能造成ANR
* 这里都加入到白名单
* */
bool judge_whitelist(char* path){
	char* result;
	result = strstr(path, "/dev/");
	if(result!=NULL){
		return true;
	}
	result = strstr(path, "/proc/");
	if(result!=NULL){
		return true;
	}
	result = strstr(path, "/sys/");
	if(result!=NULL){
		return true;
	}

	result = strstr(path, "/system/");
	if(result!=NULL){
		return true;
	}

	result = strstr(path, "SQLExplainInfo");
	if(result != NULL){
		return true;
	}
	result = strstr(path, "IOInfo");
	if(result != NULL){
		return true;
	}
    result = strstr(path,"powervr");
    if(result != NULL){
        return true;
    }
	result = strstr(path, "sdk_db");
	if(result != NULL){
		return true;
	}
	//过滤内存dump
	result = strstr(path, "hprof");
	if(result != NULL){
		return true;
	}
	//app_webview会导致手Q在Android5.0的机型上ANR
/*	result = strstr(path, "app_webview");
    	if(result != NULL){
    	    return true;
    }*/
	result = strstr(path, "/QAPM/");
	if(result!=NULL){
		return true;
	}
    //将apm的so给过滤掉
    result = strstr(path, "libapm");
    if(result!=NULL){
        return true;
    }

	result = strstr(path, "SQLHitMissInfo");
	if(result!=NULL){
		return true;
	}
	result = strstr(path, "SQLMissDetail");
	if(result!=NULL){
		return true;
	}
	result = strstr(path, "com.android.opengl");
	if(result != NULL){
		return true;
	}
	return false;
}


bool judge_sqlite(char* path){
	char* result;
	result = strstr(path, "MicroMsg");
	if(result!=NULL){
		//	LOGD("this is MicroMsg, pass!");
		return true;
	}
	result = strstr(path, "databases");
	if(result!=NULL){
		//	LOGD("this is databases, pass!");
		return true;
	}
	string filepath(path);
	vector<string>::iterator r = find(sqlfilePath.begin(),sqlfilePath.end(),filepath);
	if(r!=sqlfilePath.end()){
		return true;
	}

	return false;
}
/*
 * 1, open必须采用原始的方法，这样不同的sdk的函数原型才一致
 * 2, sqlite的数据需要保存，因为在read和write的时候需要对应的filename来对应
 * 所以需要把这些信息放到open里面
 * 3, 数据库open堆栈没啥用, 统一不再取Native堆栈，对分析问题帮助不大
 * */
int my_open(const char* path, int flags, ...){

	int fd = -1;
	mode_t mode=0;
	flags |= O_LARGEFILE;
	if(flags&O_CREAT){
		va_list args;
		va_start(args,flags);
		mode=(mode_t)va_arg(args,int);
		va_end(args);
	}

    fd = ((int(*)(const char*, int, int))old_fun[3])(path,flags,mode);
    if((flags & O_DIRECTORY) || (flags == 02400000)){
        //	LOGD("it's a directory,%s,%d",path,flags);
        return fd;
    }
    pid_t threadId = gettid();

    pthread_mutex_lock(&map_open_lock);
    map<int, int>::iterator iter = map_open.find(threadId);
    if(iter==map_open.end()){
        map_open.insert(map<int,int>::value_type(threadId,1));
    } else if(iter->second > 0){
		pthread_mutex_unlock(&map_open_lock);
        return fd;
    } else{
        iter->second = 1;
    }
    pthread_mutex_unlock(&map_open_lock);

    if(fd!=-1 && !judge_whitelist((char*)path)){
        char threadName[MAX_THREAD_LEN] = {0};
        char javastack[MAX_STACK_LEN] = {0};

        if(saveInfoType == 1 && judge_sqlite((char*)path)){
            //如果只有IO测试，就不再记录数据库操作的相关文件
            return fd;
        }
        //这里普通IO才会进这个逻辑，sql直接返回
        if(SDK_VERSION < 21){
            //如果是要监控FILE IO，对于数据库文件，则直接返回
            if(saveInfoType != 2 && !judge_sqlite((char*)path) && getJavaStackTrace(javastack, MAX_STACK_LEN)){
                LOGE("get java stack error:%s", path);
                return fd;
            }
            if(getCurThreadName(threadName, sizeof(threadName))){
                LOGE("get thread name error");
                return fd;
            }
        }else{
            //使用老的方式取堆栈和线程名称
            if(saveInfoType != 2 && !judge_sqlite((char*)path)){
                if(artGetJavaStack(javastack)){
                    LOGE("artGetJavaStack error:%s.",path);
                    return fd;
                }
                if(artGetThreadName(threadName)){
                    LOGE("artGetThreadName error");
                    return fd;
                }
            }
        }
        pfilestat node=makeNode(fd,path,getTime());
        if(judge_sqlite((char*)path)){
            node->isSQL = true;
        }
        strcpy(node->stackTrace,javastack);
        strcpy(node->processName,processName);
        strcpy(node->threadName,threadName);
        //在插入链表之前加锁
        pthread_mutex_lock(&listlock);
        insertNode(head,node);
        pthread_mutex_unlock(&listlock);

    }

    pthread_mutex_lock(&map_open_lock);
    map_open[threadId] = 0;
    pthread_mutex_unlock(&map_open_lock);

	return fd;
}

int my_close(int fd){
	bool haveWriteFile = false;
	int ret = -1;

	ret = ((int(*)(int))old_fun[0])(fd);

    pid_t threadId = gettid();

    pthread_mutex_lock(&map_close_lock);
    map<int, int>::iterator iter = map_close.find(threadId);
    if(iter==map_close.end()){
        map_close.insert(map<int,int>::value_type(threadId,1));
    } else if(iter->second > 0){
		pthread_mutex_unlock(&map_close_lock);
        return ret;
    }else{
        iter->second = 1;
    }
    pthread_mutex_unlock(&map_close_lock);

	pfilestat node=findNode(head,fd);
	if(ret==0 && node != NULL)
	{
		pthread_mutex_lock(&listlock);
		node=findNode(head,fd);
		if(node==NULL)
		{
			pthread_mutex_unlock(&listlock);
			return ret;
		}
		else{
			//when will delete node failed, i dont know why
			//delete will not free memory of node
			if(deleteNode(head,fd)){
				LOGE("cant find node when delete,fuck!");
				pthread_mutex_unlock(&listlock);
				return ret;
			}
			long long costtime=getTime()-node->startTime;
			if(node->readCount!=0)
				node->readTime=costtime;
			else
				node->writeTime=costtime;
			if(writeToFileList.length != MAX_LENGTH){
				writeToFileList.writeToFileArray[writeToFileList.length]=node;
				writeToFileList.length++;
				pthread_mutex_unlock(&listlock);   //释放锁
			}else{
				pthread_mutex_unlock(&listlock);
				char* result;char* result1;
				result = strstr(node -> threadName, "main");
				result1 = strstr(node -> threadName, "SharedPreference");
				if(result != NULL || result1 != NULL){
					free(node);
				}else{
					//如果有其他线程在占用锁，则直接返回，防止死锁
					int lock = pthread_mutex_trylock(&writeToFilelock); //这里定义一个新的锁

					if(writeToFileList.length == MAX_LENGTH)
					{
						if (lock != 0){
							return ret;
						}
						if(updateWriteToFile()){
							LOGE("updateWriteToFile failed!");
						}else{
							haveWriteFile = true;
						}
					}
					pthread_mutex_unlock(&writeToFilelock);
				}
			}
		}
	}
	if(haveWriteFile && getFileSize(nameForFileIO) > MAX_FILESIZE_UPLOAD){
		//LOGD("begin to upload");
		char filenamebackup[MAX_FILENAME_LEN];
		memset(filenamebackup,'\0',sizeof(filenamebackup));
		strcat(filenamebackup, dirForFileUpload);
		//上传云分析的文件需要加上时间戳，否则造成云分析任务被覆盖
		char timestamp[15];
		memset(timestamp,'\0',sizeof(timestamp));
		sprintf(timestamp, "%ld",getTime());
		strcat(filenamebackup,"/IOMonitorBackup_");
		strcat(filenamebackup,timestamp);
		strcat(filenamebackup,".io");
		rename(nameForFileIO,filenamebackup);
		//	LOGD("IOMonitor=true,dumpPath=%s",filenamebackup);
		char dirforuploadfinal[MAX_FILENAME_LEN];
		memset(dirforuploadfinal, '\0', sizeof(dirforuploadfinal));
		if(renameDirForUpload(dirforuploadfinal) || rename(dirForFileUpload, dirforuploadfinal)){
			//LOGE("rename dir failed");
		}
		callbackForUpload(dirforuploadfinal);
		//LOGD("dirforuploadfinal:%s", dirforuploadfinal);
	}

    pthread_mutex_lock(&map_close_lock);
    map_close[threadId] = 0;
    pthread_mutex_unlock(&map_close_lock);

	return ret;
}

ssize_t my_read(int fd, void* buf, size_t count){
	int readsize = -1;

	readsize = ((ssize_t(*)(int, void*, size_t))old_fun[1])(fd,buf,count);

	if(readsize!=-1){
		pfilestat node=findNode(head,fd);
		if(node!=NULL)
		{
			node->readCount++;
			node->readBytes+=readsize;
		}
	}
	return readsize;
}

ssize_t my_write(int fd, const void* buf, size_t count){
	int writesize = -1;

	writesize = ((ssize_t(*)(int, const void*, size_t))old_fun[2])(fd, buf,count);

	if(writesize!=-1){
		pfilestat node=findNode(head,fd);
		if(node!=NULL){
			node->writeCount++;
			node->writeBytes += writesize;
		}
	}
	return writesize;
}

ssize_t my_pread(int fd, void *buf, size_t nbytes, off_t offset){
	int readsize = ((int(*)(int, void*, size_t, off_t))old_fun[4])(fd,buf,nbytes,offset);
	if(readsize!=-1){
		pfilestat node=findNode(head,fd);
		if(node!=NULL){
			//	LOGD("%lld:pread:%s,%d,%ld",getTime(),node->filePath,readsize,offset);
			node->readCount++;
			node->readBytes+=readsize;
		}
	}
	return readsize;
}

ssize_t my_pwrite(int fd, const void *buf, size_t nbytes, off_t offset){
	int writesize = ((int(*)(int, const void*, size_t, off_t))old_fun[6])(fd,buf,nbytes,offset);
	if(writesize!=-1){
		pfilestat node=findNode(head,fd);
		if(node!=NULL){
			//	LOGD("%lld:pwrite:%s,%d,%ld",getTime(), node->filePath,writesize,offset);
			node->writeCount++;
			node->writeBytes += writesize;
		}
	}
	return writesize;
}

void save_sqlite_detail(const char* type, const char* filePath, const void* buf, size_t size, off64_t offset){
	pthread_mutex_lock(&sqlitelock);
	memset(sqlInfoWriteToFile.sqlInfoArray[sqlInfoWriteToFile.curlen], '\0', SQLINFO_LEN);
	char stackTrace[MAX_STACK_LEN] = {0};
	if(SDK_VERSION < 21){
		getJavaStackTrace(stackTrace, MAX_STACK_LEN);
	}else{
		//artGetJavaStack(stackTrace);
	}

	if((int)offset == 0 and (int)((char*)buf)[0] == 83){
		sprintf(sqlInfoWriteToFile.sqlInfoArray[sqlInfoWriteToFile.curlen], "%ld,%s,%s,%d,%lld,%d,%s\n", getTime(),type, filePath, size, offset, (int)((char*)buf)[100], stackTrace);
	}else{
		sprintf(sqlInfoWriteToFile.sqlInfoArray[sqlInfoWriteToFile.curlen], "%ld,%s,%s,%d,%lld,%d,%s\n", getTime(), type, filePath, size, offset, (int)((char*)buf)[0], stackTrace);
	}
	sqlInfoWriteToFile.curlen++;

	if(sqlInfoWriteToFile.curlen == (SQLINFO_COUNT - 1)){
		writeSQLDetailInfo();
	}
	pthread_mutex_unlock(&sqlitelock);
}

/*
 * sqlite文件用Btree结构存储
 * pagetype(2:B-tree内部页，5：B+tree内部页，10：B-tree叶子页，13：B+tree叶子页)
 */

void save_sqlite_summary(int type, const char* filePath, const void* buf, size_t size, off64_t offset){
	/*judge page type, if "journal" in filaPath, return.
     * 先把other page的情况剔除，因为显示出来对分析问题帮助也不大
     */
	char* result;
	result = strstr((char*)filePath,"journal");
	if(result != NULL){
		return;
	}
	int pagetype = -1;

	if((int)offset == 0 && (int)((char*)buf)[0] == 83 && (int)((char*)buf)[1] == 81){
		pagetype = (int)((char*)buf)[100];
	}else{
		pagetype = (int)((char*)buf)[0];
	}
	char stackTrace[MAX_STACK_LEN] = {0};
	if(SDK_VERSION < 21){
		getJavaStackTrace(stackTrace, MAX_STACK_LEN);
	}else{
		//artGetJavaStack(stackTrace);
	}
	pthread_mutex_lock(&sqlitesummarylock);
	map<string, sqlSummaryInfo>::iterator iter = sqlSummaryInfoMap.find(stackTrace);
	if (iter == sqlSummaryInfoMap.end()){
		sqlSummaryInfo item = {"",0,0,0,0,0,0,0};
		switch(pagetype){
			case 2:
				item.indexInter++;
				break;
			case 5:
				item.tableInter++;
				break;
			case 10:
				item.indexLeaf++;
				break;
			case 13:
				item.tableLeaf++;
				break;
			case 0:
				if(size/1024 > 0){
					item.overFlow++;
					break;
				}
			default:
				pthread_mutex_unlock(&sqlitesummarylock);
				return;
		}
		if(type == SQL_TYPE_READ){
			item.readSize += size;
		}else{
			item.writeSize += size;
		}
		item.fileName = filePath;
		sqlSummaryInfoMap.insert( map<string, sqlSummaryInfo>::value_type (stackTrace, item));
	}else{
		switch(pagetype){
			case 2:
				iter->second.indexInter++;
				break;
			case 5:
				iter->second.tableInter++;
				break;
			case 10:
				iter->second.indexLeaf++;
				break;
			case 13:
				iter->second.tableLeaf++;
				break;
			case 0:
				if(size/1024 > 0){
					iter->second.overFlow++;
					break;
				}
			default:
				pthread_mutex_unlock(&sqlitesummarylock);
				return;
		}
		if(type == SQL_TYPE_READ){
			iter->second.readSize += size;
		}else{
			iter->second.writeSize += size;
		}
	}
	if(sqlSummaryInfoMap.size()  == SQLINFO_COUNT){
		writeSQLSummaryInfo();
	}
	pthread_mutex_unlock(&sqlitesummarylock);
}

ssize_t my_pread64(int fd, void *buf, size_t nbytes, off64_t offset){
	int readsize = ((int(*)(int, void*, size_t, off64_t))old_fun[5])(fd,buf,nbytes,offset);

    pid_t threadId = gettid();

    pthread_mutex_lock(&map_pread64_lock);
    map<int, int>::iterator iter = map_pread64.find(threadId);
    if(iter==map_pread64.end()){
        map_pread64.insert(map<int,int>::value_type(threadId,1));
    } else if(iter->second > 0){
		pthread_mutex_unlock(&map_pread64_lock);
        return readsize;
    }else{
        iter->second = 1;
    }
    pthread_mutex_unlock(&map_pread64_lock);

	if(readsize!=-1){
		pfilestat node=findNode(head,fd);
		if(node!=NULL&&node->isSQL){
			node->readCount++;
			node->readBytes+=readsize;
			if(saveInfoType != 1 && !ONPAUSE){
				save_sqlite_summary(SQL_TYPE_READ, node->filePath, buf, readsize, offset);
			}
		}
	}

    pthread_mutex_lock(&map_pread64_lock);
    map_pread64[threadId] = 0;
    pthread_mutex_unlock(&map_pread64_lock);

	return readsize;
}

ssize_t my_pwrite64(int fd, const void* buf, size_t nbytes, off64_t offset){

	int writesize = ((int(*)(int, const void*, size_t, off64_t))old_fun[7])(fd,buf,nbytes,offset);

    pid_t threadId = gettid();

    pthread_mutex_lock(&map_pwrite64_lock);
    map<int, int>::iterator iter = map_pwrite64.find(threadId);
    if(iter==map_pwrite64.end()){
        map_pwrite64.insert(map<int,int>::value_type(threadId,1));
    } else if(iter->second > 0){
		pthread_mutex_unlock(&map_pwrite64_lock);
        return writesize;
    }else{
        iter->second = 1;
    }
    pthread_mutex_unlock(&map_pwrite64_lock);

	if(writesize!=-1){
		pfilestat node=findNode(head,fd);
		if(node!=NULL&&node->isSQL){
			//	LOGD("%lld:pwrite64:%s,%d,%lld",getTime(), node->filePath,writesize,offset);
			node->writeCount++;
			node->writeBytes += writesize;
			if(saveInfoType != 1 && !ONPAUSE){
				save_sqlite_summary(SQL_TYPE_WRITE, node->filePath, buf, writesize, offset);
			}
		}
	}

    pthread_mutex_lock(&map_pwrite64_lock);
    map_pwrite64[threadId] = 0;
    pthread_mutex_unlock(&map_pwrite64_lock);

	return writesize;
}

void handle_sqlite(const char* zSql, int nBytes, char* sqlascii)
{
	int j=0;
	for(int i =0 ;i< nBytes;i++){
		if(zSql[i]!='\0'){
			if(zSql[i]==','){
				sqlascii[j] = '#';
			}
			else if(zSql[i]=='\r' || zSql[i]=='\n'){
				continue;
			}
			else{
				sqlascii[j] = zSql[i];
			}
			j++;
		}
	}
}

int my_sqlite3_open_v2(const char* filename,void **ppDb, int flags,const char *zVfs){

    int ret = ((int(*)(const char*,void**,int,const char*))old_fun[9])(filename,ppDb,flags,zVfs);

    if(saveInfoType==1){
        return ret;
    }
	string filepath = filename;
	vector<string>::iterator r = find(sqlfilePath.begin(),sqlfilePath.end(),filepath);
	if(r==sqlfilePath.end()){
		sqlfilePath.push_back(filepath);
	}

	return ret;
}


/*
*zSql:UTF-16 encoded SQL statement.
*/

int my_sqlite3_prepare16_v2(void* db, const char *zSql, int nBytes, void** ppStmt, const char** pzTail){
	if(CACHEHITSWITCH){
//		bool foundMethod =  HasNeedJavaMethod("SQLiteConnection", "acquirePreparedStatement");
//		if(foundMethod){
		char* sqlascii = new char[nBytes];
		memset(sqlascii,'\0',nBytes);
		handle_sqlite(zSql, nBytes, sqlascii);
		string sql(sqlascii);
		map<string, int>::iterator iterSqlMiss = mapSqllMiss.find(sql);
		if(iterSqlMiss != mapSqllMiss.end()){
			iterSqlMiss->second++;
		}
		else{
			mapSqllMiss[sql]=1;
		}
		delete[] sqlascii;
//		}
	}

	int ret = ((int(*)(void*,const char*, int, void**, const char**))old_fun[8])(db, zSql, nBytes, ppStmt, pzTail);
    if(saveInfoType == 1){
        return ret;
    }
	if(symState == -1){
		LOGE("sql do not exec explain, because the getSymRes is -1 which get last time !");
		return ret;
	}
	if(symState == 1 && getSqlite3Fun()){
		LOGE("getSqlite3Fun: get sym error!");
		return ret;
	}

    pid_t threadId = gettid();

    pthread_mutex_lock(&map_prepare16_v2_lock);
    map<int, int>::iterator iter = map_prepare16_v2.find(threadId);
    if(iter==map_prepare16_v2.end()){
        map_prepare16_v2.insert(map<int,int>::value_type(threadId,1));
    } else if(iter->second > 0){
		pthread_mutex_unlock(&map_prepare16_v2_lock);
        return ret;
    }else{
        iter->second = 1;
    }
    pthread_mutex_unlock(&map_prepare16_v2_lock);

	if(saveInfoType != 1 && ret == SQLITE_OK){
		char explain[] = "EXPLAIN QUERY PLAN ";
		char newsql[(sizeof(explain)-1)*2+nBytes];
		memset(newsql,0, sizeof(newsql));
		for(int i=0; i<(sizeof(explain)-1)*2; i++){
			if(i%2==0){
				newsql[i]=explain[i/2];
			}
			else{
				newsql[i]='\0';
			}
		}
		for(int i=0; i<nBytes; i++){
			newsql[i+(sizeof(explain)-1)*2] = zSql[i];
		}
		void *newpStmt;
		int newret = ((int(*)(void*,const char*, int, void**, const char**))old_fun[8])(db, newsql, sizeof(newsql), &newpStmt, NULL);
		//执行计划不需要取堆栈
		if(newret == SQLITE_OK && newpStmt != NULL){
			pthread_mutex_lock(&sqliteexplainlock);
			char* sqlascii = new char[nBytes];
			memset(sqlascii,'\0',nBytes);
			handle_sqlite(zSql, nBytes, sqlascii);
			while (((int(*)(void*))func_sqlite3_step)(newpStmt) == SQLITE_ROW ){
				char* plain = ((char*(*)(void*,int))func_sqlite3_column_text)(newpStmt,3);
				if(sqlInfoExplainToFile.curlen < SQLINFO_COUNT - 1){
					memset(sqlInfoExplainToFile.sqlInfoArray[sqlInfoExplainToFile.curlen], '\0', SQLEXPLAIN_LEN);
					sprintf(sqlInfoExplainToFile.sqlInfoArray[sqlInfoExplainToFile.curlen], "%s,%s\n", sqlascii, plain);
					sqlInfoExplainToFile.curlen++;
				}
				if(sqlInfoExplainToFile.curlen == (SQLINFO_COUNT - 1) && !ONPAUSE){
					writeSQLExplainInfo();
				}
			}
			((int(*)(void*))func_sqlite3_reset)(newpStmt);
			((int(*)(void*))func_sqlite3_finalize)(newpStmt);
			delete[] sqlascii;
			pthread_mutex_unlock(&sqliteexplainlock);
		}
	} else{
		LOGD("saveInfoType error.");
	}

    pthread_mutex_lock(&map_prepare16_v2_lock);
    map_prepare16_v2[threadId] = 0;
    pthread_mutex_unlock(&map_prepare16_v2_lock);

	return ret;
}

int getSqlite3Fun(){
	void *handle = NULL;
	int res = 0;
	symState = 0;
	if(SDK_VERSION < 24){
		handle = dlopen("libsqlite.so", RTLD_NOW);
		if(handle==NULL){
			LOGE("dlopen libsqlite.so failed.");
			symState = -1;
			return -1;
		}
		func_sqlite3_step = dlsym(handle, "sqlite3_step");
		func_sqlite3_finalize = dlsym(handle, "sqlite3_finalize");
		func_sqlite3_column_text = dlsym(handle, "sqlite3_column_text");
		func_sqlite3_reset = dlsym(handle, "sqlite3_reset");
		func_sqlite3_db_status = dlsym(handle, "sqlite3_db_status");
		func_sqlite3_status = dlsym(handle, "sqlite3_status");

	}else{
		func_sqlite3_step = dlsym_abs_for_a7("sqlite3_step", "/system/lib/libsqlite.so");
		func_sqlite3_finalize = dlsym_abs_for_a7("sqlite3_finalize", "/system/lib/libsqlite.so");
		func_sqlite3_column_text = dlsym_abs_for_a7("sqlite3_column_text", "/system/lib/libsqlite.so");
		func_sqlite3_reset = dlsym_abs_for_a7("sqlite3_reset", "/system/lib/libsqlite.so");
		func_sqlite3_db_status = dlsym_abs_for_a7("sqlite3_db_status", "/system/lib/libsqlite.so");
		func_sqlite3_status = dlsym_abs_for_a7("sqlite3_status", "/system/lib/libsqlite.so");
	}

	if(func_sqlite3_step == NULL){
		LOGE("dlsym sqlite3_step failed");
		res = -1;
	}
	if(func_sqlite3_finalize == NULL){
		LOGE("dlsym func_sqite3_finalize failed");
		res = -1;
	}
	if(func_sqlite3_column_text == NULL){
		LOGE("dlsym func_sqlite3_column_text failed");
		res = -1;
	}
	if(func_sqlite3_reset == NULL){
		LOGE("dlsym func_sqlite3_reset failed");
		res = -1;
	}
	if(func_sqlite3_db_status == NULL){
		LOGE("dlsym func_sqlite3_db_status failed");
		res = -1;
	}
	if(func_sqlite3_status == NULL){
		LOGE("dlsym func_sqlite3_status failed");
		res = -1;
	}
	if(res == -1 && handle != NULL){
		dlclose(handle);
	}
	symState = res;
	return res;
}

int HookAll(){
	int i;
	void *hLibc = NULL;
	void *hSqlite = NULL;
	void *fun = NULL;

	//android 7.1及以下
	if(SDK_VERSION < 26){
		void *new_fun[HOOKSIZE];
		new_fun[0] = (void*)my_close;
		new_fun[1] = (void*)my_read;
		new_fun[2] = (void*)my_write;
		new_fun[3] = (void*)my_open;
		new_fun[4] = (void*)my_pread;
		new_fun[5] = (void*)my_pread64;
		new_fun[6] = (void*)my_pwrite;
		new_fun[7] = (void*)my_pwrite64;
		new_fun[8] = (void*)my_sqlite3_prepare16_v2;
		new_fun[9] = (void*)my_sqlite3_open_v2;
		hLibc = dlopen("libc.so", RTLD_NOW);
		if(SDK_VERSION < 24){
			hSqlite = dlopen("libsqlite.so", RTLD_NOW);
		}

		if(hLibc == NULL){
			LOGE("dlopen libc.so failed");
			return -1;
		}
		if(hSqlite == NULL&&SDK_VERSION < 24){
			LOGE("dlopen libsqlite.so failed");
			return -1;
		}
		void* judgeop = cheackJudgeop();
		if(judgeop){
			hook_fun[1] = "__read";
			hook_fun[2] = "__write";
		}

		for(i=0;i<HOOKSIZE;i++){
			if(i >= HOOKSIZE - 2){
				fun = dlsym_abs_for_a7(hook_fun[i],"/system/lib/libsqlite.so");
			}else{
				fun = dlsym_abs_for_a7(hook_fun[i],"/system/lib/libc.so");
			}
			if(fun == NULL){
				LOGE("dlsym fun[%s] failed", hook_fun[i]);
				return -1;
			}

			int status = registerInlineHook_a((uint32_t)fun, (uint32_t)new_fun[i], (uint32_t **)(old_fun + i));
			if (status != SUCCEED) {
				LOGE("registerInlineHook[%s] failed! %d",hook_fun[i], status);
				return -1;
			}
		}
	}else{
		LOGE("Android sdk version is not support! SDK_VERSION: %d", SDK_VERSION);
		return -1;
	}
	int ret;
	ret = inlineHookAll_a();
	if(ret!=0){
		LOGE("inlineHookAll_a error![%d]",ret);
	}
	return ret;
}

int init_create_sql_file(){
	int fd;
	if(checkAndCreatSQLiteDir()){
		LOGE("error when cheackAndCreatSQLiteDir");
		return -1;
	}
	char sqlfilename[MAX_FILENAME_LEN] = {0};
	strcat(sqlfilename, dirForSQLiteUpload);
	strcat(sqlfilename,"/SQLIOInfo.csv");
	LOGI("create sqlfile success,%s",sqlfilename);
	if(access(sqlfilename,F_OK)){
		LOGD("%s don't exist,now create!",sqlfilename);
		if((fd = open(sqlfilename,O_RDWR|O_CREAT|O_APPEND, 0666))!=-1){
			const char* table="stackTrace,fileName,tableInter,tableLeaf,indexInter,indexLeaf,overFlow,readSize,writeSize\n";
			write(fd,table,strlen(table));
			close(fd);
		}else{
			LOGE("create %s file failed.%s",sqlfilename,(char*)strerror(errno));
			return -1;
		}
	}
	memset(sqlfilename, '\0', sizeof(sqlfilename));
	strcat(sqlfilename, dirForSQLiteUpload);
	strcat(sqlfilename,"/SQLExplainInfo.csv");
	if(access(sqlfilename,F_OK)){
		LOGD("%s don't exist,now create!",sqlfilename);
		if((fd = open(sqlfilename,O_RDWR|O_CREAT|O_APPEND, 0666))!=-1){
			const char* table="sql,plain\n";
			write(fd,table,strlen(table));
			close(fd);
		}else{
			LOGE("create %s file failed.%s",sqlfilename,(char*)strerror(errno));
			return -1;
		}
	}
	//write hitmiss file
	if(CACHEHITSWITCH){
		memset(sqlfilename, '\0', sizeof(sqlfilename));
		strcat(sqlfilename, dirForSQLiteUpload);
		strcat(sqlfilename,"/SQLHitMissInfo.csv");
		if(access(sqlfilename,F_OK)){
			LOGD("%s don't exist,now create!",sqlfilename);
			if((fd = open(sqlfilename,O_RDWR|O_CREAT|O_APPEND, 0666))!=-1){
				const char* table="dbname,cahce_used_byte,cahce_write_times,cache_hit_times,cache_miss_times,hit_percent\n";
				write(fd,table,strlen(table));
				close(fd);
			}else{
				LOGE("create %s file failed.%s",sqlfilename,(char*)strerror(errno));
				return -1;
			}
		}
		//write sqlmiss file
		memset(sqlfilename, '\0', sizeof(sqlfilename));
		strcat(sqlfilename, dirForSQLiteUpload);
		strcat(sqlfilename,"/SQLMissDetail(Java).csv");
		if(access(sqlfilename,F_OK)){
			LOGD("%s don't exist,now create!",sqlfilename);
			if((fd = open(sqlfilename,O_RDWR|O_CREAT|O_APPEND, 0666))!=-1){
				const char* table="sql,misscount\n";
				write(fd,table,strlen(table));
				close(fd);
			}else{
				LOGE("create %s file failed:%s",sqlfilename,(char*)strerror(errno));
				return -1;
			}
		}
	}
	return 0;
}

int init_create_io_file(){
	int fd;
	if(checkAndCreatFileDir()){
		LOGE("error when cheackAndCreatFileDir");
		return -1;
	}
	if(!haveInitFileIOName){
		strcat(nameForFileIO, dirForFileUpload);
		strcat(nameForFileIO,"/IOInfo.csv");
		haveInitFileIOName = true;
		LOGI("iofile create success,%s",nameForFileIO);
	}
	if(access(nameForFileIO,F_OK)){
		LOGD("%s don't exist,now create!",nameForFileIO);
		if((fd = open(nameForFileIO,O_RDWR|O_CREAT|O_APPEND, 0666))!=-1){
			const char* table="filepath,process,thread,readcount,readbytes,readtime,writecount,writebytes,writetime,stacktrace,timeStamp\n";
			write(fd,table,strlen(table));
			close(fd);
		}else{
			LOGE("create %s file failed.%s",nameForFileIO, (char*)strerror(errno));
			return -1;
		}
	}
	return 0;
}
//创建文件
int init_step_create_file(){
	if(saveInfoType != 1){
		if(init_create_sql_file()){
			LOGE("init_step_create_file error");
			return -1;
		}
	}
	if(saveInfoType != 2){
		if(init_create_io_file()){
			LOGE("init_create_io_file error.");
			return -1;
		}
	}
	return 0;
}

int init_step_get_env(){
	long initTime=getTime();
	head=createList();
	//pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
	pthread_mutexattr_settype(&attr,PTHREAD_MUTEX_ERRORCHECK);
	pthread_mutex_init(&listlock, &attr);
	pthread_mutex_init(&writeToFilelock,NULL);
    pthread_mutex_init(&map_close_lock,NULL);
    pthread_mutex_init(&map_open_lock,NULL);
    pthread_mutex_init(&map_pread64_lock,NULL);
    pthread_mutex_init(&map_pwrite64_lock,NULL);
    pthread_mutex_init(&map_prepare16_v2_lock,NULL);
	if(saveInfoType != 1){
		//	pthread_mutex_init(&sqlitelock,NULL);
		pthread_mutex_init(&sqlitesummarylock,NULL);
		pthread_mutex_init(&sqliteexplainlock,NULL);
	}
	memset(processName,'\0',sizeof(processName));
	getN_ProcessName(processName);
	if(strlen(processName)==0){
		LOGE("cannot get process name.");
	}
	memset(sdcardPath,'\0',sizeof(sdcardPath));
	if(getAPMRoot(sdcardPath)){
		LOGE("getAPMRoot error!");
		return -1;
	}
	test_mmap();
	LOGD("init cost time: %ld ms.",getTime()-initTime);
	return 0;
}

//saveAllData只有在数据库测试时，才会调用
void saveAllData(){
	if(saveInfoType != 1){
//    	pthread_mutex_lock(&sqlitelock);
//    	writeSQLDetailInfo();
//    	pthread_mutex_unlock(&sqlitelock);

		pthread_mutex_lock(&sqliteexplainlock);
		writeSQLExplainInfo();
		pthread_mutex_unlock(&sqliteexplainlock);

		if(CACHEHITSWITCH){
			pthread_mutex_lock(&sqlitemisslock);
			writeSqlMiss();
			pthread_mutex_unlock(&sqlitemisslock);
		}

		pthread_mutex_lock(&sqlitesummarylock);
		writeSQLSummaryInfo();
		pthread_mutex_unlock(&sqlitesummarylock);
	}
	updateWriteToFile();
}

//这个函数获得未落地的IO操作
IoOperationInfo* getNotToFileIoOperation(){
	if(writeToFileList.length==0)
	{
		LOGV("writeToFileList is NULL");
		return 0;
	}
	IoOperationInfo* ioInfo = new IoOperationInfo();
	memset(ioInfo,0,sizeof(IoOperationInfo));
	for(int i=0;i<writeToFileList.length;i++)
	{
		ioInfo->ioOperationCount += writeToFileList.writeToFileArray[i]->readCount;
		ioInfo->ioOperationCount += writeToFileList.writeToFileArray[i]->writeCount;
		ioInfo->ioOperationBytes += writeToFileList.writeToFileArray[i]->readBytes;
		ioInfo->ioOperationBytes += writeToFileList.writeToFileArray[i]->writeBytes;
	}
	return ioInfo;
}


bool cheackCrash()
{
	if(strlen(crashFilePath)!=0)
	{
		FILE *fp = NULL;;
		fp = fopen(crashFilePath, "r");
		if(fp == NULL)
		{
			LOGE("cannot create %s",crashFilePath);
			return false;
		}

		char line[100] = {0};
		while(fgets(line, 100, fp)!=NULL)
		{
			int len = strlen(line);
			if(len <= 0){
				break;
			}
			char *v1 = strchr(line, '=');
			if(v1 == NULL)
				break;
			*v1++ = '\0';
			char *v2 = v1 + 1;
			*v2 = '\0'; //"1"后边不是'\0'，是一堆类似空格的字符，这里给截断
			if(strcmp(v1,"1")==0)
			{
				LOGE("this action may cause a crash.");
				return true;
			}
		}
		fclose(fp);
	}
	return false;
}

bool initSignal()
{
	memset(crashFilePath,'\0',sizeof(crashFilePath));
	if(getAPMRoot(crashFilePath))
	{
		return false;
	}

	strcat(crashFilePath,"/crashProtect");

	FILE *fp = NULL;
	fp = fopen(crashFilePath, "at+");
	if(fp == NULL)
	{
		LOGE("cannot create %s",crashFilePath);
		return false;
	}

	fclose(fp);

	registerSignalHandler();
	return true;
}

void* cheackJudgeop(){

	void* addr = 0;

	addr = dlsym_abs_for_a7("judgeop","/system/lib/libc.so");
	return addr;
}


extern "C"{
JNIEXPORT void JNICALL Java_com_tencent_qapmsdk_io_util_NativeMethodHook_doHook(JNIEnv *env, jobject obj, jint type, jstring appVersion, jint SDKVersion, jobject callback){
	//LOGD("Native Start Called, have set callback object");
	//创建全局引用
	objectforcallback = env->NewGlobalRef(callback);
	const char* app_version = env->GetStringUTFChars(appVersion, 0);
	memset(APP_VERSION, '\0', sizeof(APP_VERSION));
	strcpy(APP_VERSION, app_version);
	HAVE_APP_VERSION = true;
	env->ReleaseStringUTFChars(appVersion, app_version);
	SDK_VERSION = SDKVersion;
	LOGI("APP_VERSION:%s, SDK_VERSION:%d", APP_VERSION, SDK_VERSION);

	if(cheackCrash()){
		return;
	}

	if(!ONSTART){
		saveInfoType = type;
		if(init_step_get_env() || init_step_create_file()){
			LOGE("init_step_get_env or init_step_create_file error");
			return;
		}
		if(HookAll()){
			LOGE("HookAll error");
			return;
		}
		ONSTART = true;
	}else{
		if(ONPAUSE){
			//onpause之后，文件可能被移走，重新检查一下文件
			if(init_step_create_file()){
				LOGE("init_step_create_file error!");
			}
			ONPAUSE = false;
		}
	}
}

JNIEXPORT void JNICALL Java_com_tencent_qapmsdk_io_util_NativeMethodHook_stop(JNIEnv *env, jobject obj){
	LOGD("Native Stop Called");
	ONPAUSE = true;
	saveAllData();
}

JNIEXPORT void JNICALL Java_com_tencent_qapmsdk_io_util_NativeMethodHook_saveAllData(JNIEnv *env, jobject obj){
	saveAllData();
}

//设置Db路径
JNIEXPORT void JNICALL Java_com_tencent_qapmsdk_io_util_NativeMethodHook_setDbName(JNIEnv* env, jclass clazz, jstring dbName) {
	const char *nativeString = (env)->GetStringUTFChars(dbName, JNI_FALSE);
//		lastDbName = string(nativeString);
	(env)->ReleaseStringUTFChars(dbName, nativeString);
}

JNIEXPORT void JNICALL Java_com_tencent_qapmsdk_io_util_NativeMethodHook_writehm(JNIEnv* env, jclass clazz) {
	writeHitMissInfo();
}

/*
 * 统计操作IO次数以及读/写字节数
 * operateCount：IO操作次数
 * operateBytes：IO操作字节数
 */
JNIEXPORT jlongArray JNICALL Java_com_tencent_qapmsdk_io_FileIOMonitor_getIOStatus(JNIEnv* env,jclass clazz){

	IoOperationInfo* ioOperation = NULL;

	ioOperation = getNotToFileIoOperation();
	if(ioOperation==NULL){
		ioOperation = new IoOperationInfo();
		memset(ioOperation,0,sizeof(IoOperationInfo));
	}
	ioOperation->ioOperationCount += g_IoOperationInfo.ioOperationCount;
	ioOperation->ioOperationBytes += g_IoOperationInfo.ioOperationBytes;
	jlongArray values;
	values = env->NewLongArray(2);
	jlong *elems = env->GetLongArrayElements(values, NULL);
	elems[0] = ioOperation->ioOperationCount;
	elems[1] = ioOperation->ioOperationBytes;
	env->ReleaseLongArrayElements(values, elems, 0);
	delete ioOperation;
	ioOperation = NULL;
	return values;
}

JNIEXPORT void JNICALL Java_com_tencent_qapmsdk_common_ILogUtil_setDebugNative(JNIEnv *env, jclass clazz,jboolean isDebug){
//	g_debug = isDebug;
}
/*
 * 加载lib之后，注册signal处理函数
 */
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved)
{
	JNIEnv* env = NULL;
	if (vm->GetEnv((void**)&env, JNI_VERSION_1_4) != JNI_OK) {
		return JNI_ERR;
	}

    jclass logUtilClass = env->FindClass("com/tencent/qapmsdk/common/ILogUtil");
    if(logUtilClass!=NULL){
        jfieldID logLevel = env->GetStaticFieldID(logUtilClass, "logLevel", "I");
        if(logLevel!=NULL){
            jint level = env->GetStaticIntField(logUtilClass, logLevel);
            setNativeLogLevel(level);
        }
    }

    g_IoOperationInfo.ioOperationBytes = 0;
    g_IoOperationInfo.ioOperationCount = 0;
	char sdk_ver_str[PROPERTY_VALUE_MAX] = {0};
	__system_property_get("ro.build.version.sdk", sdk_ver_str);
	int sdk_ver = atoi(sdk_ver_str);
	SDK_VERSION = sdk_ver;
//	initSignal();
	return JNI_VERSION_1_4;

}

/*
 * 卸载lib的时候卸载signal处理函数
 */
JNIEXPORT void JNICALL JNI_OnUnload(JavaVM* vm, void* reserved)
{
	unregisterSignalHandler();
}

}

int callbackForUpload(char* uploadPath){
	if(SDK_VERSION > 23){
		getJNIEnvPoint = (JNIEnv* (*)())dlsym_abs_for_a7("_ZN7android14AndroidRuntime9getJNIEnvEv","/system/lib/libandroid_runtime.so");
		if(getJNIEnvPoint==NULL){
			LOGE("get getJNIEnv method is NULL");
			return -1;
		}
	}else{
		if(run_handle==NULL){
			run_handle = dlopen("/system/lib/libandroid_runtime.so", RTLD_NOW);
			if(run_handle==NULL){
				LOGE("dlopen runtime.so error");
				return -1;
			}

			getJNIEnvPoint =(JNIEnv* (*)())dlsym(run_handle,"_ZN7android14AndroidRuntime9getJNIEnvEv");
			if(getJNIEnvPoint==NULL){
				LOGE("get getJNIEnv method is NULL");
				return -1;
			}
			LOGD("callbackForUpload:getjniENV,JNIPoint,%X",getJNIEnvPoint);
		}
	}
	JNIEnv* env = getJNIEnvPoint();
	if(env==NULL){
		LOGE("env is NULL");
		return -1;
	}

	jthrowable exc = env->ExceptionOccurred();
	if(exc) {
		env->ExceptionDescribe();
		env->ExceptionClear();
		env->DeleteLocalRef(exc);
		LOGE("dvm occur error");
		return -1;
	}
	jclass objectClass = env->FindClass("java/lang/Object");
	jmethodID equalsMethod = env->GetMethodID(objectClass, "equals", "(Ljava/lang/Object;)Z");
	if(objectforcallback == NULL){
		LOGE("objectforcallback is NULL");
		return -1;
	}
	jobject uploaddir = (jobject)env->NewStringUTF(uploadPath);
	env->CallBooleanMethod(objectforcallback, equalsMethod, uploaddir);
	exc = env->ExceptionOccurred();
	if(exc) {
		env->ExceptionDescribe();
		env->ExceptionClear();
		env->DeleteLocalRef(exc);
		LOGE("find class error");
		return -1;
	}
	env->DeleteLocalRef(objectClass);
	env->DeleteLocalRef(uploaddir);
	return 0;
}

int updateWriteToFile(){
	//judge the file exist or not before write data
	//because the file while be rename by other process
	long startTime=getTime();
	init_create_io_file();
	int savefile_fd=-1;
	if(!USEMMAP){
		if((savefile_fd=open(nameForFileIO,O_RDWR|O_APPEND))==-1){
			LOGE("open file failed:%s",nameForFileIO);
			writeToFileList.length=0;
			return -1;
		}
	}else{
		if((savefile_fd=open(nameForFileIO,O_RDWR))==-1){
			LOGE("open file failed:%s",nameForFileIO);
			writeToFileList.length=0;
			return -1;
		}
	}
	memset(&lock,0,sizeof(lock));
	lock.l_type=F_WRLCK;
	lock.l_whence=SEEK_SET;
	lock.l_start=0;
	lock.l_len=0;
	if(fcntl(savefile_fd,F_SETLK,&lock)==0){
		if(USEMMAP){
			writefile_mmap(savefile_fd, nameForFileIO);
		}else{
			writefile_orig(savefile_fd);
		}
		lock.l_type = F_UNLCK;
		if (fcntl(savefile_fd, F_SETLK, &lock)){
			LOGE("unlock failed");
		}
	}
	else{
		LOGE("get lock error");
	}
	close(savefile_fd);
	writeToFileList.length=0;
	LOGD("writefile cost time:%ld",getTime()-startTime);
	return 0;
}

/*
*将当前缓存列表的内容写到磁盘
*/
int writefile_mmap(int savefile_fd, char* filename){
	if(writeToFileList.length==0)
		return -1;
	int curlen=getFileSize(filename);
	//	LOGD("Curlen is %d",curlen);
	if(curlen < 0){
		return -1;
	}
	int len_file=FILEINFO_LEN*writeToFileList.length+curlen;
	//LOGD("len_file is %d",len_file);
	int trunRet = -2;
	trunRet = truncate(filename,len_file);
	if(trunRet == -1)
	{
		LOGE("truncate error");
		return -1;
	}
	char* map_file=(char*)mmap(NULL,len_file, PROT_READ|PROT_WRITE, MAP_SHARED, savefile_fd, 0);
	int i=0;
	if(map_file == MAP_FAILED){
		LOGE("map error!");
		return -1;
	}
	char content[FILEINFO_LEN];
	pfilestat temp=NULL;
	for(;i<writeToFileList.length;i++){
		memset(content,'\0',sizeof(content));
		temp= writeToFileList.writeToFileArray[i];
		sprintf(content,"%s,%s,%s,%d,%d,%d,%d,%d,%d,%s,%lld\n",temp->filePath,temp->processName,temp->threadName,temp->readCount,temp->readBytes,temp->readTime,temp->writeCount
				,temp->writeBytes,temp->writeTime,temp->stackTrace,temp->startTime);
		//全局变量累加记录IO操作次数
		g_IoOperationInfo.ioOperationCount += temp->readCount;
		g_IoOperationInfo.ioOperationCount += temp->writeCount;
		g_IoOperationInfo.ioOperationBytes += temp->readBytes;
		g_IoOperationInfo.ioOperationBytes += temp->writeBytes;
		int len_item=strlen(content);
		memcpy(map_file+curlen, content, len_item);
		curlen+=len_item;
		free(temp);
		temp=NULL;
	}

	//解除内存映射
	if(munmap(map_file, len_file) == -1){
		LOGE("munmap error");
		return -1;
	}
	trunRet = truncate(filename,curlen);
	if(trunRet == -1)
	{
		LOGE("truncate error");
		return -1;
	}
	return 0;
}

void writefile_orig(int savefile_fd){
	int i=0;
	char content[FILEINFO_LEN];
	pfilestat temp=NULL;
	for(;i<writeToFileList.length;i++){
		memset(content,'\0',sizeof(content));
		temp= writeToFileList.writeToFileArray[i];
		sprintf(content,"%s,%s,%s,%d,%d,%d,%d,%d,%d,%s,%lld\n",temp->filePath,temp->processName,temp->threadName,temp->readCount,temp->readBytes,temp->readTime,temp->writeCount
				,temp->writeBytes,temp->writeTime,temp->stackTrace,temp->startTime);
		//全局变量累加记录IO操作次数
		g_IoOperationInfo.ioOperationCount += temp->readCount;
		g_IoOperationInfo.ioOperationCount += temp->writeCount;
		g_IoOperationInfo.ioOperationBytes += temp->readBytes;
		g_IoOperationInfo.ioOperationBytes += temp->writeBytes;
		write(savefile_fd,content,strlen(content));
		free(temp);
		temp=NULL;
	}
}

void test_mmap(){
	char testfile[MAX_FILENAME_LEN];
	memset(testfile,'\0',sizeof(testfile));
	strcat(testfile,sdcardPath);
	strcat(testfile, "/MagnifierTestFile.txt");

	//如果文件存在先删除
	if(!access(testfile,F_OK)){
		remove(testfile);
	}
	//创建文件
	int fd = open(testfile,O_RDWR|O_CREAT, 0666);
	int len_file = 50;
	int trunRet = -2;
	if( fd == -1)
	{
		LOGE("open error!");
		USEMMAP = false;
		return;
	}
	//该函数会将文件改为len_file指定大小
	trunRet = truncate(testfile,len_file);
	if(trunRet == -1)
	{
		LOGE("truncate error");
		USEMMAP = false;
		close(fd);
		return;
	}
	char* map_file=(char*)mmap(NULL,len_file, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
	if(map_file == MAP_FAILED){
		LOGE("map error!");
		USEMMAP = false;
		close(fd);
		return;
	}
	char* content = "helloworld";
	int len_item = strlen(content) + 1;
	memcpy(map_file, content, len_item);
	if(munmap(map_file, len_file) == -1){
		LOGE("munmap error");
		USEMMAP = false;
		close(fd);
		return;
	}
	trunRet = truncate(testfile,len_item);
	if(trunRet == -1)
	{
		LOGE("truncate error");
		USEMMAP = false;
		close(fd);
		return;
	}

	map_file=(char*)mmap(NULL,len_item, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
	if(strlen(map_file) == 0){
		USEMMAP = false;
		LOGE("sdcard can't write file by mmap, change to use orinal write");
	}
	if(munmap(map_file, len_item) == -1){
		LOGE("munmap error");
		USEMMAP = false;
	}
	close(fd);
	remove(testfile);
}

void writeSQLDetailInfo(){
	long initTime=getTime();
	int i = 0;
	char sqlfilename[MAX_FILENAME_LEN] = {0};
	strcat(sqlfilename, sdcardPath);
	strcat(sqlfilename,"/SQLIOInfo.csv");
	int fd;
	if((fd=open(sqlfilename,O_RDWR|O_APPEND))==-1){
		LOGE("open %s file failed.%s",sqlfilename,(char*)strerror(errno));
		return;
	}

	memset(&fsqldetaillock,0,sizeof(fsqldetaillock));
	fsqldetaillock.l_type=F_WRLCK;
	fsqldetaillock.l_whence=SEEK_SET;
	fsqldetaillock.l_start=0;
	fsqldetaillock.l_len=0;
	if(fcntl(fd,F_SETLK,&fsqldetaillock)==0){
		for(;i<sqlInfoWriteToFile.curlen;i++){
			write(fd, sqlInfoWriteToFile.sqlInfoArray[i], strlen(sqlInfoWriteToFile.sqlInfoArray[i]));
		}
		fsqldetaillock.l_type = F_UNLCK;
		if (fcntl(fd, F_SETLK, &fsqldetaillock)){
			LOGE("unlock failed");
		}
	}
	close(fd);
	sqlInfoWriteToFile.curlen = 0;
	LOGD("write SQLInfo cost:%ld", getTime() - initTime);
}

void writeSQLSummaryInfo(){

	long initTime=getTime();
	char sqlfilename[MAX_FILENAME_LEN] = {0};
	strcat(sqlfilename, dirForSQLiteUpload);
	strcat(sqlfilename,"/SQLIOInfo.csv");
	init_create_sql_file();
	int fd;
	if(!USEMMAP){
		if((fd=open(sqlfilename,O_RDWR|O_APPEND))==-1){
			LOGE("open %s file failed.%s",sqlfilename,(char*)strerror(errno));
			sqlSummaryInfoMap.clear();
			return;
		}
	}else{
		if((fd=open(sqlfilename,O_RDWR))==-1){
			LOGE("open %s file failed.%s",sqlfilename,(char*)strerror(errno));
			sqlSummaryInfoMap.clear();
			return;
		}
	}
	memset(&fsqlsummarylock,0,sizeof(fsqlsummarylock));
	fsqlsummarylock.l_type=F_WRLCK;
	fsqlsummarylock.l_whence=SEEK_SET;
	fsqlsummarylock.l_start=0;
	fsqlsummarylock.l_len=0;
	if(fcntl(fd,F_SETLK,&fsqlsummarylock)==0){
		if(!USEMMAP){
			map<string, sqlSummaryInfo>::iterator iter = sqlSummaryInfoMap.begin();
			char content[FILEINFO_LEN];
			for(;iter != sqlSummaryInfoMap.end(); iter++){
				memset(content,'\0',sizeof(content));
				sprintf(content,"%s,%s,%d,%d,%d,%d,%d,%d,%d\n", iter->first.c_str(), iter->second.fileName.c_str(), iter->second.tableInter, iter->second.tableLeaf, iter->second.indexInter,
						iter->second.indexLeaf, iter->second.overFlow, (iter->second.readSize)/1024, (iter->second.writeSize)/1024);
				write(fd,content,strlen(content));
			}
		}else{
			int curlen=getFileSize(sqlfilename);
			if(curlen < 0){
				fsqlsummarylock.l_type = F_UNLCK;
				if (fcntl(fd, F_SETLK, &fsqlsummarylock)){
					LOGE("unlock failed");
				}
				close(fd);
				sqlSummaryInfoMap.clear();
				return;
			}
			int len_file=FILEINFO_LEN*sqlSummaryInfoMap.size() + curlen;
			truncate(sqlfilename,len_file);
			char* map_file=(char*)mmap(NULL,len_file, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
			if(map_file == MAP_FAILED){
				LOGE("map error!");
				fsqlsummarylock.l_type = F_UNLCK;
				if (fcntl(fd, F_SETLK, &fsqlsummarylock)){
					LOGE("unlock failed");
				}
				close(fd);
				sqlSummaryInfoMap.clear();
				return;
			}
			map<string, sqlSummaryInfo>::iterator iter = sqlSummaryInfoMap.begin();
			char content[FILEINFO_LEN];
			for(;iter != sqlSummaryInfoMap.end(); iter++){
				memset(content,'\0',sizeof(content));
				sprintf(content,"%s,%s,%d,%d,%d,%d,%d,%d,%d\n", iter->first.c_str(), iter->second.fileName.c_str(), iter->second.tableInter, iter->second.tableLeaf, iter->second.indexInter,
						iter->second.indexLeaf, iter->second.overFlow, (iter->second.readSize)/1024, (iter->second.writeSize)/1024);
				int len_item=strlen(content);
				memcpy(map_file+curlen, content, len_item);
				curlen+=len_item;
			}
			if(munmap(map_file, len_file) == -1){
				fsqlsummarylock.l_type = F_UNLCK;
				if (fcntl(fd, F_SETLK, &fsqlsummarylock)){
					LOGE("unlock failed");
				}
				close(fd);
				sqlSummaryInfoMap.clear();
				return;
			}
			truncate(sqlfilename,curlen);
		}
		fsqlsummarylock.l_type = F_UNLCK;
		if (fcntl(fd, F_SETLK, &fsqlsummarylock)){
			LOGE("unlock failed");
		}
	}
	close(fd);
	sqlSummaryInfoMap.clear();
	LOGD("write SQLSummaryInfo cost:%ld", getTime() - initTime);
}

void writeSQLExplainInfo(){
	long initTime=getTime();
	int i = 0;
	char sqlfilename[MAX_FILENAME_LEN] = {0};
	strcat(sqlfilename, dirForSQLiteUpload);
	strcat(sqlfilename,"/SQLExplainInfo.csv");
	init_create_sql_file();
	int fd;
	if(!USEMMAP){
		if((fd=open(sqlfilename,O_RDWR|O_APPEND))==-1){
			LOGE("open %s file failed.%s",sqlfilename,(char*)strerror(errno));
			sqlInfoExplainToFile.curlen = 0;
			return;
		}
	}else{
		if((fd=open(sqlfilename,O_RDWR))==-1){
			LOGE("open %s file failed.%s",sqlfilename,(char*)strerror(errno));
			sqlInfoExplainToFile.curlen = 0;
			return;
		}
	}
	memset(&fsqlexpainlock,0,sizeof(fsqlexpainlock));
	fsqlexpainlock.l_type=F_WRLCK;
	fsqlexpainlock.l_whence=SEEK_SET;
	fsqlexpainlock.l_start=0;
	fsqlexpainlock.l_len=0;
	if(fcntl(fd,F_SETLK,&fsqlexpainlock)==0){
		if(!USEMMAP){
			for(;i<sqlInfoExplainToFile.curlen;i++){
				write(fd, sqlInfoExplainToFile.sqlInfoArray[i], strnlen(sqlInfoExplainToFile.sqlInfoArray[i],200));
			}
		}else{
			int curlen = getFileSize(sqlfilename);
			if(curlen < 0){
				fsqlexpainlock.l_type = F_UNLCK;
				if (fcntl(fd, F_SETLK, &fsqlexpainlock)){
					LOGE("unlock failed");
				}
				close(fd);
				sqlInfoExplainToFile.curlen = 0;
				return;
			}
			int len_file = SQLEXPLAIN_LEN*sqlInfoExplainToFile.curlen + curlen;
			truncate(sqlfilename, len_file);
			char* map_file=(char*)mmap(NULL,len_file, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
			if(map_file == MAP_FAILED){
				fsqlexpainlock.l_type = F_UNLCK;
				if (fcntl(fd, F_SETLK, &fsqlexpainlock)){
					LOGE("unlock failed");
				}
				close(fd);
				sqlInfoExplainToFile.curlen = 0;
				return;
			}
			for(;i<sqlInfoExplainToFile.curlen;i++){
				//JOOX上报crash，strlen添加保护
				if(sqlInfoExplainToFile.sqlInfoArray[i]==NULL)
				{
					LOGE("the sqlInfoExplainToFile.sqlInfoArray[%d] is null",i);
					return;
				}
				int len_item = strnlen(sqlInfoExplainToFile.sqlInfoArray[i],200);
				if(len_item >= SQLEXPLAIN_LEN)
					continue;
				memcpy(map_file+curlen, sqlInfoExplainToFile.sqlInfoArray[i], len_item);
				curlen += len_item;
			}
			if(munmap(map_file, len_file) == -1){
				fsqlexpainlock.l_type = F_UNLCK;
				if (fcntl(fd, F_SETLK, &fsqlexpainlock)){
					LOGE("unlock failed");
				}
				close(fd);
				sqlInfoExplainToFile.curlen = 0;
				return;
			}
			truncate(sqlfilename,curlen);
		}
		fsqlexpainlock.l_type = F_UNLCK;
		if (fcntl(fd, F_SETLK, &fsqlexpainlock)){
			LOGE("unlock failed");
		}
		close(fd);
		sqlInfoExplainToFile.curlen = 0;
	}
	LOGD("write SQLExplainInfo cost:%ld", getTime() - initTime);
}

void writeSqlMiss(){
	long initTime=getTime();
	int i = 0;
	int j = 0;
	char sqlfilename[MAX_FILENAME_LEN] = {0};
	strcat(sqlfilename, dirForSQLiteUpload);
	strcat(sqlfilename,"/SQLMissDetail(Java).csv");
	init_create_sql_file();
	int fd;
	if((fd=open(sqlfilename,O_RDWR|O_APPEND))==-1){
		LOGE("open %s file failed.%s",sqlfilename,(char*)strerror(errno));
		return;
	}
	memset(&fsqlexpainlock,0,sizeof(fsqlexpainlock));
	fsqlexpainlock.l_type=F_WRLCK;
	fsqlexpainlock.l_whence=SEEK_SET;
	fsqlexpainlock.l_start=0;
	fsqlexpainlock.l_len=0;
	if(fcntl(fd,F_SETLK,&fsqlexpainlock)==0){
		map<string,int>::iterator iter = mapSqllMiss.begin();
		char* info = new char[1024];
		for(; iter != mapSqllMiss.end(); iter++){
			memset(info,'\0',1024);
			sprintf(info, "%s,%d\n", iter->first.c_str(), iter->second);
			write(fd, info, strlen(info));
			i++;
			j=j+iter->second;
		}
		memset(info,'\0',1024);
		sprintf(info, "\n\n%s,%d\n%s,%d\n", "miss sql sort", i, "total count", j);
		write(fd, info, strlen(info));
		delete info;
		fsqlexpainlock.l_type = F_UNLCK;
		if (fcntl(fd, F_SETLK, &fsqlexpainlock)){
			LOGE("unlock failed");
		}
		close(fd);
		mapSqllMiss.clear();
	}
	LOGD("write SQLMissDetail(Java) cost:%ld", getTime() - initTime);
}

void writeHitMissInfo(){
	long initTime=getTime();
	char sqlfilename[MAX_FILENAME_LEN] = {0};
	strcat(sqlfilename, dirForSQLiteUpload);
	strcat(sqlfilename,"/SQLHitMissInfo.csv");
	init_create_sql_file();
	int fd;
	if((fd=open(sqlfilename,O_RDWR|O_APPEND))==-1){
		LOGE("open file failed:%s",sqlfilename);
		return;
	}
	memset(&fsqlsummarylock,0,sizeof(fsqlsummarylock));
	fsqlsummarylock.l_type=F_WRLCK;
	fsqlsummarylock.l_whence=SEEK_SET;
	fsqlsummarylock.l_start=0;
	fsqlsummarylock.l_len=0;

	if(fcntl(fd,F_SETLK,&fsqlsummarylock)==0){
		map<string, HitMiss>::iterator iter = mapDbHitMiss.begin();
		char content[1024];
		for(;iter != mapDbHitMiss.end(); iter++){
			memset(content,'\0',sizeof(content));
			sprintf(content,"%s,%d,%d,%d,%d,%.2f%%\n",
					iter->first.c_str(),
					iter->second.cache_used,
					iter->second.cache_write,
					iter->second.cache_hit,
					iter->second.cache_miss,
					(float)iter->second.cache_hit/(iter->second.cache_hit+iter->second.cache_miss)*100);
			write(fd,content,strlen(content));
		}

		if(func_sqlite3_status != NULL) {
			memset(content, '\0', sizeof(content));
			sprintf(content, "\n%s\n",
					"sqlite_summary,current,max");
			write(fd, content, strlen(content));
			int currentvalue;
			int maxvalue;
			int const summarycount = 6;
			char *summary_title[summarycount] = {"sqlite_memory_used (byte / sum)",
												 "sqlite_pagecache_used (page)",
												 "sqlite_pagecache_overflow (byte)",
												 "sqlite_pagecache_size (byte / max)",
												 "sqlite_malloc_count (times)",
												 "sqlite_malloc_size (byte / max)"};
			int summary_element[summarycount] = {SQLITE_STATUS_MEMORY_USED,
												 SQLITE_STATUS_PAGECACHE_USED,
												 SQLITE_STATUS_PAGECACHE_OVERFLOW,
												 SQLITE_STATUS_PAGECACHE_SIZE,
												 SQLITE_STATUS_MALLOC_COUNT,
												 SQLITE_STATUS_MALLOC_SIZE};


			for (int i = 0; i < summarycount; i++) {
				memset(content, '\0', sizeof(content));
				((int (*)(int, int *, int *, int)) func_sqlite3_status)(summary_element[i], &currentvalue, &maxvalue, 0);
				sprintf(content, "%s,%d,%d\n",
						summary_title[i],
						currentvalue,
						maxvalue);
				write(fd, content, strlen(content));
			}
		}
		fsqlsummarylock.l_type = F_UNLCK;
		if (fcntl(fd, F_SETLK, &fsqlsummarylock)){
			LOGE("unlock failed");
		}
	}
	close(fd);
	mapDbHitMiss.clear();
	LOGD("write SQLHitMissInfo cost:%ld", getTime() - initTime);
}

int createDumpFileDir(){

	static bool have_check_dump_dir = false;
	if(!have_check_dump_dir){
		LOGD("check createDumpFileDir...");
		memset(magnifierDumpDir,'\0',sizeof(magnifierDumpDir));
		strcat(magnifierDumpDir, sdcardPath);
		strcat(magnifierDumpDir, "/dumpfile");
		if(access(magnifierDumpDir,F_OK)){
			if(mkdir(magnifierDumpDir, 0777)){
				if(errno == EEXIST){
					LOGD("dir is already exist.");
				}else{
					LOGE("mkdir %s error.%s", magnifierDumpDir,(char*)strerror(errno));
					return -1;
				}
			}
		}
		have_check_dump_dir = true;
		LOGD("check createDumpFileDir end...");
	}
	return 0;
}

int checkAndCreatSQLiteDir(){

	if(createDumpFileDir()){
		LOGE("create dumpfiledir error");
		return -1;
	}
	char tmp_ProcessName[MAX_PROCESS_LEN];
	strcpy(tmp_ProcessName, processName);
	strcpy(dirForSQLiteUpload, magnifierDumpDir);
	strcat(dirForSQLiteUpload, "/2016=");
	char* pre_processName = strtok(tmp_ProcessName, "&");
	if(pre_processName != NULL)
	{
		char* pakcageName = strtok(pre_processName, ":");
		if(pakcageName != NULL)
		{
			strcat(dirForSQLiteUpload, pakcageName);
		}
	}
//	LOGD("checkAndCreatFileDir/magnifierDumpDir:%s", magnifierDumpDir);
	strcat(dirForSQLiteUpload, "@28@SQLiteAnalysis");
	if(access(dirForSQLiteUpload,F_OK)){
		if(mkdir(dirForSQLiteUpload, 0777)){
			if(errno == EEXIST){
				LOGD("dir is already exist.");
			}else{
				LOGE("mkdir %s error.%s", dirForSQLiteUpload,(char*)strerror(errno));
				return -1;
			}
		}
	}
//	LOGD("check sdcard success:%s", dirForSQLiteUpload);
	return 0;
}

int checkAndCreatFileDir(){
	if(createDumpFileDir()){
		LOGE("create dumpfiledir failed");
		return -1;
	}
//	LOGD("checkAndCreatFileDir/magnifierDumpDir:%s", magnifierDumpDir);
	strcpy(dirForFileUpload, magnifierDumpDir);
	char tmp_ProcessName[MAX_PROCESS_LEN];
	strcpy(tmp_ProcessName, processName);
	strcat(dirForFileUpload, "/2016=");
	char* pre_processName = strtok(tmp_ProcessName, "&");
	if(pre_processName!=NULL)
	{
		char* pakcageName = strtok(pre_processName, ":");
		if(pakcageName != NULL)
		{
			strcat(dirForFileUpload, pakcageName);
		}
	}
	strcat(dirForFileUpload, "@10@XPlatformNativeIO");
	if(access(dirForFileUpload,F_OK)){
		if(mkdir(dirForFileUpload, 0777)){
			if(errno == EEXIST){
				LOGD("dir is already exist.");
			}else{
				LOGE("mkdir %s error.%s", dirForFileUpload, (char*)strerror(errno));
				return -1;
			}
		}
	}
	return 0;
}

int renameDirForUpload(char* path){
	if(createDumpFileDir()){
		LOGE("create dumpfiledir failed");
		return -1;
	}

	strcpy(path, magnifierDumpDir);
	char * format = "%Y-%m-%d_%H.%M.%S.000";
	time_t clock;
	struct tm *tm;
	time(&clock);
	tm = localtime(&clock);
	char timestamp[30];
	strftime(timestamp, sizeof(timestamp), format, tm);
	//LOGD("path_uploaddirpath:%s",path);
	strcat(path, "/");
	strcat(path, timestamp);

	char tmp_ProcessName[MAX_PROCESS_LEN];
	strcpy(tmp_ProcessName, processName);
	strcat(path, "=");
	char* pre_processName = strtok(tmp_ProcessName, "&");
	if(pre_processName!=NULL)
	{
		char* pakcageName = strtok(pre_processName, ":");
		if(pakcageName !=NULL)
		{
			strcat(path, pakcageName);
		}
	}

	strcat(path, "@10@XPlatformNativeIO[");
	if(HAVE_APP_VERSION){
		strcat(path, APP_VERSION);
		strcat(path, "]");
	}else{
		strcat(path, "None");
		strcat(path, "]");
	}
	strcat(path, ".finish");
	return 0;
}