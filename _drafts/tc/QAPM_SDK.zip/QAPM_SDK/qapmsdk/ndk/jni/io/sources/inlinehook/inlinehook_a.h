#ifndef _INLINEHOOK_A_H
#define _INLINEHOOK_A_H

#include <stdio.h>

#ifndef PAGE_SIZE
#define PAGE_SIZE 4096
#endif

#define PAGE_START(addr)	(~(PAGE_SIZE - 1) & (addr))
#define SET_BIT0(addr)		(addr | 1)
#define CLEAR_BIT0(addr)	(addr & 0xFFFFFFFE)
#define TEST_BIT0(addr)		(addr & 1)

#define ACTION_ENABLE	0
#define ACTION_DISABLE	1
	
enum hook_status {
	REGISTERED,
	HOOKED,
};

struct inlineHookItem {
	uint32_t target_addr;
	uint32_t new_addr;
	uint32_t **proto_addr;
	void *orig_instructions;
	int orig_boundaries[4];
	int trampoline_boundaries[20];
	int count;
	void *trampoline_instructions;
	int length;
	int status;
	int mode;
	void *trampoline_oat_header;  //art hook用
	void *target_art_method_info; //art hook用
	uint32_t page_count;          //art hook用
	uint32_t art_method_size;     //art hook用
};

struct inlineHookInfo {
	struct inlineHookItem item[1024];
	int size;
};


#endif
