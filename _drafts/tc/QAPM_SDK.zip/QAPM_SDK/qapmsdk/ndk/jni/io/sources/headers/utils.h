﻿#ifndef __UTILS_H__
#define __UTILS_H__
#include <unistd.h>

#define __PAGESIZE sysconf(_SC_PAGE_SIZE)
// 将num按照mask位对齐
#define ALIGN(num, mask) (((num)+(mask)-1)&~((mask)-1))


struct maps_info
{
	uint32_t block_begin;
	uint32_t block_end;
	uint32_t base_addr;
	maps_info* next;

};


#endif // end __INNER_DEFS_H__
