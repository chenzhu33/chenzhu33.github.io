//
// Created by toringzhang(张前) on 2019/4/6.
//

#ifndef QAPM_SDK_BRACKTRACE_H
#define QAPM_SDK_BRACKTRACE_H

#include <stdint.h>
#include <setjmp.h>
#include <asm/signal.h>
#include <asm/siginfo.h>
#include <ucontext.h>
#include <corkscrew/backtrace.h>
#include <corkscrew/map_info.h>

#ifdef __cplusplus
extern "C" {
#endif

#define BACKTRACE_FRAMES_MAX 32
#define MAX_SIGNAL_HANDLER_SETUP_TIMES 2
#define NATIVE_CODE_GLOBAL_INITIALIZER { 0, 0, PTHREAD_MUTEX_INITIALIZER, NULL, NULL}

#ifdef __ANDROID__
#define USE_UNWIND
//#define USE_CORKSCREW
#endif

#include <pthread.h>

/* #undef NO_USE_SIGALTSTACK */
/* #undef USE_SILENT_SIGALTSTACK */

#if defined(__ANDROID__) && !defined(__BIONIC_HAVE_UCONTEXT_T) && \
    defined(__arm__) && !defined(__BIONIC_HAVE_STRUCT_SIGCONTEXT)
#include <asm/sigcontext.h>
#endif

#if (defined(USE_UNWIND) && !defined(USE_CORKSCREW))
#include <unwind.h>
#endif

#ifdef USE_UNWIND
/* Number of backtraces to get. */
#define BACKTRACE_FRAMES_MAX 32
#endif

#if defined(__ANDROID__)
#ifndef ucontext_h_seen
#define ucontext_h_seen

/* stack_t definition */
#include <asm/signal.h>

#if defined(__arm__)

/* Taken from richard.quirk's header file. (Android does not have it) */

#if !defined(__BIONIC_HAVE_UCONTEXT_T)
typedef struct ucontext {
  unsigned long uc_flags;
  struct ucontext *uc_link;
  stack_t uc_stack;
  struct sigcontext uc_mcontext;
  unsigned long uc_sigmask;
} ucontext_t;
#endif

#elif defined(__aarch64__)

#elif defined(__i386__)

/* Taken from Google Breakpad. */

/* 80-bit floating-point register */
struct _libc_fpreg {
  unsigned short significand[4];
  unsigned short exponent;
};

/* Simple floating-point state, see FNSTENV instruction */
struct _libc_fpstate {
  unsigned long cw;
  unsigned long sw;
  unsigned long tag;
  unsigned long ipoff;
  unsigned long cssel;
  unsigned long dataoff;
  unsigned long datasel;
  struct _libc_fpreg _st[8];
  unsigned long status;
};

typedef uint32_t  greg_t;

typedef struct {
  uint32_t gregs[19];
  struct _libc_fpstate* fpregs;
  uint32_t oldmask;
  uint32_t cr2;
} mcontext_t;

enum {
  REG_GS = 0,
  REG_FS,
  REG_ES,
  REG_DS,
  REG_EDI,
  REG_ESI,
  REG_EBP,
  REG_ESP,
  REG_EBX,
  REG_EDX,
  REG_ECX,
  REG_EAX,
  REG_TRAPNO,
  REG_ERR,
  REG_EIP,
  REG_CS,
  REG_EFL,
  REG_UESP,
  REG_SS,
};

#if !defined(__BIONIC_HAVE_UCONTEXT_T)
typedef struct ucontext {
  uint32_t uc_flags;
  struct ucontext* uc_link;
  stack_t uc_stack;
  mcontext_t uc_mcontext;
} ucontext_t;
#endif

#elif defined(__mips__)

/* Taken from Google Breakpad. */

typedef struct {
  uint32_t regmask;
  uint32_t status;
  uint64_t pc;
  uint64_t gregs[32];
  uint64_t fpregs[32];
  uint32_t acx;
  uint32_t fpc_csr;
  uint32_t fpc_eir;
  uint32_t used_math;
  uint32_t dsp;
  uint64_t mdhi;
  uint64_t mdlo;
  uint32_t hi1;
  uint32_t lo1;
  uint32_t hi2;
  uint32_t lo2;
  uint32_t hi3;
  uint32_t lo3;
} mcontext_t;

#if !defined(__BIONIC_HAVE_UCONTEXT_T)
typedef struct ucontext {
  uint32_t uc_flags;
  struct ucontext* uc_link;
  stack_t uc_stack;
  mcontext_t uc_mcontext;
} ucontext_t;
#endif

#else
#error "Architecture is not supported (unknown ucontext layout)"
#endif

#endif

#ifdef USE_CORKSCREW
typedef struct map_info_t map_info_t;
/* Extracted from Android's include/corkscrew/backtrace.h */
typedef struct {
    uintptr_t absolute_pc;
    uintptr_t stack_top;
    size_t stack_size;
} backtrace_frame_t;
typedef struct {
    uintptr_t relative_pc;
    uintptr_t relative_symbol_addr;
    char* map_name;
    char* symbol_name;
    char* demangled_name;
} backtrace_symbol_t;
/* Extracted from Android's libcorkscrew/arch-arm/backtrace-arm.c */
typedef ssize_t (*t_unwind_backtrace_signal_arch)
(siginfo_t* si, void* sc, const map_info_t* lst, backtrace_frame_t* bt,
size_t ignore_depth, size_t max_depth);
typedef map_info_t* (*t_acquire_my_map_info_list)();
typedef void (*t_release_my_map_info_list)(map_info_t* milist);
typedef void (*t_get_backtrace_symbols)(const backtrace_frame_t* backtrace,
                                        size_t frames,
                                        backtrace_symbol_t* symbols);
typedef void (*t_free_backtrace_symbols)(backtrace_symbol_t* symbols,
                                         size_t frames);
#endif

#endif

/* Process-wide crash handler structure. */
typedef struct native_code_global_struct {
    int maxInitialized;

    /* Initialized. */
    int initialized;

    /* Lock. */
    pthread_mutex_t mutex;

    /* Backup of sigaction. */
    struct sigaction** sa_old;

    int* id;
} native_code_global_struct;

/* Thread-specific crash handler structure. */
typedef struct native_code_handler_struct {
    /* Restore point context. */
    sigjmp_buf ctx;
    int ctx_is_set;
    int reenter;

    /* Alternate stack. */
    char *stack_buffer;
    size_t stack_buffer_size;
    stack_t stack_old;

    /* Signal code and info. */
    int code;
    siginfo_t si;
    ucontext_t uc;

    /* Uwind context. */
#if (defined(USE_CORKSCREW))
    backtrace_frame_t frames[BACKTRACE_FRAMES_MAX];
#elif (defined(USE_UNWIND))
    uintptr_t frames[BACKTRACE_FRAMES_MAX];
#endif

#ifdef USE_LIBUNWIND
    void* uframes[BACKTRACE_FRAMES_MAX];
#endif
    size_t frames_size;
    size_t frames_skip;

    /* Custom assertion failures. */
    const char *expression;
    const char *file;
    int line;

    /* Alarm was fired. */
    int alarm;
} native_code_handler_struct;

extern ssize_t unwind_signal(void* sc, void** frames, size_t max_depth);

#ifdef USE_CORKSCREW
size_t backtrace_signal(siginfo_t* si, void* sc,
                                           backtrace_frame_t* frames,
                                           size_t ignore_depth,
                                           size_t max_depth);
int backtrace_symbols(const backtrace_frame_t* backtrace,
                                        size_t frames,
                                        void (*fun)(void *arg,
                                        const backtrace_symbol_t *sym),
                                        void *arg);
#endif
#ifdef __cplusplus
}
#endif
#endif //QAPM_SDK_BRACKTRACE_H
