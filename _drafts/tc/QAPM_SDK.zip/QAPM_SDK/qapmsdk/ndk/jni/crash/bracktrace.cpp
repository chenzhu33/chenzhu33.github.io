//
// Created by toringzhang(张前) on 2019/4/6.
//

#include <dlfcn.h>
#include <hutils.h>
#if defined(__ANDROID__) && !defined(__BIONIC_HAVE_UCONTEXT_T) && \
    defined(__arm__) && !defined(__BIONIC_HAVE_STRUCT_SIGCONTEXT)
#include <asm/sigcontext.h>
#endif

#include "bracktrace.h"
#include "common/log.h"
#include "include/libunwind.h"
#include "include/compiler.h"
#include "utils.h"


#define tdep_trace(cur,addr,n)		(-UNW_ENOINFO)

#ifdef USE_CORKSCREW
ssize_t backtrace_signal(siginfo_t* si, void* sc,
                        backtrace_frame_t* frames,
                        size_t ignore_depth,
                        size_t max_depth) {
    void *const libcorkscrew = dlopen("libcorkscrew.so", RTLD_LAZY | RTLD_LOCAL);
    if (libcorkscrew != NULL) {
        t_unwind_backtrace_signal_arch unwind_backtrace_signal_arch = (t_unwind_backtrace_signal_arch) dlsym(libcorkscrew, "unwind_backtrace_signal_arch");
        t_acquire_my_map_info_list acquire_my_map_info_list = (t_acquire_my_map_info_list) dlsym(libcorkscrew, "acquire_my_map_info_list");
        t_release_my_map_info_list release_my_map_info_list = (t_release_my_map_info_list) dlsym(libcorkscrew, "release_my_map_info_list");

        if (unwind_backtrace_signal_arch != NULL && acquire_my_map_info_list != NULL && release_my_map_info_list != NULL) {
            map_info_t*const info = acquire_my_map_info_list();
            const ssize_t size = unwind_backtrace_signal_arch(si, sc, info, frames, ignore_depth, max_depth);
            release_my_map_info_list(info);
            //crash 保护？？

            return size >= 0 ? size : 0;
        } else {
            LOGE("symbols not found in libcorkscrew.so.");
        }
        dlclose(libcorkscrew);
    } else {
        LOGE("libcorkscrew.so could not be loaded.");
    }
    return 0;
}

int backtrace_symbols(const backtrace_frame_t* backtrace,
                      ssize_t frames,
                      void (*fun)(void *arg,
                                  const backtrace_symbol_t *sym),
                      void *arg) {
    int success = 0;
    void *const libcorkscrew = dlopen("libcorkscrew.so", RTLD_LAZY | RTLD_LOCAL);
    if (libcorkscrew != NULL) {
        t_get_backtrace_symbols get_backtrace_symbols = (t_get_backtrace_symbols) dlsym(libcorkscrew, "get_backtrace_symbols");
        t_free_backtrace_symbols free_backtrace_symbols = (t_free_backtrace_symbols) dlsym(libcorkscrew, "free_backtrace_symbols");

        if (get_backtrace_symbols != NULL
            && free_backtrace_symbols != NULL) {
            backtrace_symbol_t symbols[BACKTRACE_FRAMES_MAX];
            size_t i;
            if (frames > BACKTRACE_FRAMES_MAX) {
                frames = BACKTRACE_FRAMES_MAX;
            }
            get_backtrace_symbols(backtrace, frames, symbols);
            for(i = 0; i < frames; i++) {
                fun(arg, &symbols[i]);
            }
            free_backtrace_symbols(symbols, frames);
            success = 1;
        } else {
            LOGE("symbols not found in libcorkscrew.so.");
        }
        dlclose(libcorkscrew);
    } else {
        LOGE("libcorkscrew.so could not be loaded.");
    }
    return success;
}
#endif

#ifdef USE_LIBUNWIND
void coffee_getcontext(unw_context_t* puc, void* reserved) {
    //platform specific voodoo to build a context for libunwind
#if defined(__arm__)
    //cast/extract the necessary structures
    ucontext_t* context = (ucontext_t*)reserved;
    unw_tdep_context_t *unw_ctx = (unw_tdep_context_t*)puc;
    struct sigcontext* sig_ctx = &context->uc_mcontext;
    // we need to store all the general purpose registers so that libunwind can resolve
    // the stack correctly, so we read them from the sigcontext into the unw_context
    unw_ctx->regs[UNW_ARM_R0] = sig_ctx->arm_r0;
    unw_ctx->regs[UNW_ARM_R1] = sig_ctx->arm_r1;
    unw_ctx->regs[UNW_ARM_R2] = sig_ctx->arm_r2;
    unw_ctx->regs[UNW_ARM_R3] = sig_ctx->arm_r3;
    unw_ctx->regs[UNW_ARM_R4] = sig_ctx->arm_r4;
    unw_ctx->regs[UNW_ARM_R5] = sig_ctx->arm_r5;
    unw_ctx->regs[UNW_ARM_R6] = sig_ctx->arm_r6;
    unw_ctx->regs[UNW_ARM_R7] = sig_ctx->arm_r7;
    unw_ctx->regs[UNW_ARM_R8] = sig_ctx->arm_r8;
    unw_ctx->regs[UNW_ARM_R9] = sig_ctx->arm_r9;
    unw_ctx->regs[UNW_ARM_R10] = sig_ctx->arm_r10;
    unw_ctx->regs[UNW_ARM_R11] = sig_ctx->arm_fp;
    unw_ctx->regs[UNW_ARM_R12] = sig_ctx->arm_ip;
    unw_ctx->regs[UNW_ARM_R13] = sig_ctx->arm_sp;
    unw_ctx->regs[UNW_ARM_R14] = sig_ctx->arm_lr;
    unw_ctx->regs[UNW_ARM_R15] = sig_ctx->arm_pc;
    LOGD("base pc: %p", (void *)sig_ctx->arm_pc);
#elif defined(__i386__)
    ucontext_t* context = (ucontext_t*)reserved;
    //on x86 libunwind just uses the ucontext_t directly
    uc = *((unw_context_t*)context);
#else
    //We don't have platform specific voodoo for whatever we were built for
    //    just call libunwind and hope it can jump out of the signal stack on it's own
    unw_getcontext(&uc);
#endif
}

static ALWAYS_INLINE int
slow_backtrace (void **buffer, int size, unw_context_t *uc)
{
    unw_cursor_t cursor;
    unw_word_t ip;
    unw_word_t sp;
    int n = 0;

    if (unlikely (unw_init_local (&cursor, uc) < 0)) {
        LOGD("unw_init_local error");
        return 0;
    }

    int stepRet = 0;
    int getRegRet = 0;
    uintptr_t preIp = 0;
    LOGD("before unw_step");

    do {
        if (n >= size)
            return n;

        LOGD("after unw_step, stepRet:%d", stepRet);
        if ((getRegRet = unw_get_reg (&cursor, UNW_REG_IP, &ip)) < 0) {
            LOGE("Fail to read IP %d", getRegRet);
            return n;
        }

        if ((getRegRet = unw_get_reg (&cursor, UNW_REG_SP, &sp)) < 0) {
            LOGE("Fail to read SP %d", getRegRet);
            return n;
        }

        buffer[n++] = (void *) (uintptr_t) ip;
        char* name = PC2DLName((void *) ip);
        LOGI("slow_backtrace, ip: 0x%x sp: 0x%x name: %s getRegRet:%d", (uintptr_t) ip, (uintptr_t) sp, name, getRegRet);

        //栈从高向低生长，所以上一层栈帧的pc必须位于更高地址
        if (preIp >= ip) {
            break;
        }
        //Fixme: unw_step有偶现的crash, 两次pc相差太大就停止解堆栈
        if (preIp != 0 && ip - preIp > 0xD00000) {
            LOGI("Stop cause gap is too large, ip: 0x%x preIp: 0x%x", ip, preIp);
            break;
        }

        preIp = ip;
    } while ((stepRet = unw_step (&cursor)) > 0);

    LOGD("slow_backtrace frames: %d", n);

    return n;
}

int getStackTrace(void **buffer, int size, void* sc){
    unw_cursor_t cursor;
    unw_context_t uc;
    int n = size;
//
//    (void) coffee_getcontext (&uc, sc);
//
//    if (unlikely (unw_init_local (&cursor, &uc) < 0))
//        return 0;
//
//    if (unlikely (tdep_trace (&cursor, buffer, &n) < 0))
//    {
//        (void) coffee_getcontext (&uc, sc);
//        return slow_backtrace (buffer, size, &uc);
//    }

    return n;

}

/* Use libunwind to get a backtrace inside a signal handler.
   Will only return a non-zero code on Android >= 5 (with libunwind.so
   being shipped) */

ssize_t unwind_signal(void* sc, void** frames, size_t max_depth) {

    return getStackTrace(frames, max_depth, sc);
}
#endif