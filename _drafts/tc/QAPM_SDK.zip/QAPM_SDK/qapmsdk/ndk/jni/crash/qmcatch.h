//
// Created by toringzhang(张前) on 2019/4/6.
//

#ifndef QAPM_SDK_QMCATCH_H
#define QAPM_SDK_QMCATCH_H
#include <stdint.h>
#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif


#define SIG_STACK_BUFFER_SIZE SIGSTKSZ
/* Maximum value of a caught signal. */
#define SIG_NUMBER_MAX 32

/* Signals to be caught. */
#define SIG_CATCH_COUNT 8
static const int native_sig_catch[SIG_CATCH_COUNT + 1]
        = { SIGABRT, SIGILL, SIGTRAP, SIGBUS, SIGFPE, SIGSEGV, SIGPIPE
#ifdef SIGSTKFLT
                , SIGSTKFLT
#endif
                , 0 };

typedef struct t_bt_fun {
    JNIEnv* env;
    jclass cls;
    jclass cls_ste;
    jmethodID cons_ste;
    jobjectArray elements;
    ssize_t size;
    size_t index;
} t_bt_fun;

#ifdef USE_CORKSCREW
typedef struct t_backtrace_symbols_fun {
    void (*fun)(void *arg, const char *module, uintptr_t addr,
                const char *function, uintptr_t offset);
    void *arg;
} t_backtrace_symbols_fun;
#endif

/**
 * Enumerate the backtrace with information.
 * This function can only be called inside a COFFEE_CATCH() block.
 */
extern void get_backtrace_info(void (*fun)(void *arg,
                                           const char *module,
                                           uintptr_t addr,
                                           const char *function,
                                           uintptr_t offset), void *arg);
extern int setupSignalHandler(int id);
/**
 * Get the full error message associated with the crash.
 * This function can only be called inside a COFFEE_CATCH() block, and the
 * returned pointer is only valid within this block. (you may want to copy
 * the string in a static buffer, or use strdup())
 */
extern const char* getMessage(void);

extern ssize_t getBacktraceSize(void);

extern void cleanup();

#ifdef __cplusplus
}
#endif
#endif //QAPM_SDK_QMCATCH_H
