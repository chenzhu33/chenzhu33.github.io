//
// Created by toringzhang(张前) on 2019/4/6.
//

#ifndef QAPM_SDK_QMJNI_H
#define QAPM_SDK_QMJNI_H

#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif
struct dump_thread_entry_args{
    jobject callback;
    jclass nativeCrashCatcher;
};

extern void initCondition();
extern void* DumpThreadEntry(void *argv);
extern void notifyCaughtSignal();
extern void waitForThrowException();
#ifdef __cplusplus
}
#endif
#endif //QAPM_SDK_QMJNI_H
