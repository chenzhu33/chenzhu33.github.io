//
// Created by toringzhang(张前) on 2019/4/6.
//
#include <jni.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>

#include "qmjni.h"
#include "common/log.h"
#include "qmcatch.h"
#include "bracktrace.h"

extern JavaVM* g_jvm;
extern char* g_crashThreadName;
extern native_code_global_struct g_native_code;

int estatus = 1;
bool isSignalCaught = false;
bool isThrow = false;
pthread_cond_t signalCond; //条件变量
pthread_mutex_t signalLock;   //互斥锁
pthread_mutex_t exceptionLock; //互斥锁
pthread_cond_t exceptionCond; //条件变量


static void waitForSignal()
{
    pthread_mutex_lock(&signalLock);
    LOGV("waitForSignal start.");
    while(!isSignalCaught) {
        pthread_cond_wait(&signalCond, &signalLock);
    }
    isSignalCaught = false;
    LOGV("waitForSignal finish.");
    pthread_mutex_unlock(&signalLock);
}

jthrowable dumpJavaStack(const char* threadName, const char* javaStackMessage, JNIEnv* env, jclass nativeCrashCatcherClass, jclass errorClass, jclass stackTraceElementClass, jmethodID errorClass_init, jmethodID errorClass_setStackTrace) {
    LOGI("dumpJavaStack start. threadName: %s, javaStackMessage: %s", threadName, javaStackMessage);
    try {
        jmethodID stackTraceElementClass_toString = env->GetMethodID(stackTraceElementClass, "toString", "()Ljava/lang/String;");

        jmethodID getThreadNameID = env->GetStaticMethodID(nativeCrashCatcherClass, "getThreadByName", "(Ljava/lang/String;)Ljava/lang/Thread;");
        if(getThreadNameID==NULL){
            LOGE("getThreadNameID error.");
            return NULL;
        }

        jstring crashThreadNameStr = env->NewStringUTF(threadName);

        jobject thread = env->CallStaticObjectMethod(nativeCrashCatcherClass, getThreadNameID, crashThreadNameStr);

        if (thread == NULL) {
            LOGE("getThreadByName error.");
            return NULL;
        }

        jclass threadClass = env->GetObjectClass(thread);
        jmethodID getStackTraceMethodID = env->GetMethodID(threadClass, "getStackTrace", "()[Ljava/lang/StackTraceElement;");
        jobjectArray javaElements = (jobjectArray)env->CallObjectMethod(thread, getStackTraceMethodID);

        jstring str = env->NewStringUTF(javaStackMessage);
        LOGD("javaStackMessage: %s.", javaStackMessage);
        jthrowable cause = (jthrowable) env->NewObject(errorClass, errorClass_init, str);
        env->CallVoidMethod(cause, errorClass_setStackTrace, javaElements);

        int javaElementsLen = env->GetArrayLength(javaElements);
        const int MAX_ELEMENT_LEN = 20;
        for (int i = 0;i < javaElementsLen && i < MAX_ELEMENT_LEN;i++) {
            jobject element = env->GetObjectArrayElement( javaElements, i);
            jstring stack = (jstring)env->CallObjectMethod(element, stackTraceElementClass_toString);
            const char *strReturn = env->GetStringUTFChars( stack, 0);
            LOGD("strReturn: %s", strReturn);

            env->ReleaseStringUTFChars(stack, strReturn);
            env->DeleteLocalRef(stack);
            env->DeleteLocalRef(element);
        }

        LOGI("dumpJavaStack end.");
        return cause;
    }catch (...){
    }
    return NULL;
}

static char* bt_addr(uintptr_t addr) {
    char buffer[32];
    snprintf(buffer, sizeof(buffer), "%08p", (void*) addr);
    return strdup(buffer);
}

static const char* bt_print(const char *function, uintptr_t offset) {
    if (function != NULL) {
        char buffer[256];
        snprintf(buffer, sizeof(buffer), "%s:%p", function, (void*) offset);
        return strdup(buffer);
    } else {
        return "<unknown>";
    }
}

static void bt_fun(void *arg, const char *module, uintptr_t addr,
                   const char *function, uintptr_t offset) {
    t_bt_fun *const t = (t_bt_fun*) arg;
    JNIEnv*const env = t->env;

    if (module == NULL) {
        module = "<unknown>";
    }

    jstring declaringClass = env->NewStringUTF(module);
    jstring methodName = env->NewStringUTF(bt_addr(addr));
    jstring fileName = env->NewStringUTF(bt_print(function, offset));
    const int lineNumber = function != NULL ? 0 : -2;  /* "-2" is "inside JNI code" */
    jobject trace = env->NewObject(t->cls_ste, t->cons_ste,
                                      declaringClass, methodName, fileName,
                                      lineNumber);
    if (t->index < t->size) {
        env->SetObjectArrayElement(t->elements, t->index++, trace);
    }
    LOGD("#%02d pc 0x%08x %s (%s+0x%x)", t->index, addr, module, function, offset);
}

void throwException(JNIEnv* env, jclass nativeCrashCatcher, jobject callback) {
    LOGD("throwException");
    jclass errorClass = env->FindClass("java/lang/Error");
    jclass stackTraceElementClass = env->FindClass("java/lang/StackTraceElement");

    jmethodID errorClass_init = env->GetMethodID(errorClass, "<init>", "(Ljava/lang/String;)V");
    jmethodID errorClass_init2 = env->GetMethodID(errorClass, "<init>", "(Ljava/lang/String;Ljava/lang/Throwable;)V");
    jmethodID stackTraceElementClass_init = env->GetMethodID(stackTraceElementClass, "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V");

    jmethodID errorClass_setStackTrace = env->GetMethodID(errorClass, "setStackTrace", "([Ljava/lang/StackTraceElement;)V");

    /* Exception message. */
    const char* const message = getMessage();
    jstring str = env->NewStringUTF(strdup(message));
    LOGI("Exception message: %s", message);

    /* Final exception. */
    jthrowable exception;

    LOGD("check get class and method is NULL errorClass: %i, stackTraceElementClass: %i, errorClass_init: %i, errorClass_init2: %i, stackTraceElementClass_init: %i, errorClass_setStackTrace: %i, message: %i, str: %i", errorClass != NULL, stackTraceElementClass != NULL, errorClass_init != NULL, errorClass_init2 != NULL,
         stackTraceElementClass_init != NULL, errorClass_setStackTrace != NULL, message != NULL, str != NULL);
    if (errorClass == NULL || stackTraceElementClass == NULL || errorClass_init == NULL || errorClass_init2 == NULL || stackTraceElementClass_init == NULL || errorClass_setStackTrace == NULL) {
        LOGE("check get class and method is NULL errorClass: %i, stackTraceElementClass: %i, errorClass_init: %i, errorClass_init2: %i, stackTraceElementClass_init: %i, errorClass_setStackTrace: %i, message: %i, str: %i", errorClass != NULL, stackTraceElementClass != NULL, errorClass_init != NULL, errorClass_init2 != NULL,
             stackTraceElementClass_init != NULL, errorClass_setStackTrace != NULL, message != NULL, str != NULL);
        return;
    }

    if(str == NULL) {
        const char *empty = "";
        str = env->NewStringUTF(empty);
    }

    /* Add pseudo-stack trace. */
    const ssize_t backtraceSize = getBacktraceSize();
    LOGD("backtraceSize: %i.", backtraceSize);
    /* Can we produce a stack trace ? */
    if (backtraceSize > 0) {
        jthrowable javaThrowable = dumpJavaStack(g_crashThreadName, "java_stack.", env, nativeCrashCatcher, errorClass, stackTraceElementClass, errorClass_init, errorClass_setStackTrace);
        if (javaThrowable == NULL) {
            LOGW("dump thread- %s failure, now dump main thread.", g_crashThreadName);
            javaThrowable = dumpJavaStack("main", "this stack may not be right.", env, nativeCrashCatcher, errorClass, stackTraceElementClass, errorClass_init, errorClass_setStackTrace);
        }


        /* Create secondary exception. */
        jthrowable cause;
        if (javaThrowable != NULL) {
            cause = (jthrowable) env->NewObject(errorClass, errorClass_init2, str, javaThrowable);
        } else {
            LOGW("dump java stack error.");
            cause = (jthrowable) env->NewObject(errorClass, errorClass_init, str);
        }

        jobjectArray elements = env->NewObjectArray(backtraceSize, stackTraceElementClass, NULL);
        /* Stack trace. */
        if (elements != NULL) {
            LOGI("native stack: ");

            t_bt_fun t;
            t.env = env;
            t.cls = errorClass;
            t.cls_ste = stackTraceElementClass;
            t.cons_ste = stackTraceElementClass_init;
            t.elements = elements;
            t.index = 0;
            t.size = backtraceSize;
            get_backtrace_info(bt_fun, &t);

            env->CallVoidMethod(cause, errorClass_setStackTrace, elements);
        }

        /* Primary exception */
        exception = (jthrowable) env->NewObject(errorClass, errorClass_init2, str, cause);
    } else {
        LOGW("getBacktraceSize failure, now create a simple exception.");
        /* Simple exception */
        exception = (jthrowable) env->NewObject(errorClass, errorClass_init, str);
    }

    if (callback != NULL) {
        jclass callbackClass = env->GetObjectClass(callback);
        jmethodID onCrash = env->GetMethodID(callbackClass , "onCrash" , "(ILjava/lang/String;Ljava/lang/Error;)V");
        int curInitCount = g_native_code.initialized - 1;
        jstring crashThreadNameStr = env->NewStringUTF(g_crashThreadName);
        env->CallVoidMethod(callback, onCrash, g_native_code.id[curInitCount], crashThreadNameStr, exception);
    }
}

static void notifyThrowException() {
    pthread_mutex_lock(&exceptionLock);
    isThrow = true;
    pthread_cond_signal(&exceptionCond);
    LOGV("notifyThrowException");
    pthread_mutex_unlock(&exceptionLock);
}

void initCondition() {
    pthread_mutex_init(&signalLock, NULL);
    pthread_cond_init(&signalCond, NULL);
    pthread_mutex_init(&exceptionLock, NULL);
    pthread_cond_init(&exceptionCond, NULL);
}

void waitForThrowException() {
    pthread_mutex_lock(&exceptionLock);
    LOGV("waitForThrowException start");
    while(!isThrow) {
        pthread_cond_wait(&exceptionCond, &exceptionLock);
    }
    isThrow = false;
    LOGV("waitForThrowException finish");
    pthread_mutex_unlock(&exceptionLock);
}

void notifyCaughtSignal() {
    pthread_mutex_lock(&signalLock);
    if(!isSignalCaught) {
        isSignalCaught = true;
        LOGV("notifyCaughtSignal");
        pthread_cond_signal(&signalCond);
    }
    pthread_mutex_unlock(&signalLock);
}

void* DumpThreadEntry(void *argv) {

    JNIEnv* env = NULL;
    dump_thread_entry_args* args  = (dump_thread_entry_args*)argv;
    jobject callback = args->callback;
    jclass nativeCrashCatcher = args->nativeCrashCatcher;
    if(g_jvm->AttachCurrentThread(&env, NULL) != JNI_OK)
    {
        LOGE("AttachCurrentThread() failed.");
        estatus = 0;
        return &estatus;
    }

    while (true) {
        waitForSignal();

        throwException(env, nativeCrashCatcher, callback);

        notifyThrowException();
    }

    if(g_jvm->DetachCurrentThread() != JNI_OK)
    {
        LOGE("DetachCurrentThread() failed");
        estatus = 0;
        return &estatus;
    }

    return &estatus;
}