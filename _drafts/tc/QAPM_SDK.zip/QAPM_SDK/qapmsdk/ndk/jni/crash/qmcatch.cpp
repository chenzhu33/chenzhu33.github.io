//
// Created by toringzhang(张前) on 2019/4/6.
//

#include <stdint.h>
#include <errno.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <android/configuration.h>
#include <sys/system_properties.h>
#include <dlfcn.h>
#include <stdio.h>
#include <unwind.h>

#if (defined(USE_UNWIND) && !defined(USE_CORKSCREW))
#include <unwind.h>
#endif

#include "common/log.h"
#include "qmcatch.h"
#include "bracktrace.h"
#include "utils.h"
#include "qmjni.h"

char* g_crashThreadName;
native_code_handler_struct* g_native_code_handler;
native_code_global_struct g_native_code = NATIVE_CODE_GLOBAL_INITIALIZER;
/* Thread variable holding context. */
pthread_key_t native_code_thread;
extern char* g_packageName;
static native_code_handler_struct* getCrashHandler() {
    return g_native_code_handler;
}
#if (defined(USE_UNWIND) && !defined(USE_CORKSCREW))
/* Unwind callback */

static _Unwind_Reason_Code unwind_callback(struct _Unwind_Context* context, void* arg) {
    native_code_handler_struct *const s = (native_code_handler_struct*) arg;

    const uintptr_t ip = _Unwind_GetIP(context);

    LOGD("called unwind callback.");

    if (ip != 0x0) {
        if (s->frames_skip == 0) {
            s->frames[s->frames_size] = ip;
            s->frames_size++;
        } else {
            s->frames_skip--;
        }
    }

    if (s->frames_size == BACKTRACE_FRAMES_MAX) {
        return _URC_END_OF_STACK;
    } else {
        LOGD("returned _URC_OK.");
        return _URC_OK;
    }
}

#endif

/**
 * Get the full error message associated with the crash.
 */
const char* getMessage() {
    const int error = errno;
    const native_code_handler_struct* const t = getCrashHandler();

    /* Found valid handler. */
    if (t != NULL) {
        char * const buffer = t->stack_buffer;
        const size_t buffer_len = t->stack_buffer_size;
        size_t buffer_offs = 0;

        const char* const posix_desc =
                desc_sig(t->si.si_signo, t->si.si_code);

        /* Assertion failure ? */
        if ((t->code == SIGABRT
#ifdef __ANDROID__
             /* See Android BUG #16672:
              * "C assert() failure causes SIGSEGV when it should cause SIGABRT" */
             || (t->code == SIGSEGV && (uintptr_t) t->si.si_addr == 0xdeadbaad)
#endif
            ) && t->expression != NULL) {
            snprintf(&buffer[buffer_offs], buffer_len - buffer_offs,
                     "assertion '%s' failed at %s:%d",
                     t->expression, t->file, t->line);
            buffer_offs += strlen(&buffer[buffer_offs]);
        }
            /* Signal */
        else {
            snprintf(&buffer[buffer_offs], buffer_len - buffer_offs, "signal %d", t->si.si_signo);
            buffer_offs += strlen(&buffer[buffer_offs]);

            /* Description */
            snprintf(&buffer[buffer_offs], buffer_len - buffer_offs, " (%s)", posix_desc);
            buffer_offs += strlen(&buffer[buffer_offs]);

            /* Address of faulting instruction */
            if (t->si.si_signo == SIGILL || t->si.si_signo == SIGSEGV) {
                snprintf(&buffer[buffer_offs], buffer_len - buffer_offs, " at address %p", t->si.si_addr);
                buffer_offs += strlen(&buffer[buffer_offs]);
            }
        }

        /* [POSIX] If non-zero, an errno value associated with this signal,
         as defined in <errno.h>. */
        if (t->si.si_errno != 0) {
            snprintf(&buffer[buffer_offs], buffer_len - buffer_offs, ": ");
            buffer_offs += strlen(&buffer[buffer_offs]);
            if (strerror_r(t->si.si_errno, &buffer[buffer_offs], buffer_len - buffer_offs) == 0) {
                snprintf(&buffer[buffer_offs], buffer_len - buffer_offs, "unknown error");
                buffer_offs += strlen(&buffer[buffer_offs]);
            }
        }

        /* Sending process ID. */
        if (t->si.si_signo == SIGCHLD && t->si.si_pid != 0) {
            snprintf(&buffer[buffer_offs], buffer_len - buffer_offs, " (sent by pid %d)", (int) t->si.si_pid);
            buffer_offs += strlen(&buffer[buffer_offs]);
        }

        /* Return string. */
        buffer[buffer_offs] = '\0';
        return t->stack_buffer;
    } else {
        /* Static buffer in case of emergency */
        static char buffer[256];
        const int code = strerror_r(error, &buffer[0], sizeof(buffer));
        errno = error;
        if (code == 0) {
            return buffer;
        } else {
            return "unknown error during crash handler setup";
        }
    }
}

#if (defined(USE_CORKSCREW))

static void backtrace_symbols_fun(void *arg, const backtrace_symbol_t *sym) {
    t_backtrace_symbols_fun *const bt = (t_backtrace_symbols_fun *) arg;
    const char *symbol = sym->demangled_name != NULL ? sym->demangled_name : sym->symbol_name;
    const uintptr_t rel = sym->relative_pc - sym->relative_symbol_addr;
    bt->fun(bt->arg, sym->map_name, sym->relative_pc, symbol, rel);
}
#endif

/**
 * Get the <index>th element of the backtrace, or 0 upon error.
 */
uintptr_t get_backtrace(ssize_t index) {
#ifdef USE_UNWIND
    const native_code_handler_struct* const t = getCrashHandler();
    if (t != NULL) {
        if (index < 0) {
            index = t->frames_size + index;
        }
        if (index >= 0 && (size_t) index < t->frames_size) {
#ifdef USE_CORKSCREW
            return t->frames[index].absolute_pc;
#else
            return t->frames[index];
#endif
        }
    }
#else
    (void) index;
#endif
    return 0;
}

/**
 * Enumerate backtrace information.
 */
void get_backtrace_info(void (*fun)(void *arg,
                                    const char *module,
                                    uintptr_t addr,
                                    const char *function,
                                    uintptr_t offset), void *arg) {
    const native_code_handler_struct* const t = getCrashHandler();
    if (t != NULL) {
        size_t i;
#ifdef USE_CORKSCREW
        t_backtrace_symbols_fun bt;
        bt.fun = fun;
        bt.arg = arg;
        if (backtrace_symbols(t->frames, t->frames_size,
                                          backtrace_symbols_fun,
                                          &bt)) {
            return;
        }
#endif
        for(i = 0; i < t->frames_size; i++) {
#ifdef USE_CORKSCREW
            const uintptr_t pc = t->frames[i].absolute_pc;
#else
            const uintptr_t pc = t->frames[i];
#endif
            format_pc_address_cb(pc, fun, arg);
        }
    }
}


/**
 * Get the backtrace size. Returns 0 if no backtrace is available.
 */
ssize_t getBacktraceSize() {
#ifdef USE_UNWIND
    const native_code_handler_struct* const t = getCrashHandler();
    if (t != NULL) {
        return t->frames_size;
    } else {
        return 0;
    }
#else
    return 0;
#endif
}

static void start_alarm(void) {
    /* Ensure we do not deadlock. Default of ALRM is to die.
     * (signal() and alarm() are signal-safe) */
    (void) alarm(8);
}

static void mark_alarm(native_code_handler_struct *const t) {
    t->alarm = 1;
}

/* Copy context infos (signal code, etc.) */
static void copy_context(native_code_handler_struct *const t,
                         const int code, siginfo_t *const si,
                         void *const sc) {
    t->code = code;
    t->si = *si;
    if (sc != NULL) {
        ucontext_t *const uc = (ucontext_t*) sc;
        t->uc = *uc;
    } else {
        memset(&t->uc, 0, sizeof(t->uc));
    }

#ifdef USE_UNWIND
    /* Frame buffer initial position. */
    t->frames_size = 0;

    /* Skip us and the caller. */
    t->frames_skip = 0;

    /* Use the corkscrew library to extract the backtrace. */
#ifdef USE_CORKSCREW
    t->frames_size = backtrace_signal(si, sc, t->frames, 0,
                                                BACKTRACE_FRAMES_MAX);
#else
    /* Unwind frames (equivalent to backtrace()) */
    _Unwind_Backtrace(unwind_callback, t);
#endif

#ifdef USE_LIBUNWIND
    if (t->frames_size == 0) {
        size_t i;
        t->frames_size = unwind_signal(sc, t->uframes, BACKTRACE_FRAMES_MAX);
        for(i = 0 ; i < t->frames_size ; i++) {
            t->frames[i].absolute_pc = (uintptr_t) t->uframes[i];
            t->frames[i].stack_top = 0;
            t->frames[i].stack_size = 0;
            LOGD("absolute_pc:%x", t->frames[i].absolute_pc);
        }
    }
#endif

    LOGD("copy_context frames_size: %d", t->frames_size);
#endif
}

static void invalidate_context(native_code_handler_struct* const t) {
    /* Valid context ? */
    if (t != NULL && t->ctx_is_set) {
        /* Invalidate the context */
        t->ctx_is_set = 0;
        t->frames_size = 0;
    }
}

/* Call the old handler. */
static void call_old_signal_handler(const int code, siginfo_t *const si, void * const sc) {
    /* Call the "real" Java handler for JIT and internals. */
    if (code >= 0 && code < SIG_NUMBER_MAX) {
        int curInitCount = --g_native_code.initialized;
        LOGD("call_old_signal_handler, curInitCount:%d initialized:%d maxInitialized:%d", curInitCount, g_native_code.initialized, g_native_code.maxInitialized);
        if (g_native_code.sa_old[curInitCount][code].sa_sigaction != NULL) {
            g_native_code.sa_old[curInitCount][code].sa_sigaction(code, si, sc);
        } else if (g_native_code.sa_old[curInitCount][code].sa_handler != NULL) {
            g_native_code.sa_old[curInitCount][code].sa_handler(code);
        }
    }
}

/* Internal signal pass-through. Allows to peek the "real" crash before
 * calling the Java handler. Remember than Java needs many of the signals
 * (for the JIT, for test-free NullPointerException handling, etc.)
 * We record the siginfo_t context in this function each time it is being
 * called, to be able to know what error caused an issue.
 */
static void signal_pass(int code, siginfo_t* si, void* sc) {
    native_code_handler_struct *t;

    pid_t tid = gettid();
    g_crashThreadName = getThreadName(tid);
    bool isEqual = isEqualToPackageName(g_crashThreadName, g_packageName);
    if (isEqual) {
        free(g_crashThreadName);
        g_crashThreadName = strdup("main");
    }
    LOGD("crash thread info, tid:%d, name:%s", tid, g_crashThreadName);

    /* Ensure we do not deadlock. Default of ALRM is to die.
    * (signal() and alarm() are signal-safe) */
    //todo:考虑用非信号方式防止死锁
    signal(code, SIG_DFL);
    signal(SIGALRM, SIG_DFL);
    start_alarm();

    /* Available context ? */
    t = getCrashHandler();
    if (t != NULL) {
        /* An alarm() call was triggered. */
        mark_alarm(t);

        /* Take note of the signal. */
        copy_context(t, code, si, sc);

        notifyCaughtSignal();

        waitForThrowException();

        invalidate_context(t);
    }

    call_old_signal_handler(code, si, sc);

    LOGD("at the end of signal_pass");
}


/* Internal globals initialization. */
static int handler_setup_global(int id) {
    int curInitCount = g_native_code.initialized;
    size_t i;
    struct sigaction sa_pass;

    if (g_native_code.initialized++ == 0) {
        g_native_code.sa_old = (struct sigaction**)calloc(sizeof(struct sigaction*), MAX_SIGNAL_HANDLER_SETUP_TIMES);
        if (g_native_code.sa_old == NULL) {
            LOGE("sa_old is null.");
            return -1;
        }
        g_native_code.id = (int*)calloc(sizeof(int), MAX_SIGNAL_HANDLER_SETUP_TIMES);
    }
    g_native_code.id[curInitCount] = id;

    if (g_native_code.initialized > g_native_code.maxInitialized) {
        g_native_code.maxInitialized = g_native_code.initialized;
        if(g_native_code.maxInitialized > MAX_SIGNAL_HANDLER_SETUP_TIMES){
            LOGE("handler_setup_global error.g_native_code.maxInitialized: %d", g_native_code.maxInitialized);
            return -1;
        }
    }

    /* Setup handler structure. */
    memset(&sa_pass, 0, sizeof(sa_pass));
    sigemptyset(&sa_pass.sa_mask);
    sa_pass.sa_sigaction = signal_pass;
    sa_pass.sa_flags = SA_SIGINFO | SA_ONSTACK;

    /* Allocate */
    g_native_code.sa_old[curInitCount] = (struct sigaction*)calloc(sizeof(struct sigaction), SIG_NUMBER_MAX);
    if (g_native_code.sa_old[curInitCount] == NULL) {
        LOGE("g_native_code.sa_old init count is null.");
        return -1;
    }

    /* Setup signal handlers for SIGABRT (Java calls abort()) and others. **/
    for (i = 0; native_sig_catch[i] != 0; i++) {
        const int sig = native_sig_catch[i];
        const struct sigaction * const action = &sa_pass;
        if(sig>=SIG_NUMBER_MAX || sig<=0){
            LOGE("sig is invalid.%d", sig);
            return -1;
        }
        int ret;
        if ((ret = sigaction(sig, action, &g_native_code.sa_old[curInitCount][sig])) != 0) {
            LOGE("sigaction error. ret: %d", ret);
            return -1;
        }
    }
    LOGD("set sigaction ok.");
    /* OK. */
    return 0;
}

/**
 * Free a native_code_handler_struct structure.
 **/
static int native_code_handler_struct_free(native_code_handler_struct *const t) {
    int code = 0;

    if (t == NULL) {
        return -1;
    }

#ifndef NO_USE_SIGALTSTACK
    /* Restore previous alternative stack. */
    if (t->stack_old.ss_sp != NULL && sigaltstack(&t->stack_old, NULL) != 0) {
#ifndef USE_SILENT_SIGALTSTACK
        code = -1;
#endif
    }
#endif

    /* Free alternative stack */
    if (t->stack_buffer != NULL) {
        free(t->stack_buffer);
        t->stack_buffer = NULL;
        t->stack_buffer_size = 0;
    }

    /* Free structure. */
    free(t);

    return code;
}

/**
 * Create a native_code_handler_struct structure.
 **/
static native_code_handler_struct* native_code_handler_struct_init(void) {
    stack_t stack;
    native_code_handler_struct *const t = (native_code_handler_struct*)calloc(sizeof(native_code_handler_struct), 1);

    if (t == NULL) {
        LOGE("native_code_handler_struct_init cannot calloc memory.");
        return NULL;
    }

    /* Initialize structure */
    t->stack_buffer_size = SIG_STACK_BUFFER_SIZE;
    t->stack_buffer = (char*)malloc(t->stack_buffer_size);
    if (t->stack_buffer == NULL) {
        native_code_handler_struct_free(t);
        LOGE("t->stack_buffer cannot malloc memory.");
        return NULL;
    }

    /* Setup alternative stack. */
    memset(&stack, 0, sizeof(stack));
    stack.ss_sp = t->stack_buffer;
    stack.ss_size = t->stack_buffer_size;
    stack.ss_flags = 0;

#ifndef NO_USE_SIGALTSTACK
    /* Install alternative stack. This is thread-safe */
    LOGD("sigaltstack NO_USE_SIGALTSTACK");
    if (sigaltstack(&stack, &t->stack_old) != 0) {
#ifndef USE_SILENT_SIGALTSTACK
        LOGD("sigaltstack USE_SILENT_SIGALTSTACK");
        native_code_handler_struct_free(t);
        return NULL;
#endif
    }
#endif

    return t;
}

/**
 * Acquire the crash handler for the current thread.
 * The handler_cleanup() must be called to release allocated
 * resources.
 **/
static int handler_setup(int setup_thread, int id) {
    int code;

    /* Initialize globals. */
    if (pthread_mutex_lock(&g_native_code.mutex) != 0) {
        return -1;
    }

    code = handler_setup_global(id);

    if (pthread_mutex_unlock(&g_native_code.mutex) != 0) {
        return -1;
    }

    /* Global initialization failed. */
    if (code != 0) {
        return -1;
    }

    /* Initialize locals. */
    if (setup_thread && getCrashHandler() == NULL) {
        native_code_handler_struct *const t = native_code_handler_struct_init();

        if (t == NULL) {
            return -1;
        }

        g_native_code_handler = t;

    }

    /* OK. */
    return 0;
}

/**
 * Get the backtrace size. Returns 0 if no backtrace is available.
 */
size_t get_backtrace_size(void) {
#ifdef USE_UNWIND
    const native_code_handler_struct* const t = getCrashHandler();
    if (t != NULL) {
        return t->frames_size;
    } else {
        return 0;
    }
#else
    return 0;
#endif
}

/* Unflag "on stack" */
static void revert_alternate_stack(void) {
#ifndef NO_USE_SIGALTSTACK
    stack_t ss;
    if (sigaltstack(NULL, &ss) == 0) {
        ss.ss_flags &= ~SS_ONSTACK;
        sigaltstack (&ss, NULL);
    }
#endif
}

/**
 * Release the resources allocated by a previous call to
 * handler_setup().
 * This function must be called as many times as
 * handler_setup() was called to fully release allocated
 * resources.
 **/
static int handler_cleanup() {
    /* Cleanup locals. */
    native_code_handler_struct *const t = getCrashHandler();
    if (t != NULL) {

        /* Erase thread-specific value now (detach). */
        if (pthread_setspecific(native_code_thread, NULL) != 0) {
            LOGE("pthread_setspecific() failed");
            return -1;
        }

        /* Free handler and reset slternate stack */
        if (native_code_handler_struct_free(t) != 0) {
            return -1;
        }
        LOGD("removed thread alternative stack.");
    }

    /* Cleanup globals. */
    if (pthread_mutex_lock(&g_native_code.mutex) != 0) {
        LOGE("pthread_mutex_lock() failed");
        return -1;
    }
    if(g_native_code.maxInitialized==0){
        return -1;
    }
    if (g_native_code.initialized == 0) {

        size_t i;
        /* Restore signal handler. */
        for(i = 0; native_sig_catch[i] != 0; i++) {
            const int sig = native_sig_catch[i];
            if (sig>SIG_NUMBER_MAX){
                LOGE("sig is bigger than max.");
                return -1;
            }
            //直接重置成最早一次设置信号处理函数时，所对应的旧信号处理函数
            if (sigaction(sig, &g_native_code.sa_old[0][sig], NULL) != 0) {
                return -1;
            }
        }

        /* Free old structure. */
        for (i = 0;i < g_native_code.maxInitialized;i++) {
            free(g_native_code.sa_old[i]);
            g_native_code.sa_old[i] = NULL;
        }

        /* Free old structure. */
        free(g_native_code.sa_old);
        g_native_code.sa_old = NULL;
        free(g_native_code.id);
        g_native_code.id = NULL;
        LOGV("cleanup signal handler");

        /* Delete thread var. */
        if (pthread_key_delete(native_code_thread) != 0) {
            LOGE("pthread_key_delete() failed.");
            return -1;
        }
    }
    if (pthread_mutex_unlock(&g_native_code.mutex) != 0) {
        LOGE("pthread_mutex_unlock() failed");
        return -1;
    }

    return 0;
}

/**
 * Calls handler_cleanup()
 */
void cleanup() {
    revert_alternate_stack();

    native_code_handler_struct *const t = getCrashHandler();
    if (t==NULL || t->reenter<=0){
        LOGE("clean up error.");
        return;
    }
    t->reenter--;
    if (t->reenter == 0) {
        t->ctx_is_set = 0;
        handler_cleanup();
    }
}

/**
 * Calls handler_setup(1) to setup a crash handler, mark the
 * context as valid, and return 0 upon success.
 */
int setupSignalHandler(int id) {
    if (handler_setup(1, id) == 0) {
        native_code_handler_struct *const t = getCrashHandler();
        if(t==NULL){
            LOGE("setupSignalHandler error.");
            return -1;
        }
        t->reenter++;
        t->ctx_is_set = 1;
        LOGD("setup reenter:%d", t->reenter);
        return 0;
    } else {
        return -1;
    }
}