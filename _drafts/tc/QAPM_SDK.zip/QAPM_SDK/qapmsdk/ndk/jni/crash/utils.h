//
// Created by toringzhang(张前) on 2019/4/6.
//

#ifndef QAPM_SDK_UTILS_H
#define QAPM_SDK_UTILS_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define THREAD_NAME_LENGTH 160

extern const char* desc_sig(int sig, int code);
extern bool format_pc_address_cb(uintptr_t pc,
                                 void (*fun)(void *arg, const char *module,
                                             uintptr_t addr,
                                             const char *function,
                                             uintptr_t offset), void *arg);
extern char* getThreadName(pid_t tid);
extern bool isEqualToPackageName(char* threadName, char* packageName);
extern char* PC2DLName(void * const addr);
#ifdef __cplusplus
}
#endif
#endif //QAPM_SDK_UTILS_H
