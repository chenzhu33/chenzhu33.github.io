//
// Created by toringzhang(张前) on 2019/4/6.
//
#include <jni.h>
#include <pthread.h>
#include <malloc.h>

#include "crashCatcher.h"
#include "common/log.h"
#include "qmjni.h"
#include "qmcatch.h"


JavaVM* g_jvm;

const char* g_packageName;
const char* g_logfile_path;

extern "C"
JNIEXPORT
void JNICALL Java_com_tencent_qapmsdk_crash_util_NativeCrashCatcher_nativeInit(JNIEnv *env, jclass type, jstring packageNameStr, jstring logPathStr, jobject callback) {


    env->GetJavaVM(&g_jvm);
    jobject callbackObj = NULL;
    if (callback != NULL) {
        callbackObj = env->NewGlobalRef(callback);
    }
    jclass nativeCrashCatcherClass = (jclass)env->NewGlobalRef(type);

    if (packageNameStr != NULL) {
        g_packageName = env->GetStringUTFChars(packageNameStr, 0);
    }

    if (logPathStr != NULL) {
        g_logfile_path = env->GetStringUTFChars(logPathStr, 0);
    }
    LOGI("native crash catcher init. packageNameStr: %s", g_packageName);
    initCondition();

    // 启动一个线程
    pthread_t thd;
    dump_thread_entry_args* args = (dump_thread_entry_args*)calloc(1, sizeof(dump_thread_entry_args));
    args->callback = callbackObj;
    args->nativeCrashCatcher = nativeCrashCatcherClass;
    int ret = pthread_create(&thd, NULL, DumpThreadEntry, args);
    if(ret) {
        LOGE("pthread_create DumpThreadEntry error. ret: %d, error:%s", ret, strerror(errno));
    }
}

extern "C"
JNIEXPORT
void JNICALL Java_com_tencent_qapmsdk_crash_util_NativeCrashCatcher_nativeSetup(JNIEnv* env, jclass type, jint id) {
    LOGI("set up signal id: %d", id);
    setupSignalHandler(id);
}

extern "C"
JNIEXPORT
void JNICALL JNI_OnUnload(JavaVM* vm, void* reserved)
{
    cleanup();
}

extern "C"
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved)
{
    JNIEnv* env = NULL;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_4) != JNI_OK) {
        return JNI_ERR;
    }

    jclass logUtilClass = env->FindClass("com/tencent/qapmsdk/common/ILogUtil");
    if(logUtilClass==NULL){
        return JNI_VERSION_1_4;
    }
    jfieldID logLevel = env->GetStaticFieldID(logUtilClass, "logLevel", "I");
    if(logLevel==NULL){
        return JNI_VERSION_1_4;
    }

    jint level = env->GetStaticIntField(logUtilClass, logLevel);
    if(level>0){
        setNativeLogLevel(level);
    }

    return JNI_VERSION_1_4;
}