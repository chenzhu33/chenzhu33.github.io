//
// Created by toringzhang(张前) on 2019/4/6.
//
#include <jni.h>

#include "log.h"

int g_debugLevel = LevelInfo;

void setNativeLogLevel(int level)
{
    g_debugLevel = level;
}

