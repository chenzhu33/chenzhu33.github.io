//
// Created by toringzhang(张前) on 2019/4/6.
//

#ifndef QAPM_SDK_LOG_H
#define QAPM_SDK_LOG_H

#include <android/log.h>
#include <jni.h>
#include <sys/system_properties.h>

enum logLevel {
    LevelOff = 0,
    LevelError,
    LevelWarn,
    LevelInfo,
    LevelDebug,
    LevelVerbos
};

extern int g_debugLevel;

#define  LOG_TAG    "QAPM_Native"
#define  LOGV(...)  if(g_debugLevel>LevelDebug) __android_log_print(ANDROID_LOG_VERBOSE,LOG_TAG,__VA_ARGS__)
#define  LOGD(...)  if(g_debugLevel>LevelInfo) __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)
#define  LOGI(...)  if(g_debugLevel>LevelWarn) __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define  LOGW(...)  if(g_debugLevel>LevelError) __android_log_print(ANDROID_LOG_WARN,LOG_TAG,__VA_ARGS__)
#define  LOGE(...)  if(g_debugLevel>LevelOff) __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)

extern void setNativeLogLevel(int level);
#endif //QAPM_SDK_LOG_H
