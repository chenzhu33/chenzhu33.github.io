#include "jni.h"
#include "android/log.h"
#include "stdio.h"
#include "stdlib.h"
#include <dlfcn.h>
#define ANDROID_SMP 0
#define HAVE_LITTLE_ENDIAN
#include "Common.h"
struct DvmDex;
#define INLINE
#include "DexProto.h"
#include "Object.h"
#include "Alloc.h"
#include "Class.h"
#include "Native.h"
#include "Array.h"
void dvmMarkCard(const void *addr);
#include "WriteBarrier.h"
#include "hutils.h"

extern "C" void dvmThrowNoSuchMethodError(const char* msg);
extern "C" ArrayObject* dvmAllocArrayByClass(ClassObject* arrayClass,
    size_t length, int allocFlags);
DataObject* dvmBoxPrimitive(JValue value, ClassObject* returnType);
Thread* dvmThreadSelf(void);
Object* dvmDecodeIndirectRef(Thread* self, jobject jobj);
void dvmCallMethod(Thread* self, const Method* method, Object* obj, JValue* pResult, ...);
INLINE bool dvmCheckException(Thread* self);
extern "C" void dvmThrowNullPointerException(const char* msg);
extern "C" void dvmThrowClassCastException(ClassObject* actual, ClassObject* desired);
Object* dvmInvokeMethod(Object* obj, const Method* method, ArrayObject* argList, ArrayObject* params, ClassObject* returnType, bool noAccessCheck);
void dvmLogExceptionStackTrace();
ClassObject* dvmGetBoxedReturnType(const Method* meth);
bool dvmUnboxPrimitive(Object* value, ClassObject* returnType, JValue* pResult);
void dvmThrowIllegalArgumentException(const char* msg);
Method* dvmGetMethodFromReflectObj(Object* obj);
Method* dvmSlotToMethod(ClassObject* clazz, int slot);

#define XPOSED_CLASS "com/tencent/qapmsdk/io/util/JavaMethodHook"

typedef JNIEnv* (*GetJNIEnv)();

#define MEMBER_OFFSET_ARRAY(type,member) offsets_array_ ## type ## _ ## member
#define MEMBER_OFFSET_VAR(type,member) offset_ ## type ## _ ## member
#define MEMBER_TYPE(type,member) offset_type_ ## type ## _ ## member

#define MEMBER_PTR(obj,type,member) \
    ( (MEMBER_TYPE(type,member)*)  ( (char*)(obj) + MEMBER_OFFSET_VAR(type,member) ) )
#define MEMBER_VAL(obj,type,member) *MEMBER_PTR(obj,type,member)

#define MEMBER_OFFSET_DEFINE(type,member,offsets...) \
    static int MEMBER_OFFSET_ARRAY(type,member)[] = { offsets }; \
    static int MEMBER_OFFSET_VAR(type,member);
#define MEMBER_OFFSET_COPY(type,member) MEMBER_OFFSET_VAR(type,member) = MEMBER_OFFSET_ARRAY(type,member)[offsetMode]


enum xposedOffsetModes {
    MEMBER_OFFSET_MODE_WITH_JIT,
    MEMBER_OFFSET_MODE_NO_JIT,
};
static xposedOffsetModes offsetMode;


MEMBER_OFFSET_DEFINE(DvmJitGlobals, codeCacheFull, 120, 0)
#define offset_type_DvmJitGlobals_codeCacheFull bool



// helper to determine the required values (compile with XPOSED_SHOW_OFFSET=true)
#ifdef XPOSED_SHOW_OFFSETS
    template<int s> struct RESULT;
    #ifdef WITH_JIT
        #pragma message "WITH_JIT is defined"
    #else
       #pragma message "WITH_JIT is not defined"
    #endif
    RESULT<sizeof(Method)> SIZEOF_Method;
    RESULT<sizeof(Thread)> SIZEOF_Thread;
    RESULT<offsetof(DvmJitGlobals, codeCacheFull)> OFFSETOF_DvmJitGlobals_codeCacheFull;
#endif

struct XposedHookInfo {
    struct {
        Method originalMethod;
        // copy a few bytes more than defined for Method in AOSP
        // to accomodate for (rare) extensions by the target ROM
        int dummyForRomExtensions[4];
    } originalMethodStruct;

    Object* reflectedMethod;
    Object* additionalInfo;
};

bool keepLoadingXposed = false;
static jclass xposedClass = NULL;
ClassObject* objectArrayClass = NULL;
Method* xposedHandleHookedMethod = NULL;
void* PTR_gDvmJit = NULL;
size_t arrayContentsOffset = 0;

static inline bool xposedIsHooked(const Method* method);

static bool xposedInitMemberOffsets(JNIEnv* env) {
    PTR_gDvmJit = dlsym(RTLD_DEFAULT, "gDvmJit");

    if (PTR_gDvmJit == NULL) {
        offsetMode = MEMBER_OFFSET_MODE_NO_JIT;
    } else {
        offsetMode = MEMBER_OFFSET_MODE_WITH_JIT;
    }
    //LOGD("Using structure member offsets for mode %s", xposedOffsetModesDesc[offsetMode]);

    MEMBER_OFFSET_COPY(DvmJitGlobals, codeCacheFull);

    // detect offset of ArrayObject->contents
    jintArray dummyArray = env->NewIntArray(1);
    if (dummyArray == NULL) {
        LOGE("Could allocate int array for testing");
        dvmLogExceptionStackTrace();
        env->ExceptionClear();
        return false;
    }

    jint* dummyArrayElements = env->GetIntArrayElements(dummyArray, NULL);
    arrayContentsOffset = (size_t)dummyArrayElements - (size_t)dvmDecodeIndirectRef(dvmThreadSelf(), dummyArray);
    env->ReleaseIntArrayElements(dummyArray,dummyArrayElements, 0);
    env->DeleteLocalRef(dummyArray);

    if (arrayContentsOffset < 12 || arrayContentsOffset > 128) {
        LOGE("Detected strange offset %d of ArrayObject->contents", arrayContentsOffset);
        return false;
    }

    return true;
}

static inline void xposedSetObjectArrayElement(const ArrayObject* obj, int index, Object* val) {
    uintptr_t arrayContents = (uintptr_t)obj + arrayContentsOffset;
    ((Object **)arrayContents)[index] = val;
    dvmWriteBarrierArray(obj, index, index + 1);
}

static void xposedCallHandler(const u4* args, JValue* pResult, const Method* method, ::Thread* self) {
		if (!xposedIsHooked(method)) {
        dvmThrowNoSuchMethodError("could not find Xposed original method - how did you even get here?");
        return;
    }

    XposedHookInfo* hookInfo = (XposedHookInfo*) method->insns;
    Method* original = (Method*) hookInfo;
    Object* originalReflected = hookInfo->reflectedMethod;
    Object* additionalInfo = hookInfo->additionalInfo;

    // convert/box arguments
    const char* desc = &method->shorty[1]; // [0] is the return type.
    Object* thisObject = NULL;
    size_t srcIndex = 0;
    size_t dstIndex = 0;

    // for non-static methods determine the "this" pointer
    if (!dvmIsStaticMethod(original)) {
        thisObject = (Object*) args[0];
        srcIndex++;
    }

    ArrayObject* argsArray = dvmAllocArrayByClass(objectArrayClass, strlen(method->shorty) - 1, ALLOC_DEFAULT);
    if (argsArray == NULL) {
        return;
    }

    while (*desc != '\0') {
        char descChar = *(desc++);
        JValue value;
        Object* obj;

        switch (descChar) {
        case 'Z':
        case 'C':
        case 'F':
        case 'B':
        case 'S':
        case 'I':
            value.i = args[srcIndex++];
            obj = (Object*) dvmBoxPrimitive(value, dvmFindPrimitiveClass(descChar));
            dvmReleaseTrackedAlloc(obj, self);
            break;
        case 'D':
        case 'J':
            value.j = dvmGetArgLong(args, srcIndex);
            srcIndex += 2;
            obj = (Object*) dvmBoxPrimitive(value, dvmFindPrimitiveClass(descChar));
            dvmReleaseTrackedAlloc(obj, self);
            break;
        case '[':
        case 'L':
            obj  = (Object*) args[srcIndex++];
            break;
        default:
            LOGE("Unknown method signature description character: %c\n", descChar);
            obj = NULL;
            srcIndex++;
        }
        xposedSetObjectArrayElement(argsArray, dstIndex++, obj);
    }

    // call the Java handler function
    JValue result;
    dvmCallMethod(self, xposedHandleHookedMethod, NULL, &result,
        originalReflected, (int) original, additionalInfo, thisObject, argsArray);

    dvmReleaseTrackedAlloc(argsArray, self);

    // exceptions are thrown to the caller
    if (dvmCheckException(self)) {
        return;
    }

    // return result with proper type
    ClassObject* returnType = dvmGetBoxedReturnType(method);
    if (returnType->primitiveType == PRIM_VOID) {
        // ignored
    } else if (result.l == NULL) {
        if (dvmIsPrimitiveClass(returnType)) {
            dvmThrowNullPointerException("null result when primitive expected");
        }
        pResult->l = NULL;
    } else {
        if (!dvmUnboxPrimitive(result.l, returnType, pResult)) {
            dvmThrowClassCastException(result.l->clazz, returnType);
        }
    }
}

static inline bool xposedIsHooked(const Method* method) {
    return (method->nativeFunc == &xposedCallHandler);
}

#ifdef __cplusplus
extern "C" {
#endif
//static jint JNI_OnLoad(JavaVM* vm, void* reserved);
JNIEXPORT static void Java_com_tencent_qapmsdk_io_util_JavaMethodHook_invokeOriginalMethodNative(const u4* args, JValue* pResult,
            const Method* method, ::Thread* self);
JNIEXPORT jboolean Java_com_tencent_qapmsdk_io_util_JavaMethodHook_initNative(JNIEnv* env, jclass clazz);
JNIEXPORT void Java_com_tencent_qapmsdk_io_util_JavaMethodHook_hookMethodNative(JNIEnv* env, jclass clazz, jobject reflectedMethodIndirect,
            jobject declaredClassIndirect, jint slot, jobject additionalInfoIndirect);

#ifdef __cplusplus
}
#endif

// simplified copy of Method.invokeNative, but calls the original (non-hooked) method and has no access checks
// used when a method has been hooked
static void Java_com_tencent_qapmsdk_io_util_JavaMethodHook_invokeOriginalMethodNative(const u4* args, JValue* pResult,
            const Method* method, ::Thread* self) {
    Method* meth = (Method*) args[1];
    if (meth == NULL) {
        meth = dvmGetMethodFromReflectObj((Object*) args[0]);
        if (xposedIsHooked(meth)) {
            meth = (Method*) meth->insns;
        }
    }
    ArrayObject* params = (ArrayObject*) args[2];
    ClassObject* returnType = (ClassObject*) args[3];
    Object* thisObject = (Object*) args[4]; // null for static methods
    ArrayObject* argList = (ArrayObject*) args[5];

    // invoke the method
    pResult->l = dvmInvokeMethod(thisObject, meth, argList, params, returnType, true);
    return;
}

jboolean Java_com_tencent_qapmsdk_io_util_JavaMethodHook_initNative(JNIEnv* env, jclass clazz) {

    ::Thread* self = dvmThreadSelf();
	jclass tmp=env->FindClass(XPOSED_CLASS);
	if(tmp==NULL)
	{
		LOGE("ERROR: cannot find XPOSED_CLASS");
		return false;
	}
	xposedClass =(jclass)env->NewGlobalRef(tmp);
    //xposedClass = env->FindClass(XPOSED_CLASS);
    LOGD("xposedClass=0x%.8X\n", xposedClass);

    xposedHandleHookedMethod = (Method*) env->GetStaticMethodID(clazz, "handleHookedMethod", //xposedClass
        "(Ljava/lang/reflect/Member;ILjava/lang/Object;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;");
    if (xposedHandleHookedMethod == NULL) {
        LOGE("ERROR: could not find method %s.handleHookedMethod(Member, int, Object, Object, Object[])\n", XPOSED_CLASS);
        dvmLogExceptionStackTrace();
        env->ExceptionClear();
        keepLoadingXposed = false;
        return false;
    }

    Method* xposedInvokeOriginalMethodNative = (Method*) env->GetStaticMethodID(xposedClass, "invokeOriginalMethodNative",
        "(Ljava/lang/reflect/Member;I[Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;");
    if (xposedInvokeOriginalMethodNative == NULL) {
        LOGE("ERROR: could not find method %s.invokeOriginalMethodNative(Member, int, Class[], Class, Object, Object[])\n", XPOSED_CLASS);
        dvmLogExceptionStackTrace();
        env->ExceptionClear();
        keepLoadingXposed = false;
        return false;
    }
    dvmSetNativeFunc(xposedInvokeOriginalMethodNative, Java_com_tencent_qapmsdk_io_util_JavaMethodHook_invokeOriginalMethodNative, NULL);


    objectArrayClass = dvmFindArrayClass("[Ljava/lang/Object;", NULL);
    if (objectArrayClass == NULL) {
        LOGE("Error while loading Object[] class");
        dvmLogExceptionStackTrace();
        env->ExceptionClear();
        keepLoadingXposed = false;
        return false;
    }

    return true;
}

void Java_com_tencent_qapmsdk_io_util_JavaMethodHook_hookMethodNative(JNIEnv* env, jclass clazz, jobject reflectedMethodIndirect,
            jobject declaredClassIndirect, jint slot, jobject additionalInfoIndirect) {
    // Usage errors?
    if(arrayContentsOffset == 0)
        xposedInitMemberOffsets(env);

    if (declaredClassIndirect == NULL || reflectedMethodIndirect == NULL) {
        dvmThrowIllegalArgumentException("method and declaredClass must not be null");
        return;
    }

    // Find the internal representation of the method
    ClassObject* declaredClass = (ClassObject*) dvmDecodeIndirectRef(dvmThreadSelf(), declaredClassIndirect);
    Method* method = dvmSlotToMethod(declaredClass, slot);
    if (method == NULL) {
        dvmThrowNoSuchMethodError("could not get internal representation for method");
        return;
    }

    if (xposedIsHooked(method)) {
        // already hooked
        return;
    }

    // Save a copy of the original method and other hook info
    XposedHookInfo* hookInfo = (XposedHookInfo*) calloc(1, sizeof(XposedHookInfo));
    memcpy(hookInfo, method, sizeof(hookInfo->originalMethodStruct));
    hookInfo->reflectedMethod = dvmDecodeIndirectRef(dvmThreadSelf(), env->NewGlobalRef(reflectedMethodIndirect));
    hookInfo->additionalInfo = dvmDecodeIndirectRef(dvmThreadSelf(), env->NewGlobalRef(additionalInfoIndirect));

    // Replace method with our own code
    SET_METHOD_FLAG(method, ACC_NATIVE);
    method->nativeFunc = &xposedCallHandler;
    method->insns = (const u2*) hookInfo;
    method->registersSize = method->insSize;
    method->outsSize = 0;


    if (PTR_gDvmJit != NULL) {
        // reset JIT cache
		char currentValue = *((char*)PTR_gDvmJit + MEMBER_OFFSET_VAR(DvmJitGlobals,codeCacheFull));
        if(currentValue == 0 || currentValue == 1){
			MEMBER_VAL(PTR_gDvmJit, DvmJitGlobals, codeCacheFull) = true;
		}else{
			LOGE("Unexpected current value for codeCacheFull:%d", currentValue);
		}
    }
}

extern "C"
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved)
{
    JNIEnv* env = NULL;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_4) != JNI_OK) {
        return JNI_ERR;
    }

    jclass logUtilClass = env->FindClass("com/tencent/qapmsdk/common/ILogUtil");
    if(logUtilClass==NULL){
        return JNI_VERSION_1_4;
    }
    jfieldID logLevel = env->GetStaticFieldID(logUtilClass, "logLevel", "I");
    if(logLevel==NULL){
        return JNI_VERSION_1_4;
    }

    jint level = env->GetStaticIntField(logUtilClass, logLevel);
    setNativeLogLevel(level);

    return JNI_VERSION_1_4;

}