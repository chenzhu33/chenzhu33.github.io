#ifndef __HUTILS_H__
#define __HUTILS_H__
#include <stdint.h>
#include <stdio.h>
#include "common/log.h"

struct JumpInfo
{
	jbyte* byte_array;
	int array_len;
	
};

extern "C" {
/**
 * 内部调用hook
 * 修改当前函数指令，对所有该函数调用均生效，该函数用于注册
 * @param old_addr 原始函数地址
 * @param new_addr 新函数地址
 * @param proto_addr 函数原型，如ssize_t (*IO_read)(int fd, void *buf, size_t count) = NULL;
 */
int __attribute__ ((visibility ("default"))) registerInlineHook_a(uint32_t old_addr, uint32_t new_addr, uint32_t **proto_addr);


/**
 * 内部调用hook
 * 仅仅构造跳转回原地址的指令块用。
 * @param old_addr 原始函数地址
 */
JumpInfo* __attribute__ ((visibility ("default"))) createJumpBlock(uint32_t old_addr);


/**
 * 内部调用hook
 * 调用registerInlineHook_a注册后，调用该函数进行hook
 */
int __attribute__ ((visibility ("default"))) inlineHook_a(uint32_t old_addr);

/**
 * 内部调用hook
 * 调用registerInlineHook_a注册后，调用该函数进行所有函数的hook
 */
int __attribute__ ((visibility ("default"))) inlineHookAll_a();

/**
 * 内部调用hook
 * 调用registerInlineHook_a注册并hook，调用该函数进行函数的unhook
 */
int __attribute__ ((visibility ("default"))) inlineUnHook_a(uint32_t old_addr);

/**
 * 内部调用hook
 * 调用registerInlineHook_a注册并hook，调用该函数进行所有函数的unhook
 */
void __attribute__ ((visibility ("default"))) inlineUnHookAll_a();

/*
 * 获得隐藏函数地址
 */
void* __attribute__ ((visibility ("default"))) dlsym_abs(const char * sym, const char * libname);

/*
 * android 7.0之下获得隐藏函数
 */
void* __attribute__ ((visibility ("default"))) dlsym_abs_for_a7(const char * sym, const char * libname);

/*
 * 获得sdcard路径
 */
//int __attribute__ ((visibility ("default"))) getSdcardPath(char* sdcardPath);

/*
 * 获得QAPM存储路径
 */
int __attribute__ ((visibility ("default"))) getAPMRoot(char* sdcardPath);

}

#endif // __HUTILS__
