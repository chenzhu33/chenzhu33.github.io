//
// Created by toringzhang on 2018/1/5.
//

#ifndef MAGNIFIERAPP_NATIVE_H
#define MAGNIFIERAPP_NATIVE_H

#include <jni.h>

#include <android/log.h>

#define LOG_TAG "MagnifierAPP"
#define LOGI(fmt, args...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, fmt, ##args)
#define LOGD(fmt, args...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, fmt, ##args)
#define LOGE(fmt, args...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, fmt, ##args)

#endif //MAGNIFIERAPP_NATIVE_H
