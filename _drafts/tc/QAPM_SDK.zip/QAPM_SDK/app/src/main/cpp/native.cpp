//
// Created by toringzhang on 2018/1/5.
//

#include "native.h"
#include <jni.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <linux/stat.h>
#include <errno.h>
#include <sys/system_properties.h>

void pwritetest(){
    char *str = "Sqlite 3";
    char filepath[] = "/storage/emulated/0/test.txt";
    int fd = creat(filepath,O_RDWR|O_CREAT|O_APPEND|S_IWUSR);
    if(fd==-1){
        LOGD("cannot open file.[%s]",strerror(errno));
        return;
    }
    pwrite64(fd,str, sizeof(str),0);
    close(fd);
}

void emptyPointer() {
    int* ponter = (int*)0x100;
    *ponter = 100;
}

char* getSystemProperty(const char* key) {
    char value[256];
    int ret = __system_property_get(key, value);
    LOGD("key: %s - value: %s.", key, value);
    if(ret==0){
        LOGD("get ok");
    }
    return value;
}

void setSystemProperty(const char* key, const char* value) {
//    int ret = __system_property_set(key, value);
//    if(ret==0){
//        LOGD("set ok.");
//    } else{
//        LOGD("error: %d", ret);
//        LOGD("%s", strerror(errno));
//    }
}

extern "C"
JNIEXPORT void JNICALL
        Java_com_example_sdkapp_MainActivity_nativeTest(JNIEnv* env,
                                                                         jobject /* this */){
        pwritetest();
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_test_1app_MainActivity_emptyPointerTest(JNIEnv* env,
                                                jobject /* this */){
    emptyPointer();
}

extern "C"
JNIEXPORT jstring JNICALL
        Java_com_example_test_1app_MainActivity_getSystemProperty(JNIEnv* env,
                                                                  jobject type, jstring keyStr){
    const char* key = env->GetStringUTFChars(keyStr,0);
    char* value = getSystemProperty(key);
    jstring valueStr = env->NewStringUTF(value);
    env->ReleaseStringUTFChars(keyStr, key);

    return valueStr;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_test_1app_MainActivity_setSystemProperty(JNIEnv* env,
                                                          jobject type, jstring keyStr, jstring valueStr){
    const char* key = env->GetStringUTFChars(keyStr,0);
    const char* value = env->GetStringUTFChars(valueStr,0);
    setSystemProperty(key, value);
    env->ReleaseStringUTFChars(keyStr, key);
    env->ReleaseStringUTFChars(valueStr, value);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved)
{
    JNIEnv* env = NULL;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_4) != JNI_OK) {
        return JNI_ERR;
    }

    return JNI_VERSION_1_4;

}
