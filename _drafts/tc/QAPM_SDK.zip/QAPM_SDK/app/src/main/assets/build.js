/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/constants/boss/index.js":
/*!*************************************!*\
  !*** ./src/constants/boss/index.js ***!
  \*************************************/
/*! exports provided: CANMODIFYKEYS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CANMODIFYKEYS", function() { return CANMODIFYKEYS; });
var CANMODIFYKEYS = ['s_path', 's_uuid', 's_traceid', 's_guid', 's_appid', 's_vuserid', 'hc_pgv_pvid', 's_omgid', 'err_desc'];

/***/ }),

/***/ "./src/constants/config/index.js":
/*!***************************************!*\
  !*** ./src/constants/config/index.js ***!
  \***************************************/
/*! exports provided: CDNQUALITY, REPORTTYPES, NOREPORTTYPES, baseUrl, getToken, setToken, setThreshold, getThreshold */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CDNQUALITY", function() { return CDNQUALITY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "REPORTTYPES", function() { return REPORTTYPES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NOREPORTTYPES", function() { return NOREPORTTYPES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "baseUrl", function() { return baseUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getToken", function() { return getToken; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setToken", function() { return setToken; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setThreshold", function() { return setThreshold; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getThreshold", function() { return getThreshold; });
var CDNQUALITY = {
  duration: 'delay',
  name: 'resurl',
  type: 'type'
};

var REPORTTYPES = ['css', 'script', 'img', 'video', 'audio'];

var NOREPORTTYPES = ['cdn', 'cgi'];

var baseUrl = 'http://162.14.17.144:30080';

var token = false;
var getToken = function getToken() {
  return token;
};
var setToken = function setToken(value) {
  token = value;
};

var isSlow = 3000;
var setThreshold = function setThreshold(threshold) {
  isSlow = threshold;
};
var getThreshold = function getThreshold() {
  return isSlow;
};

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/*! exports provided: initEmonitor, getRcTiming, getPfTiming, getCdnTiming, getParts */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initEmonitor", function() { return initEmonitor; });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils */ "./src/utils/index.js");
/* harmony import */ var _performance__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./performance */ "./src/performance/index.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getRcTiming", function() { return _performance__WEBPACK_IMPORTED_MODULE_1__["getRcTiming"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getPfTiming", function() { return _performance__WEBPACK_IMPORTED_MODULE_1__["getPfTiming"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getCdnTiming", function() { return _performance__WEBPACK_IMPORTED_MODULE_1__["getCdnTiming"]; });

/* harmony import */ var _performance_parts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./performance/parts */ "./src/performance/parts.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getParts", function() { return _performance_parts__WEBPACK_IMPORTED_MODULE_2__["getParts"]; });

/* harmony import */ var _constants_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./constants/config */ "./src/constants/config/index.js");
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/* eslint-disable func-names */





__webpack_require__(/*! ./track/trackbundle.js */ "./src/track/trackbundle.js");

// 初始化参数
// TODO, change this, pid,默认为ios的配置
var appId = '770';
// TODO, change this, 产品自身的版本号
var version = '1.0';
// TODO, change this, 当前登录的用户标识, 如 QQ 号, openid, 企业员工名字等
var userId = '10000';
// TODO, change this, 设备id
var deviceId = 'test';
// TODO, change this, appkey,默认为ios的配置
var appKey = '53416939-770';
// emonitor的参数
window.onerror = true;
var isTimingReported = false;

window.qapmAndroidBreadCrumb = function () {
  var eventId = '';
  try {
    var eventCon = window.EventCon.EventCon.getInstance();
    var EventCAL = window.EventCon.EventCAL;

    var eventCal = new EventCAL();
    eventCal.category = '_APM.LAG';
    eventId = eventCon.sendEvent(eventCal);
    window.AndroidQAPMJsBridge.setBreadCrumbId(eventId);
    console.log('TEST, _APM.LAG, eventId: ', eventId);
  } catch (e) {
    try {
      eventId = '';
      window.android.setBreadCrumbId(eventId);
    } catch (e1) {
      console.error(e1);
    }
    console.error(e);
  }
  return eventId;
};

var Monitor = function () {
  function Monitor(_ref) {
    var qapm = _ref.qapm,
        config = _ref.config;

    _classCallCheck(this, Monitor);

    Object(_constants_config__WEBPACK_IMPORTED_MODULE_3__["setToken"])(false);
    this.qapm = qapm;
    Object(_constants_config__WEBPACK_IMPORTED_MODULE_3__["setThreshold"])(config.is_slow);
    var debounceReport = Object(_utils__WEBPACK_IMPORTED_MODULE_0__["debounce"])(_utils__WEBPACK_IMPORTED_MODULE_0__["doReport"], 0, function () {});
    var key = Object(_utils__WEBPACK_IMPORTED_MODULE_0__["getKey"])(qapm.app_key);
    var context = this;
    context.qapm.p_id = key.p_id;
    if (!Object(_utils__WEBPACK_IMPORTED_MODULE_0__["isiOS"])()) return;
    debounceReport({
      baseUrl: _constants_config__WEBPACK_IMPORTED_MODULE_3__["baseUrl"],
      data: { app_key: key.private_app_key, p_id: key.p_id },
      method: 'GET'
    });
    // TODO 调用JS桥进行传入设备数据
    //  initByJsBridge
  }

  _createClass(Monitor, [{
    key: 'config',
    value: function config() {
      var opts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      for (var op in opts) {
        this[op] = opts[op];
        // if (
        //   ['baseUrl', 'delay', 'name'].indexOf(
        //     String(op),
        //   ) !== -1
        // ) {
        //   this[op] = opts[op];
        // }
      }
      return this;
    }
  }, {
    key: 'send',
    value: function send() {
      if (!Object(_utils__WEBPACK_IMPORTED_MODULE_0__["isiOS"])()) return;
      var debounceReport = Object(_utils__WEBPACK_IMPORTED_MODULE_0__["debounce"])(_utils__WEBPACK_IMPORTED_MODULE_0__["doReport"], 2000, function () {});
      var partData = Object(_performance_parts__WEBPACK_IMPORTED_MODULE_2__["getParts"])();
      if (!partData.parts) {
        return;
      }
      var mergeData = Object.assign({}, this.qapm, partData);
      debounceReport({
        baseUrl: _constants_config__WEBPACK_IMPORTED_MODULE_3__["baseUrl"],
        data: mergeData,
        method: 'POST'
      });
    }
  }]);

  return Monitor;
}();

var initEmonitor = function initEmonitor() {
  var _ref2 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      qapm = _ref2.qapm,
      config = _ref2.config;

  return new Monitor({
    qapm: qapm,
    config: config
  });
};

var initAnthena = function initAnthena() {
  // 初始化 GA, 直接这么写就好
  window.ga('create', 'UA-74197094-1', 'auto');

  console.log('init eventcon.js, user:', userId);
  var eventCon = window.EventCon.EventCon.getInstance();
  eventCon.init(appId, version, userId);
  eventCon.setField('athena_base_url', 'http://162.14.17.144:30081/athena/');
  eventCon.setField('device_id', deviceId);
  // eventCon.subscribe(e => {
  //   console.log('event:', e);
  // });
  eventCon.start();
  console.log('init track.js');

  // 记录用户操作行为
  // eslint-disable-next-line no-undef
  ga('require', 'godTracker', {
    transforms: [{
      urlFilter: '/',
      middlewareList: [
      // TODO, change this
      // 不保留 url query string 参数
      ['middlewarePickParams', []]]
    }]
  });
  // 捕获 console 日志并上报
  // eslint-disable-next-line no-undef
  ga('require', 'consoleTracker', { methods: ['error', 'warn'] });
  // DOM 全局事件,
  // eslint-disable-next-line no-undef
  ga('require', 'domEventTracker');
  // 页面加载性能
  // eslint-disable-next-line no-undef
  ga('require', 'performanceTracker');
  // 监控页面上元素的变更
  // eslint-disable-next-line no-undef
  ga('require', 'elementWatchTracker', {
    // TODO, change this
    watchers: [{
      name: 'version',
      urlFilter: '/web/uba/pageTransform',
      selector: function selector() {
        return document.querySelector(".Filter input[name='version']").value;
      }
    }, {
      name: 'page',
      urlFilter: '/web/uba/pageTransform',
      // eslint-disable-next-line no-undef
      selector: function selector() {
        return $(".Filter input[name='page']").value;
      }
    }]
  });
};

var doInit = function doInit() {
  var emonitorIns = initEmonitor({
    qapm: {
      uin: userId,
      arch: 'web',
      version: '1.0.0',
      device: 'web',
      // app_key: 'c61b0684-14199',
      app_key: '' + appKey,
      plugin: '141',
      api_ver: '1',
      plugin_ver: '1',
      client_identify: '1',
      os: '1.0.0',
      deviceid: deviceId,
      manu: 'web',
      rdmuuid: 'e6ae1282-ceb8-4237-89bd-2d23d00a8e33',
      sdk_ver: '1.0.0'
    },
    config: {
      is_slow: 1
    }
  });

  window.addEventListener('load', function () {
    initAnthena();
    setTimeout(function () {
      if (!isTimingReported) {
        if (typeof onLoad === 'function') {
          // eslint-disable-next-line no-undef
          onLoad();
        } else {
          emonitorIns.send();
        }
        isTimingReported = true;
      }
    }, 0);
  }, false);
};

if (Object(_utils__WEBPACK_IMPORTED_MODULE_0__["isAndroid"])()) {
  try {
    userId = window.AndroidQAPMJsBridge.getUin();
    deviceId = window.AndroidQAPMJsBridge.getDeviceId();
    appKey = window.AndroidQAPMJsBridge.getAppkey();
    // eslint-disable-next-line prefer-destructuring
    appId = appKey.split('-')[1];
  } catch (e) {
    console.log(e.toString());
  }
}

if (Object(_utils__WEBPACK_IMPORTED_MODULE_0__["isiOS"])()) {
  try {
    // eslint-disable-next-line prefer-destructuring
    userId = window.qapmBaseInfo.userId;
    // eslint-disable-next-line prefer-destructuring
    deviceId = window.qapmBaseInfo.deviceId;
    // eslint-disable-next-line prefer-destructuring
    appKey = window.qapmBaseInfo.appKey;
    // eslint-disable-next-line prefer-destructuring
    appId = appKey.split('-')[1];
    alert(appKey.split('-'));
  } catch (e) {
    console.log(e.toString());
  }
}
alert('userId: ' + userId + 'deviceId: ' + deviceId + 'appKey: ' + appKey + 'appId: ' + appId);
doInit();



/***/ }),

/***/ "./src/performance/data.js":
/*!*********************************!*\
  !*** ./src/performance/data.js ***!
  \*********************************/
/*! exports provided: getOtherData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getOtherData", function() { return getOtherData; });
var getOtherData = function getOtherData() {
  var otherData = {
    fps_json_arr: [],
    cup_info_json_arr: [],
    memory_info_json_arr: [],
    network_info_json_arr: [],
    gpu_info_json_arr: [],
    proxy_type: 0,
    socket_reuse_pro: 0,
    qproxy_strategy: 0,
    hostcount: 0,
    apn_type: 4,
    version: 'V1',
    quic_pro: 0,
    frame_start_time: 0,
    frame_end_time: 0,
    layer_num: 0,
    total_layer_mem: 0,
    min_layer_size: 0,
    max_layer_size: 0,
    base_time: 0
  };
  return otherData;
};



/***/ }),

/***/ "./src/performance/index.js":
/*!**********************************!*\
  !*** ./src/performance/index.js ***!
  \**********************************/
/*! exports provided: getPfTiming, getRcTiming, getSingletonTiming, getCdnTiming, getRecData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPfTiming", function() { return getPfTiming; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRcTiming", function() { return getRcTiming; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSingletonTiming", function() { return getSingletonTiming; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCdnTiming", function() { return getCdnTiming; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRecData", function() { return getRecData; });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils */ "./src/utils/index.js");
/* harmony import */ var _constants_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants/config */ "./src/constants/config/index.js");
/* harmony import */ var _untils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./untils */ "./src/performance/untils.js");



// 计算加载时间

var getPfTiming = function getPfTiming() {
  try {
    var _performance = window.performance || window.webkitPerformance || window.msPerformance || window.mozPerformance;

    if (_performance === undefined) {
      return false;
    }
    var timing = _performance.timing;

    var times = {};

    times.first_word = timing.responseStart - timing.fetchStart;
    times.first_screen = timing.responseEnd - timing.fetchStart;
    times.page_finish = timing.loadEventEnd - timing.fetchStart;
    times.dom_loading = timing.domLoading - timing.fetchStart;
    times.dom_interactive = timing.domInteractive - timing.fetchStart;
    // eslint-disable-next-line max-len
    times.dom_content_loaded_event = timing.domContentLoadedEventEnd - timing.fetchStart;
    times.dom_complete = timing.domComplete - timing.fetchStart;

    return times;
  } catch (err) {
    console.warn('err', err);
    return {};
  }
};

var calculateTime = function calculateTime(domTime, origin) {
  return domTime + origin <= 0 ? 0 : Math.round(domTime + origin);
};
// 统计页面资源性能
var getRecData = function getRecData() {
  try {
    if (!window.performance || !window.performance.getEntries) {
      console.warn('prerformance is not supported');
      return [];
    }
    var _window = window,
        _performance2 = _window.performance;

    var resource = _performance2.getEntries();
    if (!resource && !resource.length) {
      return [];
    }
    var mainResource = {};
    var subResourceJsonArr = [];
    try {
      resource.forEach(function (item) {
        // 顺序不可变
        var origin = _performance2.timing.navigationStart;
        var json = {
          shortUrl: item.name,
          resource_type: _untils__WEBPACK_IMPORTED_MODULE_2__["TYPE"][item.initiatorType],
          proxy_type: item.nextHopProtocol,
          qProxyStrategy: 0,
          website_address: ':0',
          dns_end: calculateTime(item.domainLookupEnd, origin),
          dns_start: calculateTime(item.domainLookupStart, origin),
          connect_end: calculateTime(item.connectEnd, origin),
          connect_start: calculateTime(item.connectStart, origin),
          ssl_handshake_end: item.secureConnectionStart === 0 ? 0 : calculateTime(item.connectEnd, origin),
          ssl_handshake_start: item.secureConnectionStart === 0 ? 0 : calculateTime(item.secureConnectionStart, origin),
          send_end: calculateTime(item.responseStart, origin),
          send_start: calculateTime(item.requestStart, origin),
          recv_end: calculateTime(item.responseEnd, origin),
          recv_start: calculateTime(item.responseStart, origin),
          zero: 0,
          recv_bytes: item.encodedBodySize !== undefined ? item.encodedBodySize : 0,
          session_resumption: 0,
          cipher_suit: 0,
          proxy_data: 0,
          socket_reused: 0,
          was_cached: 0,
          expired_time: 86400000,
          error_id: 0,
          resourceRequestTriggerTime: calculateTime(item.requestStart, origin),
          resourceRequestHandleTime: calculateTime(item.domainLookupEnd, origin),
          status_code: 200,
          connectInfo: 0,
          redirect_end_time: item.redirectEnd === 0 ? 0 : calculateTime(item.redirectEnd, origin),
          redirect_start_time: item.redirectStart === 0 ? 0 : calculateTime(item.redirectEnd, origin),
          redirect_times: item.redirectStart !== 0 ? 2 : 1,
          is_first_screen_resource: 0,
          sent_bytes: 0,
          http_method: 'GET',
          content_encoding: ''
        };
        //   Object.assign(json, getRecOtherData); 添加其他信息
        if (typeof json.resource_type !== 'undefined') {
          if (item instanceof PerformanceResourceTiming) {
            subResourceJsonArr.push(json);
          } else {
            mainResource.push(json);
          }
        }
      });
    } catch (err) {
      console.error('get resourceTiming err::::', err);
    }
    if (JSON.stringify(mainResource) === '{}') {
      var timing = _performance2.timing;

      mainResource = {
        shortUrl: window.location.href,
        resource_type: 0,
        proxy_type: 0,
        qProxyStrategy: 0,
        website: ':0',
        dns_end: timing.domainLookupEnd,
        dns_start: timing.domainLookupStart,
        connect_end: timing.connectEnd,
        connect_start: timing.connectStart,
        ssl_handshake_end: timing.secureConnectionStart === 0 ? 0 : timing.connectEnd,
        ssl_handshake_start: timing.secureConnectionStart,
        send_end: timing.responseStart,
        send_start: timing.requestStart,
        recv_end: timing.responseEnd,
        recv_start: timing.responseStart,
        zero: 0,
        recv_bytes: 0,
        session_resumption: 0,
        cipher_suit: 0,
        proxy_data: 0,
        socket_reused: 0,
        was_cached: 0,
        expired_time: 86400000,
        error_id: 0,
        resourceRequestTriggerTime: timing.requestStart,
        resourceRequestHandleTime: timing.domainLookupEnd,
        status_code: 200,
        connectInfo: 0,
        redirect_end_time: timing.redirectEnd,
        redirect_start_time: timing.redirectStart,
        redirect_times: _performance2.navigation.redirectCount + 1,
        is_first_screen_resource: 0,
        sent_bytes: 0,
        http_method: 'GET',
        content_encoding: ''
      };
    }
    var data = {
      main_resource: Object(_untils__WEBPACK_IMPORTED_MODULE_2__["changMainSrcString"])(mainResource),
      sub_resource_json_arr: Object(_untils__WEBPACK_IMPORTED_MODULE_2__["changToString"])(subResourceJsonArr)
    };
    return data;
  } catch (err) {
    console.warn('get performance happen error');
    return [];
  }
};
var getSingletonTiming = function getSingletonTiming() {
  try {
    var _performance3 = window.performance || window.webkitPerformance || window.msPerformance || window.mozPerformance;

    if (_performance3 === undefined) {
      return false;
    }
    var timing = _performance3.timing;

    var data = {};
    data.first_screen = timing.loadEventStart;
    data.dom_loading = timing.domLoading;
    data.page_finish = timing.loadEventEnd;
    data.dom_interactive = timing.domInteractive;
    data.dom_complete = timing.domComplete;
    data.first_word = timing.responseStart;
    data.dom_content_loaded_event_start = timing.domContentLoadedEventStart;
    data.dom_content_loaded_event_end = timing.domContentLoadedEventEnd;
    // 首字时间
    data.first_word_stamp = timing.domLoading;
    // 首屏时间
    data.first_screen_stamp = timing.loadEventEnd;
    // 首字节时间
    data.first_byte_stamp = timing.responseStart;
    data.frame_start_time = 0;
    data.frame_end_time = 0;
    // 解析耗时
    data.parser_elapsed = timing.domInteractive;
    // 渲染耗时
    data.render_elapsed = timing.domContentLoadedEventEnd;
    // 上屏耗时
    data.layout_elapsed = timing.loadEventEnd;
    data.page_start = timing.fetchStart;
    data.is_system_kernel = Object(_utils__WEBPACK_IMPORTED_MODULE_0__["DeviceInfo"])();
    data.start_monitor_time = timing.navigationStart;
    data.stop_monitor_time = timing.loadEventEnd;
    return data;
  } catch (err) {
    console.warn('err', err);
    return {};
  }
};
var getRcTiming = function getRcTiming() {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      name = _ref.name,
      type = _ref.type;

  try {
    if (!window.performance && !window.performance.getEntries) {
      console.warn('prerformance is not supported');
      return [];
    }
    var resource = performance.getEntries();
    var resourceList = [];
    if (!resource && !resource.length) {
      return resourceList;
    }
    try {
      resource.forEach(function (item) {
        var json = {
          name: item.name,
          time_redirect: item.redirectEnd - item.redirectStart,
          time_dns: item.domainLookupEnd - item.domainLookupStart,
          time_requestTime: item.responseEnd - item.requestStart,
          time_tcp: item.connectEnd - item.connectStart,
          type: item.initiatorType,
          starttime: Math.floor(item.startTime),
          entryType: item.entryType,
          duration: Math.floor(item.duration) || 0,
          decodedBodySize: item.decodedBodySize || 0,
          nextHopProtocol: item.nextHopProtocol,
          json_entries: JSON.stringify(item)
        };
        resourceList.push(json);
      });
    } catch (err) {
      console.error('get resourceTiming err::::', err);
    }
    var match = [];
    if (name) {
      match = resourceList.filter(function (r) {
        return r.name === name;
      });
      return match[0];
    }
    if (type) {
      match = resourceList.filter(function (r) {
        return r.type === type;
      });
      return match;
    }
    return resourceList;
  } catch (err) {
    console.warn('get performance happen error');
    return [];
  }
};

var getCdnTiming = function getCdnTiming() {
  var CDNRCININFO = {};
  _constants_config__WEBPACK_IMPORTED_MODULE_1__["REPORTTYPES"].forEach(function (type) {
    CDNRCININFO[type] = Object(_utils__WEBPACK_IMPORTED_MODULE_0__["transformRc"])(getRcTiming({
      type: type
    }));
  });
  return CDNRCININFO;
};


/***/ }),

/***/ "./src/performance/network.js":
/*!************************************!*\
  !*** ./src/performance/network.js ***!
  \************************************/
/*! exports provided: getNetWork */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getNetWork", function() { return getNetWork; });
var getNetWork = function getNetWork() {
  if (!document) {
    return {};
  }
  var data = {
    url: document.URL ? document.URL : '',
    referer: document.referrer,
    qproxy_strategy: 0
  };
  return data;
};



/***/ }),

/***/ "./src/performance/parts.js":
/*!**********************************!*\
  !*** ./src/performance/parts.js ***!
  \**********************************/
/*! exports provided: getParts */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getParts", function() { return getParts; });
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index */ "./src/performance/index.js");
/* harmony import */ var _constants_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants/config */ "./src/constants/config/index.js");
/* harmony import */ var _network__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./network */ "./src/performance/network.js");
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./data */ "./src/performance/data.js");





var getParts = function getParts() {
  var partData = {
    parts: []
  };
  var data = {
    category: 'webview_x5_metrics',
    is_slow: Object(_constants_config__WEBPACK_IMPORTED_MODULE_1__["getThreshold"])(),
    url: '',
    apn_type: 0,
    first_word: 0,
    first_screen: 0,
    page_finish: 0,
    dom_loading: 0,
    dom_interactive: 0,
    dom_content_loaded_event: 0,
    dom_complete: 0

  };
  Object.assign(data, Object(_index__WEBPACK_IMPORTED_MODULE_0__["getPfTiming"])(), Object(_network__WEBPACK_IMPORTED_MODULE_2__["getNetWork"])());
  partData.parts.push(data);
  if (data.page_finish > Object(_constants_config__WEBPACK_IMPORTED_MODULE_1__["getThreshold"])()) {
    var singleton = {
      category: 'webview_x5_singleton'
    };
    Object.assign(singleton, Object(_index__WEBPACK_IMPORTED_MODULE_0__["getSingletonTiming"])(), Object(_index__WEBPACK_IMPORTED_MODULE_0__["getRecData"])(), Object(_network__WEBPACK_IMPORTED_MODULE_2__["getNetWork"])(), Object(_data__WEBPACK_IMPORTED_MODULE_3__["getOtherData"])());

    // 如果个例里面主资源不存在则表示数据异常不用上报
    if (!singleton.main_resource) {
      return {};
    }
    // 添加用户行为上报
    var breadcrumbs = { bread_crumb_id: '' };
    try {
      var eventCon = window.EventCon.EventCon.getInstance();
      var EventCAL = window.EventCon.EventCAL;

      var eventCal = new EventCAL();
      eventCal.category = '_APM.LAG';
      var eventId = eventCon.sendEvent(eventCal);
      breadcrumbs = { bread_crumb_id: eventId };
      console.log('TEST, _APM.LAG, eventId: ', eventId);
    } catch (e) {
      console.error(e);
    }

    Object.assign(singleton, breadcrumbs);
    partData.parts.push(singleton);
  }
  return partData;
  // TO-DO
};



/***/ }),

/***/ "./src/performance/untils.js":
/*!***********************************!*\
  !*** ./src/performance/untils.js ***!
  \***********************************/
/*! exports provided: TYPE, changToString, changMainSrcString */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TYPE", function() { return TYPE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "changToString", function() { return changToString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "changMainSrcString", function() { return changMainSrcString; });
var TYPE = {
  default: -1,
  mianframe: 0,
  subframe: 1,
  css: 2,
  script: 3,
  img: 4,
  FONT_RESOURCE: 5,
  SUB_RESOURCE: 6,
  OBJECT: 7,
  audio: 8,
  video: 8,
  media: 8,
  WORKER: 9,
  SHARED_WORKER: 10,
  fetch: 11,
  FAVICON: 12,
  xmlhttprequest: 13,
  RESOURCE_TYPE_PING: 14,
  RESOURCE_TYPE_SERVICE_WORKER: 15,
  RESOURCE_TYPE_CSP_REPORT: 16,
  RESOURCE_TYPE_PLUGIN_RESOURCE: 17,
  RESOURCE_TYPE_LAST_TYPE: 18,
  LAST_TYPE: 19,
  navigation: 0
};

var changMainSrcString = function changMainSrcString(data) {
  if (!data) return '';
  var array = Object.values(data);
  var result = array[0];
  for (var i = 1, len = array.length; i < len; i++) {
    result += '||' + array[i];
  }
  return result;
};

var changToString = function changToString(json) {
  if (!json) return '';
  var result = [];
  for (var i = 0, len = json.length; i < len; i++) {
    result.push(changMainSrcString(json[i]));
  }
  return result;
};



/***/ }),

/***/ "./src/track/trackbundle.js":
/*!**********************************!*\
  !*** ./src/track/trackbundle.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function (e) {
  var t = {};function n(r) {
    if (t[r]) return t[r].exports;var i = t[r] = { i: r, l: !1, exports: {} };return e[r].call(i.exports, i, i.exports, n), i.l = !0, i.exports;
  }n.m = e, n.c = t, n.d = function (e, t, r) {
    n.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: r });
  }, n.r = function (e) {
    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e, "__esModule", { value: !0 });
  }, n.t = function (e, t) {
    if (1 & t && (e = n(e)), 8 & t) return e;if (4 & t && "object" == (typeof e === "undefined" ? "undefined" : _typeof(e)) && e && e.__esModule) return e;var r = Object.create(null);if (n.r(r), Object.defineProperty(r, "default", { enumerable: !0, value: e }), 2 & t && "string" != typeof e) for (var i in e) {
      n.d(r, i, function (t) {
        return e[t];
      }.bind(null, i));
    }return r;
  }, n.n = function (e) {
    var t = e && e.__esModule ? function () {
      return e.default;
    } : function () {
      return e;
    };return n.d(t, "a", t), t;
  }, n.o = function (e, t) {
    return Object.prototype.hasOwnProperty.call(e, t);
  }, n.p = "", n(n.s = 0);
}([function (e, t, n) {
  n(1), n(2), e.exports = n(3);
}, function (e, t) {
  !function () {
    var e = this,
        t = function t(_t2, n) {
      _t2 = _t2.split(".");var r,
          i = e;_t2[0] in i || void 0 === i.execScript || i.execScript("var " + _t2[0]);for (; _t2.length && (r = _t2.shift());) {
        _t2.length || void 0 === n ? i = i[r] && i[r] !== Object.prototype[r] ? i[r] : i[r] = {} : i[r] = n;
      }
    },
        n = function n(e, t) {
      for (var n in t) {
        t.hasOwnProperty(n) && (e[n] = t[n]);
      }
    },
        r = function r(e) {
      for (var t in e) {
        if (e.hasOwnProperty(t)) return !0;
      }return !1;
    },
        i = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i,
        o = window,
        a = document,
        s = function s(e, t) {
      a.addEventListener ? a.addEventListener(e, t, !1) : a.attachEvent && a.attachEvent("on" + e, t);
    },
        c = /:[0-9]+$/,
        l = function l(e, t) {
      t && (t = String(t).toLowerCase()), "protocol" !== t && "port" !== t || (e.protocol = u(e.protocol) || u(o.location.protocol)), "port" === t ? e.port = String(Number(e.hostname ? e.port : o.location.port) || ("http" == e.protocol ? 80 : "https" == e.protocol ? 443 : "")) : "host" === t && (e.hostname = (e.hostname || o.location.hostname).replace(c, "").toLowerCase());var n = u(e.protocol);switch (t && (t = String(t).toLowerCase()), t) {case "url_no_fragment":
          t = "", e && e.href && (t = 0 > (t = e.href.indexOf("#")) ? e.href : e.href.substr(0, t)), e = t;break;case "protocol":
          e = n;break;case "host":
          e = e.hostname.replace(c, "").toLowerCase();break;case "port":
          e = String(Number(e.port) || ("http" == n ? 80 : "https" == n ? 443 : ""));break;case "path":
          e = (e = "/" == e.pathname.substr(0, 1) ? e.pathname : "/" + e.pathname).split("/");e: if (t = e[e.length - 1], n = [], Array.prototype.indexOf) t = n.indexOf(t), t = "number" == typeof t ? t : -1;else {
            for (var r = 0; r < n.length; r++) {
              if (n[r] === t) {
                t = r;break e;
              }
            }t = -1;
          }0 <= t && (e[e.length - 1] = ""), e = e.join("/");break;case "query":
          e = e.search.replace("?", "");break;case "extension":
          e = (e = 1 < (e = e.pathname.split(".")).length ? e[e.length - 1] : "").split("/")[0];break;case "fragment":
          e = e.hash.replace("#", "");break;default:
          e = e && e.href;}return e;
    },
        u = function u(e) {
      return e ? e.replace(":", "").toLowerCase() : "";
    },
        d = function d(e) {
      var t = a.createElement("a");e && (t.href = e), "/" !== (e = t.pathname)[0] && (e = "/" + e);var n = t.hostname.replace(c, "");return { href: t.href, protocol: t.protocol, host: t.host, hostname: n, pathname: e, search: t.search, hash: t.hash, port: t.port };
    };function h() {
      for (var e = g, t = {}, n = 0; n < e.length; ++n) {
        t[e[n]] = n;
      }return t;
    }function f() {
      var e = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";return (e += e.toLowerCase() + "0123456789-_") + ".";
    }var g,
        p,
        m,
        v = function v(e) {
      g = g || f(), p = p || h();for (var t = [], n = 0; n < e.length; n += 3) {
        var r = n + 1 < e.length,
            i = n + 2 < e.length,
            o = e.charCodeAt(n),
            a = r ? e.charCodeAt(n + 1) : 0,
            s = i ? e.charCodeAt(n + 2) : 0,
            c = o >> 2;o = (3 & o) << 4 | a >> 4, a = (15 & a) << 2 | s >> 6, s &= 63, i || (s = 64, r || (a = 64)), t.push(g[c], g[o], g[a], g[s]);
      }return t.join("");
    },
        _ = function _(e) {
      function t(t) {
        for (; r < e.length;) {
          var n = e.charAt(r++),
              i = p[n];if (null != i) return i;if (!/^[\s\xa0]*$/.test(n)) throw Error("Unknown base64 encoding at char: " + n);
        }return t;
      }g = g || f(), p = p || h();for (var n = "", r = 0;;) {
        var i = t(-1),
            o = t(0),
            a = t(64),
            s = t(64);if (64 === s && -1 === i) return n;n += String.fromCharCode(i << 2 | o >> 4), 64 != a && (n += String.fromCharCode(o << 4 & 240 | a >> 2), 64 != s && (n += String.fromCharCode(a << 6 & 192 | s)));
      }
    };function w(e, t) {
      if (!e || t === a.location.hostname) return !1;for (var n = 0; n < e.length; n++) {
        if (e[n] instanceof RegExp) {
          if (e[n].test(t)) return !0;
        } else if (0 <= t.indexOf(e[n])) return !0;
      }return !1;
    }var y = function y() {
      var e = {},
          t = o.google_tag_data;return o.google_tag_data = void 0 === t ? e : t, (t = (e = o.google_tag_data).gl) && t.decorators || (t = { decorators: [] }, e.gl = t), t;
    },
        b = /(.*?)\*(.*?)\*(.*)/,
        E = /([^?#]+)(\?[^#]*)?(#.*)?/,
        T = /(.*?)(^|&)_gl=([^&]*)&?(.*)/,
        C = function C(e) {
      var t,
          n = [];for (t in e) {
        if (e.hasOwnProperty(t)) {
          var r = e[t];void 0 !== r && r == r && null !== r && "[object Object]" !== r.toString() && (n.push(t), n.push(v(String(r))));
        }
      }return e = n.join("*"), ["1", O(e), e].join("*");
    },
        O = function O(e, t) {
      if (e = [window.navigator.userAgent, new Date().getTimezoneOffset(), window.navigator.userLanguage || window.navigator.language, Math.floor(new Date().getTime() / 60 / 1e3) - (void 0 === t ? 0 : t), e].join("*"), !(t = m)) {
        t = Array(256);for (var n = 0; 256 > n; n++) {
          for (var r = n, i = 0; 8 > i; i++) {
            r = 1 & r ? r >>> 1 ^ 3988292384 : r >>> 1;
          }t[n] = r;
        }
      }for (m = t, t = 4294967295, n = 0; n < e.length; n++) {
        t = t >>> 8 ^ m[255 & (t ^ e.charCodeAt(n))];
      }return ((-1 ^ t) >>> 0).toString(36);
    };function k(e) {
      var t = T.exec(e);if (t) {
        var n = t[2],
            r = t[4];e = t[1], r && (e = e + n + r);
      }return e;
    }var S = function S(e, t, n) {
      function r(e, t) {
        return (e = k(e)).length && (e = t + e), e;
      }o.history && o.history.replaceState && (T.test(t) || T.test(n)) && (e = l(e, "path"), t = r(t, "?"), n = r(n, "#"), o.history.replaceState({}, void 0, "" + e + t + n));
    },
        A = function A(e) {
      var t = void 0 === t ? 3 : t;try {
        if (e) {
          e: {
            for (var n = 0; 3 > n; ++n) {
              var r = b.exec(e);if (r) {
                var i = r;break e;
              }e = decodeURIComponent(e);
            }i = void 0;
          }if (i && "1" === i[1]) {
            var o = i[2],
                a = i[3];e: {
              for (i = 0; i < t; ++i) {
                if (o === O(a, i)) {
                  var s = !0;break e;
                }
              }s = !1;
            }if (s) {
              t = {};var c = a ? a.split("*") : [];for (a = 0; a < c.length; a += 2) {
                t[c[a]] = _(c[a + 1]);
              }return t;
            }
          }
        }
      } catch (e) {}
    };function R(e, t, n) {
      function r(e) {
        var t = (e = k(e)).charAt(e.length - 1);return e && "&" !== t && (e += "&"), e + a;
      }n = void 0 !== n && n;var i = E.exec(t);if (!i) return "";t = i[1];var o = i[2] || "";i = i[3] || "";var a = "_gl=" + e;return n ? i = "#" + r(i.substring(1)) : o = "?" + r(o.substring(1)), "" + t + o + i;
    }function I(e, t, i) {
      for (var o = {}, a = {}, s = y().decorators, c = 0; c < s.length; ++c) {
        var l = s[c];(!i || l.forms) && w(l.domains, t) && (l.fragment ? n(a, l.callback()) : n(o, l.callback()));
      }r(o) && (t = C(o), i ? N(t, e) : x(t, e, !1)), !i && r(a) && x(i = C(a), e, !0);
    }function x(e, t, n) {
      t.href && (e = R(e, t.href, void 0 !== n && n), i.test(e) && (t.href = e));
    }function N(e, t) {
      if (t && t.action) {
        var n = (t.method || "").toLowerCase();if ("get" === n) {
          n = t.childNodes || [];for (var r = !1, o = 0; o < n.length; o++) {
            var s = n[o];if ("_gl" === s.name) {
              s.setAttribute("value", e), r = !0;break;
            }
          }r || ((n = a.createElement("input")).setAttribute("type", "hidden"), n.setAttribute("name", "_gl"), n.setAttribute("value", e), t.appendChild(n));
        } else "post" === n && (e = R(e, t.action), i.test(e) && (t.action = e));
      }
    }var L = function L(e) {
      try {
        e: {
          var t = e.target || e.srcElement || {};for (e = 100; t && 0 < e;) {
            if (t.href && t.nodeName.match(/^a(?:rea)?$/i)) {
              var n = t;break e;
            }t = t.parentNode, e--;
          }n = null;
        }if (n) {
          var r = n.protocol;"http:" !== r && "https:" !== r || I(n, n.hostname, !1);
        }
      } catch (e) {}
    },
        U = function U(e) {
      try {
        var t = e.target || e.srcElement || {};if (t.action) I(t, l(d(t.action), "host"), !0);
      } catch (e) {}
    };t("google_tag_data.glBridge.auto", function (e, t, n, r) {
      var i = y();i.init || (s("mousedown", L), s("keyup", L), s("submit", U), i.init = !0), e = { callback: e, domains: t, fragment: "fragment" === n, forms: !!r }, y().decorators.push(e);
    }), t("google_tag_data.glBridge.decorate", function (e, t, n) {
      if (n = !!n, e = C(e), t.tagName) {
        if ("a" == t.tagName.toLowerCase()) return x(e, t, n);if ("form" == t.tagName.toLowerCase()) return N(e, t);
      }if ("string" == typeof t) return R(e, t, n);
    }), t("google_tag_data.glBridge.generate", C), t("google_tag_data.glBridge.get", function (e, t) {
      var r = function (e) {
        return function (t) {
          var n = d(o.location.href),
              r = n.search.replace("?", "");e: {
            for (var i = r.split("&"), a = 0; a < i.length; a++) {
              var s = i[a].split("=");if ("_gl" === decodeURIComponent(s[0]).replace(/\+/g, " ")) {
                i = s.slice(1).join("=");break e;
              }
            }i = void 0;
          }t.query = A(i || "") || {}, a = (i = l(n, "fragment")).match(T), t.fragment = A(a && a[3] || "") || {}, e && S(n, r, i);
        };
      }(!!t);return (t = y()).data || (t.data = { query: {}, fragment: {} }, r(t.data)), r = {}, (t = t.data) && (n(r, t.query), e && n(r, t.fragment)), r;
    });
  }(window), function () {
    function e(e) {
      var t,
          n = 1;if (e) for (n = 0, t = e.length - 1; 0 <= t; t--) {
        var r = e.charCodeAt(t);n = 0 != (r = 266338304 & (n = (n << 6 & 268435455) + r + (r << 14))) ? n ^ r >> 21 : n;
      }return n;
    }var t = function t(e) {
      this.w = e || [];
    };t.prototype.set = function (e) {
      this.w[e] = !0;
    }, t.prototype.encode = function () {
      for (var e = [], t = 0; t < this.w.length; t++) {
        this.w[t] && (e[Math.floor(t / 6)] ^= 1 << t % 6);
      }for (t = 0; t < e.length; t++) {
        e[t] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(e[t] || 0);
      }return e.join("") + "~";
    };var n = new t();function r(e) {
      n.set(e);
    }var i = function i(e) {
      e = o(e), e = new t(e);for (var r = n.w.slice(), i = 0; i < e.w.length; i++) {
        r[i] = r[i] || e.w[i];
      }return new t(r).encode();
    },
        o = function o(e) {
      return e = e.get(Ut), s(e) || (e = []), e;
    },
        a = function a(e) {
      return "function" == typeof e;
    },
        s = function s(e) {
      return "[object Array]" == Object.prototype.toString.call(Object(e));
    },
        c = function c(e) {
      return void 0 != e && -1 < (e.constructor + "").indexOf("String");
    },
        l = function l(e, t) {
      return 0 == e.indexOf(t);
    },
        u = function u(e) {
      return e ? e.replace(/^[\s\xa0]+|[\s\xa0]+$/g, "") : "";
    },
        d = function d() {
      for (var t = I.navigator.userAgent + (x.cookie ? x.cookie : "") + (x.referrer ? x.referrer : ""), n = t.length, r = I.history.length; 0 < r;) {
        t += r-- ^ n++;
      }return [me() ^ 2147483647 & e(t), Math.round(new Date().getTime() / 1e3)].join(".");
    },
        h = function h(e) {
      var t = x.createElement("img");return t.width = 1, t.height = 1, t.src = e, t;
    },
        f = function f() {},
        g = function g(e) {
      return encodeURIComponent instanceof Function ? encodeURIComponent(e) : (r(28), e);
    },
        p = function p(e, t, n, i) {
      try {
        e.addEventListener ? e.addEventListener(t, n, !!i) : e.attachEvent && e.attachEvent("on" + t, n);
      } catch (e) {
        r(27);
      }
    },
        m = /^[\w\-:/.?=&%!\[\]]+$/,
        v = /^[\w+/_-]+[=]{0,2}$/,
        _ = function _(e, t, n) {
      if (e) {
        var r = x.querySelector && x.querySelector("script[nonce]") || null;if (r = r && (r.nonce || r.getAttribute && r.getAttribute("nonce")) || "", n) {
          var i = n = "";t && m.test(t) && (n = ' id="' + t + '"'), r && v.test(r) && (i = ' nonce="' + r + '"'), m.test(e) && x.write("<script" + n + i + ' src="' + e + '"><\/script>');
        } else (n = x.createElement("script")).type = "text/javascript", n.async = !0, n.src = e, t && (n.id = t), r && n.setAttribute("nonce", r), (e = x.getElementsByTagName("script")[0]).parentNode.insertBefore(n, e);
      }
    },
        w = function w(e, t) {
      return y(x.location[t ? "href" : "search"], e);
    },
        y = function y(e, t) {
      return (e = e.match("(?:&|#|\\?)" + g(t).replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1") + "=([^&#]*)")) && 2 == e.length ? e[1] : "";
    },
        b = function b() {
      var e = "" + x.location.hostname;return 0 == e.indexOf("www.") ? e.substring(4) : e;
    },
        E = function E(e, t) {
      var n = e.indexOf(t);return (5 == n || 6 == n) && ("/" == (e = e.charAt(n + t.length)) || "?" == e || "" == e || ":" == e);
    },
        T = function T(e, t) {
      if (1 == t.length && null != t[0] && "object" == _typeof(t[0])) return t[0];for (var n = {}, r = Math.min(e.length + 1, t.length), i = 0; i < r; i++) {
        if ("object" == _typeof(t[i])) {
          for (var o in t[i]) {
            t[i].hasOwnProperty(o) && (n[o] = t[i][o]);
          }break;
        }i < e.length && (n[e[i]] = t[i]);
      }return n;
    },
        C = function C() {
      this.keys = [], this.values = {}, this.m = {};
    };C.prototype.set = function (e, t, n) {
      this.keys.push(e), n ? this.m[":" + e] = t : this.values[":" + e] = t;
    }, C.prototype.get = function (e) {
      return this.m.hasOwnProperty(":" + e) ? this.m[":" + e] : this.values[":" + e];
    }, C.prototype.map = function (e) {
      for (var t = 0; t < this.keys.length; t++) {
        var n = this.keys[t],
            r = this.get(n);r && e(n, r);
      }
    };var O,
        k,
        S,
        A,
        R,
        I = window,
        x = document,
        N = function N(e, t) {
      return setTimeout(e, t);
    },
        L = window,
        U = document,
        P = function P(e) {
      var t = L._gaUserPrefs;if (t && t.ioo && t.ioo() || e && !0 === L["ga-disable-" + e]) return !0;try {
        var n = L.external;if (n && n._gaUserPrefs && "oo" == n._gaUserPrefs) return !0;
      } catch (e) {}for (e = [], t = String(U.cookie || document.cookie).split(";"), n = 0; n < t.length; n++) {
        var r = t[n].split("="),
            i = r[0].replace(/^\s*|\s*$/g, "");i && "AMP_TOKEN" == i && ((r = r.slice(1).join("=").replace(/^\s*|\s*$/g, "")) && (r = decodeURIComponent(r)), e.push(r));
      }for (t = 0; t < e.length; t++) {
        if ("$OPT_OUT" == e[t]) return !0;
      }return !1;
    },
        D = function D(e) {
      var t = [],
          n = x.cookie.split(";");e = new RegExp("^\\s*" + e + "=\\s*(.*?)\\s*$");for (var r = 0; r < n.length; r++) {
        var i = n[r].match(e);i && t.push(i[1]);
      }return t;
    },
        j = function j(e, t, n, r, i, o) {
      if (!(i = !P(i) && !(F.test(x.location.hostname) || "/" == n && H.test(r)))) return !1;if (t && 1200 < t.length && (t = t.substring(0, 1200)), n = e + "=" + t + "; path=" + n + "; ", o && (n += "expires=" + new Date(new Date().getTime() + o).toGMTString() + "; "), r && "none" !== r && (n += "domain=" + r + ";"), r = x.cookie, x.cookie = n, !(r = r != x.cookie)) e: {
        for (e = D(e), r = 0; r < e.length; r++) {
          if (t == e[r]) {
            r = !0;break e;
          }
        }r = !1;
      }return r;
    },
        M = function M(e) {
      return encodeURIComponent ? encodeURIComponent(e).replace(/\(/g, "%28").replace(/\)/g, "%29") : e;
    },
        H = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
        F = /(^|\.)doubleclick\.net$/i,
        V = /^.*Version\/?(\d+)[^\d].*$/i,
        W = function W() {
      if (void 0 !== I.__ga4__) return I.__ga4__;if (void 0 === O) {
        var e = I.navigator.userAgent;if (e) {
          var t = e;try {
            t = decodeURIComponent(e);
          } catch (e) {}(e = !(0 <= t.indexOf("Chrome") || 0 <= t.indexOf("CriOS") || !(0 <= t.indexOf("Safari/") || 0 <= t.indexOf("Safari,")))) && (e = 11 <= ((t = V.exec(t)) ? Number(t[1]) : -1)), O = e;
        } else O = !1;
      }return O;
    },
        B = /^https?:\/\/[^/]*cdn\.ampproject\.org\//,
        q = /^(?:www\.|m\.|amp\.)+/,
        $ = [],
        G = function G() {
      $r.D([f]);
    },
        K = function K(e, t) {
      var n = D("AMP_TOKEN");return 1 < n.length ? (r(55), !1) : "$OPT_OUT" == (n = decodeURIComponent(n[0] || "")) || "$ERROR" == n || P(t) ? (r(62), !1) : B.test(x.referrer) || "$NOT_FOUND" != n ? void 0 !== R ? (r(56), N(function () {
        e(R);
      }, 0), !0) : k ? ($.push(e), !0) : "$RETRIEVING" == n ? (r(57), N(function () {
        K(e, t);
      }, 1e4), !0) : (k = !0, n && "$" != n[0] || (X("$RETRIEVING", 3e4), setTimeout(J, 3e4), n = ""), !!z(n, t) && ($.push(e), !0)) : (r(68), !1);
    },
        z = function z(e, t, n) {
      if (!window.JSON) return r(58), !1;var i = I.XMLHttpRequest;if (!i) return r(59), !1;var o = new i();return "withCredentials" in o ? (o.open("POST", (n || "https://ampcid.google.com/v1/publisher:getClientId") + "?key=AIzaSyA65lEHUEizIsNtlbNo-l2K18dT680nsaM", !0), o.withCredentials = !0, o.setRequestHeader("Content-Type", "text/plain"), o.onload = function () {
        if (k = !1, 4 == o.readyState) {
          try {
            200 != o.status && (r(61), Q("", "$ERROR", 3e4));var i = JSON.parse(o.responseText);i.optOut ? (r(63), Q("", "$OPT_OUT", 31536e6)) : i.clientId ? Q(i.clientId, i.securityToken, 31536e6) : !n && i.alternateUrl ? (S && clearTimeout(S), k = !0, z(e, t, i.alternateUrl)) : (r(64), Q("", "$NOT_FOUND", 36e5));
          } catch (e) {
            r(65), Q("", "$ERROR", 3e4);
          }o = null;
        }
      }, i = { originScope: "AMP_ECID_GOOGLE" }, e && (i.securityToken = e), o.send(JSON.stringify(i)), S = N(function () {
        r(66), Q("", "$ERROR", 3e4);
      }, 1e4), !0) : (r(60), !1);
    },
        J = function J() {
      k = !1;
    },
        X = function X(e, t) {
      if (void 0 === A) {
        A = "";for (var n = Gn(), r = 0; r < n.length; r++) {
          var i = n[r];if (j("AMP_TOKEN", encodeURIComponent(e), "/", i, "", t)) return void (A = i);
        }
      }j("AMP_TOKEN", encodeURIComponent(e), "/", A, "", t);
    },
        Q = function Q(e, t, n) {
      for (S && clearTimeout(S), t && X(t, n), R = e, t = $, $ = [], n = 0; n < t.length; n++) {
        t[n](e);
      }
    },
        Z = function Z() {
      return (Ue || "https:" == x.location.protocol ? "https:" : "http:") + "//www.google-analytics.com";
    },
        Y = function Y(e, t, n) {
      if (n = n || f, 2036 >= t.length) te(e, t, n);else {
        if (!(8192 >= t.length)) throw ie("len", t.length), new function (e) {
          this.name = "len", this.message = e + "-8192";
        }(t.length);re(e, t, n) || ne(e, t, n) || te(e, t, n);
      }
    },
        ee = function ee(e, t, n, r) {
      ne(e + "?" + t, "", r = r || f, n);
    },
        te = function te(e, t, n) {
      var r = h(e + "?" + t);r.onload = r.onerror = function () {
        r.onload = null, r.onerror = null, n();
      };
    },
        ne = function ne(e, t, n, r) {
      var i = I.XMLHttpRequest;if (!i) return !1;var o = new i();return "withCredentials" in o && (e = e.replace(/^http:/, "https:"), o.open("POST", e, !0), o.withCredentials = !0, o.setRequestHeader("Content-Type", "text/plain"), o.onreadystatechange = function () {
        if (4 == o.readyState) {
          if (r) try {
            var e = o.responseText;if (1 > e.length) ie("xhr", "ver", "0"), n();else if ("1" != e.charAt(0)) ie("xhr", "ver", String(e.length)), n();else if (3 < r.count++) ie("xhr", "tmr", "" + r.count), n();else if (1 == e.length) n();else {
              var t = e.charAt(1);if ("d" == t) ee("https://stats.g.doubleclick.net/j/collect", r.U, r, n);else if ("g" == t) {
                var i = "https://www.google.%/ads/ga-audiences".replace("%", "com");te(i, r.google, n);var a = e.substring(2);if (a) if (/^[a-z.]{1,6}$/.test(a)) {
                  var s = "https://www.google.%/ads/ga-audiences".replace("%", a);te(s, r.google, f);
                } else ie("tld", "bcc", a);
              } else ie("xhr", "brc", t), n();
            }
          } catch (e) {
            ie("xhr", "rsp"), n();
          } else n();o = null;
        }
      }, o.send(t), !0);
    },
        re = function re(e, t, n) {
      return !!I.navigator.sendBeacon && !!I.navigator.sendBeacon(e, t) && (n(), !0);
    },
        ie = function ie(e, t, n) {
      1 <= 100 * Math.random() || P("?") || (e = ["t=error", "_e=" + e, "_v=j73", "sr=1"], t && e.push("_f=" + t), n && e.push("_m=" + g(n.substring(0, 100))), e.push("aip=1"), e.push("z=" + me()), te("https://www.google-analytics.com/u/d", e.join("&"), f));
    },
        oe = function oe(e) {
      var t = I.gaData = I.gaData || {};return t[e] = t[e] || {};
    },
        ae = function ae() {
      this.M = [];
    };function se(t) {
      if (100 != t.get(pn) && e(Ee(t, Yt)) % 1e4 >= 100 * Te(t, pn)) throw "abort";
    }function ce(e) {
      if (P(Ee(e, rn))) throw "abort";
    }function le() {
      var e = x.location.protocol;if ("http:" != e && "https:" != e) throw "abort";
    }function ue(e) {
      try {
        I.navigator.sendBeacon ? r(42) : I.XMLHttpRequest && "withCredentials" in new I.XMLHttpRequest() && r(40);
      } catch (e) {}e.set(Lt, i(e), !0), e.set(Be, Te(e, Be) + 1);var t = [];ye.map(function (n, r) {
        r.F && void 0 != (n = e.get(n)) && n != r.defaultValue && ("boolean" == typeof n && (n *= 1), t.push(r.F + "=" + g("" + n)));
      }), t.push("z=" + ve()), e.set(Fe, t.join("&"), !0);
    }function de(e) {
      var t = Ee(e, kn) || Z() + "/collect",
          n = e.get(An),
          r = Ee(e, We);if (!r && e.get(Ve) && (r = "beacon"), n) ee(t, Ee(e, Fe), n, e.get(He));else if (r) {
        n = r, r = Ee(e, Fe);var i = e.get(He);i = i || f, "image" == n ? te(t, r, i) : "xhr" == n && ne(t, r, i) || "beacon" == n && re(t, r, i) || Y(t, r, i);
      } else Y(t, Ee(e, Fe), e.get(He));t = e.get(rn), n = (t = oe(t)).hitcount, t.hitcount = n ? n + 1 : 1, t = e.get(rn), delete oe(t).pending_experiments, e.set(He, f, !0);
    }function he(e) {
      (I.gaData = I.gaData || {}).expId && e.set(Tt, (I.gaData = I.gaData || {}).expId), (I.gaData = I.gaData || {}).expVar && e.set(Ct, (I.gaData = I.gaData || {}).expVar);var t = e.get(rn);if (t = oe(t).pending_experiments) {
        var n = [];for (r in t) {
          t.hasOwnProperty(r) && t[r] && n.push(encodeURIComponent(r) + "." + encodeURIComponent(t[r]));
        }var r = n.join("!");
      } else r = void 0;r && e.set(Ot, r, !0);
    }function fe() {
      if (I.navigator && "preview" == I.navigator.loadPurpose) throw "abort";
    }function ge(e) {
      var t = I.gaDevIds;s(t) && 0 != t.length && e.set("&did", t.join(","), !0);
    }function pe(e) {
      if (!e.get(rn)) throw "abort";
    }ae.prototype.add = function (e) {
      this.M.push(e);
    }, ae.prototype.D = function (e) {
      try {
        for (var t = 0; t < this.M.length; t++) {
          var n = e.get(this.M[t]);n && a(n) && n.call(I, e);
        }
      } catch (e) {}(t = e.get(He)) != f && a(t) && (e.set(He, f, !0), setTimeout(t, 10));
    };var me = function me() {
      return Math.round(2147483647 * Math.random());
    },
        ve = function ve() {
      try {
        var e = new Uint32Array(1);return I.crypto.getRandomValues(e), 2147483647 & e[0];
      } catch (e) {
        return me();
      }
    };function _e(e) {
      var t = Te(e, Rt);500 <= t && r(15);var n = Ee(e, Me);if ("transaction" != n && "item" != n) {
        n = Te(e, xt);var i = new Date().getTime(),
            o = Te(e, It);if (0 == o && e.set(It, i), 0 < (o = Math.round(2 * (i - o) / 1e3)) && (n = Math.min(n + o, 20), e.set(It, i)), 0 >= n) throw "abort";e.set(xt, --n);
      }e.set(Rt, ++t);
    }var we = function we() {
      this.data = new C();
    },
        ye = new C(),
        be = [];we.prototype.get = function (e) {
      var t = ke(e),
          n = this.data.get(e);return t && void 0 == n && (n = a(t.defaultValue) ? t.defaultValue() : t.defaultValue), t && t.Z ? t.Z(this, e, n) : n;
    };var Ee = function Ee(e, t) {
      return void 0 == (e = e.get(t)) ? "" : "" + e;
    },
        Te = function Te(e, t) {
      return void 0 == (e = e.get(t)) || "" === e ? 0 : 1 * e;
    };we.prototype.set = function (e, t, n) {
      if (e) if ("object" == (typeof e === "undefined" ? "undefined" : _typeof(e))) for (var r in e) {
        e.hasOwnProperty(r) && Ce(this, r, e[r], n);
      } else Ce(this, e, t, n);
    };var Ce = function Ce(e, t, n, r) {
      if (void 0 != n) switch (t) {case rn:
          Or.test(n);}var i = ke(t);i && i.o ? i.o(e, t, n, r) : e.data.set(t, n, r);
    },
        Oe = function Oe(e, t, n, r, i) {
      this.name = e, this.F = t, this.Z = r, this.o = i, this.defaultValue = n;
    },
        ke = function ke(e) {
      var t = ye.get(e);if (!t) for (var n = 0; n < be.length; n++) {
        var r = be[n],
            i = r[0].exec(e);if (i) {
          t = r[1](i), ye.set(t.name, t);break;
        }
      }return t;
    },
        Se = function Se(e, t, n, r, i) {
      return e = new Oe(e, t, n, r, i), ye.set(e.name, e), e.name;
    },
        Ae = function Ae(e, t) {
      be.push([new RegExp("^" + e + "$"), t]);
    },
        Re = function Re(e, t, n) {
      return Se(e, t, n, void 0, Ie);
    },
        Ie = function Ie() {},
        xe = c(window.GoogleAnalyticsObject) && u(window.GoogleAnalyticsObject) || "ga",
        Ne = /^(?:utma\.)?\d+\.\d+$/,
        Le = /^amp-[\w.-]{22,64}$/,
        Ue = !1,
        Pe = Re("apiVersion", "v"),
        De = Re("clientVersion", "_v");Se("anonymizeIp", "aip");var je = Se("adSenseId", "a"),
        Me = Se("hitType", "t"),
        He = Se("hitCallback"),
        Fe = Se("hitPayload");Se("nonInteraction", "ni"), Se("currencyCode", "cu"), Se("dataSource", "ds");var Ve = Se("useBeacon", void 0, !1),
        We = Se("transport");Se("sessionControl", "sc", ""), Se("sessionGroup", "sg"), Se("queueTime", "qt");var Be = Se("_s", "_s");Se("screenName", "cd");var qe = Se("location", "dl", ""),
        $e = Se("referrer", "dr"),
        Ge = Se("page", "dp", "");Se("hostname", "dh");var Ke = Se("language", "ul"),
        ze = Se("encoding", "de");Se("title", "dt", function () {
      return x.title || void 0;
    }), Ae("contentGroup([0-9]+)", function (e) {
      return new Oe(e[0], "cg" + e[1]);
    });var Je = Se("screenColors", "sd"),
        Xe = Se("screenResolution", "sr"),
        Qe = Se("viewportSize", "vp"),
        Ze = Se("javaEnabled", "je"),
        Ye = Se("flashVersion", "fl");Se("campaignId", "ci"), Se("campaignName", "cn"), Se("campaignSource", "cs"), Se("campaignMedium", "cm"), Se("campaignKeyword", "ck"), Se("campaignContent", "cc");var et = Se("eventCategory", "ec"),
        tt = Se("eventAction", "ea"),
        nt = Se("eventLabel", "el"),
        rt = Se("eventValue", "ev"),
        it = Se("socialNetwork", "sn"),
        ot = Se("socialAction", "sa"),
        at = Se("socialTarget", "st"),
        st = Se("l1", "plt"),
        ct = Se("l2", "pdt"),
        lt = Se("l3", "dns"),
        ut = Se("l4", "rrt"),
        dt = Se("l5", "srt"),
        ht = Se("l6", "tcp"),
        ft = Se("l7", "dit"),
        gt = Se("l8", "clt"),
        pt = Se("l9", "_gst"),
        mt = Se("l10", "_gbt"),
        vt = Se("l11", "_cst"),
        _t = Se("l12", "_cbt"),
        wt = Se("timingCategory", "utc"),
        yt = Se("timingVar", "utv"),
        bt = Se("timingLabel", "utl"),
        Et = Se("timingValue", "utt");Se("appName", "an"), Se("appVersion", "av", ""), Se("appId", "aid", ""), Se("appInstallerId", "aiid", ""), Se("exDescription", "exd"), Se("exFatal", "exf");var Tt = Se("expId", "xid"),
        Ct = Se("expVar", "xvar"),
        Ot = Se("exp", "exp"),
        kt = Se("_utma", "_utma"),
        St = Se("_utmz", "_utmz"),
        At = Se("_utmht", "_utmht"),
        Rt = Se("_hc", void 0, 0),
        It = Se("_ti", void 0, 0),
        xt = Se("_to", void 0, 20);Ae("dimension([0-9]+)", function (e) {
      return new Oe(e[0], "cd" + e[1]);
    }), Ae("metric([0-9]+)", function (e) {
      return new Oe(e[0], "cm" + e[1]);
    }), Se("linkerParam", void 0, void 0, function (e) {
      if (e.get(Nt)) return r(35), Yn.generate(lr(e));var t = e.get(Yt),
          n = e.get(_n) || "";return t = "_ga=2." + g(rr(n + t, 0) + "." + n + "-" + t), (e = ur(e)) ? (r(44), e = "&_gac=1." + g([rr(e.qa, 0), e.timestamp, e.qa].join("."))) : e = "", t + e;
    }, Ie);var Nt = Re("_cd2l", void 0, !1),
        Lt = Se("usage", "_u"),
        Ut = Se("_um");Se("forceSSL", void 0, void 0, function () {
      return Ue;
    }, function (e, t, n) {
      r(34), Ue = !!n;
    });var Pt = Se("_j1", "jid"),
        Dt = Se("_j2", "gjid");Ae("\\&(.*)", function (e) {
      var t = new Oe(e[0], e[1]),
          n = function (e) {
        var t;return ye.map(function (n, r) {
          r.F == e && (t = r);
        }), t && t.name;
      }(e[0].substring(1));return n && (t.Z = function (e) {
        return e.get(n);
      }, t.o = function (e, t, r, i) {
        e.set(n, r, i);
      }, t.F = void 0), t;
    });var jt = Re("_oot"),
        Mt = Se("previewTask"),
        Ht = Se("checkProtocolTask"),
        Ft = Se("validationTask"),
        Vt = Se("checkStorageTask"),
        Wt = Se("historyImportTask"),
        Bt = Se("samplerTask"),
        qt = Se("_rlt"),
        $t = Se("buildHitTask"),
        Gt = Se("sendHitTask"),
        Kt = Se("ceTask"),
        zt = Se("devIdTask"),
        Jt = Se("timingTask"),
        Xt = Se("displayFeaturesTask"),
        Qt = Se("customTask"),
        Zt = Re("name"),
        Yt = Re("clientId", "cid"),
        en = Re("clientIdTime"),
        tn = Re("storedClientId"),
        nn = Se("userId", "uid"),
        rn = Re("trackingId", "tid"),
        on = Re("cookieName", void 0, "_ga"),
        an = Re("cookieDomain"),
        sn = Re("cookiePath", void 0, "/"),
        cn = Re("cookieExpires", void 0, 63072e3),
        ln = Re("cookieUpdate", void 0, !0),
        un = Re("legacyCookieDomain"),
        dn = Re("legacyHistoryImport", void 0, !0),
        hn = Re("storage", void 0, "cookie"),
        fn = Re("allowLinker", void 0, !1),
        gn = Re("allowAnchor", void 0, !0),
        pn = Re("sampleRate", "sf", 100),
        mn = Re("siteSpeedSampleRate", void 0, 1),
        vn = Re("alwaysSendReferrer", void 0, !1),
        _n = Re("_gid", "_gid"),
        wn = Re("_gcn"),
        yn = Re("useAmpClientId"),
        bn = Re("_gclid"),
        En = Re("_gt"),
        Tn = Re("_ge", void 0, 7776e6),
        Cn = Re("_gclsrc"),
        On = Re("storeGac", void 0, !0),
        kn = Se("transportUrl"),
        Sn = Se("_r", "_r"),
        An = Se("_dp"),
        Rn = Se("allowAdFeatures", void 0, !0);function In(e, t, n, i) {
      t[e] = function () {
        try {
          return i && r(i), n.apply(this, arguments);
        } catch (t) {
          throw ie("exc", e, t && t.name), t;
        }
      };
    }var xn = function xn(e) {
      var t = {};if (Nn(t) || Ln(t)) {
        var n = t[st];void 0 == n || 1 / 0 == n || isNaN(n) || (0 < n ? (Un(t, lt), Un(t, ht), Un(t, dt), Un(t, ct), Un(t, ut), Un(t, ft), Un(t, gt), Un(t, pt), Un(t, mt), Un(t, vt), Un(t, _t), N(function () {
          e(t);
        }, 10)) : p(I, "load", function () {
          xn(e);
        }, !1));
      }
    },
        Nn = function Nn(e) {
      var t = I.performance || I.webkitPerformance;if (!(t = t && t.timing)) return !1;var n = t.navigationStart;return 0 != n && (e[st] = t.loadEventStart - n, e[lt] = t.domainLookupEnd - t.domainLookupStart, e[ht] = t.connectEnd - t.connectStart, e[dt] = t.responseStart - t.requestStart, e[ct] = t.responseEnd - t.responseStart, e[ut] = t.fetchStart - n, e[ft] = t.domInteractive - n, e[gt] = t.domContentLoadedEventStart - n, e[pt] = Gr.L - n, e[mt] = Gr.ya - n, I.google_tag_manager && I.google_tag_manager._li && (t = I.google_tag_manager._li, e[vt] = t.cst, e[_t] = t.cbt), !0);
    },
        Ln = function Ln(e) {
      if (I.top != I) return !1;var t = I.external,
          n = t && t.onloadT;return t && !t.isValidLoadTime && (n = void 0), 2147483648 < n && (n = void 0), 0 < n && t.setPageReadyTime(), void 0 != n && (e[st] = n, !0);
    },
        Un = function Un(e, t) {
      var n = e[t];(isNaN(n) || 1 / 0 == n || 0 > n) && (e[t] = void 0);
    },
        Pn = function Pn(t) {
      return function (n) {
        if ("pageview" == n.get(Me) && !t.I) {
          t.I = !0;var r = function (t) {
            var n = Math.min(Te(t, mn), 100);return !(e(Ee(t, Yt)) % 100 >= n);
          }(n),
              i = 0 < y(n.get(qe), "gclid").length;(r || i) && xn(function (e) {
            r && t.send("timing", e), i && t.send("adtiming", e);
          });
        }
      };
    },
        Dn = !1,
        jn = function jn(e) {
      if ("cookie" == Ee(e, hn)) {
        if (e.get(ln) || Ee(e, tn) != Ee(e, Yt)) {
          var t = 1e3 * Te(e, cn);Mn(e, Yt, on, t);
        }if (Mn(e, _n, wn, 864e5), e.get(On)) {
          var n = e.get(bn);if (n) {
            var i = Math.min(Te(e, Tn), 1e3 * Te(e, cn));i = Math.min(i, 1e3 * Te(e, En) + i - new Date().getTime()), e.data.set(Tn, i), t = {};var o = e.get(En),
                a = e.get(Cn),
                s = Kn(Ee(e, sn)),
                c = $n(Ee(e, an));e = Ee(e, rn), a && "aw.ds" != a ? t && (t.ua = !0) : (n = ["1", o, M(n)].join("."), 0 < i && (t && (t.ta = !0), j("_gac_" + M(e), n, s, c, e, i))), Jn(t);
          }
        } else r(75);
      }
    },
        Mn = function Mn(e, t, n, i) {
      var o = Vn(e, t);if (o) {
        n = Ee(e, n);var a = Kn(Ee(e, sn)),
            s = $n(Ee(e, an)),
            c = Ee(e, rn);if ("auto" != s) j(n, o, a, s, c, i) && (Dn = !0);else {
          r(32);for (var l = Gn(), u = 0; u < l.length; u++) {
            if (s = l[u], e.data.set(an, s), o = Vn(e, t), j(n, o, a, s, c, i)) return void (Dn = !0);
          }e.data.set(an, "auto");
        }
      }
    },
        Hn = function Hn(e) {
      if ("cookie" == Ee(e, hn) && !Dn && (jn(e), !Dn)) throw "abort";
    },
        Fn = function Fn(e) {
      if (e.get(dn)) {
        var t = Ee(e, an),
            n = Ee(e, un) || b(),
            i = Xn("__utma", n, t);i && (r(19), e.set(At, new Date().getTime(), !0), e.set(kt, i.R), (t = Xn("__utmz", n, t)) && i.hash == t.hash && e.set(St, t.R));
      }
    },
        Vn = function Vn(e, t) {
      t = M(Ee(e, t));var n = $n(Ee(e, an)).split(".").length;return 1 < (e = zn(Ee(e, sn))) && (n += "-" + e), t ? ["GA1", n, t].join(".") : "";
    },
        Wn = function Wn(e, t) {
      return Bn(t, Ee(e, an), Ee(e, sn));
    },
        Bn = function Bn(e, t, n) {
      if (!e || 1 > e.length) r(12);else {
        for (var i = [], o = 0; o < e.length; o++) {
          var a = e[o],
              s = a.split("."),
              c = s.shift();("GA1" == c || "1" == c) && 1 < s.length ? (1 == (a = s.shift().split("-")).length && (a[1] = "1"), a[0] *= 1, a[1] *= 1, s = { H: a, s: s.join(".") }) : s = Le.test(a) ? { H: [0, 0], s: a } : void 0, s && i.push(s);
        }if (1 == i.length) return r(13), i[0].s;if (0 != i.length) return r(14), 1 == (i = qn(i, $n(t).split(".").length, 0)).length ? i[0].s : (1 < (i = qn(i, zn(n), 1)).length && r(41), i[0] && i[0].s);r(12);
      }
    },
        qn = function qn(e, t, n) {
      for (var r, i = [], o = [], a = 0; a < e.length; a++) {
        var s = e[a];s.H[n] == t ? i.push(s) : void 0 == r || s.H[n] < r ? (o = [s], r = s.H[n]) : s.H[n] == r && o.push(s);
      }return 0 < i.length ? i : o;
    },
        $n = function $n(e) {
      return 0 == e.indexOf(".") ? e.substr(1) : e;
    },
        Gn = function Gn() {
      var e = [],
          t = b().split(".");if (4 == t.length) {
        var n = t[t.length - 1];if (parseInt(n, 10) == n) return ["none"];
      }for (n = t.length - 2; 0 <= n; n--) {
        e.push(t.slice(n).join("."));
      }return t = x.location.hostname, F.test(t) || H.test(t) || e.push("none"), e;
    },
        Kn = function Kn(e) {
      return e ? (1 < e.length && e.lastIndexOf("/") == e.length - 1 && (e = e.substr(0, e.length - 1)), 0 != e.indexOf("/") && (e = "/" + e), e) : "/";
    },
        zn = function zn(e) {
      return "/" == (e = Kn(e)) ? 1 : e.split("/").length;
    },
        Jn = function Jn(e) {
      e.ta && r(77), e.na && r(74), e.pa && r(73), e.ua && r(69);
    };function Xn(e, t, n) {
      "none" == t && (t = "");var r = [],
          i = D(e);e = "__utma" == e ? 6 : 2;for (var o = 0; o < i.length; o++) {
        var a = ("" + i[o]).split(".");a.length >= e && r.push({ hash: a[0], R: i[o], O: a });
      }if (0 != r.length) return 1 == r.length ? r[0] : Qn(t, r) || Qn(n, r) || Qn(null, r) || r[0];
    }function Qn(t, n) {
      if (null == t) var r = t = 1;else r = e(t), t = e(l(t, ".") ? t.substring(1) : "." + t);for (var i = 0; i < n.length; i++) {
        if (n[i].hash == r || n[i].hash == t) return n[i];
      }
    }var Zn = new RegExp(/^https?:\/\/([^\/:]+)/),
        Yn = I.google_tag_data.glBridge,
        er = /(.*)([?&#])(?:_ga=[^&#]*)(?:&?)(.*)/,
        tr = /(.*)([?&#])(?:_gac=[^&#]*)(?:&?)(.*)/;function nr(t, n) {
      var r = new Date(),
          i = I.navigator,
          o = i.plugins || [];for (t = [t, i.userAgent, r.getTimezoneOffset(), r.getYear(), r.getDate(), r.getHours(), r.getMinutes() + n], n = 0; n < o.length; ++n) {
        t.push(o[n].description);
      }return e(t.join("."));
    }function rr(t, n) {
      var r = new Date(),
          i = I.navigator,
          o = r.getHours() + Math.floor((r.getMinutes() + n) / 60);return e([t, i.userAgent, i.language || "", r.getTimezoneOffset(), r.getYear(), r.getDate() + Math.floor(o / 24), (24 + o) % 24, (60 + r.getMinutes() + n) % 60].join("."));
    }var ir = function ir(e) {
      r(48), this.target = e, this.T = !1;
    };ir.prototype.ca = function (e, t) {
      if (e) {
        if (this.target.get(Nt)) return Yn.decorate(lr(this.target), e, t);if (e.tagName) {
          if ("a" == e.tagName.toLowerCase()) return void (e.href && (e.href = or(this, e.href, t)));if ("form" == e.tagName.toLowerCase()) return ar(this, e);
        }if ("string" == typeof e) return or(this, e, t);
      }
    };var or = function or(e, t, n) {
      var r = er.exec(t);r && 3 <= r.length && (t = r[1] + (r[3] ? r[2] + r[3] : "")), (r = tr.exec(t)) && 3 <= r.length && (t = r[1] + (r[3] ? r[2] + r[3] : "")), e = e.target.get("linkerParam");var i = t.indexOf("?");return r = t.indexOf("#"), n ? t += (-1 == r ? "#" : "&") + e : (n = -1 == i ? "?" : "&", t = -1 == r ? t + (n + e) : t.substring(0, r) + n + e + t.substring(r)), (t = t.replace(/&+_ga=/, "&_ga=")).replace(/&+_gac=/, "&_gac=");
    },
        ar = function ar(e, t) {
      if (t && t.action) if ("get" == t.method.toLowerCase()) {
        e = e.target.get("linkerParam").split("&");for (var n = 0; n < e.length; n++) {
          var r = e[n].split("="),
              i = r[1];r = r[0];for (var o = t.childNodes || [], a = !1, s = 0; s < o.length; s++) {
            if (o[s].name == r) {
              o[s].setAttribute("value", i), a = !0;break;
            }
          }a || ((o = x.createElement("input")).setAttribute("type", "hidden"), o.setAttribute("name", r), o.setAttribute("value", i), t.appendChild(o));
        }
      } else "post" == t.method.toLowerCase() && (t.action = or(e, t.action));
    };function sr(e, t) {
      if (t == x.location.hostname) return !1;for (var n = 0; n < e.length; n++) {
        if (e[n] instanceof RegExp) {
          if (e[n].test(t)) return !0;
        } else if (0 <= t.indexOf(e[n])) return !0;
      }return !1;
    }function cr(e, t) {
      return t != nr(e, 0) && t != nr(e, -1) && t != nr(e, -2) && t != rr(e, 0) && t != rr(e, -1) && t != rr(e, -2);
    }function lr(e) {
      var t = ur(e);return { _ga: e.get(Yt), _gid: e.get(_n) || void 0, _gac: t ? [t.qa, t.timestamp].join(".") : void 0 };
    }function ur(e) {
      function t(e) {
        return void 0 == e || "" === e ? 0 : Number(e);
      }var n = e.get(bn);if (n && e.get(On)) {
        var i = t(e.get(En));if (!(1e3 * i + t(e.get(Tn)) <= new Date().getTime())) return { timestamp: i, qa: n };r(76);
      }
    }ir.prototype.S = function (e, t, n) {
      function i(n) {
        try {
          n = n || I.event;e: {
            var i = n.target || n.srcElement;for (n = 100; i && 0 < n;) {
              if (i.href && i.nodeName.match(/^a(?:rea)?$/i)) {
                var a = i;break e;
              }i = i.parentNode, n--;
            }a = {};
          }("http:" == a.protocol || "https:" == a.protocol) && sr(e, a.hostname || "") && a.href && (a.href = or(o, a.href, t));
        } catch (e) {
          r(26);
        }
      }var o = this;this.target.get(Nt) ? Yn.auto(function () {
        return lr(o.target);
      }, e, t ? "fragment" : "", n) : (this.T || (this.T = !0, p(x, "mousedown", i, !1), p(x, "keyup", i, !1)), n && p(x, "submit", function (t) {
        if ((t = (t = t || I.event).target || t.srcElement) && t.action) {
          var n = t.action.match(Zn);n && sr(e, n[1]) && ar(o, t);
        }
      }));
    };var dr,
        hr = /^(GTM|OPT)-[A-Z0-9]+$/,
        fr = /;_gaexp=[^;]*/g,
        gr = /;((__utma=)|([^;=]+=GAX?\d+\.))[^;]*/g,
        pr = /^https?:\/\/[\w\-.]+\.google.com(:\d+)?\/optimize\/opt-launch\.html\?.*$/,
        mr = function mr(e, t, n) {
      this.aa = t, (t = n) || (t = (t = Ee(e, Zt)) && "t0" != t ? Er.test(t) ? "_gat_" + M(Ee(e, rn)) : "_gat_" + M(t) : "_gat"), this.Y = t, this.ra = null;
    },
        vr = function vr(e, t, n) {
      !1 === t.get(Rn) || t.get(n) || ("1" == D(e.Y)[0] ? t.set(n, "", !0) : t.set(n, "" + me(), !0));
    },
        _r = function _r(e, t) {
      wr(t) && j(e.Y, "1", t.get(sn), t.get(an), t.get(rn), 6e4);
    },
        wr = function wr(e) {
      return !!e.get(Pt) && e.get(Rn);
    },
        yr = function yr(e, t, n) {
      var r = new C(),
          o = function o(e) {
        ke(e).F && r.set(ke(e).F, t.get(e));
      };o(Pe), o(De), o(rn), o(Yt), o(Pt), 0 != n && 1 != n || (o(nn), o(Dt), o(_n)), r.set(ke(Lt).F, i(t));var a = "";return r.map(function (e, t) {
        a += g(e) + "=", a += g("" + t) + "&";
      }), a += "z=" + me(), 0 == n ? a = e.aa + a : 1 == n ? a = "t=dc&aip=1&_r=3&" + a : 2 == n && (a = "t=sr&aip=1&_r=4&slf_rd=1&" + a), a;
    },
        br = function br(e, t) {
      return null === e.ra && (e.ra = 1 === function (e) {
        var t,
            n = new function () {
          this.V = 100, this.$ = this.fa = !1, this.oa = "detourexp", this.groups = 1;
        }();if (n.fa && n.$) return 0;if (n.$ = !0, e) {
          if (n.oa && void 0 !== e.get(n.oa)) return Te(e, n.oa);if (0 == e.get(mn)) return 0;
        }return 0 == n.V ? 0 : (void 0 === t && (t = ve()), 0 == t % n.V ? Math.floor(t / n.V) % n.groups + 1 : 0);
      }(t), e.ra && r(33)), e.ra;
    },
        Er = /^gtm\d+$/,
        Tr = function Tr(e, n) {
      if (!(e = e.b).get("dcLoaded")) {
        var i,
            a = new t(o(e));a.set(29), e.set(Ut, a.w), (n = n || {})[on] && (i = M(n[on])), function (e, t) {
          var n = t.get($t);t.set($t, function (t) {
            vr(e, t, Pt), vr(e, t, Dt);var r = n(t);return _r(e, t), r;
          });var i = t.get(Gt);t.set(Gt, function (t) {
            var n = i(t);if (wr(t)) {
              if (W() !== br(e, t)) {
                r(80);var o = { U: yr(e, t, 1), google: yr(e, t, 2), count: 0 };ee("https://stats.g.doubleclick.net/j/collect", o.U, o);
              } else h(yr(e, t, 0));t.set(Pt, "", !0);
            }return n;
          });
        }(n = new mr(e, "https://stats.g.doubleclick.net/r/collect?t=dc&aip=1&_r=3&", i), e), e.set("dcLoaded", !0);
      }
    },
        Cr = function Cr(e) {
      if (!e.get("dcLoaded") && "cookie" == e.get(hn)) {
        var t = new mr(e);if (vr(t, e, Pt), vr(t, e, Dt), _r(t, e), wr(e)) {
          var n = W() !== br(t, e);e.set(Sn, 1, !0), n ? (r(79), e.set(kn, Z() + "/j/collect", !0), e.set(An, { U: yr(t, e, 1), google: yr(t, e, 2), count: 0 }, !0)) : e.set(kn, Z() + "/r/collect", !0);
        }
      }
    },
        Or = /^(UA|YT|MO|GP)-(\d+)-(\d+)$/,
        kr = function kr(e) {
      function t(e, t) {
        r.b.data.set(e, t);
      }function n(e, n) {
        t(e, n), r.filters.add(e);
      }var r = this;this.b = new we(), this.filters = new ae(), t(Zt, e[Zt]), t(rn, u(e[rn])), t(on, e[on]), t(an, e[an] || b()), t(sn, e[sn]), t(cn, e[cn]), t(ln, e[ln]), t(un, e[un]), t(dn, e[dn]), t(fn, e[fn]), t(gn, e[gn]), t(pn, e[pn]), t(mn, e[mn]), t(vn, e[vn]), t(hn, e[hn]), t(nn, e[nn]), t(en, e[en]), t(yn, e[yn]), t(On, e[On]), t(Nt, e[Nt]), t(Pe, 1), t(De, "j73"), n(jt, ce), n(Qt, f), n(Mt, fe), n(Ht, le), n(Ft, pe), n(Vt, Hn), n(Wt, Fn), n(Bt, se), n(qt, _e), n(Kt, he), n(zt, ge), n(Xt, Cr), n($t, ue), n(Gt, de), n(Jt, Pn(this)), Ar(this.b), Sr(this.b, e[Yt]), this.b.set(je, function () {
        var e = I.gaGlobal = I.gaGlobal || {};return e.hid = e.hid || me();
      }()), function (e, t, n) {
        if (!dr) {
          var r = x.location.hash,
              i = I.name,
              o = /^#?gaso=([^&]*)/;(i = (r = (r = r && r.match(o) || i && i.match(o)) ? r[1] : D("GASO")[0] || "") && r.match(/^(?:!([-0-9a-z.]{1,40})!)?([-.\w]{10,1200})$/i)) && (j("GASO", "" + r, n, t, e, 0), window._udo || (window._udo = t), window._utcp || (window._utcp = n), e = i[1], _("https://www.google.com/analytics/web/inpage/pub/inpage.js?" + (e ? "prefix=" + e + "&" : "") + me(), "_gasojs")), dr = !0;
        }
      }(this.b.get(rn), this.b.get(an), this.b.get(sn));
    },
        Sr = function Sr(e, t) {
      var n = Ee(e, on);if (e.data.set(wn, "_ga" == n ? "_gid" : n + "_gid"), "cookie" == Ee(e, hn)) {
        if (Dn = !1, n = D(Ee(e, on)), !(n = Wn(e, n))) {
          n = Ee(e, an);var i = Ee(e, un) || b();void 0 != (n = Xn("__utma", i, n)) ? (r(10), n = n.O[1] + "." + n.O[2]) : n = void 0;
        }if (n && (Dn = !0), i = n && !e.get(ln)) if (2 != (i = n.split(".")).length) i = !1;else if (i = Number(i[1])) {
          var o = Te(e, cn);i = i + o < new Date().getTime() / 1e3;
        } else i = !1;if (i && (n = void 0), n && (e.data.set(tn, n), e.data.set(Yt, n), n = D(Ee(e, wn)), (n = Wn(e, n)) && e.data.set(_n, n)), e.get(On) && (n = e.get(bn), i = e.get(Cn), !n || i && "aw.ds" != i)) {
          if (n = {}, x) {
            i = [], o = x.cookie.split(";");for (var a = /^\s*_gac_(UA-\d+-\d+)=\s*(.+?)\s*$/, s = 0; s < o.length; s++) {
              var c = o[s].match(a);c && i.push({ ja: c[1], value: c[2] });
            }if (o = {}, i && i.length) for (a = 0; a < i.length; a++) {
              "1" != (s = i[a].value.split("."))[0] || 3 != s.length ? n && (n.na = !0) : s[1] && (o[i[a].ja] ? n && (n.pa = !0) : o[i[a].ja] = [], o[i[a].ja].push({ timestamp: s[1], qa: s[2] }));
            }i = o;
          } else i = {};i = i[Ee(e, rn)], Jn(n), i && 0 != i.length && (n = i[0], e.data.set(En, n.timestamp), e.data.set(bn, n.qa));
        }
      }if (e.get(ln) && (n = w("_ga", e.get(gn)), i = w("_gl", e.get(gn)), a = (o = Yn.get(e.get(gn)))._ga, i && 0 < i.indexOf("_ga") && !a && r(30), n || a)) if (n && a && r(36), e.get(fn)) {
        if (a && (r(38), e.data.set(Yt, a), o._gid && (r(51), e.data.set(_n, o._gid)), o._gac && (i = o._gac.split(".")) && 2 == i.length && (r(37), e.data.set(bn, i[0]), e.data.set(En, i[1]))), n) e: if (i = n.indexOf("."), -1 == i) r(22);else {
          if (o = n.substring(0, i), i = (a = n.substring(i + 1)).indexOf("."), n = a.substring(0, i), a = a.substring(i + 1), "1" == o) {
            if (cr(i = a, n)) {
              r(23);break e;
            }
          } else {
            if ("2" != o) {
              r(22);break e;
            }if (o = "", 0 < (i = a.indexOf("-")) ? (o = a.substring(0, i), i = a.substring(i + 1)) : i = a.substring(1), cr(o + i, n)) {
              r(53);break e;
            }o && (r(2), e.data.set(_n, o));
          }r(11), e.data.set(Yt, i), (n = w("_gac", e.get(gn))) && ("1" != (n = n.split("."))[0] || 4 != n.length ? r(72) : cr(n[3], n[1]) ? r(71) : (e.data.set(bn, n[3]), e.data.set(En, n[2]), r(70)));
        }
      } else r(21);t && (r(9), e.data.set(Yt, g(t))), e.get(Yt) || ((t = (t = I.gaGlobal && I.gaGlobal.vid) && -1 != t.search(Ne) ? t : void 0) ? (r(17), e.data.set(Yt, t)) : (r(8), e.data.set(Yt, d()))), e.get(_n) || (r(3), e.data.set(_n, d())), jn(e);
    },
        Ar = function Ar(e) {
      var t = I.navigator,
          n = I.screen,
          i = x.location;if (e.set($e, function (e, t) {
        var n = x.referrer;if (/^(https?|android-app):\/\//i.test(n)) {
          if (e) return n;if (e = "//" + x.location.hostname, !E(n, e)) return t && (t = e.replace(/\./g, "-") + ".cdn.ampproject.org", E(n, t)) ? void 0 : n;
        }
      }(e.get(vn), e.get(yn))), i) {
        var o = i.pathname || "";"/" != o.charAt(0) && (r(31), o = "/" + o), e.set(qe, i.protocol + "//" + i.hostname + o + i.search);
      }n && e.set(Xe, n.width + "x" + n.height), n && e.set(Je, n.colorDepth + "-bit"), n = x.documentElement;var a = (o = x.body) && o.clientWidth && o.clientHeight,
          s = [];if (n && n.clientWidth && n.clientHeight && ("CSS1Compat" === x.compatMode || !a) ? s = [n.clientWidth, n.clientHeight] : a && (s = [o.clientWidth, o.clientHeight]), n = 0 >= s[0] || 0 >= s[1] ? "" : s.join("x"), e.set(Qe, n), e.set(Ye, function () {
        var e, t;if ((t = (t = I.navigator) ? t.plugins : null) && t.length) for (var n = 0; n < t.length && !e; n++) {
          var r = t[n];-1 < r.name.indexOf("Shockwave Flash") && (e = r.description);
        }if (!e) try {
          var i = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.7");e = i.GetVariable("$version");
        } catch (e) {}if (!e) try {
          i = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.6"), e = "WIN 6,0,21,0", i.AllowScriptAccess = "always", e = i.GetVariable("$version");
        } catch (e) {}if (!e) try {
          e = (i = new ActiveXObject("ShockwaveFlash.ShockwaveFlash")).GetVariable("$version");
        } catch (e) {}return e && (i = e.match(/[\d]+/g)) && 3 <= i.length && (e = i[0] + "." + i[1] + " r" + i[2]), e || void 0;
      }()), e.set(ze, x.characterSet || x.charset), e.set(Ze, t && "function" == typeof t.javaEnabled && t.javaEnabled() || !1), e.set(Ke, (t && (t.language || t.browserLanguage) || "").toLowerCase()), e.data.set(bn, w("gclid", !0)), e.data.set(Cn, w("gclsrc", !0)), e.data.set(En, Math.round(new Date().getTime() / 1e3)), i && e.get(gn) && (t = x.location.hash)) {
        for (t = t.split(/[?&#]+/), i = [], n = 0; n < t.length; ++n) {
          (l(t[n], "utm_id") || l(t[n], "utm_campaign") || l(t[n], "utm_source") || l(t[n], "utm_medium") || l(t[n], "utm_term") || l(t[n], "utm_content") || l(t[n], "gclid") || l(t[n], "dclid") || l(t[n], "gclsrc")) && i.push(t[n]);
        }0 < i.length && (t = "#" + i.join("&"), e.set(qe, e.get(qe) + t));
      }
    };kr.prototype.get = function (e) {
      return this.b.get(e);
    }, kr.prototype.set = function (e, t) {
      this.b.set(e, t);
    };var Rr = { pageview: [Ge], event: [et, tt, nt, rt], social: [it, ot, at], timing: [wt, yt, Et, bt] };kr.prototype.send = function (e) {
      if (!(1 > arguments.length)) {
        if ("string" == typeof arguments[0]) var t = arguments[0],
            n = [].slice.call(arguments, 1);else t = arguments[0] && arguments[0][Me], n = arguments;t && ((n = T(Rr[t] || [], n))[Me] = t, this.b.set(n, void 0, !0), this.filters.D(this.b), this.b.data.m = {});
      }
    }, kr.prototype.ma = function (e, t) {
      var n = this;Hr(e, n, t) || (Vr(e, function () {
        Hr(e, n, t);
      }), Fr(String(n.get(Zt)), e, void 0, t, !0));
    };var Ir,
        xr,
        Nr,
        Lr,
        Ur = function Ur(e) {
      return "prerender" != x.visibilityState && (e(), !0);
    },
        Pr = function Pr(e) {
      if (!Ur(e)) {
        r(16);var t = !1,
            n = function n() {
          if (!t && Ur(e)) {
            t = !0;var r = n,
                i = x;i.removeEventListener ? i.removeEventListener("visibilitychange", r, !1) : i.detachEvent && i.detachEvent("onvisibilitychange", r);
          }
        };p(x, "visibilitychange", n);
      }
    },
        Dr = /^(?:(\w+)\.)?(?:(\w+):)?(\w+)$/,
        jr = function jr(e) {
      if (a(e[0])) this.u = e[0];else {
        var t = Dr.exec(e[0]);if (null != t && 4 == t.length && (this.c = t[1] || "t0", this.K = t[2] || "", this.C = t[3], this.a = [].slice.call(e, 1), this.K || (this.A = "create" == this.C, this.i = "require" == this.C, this.g = "provide" == this.C, this.ba = "remove" == this.C), this.i && (3 <= this.a.length ? (this.X = this.a[1], this.W = this.a[2]) : this.a[1] && (c(this.a[1]) ? this.X = this.a[1] : this.W = this.a[1]))), t = e[1], e = e[2], !this.C) throw "abort";if (this.i && (!c(t) || "" == t)) throw "abort";if (this.g && (!c(t) || "" == t || !a(e))) throw "abort";if (Mr(this.c) || Mr(this.K)) throw "abort";if (this.g && "t0" != this.c) throw "abort";
      }
    };function Mr(e) {
      return 0 <= e.indexOf(".") || 0 <= e.indexOf(":");
    }Ir = new C(), Nr = new C(), Lr = new C(), xr = { ec: 45, ecommerce: 46, linkid: 47 };var Hr = function Hr(e, t, n) {
      t == Gr || t.get(Zt);var r = Ir.get(e);return !!a(r) && (t.plugins_ = t.plugins_ || new C(), !!t.plugins_.get(e) || (t.plugins_.set(e, new r(t, n || {})), !0));
    },
        Fr = function Fr(e, t, n, i, o) {
      if (!a(Ir.get(t)) && !Nr.get(t)) {
        if (xr.hasOwnProperty(t) && r(xr[t]), hr.test(t)) {
          if (r(52), !(e = Gr.j(e))) return !0;i = { id: t, B: (n = i || {}).dataLayer || "dataLayer", ia: !!e.get("anonymizeIp"), sync: o, G: !1 }, e.get("&gtm") == t && (i.G = !0);var s = String(e.get("name"));"t0" != s && (i.target = s), P(String(e.get("trackingId"))) || (i.clientId = String(e.get(Yt)), i.ka = Number(e.get(en)), n = n.palindrome ? gr : fr, n = (n = x.cookie.replace(/^|(; +)/g, ";").match(n)) ? n.sort().join("").substring(1) : void 0, i.la = n, i.qa = y(e.b.get(qe) || "", "gclid")), e = i.B, n = new Date().getTime(), I[e] = I[e] || [], n = { "gtm.start": n }, o || (n.event = "gtm.js"), I[e].push(n), n = function (e) {
            function t(e, t) {
              t && (n += "&" + e + "=" + g(t));
            }var n = "https://www.google-analytics.com/gtm/js?id=" + g(e.id);return "dataLayer" != e.B && t("l", e.B), t("t", e.target), t("cid", e.clientId), t("cidt", e.ka), t("gac", e.la), t("aip", e.ia), e.sync && t("m", "sync"), t("cycle", e.G), e.qa && t("gclid", e.qa), pr.test(x.referrer) && t("cb", String(me())), n;
          }(i);
        }!n && xr.hasOwnProperty(t) ? (r(39), n = t + ".js") : r(43), n && (n && 0 <= n.indexOf("/") || (n = (Ue || "https:" == x.location.protocol ? "https:" : "http:") + "//www.google-analytics.com/plugins/ua/" + n), e = (i = qr(n)).protocol, n = x.location.protocol, ("https:" == e || e == n || "http:" == e && "http:" == n) && Br(i) && (_(i.url, void 0, o), Nr.set(t, !0)));
      }
    },
        Vr = function Vr(e, t) {
      var n = Lr.get(e) || [];n.push(t), Lr.set(e, n);
    },
        Wr = function Wr(e, t) {
      Ir.set(e, t), t = Lr.get(e) || [];for (var n = 0; n < t.length; n++) {
        t[n]();
      }Lr.set(e, []);
    },
        Br = function Br(e) {
      var t = qr(x.location.href);return !!l(e.url, "https://www.google-analytics.com/gtm/js?id=") || !(e.query || 0 <= e.url.indexOf("?") || 0 <= e.path.indexOf("://")) && (e.host == t.host && e.port == t.port || (t = "http:" == e.protocol ? 80 : 443, !("www.google-analytics.com" != e.host || (e.port || t) != t || !l(e.path, "/plugins/"))));
    },
        qr = function qr(e) {
      function t(e) {
        var t = e.hostname || "",
            n = 0 <= t.indexOf("]");return t = t.split(n ? "]" : ":")[0].toLowerCase(), n && (t += "]"), n = (e.protocol || "").toLowerCase(), n = 1 * e.port || ("http:" == n ? 80 : "https:" == n ? 443 : ""), e = e.pathname || "", l(e, "/") || (e = "/" + e), [t, "" + n, e];
      }var n = x.createElement("a");n.href = x.location.href;var r = (n.protocol || "").toLowerCase(),
          i = t(n),
          o = n.search || "",
          a = r + "//" + i[0] + (i[1] ? ":" + i[1] : "");return l(e, "//") ? e = r + e : l(e, "/") ? e = a + e : !e || l(e, "?") ? e = a + i[2] + (e || o) : 0 > e.split("/")[0].indexOf(":") && (e = a + i[2].substring(0, i[2].lastIndexOf("/")) + "/" + e), n.href = e, r = t(n), { protocol: (n.protocol || "").toLowerCase(), host: r[0], port: r[1], path: r[2], query: n.search || "", url: e || "" };
    },
        $r = { ga: function ga() {
        $r.f = [];
      } };$r.ga(), $r.D = function (e) {
      var t = $r.J.apply($r, arguments);for (t = $r.f.concat(t), $r.f = []; 0 < t.length && !$r.v(t[0]) && (t.shift(), !(0 < $r.f.length));) {}$r.f = $r.f.concat(t);
    }, $r.J = function (e) {
      for (var t = [], n = 0; n < arguments.length; n++) {
        try {
          var r = new jr(arguments[n]);r.g ? Wr(r.a[0], r.a[1]) : (r.i && (r.ha = Fr(r.c, r.a[0], r.X, r.W)), t.push(r));
        } catch (e) {}
      }return t;
    }, $r.v = function (e) {
      try {
        if (e.u) e.u.call(I, Gr.j("t0"));else {
          var t = e.c == xe ? Gr : Gr.j(e.c);if (e.A) {
            if ("t0" == e.c && null === (t = Gr.create.apply(Gr, e.a))) return !0;
          } else if (e.ba) Gr.remove(e.c);else if (t) if (e.i) {
            if (e.ha && (e.ha = Fr(e.c, e.a[0], e.X, e.W)), !Hr(e.a[0], t, e.W)) return !0;
          } else if (e.K) {
            var n = e.C,
                r = e.a,
                i = t.plugins_.get(e.K);i[n].apply(i, r);
          } else t[e.C].apply(t, e.a);
        }
      } catch (e) {}
    };var Gr = function Gr(e) {
      r(1), $r.D.apply($r, [arguments]);
    };Gr.h = {}, Gr.P = [], Gr.L = 0, Gr.ya = 0, Gr.answer = 42;var Kr = [rn, an, Zt];Gr.create = function (e) {
      var t = T(Kr, [].slice.call(arguments));t[Zt] || (t[Zt] = "t0");var n = "" + t[Zt];return Gr.h[n] ? Gr.h[n] : function (e) {
        e: {
          if (B.test(x.referrer)) {
            var t = x.location.hostname.replace(q, "");t: {
              var n = x.referrer,
                  i = (n = n.replace(/^https?:\/\//, "")).replace(/^[^/]+/, "").split("/"),
                  o = i[2];if (!(i = (i = "s" == o ? i[3] : o) ? decodeURIComponent(i) : i)) {
                if (0 == n.indexOf("xn--")) {
                  n = "";break t;
                }(n = n.match(/(.*)\.cdn\.ampproject\.org\/?$/)) && 2 == n.length && (i = n[1].replace(/-/g, ".").replace(/\.\./g, "-"));
              }n = i ? i.replace(q, "") : "";
            }if (t == n) {
              t = !0;break e;
            }r(78);
          }t = !1;
        }if (t && !1 !== e[yn] && (void 0 === R && (t = (t = Yn.get()) && t._ga || void 0) && (R = t, r(81)), void 0 !== R)) return e[Yt] || (e[Yt] = R), !1;if (e[yn]) {
          if (r(67), e[hn] && "cookie" != e[hn]) return !1;if (void 0 !== R) e[Yt] || (e[Yt] = R);else {
            e: if (t = String(e[an] || b()), n = String(e[sn] || "/"), i = D(String(e[on] || "_ga")), t = Bn(i, t, n), !t || Ne.test(t)) t = !0;else if (t = D("AMP_TOKEN"), 0 == t.length) t = !0;else {
              if (1 == t.length && ("$RETRIEVING" == (t = decodeURIComponent(t[0])) || "$OPT_OUT" == t || "$ERROR" == t || "$NOT_FOUND" == t)) {
                t = !0;break e;
              }t = !1;
            }if (t && K(G, String(e[rn]))) return !0;
          }
        }return !1;
      }(t) ? null : (t = new kr(t), Gr.h[n] = t, Gr.P.push(t), t);
    }, Gr.remove = function (e) {
      for (var t = 0; t < Gr.P.length; t++) {
        if (Gr.P[t].get(Zt) == e) {
          Gr.P.splice(t, 1), Gr.h[e] = null;break;
        }
      }
    }, Gr.j = function (e) {
      return Gr.h[e];
    }, Gr.getAll = function () {
      return Gr.P.slice(0);
    }, Gr.N = function () {
      "ga" != xe && r(49);var e = I[xe];if (!e || 42 != e.answer) {
        Gr.L = e && e.l, Gr.ya = 1 * new Date(), Gr.loaded = !0;var t = I[xe] = Gr;if (In("create", t, t.create), In("remove", t, t.remove), In("getByName", t, t.j, 5), In("getAll", t, t.getAll, 6), In("get", t = kr.prototype, t.get, 7), In("set", t, t.set, 4), In("send", t, t.send), In("requireSync", t, t.ma), In("get", t = we.prototype, t.get), In("set", t, t.set), "https:" != x.location.protocol && !Ue) {
          e: {
            t = x.getElementsByTagName("script");for (var n = 0; n < t.length && 100 > n; n++) {
              var i = t[n].src;if (i && 0 == i.indexOf("https://www.google-analytics.com/analytics")) {
                t = !0;break e;
              }
            }t = !1;
          }t && (Ue = !0);
        }(I.gaplugins = I.gaplugins || {}).Linker = ir, t = ir.prototype, Wr("linker", ir), In("decorate", t, t.ca, 20), In("autoLink", t, t.S, 25), Wr("displayfeatures", Tr), Wr("adfeatures", Tr), e = e && e.q, s(e) ? $r.D.apply(Gr, e) : r(50);
      }
    }, Gr.da = function () {
      for (var e = Gr.getAll(), t = 0; t < e.length; t++) {
        e[t].get(Zt);
      }
    };var zr = Gr.N,
        Jr = I[xe];Jr && Jr.r ? zr() : Pr(zr), Pr(function () {
      $r.D(["provide", "render", f]);
    });
  }(window);
}, function (e, t, n) {
  window, e.exports = function (e) {
    var t = {};function n(r) {
      if (t[r]) return t[r].exports;var i = t[r] = { i: r, l: !1, exports: {} };return e[r].call(i.exports, i, i.exports, n), i.l = !0, i.exports;
    }return n.m = e, n.c = t, n.d = function (e, t, r) {
      n.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: r });
    }, n.r = function (e) {
      "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e, "__esModule", { value: !0 });
    }, n.t = function (e, t) {
      if (1 & t && (e = n(e)), 8 & t) return e;if (4 & t && "object" == (typeof e === "undefined" ? "undefined" : _typeof(e)) && e && e.__esModule) return e;var r = Object.create(null);if (n.r(r), Object.defineProperty(r, "default", { enumerable: !0, value: e }), 2 & t && "string" != typeof e) for (var i in e) {
        n.d(r, i, function (t) {
          return e[t];
        }.bind(null, i));
      }return r;
    }, n.n = function (e) {
      var t = e && e.__esModule ? function () {
        return e.default;
      } : function () {
        return e;
      };return n.d(t, "a", t), t;
    }, n.o = function (e, t) {
      return Object.prototype.hasOwnProperty.call(e, t);
    }, n.p = "", n(n.s = 30);
  }([function (e, t, n) {
    "use strict";
    var r = n(3),
        i = n(9),
        o = Object.prototype.toString;function a(e) {
      return "[object Array]" === o.call(e);
    }function s(e) {
      return null !== e && "object" == (typeof e === "undefined" ? "undefined" : _typeof(e));
    }function c(e) {
      return "[object Function]" === o.call(e);
    }function l(e, t) {
      if (null != e) if ("object" != (typeof e === "undefined" ? "undefined" : _typeof(e)) && (e = [e]), a(e)) for (var n = 0, r = e.length; n < r; n++) {
        t.call(null, e[n], n, e);
      } else for (var i in e) {
        Object.prototype.hasOwnProperty.call(e, i) && t.call(null, e[i], i, e);
      }
    }e.exports = { isArray: a, isArrayBuffer: function isArrayBuffer(e) {
        return "[object ArrayBuffer]" === o.call(e);
      }, isBuffer: i, isFormData: function isFormData(e) {
        return "undefined" != typeof FormData && e instanceof FormData;
      }, isArrayBufferView: function isArrayBufferView(e) {
        return "undefined" != typeof ArrayBuffer && ArrayBuffer.isView ? ArrayBuffer.isView(e) : e && e.buffer && e.buffer instanceof ArrayBuffer;
      }, isString: function isString(e) {
        return "string" == typeof e;
      }, isNumber: function isNumber(e) {
        return "number" == typeof e;
      }, isObject: s, isUndefined: function isUndefined(e) {
        return void 0 === e;
      }, isDate: function isDate(e) {
        return "[object Date]" === o.call(e);
      }, isFile: function isFile(e) {
        return "[object File]" === o.call(e);
      }, isBlob: function isBlob(e) {
        return "[object Blob]" === o.call(e);
      }, isFunction: c, isStream: function isStream(e) {
        return s(e) && c(e.pipe);
      }, isURLSearchParams: function isURLSearchParams(e) {
        return "undefined" != typeof URLSearchParams && e instanceof URLSearchParams;
      }, isStandardBrowserEnv: function isStandardBrowserEnv() {
        return ("undefined" == typeof navigator || "ReactNative" !== navigator.product) && "undefined" != typeof window && "undefined" != typeof document;
      }, forEach: l, merge: function e() {
        var t = {};function n(n, r) {
          "object" == _typeof(t[r]) && "object" == (typeof n === "undefined" ? "undefined" : _typeof(n)) ? t[r] = e(t[r], n) : t[r] = n;
        }for (var r = 0, i = arguments.length; r < i; r++) {
          l(arguments[r], n);
        }return t;
      }, extend: function extend(e, t, n) {
        return l(t, function (t, i) {
          e[i] = n && "function" == typeof t ? r(t, n) : t;
        }), e;
      }, trim: function trim(e) {
        return e.replace(/^\s*/, "").replace(/\s*$/, "");
      } };
  }, function (e, t, n) {
    e.exports = n(8);
  }, function (e, t, n) {
    "use strict";
    (function (t) {
      var r = n(0),
          i = n(12),
          o = { "Content-Type": "application/x-www-form-urlencoded" };function a(e, t) {
        !r.isUndefined(e) && r.isUndefined(e["Content-Type"]) && (e["Content-Type"] = t);
      }var s,
          c = { adapter: ("undefined" != typeof XMLHttpRequest ? s = n(4) : void 0 !== t && (s = n(4)), s), transformRequest: [function (e, t) {
          return i(t, "Content-Type"), r.isFormData(e) || r.isArrayBuffer(e) || r.isBuffer(e) || r.isStream(e) || r.isFile(e) || r.isBlob(e) ? e : r.isArrayBufferView(e) ? e.buffer : r.isURLSearchParams(e) ? (a(t, "application/x-www-form-urlencoded;charset=utf-8"), e.toString()) : r.isObject(e) ? (a(t, "application/json;charset=utf-8"), JSON.stringify(e)) : e;
        }], transformResponse: [function (e) {
          if ("string" == typeof e) try {
            e = JSON.parse(e);
          } catch (e) {}return e;
        }], timeout: 0, xsrfCookieName: "XSRF-TOKEN", xsrfHeaderName: "X-XSRF-TOKEN", maxContentLength: -1, validateStatus: function validateStatus(e) {
          return e >= 200 && e < 300;
        }, headers: { common: { Accept: "application/json, text/plain, */*" } } };r.forEach(["delete", "get", "head"], function (e) {
        c.headers[e] = {};
      }), r.forEach(["post", "put", "patch"], function (e) {
        c.headers[e] = r.merge(o);
      }), e.exports = c;
    }).call(this, n(11));
  }, function (e, t, n) {
    "use strict";
    e.exports = function (e, t) {
      return function () {
        for (var n = new Array(arguments.length), r = 0; r < n.length; r++) {
          n[r] = arguments[r];
        }return e.apply(t, n);
      };
    };
  }, function (e, t, n) {
    "use strict";
    var r = n(0),
        i = n(13),
        o = n(15),
        a = n(16),
        s = n(17),
        c = n(5),
        l = "undefined" != typeof window && window.btoa && window.btoa.bind(window) || n(18);e.exports = function (e) {
      return new Promise(function (t, u) {
        var d = e.data,
            h = e.headers;r.isFormData(d) && delete h["Content-Type"];var f = new XMLHttpRequest(),
            g = "onreadystatechange",
            p = !1;if ("undefined" == typeof window || !window.XDomainRequest || "withCredentials" in f || s(e.url) || (f = new window.XDomainRequest(), g = "onload", p = !0, f.onprogress = function () {}, f.ontimeout = function () {}), e.auth) {
          var m = e.auth.username || "",
              v = e.auth.password || "";h.Authorization = "Basic " + l(m + ":" + v);
        }if (f.open(e.method.toUpperCase(), o(e.url, e.params, e.paramsSerializer), !0), f.timeout = e.timeout, f[g] = function () {
          if (f && (4 === f.readyState || p) && (0 !== f.status || f.responseURL && 0 === f.responseURL.indexOf("file:"))) {
            var n = "getAllResponseHeaders" in f ? a(f.getAllResponseHeaders()) : null,
                r = { data: e.responseType && "text" !== e.responseType ? f.response : f.responseText, status: 1223 === f.status ? 204 : f.status, statusText: 1223 === f.status ? "No Content" : f.statusText, headers: n, config: e, request: f };i(t, u, r), f = null;
          }
        }, f.onerror = function () {
          u(c("Network Error", e, null, f)), f = null;
        }, f.ontimeout = function () {
          u(c("timeout of " + e.timeout + "ms exceeded", e, "ECONNABORTED", f)), f = null;
        }, r.isStandardBrowserEnv()) {
          var _ = n(19),
              w = (e.withCredentials || s(e.url)) && e.xsrfCookieName ? _.read(e.xsrfCookieName) : void 0;w && (h[e.xsrfHeaderName] = w);
        }if ("setRequestHeader" in f && r.forEach(h, function (e, t) {
          void 0 === d && "content-type" === t.toLowerCase() ? delete h[t] : f.setRequestHeader(t, e);
        }), e.withCredentials && (f.withCredentials = !0), e.responseType) try {
          f.responseType = e.responseType;
        } catch (t) {
          if ("json" !== e.responseType) throw t;
        }"function" == typeof e.onDownloadProgress && f.addEventListener("progress", e.onDownloadProgress), "function" == typeof e.onUploadProgress && f.upload && f.upload.addEventListener("progress", e.onUploadProgress), e.cancelToken && e.cancelToken.promise.then(function (e) {
          f && (f.abort(), u(e), f = null);
        }), void 0 === d && (d = null), f.send(d);
      });
    };
  }, function (e, t, n) {
    "use strict";
    var r = n(14);e.exports = function (e, t, n, i, o) {
      var a = new Error(e);return r(a, t, n, i, o);
    };
  }, function (e, t, n) {
    "use strict";
    e.exports = function (e) {
      return !(!e || !e.__CANCEL__);
    };
  }, function (e, t, n) {
    "use strict";
    function r(e) {
      this.message = e;
    }r.prototype.toString = function () {
      return "Cancel" + (this.message ? ": " + this.message : "");
    }, r.prototype.__CANCEL__ = !0, e.exports = r;
  }, function (e, t, n) {
    "use strict";
    var r = n(0),
        i = n(3),
        o = n(10),
        a = n(2);function s(e) {
      var t = new o(e),
          n = i(o.prototype.request, t);return r.extend(n, o.prototype, t), r.extend(n, t), n;
    }var c = s(a);c.Axios = o, c.create = function (e) {
      return s(r.merge(a, e));
    }, c.Cancel = n(7), c.CancelToken = n(25), c.isCancel = n(6), c.all = function (e) {
      return Promise.all(e);
    }, c.spread = n(26), e.exports = c, e.exports.default = c;
  }, function (e, t) {
    function n(e) {
      return !!e.constructor && "function" == typeof e.constructor.isBuffer && e.constructor.isBuffer(e);
    }
    /*!
     * Determine if an object is a Buffer
     *
     * @author   Feross Aboukhadijeh <https://feross.org>
     * @license  MIT
     */e.exports = function (e) {
      return null != e && (n(e) || function (e) {
        return "function" == typeof e.readFloatLE && "function" == typeof e.slice && n(e.slice(0, 0));
      }(e) || !!e._isBuffer);
    };
  }, function (e, t, n) {
    "use strict";
    var r = n(2),
        i = n(0),
        o = n(20),
        a = n(21);function s(e) {
      this.defaults = e, this.interceptors = { request: new o(), response: new o() };
    }s.prototype.request = function (e) {
      "string" == typeof e && (e = i.merge({ url: arguments[0] }, arguments[1])), (e = i.merge(r, this.defaults, { method: "get" }, e)).method = e.method.toLowerCase();var t = [a, void 0],
          n = Promise.resolve(e);for (this.interceptors.request.forEach(function (e) {
        t.unshift(e.fulfilled, e.rejected);
      }), this.interceptors.response.forEach(function (e) {
        t.push(e.fulfilled, e.rejected);
      }); t.length;) {
        n = n.then(t.shift(), t.shift());
      }return n;
    }, i.forEach(["delete", "get", "head", "options"], function (e) {
      s.prototype[e] = function (t, n) {
        return this.request(i.merge(n || {}, { method: e, url: t }));
      };
    }), i.forEach(["post", "put", "patch"], function (e) {
      s.prototype[e] = function (t, n, r) {
        return this.request(i.merge(r || {}, { method: e, url: t, data: n }));
      };
    }), e.exports = s;
  }, function (e, t) {
    var n,
        r,
        i = e.exports = {};function o() {
      throw new Error("setTimeout has not been defined");
    }function a() {
      throw new Error("clearTimeout has not been defined");
    }function s(e) {
      if (n === setTimeout) return setTimeout(e, 0);if ((n === o || !n) && setTimeout) return n = setTimeout, setTimeout(e, 0);try {
        return n(e, 0);
      } catch (t) {
        try {
          return n.call(null, e, 0);
        } catch (t) {
          return n.call(this, e, 0);
        }
      }
    }!function () {
      try {
        n = "function" == typeof setTimeout ? setTimeout : o;
      } catch (e) {
        n = o;
      }try {
        r = "function" == typeof clearTimeout ? clearTimeout : a;
      } catch (e) {
        r = a;
      }
    }();var c,
        l = [],
        u = !1,
        d = -1;function h() {
      u && c && (u = !1, c.length ? l = c.concat(l) : d = -1, l.length && f());
    }function f() {
      if (!u) {
        var e = s(h);u = !0;for (var t = l.length; t;) {
          for (c = l, l = []; ++d < t;) {
            c && c[d].run();
          }d = -1, t = l.length;
        }c = null, u = !1, function (e) {
          if (r === clearTimeout) return clearTimeout(e);if ((r === a || !r) && clearTimeout) return r = clearTimeout, clearTimeout(e);try {
            r(e);
          } catch (t) {
            try {
              return r.call(null, e);
            } catch (t) {
              return r.call(this, e);
            }
          }
        }(e);
      }
    }function g(e, t) {
      this.fun = e, this.array = t;
    }function p() {}i.nextTick = function (e) {
      var t = new Array(arguments.length - 1);if (arguments.length > 1) for (var n = 1; n < arguments.length; n++) {
        t[n - 1] = arguments[n];
      }l.push(new g(e, t)), 1 !== l.length || u || s(f);
    }, g.prototype.run = function () {
      this.fun.apply(null, this.array);
    }, i.title = "browser", i.browser = !0, i.env = {}, i.argv = [], i.version = "", i.versions = {}, i.on = p, i.addListener = p, i.once = p, i.off = p, i.removeListener = p, i.removeAllListeners = p, i.emit = p, i.prependListener = p, i.prependOnceListener = p, i.listeners = function (e) {
      return [];
    }, i.binding = function (e) {
      throw new Error("process.binding is not supported");
    }, i.cwd = function () {
      return "/";
    }, i.chdir = function (e) {
      throw new Error("process.chdir is not supported");
    }, i.umask = function () {
      return 0;
    };
  }, function (e, t, n) {
    "use strict";
    var r = n(0);e.exports = function (e, t) {
      r.forEach(e, function (n, r) {
        r !== t && r.toUpperCase() === t.toUpperCase() && (e[t] = n, delete e[r]);
      });
    };
  }, function (e, t, n) {
    "use strict";
    var r = n(5);e.exports = function (e, t, n) {
      var i = n.config.validateStatus;n.status && i && !i(n.status) ? t(r("Request failed with status code " + n.status, n.config, null, n.request, n)) : e(n);
    };
  }, function (e, t, n) {
    "use strict";
    e.exports = function (e, t, n, r, i) {
      return e.config = t, n && (e.code = n), e.request = r, e.response = i, e;
    };
  }, function (e, t, n) {
    "use strict";
    var r = n(0);function i(e) {
      return encodeURIComponent(e).replace(/%40/gi, "@").replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]");
    }e.exports = function (e, t, n) {
      if (!t) return e;var o;if (n) o = n(t);else if (r.isURLSearchParams(t)) o = t.toString();else {
        var a = [];r.forEach(t, function (e, t) {
          null != e && (r.isArray(e) && (t += "[]"), r.isArray(e) || (e = [e]), r.forEach(e, function (e) {
            r.isDate(e) ? e = e.toISOString() : r.isObject(e) && (e = JSON.stringify(e)), a.push(i(t) + "=" + i(e));
          }));
        }), o = a.join("&");
      }return o && (e += (-1 === e.indexOf("?") ? "?" : "&") + o), e;
    };
  }, function (e, t, n) {
    "use strict";
    var r = n(0),
        i = ["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"];e.exports = function (e) {
      var t,
          n,
          o,
          a = {};return e ? (r.forEach(e.split("\n"), function (e) {
        if (o = e.indexOf(":"), t = r.trim(e.substr(0, o)).toLowerCase(), n = r.trim(e.substr(o + 1)), t) {
          if (a[t] && i.indexOf(t) >= 0) return;a[t] = "set-cookie" === t ? (a[t] ? a[t] : []).concat([n]) : a[t] ? a[t] + ", " + n : n;
        }
      }), a) : a;
    };
  }, function (e, t, n) {
    "use strict";
    var r = n(0);e.exports = r.isStandardBrowserEnv() ? function () {
      var e,
          t = /(msie|trident)/i.test(navigator.userAgent),
          n = document.createElement("a");function i(e) {
        var r = e;return t && (n.setAttribute("href", r), r = n.href), n.setAttribute("href", r), { href: n.href, protocol: n.protocol ? n.protocol.replace(/:$/, "") : "", host: n.host, search: n.search ? n.search.replace(/^\?/, "") : "", hash: n.hash ? n.hash.replace(/^#/, "") : "", hostname: n.hostname, port: n.port, pathname: "/" === n.pathname.charAt(0) ? n.pathname : "/" + n.pathname };
      }return e = i(window.location.href), function (t) {
        var n = r.isString(t) ? i(t) : t;return n.protocol === e.protocol && n.host === e.host;
      };
    }() : function () {
      return !0;
    };
  }, function (e, t, n) {
    "use strict";
    function r() {
      this.message = "String contains an invalid character";
    }r.prototype = new Error(), r.prototype.code = 5, r.prototype.name = "InvalidCharacterError", e.exports = function (e) {
      for (var t, n, i = String(e), o = "", a = 0, s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="; i.charAt(0 | a) || (s = "=", a % 1); o += s.charAt(63 & t >> 8 - a % 1 * 8)) {
        if ((n = i.charCodeAt(a += .75)) > 255) throw new r();t = t << 8 | n;
      }return o;
    };
  }, function (e, t, n) {
    "use strict";
    var r = n(0);e.exports = r.isStandardBrowserEnv() ? { write: function write(e, t, n, i, o, a) {
        var s = [];s.push(e + "=" + encodeURIComponent(t)), r.isNumber(n) && s.push("expires=" + new Date(n).toGMTString()), r.isString(i) && s.push("path=" + i), r.isString(o) && s.push("domain=" + o), !0 === a && s.push("secure"), document.cookie = s.join("; ");
      }, read: function read(e) {
        var t = document.cookie.match(new RegExp("(^|;\\s*)(" + e + ")=([^;]*)"));return t ? decodeURIComponent(t[3]) : null;
      }, remove: function remove(e) {
        this.write(e, "", Date.now() - 864e5);
      } } : { write: function write() {}, read: function read() {
        return null;
      }, remove: function remove() {} };
  }, function (e, t, n) {
    "use strict";
    var r = n(0);function i() {
      this.handlers = [];
    }i.prototype.use = function (e, t) {
      return this.handlers.push({ fulfilled: e, rejected: t }), this.handlers.length - 1;
    }, i.prototype.eject = function (e) {
      this.handlers[e] && (this.handlers[e] = null);
    }, i.prototype.forEach = function (e) {
      r.forEach(this.handlers, function (t) {
        null !== t && e(t);
      });
    }, e.exports = i;
  }, function (e, t, n) {
    "use strict";
    var r = n(0),
        i = n(22),
        o = n(6),
        a = n(2),
        s = n(23),
        c = n(24);function l(e) {
      e.cancelToken && e.cancelToken.throwIfRequested();
    }e.exports = function (e) {
      return l(e), e.baseURL && !s(e.url) && (e.url = c(e.baseURL, e.url)), e.headers = e.headers || {}, e.data = i(e.data, e.headers, e.transformRequest), e.headers = r.merge(e.headers.common || {}, e.headers[e.method] || {}, e.headers || {}), r.forEach(["delete", "get", "head", "post", "put", "patch", "common"], function (t) {
        delete e.headers[t];
      }), (e.adapter || a.adapter)(e).then(function (t) {
        return l(e), t.data = i(t.data, t.headers, e.transformResponse), t;
      }, function (t) {
        return o(t) || (l(e), t && t.response && (t.response.data = i(t.response.data, t.response.headers, e.transformResponse))), Promise.reject(t);
      });
    };
  }, function (e, t, n) {
    "use strict";
    var r = n(0);e.exports = function (e, t, n) {
      return r.forEach(n, function (n) {
        e = n(e, t);
      }), e;
    };
  }, function (e, t, n) {
    "use strict";
    e.exports = function (e) {
      return (/^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(e)
      );
    };
  }, function (e, t, n) {
    "use strict";
    e.exports = function (e, t) {
      return t ? e.replace(/\/+$/, "") + "/" + t.replace(/^\/+/, "") : e;
    };
  }, function (e, t, n) {
    "use strict";
    var r = n(7);function i(e) {
      if ("function" != typeof e) throw new TypeError("executor must be a function.");var t;this.promise = new Promise(function (e) {
        t = e;
      });var n = this;e(function (e) {
        n.reason || (n.reason = new r(e), t(n.reason));
      });
    }i.prototype.throwIfRequested = function () {
      if (this.reason) throw this.reason;
    }, i.source = function () {
      var e;return { token: new i(function (t) {
          e = t;
        }), cancel: e };
    }, e.exports = i;
  }, function (e, t, n) {
    "use strict";
    e.exports = function (e) {
      return function (t) {
        return e.apply(null, t);
      };
    };
  }, function (e, t, n) {
    var r,
        i,
        o = n(28),
        a = n(29),
        s = 0,
        c = 0;e.exports = function (e, t, n) {
      var l = t && n || 0,
          u = t || [],
          d = (e = e || {}).node || r,
          h = void 0 !== e.clockseq ? e.clockseq : i;if (null == d || null == h) {
        var f = o();null == d && (d = r = [1 | f[0], f[1], f[2], f[3], f[4], f[5]]), null == h && (h = i = 16383 & (f[6] << 8 | f[7]));
      }var g = void 0 !== e.msecs ? e.msecs : new Date().getTime(),
          p = void 0 !== e.nsecs ? e.nsecs : c + 1,
          m = g - s + (p - c) / 1e4;if (m < 0 && void 0 === e.clockseq && (h = h + 1 & 16383), (m < 0 || g > s) && void 0 === e.nsecs && (p = 0), p >= 1e4) throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");s = g, c = p, i = h;var v = (1e4 * (268435455 & (g += 122192928e5)) + p) % 4294967296;u[l++] = v >>> 24 & 255, u[l++] = v >>> 16 & 255, u[l++] = v >>> 8 & 255, u[l++] = 255 & v;var _ = g / 4294967296 * 1e4 & 268435455;u[l++] = _ >>> 8 & 255, u[l++] = 255 & _, u[l++] = _ >>> 24 & 15 | 16, u[l++] = _ >>> 16 & 255, u[l++] = h >>> 8 | 128, u[l++] = 255 & h;for (var w = 0; w < 6; ++w) {
        u[l + w] = d[w];
      }return t || a(u);
    };
  }, function (e, t) {
    var n = "undefined" != typeof crypto && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || "undefined" != typeof msCrypto && "function" == typeof window.msCrypto.getRandomValues && msCrypto.getRandomValues.bind(msCrypto);if (n) {
      var r = new Uint8Array(16);e.exports = function () {
        return n(r), r;
      };
    } else {
      var i = new Array(16);e.exports = function () {
        for (var e, t = 0; t < 16; t++) {
          0 == (3 & t) && (e = 4294967296 * Math.random()), i[t] = e >>> ((3 & t) << 3) & 255;
        }return i;
      };
    }
  }, function (e, t) {
    for (var n = [], r = 0; r < 256; ++r) {
      n[r] = (r + 256).toString(16).substr(1);
    }e.exports = function (e, t) {
      var r = t || 0,
          i = n;return [i[e[r++]], i[e[r++]], i[e[r++]], i[e[r++]], "-", i[e[r++]], i[e[r++]], "-", i[e[r++]], i[e[r++]], "-", i[e[r++]], i[e[r++]], "-", i[e[r++]], i[e[r++]], i[e[r++]], i[e[r++]], i[e[r++]], i[e[r++]]].join("");
    };
  }, function (e, t, n) {
    "use strict";
    n.r(t);var r = { log: function log() {
        var _console;

        (_console = console).log.apply(_console, arguments);
      }, error: function error() {
        var _console2;

        (_console2 = console).error.apply(_console2, arguments);
      }, debug: function debug() {} },
        i = function i(e) {
      return new Date(e).toISOString();
    },
        o = function o(e) {
      return "string" == typeof e && (e = e.trim()), null == e || "" === e || "unknown" === e;
    };function a(e) {
      return "[object Function]" === Object.prototype.toString.call(e);
    }var s = function e(t) {
      return t ? (t ^ 16 * Math.random() >> t / 4).toString(16) : ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, e);
    },
        c = "unknown";
    var l = function () {
      function l() {
        _classCallCheck(this, l);

        this.app_id = c, this.user_id = c, this.version = c, this.build_id = c, this.device_id = c, this.display = c, this.bucket = c, this.flag = 0, this._init();
      }

      _createClass(l, [{
        key: "_init",
        value: function _init() {
          this.device_id = l.getDeviceId(), r.log("EventConMeta, device_id:", this.device_id), this.display = window.screen.width + "," + window.screen.height;
        }
      }, {
        key: "toJsonString",
        value: function toJsonString() {
          return JSON.stringify(this);
        }
      }, {
        key: "userId",
        get: function get() {
          return a(this.user_id) ? this.user_id() : this.user_id;
        }
      }, {
        key: "metaObj",
        get: function get() {
          return { app_id: this.app_id, user_id: this.userId, version: this.version, build_id: this.build_id, device_id: this.device_id, display: this.display, bucket: this.bucket, flag: this.flag };
        }
      }], [{
        key: "getDeviceId",
        value: function getDeviceId() {
          var e = localStorage.getItem("eventcon.device_id");return null == e && (e = s(), localStorage.setItem("eventcon.device_id", e)), e;
        }
      }]);

      return l;
    }();

    var u = { EVENT_BASE: 1, EVENT_APP: 2, EVENT_UI_ACTION: 3, EVENT_PAGE_CHANGE: 4, EVENT_TAG: 5, EVENT_TRACE: 6, EVENT_CAL: 7, EVENT_RDM_CRASH: 8, EVENT_QAPM_PERF: 9, EVENT_EXTERNAL_HEADER: 1e3, EVENT_EXTERNAL_QAPM_SIGKILL: 1001, EVENT_EXTERNAL_QAPM_LAG: 1002 };Object.freeze(u);var d = { RESERVED: 1, QAPM: 2, QAPM_SIGKILL: 4, QAPM_LAG: 8 };Object.freeze(d);var h = { APP_ID: "app_id", USER_ID: "user_id", DEVICE_ID: "device_id", VERSION: "version", BUILD_ID: "build_id", BUCKET: "bucket", ATHENA_HOST: "athena_host", ATHENA_BASE_URL: "athena_base_url", ENABLE_UPLOAD_ATHENA: "enable_upload_athena" };Object.freeze(h);var f = { CLICK: 1, LONG_PRESS: 2, SCROLL: 3, KEY: 4, SCREEN_ROTATION: 5, ZOOM: 6, INPUT: 7, OTHERS: 100 };Object.freeze(f);
    var g = function () {
      function g() {
        _classCallCheck(this, g);

        this.uploadPeriod = 5e3, this.enableUploadAthena = !0, this.athenaHost = "athena.qq.com", this.athenaBaseUrl = "", this.netConfig = { headers: { "Content-Type": "application/json" } };
      }

      _createClass(g, [{
        key: "AthenaUrl",
        get: function get() {
          var e = "";return (e = "" !== this.athenaBaseUrl ? this.athenaBaseUrl : this.athenaHost.startsWith("http") ? this.athenaHost : "https://" + this.athenaHost + "/").endsWith("/") || (e += "/"), e + "entrance/uploadJson/" + C.getInstance().app_id + "/" + C.getInstance().version + "/?format=2&user_id=" + C.getInstance().user_id;
        }
      }]);

      return g;
    }();

    var p = n(1),
        m = n.n(p);var v = n(27);
    var _ = function _(e) {
      _classCallCheck(this, _);

      this.id = v(), this.payload = e, this.maxRetry = 3, this.createTime = new Date().getTime(), this.outofdate = !1;
    };

    var w = function () {
      function w(e) {
        _classCallCheck(this, w);

        return e instanceof _ ? (this.retryInterval = 36e5, this.model = e, window.localStorage ? this.storage = { save: function save(e, t) {
            window.localStorage.setItem(e, t);
          }, fetch: function fetch(e) {
            return window.localStorage.getItem(e);
          }, remove: function remove(e) {
            window.localStorage.removeItem(e);
          } } : document.cookie ? this.storage = { save: function save(e, t) {
            document.cookie = "";
          }, fetch: function fetch() {
            return "";
          }, remove: function remove(e) {
            document.cookie = "";
          } } : this.storage = void 0, this.reTryLater = this.reTryLater.bind(this), this) : void 0;
      }

      _createClass(w, [{
        key: "setRetryInterval",
        value: function setRetryInterval(e) {
          this.retryInterval = e;
        }
      }, {
        key: "json2model",
        value: function json2model(e) {
          return this.model.id = e.id, this.model.data = e.data, this.model.maxRetry = e.maxRetry, this.model.createTime = e.createTime, this.model.outofdate = e.outofdate, this.model;
        }
      }, {
        key: "isOutOfDate",
        value: function isOutOfDate() {
          return new Date().getTime() - this.model.createTime > 864e5;
        }
      }, {
        key: "saveModel",
        value: function saveModel(e) {
          e instanceof _ ? this.storage.save(e.id, JSON.stringify(e)) : r.debug(e, "is not a RetryModel");
        }
      }, {
        key: "fetchModel",
        value: function fetchModel(e) {
          return this.model = this.json2model(JSON.parse(this.storage.fetch(e))), this.model;
        }
      }, {
        key: "deleteModel",
        value: function deleteModel() {
          this.storage.remove(this.model.id);
        }
      }, {
        key: "reUpload",
        value: function reUpload(e, t) {
          r.debug("reupload !"), m.a.post(C.getInstance().config.AthenaUrl, this.model.payload, C.getInstance().config.netConfig).then(function (n) {
            if (n.data && n.data.code) switch (n.data.code) {case 1e3:
                r.debug("upload success !"), e(n);break;case 1500:
                t();}
          }).catch(function (e) {
            r.debug("upload failure"), e.response && (r.error(t.response.data), r.error(t.response.status), r.error(t.response.headers), 504 == t.response.status && t());
          });
        }
      }, {
        key: "reTryLater",
        value: function reTryLater() {
          this.saveModel(this.model), this.timer = setTimeout(function (e) {
            r.debug("1,触发定时器"), e.fetchModel(e.model.id) ? (r.debug("2,fetch model!"), r.debug(e.model), e.isOutOfDate() && (r.debug("3, model is out of date"), e.model.maxRetry = 0, e.deleteModel(e.model.id)), e.model.maxRetry-- > 0 ? (r.debug("4,less than maxRetry :", e.model.maxRetry), e.reUpload(function (t) {
              r.debug("the " + (3 - e.model.maxRetry) + "th reupload success !"), e.deleteModel(e.model.id), r.debug("delete the model");
            }, e.reTryLater)) : (r.debug("4,more than maxRetry"), r.debug("delete the model"), e.deleteModel(e.model.id))) : r.debug("2,fetch model failure ");
          }, this.retryInterval, this);
        }
      }]);

      return w;
    }();

    var y = "EventHandler.js";
    var b = function () {
      function b() {
        _classCallCheck(this, b);

        this.queue = new Array();
      }

      _createClass(b, [{
        key: "offerEvent",
        value: function offerEvent(e) {
          this.queue.push(e);
        }
      }, {
        key: "pollEvent",
        value: function pollEvent() {
          return this.queue.shift();
        }
      }, {
        key: "getCurrentEvents",
        value: function getCurrentEvents() {
          var e = [];for (; !this.isEmpty();) {
            var _t3 = this.pollEvent();e.push(_t3);
          }return e;
        }
      }, {
        key: "isEmpty",
        value: function isEmpty() {
          return 0 == this.queue.length;
        }
      }, {
        key: "retry",
        value: function retry(e) {
          new w(new _(e)).reTryLater();
        }
      }, {
        key: "clearEvent",
        value: function clearEvent() {
          this.queue = new Array();
        }
      }, {
        key: "uploadEvents",
        value: function uploadEvents() {
          var _this = this;

          var e = C.getInstance().config.AthenaUrl,
              t = C.getInstance().config.netConfig;if (b.getInstance().isEmpty()) return void r.debug("events is empty");var n = C.getInstance().meta_json;if (o(n.app_id) || o(n.version) || o(n.device_id) || o(n.display)) return void r.error(y, "uploadEvents", "one of app_id(" + n.app_id + "), version(" + n.version + "), device_id(" + n.device_id + "), display(" + n.display + ") is empty !");var i = { meta: n, events: b.getInstance().getCurrentEvents() };r.debug("eventHandler", "config", t), r.debug("eventHandler", "upload url", e), r.debug("eventHandler", "payload", i), m.a.post(e, i, t).then(function (e) {
            if (r.debug("ok", e.data), e.data && e.data.code) switch (e.data.code) {case 1e3:
                r.debug("upload success !");}
          }).catch(function (e) {
            e.response ? (r.error(y, "uploadEvents", e.response.data), r.error(y, "uploadEvents", e.response.status), r.error(y, "uploadEvents", e.response.headers), 504 === e.response.status && _this.retry(i)) : e.request ? r.error(y, "uploadEvents", "The request was made but no response was received, error.request:", e.request) : r.error(y, "uploadEvents", "Something happened in setting up the request that triggered an Error:", e.message);
          });
        }
      }, {
        key: "size",
        get: function get() {
          return this.queue.length;
        }
      }], [{
        key: "getInstance",
        value: function getInstance() {
          return this.instance || (this.instance = new b()), this.instance;
        }
      }]);

      return b;
    }();

    var E = b;var T = "EventCon.js";
    var C = function () {
      function C() {
        _classCallCheck(this, C);

        this._meta = new l(), this.localStorage = window.localStorage ? window.localStorage : void 0, this.config = new g(), this._ready2upload = !1, this.subscribeCallbacks = [];
      }

      _createClass(C, [{
        key: "init",
        value: function init(e, t, n) {
          this.setField(h.APP_ID, e).setField(h.VERSION, t).setField(h.USER_ID, n), this._ready2upload = this.checkConfig();
        }
      }, {
        key: "checkConfig",
        value: function checkConfig() {
          return !(o(this.user_id) || o(this.app_id) || o(this.user_id) || o(this.host));
        }
      }, {
        key: "start",
        value: function start() {
          this._ready2upload ? (this.timer && (r.error("looper is already exits "), this.stop()), r.debug("begin event loop "), this.timer = setInterval(function () {
            r.debug("looping..."), E.getInstance().uploadEvents();
          }, this.config.uploadPeriod)) : r.error("please init eventcon first !");
        }
      }, {
        key: "stop",
        value: function stop() {
          this.timer && (clearInterval(this.timer), r.debug("end event loop "));
        }
      }, {
        key: "setField",
        value: function setField(e, t) {
          switch (e) {case h.APP_ID:
              this._meta.app_id = t;break;case h.USER_ID:
              this._meta.user_id = t;break;case h.DEVICE_ID:
              this._meta.device_id = t;break;case h.VERSION:
              this._meta.version = t;break;case h.BUILD_ID:
              this._meta.build_id = t;break;case h.BUCKET:
              this._meta.bucket = t;break;case h.ATHENA_HOST:
              this.config.athenaHost = t;break;case h.ATHENA_BASE_URL:
              this.config.athenaBaseUrl = t;break;case h.ENABLE_UPLOAD_ATHENA:
              this.config.enableUploadAthena = t;break;default:
              r.error("EventCon.setField, key MUST NOT be", e);}return this;
        }
      }, {
        key: "setFunctionFlag",
        value: function setFunctionFlag(e, t) {
          this._meta.flag = t ? this._meta.flag | e : this._meta.flag & ~e;
        }
      }, {
        key: "sendEvent",
        value: function sendEvent(e, t) {
          return e.check() ? (this.applySubscribe(e), this.config.enableUploadAthena && (E.getInstance().offerEvent(e), t && E.getInstance().uploadEvents())) : r.error(T, "sendEvent", "some field of event is null! =>", e), e.id;
        }
      }, {
        key: "sendUnloadEvent",
        value: function sendUnloadEvent(e) {
          var t = C.getInstance().config.AthenaUrl,
              n = C.getInstance().meta;if (o(n.app_id) || o(n.version) || o(n.device_id) || o(n.display)) return void r.error(T, "uploadEvents", "one of app_id, version, device_id, display is empty !");var i = { meta: n, events: [e] },
              a = new Blob([JSON.stringify(i)], { type: "text/plain" });navigator.sendBeacon(t, a);
        }
      }, {
        key: "getEventLogs",
        value: function getEventLogs() {}
      }, {
        key: "subscribe",
        value: function subscribe(e) {
          a(e) || r.error('EventCon.subscribe, error, param "callback" MUST be function'), this.subscribeCallbacks.indexOf(e) > -1 ? r.log("EventCon.subscribe, already subscribed,", e) : this.subscribeCallbacks.push(e);
        }
      }, {
        key: "applySubscribe",
        value: function applySubscribe(e) {
          this.subscribeCallbacks.forEach(function (t) {
            var n = { meta: C.getInstance().meta_json, event: e };if (a(t)) try {
              t(n);
            } catch (e) {
              r.error("EventCon.applySubscribe, user callback failed", t, e);
            }
          });
        }
      }, {
        key: "meta",
        get: function get() {
          return this._meta;
        }
      }, {
        key: "meta_json",
        get: function get() {
          return this._meta.metaObj;
        }
      }, {
        key: "user_id",
        get: function get() {
          return this.meta.userId;
        }
      }, {
        key: "app_id",
        get: function get() {
          return this.meta.app_id;
        }
      }, {
        key: "version",
        get: function get() {
          return this.meta.version;
        }
      }, {
        key: "host",
        get: function get() {
          return this.config.athenaHost;
        }
      }, {
        key: "uploadPeriod",
        set: function set(e) {
          this.config.uploadPeriod = e, this._start();
        }
      }], [{
        key: "registerWindow",
        value: function registerWindow() {
          window.eventcon = window.eventcon || C.getInstance();
        }
      }, {
        key: "getInstance",
        value: function getInstance() {
          return this._instance || (this._instance = new C()), this._instance;
        }
      }]);

      return C;
    }();

    var O = function () {
      function O() {
        _classCallCheck(this, O);

        this.id = s(), this.time = new Date().toISOString(), this.topic = u.EVENT_BASE, this.extra = "";
      }

      _createClass(O, [{
        key: "setTime",
        value: function setTime(e) {
          this.time = new Date(e).toISOString();
        }
      }, {
        key: "check",
        value: function check() {
          return !(o(this.id) || o(this.time) || o(this.topic));
        }
      }, {
        key: "jsonstr",
        get: function get() {
          return JSON.stringify(this);
        }
      }]);

      return O;
    }();

    var k = function (_O) {
      _inherits(k, _O);

      function k() {
        var _this2;

        _classCallCheck(this, k);

        (_this2 = _possibleConstructorReturn(this, (k.__proto__ || Object.getPrototypeOf(k)).call(this)), _this2), _this2.topic = u.EVENT_APP;return _this2;
      }

      return k;
    }(O);

    var S = function (_k) {
      _inherits(S, _k);

      function S() {
        var _this3;

        _classCallCheck(this, S);

        (_this3 = _possibleConstructorReturn(this, (S.__proto__ || Object.getPrototypeOf(S)).call(this)), _this3), _this3.topic = u.EVENT_PAGE_CHANGE, _this3.pre_page_id = "", _this3.pre_page = "", _this3.page_id = "", _this3.page = "", _this3.pre_page_start = 0, _this3.pre_page_end = 0, _this3.page_start = 0;return _this3;
      }

      _createClass(S, [{
        key: "check",
        value: function check() {
          return _get(S.prototype.__proto__ || Object.getPrototypeOf(S.prototype), "check", this).call(this) && !(o(this.pre_page_id) || o(this.pre_page) || o(this.page_id) || o(this.page) || o(this.pre_page_start) || o(this.pre_page_end) || o(this.pre_page_start));
        }
      }]);

      return S;
    }(k);

    var A = function (_k2) {
      _inherits(A, _k2);

      function A() {
        var _this4;

        _classCallCheck(this, A);

        (_this4 = _possibleConstructorReturn(this, (A.__proto__ || Object.getPrototypeOf(A)).call(this)), _this4), _this4.topic = u.EVENT_UI_ACTION, _this4.op = -1, _this4.data = {}, _this4.view_pos = "", _this4.view_type = "", _this4.view_tag = "", _this4.view_text = "", _this4.view_desc = "", _this4.view_super = "", _this4.page = "", _this4.page_id = "";return _this4;
      }

      _createClass(A, [{
        key: "check",
        value: function check() {
          return _get(A.prototype.__proto__ || Object.getPrototypeOf(A.prototype), "check", this).call(this) && !(o(this.page) || o(this.page_id) || o(this.op) || o(this.view_tag));
        }
      }]);

      return A;
    }(k);

    var R = function (_k3) {
      _inherits(R, _k3);

      function R(e) {
        var _this5;

        _classCallCheck(this, R);

        (_this5 = _possibleConstructorReturn(this, (R.__proto__ || Object.getPrototypeOf(R)).call(this)), _this5), _this5.topic = u.EVENT_CAL, _this5.category = "", _this5.action = "", _this5.label = "", _this5.value = 0, _this5.extra = e;return _this5;
      }

      _createClass(R, [{
        key: "check",
        value: function check() {
          return _get(R.prototype.__proto__ || Object.getPrototypeOf(R.prototype), "check", this).call(this) && !o(this.category);
        }
      }]);

      return R;
    }(k);

    var I = function () {
      function I() {
        _classCallCheck(this, I);
      }

      _createClass(I, null, [{
        key: "reverse",
        value: function reverse(e) {
          return e.split("").reverse().join("");
        }
      }, {
        key: "fold",
        value: function fold(e, t) {
          var n = e.slice(0, t),
              r = e.slice(t);return I.reverse(r) + n;
        }
      }, {
        key: "unfold",
        value: function unfold(e, t) {
          var n = e.slice(0, t);return e.slice(t) + I.reverse(n);
        }
      }, {
        key: "encodeOnce",
        value: function encodeOnce(e) {
          return I.fold(e, e.length / 4);
        }
      }, {
        key: "encode",
        value: function encode(e, t) {
          t = t || 3;var n = window.btoa(e);for (var _e2 = 0; _e2 < t; _e2++) {
            n = I.encodeOnce(n);
          }return n;
        }
      }, {
        key: "decodeOnce",
        value: function decodeOnce(e) {
          return I.unfold(e, e.length - e.length / 4);
        }
      }, {
        key: "decode",
        value: function decode(e, t) {
          t = t || 3;var n = e;for (var _e3 = 0; _e3 < t; _e3++) {
            n = I.decodeOnce(n);
          }return window.atob(n);
        }
      }]);

      return I;
    }();

    n.d(t, "EventCon", function () {
      return C;
    }), n.d(t, "FunctionFlag", function () {
      return d;
    }), n.d(t, "Field", function () {
      return h;
    }), n.d(t, "UiAction", function () {
      return f;
    }), n.d(t, "EventPageChange", function () {
      return S;
    }), n.d(t, "EventUiAction", function () {
      return A;
    }), n.d(t, "EventCAL", function () {
      return R;
    }), n.d(t, "epoch2String", function () {
      return i;
    }), n.d(t, "Fold", function () {
      return I;
    });var x = { EventCon: C, EventPageChange: S, EventUiAction: A, EventCAL: R, epoch2String: i, FunctionFlag: d, Field: h, UiAction: f, Fold: I };window.EventCon = window.EventCon || x, window.addEventListener("load", C.registerWindow, !1);
  }]);
}, function (e, t, n) {
  window, e.exports = function (e) {
    var t = {};function n(r) {
      if (t[r]) return t[r].exports;var i = t[r] = { i: r, l: !1, exports: {} };return e[r].call(i.exports, i, i.exports, n), i.l = !0, i.exports;
    }return n.m = e, n.c = t, n.d = function (e, t, r) {
      n.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: r });
    }, n.r = function (e) {
      "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e, "__esModule", { value: !0 });
    }, n.t = function (e, t) {
      if (1 & t && (e = n(e)), 8 & t) return e;if (4 & t && "object" == (typeof e === "undefined" ? "undefined" : _typeof(e)) && e && e.__esModule) return e;var r = Object.create(null);if (n.r(r), Object.defineProperty(r, "default", { enumerable: !0, value: e }), 2 & t && "string" != typeof e) for (var i in e) {
        n.d(r, i, function (t) {
          return e[t];
        }.bind(null, i));
      }return r;
    }, n.n = function (e) {
      var t = e && e.__esModule ? function () {
        return e.default;
      } : function () {
        return e;
      };return n.d(t, "a", t), t;
    }, n.o = function (e, t) {
      return Object.prototype.hasOwnProperty.call(e, t);
    }, n.p = "", n(n.s = 0);
  }([function (e, t, n) {
    "use strict";
    n.r(t);var r = { logLevel: "debug", levelMap: { debug: 1, info: 2, log: 3, warn: 4, error: 5, none: 6 }, enableLogLevel: function enableLogLevel(e) {
        var t = this.levelMap[e];if (null == t || void 0 === t) return !1;var n = this.levelMap[this.logLevel];return null != e && void 0 !== e && t >= n;
      },
      debug: function debug() {
        var _console3;

        for (var _len = arguments.length, e = Array(_len), _key = 0; _key < _len; _key++) {
          e[_key] = arguments[_key];
        }

        this.enableLogLevel("debug") && (_console3 = console).debug.apply(_console3, ["track.js,"].concat(e));
      }, log: function log() {
        var _console4;

        for (var _len2 = arguments.length, e = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          e[_key2] = arguments[_key2];
        }

        this.enableLogLevel("log") && (_console4 = console).log.apply(_console4, ["track.js,"].concat(e));
      }, error: function error() {
        var _console5;

        for (var _len3 = arguments.length, e = Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
          e[_key3] = arguments[_key3];
        }

        this.enableLogLevel("error") && (_console5 = console).error.apply(_console5, ["track.js,"].concat(e));
      } };function i(e) {
      if ("" !== e.id && e.id) return 'id("' + e.id + '")';if (e === document.body) return e.tagName;if (e === document) return "document";var t = 0;if (e.parentNode) {
        var _n2 = e.parentNode.childNodes;for (var _r2 = 0; _r2 < _n2.length; _r2++) {
          var _o = _n2[_r2];if (_o === e) return i(e.parentNode) + "/" + e.tagName + "[" + (t + 1) + "]";1 === _o.nodeType && _o.tagName === e.tagName && t++;
        }
      }
    }function o(e) {
      var t = "",
          n = e.nodeType;if (1 === n || 9 === n || 11 === n) {
        if ("string" == typeof e.textContent) return e.textContent;for (e = e.firstChild; e; e = e.nextSibling) {
          t += o(e);
        }
      } else if (3 === n || 4 === n) return e.nodeValue;return t;
    }
    /*!
     * long-press-event.js
     * Pure JavaScript long-press-event
     * https://github.com/john-doherty/long-press-event
     * @author John Doherty <www.johndoherty.info>
     * @license MIT
     */var a = window.Element.prototype;a.matches || a.matchesSelector || a.webkitMatchesSelector || a.mozMatchesSelector || a.msMatchesSelector || a.oMatchesSelector;var s = "80",
        c = "443",
        l = RegExp(":(" + s + "|" + c + ")$"),
        u = document.createElement("a"),
        d = {};function h(e) {
      if (e = e && "." != e ? e : location.href, d[e]) return d[e];if (u.href = e, "." == e.charAt(0) || "/" == e.charAt(0)) return h(u.href);var t = u.port == s || u.port == c ? "" : u.port;t = "0" == t ? "" : t;var n = u.host.replace(l, ""),
          r = u.origin ? u.origin : u.protocol + "//" + n,
          i = "/" == u.pathname.charAt(0) ? u.pathname : "/" + u.pathname;return d[e] = { hash: u.hash, host: n, hostname: u.hostname, href: u.href, origin: r, pathname: i, port: t, protocol: u.protocol, search: u.search };
    }var f = [];
    var g = function () {
      _createClass(g, null, [{
        key: "add",
        value: function add(e, t, n) {
          (function (e, t) {
            var n = p(e, t);return n || (n = new g(e, t), f.push(n)), n;
          })(e, t).add(n);
        }
      }, {
        key: "remove",
        value: function remove(e, t, n) {
          var r = p(e, t);r && r.remove(n);
        }
      }]);

      function g(e, t) {
        var _this6 = this;

        _classCallCheck(this, g);

        this.context = e, this.methodName = t, this.isTask = /Task$/.test(t), this.originalMethodReference = this.isTask ? e.get(t) : e[t], this.methodChain = [], this.boundMethodChain = [], this.wrappedMethod = function () {
          return (0, _this6.boundMethodChain[_this6.boundMethodChain.length - 1]).apply(undefined, arguments);
        }, this.isTask ? e.set(t, this.wrappedMethod) : e[t] = this.wrappedMethod;
      }

      _createClass(g, [{
        key: "add",
        value: function add(e) {
          this.methodChain.push(e), this.rebindMethodChain();
        }
      }, {
        key: "remove",
        value: function remove(e) {
          var t = this.methodChain.indexOf(e);t > -1 && (this.methodChain.splice(t, 1), this.methodChain.length > 0 ? this.rebindMethodChain() : this.destroy());
        }
      }, {
        key: "rebindMethodChain",
        value: function rebindMethodChain() {
          this.boundMethodChain = [];for (var _e4, _t4 = 0; _e4 = this.methodChain[_t4]; _t4++) {
            var _n3 = this.boundMethodChain[_t4 - 1] || this.originalMethodReference.bind(this.context);this.boundMethodChain.push(_e4(_n3));
          }
        }
      }, {
        key: "destroy",
        value: function destroy() {
          var e = f.indexOf(this);e > -1 && (f.splice(e, 1), this.isTask ? this.context.set(this.methodName, this.originalMethodReference) : this.context[this.methodName] = this.originalMethodReference);
        }
      }]);

      return g;
    }();

    function p(e, t) {
      return f.filter(function (n) {
        return n.context == e && n.methodName == t;
      })[0];
    }var m = "2.4.1",
        v = "i5iSjo",
        _ = "_av",
        w = "_au",
        y = Object.assign || function (e) {
      for (var _len4 = arguments.length, t = Array(_len4 > 1 ? _len4 - 1 : 0), _key4 = 1; _key4 < _len4; _key4++) {
        t[_key4 - 1] = arguments[_key4];
      }

      for (var _n4 = 0, _r3 = t.length; _n4 < _r3; _n4++) {
        var _r4 = Object(t[_n4]);for (var _t5 in _r4) {
          Object.prototype.hasOwnProperty.call(_r4, _t5) && (e[_t5] = _r4[_t5]);
        }
      }return e;
    },
        b = function e(t) {
      return t ? (t ^ 16 * Math.random() >> t / 4).toString(16) : ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, e);
    };function E(e, t) {
      var n = window.GoogleAnalyticsObject || "ga";window[n] = window[n] || function () {
        for (var _len5 = arguments.length, e = Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
          e[_key5] = arguments[_key5];
        }

        (window[n].q = window[n].q || []).push(e);
      }, window.gaDevIds = window.gaDevIds || [], window.gaDevIds.indexOf(v) < 0 && window.gaDevIds.push(v), window[n]("provide", e, t), window.gaplugins = window.gaplugins || {}, window.gaplugins[function (e) {
        return e.charAt(0).toUpperCase() + e.slice(1);
      }(e)] = t;
    }var T = function T() {
      return +new Date();
    },
        C = "function" == typeof requestIdleCallback,
        O = C ? requestIdleCallback : function (e) {
      var t = new (function () {
        function _class(e) {
          _classCallCheck(this, _class);

          this.initTime_ = e;
        }

        _createClass(_class, [{
          key: "timeRemaining",
          value: function timeRemaining() {
            return Math.max(0, 50 - (T() - this.initTime_));
          }
        }, {
          key: "didTimeout",
          get: function get() {
            return !1;
          }
        }]);

        return _class;
      }())(T());return setTimeout(function () {
        return e(t);
      }, 0);
    },
        k = C ? cancelIdleCallback : function (e) {
      clearTimeout(e);
    };
    var S = function () {
      function S(e) {
        var _this7 = this;

        _classCallCheck(this, S);

        this.init_ = e, this.valueSet_ = !1, this.value_, this.idleHandle_ = O(function () {
          return _this7.setValue();
        });
      }

      _createClass(S, [{
        key: "getValue",
        value: function getValue() {
          return this.valueSet_ || this.setValue(), this.value_;
        }
      }, {
        key: "setValue",
        value: function setValue() {
          var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.init_();
          this.cancleIdleInit_(), this.value_ = e, this.valueSet_ = !0;
        }
      }, {
        key: "cancleIdleInit_",
        value: function cancleIdleInit_() {
          this.idleHandle_ && (k(this.idleHandle_), this.idleHandle_ = null);
        }
      }]);

      return S;
    }();

    var A = function () {
      function A() {
        _classCallCheck(this, A);

        this.registry_ = {};
      }

      _createClass(A, [{
        key: "on",
        value: function on(e, t) {
          this.getRegistry_(e).push(t);
        }
      }, {
        key: "off",
        value: function off(e, t) {
          if (e && t) {
            var _n5 = this.getRegistry_(e),
                _r5 = _n5.indexOf(t);_r5 > -1 && _n5.splice(_r5, 1);
          } else this.registry_ = {};
        }
      }, {
        key: "emit",
        value: function emit(e) {
          for (var _len6 = arguments.length, t = Array(_len6 > 1 ? _len6 - 1 : 0), _key6 = 1; _key6 < _len6; _key6++) {
            t[_key6 - 1] = arguments[_key6];
          }

          this.getRegistry_(e).forEach(function (e) {
            return e.apply(undefined, t);
          });
        }
      }, {
        key: "getRegistry_",
        value: function getRegistry_(e) {
          return this.registry_[e] = this.registry_[e] || [];
        }
      }]);

      return A;
    }();

    var R = "autotrack",
        I = {};var x = void 0,
        N = !1;
    var L = function (_A) {
      _inherits(L, _A);

      _createClass(L, null, [{
        key: "getOrCreate",
        value: function getOrCreate(e, t) {
          var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
          var r = [R, e, t].join(":");return r in I || (I[r] = { references: 0, value: new L(r, n) }), N || (window.addEventListener("storage", U), N = !0), ++I[r].references, I[r].value;
        }
      }, {
        key: "isSupported_",
        value: function isSupported_() {
          if (null != x) return x;try {
            window.localStorage.setItem(R, R), window.localStorage.removeItem(R), x = !0;
          } catch (e) {
            x = !1;
          }return x;
        }
      }, {
        key: "get_",
        value: function get_(e) {
          return window.localStorage.getItem(e);
        }
      }, {
        key: "set_",
        value: function set_(e, t) {
          window.localStorage.setItem(e, t);
        }
      }, {
        key: "clear_",
        value: function clear_(e) {
          window.localStorage.removeItem(e);
        }
      }]);

      function L(e) {
        var _this8;

        var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

        _classCallCheck(this, L);

        (_this8 = _possibleConstructorReturn(this, (L.__proto__ || Object.getPrototypeOf(L)).call(this)), _this8), _this8.key_ = e, _this8.defaults_ = t.defaults || {}, _this8.timestampKey_ = t.timestampKey, _this8.cache_ = new S(function () {
          return _this8.read_();
        });return _this8;
      }

      _createClass(L, [{
        key: "update",
        value: function update(e) {
          var t = this.timestampKey_;var n = void 0;if (t && "number" == typeof e[t]) {
            if ("number" == typeof (n = this.read_() || {})[t] && n[t] > e[t]) return;
          } else n = this.data;var r = y(n, e);if (this.cache_.setValue(r), L.isSupported_()) try {
            L.set_(this.key_, JSON.stringify(r));
          } catch (e) {}
        }
      }, {
        key: "clear",
        value: function clear() {
          if (this.cache_.setValue({}), L.isSupported_()) try {
            L.clear_(this.key_);
          } catch (e) {}
        }
      }, {
        key: "destroy",
        value: function destroy() {
          --I[this.key_].references, 0 === I[this.key_].references && (this.clear(), delete I[this.key_]), 0 === Object.keys(I).length && (window.removeEventListener("storage", U), N = !1);
        }
      }, {
        key: "read_",
        value: function read_() {
          if (L.isSupported_()) try {
            return P(L.get_(this.key_));
          } catch (e) {}
        }
      }, {
        key: "data",
        get: function get() {
          return y({}, this.defaults_, this.cache_.getValue());
        }
      }]);

      return L;
    }(A);

    function U(e) {
      if (e.key in I) {
        var _t6 = I[e.key].value,
            _n6 = y({}, _t6.defaults_, P(e.oldValue)),
            _r6 = y({}, _t6.defaults_, P(e.newValue));_t6.cache_.setValue(_r6), _t6.emit("externalSet", _r6, _n6);
      }
    }function P(e) {
      var t = {};if (e) try {
        t = JSON.parse(e);
      } catch (e) {}return t;
    }var D = 6e4,
        j = {};
    var M = function () {
      _createClass(M, null, [{
        key: "getOrCreate",
        value: function getOrCreate(e, t, n) {
          var r = e.get("trackingId");return r in j || (j[r] = { references: 0, value: new M(e, t, n) }), ++j[r].references, j[r].value;
        }
      }]);

      function M(e, t, n) {
        var _this9 = this;

        _classCallCheck(this, M);

        this.tracker = e, this.timeout = t || M.DEFAULT_TIMEOUT, this.timeZone = n, this.sendHitTaskOverride = this.sendHitTaskOverride.bind(this), this.idleStore_ = new S(function () {
          var t = L.getOrCreate(e.get("trackingId"), "session", { defaults: { hitTime: 0, isExpired: !1 }, timestampKey: "hitTime" });return t.data.id || t.update({ id: b() }), t;
        }), this.idleDateTimeFormatter_ = new S(function () {
          if (_this9.timeZone) try {
            return new Intl.DateTimeFormat("en-US", { timeZone: _this9.timeZone });
          } catch (e) {}return null;
        }), g.add(e, "sendHitTask", this.sendHitTaskOverride);
      }

      _createClass(M, [{
        key: "isExpired",
        value: function isExpired() {
          var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.id;
          if (e != this.id) return !0;var t = this.store_.data;if (t.isExpired) return !0;var n = t.hitTime;if (n) {
            var _e5 = new Date(),
                _t7 = new Date(n);if (_e5 - _t7 > this.timeout * D || this.datesAreDifferentInTimezone(_e5, _t7)) return !0;
          }return !1;
        }
      }, {
        key: "datesAreDifferentInTimezone",
        value: function datesAreDifferentInTimezone(e, t) {
          return !!this.dateTimeFormatter_ && this.dateTimeFormatter_.format(e) != this.dateTimeFormatter_.format(t);
        }
      }, {
        key: "sendHitTaskOverride",
        value: function sendHitTaskOverride(e) {
          var _this10 = this;

          return function (t) {
            e(t);var n = t.get("sessionControl"),
                r = "start" == n || _this10.isExpired(),
                i = "end" == n,
                o = _this10.store_.data;o.hitTime = +new Date(), r && (o.isExpired = !1, o.id = b()), i && (o.isExpired = !0), _this10.store_.update(o);
          };
        }
      }, {
        key: "destroy",
        value: function destroy() {
          var e = this.tracker.get("trackingId");--j[e].references, 0 === j[e].references && (g.remove(this.tracker, "sendHitTask", this.sendHitTaskOverride), this.store_.destroy(), delete j[e]);
        }
      }, {
        key: "store_",
        get: function get() {
          return this.idleStore_.getValue();
        }
      }, {
        key: "dateTimeFormatter_",
        get: function get() {
          return this.idleDateTimeFormatter_.getValue();
        }
      }, {
        key: "id",
        get: function get() {
          return this.store_.data.id;
        }
      }]);

      return M;
    }();

    M.DEFAULT_TIMEOUT = 30;var H = "function" == typeof Promise && Promise.toString().indexOf("[native code]") > -1 ? function (e) {
      Promise.resolve().then(e);
    } : function () {
      var e = 0,
          t = [];var n = new MutationObserver(function () {
        t.forEach(function (e) {
          return e();
        }), t = [];
      }),
          r = document.createTextNode("");return n.observe(r, { characterData: !0 }), function (n) {
        t.push(n), r.data = String(++e % 2);
      };
    }(),
        F = 0,
        V = !("object" != (typeof safari === "undefined" ? "undefined" : _typeof(safari)) || !safari.pushNotification);
    var W = function () {
      function W() {
        var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
            _ref$ensureTasksRun = _ref.ensureTasksRun,
            e = _ref$ensureTasksRun === undefined ? !1 : _ref$ensureTasksRun,
            _ref$defaultMinTaskTi = _ref.defaultMinTaskTime,
            t = _ref$defaultMinTaskTi === undefined ? F : _ref$defaultMinTaskTi;

        _classCallCheck(this, W);

        this.idleCallbackHandle_ = null, this.taskQueue_ = [], this.isProcessing_ = !1, this.state_ = null, this.defaultMinTaskTime_ = t, this.ensureTasksRun_ = e, this.runTasksImmediately = this.runTasksImmediately.bind(this), this.runTasks_ = this.runTasks_.bind(this), this.onVisibilityChange_ = this.onVisibilityChange_.bind(this), this.ensureTasksRun_ && (addEventListener("visibilitychange", this.onVisibilityChange_, !0), V && addEventListener("beforeunload", this.runTasksImmediately, !0));
      }

      _createClass(W, [{
        key: "pushTask",
        value: function pushTask() {
          for (var _len7 = arguments.length, e = Array(_len7), _key7 = 0; _key7 < _len7; _key7++) {
            e[_key7] = arguments[_key7];
          }

          this.addTask_.apply(this, [Array.prototype.push].concat(e));
        }
      }, {
        key: "unshiftTask",
        value: function unshiftTask() {
          for (var _len8 = arguments.length, e = Array(_len8), _key8 = 0; _key8 < _len8; _key8++) {
            e[_key8] = arguments[_key8];
          }

          this.addTask_.apply(this, [Array.prototype.unshift].concat(e));
        }
      }, {
        key: "runTasksImmediately",
        value: function runTasksImmediately() {
          this.runTasks_();
        }
      }, {
        key: "hasPendingTasks",
        value: function hasPendingTasks() {
          return this.taskQueue_.length > 0;
        }
      }, {
        key: "clearPendingTasks",
        value: function clearPendingTasks() {
          this.taskQueue_ = [], this.cancelScheduledRun_();
        }
      }, {
        key: "getState",
        value: function getState() {
          return this.state_;
        }
      }, {
        key: "destroy",
        value: function destroy() {
          this.taskQueue_ = [], this.cancelScheduledRun_(), this.ensureTasksRun_ && (removeEventListener("visibilitychange", this.onVisibilityChange_, !0), V && removeEventListener("beforeunload", this.runTasksImmediately, !0));
        }
      }, {
        key: "addTask_",
        value: function addTask_(e, t) {
          var _ref2 = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {},
              _ref2$minTaskTime = _ref2.minTaskTime,
              n = _ref2$minTaskTime === undefined ? this.defaultMinTaskTime_ : _ref2$minTaskTime;

          var r = { time: T(), visibilityState: document.visibilityState };e.call(this.taskQueue_, { state: r, task: t, minTaskTime: n }), this.scheduleTasksToRun_();
        }
      }, {
        key: "scheduleTasksToRun_",
        value: function scheduleTasksToRun_() {
          this.ensureTasksRun_ && "hidden" === document.visibilityState ? H(this.runTasks_) : this.idleCallbackHandle_ || (this.idleCallbackHandle_ = O(this.runTasks_));
        }
      }, {
        key: "runTasks_",
        value: function runTasks_(e) {
          if (this.cancelScheduledRun_(), !this.isProcessing_) {
            for (this.isProcessing_ = !0; this.hasPendingTasks() && !B(e, this.taskQueue_[0].minTaskTime);) {
              var _taskQueue_$shift = this.taskQueue_.shift(),
                  _e6 = _taskQueue_$shift.task,
                  _t8 = _taskQueue_$shift.state;

              this.state_ = _t8, _e6(_t8), this.state_ = null;
            }this.isProcessing_ = !1, this.hasPendingTasks() && this.scheduleTasksToRun_();
          }
        }
      }, {
        key: "cancelScheduledRun_",
        value: function cancelScheduledRun_() {
          k(this.idleCallbackHandle_), this.idleCallbackHandle_ = null;
        }
      }, {
        key: "onVisibilityChange_",
        value: function onVisibilityChange_() {
          "hidden" === document.visibilityState && this.runTasksImmediately();
        }
      }]);

      return W;
    }();

    var B = function B(e, t) {
      return !!(e && e.timeRemaining() <= t);
    },
        q = {};
    var $ = function (_W) {
      _inherits($, _W);

      _createClass($, null, [{
        key: "getOrCreate",
        value: function getOrCreate(e) {
          return e in q || (q[e] = { references: 0, value: new $(e) }), ++q[e].references, q[e].value;
        }
      }]);

      function $(e) {
        var _this11;

        _classCallCheck(this, $);

        (_this11 = _possibleConstructorReturn(this, ($.__proto__ || Object.getPrototypeOf($)).call(this, { defaultMinTaskTime: 25, ensureTasksRun: !0 })), _this11), _this11.trackingId_ = e;return _this11;
      }

      _createClass($, [{
        key: "destroy",
        value: function destroy() {
          --q[this.trackingId_].references, 0 === q[this.trackingId_].references && (_get($.prototype.__proto__ || Object.getPrototypeOf($.prototype), "destroy", this).call(this), delete q[this.trackingId_]);
        }
      }]);

      return $;
    }(W);

    var G = { CLEAN_URL_TRACKER: 1, EVENT_TRACKER: 2, IMPRESSION_TRACKER: 3, MEDIA_QUERY_TRACKER: 4, OUTBOUND_FORM_TRACKER: 5, OUTBOUND_LINK_TRACKER: 6, PAGE_VISIBILITY_TRACKER: 7, SOCIAL_WIDGET_TRACKER: 8, URL_CHANGE_TRACKER: 9, MAX_SCROLL_TRACKER: 10, GOD_TRACKER: 11, ELEMENT_WATCH_TRACKER: 12, DOM_EVENT_TRACKER: 13, CONSOLE_TRACKER: 14, PERFORMANCE_TRACKER: 15, METRICS_TRACKER: 16, PAGE_CHANGE_TRACKER: 17 },
        K = Object.keys(G).length;function z(e, t) {
      !function (e) {
        e.set("&" + _, m);
      }(e), function (e, t) {
        var n = function (e, t) {
          if (e.length < t) {
            var _n7 = t - e.length;for (; _n7;) {
              e = "0" + e, _n7--;
            }
          }return e;
        }(function (e) {
          return parseInt(e || "0", 16).toString(2);
        }(e.get("&" + w)), K);n = function (e, t) {
          return e.substr(0, t) + 1 + e.substr(t + 1);
        }(n, K - t), e.set("&" + w, parseInt("0", 2).toString(16));
      }(e, t);
    }var J = { PAGE_CHANGE: "PAGE_CHANGE", UI_ACTION: "UI_ACTION" },
        X = { RESOURCE_ERROR: "_H5.RESOURCE_ERROR", NETWORK_ONLINE: "_H5.NETWORK_ONLINE", NETWORK_OFFLINE: "_H5.NETWORK_OFFLINE", WINDOW_UNLOAD: "_H5.WINDOW_UNLOAD", WINDOW_LOAD: "_H5.WINDOW_LOAD", WINDOW_BEFOREUNLOAD: "_H5.WINDOW_BEFOREUNLOAD", CONSOLE: "_H5.CONSOLE", ELEM_WATCH: "_H5.ELEM_WATCH", METRICS: "_H5.METRICS", WINDOW_PERFORMANCE_LOAD: "_H5.WINDOW_PERFORMANCE_LOAD", WINDOW_PERFORMANCE_PAINT: "_H5.WINDOW_PERFORMANCE_PAINT" };
    var Q = function () {
      function Q() {
        _classCallCheck(this, Q);
      }

      _createClass(Q, null, [{
        key: "deliver",
        value: function deliver(e, t) {
          switch (r.log("EventBus, deliver event:", e, t), e) {case J.PAGE_CHANGE:
              r.log("EventBus, deliver event PAGE_CHANGE: " + t.pre_page_id + " -> " + t.page_id), Q.handleEventPageChangeDefault(t, !1);break;case J.UI_ACTION:
              Q.handleEventUIActionDefault(t, !1);break;case X.METRICS:
              Q.handleEventCALDefault(t, !1);break;case X.WINDOW_BEFOREUNLOAD:case X.WINDOW_LOAD:case X.WINDOW_UNLOAD:
              Q.handleEventCALClose(t);break;case X.NETWORK_ONLINE:case X.NETWORK_OFFLINE:case X.RESOURCE_ERROR:
              Q.handleEventCALDefault(t, !0);break;case X.WINDOW_PERFORMANCE_LOAD:case X.WINDOW_PERFORMANCE_PAINT:case X.CONSOLE:case X.ELEM_WATCH:
              Q.handleEventCALDefault(t, !1);break;default:
              r.log("EventBus, deliver event ignore: " + e, t);}
        }
      }, {
        key: "handleEventCALDefault",
        value: function handleEventCALDefault(e, t) {
          var n = Q.EventCon,
              r = n.EventCAL,
              i = n.EventCon.getInstance(),
              o = new r();for (var _t9 in e) {
            e.hasOwnProperty(_t9) && (o[_t9] = e[_t9]);
          }"extra" in o && !(o.extra instanceof String) && (o.extra = JSON.stringify(o.extra)), i.sendEvent(o, t);
        }
      }, {
        key: "handleEventCALClose",
        value: function handleEventCALClose(e) {
          var t = Q.EventCon,
              n = t.EventCAL,
              r = t.EventCon.getInstance(),
              i = new n();for (var _t10 in e) {
            e.hasOwnProperty(_t10) && (i[_t10] = e[_t10]);
          }"extra" in i && !(i.extra instanceof String) && (i.extra = JSON.stringify(i.extra)), r.sendUnloadEvent(i);
        }
      }, {
        key: "handleEventUIActionDefault",
        value: function handleEventUIActionDefault(e, t) {
          var n = Q.EventCon,
              r = n.EventCon.getInstance(),
              i = new n.EventUiAction();"extra" in e && !(e.extra instanceof String) && (e.extra = JSON.stringify(e.extra)), "op" in e && e.op in n.UiAction && (e.op = n.UiAction[e.op]);for (var _t11 in e) {
            e.hasOwnProperty(_t11) && (i[_t11] = e[_t11]);
          }r.sendEvent(i, t);
        }
      }, {
        key: "handleEventPageChangeDefault",
        value: function handleEventPageChangeDefault(e, t) {
          var n = Q.EventCon,
              r = n.EventCon.getInstance(),
              i = new n.EventPageChange();"extra" in e && !(e.extra instanceof String) && (e.extra = JSON.stringify(e.extra)), "pre_page_start" in e && (e.pre_page_start = n.epoch2String(e.pre_page_start)), "page_start" in e && (e.page_start = n.epoch2String(e.page_start)), "pre_page_end" in e && (e.pre_page_end = n.epoch2String(e.pre_page_end));for (var _t12 in e) {
            e.hasOwnProperty(_t12) && (i[_t12] = e[_t12]);
          }r.sendEvent(i, t);
        }
      }, {
        key: "EventCon",
        get: function get() {
          return window.EventCon;
        }
      }]);

      return Q;
    }();

    var Z = function Z(e) {
      return !!(e && e.constructor && e.call && e.apply);
    },
        Y = { Boolean: 1, Number: 1, String: 1, Function: 1, Array: 1, Date: 1, RegExp: 1, Object: 1, Error: 1 },
        ee = Object.prototype.toString,
        te = function te(e) {
      if (null == e) return String(e);var t = typeof e === "undefined" ? "undefined" : _typeof(e);return "object" === t || "function" === t ? (t = ee.call(e).slice(8, -1), Y[t] ? t.toLowerCase() : "object") : typeof e === "undefined" ? "undefined" : _typeof(e);
    },
        ne = function ne(e) {
      return "array" === te(e);
    },
        re = function re() {
      var e = window.top.location;return e.pathname + e.search;
    },
        ie = function ie() {
      var e = window.top.location;return e.protocol + "//" + e.hostname + e.pathname + e.search;
    },
        oe = function oe(e, t) {
      e = e || ie();try {
        return t instanceof RegExp ? null !== e.match(t) : "string" == typeof t || t instanceof String ? t.startsWith("http") ? e.startsWith(t) : h(e).pathname.startsWith(t) : (r.error("isUrlMatch, the urlFilter MUST be: RegExp | string,", t), !1);
      } catch (n) {
        r.error("isUrlMatch, exception,", e, t, n);
      }
    },
        ae = function ae(e) {
      var t = ce(e);t && (e = t[1]);var n = {};if (!e) return n;for (var r = /(?:&|\?)?([^\?&]+)=([^&]*)(?:&|$)/g; t = r.exec(e);) {
        var i = le(t[1]),
            o = le(t[2]),
            a = n[i];"string" == typeof a ? (n[i] = [a], n[i][1] = o) : a ? a[a.length] = o : n[i] = o;
      }return n;
    },
        se = function se(e) {
      if (!e) return "";var t = [],
          n = /\[\]$/,
          r = encodeURIComponent,
          i = function i(e, n) {
        n = "function" == typeof n ? n() : null == n ? "" : n, t[t.length] = r(e) + "=" + r(n);
      },
          o = function o(e, r) {
        var a, s, c;switch (te(r)) {case "array":
            if (e) for (a = 0, c = r.length; a < c; a++) {
              if (n.test(e)) i(e, r[a]);else {
                var l = "object" === te(r[a]) ? a : "";o(e + "[" + l + "]", r[a]);
              }
            } else for (a = 0, c = r.length; a < c; a++) {
              o(r[a].key, r[a].value);
            }break;case "object":
            for (s in r) {
              r.hasOwnProperty(s) && o(e ? e + "[" + s + "]" : s, r[s]);
            }break;default:
            r = "" + r, e ? i(e, r) : t[t.length] = r;}return t;
      };return o("", e).join("&").replace(/%20/g, "+");
    },
        ce = function ce(e) {
      return e.match(/(.*?)(#.*)/);
    },
        le = function le(e) {
      return e = e.replace(/\+/g, " "), decodeURIComponent(e);
    },
        ue = function ue(e) {
      var t = ce(e);return t && (e = t[1]), e ? (-1 !== e.indexOf("?") && (e = e.split("?")[0]), e) : "";
    },
        de = function de() {
      return Date.now();
    },
        he = new (function () {
      function _class2() {
        _classCallCheck(this, _class2);

        this.hidden = null, this.visibilityChange = null, void 0 !== document.hidden ? (this.hidden = "hidden", this.visibilityChange = "visibilitychange") : void 0 !== document.msHidden ? (this.hidden = "msHidden", this.visibilityChange = "msvisibilitychange") : void 0 !== document.webkitHidden && (this.hidden = "webkitHidden", this.visibilityChange = "webkitvisibilitychange");
      }

      _createClass(_class2, [{
        key: "isBackground",
        value: function isBackground() {
          return !0 === document[this.hidden];
        }
      }, {
        key: "isVisible",
        value: function isVisible() {
          return "visible" === document.visibilityState;
        }
      }, {
        key: "addEventListener",
        value: function addEventListener(e, t) {
          document.addEventListener(this.visibilityChange, e, t);
        }
      }]);

      return _class2;
    }())(),
        fe = function fe(e) {
      return function (t) {
        var n = ue(t.transformedUrl),
            r = ae(t.transformedUrl),
            i = {};return Object.keys(r).forEach(function (t) {
          e(t) && (i[t] = r[t]);
        }), t.transformedUrl = n + "?" + se(i), !0;
      };
    },
        ge = function ge(e) {
      return fe(function (t) {
        return e.indexOf(t) > -1;
      });
    },
        pe = function pe(e) {
      return fe(function (t) {
        return -1 === e.indexOf(t);
      });
    },
        me = function me(e, t) {
      return function (n) {
        if (!e) return !0;var r = ue(n.transformedUrl),
            i = ae(n.transformedUrl);return i[e] = function (e) {
          return Z(e) ? e() : e;
        }(t), n.transformedUrl = r + "?" + se(i), !0;
      };
    },
        ve = "_background_";
    var _e = function _e(e) {
      _classCallCheck(this, _e);

      this.transformedUrl = e;
    };

    var we = function () {
      function we(e, t) {
        _classCallCheck(this, we);

        this.trackingId = e || "default", this.enableTimer = t || !1, this.transforms = [], this.onTransformedUrlChangedCallbacks = [], this.store = L.getOrCreate(this.trackingId, "util/track/transform-url-controller"), this.calcInterval = 500, this.middlewares = { middlewareFilterParams: fe, middlewarePickParams: ge, middlewareExcludeParams: pe, middlewareAppendParams: me }, this.handleVisibilityChange = this.handleVisibilityChange.bind(this), this.handleWindowClosed = this.handleWindowClosed.bind(this), this.calcTransformedUrl = this.calcTransformedUrl.bind(this), he.addEventListener(this.handleVisibilityChange, !1);
      }

      _createClass(we, [{
        key: "start",
        value: function start() {
          var _this12 = this;

          console.log("TransformUrlController.start, in ..."), window.removeEventListener("close", this.handleWindowClosed), window.addEventListener("close", this.handleWindowClosed), this.enableTimer && this.startTimer(), setTimeout(function () {
            _this12.calcTransformedUrl();
          }, 200);
        }
      }, {
        key: "stop",
        value: function stop() {
          this.enableTimer && this.stopTimer();
        }
      }, {
        key: "startTimer",
        value: function startTimer() {
          var e = this;this.timer && clearInterval(this.timer), this.timer = setInterval(function () {
            e.calcTransformedUrl();
          }, this.calcInterval);
        }
      }, {
        key: "stopTimer",
        value: function stopTimer() {
          this.timer && clearInterval(this.timer);
        }
      }, {
        key: "reset",
        value: function reset() {
          this.transforms = [], this.onTransformedUrlChangedCallbacks = [];
        }
      }, {
        key: "register",
        value: function register(e, t) {
          var n = this;ne(t) && (t = t.map(function (e) {
            if (ne(e)) {
              var _t13 = n.middlewares[e[0]];if (Z(_t13)) return _t13.apply(undefined, _toConsumableArray(e.slice(1)));r.error("TransformUrlController.register, not found middleware:", e[0]);
            } else {
              if (Z(e)) return e;r.error("TransformUrlController.register, middleware MUST be function|array:", e);
            }
          })), this.transforms.push({ urlFilter: e, middlewareList: t });
        }
      }, {
        key: "registerTransforms",
        value: function registerTransforms(e) {
          var t = this;e.forEach(function (e) {
            t.register(e.urlFilter, e.middlewareList);
          });
        }
      }, {
        key: "setTransformedUrl",
        value: function setTransformedUrl(e) {
          e !== this.current.transformedUrl && (this.last = this.current, this.current = { time: de(), transformedUrl: e, url: ie() }, this.onTransformedUrlChanged());
        }
      }, {
        key: "getTransformedUrl",
        value: function getTransformedUrl() {
          var e = ie(),
              t = new _e(e);for (var _n8 in this.transforms) {
            var _r7 = this.transforms[_n8];if (oe(e, _r7.urlFilter)) for (var _e7 = 0; _e7 < _r7.middlewareList.length && (0, _r7.middlewareList[_e7])(t); _e7++) {}
          }return t.transformedUrl;
        }
      }, {
        key: "updateTransformedUrl",
        value: function updateTransformedUrl() {
          var e = "";return e = he.isBackground() ? ve : this.getTransformedUrl(), this.setTransformedUrl(e), e;
        }
      }, {
        key: "calcTransformedUrl",
        value: function calcTransformedUrl() {
          he.isVisible() && this.updateTransformedUrl();
        }
      }, {
        key: "onTransformedUrlChanged",
        value: function onTransformedUrlChanged() {
          var e = this;this.onTransformedUrlChangedCallbacks.forEach(function (t) {
            t(e.last, e.current);
          });
        }
      }, {
        key: "bindTransformedUrlChanged",
        value: function bindTransformedUrlChanged(e) {
          Z(e) ? this.onTransformedUrlChangedCallbacks.push(e) : r.error("TransformUrlController.bindTransformedUrlChanged, param callback MUST be function");
        }
      }, {
        key: "handleVisibilityChange",
        value: function handleVisibilityChange() {
          r.log("TransformUrlController, handleVisibilityChange, in"), he.isBackground() ? (r.log("TransformUrlController, handleVisibilityChange, is background, will stop()", re()), this.stop(), this.setTransformedUrl(ve)) : (r.log("TransformUrlController, handleVisibilityChange, is foreground, will start()", re()), this.start(), this.calcTransformedUrl());
        }
      }, {
        key: "handleWindowClosed",
        value: function handleWindowClosed() {
          r.log("TransformUrlController, handleWindowClosed, in"), this.setTransformedUrl(ve);
        }
      }, {
        key: "default",
        get: function get() {
          return { time: de(), transformedUrl: this.getTransformedUrl(), url: ie() };
        }
      }, {
        key: "current",
        set: function set(e) {
          this.store.update({ current: e });
        },
        get: function get() {
          return this.store.data.current || { time: null, transformedUrl: null, url: null };
        }
      }, {
        key: "last",
        set: function set(e) {
          this.store.update({ last: e });
        },
        get: function get() {
          return this.store.data.last || { time: null, transformedUrl: null, url: null };
        }
      }]);

      return we;
    }();

    we.PAGE_BACKGROUND = ve;var ye = new we();E("godTracker", function () {
      function _class3(e, t) {
        var _this13 = this;

        _classCallCheck(this, _class3);

        z(e, G.GOD_TRACKER);var n = { transforms: [], enableTimer: !1, events: ["long-press", "click", "scroll"], increaseThreshold: 20, sessionTimeout: M.DEFAULT_TIMEOUT };this.opts = y(n, t), this.tracker = e, this.handleScroll = function (e, t) {
          var n = void 0;return function () {
            for (var _len9 = arguments.length, t = Array(_len9), _key9 = 0; _key9 < _len9; _key9++) {
              t[_key9] = arguments[_key9];
            }

            clearTimeout(n), n = setTimeout(function () {
              return e.apply(undefined, t);
            }, 500);
          };
        }(this.handleScroll.bind(this)), this.trackerSetOverride = this.trackerSetOverride.bind(this), g.add(e, "set", this.trackerSetOverride), this.pagePath = this.getPagePath();var r = e.get("trackingId");this.store = L.getOrCreate(r, "plugins/god-tracker"), this.session = M.getOrCreate(e, this.opts.sessionTimeout, this.opts.timeZone), this.queue = $.getOrCreate(e.get("trackingId")), this.delegates = {}, this.handleEvents = this.handleEvents.bind(this), this.opts.events.forEach(function (e) {
          "scroll" !== e ? ("long-press" === e && function (e, t) {
            var n = null,
                r = !1,
                i = 0,
                o = 0,
                a = "ontouchstart" in e || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0,
                s = a ? "touchstart" : "mousedown",
                c = a ? "touchcancel" : "mouseout",
                l = a ? "touchend" : "mouseup",
                u = a ? "touchmove" : "mousemove";"function" != typeof e.CustomEvent && (e.CustomEvent = function (e, n) {
              n = n || { bubbles: !1, cancelable: !1, detail: void 0 };var r = t.createEvent("CustomEvent");return r.initCustomEvent(e, n.bubbles, n.cancelable, n.detail), r;
            }, e.CustomEvent.prototype = e.Event.prototype), t.addEventListener(s, function (e) {
              var t = e.target,
                  o = parseInt(t.getAttribute("data-long-press-delay") || "500", 10);i = new Date().getTime(), n = setTimeout(function () {
                r = !0;
              }, o);
            }), t.addEventListener(l, function (e) {
              o = new Date().getTime(), function () {
                if (r) {
                  var _e8 = new CustomEvent("long-press", { bubbles: !0, cancelable: !0 });_e8.duration = o - i, this.dispatchEvent(_e8), r = !1;
                }clearTimeout(n);
              }.call(e.target), clearTimeout(n);
            }), t.addEventListener(c, function () {
              clearTimeout(n);
            }), t.addEventListener(u, function () {
              clearTimeout(n);
            }), t.addEventListener("mousewheel", function () {
              clearTimeout(n);
            }), t.addEventListener("wheel", function () {
              clearTimeout(n);
            }), t.addEventListener("scroll", function () {
              clearTimeout(n);
            });
          }(window, window.document), _this13.delegates[e] = function (e, t) {
            var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
            var r = n.eventType,
                i = function i(e) {
              var n = document.documentElement;n && t.call(n, e, e.target);
            };return e.addEventListener(r, i, n.useCapture), { destroy: function destroy() {
                e.removeEventListener(r, i, n.useCapture);
              } };
          }(document, _this13.handleEvents, { composed: !0, useCapture: !0, eventType: e })) : _this13.listenForScrollChanges();
        }), this.handleTransformUrlChange = this.handleTransformUrlChange.bind(this), this.initTransformUrlController = this.initTransformUrlController.bind(this), this.initTransformUrlController(), this.pushStateOverride = this.pushStateOverride.bind(this), this.replaceStateOverride = this.replaceStateOverride.bind(this), this.handlePopState = this.handlePopState.bind(this), g.add(history, "pushState", this.pushStateOverride), g.add(history, "replaceState", this.replaceStateOverride), window.addEventListener("popstate", this.handlePopState);
      }

      _createClass(_class3, [{
        key: "listenForScrollChanges",
        value: function listenForScrollChanges() {
          this.getScrollPercentageForCurrentPage() < 100 && addEventListener("scroll", this.handleScroll);
        }
      }, {
        key: "stopListeningForScrollChanges",
        value: function stopListeningForScrollChanges() {
          removeEventListener("scroll", this.handleScroll);
        }
      }, {
        key: "handleScroll",
        value: function handleScroll() {
          var _this14 = this;

          var e = function () {
            var e = document.documentElement,
                t = document.body;return Math.max(e.offsetHeight, e.scrollHeight, t.offsetHeight, t.scrollHeight);
          }(),
              t = window.pageYOffset,
              n = window.innerHeight;this.queue.pushTask(function (_ref3) {
            var r = _ref3.time;
            var i = Math.min(100, Math.max(0, Math.round(t / (e - n) * 100))),
                o = _this14.session.id;o !== _this14.store.data.sessionId && (_this14.store.clear(), _this14.store.update({ sessionId: o }));var a = _this14.getScrollPercentageForCurrentPage(),
                s = Math.abs(i - a);if (100 === i || 0 === i || s >= _this14.opts.increaseThreshold) {
              _this14.setScrollPercentageForCurrentPage(i);var _e9 = { op: "SCROLL", data: { p2: "0," + a, p3: "0," + i }, page: window.location.href, page_id: ye.getTransformedUrl(), view_tag: "document", view_text: "" };Q.deliver(J.UI_ACTION, _e9);
            }
          });
        }
      }, {
        key: "trackerSetOverride",
        value: function trackerSetOverride(e) {
          var _this15 = this;

          return function (t, n) {
            if (e(t, n), _defineProperty({}, t, n).page) {
              var _e10 = _this15.pagePath;_this15.pagePath = _this15.getPagePath(), _this15.pagePath !== _e10 && _this15.listenForScrollChanges();
            }
          };
        }
      }, {
        key: "setScrollPercentageForCurrentPage",
        value: function setScrollPercentageForCurrentPage(e) {
          var _store$update;

          this.store.update((_store$update = {}, _defineProperty(_store$update, this.pagePath, e), _defineProperty(_store$update, "sessionId", this.session.id), _store$update));
        }
      }, {
        key: "getScrollPercentageForCurrentPage",
        value: function getScrollPercentageForCurrentPage() {
          return this.store.data[this.pagePath] || 0;
        }
      }, {
        key: "getPagePath",
        value: function getPagePath() {
          var e = h(this.tracker.get("page") || this.tracker.get("location"));return e.pathname + e.search;
        }
      }, {
        key: "remove",
        value: function remove() {
          var _this16 = this;

          this.queue.destroy(), this.store.destroy(), this.session.destroy(), this.stopListeningForScrollChanges(), g.remove(this.tracker, "set", this.trackerSetOverride), g.remove(history, "pushState", this.pushStateOverride), g.remove(history, "replaceState", this.replaceStateOverride), window.removeEventListener("popstate", this.handlePopState), Object.keys(this.delegates).forEach(function (e) {
            _this16.delegates[e].destroy();
          });
        }
      }, {
        key: "initTransformUrlController",
        value: function initTransformUrlController() {
          r.log("god-tracker.initTransformUrlController.this.opts.transforms", this.opts.transforms), ye.enableTimer = this.opts.enableTimer, ye.reset(), ye.registerTransforms(this.opts.transforms), ye.bindTransformedUrlChanged(this.handleTransformUrlChange), ye.start();
        }
      }, {
        key: "handleEvents",
        value: function handleEvents(e, t) {
          this.queue.pushTask(function (_ref4) {
            var n = _ref4.time;
            switch (r.log("GodTracker.handleEvents, begin"), e.type) {case "long-press":
                {
                  var _n9 = { op: "LONG_PRESS", data: { duration: e.duration }, page: ie(), page_id: ye.getTransformedUrl(), view_tag: i(t), view_text: o(t).replace(/^\s+|\s+$/g, "").slice(0, 24) };Q.deliver(J.UI_ACTION, _n9);break;
                }case "click":
                {
                  var _e11 = { op: "CLICK", page: ie(), page_id: ye.getTransformedUrl(), view_tag: i(t), view_text: o(t).replace(/^\s+|\s+$/g, "").slice(0, 24) };Q.deliver(J.UI_ACTION, _e11);break;
                }}
          });
        }
      }, {
        key: "handleTransformUrlChange",
        value: function handleTransformUrlChange(e, t) {
          r.log("god-tracker.handleTransformUrlChange", this.opts.transforms);var n = { pre_page_id: e.transformedUrl, pre_page: e.url, pre_page_start: e.time, pre_page_end: t.time, page_id: t.transformedUrl, page: t.url, page_start: t.time };Q.deliver(J.PAGE_CHANGE, n);
        }
      }, {
        key: "pushStateOverride",
        value: function pushStateOverride(e) {
          var _this17 = this;

          return function () {
            e.apply(undefined, arguments), _this17.handleUrlChange(!0);
          };
        }
      }, {
        key: "replaceStateOverride",
        value: function replaceStateOverride(e) {
          var _this18 = this;

          return function () {
            e.apply(undefined, arguments), _this18.handleUrlChange(!1);
          };
        }
      }, {
        key: "handlePopState",
        value: function handlePopState() {
          this.handleUrlChange(!0);
        }
      }, {
        key: "handleUrlChange",
        value: function handleUrlChange(e) {
          var _this19 = this;

          setTimeout(function () {
            var e = _this19.path,
                t = ie();e !== t && (_this19.path = t, ye.calcTransformedUrl());
          }, 200);
        }
      }]);

      return _class3;
    }());
    var be = function () {
      function be(e, t) {
        _classCallCheck(this, be);

        this.hooks = {}, this.refs = {}, this.isDispatching = !1, this.logger = e || console, this.silent = t || !1;
      }

      _createClass(be, [{
        key: "attach",
        value: function attach(e, t) {
          return "string" != typeof e ? (t = e, be.supportedMethods.forEach(function (e) {
            this.attach(e, t);
          }, this), this) : (this.hooks[e] ? this.hooks[e].push(t) : (this.hooks[e] = [t], this.override(e)), this);
        }
      }, {
        key: "detach",
        value: function detach(e, t) {
          return e ? (this.hooks[e] = t ? this.hooks[e].filter(function (e) {
            return e !== t;
          }) : [], this.hooks.length || this.restore(e), this) : (be.supportedMethods.forEach(function (e) {
            this.refs[e] && this.detach(e);
          }, this), this);
        }
      }, {
        key: "override",
        value: function override(e) {
          if (this.refs[e]) return;this.refs[e] = this.logger[e];var t = this;this.logger[e] = function () {
            if (!t.isDispatching) {
              var _n10 = [e, arguments];t.isDispatching = !0, t.hooks[e].forEach(function (e) {
                e.apply(this, _n10);
              }, this), t.isDispatching = !1;
            }if (!t.silent) {
              var _n11 = t.refs[e];if (_n11.apply) _n11.apply(this, arguments);else {
                var _e12 = Array.prototype.slice.apply(arguments).join(" ");_n11.call(this, _e12);
              }
            }
          };
        }
      }, {
        key: "restore",
        value: function restore(e) {
          this.logger[e] = this.refs[e], delete this.refs[e];
        }
      }]);

      return be;
    }();

    be.allMethods = ["assert", "debug", "dir", "dirxml", "error", "info", "log", "table", "trace", "warn"], be.supportedMethods = be.allMethods.filter(function (e) {
      return "function" == typeof console[e];
    }), E("consoleTracker", function () {
      function _class4(e, t) {
        _classCallCheck(this, _class4);

        function n(e) {
          return Array.prototype.slice.call(e).join(" ");
        }z(e, G.CONSOLE_TRACKER);var r = new be(),
            i = t.methods;var _iteratorNormalCompletion = true;
        var _didIteratorError = false;
        var _iteratorError = undefined;

        try {
          for (var _iterator = i[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var _e13 = _step.value;
            -1 !== be.supportedMethods.indexOf(_e13) && r.attach(_e13, function (e, t) {
              var r = n(t),
                  i = {};i.category = X.CONSOLE, i.action = e, i.label = r, i.state = ye.getTransformedUrl(), i.value = 1, Q.deliver(i.category, i);
            });
          }
        } catch (err) {
          _didIteratorError = true;
          _iteratorError = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion && _iterator.return) {
              _iterator.return();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }
      }

      return _class4;
    }()), E("domEventTracker", function () {
      function _class5(e, t) {
        _classCallCheck(this, _class5);

        z(e, G.DOM_EVENT_TRACKER), this.config = t, window.addEventListener("error", function (e) {
          var t = {},
              n = e.target,
              r = n.currentSrc || n.src || n.href;t.category = X.RESOURCE_ERROR, t.action = r, t.label = r ? r.split(".").pop() : "", t.state = ye.getTransformedUrl(), t.value = 1, Q.deliver(t.category, t);
        }, !0), window.addEventListener("offline", function () {
          var e = {};e.category = X.NETWORK_OFFLINE, e.action = "", e.label = "", e.state = ye.getTransformedUrl(), e.value = 1, Q.deliver(e.category, e);
        }), window.addEventListener("online", function () {
          var e = {};e.category = X.NETWORK_ONLINE, e.action = "", e.label = "", e.state = ye.getTransformedUrl(), e.value = 1, Q.deliver(e.category, e);
        }), window.addEventListener("load", function () {
          var e = {};e.category = X.WINDOW_LOAD, e.action = "", e.label = "", e.state = ye.getTransformedUrl(), e.value = 1, Q.deliver(e.category, e);
        }), window.addEventListener("unload", function () {
          var e = {};e.category = X.WINDOW_UNLOAD, e.action = "", e.label = "", e.state = ye.getTransformedUrl(), e.value = 1, Q.deliver(e.category, e);
        }), window.addEventListener("beforeunload", function () {
          var e = {};e.category = X.WINDOW_BEFOREUNLOAD, e.action = "", e.label = "", e.state = ye.getTransformedUrl(), e.value = 1, Q.deliver(e.category, e);
        });
      }

      return _class5;
    }()), E("performanceTracker", function () {
      function _class6(e, t) {
        _classCallCheck(this, _class6);

        z(e, G.PERFORMANCE_TRACKER), this.config = t, window.addEventListener("load", function () {
          var e = window.performance || window.webkitPerformance || window.msPerformance || window.mozPerformance;var t = {};t.category = X.WINDOW_PERFORMANCE_LOAD, t.action = "", t.label = "", t.state = ye.getTransformedUrl(), t.value = 1, e && (t.extra = { uuid: b(), timing: e.timing, memory: e.memory, resource: function () {
              try {
                if (!window.performance && !window.performance.getEntries) return console.warn("PerformanceTracker::getResourceTiming::prerformance is not supported"), [];var _e14 = performance.getEntries(),
                    _t14 = [];return _e14 || _e14.length ? (_e14.forEach(function (e) {
                  try {
                    var _n12 = { name: e.name, time_redirect: e.redirectEnd - e.redirectStart, time_dns: e.domainLookupEnd - e.domainLookupStart, time_requestTime: e.responseEnd - e.requestStart, time_tcp: e.connectEnd - e.connectStart, type: e.initiatorType, start_time: Math.floor(e.startTime), entry_type: e.entryType, duration: Math.floor(e.duration) || 0, decoded_body_size: e.decodedBodySize || 0, next_hop_protocol: e.nextHopProtocol, json_entries: JSON.stringify(e) };_t14.push(_n12);
                  } catch (e) {
                    console.error("PerformanceTracker::getResourceTiming::", e);
                  }
                }), _t14) : _t14;
              } catch (e) {
                return console.warn("PerformanceTracker::getResourceTiming::get performance happen error"), [];
              }
            }() }), Q.deliver(t.category, t);
        }), new window.PerformanceObserver(function (e) {
          !function (e) {
            var t = {};t.category = X.WINDOW_PERFORMANCE_PAINT, t.action = "", t.label = "", t.state = ye.getTransformedUrl(), t.extra = { uuid: b(), paint: e }, t.value = 1, Q.deliver(t.category, t);
          }(e.getEntries());
        }).observe({ entryTypes: ["paint"] });
      }

      return _class6;
    }());
    var Ee = function () {
      function Ee(e, t) {
        _classCallCheck(this, Ee);

        z(e, G.ELEMENT_WATCH_TRACKER), this.interval = 500, t.watchers instanceof Array ? this.watchers = t.watchers : this.watchers = [], this._doWatch = this._doWatch.bind(this), setInterval(this._doWatch, this.interval);
      }

      _createClass(Ee, [{
        key: "_doWatch",
        value: function _doWatch() {
          var e = ie();this.watchers.filter(function (t) {
            return oe(e, t.urlFilter);
          }).forEach(function (e) {
            try {
              var _t15 = e.selector();e.value ? _t15 !== e.value && (e.old_value = e.value, e.value = _t15, Ee.sendEvent(e)) : _t15 && (e.old_value = null, e.value = _t15, Ee.sendEvent(e));
            } catch (e) {
              console.error("ElementWatchTracker:_doWatch:", e);
            }
          });
        }
      }, {
        key: "addElementWatcher",
        value: function addElementWatcher(e) {
          this.watchers.push(e);
        }
      }], [{
        key: "sendEvent",
        value: function sendEvent(e) {
          var t = {};t.category = X.ELEM_WATCH, t.action = e.name, t.label = e.value, t.state = ye.getTransformedUrl(), t.value = 1, Q.deliver(t.category, t);
        }
      }]);

      return Ee;
    }();

    E("elementWatchTracker", Ee), E("metricsTracker", function () {
      function _class7(e, t) {
        _classCallCheck(this, _class7);

        z(e, G.METRICS_TRACKER), this.interval = t.interval || 5e3, this.config = t, this.doOnTick = this.doOnTick.bind(this), window.setInterval(this.doOnTick, this.interval);
      }

      _createClass(_class7, [{
        key: "doOnTick",
        value: function doOnTick() {
          var e = {};if (e.category = X.METRICS, e.action = "", e.label = "", e.state = ye.getTransformedUrl(), e.state === we.PAGE_BACKGROUND && !this.config.reportPageBg) return;var t = 0;window.performance.memory && window.performance.memory.usedJSHeapSize && (t = window.performance.memory.usedJSHeapSize), e.extra = { online: navigator.onLine, mem_used: t }, e.value = 1, Q.deliver(e.category, e);
        }
      }]);

      return _class7;
    }());var Te = { set logLevel(e) {
        r.logLevel = e;
      } };window.Track = Te;
  }]);
}]);

/***/ }),

/***/ "./src/utils/index.js":
/*!****************************!*\
  !*** ./src/utils/index.js ***!
  \****************************/
/*! exports provided: emptyFunction, processStackMsg, getUrlParam, getCookie, isReport, debounce, formatParams, doReport, isNumeric, transformRc, merge, getLocalUniqueId, traversal, getRetCodeOrMsg, filterCgiResp, autoRetain, getKey, DeviceInfo, isiOS, isAndroid */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "emptyFunction", function() { return emptyFunction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "processStackMsg", function() { return processStackMsg; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getUrlParam", function() { return getUrlParam; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCookie", function() { return getCookie; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isReport", function() { return isReport; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "debounce", function() { return debounce; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formatParams", function() { return formatParams; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "doReport", function() { return doReport; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isNumeric", function() { return isNumeric; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "transformRc", function() { return transformRc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "merge", function() { return merge; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLocalUniqueId", function() { return getLocalUniqueId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "traversal", function() { return traversal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRetCodeOrMsg", function() { return getRetCodeOrMsg; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "filterCgiResp", function() { return filterCgiResp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "autoRetain", function() { return autoRetain; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getKey", function() { return getKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeviceInfo", function() { return DeviceInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isiOS", function() { return isiOS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isAndroid", function() { return isAndroid; });
/* harmony import */ var _types_index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./types/index */ "./src/utils/types/index.js");
/* harmony import */ var _url_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./url/index */ "./src/utils/url/index.js");
/* harmony import */ var _constants_config_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants/config/index */ "./src/constants/config/index.js");
/* harmony import */ var _constants_boss_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../constants/boss/index */ "./src/constants/boss/index.js");





var emptyFunction = function emptyFunction() {};
// https://developer.mozilla.org/zh-CN/docs/Web/API/Network_Information_API
// http://www.honglei.net/?p=340
var processStackMsg = function processStackMsg(error) {
  var stack = error.stack.replace(/\n/gi, '').replace(/\bat\b/gi, '@').split('@').slice(0, 9).map(function (v) {
    return v.replace(/^\s*|\s*$/g, '');
  }).join('~').replace(/\?[^:]+/gi, '');
  var msg = error.toString();
  if (stack.indexOf(msg) < 0) {
    stack = msg + '@' + stack;
  }
  return stack;
};
var getUrlParam = function getUrlParam(_ref) {
  var name = _ref.name,
      _ref$url = _ref.url,
      url = _ref$url === undefined ? window.location.href : _ref$url;

  // eslint-disable-next-line no-useless-escape
  name = name.replace(/[\[\]]/g, '\\$&');
  var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
  var results = regex.exec(url);
  if (!results) {
    return '';
  }
  if (!results[2]) {
    return '';
  }
  return decodeURIComponent(results[2].replace(/\+/g, ' '));
};
var getCookie = function getCookie(name) {
  var nameEQ = encodeURIComponent(name) + '=';
  var ca = document.cookie.split(';');
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) === ' ') {
      c = c.substring(1, c.length);
    }if (c.indexOf(nameEQ) === 0) {
      return decodeURIComponent(c.substring(nameEQ.length, c.length));
    }
  }

  return null;
};
var isReport = function isReport() {
  var sampling = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
  return Math.random() <= sampling;
};
var debounce = function debounce(func, delay, callback) {
  var timer = null;
  // eslint-disable-next-line func-names
  return function () {
    for (var _len = arguments.length, rest = Array(_len), _key = 0; _key < _len; _key++) {
      rest[_key] = arguments[_key];
    }

    var context = this;
    clearTimeout(timer);
    timer = setTimeout(function () {
      func.apply(context, rest);
      if (typeof callback === 'function') {
        callback();
      }
    }, delay);
  };
};
var formatParams = function formatParams(data) {
  var arr = [];
  for (var name in data) {
    arr.push(encodeURIComponent(name) + '=' + encodeURIComponent(data[name]));
  }
  return arr.join('&');
};

var doReport = function doReport(_ref2) {
  var baseUrl = _ref2.baseUrl,
      data = _ref2.data,
      _ref2$method = _ref2.method,
      method = _ref2$method === undefined ? 'GET' : _ref2$method;

  if (method === 'GET') {
    var _xmlhttp = null;
    if (window.XMLHttpRequest) {
      _xmlhttp = new XMLHttpRequest();
    } else {
      // eslint-disable-next-line no-undef
      _xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
    }
    _xmlhttp.open('GET', baseUrl + '/entrance/' + data.p_id + '/authorize/?' + formatParams(data), true);
    _xmlhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    _xmlhttp.send();
    _xmlhttp.onreadystatechange = function () {
      if (_xmlhttp.readyState === 4 && _xmlhttp.status === 200) {
        Object(_constants_config_index__WEBPACK_IMPORTED_MODULE_2__["setToken"])(true);
      }
    };
  } else if (method === 'POST') {
    if (!Object(_constants_config_index__WEBPACK_IMPORTED_MODULE_2__["getToken"])()) {
      return;
    }
    var params = {
      plugin: data.plugin,
      p_id: data.p_id,
      uin: data.uin,
      arch: data.arch,
      version: data.version,
      device: data.device,
      q: 0
    };
    var _xmlhttp2 = null;
    if (window.XMLHttpRequest) {
      _xmlhttp2 = new XMLHttpRequest();
    } else {
      // eslint-disable-next-line no-undef
      _xmlhttp2 = new ActiveXObject('Microsoft.XMLHTTP');
    }
    _xmlhttp2.open('POST', baseUrl + '/entrance/' + params.p_id + '/uploadJson/?' + formatParams(params), true);

    _xmlhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    _xmlhttp2.send(JSON.stringify(data));
    alert(JSON.stringify(data));
  }
};

var isNumeric = function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
};

var transformRc = function transformRc(source) {
  var returnedArr = [];
  if (Object(_types_index__WEBPACK_IMPORTED_MODULE_0__["isArray"])(source)) {
    source.forEach(function (item) {
      var returnedVal = {};
      for (var sr in item) {
        if (_constants_config_index__WEBPACK_IMPORTED_MODULE_2__["CDNQUALITY"][sr]) {
          returnedVal[_constants_config_index__WEBPACK_IMPORTED_MODULE_2__["CDNQUALITY"][sr]] = item[sr];
          if (_constants_config_index__WEBPACK_IMPORTED_MODULE_2__["CDNQUALITY"][sr] === 'resurl') {
            var _parseLink = Object(_url_index__WEBPACK_IMPORTED_MODULE_1__["parseLink"])(item[sr]),
                hostname = _parseLink.hostname,
                path = _parseLink.path;

            returnedVal.reshost = hostname;
            returnedVal.respath = path;
            returnedVal.httpcode = 200;
          }
        }
      }
      returnedArr.push(returnedVal);
    });
  }
  return returnedArr;
};

var merge = function merge(mergeData) {
  var opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var mergeOpts = {};
  var changedKey = [];
  if (Object(_types_index__WEBPACK_IMPORTED_MODULE_0__["isObject"])(opts)) {
    for (var op in opts) {
      if (_constants_boss_index__WEBPACK_IMPORTED_MODULE_3__["CANMODIFYKEYS"].indexOf(String(op)) !== -1) {
        mergeOpts[op] = opts[op];
        changedKey.push(op);
      } else {
        console.warn(op, 'could not be modify.');
      }
    }
  }
  return Object.assign({}, mergeData, mergeOpts);
};

var getLocalUniqueId = function getLocalUniqueId() {
  var localUniqueId = '';
  try {
    localUniqueId = window.localStorage.getItem('emonitor.hc_pgv_pvid');
    if (localUniqueId) {
      return localUniqueId;
    }
    var genUIdTime = new Date().getTime();
    localUniqueId = 'ek' + [genUIdTime, Math.floor(genUIdTime * Math.random() * Math.random()).toString().slice(-5)].join('');
    window.localStorage.setItem('emonitor.hc_pgv_pvid', localUniqueId);
    return localUniqueId;
  } catch (err) {
    console.warn('emonitor.hc_pgv_pvid get error', err);
    return localUniqueId;
  }
};

/**
 * 遍历并获取指定值
 * @param {Object} data 响应信息
 * @param {String|Array} data 要过滤的响应信息字段
 * @param {String} defaultValue 默认值
 */
var traversal = function traversal(data, path) {
  var defaultValue = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';

  // eslint-disable-next-line no-void
  var returnedValue = void 0;
  String(path).split('.').forEach(function (key) {
    try {
      if (typeof returnedValue !== 'undefined') {
        returnedValue = returnedValue[key];
      } else {
        returnedValue = data[key];
      }
    } catch (err) {
      // eslint-disable-next-line no-void
      returnedValue = void 0;
    }
  });
  if (typeof returnedValue === 'undefined') {
    return defaultValue;
  }
  return returnedValue;
};
/**
 * 获取响应状态码和信息
 * @param {Object} param 过滤前响应信息和要过滤的字段
 * @param {Object} param.data 响应信息
 * @param {String|Array} param.path 要过滤的响应信息字段
 */
var getRetCodeOrMsg = function getRetCodeOrMsg(_ref3) {
  var _ref3$data = _ref3.data,
      data = _ref3$data === undefined ? {} : _ref3$data,
      _ref3$path = _ref3.path,
      path = _ref3$path === undefined ? '' : _ref3$path;

  // eslint-disable-next-line no-void
  var finalReturnedValue = void 0;
  if (Object(_types_index__WEBPACK_IMPORTED_MODULE_0__["isObject"])(data)) {
    if (Object(_types_index__WEBPACK_IMPORTED_MODULE_0__["isString"])(path)) {
      return traversal(data, path, '');
    } else if (Object(_types_index__WEBPACK_IMPORTED_MODULE_0__["isArray"])(path)) {
      path.forEach(function (pk) {
        if (traversal(data, pk, '') !== '') {
          finalReturnedValue = traversal(data, pk);
          return false;
        } else {
          finalReturnedValue = '';
        }
      });
      return finalReturnedValue;
    }
  }
  return '';
};

/**
 * 过滤cgi响应信息（响应状态码和响应信息）
 * @param {String|Object} curResponseText 服务器返回的文本数据
 * @return {Object} resp 响应状态码和响应信息
 * @return {Number|String} resp.bizcode 响应状态码
 * @return {String} resp.bizmsg 响应信息
 */
var filterCgiResp = function filterCgiResp(curResponseText) {
  var cgiOptions = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var cgiCfg = cgiOptions || {};
  var code = cgiCfg.code,
      msg = cgiCfg.msg;

  var responseData = {};
  if (Object(_types_index__WEBPACK_IMPORTED_MODULE_0__["isObject"])(curResponseText)) {
    responseData = curResponseText;
  } else {
    try {
      responseData = JSON.parse(curResponseText);
    } catch (err) {
      responseData = {};
    }
  }
  var bizcode = getRetCodeOrMsg({
    data: responseData,
    path: code
  });
  var bizmsg = getRetCodeOrMsg({
    data: responseData,
    path: msg
  });
  return { bizcode: bizcode, bizmsg: bizmsg };
};

// 自动从url或者cookie中获取对应name的值

var autoRetain = function autoRetain(name) {
  var returnedValue = '';
  if (!Object(_types_index__WEBPACK_IMPORTED_MODULE_0__["isString"])(name)) {
    console.warn('name is not string');
    return returnedValue;
  }
  try {
    returnedValue = getUrlParam({
      name: name
    });
    if (returnedValue.length === 0) {
      returnedValue = getCookie(name) || '';
    }
    return returnedValue;
  } catch (err) {
    console.error('Automatically get the value of the corresponding name from the url or cookie ' + err);
    return returnedValue;
  }
};

var getKey = function getKey(appKey) {
  var data = {
    private_app_key: appKey.split('-')[0],
    p_id: appKey.split('-')[1]
  };
  return data;
};

// export const initByJsBridge = data => {
//   data.os = qapmJsBridge.get();
//   return data;
// };

var DeviceInfo = function DeviceInfo() {
  var isMac = navigator.platform === 'Mac68K' || navigator.platform === 'MacPPC' || navigator.platform === 'Macintosh' || navigator.platform === 'MacIntel';
  if (isMac) return 1;
  return 0;
};
var isiOS = function isiOS() {
  var u = navigator.userAgent;
  return !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); // ios终端
};
var isAndroid = function isAndroid() {
  var u = navigator.userAgent;
  return u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; // android终端
};

/***/ }),

/***/ "./src/utils/types/index.js":
/*!**********************************!*\
  !*** ./src/utils/types/index.js ***!
  \**********************************/
/*! exports provided: nativeToString, nativeHasOwn, isArray, isObject, isString, isUndefined, isFunction, hasProp */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "nativeToString", function() { return nativeToString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "nativeHasOwn", function() { return nativeHasOwn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isArray", function() { return isArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isObject", function() { return isObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isString", function() { return isString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isUndefined", function() { return isUndefined; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isFunction", function() { return isFunction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hasProp", function() { return hasProp; });
var nativeToString = Object.prototype.toString;
var nativeHasOwn = Object.prototype.hasOwnProperty;
var isArray = function isArray(obj) {
  return nativeToString.call(obj) === '[object Array]';
};
var isObject = function isObject(obj) {
  return nativeToString.call(obj) === '[object Object]';
};
var isString = function isString(obj) {
  return typeof obj === 'string';
};
var isUndefined = function isUndefined(obj) {
  return typeof obj === 'undefined';
};
var isFunction = function isFunction(func) {
  return typeof func === 'function';
};
var hasProp = function hasProp(obj, key) {
  return nativeHasOwn.call(obj, key);
};

/***/ }),

/***/ "./src/utils/url/index.js":
/*!********************************!*\
  !*** ./src/utils/url/index.js ***!
  \********************************/
/*! exports provided: parseLink */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parseLink", function() { return parseLink; });
var parseLink = function parseLink(url) {
  if (!url) {
    return {};
  }
  var aTag = document.createElement('a');
  aTag.href = url;
  return {
    host: aTag.host,
    path: aTag.pathname,
    hostname: aTag.hostname,
    protocol: aTag.protocol.slice(0, -1)
  };
};

/***/ })

/******/ });
//# sourceMappingURL=build.js.map