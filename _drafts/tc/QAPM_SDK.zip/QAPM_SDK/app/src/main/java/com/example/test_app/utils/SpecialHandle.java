package com.example.test_app.utils;


import com.example.test_app.X5WebViewActivity;
import com.tencent.smtt.export.external.extension.proxy.ProxyWebChromeClientExtension;
import com.tencent.smtt.sdk.WebView;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

public class SpecialHandle {
    private static final String TAG = "SdkDemo_SpecialHandle";

    static public boolean shouldOverrideUrlLoading(WebView view, String url) {
        if (!TextUtils.isEmpty(url) && (url.startsWith("mailto:") || url.startsWith("tel:") || url.startsWith("smsto:"))) {
            Toast.makeText(view.getContext(), "拦截特殊intent:"+url, Toast.LENGTH_LONG).show();
            return true;
        }
        //特殊页面用来设置功能：功能测试临时代码
        try {
            Uri uri = Uri.parse(url);
            String scheme = uri.getScheme();
            if ("http".equals(scheme) || "https".equals(scheme)) {
                //只放开http和https类型的请求
            } else {
                Log.e(TAG, "donot support intent:" + url);
                return true;
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return false;
    }

    static public LocalWebChromeClientExtension getLocalWebChromeClientExtension(X5WebViewActivity mainActivity, WebView webview) {
        return new LocalWebChromeClientExtension(mainActivity, webview);
    }

    public static class LocalWebChromeClientExtension extends ProxyWebChromeClientExtension {
        private X5WebViewActivity m_MainActivity;
        private WebView m_WebView;

        public LocalWebChromeClientExtension(X5WebViewActivity mainActivity, WebView webview) {
            m_MainActivity = mainActivity;
            m_WebView = webview;
        }

        @Override
        public void openFileChooser(final android.webkit.ValueCallback<Uri[]> uploadFile, String acceptType, String captureType) {
            com.tencent.smtt.sdk.ValueCallback<Uri> uploadFileAdapter = new com.tencent.smtt.sdk.ValueCallback<Uri>() {
                
                @Override
                public void onReceiveValue(Uri value) {
                    Uri[] uris  = new Uri[1];
                    uris[0] = value;
                    uploadFile.onReceiveValue(uris);
                }
            };
            m_MainActivity.enterFileChooser(uploadFileAdapter, captureType.equalsIgnoreCase("*"), acceptType, true, "");
        }
    }

    public static void onGeolocationPermissionsShowPrompt(final String origin, final com.tencent.smtt.export.external.interfaces.GeolocationPermissionsCallback callback, Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("定位提示");
        builder.setMessage("是否允许" + origin + "定位：");
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                callback.invoke(origin, true, true);
            }
        });
        builder.setNeutralButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                callback.invoke(origin, false, true);
            }
        });
        builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                callback.invoke(origin, false, true);
            }
        });
        builder.show();
    };
}
