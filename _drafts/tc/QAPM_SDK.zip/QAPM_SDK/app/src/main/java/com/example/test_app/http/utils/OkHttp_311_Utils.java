package com.example.test_app.http.utils;

import android.text.TextUtils;


import com.example.test_app.http.bean.HttpBean;
import com.example.test_app.http.listener.HttpListener;

import java.io.IOException;
import java.security.cert.CertificateException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.ConnectionPool;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class OkHttp_311_Utils {
    private static final String TAG = "OkHttp_311_Utils";

    private volatile static OkHttp_311_Utils okHttp311Utils;

    private OkHttpClient okHttpClient;

    private OkHttp_311_Utils() {
        okHttpClient = getUnsafeOkHttpClient();
    }

    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[] {
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            builder.sslSocketFactory(sslSocketFactory);
            builder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });
            OkHttpClient okHttpClient = builder.connectionPool(new ConnectionPool(0, 1, TimeUnit.SECONDS)).build();
            return okHttpClient;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static OkHttp_311_Utils getInstance() {
        if (okHttp311Utils == null) {
            synchronized (OkHttp_311_Utils.class) {
                if (okHttp311Utils == null) {
                    okHttp311Utils = new OkHttp_311_Utils();
                }
            }
        }
        return okHttp311Utils;
    }

    public void getRequest(final HttpBean bean, final HttpListener listener) {
        String url = bean.getUrl();
        if (TextUtils.isEmpty(url)) {
            return;
        }
        Request request = new Request.Builder()
                .url(bean.getUrl())
                .get()
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                bean.setMessage(e.getMessage());
                bean.setException(e.toString().split(":")[0]);
                listener.onFailed(bean);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                bean.setMessage(response.body().string());
                bean.setResultCode(response.code());
                listener.onSuccess(bean);
            }
        });
    }

    public void postRequest(final HttpBean bean, final HttpListener listener) {
        RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), DefaultUtils.JSON_DATA);
        Request request = new Request.Builder()
                .url(bean.getUrl())
                .post(body)
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                bean.setMessage(e.getMessage());
                bean.setException(e.toString().split(":")[0]);
                listener.onFailed(bean);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
//                Log.d(TAG, "onResponse: " + response.body().string());
                bean.setMessage(response.body().string());
                bean.setResultCode(response.code());
                listener.onSuccess(bean);
            }
        });

    }

    public void release(){
        if (okHttpClient != null) {
            okHttpClient = null;
        }
        if (okHttp311Utils != null) {
            okHttp311Utils = null;
        }
    }

}
