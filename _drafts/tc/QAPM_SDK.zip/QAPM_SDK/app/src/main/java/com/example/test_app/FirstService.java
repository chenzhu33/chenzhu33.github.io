package com.example.test_app;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

import com.tencent.qapmsdk.QAPM;

import java.util.Timer;
import java.util.TimerTask;


public class FirstService extends Service {
    private IOTest ioTest;
    private GPSManager gpsManager;
    public FirstService() {
    }

    IMyAidlInterface.Stub mBinder = new IMyAidlInterface.Stub(){
        @Override
        public void AIDL_Service() {
            ILogUtil.getInstance(false).d("FirstService","客户端通过AIDL与远程后台成功通信");
        }
    };


    //重写与Service生命周期的相关方法
    @Override
    public void onCreate() {
        super.onCreate();

        System.out.println("Service");
        ioTest = new IOTest(FirstService.this);
        gpsManager = new GPSManager(FirstService.this);
        QAPM.setProperty(QAPM.PropertyKeyAppInstance, getApplication());
        QAPM.setProperty(QAPM.PropertyKeyAppId, "1024").setProperty(QAPM.PropertyKeyAppVersion, "2.1").setProperty(QAPM.PropertyKeySymbolId, "e6ae1282-ceb8-4237-89bd-2d23d00a8e33");
        QAPM.setProperty(QAPM.PropertyKeyUserId, "11223344");
        Timer timer = new Timer();
        timer.schedule(timerTask,5*1000,30*1000);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
//        System.out.println("执行了onStartCommand()");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean onUnbind(Intent intent) {
//        System.out.println("执行了onUnbind()");
        return super.onUnbind(intent);
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
//        throw new UnsupportedOperationException("Not yet implemented");
        return  mBinder;
    }

    TimerTask timerTask = new TimerTask() {
        @Override
        public void run() {

            try {
                ioTest.SQLiteDatabaseTest();
                Thread.sleep(3000);
                ioTest.FileTest();
                Thread.sleep(2000);
                gpsManager.getLocation();
                Thread.sleep(3000);
//                new ReportToYunYing().reportJsonLater();

            }catch (Exception e){
                e.printStackTrace();
            }
        }
    };

}
