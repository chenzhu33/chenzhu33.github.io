package com.example.test_app.http.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.test_app.R;
import com.example.test_app.http.bean.HttpBean;
import com.example.test_app.http.listener.HttpListener;
import com.example.test_app.http.utils.DefaultUtils;
import com.example.test_app.http.utils.HttpClientUtils;
import com.example.test_app.http.utils.HttpUtils;
import com.example.test_app.http.utils.OkHttp_275_Utils;
import com.example.test_app.http.utils.OkHttp_311_Utils;
import com.tencent.qapmsdk.QAPM;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ManagerActivity extends AppCompatActivity {
    private static final String TAG = "ManagerActivity";

    private OkHttp_275_Utils okHttp275Utils;
    private OkHttp_311_Utils okHttp311Utils;
    private HttpClientUtils httpClientUtils;
    private HttpUtils httpUtils;

    public ManagerHandler managerHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager);

        init();

        findViewById(R.id.doMainActivity).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerActivity.this, DoMainActivity.class);
                startActivity(intent);
            }
        });
        findViewById(R.id.ipActivity).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerActivity.this, IpActivity.class);
                startActivity(intent);
            }
        });
        findViewById(R.id._ipActivity).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerActivity.this, _IpActivity.class);
                startActivity(intent);
            }
        });
        findViewById(R.id.socketActivity).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerActivity.this, SocketActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.timerTest).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (managerHandler == null) {
                    managerHandler = new ManagerHandler(ManagerActivity.this);
                }
                managerHandler.obtainMessage().sendToTarget();
            }
        });
        findViewById(R.id.closeTimerTest).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (managerHandler != null) {
                    managerHandler.removeCallbacksAndMessages(null);
                    managerHandler = null;
                }
            }
        });
    }

    public HttpListener listener = new HttpListener() {
        @Override
        public void onFailed(HttpBean bean) {
            Log.d(TAG, "onFailed: " + bean.toString());
        }

        @Override
        public void onSuccess(HttpBean bean) {
            Log.d(TAG, "onSuccess: " + bean.toString());
        }
    };

    private void init() {
        managerHandler = new ManagerHandler(this);
        okHttp275Utils = OkHttp_275_Utils.getInstance();
        okHttp311Utils = OkHttp_311_Utils.getInstance();
        httpClientUtils = HttpClientUtils.getInstance();
        httpUtils = HttpUtils.getInstance();
    }

    static class ManagerHandler extends Handler {
        WeakReference<ManagerActivity> weakReference;

        public ManagerHandler(ManagerActivity activity) {
            weakReference = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            ManagerActivity activity = weakReference.get();
            if (activity != null) {
                HttpBean bean = new HttpBean();
                bean.setUrl(DefaultUtils.HTTPS_DOMAIN_NO_PORT);
                activity.okHttp275Utils.getRequest(bean, activity.listener);
                activity.okHttp311Utils.getRequest(bean, activity.listener);
                activity.httpClientUtils.getRequest(bean, activity.listener);
                activity.httpUtils.httpsGetRequest(bean, activity.listener);
                activity.managerHandler.sendMessageDelayed(Message.obtain(), 500);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (okHttp275Utils != null) {
            okHttp275Utils.release();
            okHttp275Utils = null;
        }
        if (okHttp311Utils != null) {
            okHttp311Utils.release();
            okHttp311Utils = null;
        }
        if (httpClientUtils != null) {
            httpClientUtils.release();
            httpClientUtils = null;
        }
        if (httpUtils != null) {
            httpUtils.release();
            httpUtils = null;
        }
        if (managerHandler != null) {
            managerHandler.removeCallbacksAndMessages(null);
            managerHandler = null;
        }
    }

}
