package com.example.test_app.http.utils;

import android.util.Log;


import com.example.test_app.http.bean.HttpBean;
import com.example.test_app.http.listener.HttpListener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class HttpUtils {

    private volatile static HttpUtils httpUtils;

    private HttpUtils() {
    }

    public static HttpUtils getInstance() {
        if (httpUtils == null) {
            synchronized (HttpUtils.class) {
                if (httpUtils == null) {
                    httpUtils = new HttpUtils();
                }
            }
        }
        return httpUtils;
    }

    public void httpGetRequest(final HttpBean bean, final HttpListener listener) {
        new Thread() {
            @Override
            public void run() {
                BufferedReader bufferedReader = null;
                try {

                    URL url = new URL(bean.getUrl());
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(5000);
                    conn.connect();
                    int code = conn.getResponseCode();
                    bean.setResultCode(code);
                    InputStream inputStream = conn.getInputStream();
                    bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    final StringBuffer stringBuffer = new StringBuffer();
                    String line = null;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuffer.append(line);
                    }
                    bean.setMessage(stringBuffer.toString());
                } catch (Exception e) {
//            e.printStackTrace();
                    bean.setException(e.toString().split(":")[0]);
                    bean.setMessage(e.getMessage());
                } finally {
                    try {
                        if (bufferedReader != null) {
                            bufferedReader.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                listener.onSuccess(bean);
            }
        }.start();
    }

    public void httpsGetRequest(final HttpBean bean, final HttpListener listener) {
        new Thread() {
            @Override
            public void run() {
                BufferedReader bufferedReader = null;
                try {
                    HostnameVerifier hostnameVerifier = new HostnameVerifier() {
                        @Override
                        public boolean verify(String hostname, SSLSession session) {
                            return true;
                        }
                    };
                    trustAllHosts();
                    URL url = new URL(bean.getUrl());
                    HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(5000);
                    conn.setHostnameVerifier(hostnameVerifier);
                    conn.connect();
                    int code = conn.getResponseCode();
                    bean.setResultCode(code);
                    InputStream inputStream = conn.getInputStream();
                    bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    final StringBuffer stringBuffer = new StringBuffer();
                    String line = null;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuffer.append(line);
                    }
                    bean.setMessage(stringBuffer.toString());
                } catch (Exception e) {
//            e.printStackTrace();
                    bean.setException(e.toString().split(":")[0]);
                    bean.setMessage(e.getMessage());
                } finally {
                    try {
                        if (bufferedReader != null) {
                            bufferedReader.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                listener.onSuccess(bean);
            }
        }.start();
    }

    public void httpPostRequest(final HttpBean bean, final HttpListener listener) {

        new Thread() {
            @Override
            public void run() {
                BufferedReader bufferedReader = null;
                try {
                    URL url = new URL(bean.getUrl());
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setConnectTimeout(5000);
                    // 设置文件字符集:
                    conn.setRequestProperty("Charset", "UTF-8");
                    //转换为字节数组
                    byte[] data = (DefaultUtils.JSON_DATA).getBytes();
                    // 设置文件长度
                    conn.setRequestProperty("Content-Length", String.valueOf(data.length));
                    // 设置文件类型:
                    conn.setRequestProperty("contentType", "application/json");
                    // 开始连接请求
                    conn.connect();
                    OutputStream out = conn.getOutputStream();
                    // 写入请求的字符串
                    out.write(data);
                    out.flush();
                    out.close();
                    int code = conn.getResponseCode();
                    bean.setResultCode(code);
                    InputStream inputStream = conn.getInputStream();
                    bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    final StringBuffer stringBuffer = new StringBuffer();
                    String line = null;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuffer.append(line);
                    }
                    bean.setMessage(stringBuffer.toString());
                } catch (Exception e) {
//            e.printStackTrace();
                    bean.setException(e.toString().split(":")[0]);
                    bean.setMessage(e.getMessage());
                } finally {
                    try {
                        if (bufferedReader != null) {
                            bufferedReader.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                listener.onSuccess(bean);
            }
        }.start();

    }

    public void httpsPostRequest(final HttpBean bean, final HttpListener listener) {
        new Thread() {
            @Override
            public void run() {
                BufferedReader bufferedReader = null;
                try {
                    HostnameVerifier hostnameVerifier = new HostnameVerifier() {
                        @Override
                        public boolean verify(String hostname, SSLSession session) {
                            return true;
                        }
                    };
                    trustAllHosts();
                    URL url = new URL(bean.getUrl());
                    HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setConnectTimeout(5000);
                    conn.setHostnameVerifier(hostnameVerifier);
                    // 设置文件字符集:
                    conn.setRequestProperty("Charset", "UTF-8");
                    //转换为字节数组
                    byte[] data = (DefaultUtils.JSON_DATA).getBytes();
                    // 设置文件长度
                    conn.setRequestProperty("Content-Length", String.valueOf(data.length));
                    // 设置文件类型:
                    conn.setRequestProperty("contentType", "application/json");
                    // 开始连接请求
                    conn.connect();
                    OutputStream out = conn.getOutputStream();
                    // 写入请求的字符串
                    out.write(data);
                    out.flush();
                    out.close();
                    int code = conn.getResponseCode();
                    bean.setResultCode(code);
                    InputStream inputStream = conn.getInputStream();
                    bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    final StringBuffer stringBuffer = new StringBuffer();
                    String line = null;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuffer.append(line);
                    }
                    bean.setMessage(stringBuffer.toString());
                } catch (Exception e) {
//            e.printStackTrace();
                    bean.setException(e.toString().split(":")[0]);
                    bean.setMessage(e.getMessage());
                } finally {
                    try {
                        if (bufferedReader != null) {
                            bufferedReader.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                listener.onSuccess(bean);
            }
        }.start();

    }

    private static void trustAllHosts() {
        // Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return new java.security.cert.X509Certificate[] {};
            }
            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                Log.i("skyapp", "checkClientTrusted");
            }
            public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                Log.i("skyapp", "checkServerTrusted");
            }
        } };
        // Install the all-trusting trust manager
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void release(){
        if (httpUtils != null) {
            httpUtils = null;
        }
    }

}
