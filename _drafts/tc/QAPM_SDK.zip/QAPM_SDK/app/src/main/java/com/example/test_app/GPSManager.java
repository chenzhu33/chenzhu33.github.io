package com.example.test_app;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.os.HandlerThread;
import android.util.Log;

/**
 * Created by toringzhang on 2017/12/15.
 */

public class GPSManager {

    private String TAG = "GPSManager";
    private LocationManager mLocationManager;
    // flag for GPS status
    boolean isGPSEnabled = false;
    // flag for network status
    boolean isNetworkEnabled = false;
    boolean canGetLocation = false;
    HandlerThread ht;
    Location location; // location
    double latitude; // latitude
    double longitude; // longitud

    // The minimum distance to change Updates in meters
    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 10; // 10 meters

    // The minimum time between updates in milliseconds
    private static final long MIN_TIME_BW_UPDATES = 1000 * 60 * 1; // 1 minute

    private final Context mContext;

    public GPSManager(Context context){
        this.mContext = context;
        this.ht = new HandlerThread("testgps");
        ht.start();
    }


    public Location getLocation() {
        ILogUtil.getInstance(true).d("GPSManager", "getLocation");
        try {
            mLocationManager = (LocationManager) mContext
                    .getSystemService(Context.LOCATION_SERVICE);

            // getting GPS status
            isGPSEnabled = mLocationManager
                    .isProviderEnabled(LocationManager.GPS_PROVIDER);

            // getting network status
            isNetworkEnabled = mLocationManager
                    .isProviderEnabled(LocationManager.NETWORK_PROVIDER);

            if (!isGPSEnabled && !isNetworkEnabled) {
                // no network provider is enabled
                ILogUtil.getInstance(true).d("GPSManager", "cannot use gps.");
            } else {
                this.canGetLocation = true;

                // First get location from Network Provider
                if (isNetworkEnabled) {

                    mLocationManager.requestLocationUpdates(
                            LocationManager.NETWORK_PROVIDER,
                            MIN_TIME_BW_UPDATES,
                            MIN_DISTANCE_CHANGE_FOR_UPDATES, locationListener,ht.getLooper());
                    mLocationManager.requestSingleUpdate(LocationManager.NETWORK_PROVIDER,locationListener,ht.getLooper());
                    if (mLocationManager != null) {
                        location = mLocationManager
                                .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                        if (location != null) {
                            latitude = location.getLatitude();
                            longitude = location.getLongitude();
                            ILogUtil.getInstance(true).d(TAG+"NETWORK","latitude:"+latitude);
                            ILogUtil.getInstance(true).d(TAG+"NETWORK","longitude:"+longitude);
                        }
                    }
                }
                // if GPS Enabled get lat/long using GPS Services
                if (isGPSEnabled) {
                    mLocationManager.requestLocationUpdates(
                            LocationManager.GPS_PROVIDER,
                            MIN_TIME_BW_UPDATES,
                            MIN_DISTANCE_CHANGE_FOR_UPDATES, locationListener,ht.getLooper());
                    if (mLocationManager != null) {
                        location = mLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                        if (location != null) {
                            ILogUtil.getInstance(true).d("GPSManager", "GPS Enabled");
                            latitude = location.getLatitude();
                            longitude = location.getLongitude();
                            ILogUtil.getInstance(true).d(TAG+"GPS","latitude:"+latitude);
                            ILogUtil.getInstance(true).d(TAG+"GPS","longitude:"+longitude);
                        }
                    }
                }
            }

        } catch (SecurityException e) {
            e.printStackTrace();
        }

        return location;
    }

    private LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            ILogUtil.getInstance(true).d(TAG, "onProviderDisabled.location = " + location);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            ILogUtil.getInstance(true).d(TAG, "onStatusChanged() called with " + "provider = [" + provider + "], status = [" + status + "], extras = [" + extras + "]");
            switch (status) {
                case LocationProvider.AVAILABLE:
                    ILogUtil.getInstance(true).i(TAG, "AVAILABLE");
                    break;
                case LocationProvider.OUT_OF_SERVICE:
                    ILogUtil.getInstance(true).i(TAG, "OUT_OF_SERVICE");
                    break;
                case LocationProvider.TEMPORARILY_UNAVAILABLE:
                    Log.i(TAG, "TEMPORARILY_UNAVAILABLE");
                    break;
            }
        }

        @Override
        public void onProviderEnabled(String provider) {
            ILogUtil.getInstance(true).d(TAG, "onProviderEnabled() called with " + "provider = [" + provider + "]");
            try {
                Location location = mLocationManager.getLastKnownLocation(provider);
                ILogUtil.getInstance(true).d(TAG, "onProviderDisabled.location = " + location);
            }catch (SecurityException e){

            }
        }

        @Override
        public void onProviderDisabled(String provider) {
            ILogUtil.getInstance(false).d(TAG, "onProviderDisabled() called with " + "provider = [" + provider + "]");
        }
    };

    public void stopLocationUpdates() {

        mLocationManager.removeUpdates(locationListener);
    }


}
