package com.example.test_app.http.utils;



import com.example.test_app.http.bean.HttpBean;
import com.example.test_app.http.listener.HttpListener;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

public class HttpClientUtils {

    private volatile static HttpClientUtils httpClientUtils;

    private HttpClientUtils() {
    }

    public static HttpClientUtils getInstance() {
        if (httpClientUtils == null) {
            synchronized (HttpClientUtils.class) {
                if (httpClientUtils == null) {
                    httpClientUtils = new HttpClientUtils();
                }
            }
        }
        return httpClientUtils;
    }

    public void getRequest(final HttpBean bean, final HttpListener listener) {
        new Thread() {
            @Override
            public void run() {
                // 创建Httpclient对象
                HttpClient httpClient = new DefaultHttpClient();
                // 创建http GET请求
                HttpGet httpGet = new HttpGet(bean.getUrl());
                try {
                    // 执行请求
                    if (bean.getUrl().startsWith("https")) {
                        SSLSocketFactory.getSocketFactory().setHostnameVerifier(new AllowAllHostnameVerifier());
                    }
                    HttpResponse response = httpClient.execute(httpGet);
                    // 判断返回状态是否为200
                    bean.setResultCode(response.getStatusLine().getStatusCode());
//                    if (response.getStatusLine().getStatusCode() == 200) {
                    //请求体内容
                    String content = EntityUtils.toString(response.getEntity(), "UTF-8");//取消200返回码的判断，任何情况都进行下列操作
                    //内容写入文件
                    bean.setMessage(content);
//                    }
                    listener.onSuccess(bean);

                } catch (Exception e) {
                    bean.setMessage(e.getMessage());
                    bean.setException(e.toString().split(":")[0]);
                    listener.onFailed(bean);
                }
            }
        }.start();
    }

    public void postRequest(final HttpBean bean, final HttpListener listener) {
        new Thread() {
            @Override
            public void run() {
                // 创建Httpclient对象
                HttpClient httpclient = new DefaultHttpClient();
                // 创建http POST请求
                HttpPost httpPost = new HttpPost(bean.getUrl());
                //伪装浏览器请求
//        httpPost.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36");
                httpPost.addHeader("Content-Type", "application/json;charset=UTF-8");

                // 解决中文乱码问题
                StringEntity stringEntity = new StringEntity(DefaultUtils.JSON_DATA, "UTF-8");
                stringEntity.setContentEncoding("UTF-8");

                httpPost.setEntity(stringEntity);

                HttpResponse response = null;
                try {
                    // 执行请求

                    if (bean.getUrl().startsWith("https")) {
                        SSLSocketFactory.getSocketFactory().setHostnameVerifier(new AllowAllHostnameVerifier());
                    }

                    response = httpclient.execute(httpPost);
                    // 判断返回状态是否为200
                    bean.setResultCode(response.getStatusLine().getStatusCode());
//                    if (response.getStatusLine().getStatusCode() == 200) { //取消200返回码的判断，任何情况都进行下列操作
                    String content = EntityUtils.toString(response.getEntity(), "UTF-8");  //后加入
                    //内容写入文件
                    bean.setMessage(content);
//                    }
                    listener.onSuccess(bean);
                } catch (Exception e) {
                    bean.setMessage(e.getMessage());
                    bean.setException(e.toString().split(":")[0]);
                    listener.onFailed(bean);
                }
            }
        }.start();
    }

    public void release(){
        if (httpClientUtils != null) {
            httpClientUtils = null;
        }
    }
}
