package com.example.test_app.report;

/**
 * Created by toringzhang on 2017/12/18.
 */

import java.util.Arrays;

import org.json.JSONObject;

import android.os.Environment;
import android.os.Looper;

import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.reporter.ResultObject;
import com.tencent.qapmsdk.reporter.ReporterMachine;

public class ReportToYunYing {
    private static final String TAG = ReportToYunYing.class.getSimpleName();
    private static final String sdPath = Environment.getExternalStorageDirectory().getPath();

    public void reportFileAtOnce() {
        try {
            JSONObject params = new JSONObject();
            params.put("plugin", Config.PLUGIN_QCLOUD_CEILING_HPROF);
            params.put("versionname", "6.3.0.0");
            params.put("uin", Magnifier.info.uin);
            params.put("model", "iPhone6");
            params.put("processname", "com.example.sdkapp");
            params.put("stage", "MainActivity");
            params.put("timecost", "112233");
            params.put("p_id", 1);
            params.put("fileObj", sdPath + "/dump.zip");
            ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, Magnifier.info.uin);
            ReporterMachine.addResultObj(ro);
        } catch (Exception e) {}
    }

    public void reportFileLater() {
        try {
            JSONObject params = new JSONObject();
            params.put("plugin", Config.PLUGIN_QCLOUD_CEILING_HPROF);
            params.put("versionname", "6.3.0.0");
            params.put("uin", Magnifier.info.uin);
            params.put("model", "iPhone6");
            params.put("processname", "com.example.sdkapp");
            params.put("stage", "MainActivity");
            params.put("timecost", "112233");
            params.put("p_id", 1);
            params.put("fileObj", sdPath + "/dump.zip");
            ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, false, true, Magnifier.info.uin);
            ReporterMachine.addResultObj(ro);
        } catch (Exception e) {}
    }

    public void reportJsonAtOnce() {
        try {
            JSONObject params = new JSONObject();
            String stage = "MainActivity";
            params.put("stage", stage != null ? stage : "");
            params.put("timecost", 3000);
            params.put("p_id", 1);
            params.put("cost_time", 3000);
            StackTraceElement[] stack = Looper.getMainLooper().getThread().getStackTrace();
            params.put("stack", Arrays.toString(stack));
            params.put("plugin", Config.PLUGIN_QCLOUD_LOOPER_STACK);

            String uin = Magnifier.info.uin;
            for (int i = 0; i < 3; i++) {
                ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, true, true, uin + i);
                ReporterMachine.addResultObj(ro);
            }
        } catch (Exception e) {}
    }

    public void reportJsonLater() {
        try {
            JSONObject params = new JSONObject();
            String stage = "MainActivity";
            params.put("stage", stage != null ? stage : "");
            params.put("timecost", 3000);
            params.put("p_id", 1);
            params.put("cost_time", 3000);
            StackTraceElement[] stack = Looper.getMainLooper().getThread().getStackTrace();
            params.put("stack", Arrays.toString(stack));
            params.put("plugin", Config.PLUGIN_QCLOUD_LOOPER_STACK);

            String uin = Magnifier.info.uin;
            for (int i = 0; i < 3; i++) {
                ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, false, true, uin + i);
                ReporterMachine.addResultObj(ro);
            }
            com.example.test_app.ILogUtil.getInstance(true).d("Repport", "report to yunying test");
        } catch (Exception e) {}
    }
}