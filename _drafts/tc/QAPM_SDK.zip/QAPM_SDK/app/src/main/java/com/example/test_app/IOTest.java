package com.example.test_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.os.HandlerThread;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by toringzhang on 2017/12/11.
 */

public class IOTest {

    private Context mContext;
    private final String TAG = "IOTest";
    private SQLiteDatabase sqliteDB = null;
    public IOTest(Context context){
        mContext = context;
    }

    public void FileTest() {
        ILogUtil.getInstance(false).d(TAG,"文件I/O用例");
        File filep;
        File filedir;
        String testFile = "testFile_"+ String.valueOf(System.currentTimeMillis())+".txt";

        String filePath = mContext.getFilesDir().getAbsolutePath();
        filedir = new File(filePath);
        if (!filedir.exists()) {
            filedir.mkdir();
        }
        try {
            filep=new File(filedir+"/"+testFile);
            if (!filep.exists()) {
                try {
                    filep.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            String str = "我在测试文件I/O呀！！！我在测试文件I/O呀！！！我在测试文件I/O呀！！！";
            byte bt[] = new byte[1024];
            bt = str.getBytes();
            for(int i = 0; i < 500; i++)
            {
                try {
                    FileOutputStream in = new FileOutputStream(filep);
                    in.write(bt, 0, bt.length);
                    in.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void SQLiteDatabaseTest() {
        ILogUtil.getInstance(false).d(TAG,"Sqlite测试用例");
        File dbf;
        File dbp;
        String dbPath;
        String qqDB = "2872971611.db";

        String filePath = mContext.getFilesDir().getAbsolutePath();
        dbPath = filePath.replace("files", "databases");
        dbp=new File(dbPath);
        if (!dbp.exists()) {
            dbp.mkdir();
        }

        boolean isExist = true;
        try {
            dbf=new File(dbPath+"/"+qqDB);
            if(!dbf.exists()){
                isExist = false;
                try {
                    dbf.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(sqliteDB == null){
                sqliteDB = SQLiteDatabase.openOrCreateDatabase(dbf, null);
            }

            if(!isExist){
                String sql_create = "create table if not exists events(_id INTEGER PRIMARY KEY, content TEXT, status INTEGER, send_count INTEGER, timestamp INTEGER)";
                sqliteDB.execSQL(sql_create);
            }

            sqliteDB.beginTransaction();
            String sql = "insert into events  (content, status, send_count, timestamp) values ('test', 0,"+ String.valueOf((int)(Math.random()*100)) +" , 31)";


            try{

                for(int i=0;i < 10;i++){
                    sqliteDB.execSQL(sql);
                }
                ContentValues values = new ContentValues();
                long curtime = 0;
                //这里设置60000循环可以验证是否有引用泄漏
                for (int j=0; j < 10; j++){
                    values.put("status", j);
                    sqliteDB.update("events", values, "content=?", new String[]{"test"});
                }
            }catch (Exception e){
                e.printStackTrace();
            }finally {
                sqliteDB.endTransaction();
            }

            sqliteDB.close();
            sqliteDB = null;
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public StackTraceElement[] getStackTrace() {
        HandlerThread ht = new HandlerThread("IOTest2222");
        ht.start();
        Handler h = new Handler(ht.getLooper());
        h.post(new Runnable() {
            @Override
            public void run() {
                // TODO Auto-generated method stub
                try {
                    for (int i = 0; i < 3; i++) {
                        FileTest();
                    }
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });

        return ht.getStackTrace();
    }

}
