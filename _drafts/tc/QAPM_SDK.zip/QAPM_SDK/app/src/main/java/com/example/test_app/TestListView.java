package com.example.test_app;

import android.app.ListActivity;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;

import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.dropframe.DropFrameMonitor;

/**
 * Created by toringzhang on 2017/12/8.
 */

public class TestListView extends ListActivity {
    /** Called when the activity is first created.*/
    private Handler testlistviewHandler;
    private class ExitRun implements Runnable {
        @Override
        public void run() {
            TestListView.this.finish();
        }
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ILogUtil.getInstance(false).d("TestListView","测试滑动列表");
        //璁剧疆涓�釜Adapter
        setListAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,COUNTRIES));
        if (null == testlistviewHandler) {
//    		HandlerThread ht = new HandlerThread("TestListview");
//    		ht.start();
            testlistviewHandler = new Handler(Looper.getMainLooper());
        }
        if (Build.VERSION.SDK_INT >= 19){
            getListView().setOnScrollListener(new AbsListView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(AbsListView view, int scrollState) {
                    if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                        QAPM.endScene("MainActivity", QAPM.ModeDropFrame);
                    } else {
                        QAPM.beginScene("MainActivity", QAPM.ModeDropFrame);
                    }
                }

                @Override
                public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

                }
            });
        }

        if (null == testlistviewHandler) {
//    		HandlerThread ht = new HandlerThread("TestListview");
//    		ht.start();
            testlistviewHandler = new Handler(Looper.getMainLooper());
        }
        testlistviewHandler.postDelayed(new Runnable() {
            int count=0;
            @Override
            public void run() {
                DropFrameMonitor.getInstance().start("test");
                getListView().smoothScrollToPosition(600);
                ILogUtil.getInstance(false).d("TestListView","count:"+count);
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                getListView().smoothScrollToPosition(0);
                DropFrameMonitor.getInstance().stop();
                if(count<5)
                {
                    testlistviewHandler.postDelayed(this,1000);
                }
                else
                {
                    ILogUtil.getInstance(false).d("TestListView","finish!"+count);
                    testlistviewHandler.postDelayed(new ExitRun(),1000);
                }
                count+=1;
            }
        }, 1000);



    }

    private  static final String[] COUNTRIES=new String[]{"test1","test2","test3","test4","test5","test6","test7","test8","test9","test10","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test","test"};
}
