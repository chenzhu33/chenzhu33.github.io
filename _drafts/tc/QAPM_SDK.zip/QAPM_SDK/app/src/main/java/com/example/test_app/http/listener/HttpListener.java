package com.example.test_app.http.listener;


import com.example.test_app.http.bean.HttpBean;

public interface HttpListener {

    void onFailed(HttpBean bean);

    void onSuccess(HttpBean bean);

}
