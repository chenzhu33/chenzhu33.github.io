package com.example.test_app.utils;

import java.net.URL;

import android.util.Log;

import com.tencent.smtt.sdk.network.InterceptConfig;
import com.tencent.smtt.sdk.network.InterceptExternalClient;
import com.tencent.smtt.sdk.network.InterceptManager;
import com.tencent.smtt.sdk.plugin.PluginManager;

public class X5CoreInitTest {
    private static final String TAG = "X5CoreInitTest";

    private X5CoreInitTest() {
    }

    public static void initTestCode() {
        PluginManager.setPrintDebugLog(true);//打印插件安装log
        InterceptConfig.setInterceptAllForTest(false);//开启全部拦截，默认为false
        InterceptConfig.setPrintImplicitInterceptInfoForTest(true);//当拦截到未明确配置的url时输出对应的url和调用栈，log的tag为InterceptLog，默认为false
        //InterceptConfig.setPrintInterceptExceptionStackTrace(true);//外部出现异常调用printStackTrace时是否能打印出栈信息,默认为false不打印栈信息

        //添加需要拦截的url,例如前缀匹配规则https://res.imtt.qq.com/*，或url整个匹配http://connect.rom.miui.com/generate_204
        //InterceptManager.getInstance().addInterceptUrl("xxx");

        //添加不要拦截的url,例如前缀匹配规则https://res.imtt.qq.com/*，或url整个匹配http://connect.rom.miui.com/generate_204
        //InterceptManager.getInstance().excludeInterceptUrl("xxx");

        //添加不要拦截的url后缀，例如".apk"
        //InterceptManager.getInstance().addExcludeInterceptUrlPostfix("xxx");

        if (false) {
            //设置外部拦截client，当设置了该client后所有是否拦截的判断都由该client进行处理
            InterceptManager.getInstance().setInterceptExternalClient(new InterceptExternalClient() {
                @Override
                public boolean shouldIntercept(URL url) {
                    if (url.getHost().contains("sngapm.qq.com") || url.getHost().contains("162.14.17.144")){
                        return false;
                    }
                    return true;
                }
            });
        }
    }

    private static void printStackTrace() {
        Exception stackException = new Exception();
        String stackTrace = Log.getStackTraceString(stackException);
        Log.e(TAG, stackTrace);
    }
}
