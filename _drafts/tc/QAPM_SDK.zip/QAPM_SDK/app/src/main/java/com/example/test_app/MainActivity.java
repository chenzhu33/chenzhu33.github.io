package com.example.test_app;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.test_app.http.activity.ManagerActivity;
import com.example.test_app.http.bean.HttpBean;
import com.example.test_app.http.listener.HttpListener;
import com.example.test_app.http.utils.DefaultUtils;
import com.example.test_app.http.utils.OkHttp_311_Utils;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.config.Config;
import com.tencent.qapmsdk.crash.config.CoreConfiguration;
import com.tencent.qapmsdk.crash.util.NativeCrashCatcher;
import com.tencent.qapmsdk.dns.HttpDns;
import com.tencent.qapmsdk.memory.LeakInspector;
import com.tencent.qapmsdk.reporter.ReporterMachine;
import com.tencent.qapmsdk.reporter.ResultObject;
import com.tencent.qapmsdk.sample.PerfCollector;
import com.tencent.qapmsdk.socket.TrafficConnectReporter;
import com.tencent.qapmsdk.socket.TrafficMonitor;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.ConnectionPool;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import okio.BufferedSource;

public class MainActivity extends AppCompatActivity {

    private Handler testHandler;
    private IOTest ioTest;
    private GPSManager gpsManager;
    private final String TAG = "MainActivity";
    private PowerManager mPowerManager;
    private PowerManager.WakeLock wakeLock;
    private IMyAidlInterface iMyAidlInterface;

    private static final String sdPath = Environment.getExternalStorageDirectory().getPath();

    private ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            ILogUtil.getInstance(true).e("APP", "onServiceConnected");
            iMyAidlInterface = IMyAidlInterface.Stub.asInterface(service);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            ILogUtil.getInstance(true).e("APP", "onServiceDisconnected");
            iMyAidlInterface = null;
        }
    };
    private String[] permissions;

    private class MainRun implements Runnable {
        //启动后自动运行测试，目的是在wetest上能够保证基本功能都会执行到
        @Override
        public void run() {
            try {
                Thread.sleep(2000);
                ioTest.SQLiteDatabaseTest();
                ioTest.FileTest();
                gpsManager.getLocation();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        QAPM.setProperty(QAPM.PropertyKeyAppInstance, getApplication());
//        QAPM.setProperty(QAPM.PropertyKeyHost, "http://162.14.17.144:30080");
        // 33e15431-1024 e3e4972c-4620 c61b0684-14199
        QAPM.setProperty(QAPM.PropertyKeyAppId, "33e15431-1024").setProperty(QAPM.PropertyKeyAppVersion, "4.1.1").setProperty(QAPM.PropertyKeySymbolId, "e6ae1282-ceb8-4237-89bd-2d23d00a8e33");
        QAPM.setProperty(QAPM.PropertyKeyUserId, "11223344").setProperty(QAPM.PropertyKeyLogLevel, QAPM.LevelVerbos);
//        QAPM.setProperty(QAPM.PropertyKeyHost, "https://qapm.qq.com");

//        try {
//            Class config = Class.forName("com.tencent.qapmsdk.config.Config");
//            Field field = config.getDeclaredField("CONFIG_URL");
//            field.setAccessible(true);
//            field.set(null, "http://162.14.17.144:30063/appconfig/v3/config/14199/");
//        }catch (Exception e){
//            e.printStackTrace();
//        }

        QAPM.setProperty(QAPM.PropertyInspectorListener, new LeakInspector.InspectorListener() {

            @Override
            public boolean onFilter(Object willCheckedObj) {
                /**
                 * 可定义不检查泄漏的类或对象
                 * @param obj -- 待检查的对象
                 * @return boolean，为true时该类将不被检查
                 */
                if (willCheckedObj.getClass().getName().equals("com.example.test_app.NeverLeakedActivity")) {
                    Toast.makeText(getApplicationContext(), String.format("%s对象不检测", willCheckedObj.getClass().getName()), Toast.LENGTH_LONG).show();
                    return true;
                }
                Log.d(TAG, "Filter Object " + willCheckedObj.getClass().getName());
                return false;
            }

            @Override
            public void onCheckingLeaked(int currentWaitSecond, String objInfo) {
                /**
                 * 等待dump回调，可以获取已经等待的时间，并提前结束等待
                 * @param currentWaitSecond:已经等待时间, objDigest:监控对象信息
                 * @return
                 */
                if (currentWaitSecond == 15) {
                    Toast.makeText(getApplicationContext(), String.format("泄漏检测进行%ds,对象%s可能存在泄漏，", currentWaitSecond, objInfo), Toast.LENGTH_LONG).show();
                    Log.d(TAG, "Wait For " + objInfo + " Leak " + String.valueOf(currentWaitSecond) + "s");
                }

            }

            @Override
            public boolean onLeaked(LeakInspector.InspectUUID uuid) {
                /**
                 * 判定发生泄漏后执行的回调，可用来提前展示泄漏相关信息，也可以通过返回值认为此次并非泄漏
                 * @param InspectUUID:包含被监控对象相关信息，uuid.toString()后即为objInfo
                 * @return boolean: 默认为true，认为这是一次泄漏并开始dump，为false时认为这不是泄漏
                 */
                if (uuid.toString().equals("com.example.test_app.NeverLeakedActivity")) {
                    return false;
                }
                Toast.makeText(getApplicationContext(), String.format("对象%s检测发现存在泄漏，", uuid.toString()), Toast.LENGTH_LONG).show();
                Log.d(TAG, uuid.toString() + " Leaked !!!");
                return true;
            }

            @Override
            public List<String> onPrepareDump(final String objInfo) {
                /**
                 * 这个接口通知要dump内存，可以在这里实现Toast提醒或转圈等逻辑，因为dump的过程比较耗时而且会卡住进程
                 * @param objInfo:泄漏对象信息
                 * @return 最终上报的zip包中所需要的其他文件
                 */
                Toast.makeText(getApplicationContext(), "开始对" + objInfo + "泄漏进行内存dump", Toast.LENGTH_LONG).show();
                Magnifier.ILOGUTIL.d(TAG, objInfo, " Leaked: Prepare Dump");
                List<String> file_list = new ArrayList<String>();
                //添加其他相关信息到zip文件中，便于定位
                file_list.add("/storage/emulated/0/Download/test.txt");
                return file_list;
            }

            @Override
            public void onFinishDump(final boolean isSuccess, final String objInfo, final String zipPath) {
                /**
                 * dump结束回调，若实现了提醒或转圈逻辑可以在此结束
                 * @param isSuccess:dump是否成功；objInfo:泄漏对象相关信息；zipPath：打包上传的zip文件路径
                 */
                if (isSuccess) {
                    Toast.makeText(getApplicationContext(), objInfo + "内存dump结束，本地路径" + zipPath, Toast.LENGTH_LONG).show();
                    Log.d(TAG, objInfo + " Leaked: Dump Seccess");
                } else {
                    Toast.makeText(getApplicationContext(), objInfo + "dump失败！！", Toast.LENGTH_LONG).show();
                    Log.d(TAG, objInfo + " Leaked: Finish Dump Faild");
                }

            }


        });
//        QAPM.setProperty(QAPM.PropertyKeyEventCon, true);
//        Config.switchRef = 1023;
//        CoreConfiguration conf = CoreConfiguration.getInstance();
//        conf.setIsNativeCatch(true);

//        String host = getIntent().getStringExtra(ApmSetting.EXTRA_MESSAGE);
//        String appId = getIntent().getStringExtra("appId");
//        if(!host.isEmpty()){
//            Log.i("host", host);
//            QAPM.setProperty(QAPM.PropertyKeyHost, host);
//        }
//        if(!appId.isEmpty()){
//            Log.i("app_id", appId);
//            QAPM.setProperty(QAPM.PropertyKeyAppId, appId);
//        }

        setSqliteUploadSize(20 * 1024);

        QAPM.beginScene(QAPM.SCENE_ALL, QAPM.ModeAll ^ QAPM.ModeANR);
        QAPM.endScene("qidong", PerfCollector.APPLAUNCH, QAPM.ModeResource);
        if (Build.VERSION.SDK_INT >= 23) {
            String[] permissions = {
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission_group.LOCATION,
                    Manifest.permission_group.STORAGE,
                    Manifest.permission.WAKE_LOCK,
                    Manifest.permission.ACCESS_WIFI_STATE,
                    Manifest.permission.CHANGE_WIFI_STATE,
                    Manifest.permission.CHANGE_NETWORK_STATE,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.READ_PHONE_STATE,
            };

            if (checkCallingOrSelfPermission(permissions[0]) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(permissions, 0);
            } else {

            }

        }

        ioTest = new IOTest(MainActivity.this);
        gpsManager = new GPSManager(MainActivity.this);
        mPowerManager = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = mPowerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "qapmapp::MyWakelockTag");
        ILogUtil.getInstance(true).d(TAG, "now begin test。。。");


//        getSystemProperty("log.level");
        if (null == testHandler) {
            HandlerThread ht = new HandlerThread("TestMain");
            ht.start();
            testHandler = new Handler(ht.getLooper());
            MainRun mainrun = new MainRun();
            testHandler.postDelayed(mainrun, 1500);
        }

        //测试数据库
        Button btnTestDB = (Button) findViewById(R.id.btntestdb);
        btnTestDB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                HandlerThread ht = new HandlerThread("DbTest");
                ht.start();
                Handler h = new Handler(ht.getLooper());
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        // TODO Auto-generated method stub
                        try {
                            for (int i = 0; i < 3; i++) {
                                ioTest.SQLiteDatabaseTest();
                                Thread.sleep(1000);
                            }
                        } catch (Exception e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                });

            }
        });

        //上报测试
        Button btnTestLooper = (Button) findViewById(R.id.btnreport);
        btnTestLooper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // upload call stack
                    JSONObject params2 = new JSONObject();
                    params2.put("stage", "MainActivity");
                    params2.put("cost_time", 3000);
//                    StackTraceElement[] stack = Looper.getMainLooper().getThread().getStackTrace();
                    StackTraceElement[] stack = ioTest.getStackTrace();
                    params2.put("stack", Arrays.toString(stack));
                    params2.put("plugin", Config.PLUGIN_QCLOUD_LOOPER_STACK);
                    ResultObject ro2 = new ResultObject(0, "testcase", true, 1, 1, params2, true, true, Magnifier.info.uin);
                    ReporterMachine.addResultObj(ro2);

                    // upload battery
                    String s = "{\"fg30LogCount\":[{\"count\":\"0\",\"time\":1511696099},{\"count\":\"0\",\"time\":1511696109}],\"fg30SysDetail\":[{\"timeList\":[1511695647],\"tag\":\"[c.t.m.g.cz$1.run(TL:109),com.tencent.mobileqq.javahooksdk.JavaHookBridge.handleHookMethod(JavaHookBridge.java:236)]\"}],\"fg30WFSCount\":[{\"count\":\"43\",\"time\":1511696099},{\"count\":\"0\",\"time\":1511696109}],\"fg30WlCount\":[{\"useBatteryTime\":0,\"count\":\"0\",\"useTime\":0,\"time\":1511696099},{\"useBatteryTime\":0,\"count\":\"0\",\"useTime\":0,\"time\":1511696109}],\"fg30CmdCount\":[{\"count\":\"0\",\"time\":1511696099},{\"count\":\"0\",\"time\":1511696109}],\"fg30SysCount\":[{\"count\":\"3\",\"time\":1511696109},{\"count\":\"0\",\"time\":1511696158}],\"fg30SdkDetail\":[{\"timeList\":[1511695039],\"tag\":\"PrecoverLbsConfig\"},{\"timeList\":[1511695402,1511695650,1511695395,1511695344,1511695307,1511695310,1511695306,1511695342,1511695416,1511695342,1511695309,1511695309,1511695357,1511695307,1511695374,1511695313,1511695379,1511695310,1511695676,1511695651,1511695479,1511695310,1511695395,1511695445,1511695309,1511695269,1511695395,1511695649,1511695445,1511695678,1511695311,1511695490,1511695445,1511695488,1511695248,1511695476,1511695307,1511695309,1511695310,1511695400,1511695459,1511695395,1511695650,1511695394,1511695342,1511695678,1511695308,1511695445,1511695342,1511695464,1511695342,1511695310,1511695309,1511695309,1511695356,1511695305,1511695306,1511695342,1511695342,1511695307,1511695307,1511695496,1511695445,1511695483,1511695342,1511695351,1511695414,1511695342,1511695679,1511695348,1511695342,1511695650,1511695310,1511695342,1511695408,1511695395,1511695470,1511695355,1511695310,1511695444,1511695342,1511695308,1511695492,1511695307,1511695485,1511695415,1511695346,1511695342,1511695676,1511695651,1511695446,1511695445,1511695306,1511695309,1511695648,1511695310,1511695305,1511695311,1511695307,1511695649,1511695353,1511695299,1511695376,1511695649,1511695395,1511695398,1511695309,1511695678,1511695289,1511695446,1511695395,1511695394,1511695412,1511695306,1511695395,1511695395,1511695463,1511695342,1511695308,1511695309,1511695305,1511695307,1511695342,1511695447,1511695474,1511695309,1511695309,1511695475,1511695307,1511695470,1511695408,1511695650,1511695364,1511695651,1511695678,1511695306,1511695445,1511695409,1511695457,1511695311,1511695310,1511695648,1511695446,1511695307,1511695498,1511695443,1511695362,1511695309,1511695494,1511695481,1511695445,1511695311,1511695306,1511695301,1511695309,1511695442,1511695306,1511695649,1511695284,1511695360,1511695450,1511695456,1511695310,1511695676,1511695472,1511695307,1511695395,1511695309,1511695650],\"tag\":\"QQMapActivity\"},{\"timeList\":[1511695039],\"tag\":\"wealthgod_locate_check\"},{\"timeList\":[1511695039],\"tag\":\"GeneralLBSConfigs\"},{\"timeList\":[1511695034],\"tag\":\"ArkAppLocationManager\"}],\"fg30WFLCount\":[{\"useBatteryTime\":0,\"count\":\"0\",\"useTime\":0,\"time\":1511696099},{\"useBatteryTime\":0,\"count\":\"0\",\"useTime\":0,\"time\":1511696109}],\"device\":\"MI 4C\",\"uin\":\"328659992\",\"fg30SdkCount\":[{\"count\":\"173\",\"time\":1511696109},{\"count\":\"0\",\"time\":1511696124}],\"sdk\":19,\"fg30WFSDetail\":[{\"timeList\":[1511696083,1511695625],\"tag\":\"[c.t.m.g.dd.onCellInfoChanged(TL:173),c.t.m.g.dd.a(TL:198),c.t.m.g.cm.b(TL:359),c.t.m.g.da.onCellInfoEvent(TL:936),c.t.m.g.di.b(TL:142),c.t.m.g.di.c(TL:233),c.t.m.g.ee.a(TL:123),com.tencent.mobileqq.javahooksdk.JavaHookBridge.handleHookMethod(JavaHookBridge.java:236)]\"},{\"timeList\":[1511695342,1511695456,1511695307,1511695306,1511695651,1511695445,1511695308,1511695299,1511695395,1511695410,1511695461,1511695403,1511695395,1511695445,1511695677,1511695342,1511695345,1511695310,1511695309,1511695361,1511695395,1511695650,1511695649,1511695313,1511695200,1511695442,1511695305,1511695307,1511695493,1511695446,1511695342,1511695485,1511695311,1511695309,1511695309,1511695307,1511695477,1511695376,1511695353,1511695310,1511695470],\"tag\":\"[c.t.m.g.di$1.run(TL:70),c.t.m.g.di.a(TL:29),c.t.m.g.di.c(TL:233),c.t.m.g.ee.a(TL:123),com.tencent.mobileqq.javahooksdk.JavaHookBridge.handleHookMethod(JavaHookBridge.java:236)]\"}]}";
                    JSONObject params3 = new JSONObject();
                    params3.put("plugin", Config.PLUGIN_QCLOUD_NEW_BATTERY);
                    params3.put("batterydata", new JSONObject(s));
                    ResultObject ro3 = new ResultObject(0, "testcase", true, 1, 1, params3, true, true, Magnifier.info.uin);
                    ReporterMachine.addResultObj(ro3);

                    // upload drop frame
                    JSONObject joInner = new JSONObject();
                    JSONObject jo2InnerLevel = new JSONObject();
                    JSONArray joDropTimes = new JSONArray();
                    long[] item = {350, 1, 0, 0, 0, 0};
                    jo2InnerLevel.put("dropDuration", 5.881160736083984);
                    for (int i = 0; i < 6; ++i) {
                        joDropTimes.put(i, item[i]);
                    }
                    jo2InnerLevel.put("dropTimes", joDropTimes);
                    joInner.put("0", jo2InnerLevel);
                    JSONObject r = new JSONObject();
                    r.put("MainActivity", joInner);
                    JSONObject params4 = new JSONObject();
                    params4.put("dropFrame", r);
                    params4.put("plugin", Config.PLUGIN_QCLOUD_DROPFRAME);
                    ResultObject ro4 = new ResultObject(0, "testcase", true, 1, 1, params4, true, true, Magnifier.info.uin);
                    ReporterMachine.addResultObj(ro4);

                    // upload crash
                    JSONObject crasher = new JSONObject("{\"plugin\":135,\"parts\":[{\"category\":\"crash\",\"exp_type\":\"\",\"exp_name\":\"java.lang.Error\",\"exp_reason\":\"signal 11 (Address not mapped to object) at address 0x100\",\"launch_uuid\":\"1554968911372\",\"stack_normal_crash\":{\"time_slices\":[{\"duration\":0,\"threads\":[{\"name\":\"1\",\"frame\":{\"calls\":[\"\\/data\\/app\\/com.toringzhang.crashdemo-1\\/lib\\/arm\\/libapmcrash.so.0x2612(Native Method)\",\"\\/system\\/bin\\/app_process32.0xaaaabf7a(InvokeUserSignalHandler:0x9d:0)\",\"\\/system\\/lib\\/libart.so.0x140ad6(_ZN3art12FaultManager11HandleFaultEiP7siginfoPv:0xe1:0)\",\"\\/system\\/lib\\/libc.so.0x171b8(Native Method)\",\"\\/data\\/app\\/com.toringzhang.crashdemo-1\\/lib\\/arm\\/libnative.so.0x58a4(_Z12emptyPointerv:0xb:0)\",\"\\/data\\/app\\/com.toringzhang.crashdemo-1\\/lib\\/arm\\/libnative.so.0x5d04(Java_com_toringzhang_crashdemo_MainActivity_emptyPointerTest:0x19:0)\",\"com.toringzhang.crashdemo.MainActivity.emptyPointerTest(Native Method)\",\"com.toringzhang.crashdemo.MainActivity$3.onClick(MainActivity.java:119)\",\"android.view.View.performClick(View.java:5647)\",\"android.view.View$PerformClick.run(View.java:22465)\",\"android.os.Handler.handleCallback(Handler.java:754)\",\"android.os.Handler.dispatchMessage(Handler.java:95)\",\"android.os.Looper.loop(Looper.java:163)\",\"android.app.ActivityThread.main(ActivityThread.java:6395)\",\"java.lang.reflect.Method.invoke(Native Method)\",\"com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:904)\",\"com.android.internal.os.ZygoteInit.main(ZygoteInit.java:794)\"]}}]}]},\"oob\":\"04-11 15:48:31.359 16116 16116 I QAPM_Native: returned _URC_OK.\\n04-11 15:48:31.359 16116 16116 I QAPM_Native: called unwind callback.\\n04-11 15:48:31.359 16116 16116 I QAPM_Native: returned _URC_OK.\\n04-11 15:48:31.359 16116 16116 I QAPM_Native: called unwind callback.\\n04-11 15:48:31.359 16116 16116 I QAPM_Native: returned _URC_OK.\\n04-11 15:48:31.359 16116 16116 I QAPM_Native: called unwind callback.\\n04-11 15:48:31.359 16116 16116 I QAPM_Native: returned _URC_OK.\\n04-11 15:48:31.359 16116 16116 I QAPM_Native: called unwind callback.\\n04-11 15:48:31.359 16116 16116 I QAPM_Native: returned _URC_OK.\\n04-11 15:48:31.359 16116 16116 I QAPM_Native: copy_context frames_size: 6\\n04-11 15:48:31.359 16116 16116 V QAPM_Native: notifyCaughtSignal\\n04-11 15:48:31.359 16116 16116 V QAPM_Native: waitForThrowException start\\n04-11 15:48:31.359 16116 16151 V QAPM_Native: waitForSignal finish.\\n04-11 15:48:31.359 16116 16151 I QAPM_Native: throwException\\n04-11 15:48:31.360 16116 16151 I QAPM_Native: Exception message: signal 11 (Address not mapped to object) at address 0x100\\n04-11 15:48:31.360 16116 16151 I QAPM_Native: check get class and method is NULL errorClass: 1, stackTraceElementClass: 1, errorClass_init: 1, errorClass_init2: 1, stackTraceElementClass_init: 1, errorClass_setStackTrace: 1, message: 1, str: 1\\n04-11 15:48:31.360 16116 16151 I QAPM_Native: backtraceSize: 6.\\n04-11 15:48:31.360 16116 16151 I QAPM_Native: dumpJavaStack start.\\n04-11 15:48:31.360 16116 16151 I QAPM_NativeCrashCatcher: threadName: main, thread: Thread[main,5,main]\\n04-11 15:48:31.361 16116 16151 I QAPM_Native: javaStackMessage: java_stack..\\n04-11 15:48:31.361 16116 16151 I QAPM_Native: strReturn: com.toringzhang.crashdemo.MainActivity.emptyPointerTest(Native Method)\\n04-11 15:48:31.361 16116 16151 I QAPM_Native: strReturn: com.toringzhang.crashdemo.MainActivity$3.onClick(MainActivity.java:119)\\n04-11 15:48:31.361 16116 16151 I QAPM_Native: strReturn: android.view.View.performClick(View.java:5647)\\n04-11 15:48:31.361 16116 16151 I QAPM_Native: strReturn: android.view.View$PerformClick.run(View.java:22465)\\n04-11 15:48:31.361 16116 16151 I QAPM_Native: strReturn: android.os.Handler.handleCallback(Handler.java:754)\\n04-11 15:48:31.361 16116 16151 I QAPM_Native: strReturn: android.os.Handler.dispatchMessage(Handler.java:95)\\n04-11 15:48:31.361 16116 16151 I QAPM_Native: strReturn: android.os.Looper.loop(Looper.java:163)\\n04-11 15:48:31.361 16116 16151 I QAPM_Native: strReturn: android.app.ActivityThread.main(ActivityThread.java:6395)\\n04-11 15:48:31.361 16116 16151 I QAPM_Native: strReturn: java.lang.reflect.Method.invoke(Native Method)\\n04-11 15:48:31.362 16116 16151 I QAPM_Native: strReturn: com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:904)\\n04-11 15:48:31.362 16116 16151 I QAPM_Native: strReturn: com.android.internal.os.ZygoteInit.main(ZygoteInit.java:794)\\n04-11 15:48:31.362 16116 16151 I QAPM_Native: dumpJavaStack end.\\n04-11 15:48:31.362 16116 16151 I QAPM_Native: native stack\\n04-11 15:48:31.362 16116 16151 I QAPM_Native: pc 2612 \\/data\\/app\\/com.toringzhang.crashdemo-1\\/lib\\/arm\\/libapmcrash.so ((null)+0xd731f612)\\n04-11 15:48:31.362 16116 16151 I QAPM_Native: pc aaaabf7a \\/system\\/bin\\/app_process32 (InvokeUserSignalHandler+0x9d)\\n04-11 15:48:31.362 16116 16151 I QAPM_Native: pc 140ad6 \\/system\\/lib\\/libart.so (_ZN3art12FaultManager11HandleFaultEiP7siginfoPv+0xe1)\\n04-11 15:48:31.362 16116 16151 I QAPM_Native: pc 171b8 \\/system\\/lib\\/libc.so ((null)+0xf49221b8)\\n04-11 15:48:31.362 16116 16151 I QAPM_Native: pc 58a4 \\/data\\/app\\/com.toringzhang.crashdemo-1\\/lib\\/arm\\/libnative.so (_Z12emptyPointerv+0xb)\\n04-11 15:48:31.362 16116 16151 I QAPM_Native: pc 5d04 \\/data\\/app\\/com.toringzhang.crashdemo-1\\/lib\\/arm\\/libnative.so (Java_com_toringzhang_crashdemo_MainActivity_emptyPointerTest+0x19)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: have a native crash\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: java.lang.Error: signal 11 (Address not mapped to object) at address 0x100\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: Caused by: java.lang.Error: signal 11 (Address not mapped to object) at address 0x100\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat \\/data\\/app\\/com.toringzhang.crashdemo-1\\/lib\\/arm\\/libapmcrash.so.0x2612(Native Method)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat \\/system\\/bin\\/app_process32.0xaaaabf7a(InvokeUserSignalHandler:0x9d:0)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat \\/system\\/lib\\/libart.so.0x140ad6(_ZN3art12FaultManager11HandleFaultEiP7siginfoPv:0xe1:0)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat \\/system\\/lib\\/libc.so.0x171b8(Native Method)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat \\/data\\/app\\/com.toringzhang.crashdemo-1\\/lib\\/arm\\/libnative.so.0x58a4(_Z12emptyPointerv:0xb:0)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat \\/data\\/app\\/com.toringzhang.crashdemo-1\\/lib\\/arm\\/libnative.so.0x5d04(Java_com_toringzhang_crashdemo_MainActivity_emptyPointerTest:0x19:0)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: Caused by: java.lang.Error: java_stack.\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat com.toringzhang.crashdemo.MainActivity.emptyPointerTest(Native Method)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat com.toringzhang.crashdemo.MainActivity$3.onClick(MainActivity.java:119)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat android.view.View.performClick(View.java:5647)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat android.view.View$PerformClick.run(View.java:22465)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat android.os.Handler.handleCallback(Handler.java:754)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat android.os.Handler.dispatchMessage(Handler.java:95)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat android.os.Looper.loop(Looper.java:163)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat android.app.ActivityThread.main(ActivityThread.java:6395)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat java.lang.reflect.Method.invoke(Native Method)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:904)\\n04-11 15:48:31.363 16116 16151 E QAPM_CrashMonitor: \\tat com.android.internal.os.ZygoteInit.main(ZygoteInit.java:794)\\n04-11 15:48:31.364 16116 16151 I QAPM_NativeCrashCatcher: threadName: main, thread: Thread[main,5,main]\\n04-11 15:48:31.364 16116 16151 D eeeee   : eeee\\n04-11 15:48:31.364 16116 16151 W System.err: java.lang.Error: signal 11 (Address not mapped to object) at address 0x100\\n04-11 15:48:31.364 16116 16151 W System.err: Caused by: java.lang.Error: signal 11 (Address not mapped to object) at address 0x100\\n04-11 15:48:31.364 16116 16151 W System.err: \\tat \\/data\\/app\\/com.toringzhang.crashdemo-1\\/lib\\/arm\\/libapmcrash.so.0x2612(Native Method)\\n04-11 15:48:31.364 16116 16151 W System.err: \\tat \\/system\\/bin\\/app_process32.0xaaaabf7a(InvokeUserSignalHandler:0x9d:0)\\n04-11 15:48:31.364 16116 16151 W System.err: \\tat \\/system\\/lib\\/libart.so.0x140ad6(_ZN3art12FaultManager11HandleFaultEiP7siginfoPv:0xe1:0)\\n04-11 15:48:31.364 16116 16151 W System.err: \\tat \\/system\\/lib\\/libc.so.0x171b8(Native Method)\\n04-11 15:48:31.364 16116 16151 W System.err: \\tat \\/data\\/app\\/com.toringzhang.crashdemo-1\\/lib\\/arm\\/libnative.so.0x58a4(_Z12emptyPointerv:0xb:0)\\n04-11 15:48:31.365 16116 16151 W System.err: \\tat \\/data\\/app\\/com.toringzhang.crashdemo-1\\/lib\\/arm\\/libnative.so.0x5d04(Java_com_toringzhang_crashdemo_MainActivity_emptyPointerTest:0x19:0)\\n04-11 15:48:31.365 16116 16151 W System.err: Caused by: java.lang.Error: java_stack.\\n04-11 15:48:31.365 16116 16151 W System.err: \\tat com.toringzhang.crashdemo.MainActivity.emptyPointerTest(Native Method)\\n04-11 15:48:31.365 16116 16151 W System.err: \\tat com.toringzhang.crashdemo.MainActivity$3.onClick(MainActivity.java:119)\\n04-11 15:48:31.365 16116 16151 W System.err: \\tat android.view.View.performClick(View.java:5647)\\n04-11 15:48:31.365 16116 16151 W System.err: \\tat android.view.View$PerformClick.run(View.java:22465)\\n04-11 15:48:31.365 16116 16151 W System.err: \\tat android.os.Handler.handleCallback(Handler.java:754)\\n04-11 15:48:31.365 16116 16151 W System.err: \\tat android.os.Handler.dispatchMessage(Handler.java:95)\\n04-11 15:48:31.365 16116 16151 W System.err: \\tat android.os.Looper.loop(Looper.java:163)\\n04-11 15:48:31.365 16116 16151 W System.err: \\tat android.app.ActivityThread.main(ActivityThread.java:6395)\\n04-11 15:48:31.365 16116 16151 W System.err: \\tat java.lang.reflect.Method.invoke(Native Method)\\n04-11 15:48:31.365 16116 16151 W System.err: \\tat com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:904)\\n04-11 15:48:31.366 16116 16151 W System.err: \\tat com.android.internal.os.ZygoteInit.main(ZygoteInit.java:794)\\n04-11 15:48:31.369 16116 16954 D QAPM_CrashReportDataFactory: Calling collector com.tencent.qapmsdk.crash.collector.LogCatCollector\\n04-11 15:48:31.369 16116 16955 D QAPM_CrashReportDataFactory: Calling collector com.tencent.qapmsdk.crash.collector.TimeCollector\\n04-11 15:48:31.370 16116 16956 D QAPM_CrashReportDataFactory: Calling collector com.tencent.qapmsdk.crash.collector.ThreadCollector\\n04-11 15:48:31.370 16116 16955 D QAPM_BaseReportFieldCollector: USER_APP_START_DATE not collect.\\n04-11 15:48:31.370 16116 16953 D QAPM_CrashReportDataFactory: Calling collector com.tencent.qapmsdk.crash.collector.StacktraceCollector\\n04-11 15:48:31.370 16116 16955 D QAPM_BaseReportFieldCollector: USER_CRASH_DATE is collecting.\\n04-11 15:48:31.370 16116 16956 D QAPM_BaseReportFieldCollector: THREAD_DETAILS is collecting.\\n04-11 15:48:31.370 16116 16953 D QAPM_BaseReportFieldCollector: STACK_TRACE is collecting.\\n04-11 15:48:31.370 16116 16954 D QAPM_BaseReportFieldCollector: LOGCAT is collecting.\\n04-11 15:48:31.371 16116 16956 D QAPM_CrashReportDataFactory: Collector com.tencent.qapmsdk.crash.collector.ThreadCollector completed\\n04-11 15:48:31.371 16116 16953 D QAPM_BaseReportFieldCollector: STACK_TRACE_HASH is collecting.\\n04-11 15:48:31.371 16116 16955 D QAPM_BaseReportFieldCollector: USER_APP_START_TIMESTAMP not collect.\\n04-11 15:48:31.371 16116 16955 D QAPM_BaseReportFieldCollector: USER_CRASH_TIMESTAMP is collecting.\\n04-11 15:48:31.372 16116 16953 D QAPM_BaseReportFieldCollector: STACK_TRACE_NAME is collecting.\\n04-11 15:48:31.372 16116 16955 D QAPM_CrashReportDataFactory: Collector com.tencent.qapmsdk.crash.collector.TimeCollector completed\\n04-11 15:48:31.372 16116 16953 D QAPM_BaseReportFieldCollector: STACK_TRACE_MESSAGE is collecting.\\n04-11 15:48:31.372 16116 16953 D QAPM_CrashReportDataFactory: Collector com.tencent.qapmsdk.crash.collector.StacktraceCollector completed\\n04-11 15:48:31.376 16116 16954 D QAPM_LogCatCollector: Retrieving logcat output (buffer:default)...\",\"instant_crash\":1,\"crashedThread\":\"1\"}]}");
                    ResultObject roo = new ResultObject(0, "testcase", true, 1, 1, crasher, true, true, Magnifier.info.uin);
                    ReporterMachine.addResultObj(roo);

                    //upload file
                    JSONObject params = new JSONObject();
                    params.put("plugin", Config.PLUGIN_QCLOUD_CEILING_HPROF);
                    params.put("versionname", "6.3.0.0");
                    params.put("uin", Magnifier.info.uin);
                    params.put("model", "android 6.0");
                    params.put("processname", "com.example.sdkapp");
                    params.put("stage", "MainActivity");
                    params.put("timecost", "112233");
                    params.put("p_id", 1);
                    params.put("fileObj", sdPath + "/dump.zip");
                    ResultObject ro = new ResultObject(0, "testcase", true, 1, 1, params, false, true, Magnifier.info.uin);
                    ReporterMachine.addResultObj(ro);

                } catch (Exception e) {
                    Magnifier.ILOGUTIL.exception(TAG, e);
                }
            }
        });

        //掉帧测试
        Button btnTestListview = (Button) findViewById(R.id.btntestlistview);
        btnTestListview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, TestListView.class);
                startActivity(intent);
            }
        });


        //测试内存泄漏
        Button btnTestactivityleak = findViewById(R.id.btntestactivityleak);
        btnTestactivityleak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, TestActivityLeak.class);
                startActivity(intent);
            }
        });

        //测试电量
        Button btnTestanimtion = (Button) findViewById(R.id.btntestbettary);
        btnTestanimtion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testWakeLock();
                gpsManager.getLocation();
            }
        });

        //测试文件io
        Button btnTestfile = (Button) findViewById(R.id.btntestfile);
        btnTestfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HandlerThread ht = new HandlerThread("IOTest");
                ht.start();
                Handler h = new Handler(ht.getLooper());
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        // TODO Auto-generated method stub
                        try {
                            for (int i = 0; i < 3; i++) {
                                ioTest.FileTest();
                            }
                        } catch (Exception e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                });
            }
        });

        Button btnTestJavaCrash = (Button) findViewById(R.id.btnTestJavaCrash);
        btnTestJavaCrash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startCrashView();
            }
        });

        Button btnTestNativeCrash = (Button) findViewById(R.id.btnTestNativeCrash);
        btnTestNativeCrash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                onOOMCrash();
//                nullPoint();
//                loadSoError();
//                try{
//                    Thread.sleep(30000);
//                }catch (InterruptedException e){
//                    e.printStackTrace();
//                }
//                NativeCrashCatcher.getThreadByName("main");

                emptyPointerTest();
            }
        });

        //掉帧webView
        Button btnWebViewTest = (Button) findViewById(R.id.test_web_view);
        btnWebViewTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, X5WebViewActivity.class);
                startActivity(intent);
            }
        });

        //网络监控测试
        findViewById(R.id.btnHttpTest).setOnClickListener(new View.OnClickListener() { //网络监控测试
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ManagerActivity.class);
                startActivity(intent);
            }
        });

    }


    private void startCrashView(){
        Intent intent = new Intent(this, CrashTest.class);
        startActivity(intent);
    }

    private void startSettingView(){
        Intent intent = new Intent(this, ApmSetting.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case R.id.setting:
                startSettingView();
                break;
            default:
                break;
        }

        return true;
    }


    private void newJavaCrash() {
        throw new RuntimeException("this is a crash demo.");
    }


    private void chengWifiStatus(boolean state) {
        try {
            WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (state && !wifiManager.isWifiEnabled()) {
                wifiManager.setWifiEnabled(true);
            } else if (!state && wifiManager.isWifiEnabled()) {
                wifiManager.setWifiEnabled(false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void chengMobileNetworks(boolean state) {
        ConnectivityManager connectivityManager = null;
        try {
            connectivityManager = (ConnectivityManager) getApplicationContext()
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            Method method = connectivityManager.getClass().getMethod(
                    "setMobileDataEnabled", new Class[]{boolean.class});
            method.invoke(connectivityManager, state);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteSqlit() {
        String filePath = getFilesDir().getAbsolutePath();
        String qqDB = "2872971611.db";
        String sdkDB = "sdk_db";
        String dbPath = filePath.replace("files", "databases");
        File dbf = new File(dbPath + "/" + qqDB);
        File sdkdb = new File(dbPath + "/" + sdkDB);
        try {

            SQLiteDatabase.deleteDatabase(dbf);
            SQLiteDatabase.deleteDatabase(sdkdb);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteCsv() {
        String filePath = "/storage/sdcard0/Tencent/Magnifier/dumpfile";
        File file = new File(filePath);
        deleteAllFiles(file);

    }

    private void onOOMCrash() {

        ArrayList<Object[]> objects = new ArrayList<>();
        int i = 0;
        while (true) {
            i++;
            if (i % 1000 == 0) {
                Log.d("total memory：", String.valueOf(Runtime.getRuntime().totalMemory()));
            }
            Object object[] = new Object[1024 * 1024 * 100];
            objects.add(object);
        }
    }

    private void nullPoint() {
        String a = null;
        a.equals("hahah");
    }

    private void loadSoError() {
        System.loadLibrary("aab");
    }

    private void deleteAllFiles(File root) {
        File files[] = root.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) { // 判断是否为文件夹
                    deleteAllFiles(f);
                    try {
                        f.delete();
                    } catch (Exception e) {
                    }
                } else {
                    if (f.exists()) { // 判断是否存在
                        deleteAllFiles(f);
                        try {
                            f.delete();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }


    TimerTask timerTask = new TimerTask() {
        @Override
        public void run() {

            try {
                for (int i = 0; i < 10; i++) {
                    ILogUtil.getInstance(true).d(TAG, "this is a log。。。。");
                }
                testWakeLock();
//                new ReportToYunYing().reportJsonLater();
                gpsManager.getLocation();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };


    private void testWakeLock() {
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        final PowerManager.WakeLock wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "apmtest::MyWakelockTag");
        try {
            wakeLock.acquire();
            testHandler.postDelayed(new Runnable() {
                public void run() {
                    wakeLock.release();
                }
            }, 5000);
            final WifiManager.WifiLock wifiLock = ((WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE)).createWifiLock(WifiManager.WIFI_MODE_FULL, "mylock");
            wifiLock.acquire();
            testHandler.postDelayed(new Runnable() {
                public void run() {
                    wifiLock.release();
                }
            }, 9000);
        } catch (Exception e) {

        }

    }

    @Override
    protected void onStop() {
        super.onStop();
        for (int i = 0; i < 10; i++) {
            ILogUtil.getInstance(true).d(TAG, "this is a log。。。。");
        }
        gpsManager.getLocation();
        testWakeLock();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        MagnifierSDK sdk = MagnifierSDK.getInstance(getApplication(), 1024, "2.1");
//        sdk.stopSDK();
//        unbindService(mServiceConnection);
//        timer.cancel();
        gpsManager.stopLocationUpdates();
    }


    private void setSqliteUploadSize(int size) {
        try {
            Class sqlite = Class.forName("com.tencent.qapmsdk.io.SQLiteMonitor");
            Field field = sqlite.getDeclaredField("UPLOADSIZE");
            field.setAccessible(true);
            Field modifiersField = Field.class.getDeclaredField("accessFlags");
            modifiersField.setAccessible(true);
            modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);

            field.set(null, size);

            Log.d("aaaaa", "UPLOADSIZE:" + field.getInt(sqlite));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static {
        System.loadLibrary("native");
    }

    public native void nativeTest();

    public native void emptyPointerTest();

    public native String getSystemProperty(String key);

    public native void setSystemProperty(String key, String value);
}
