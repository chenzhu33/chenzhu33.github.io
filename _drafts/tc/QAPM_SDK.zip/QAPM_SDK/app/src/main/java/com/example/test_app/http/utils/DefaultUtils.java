package com.example.test_app.http.utils;

public class DefaultUtils {

    //https://m.bankcomm.com/wap/index.shtml
    public static final String HTTPS_DOMAIN_NO_PORT = "https://tcc.taobao.com/cc/json/mobile_tel_segment.htm?tel=13192299856";//https://github.com/square/okhttp/issues/2337
    public static final String HTTPS_DOMAIN_PORT = "https://sngapm.qq.com:443";   //假接口
    public static final String HTTP_DOMAIN_NO_PORT = "http://t.weather.sojson.com/api/weather/city/101030100";
    public static final String HTTP_DOMAIN_PORT = "http://www.9410.com.cn:80";


    public static final String HTTPS_IP_NO_PORT = "https://203.119.169.17/cc/json/mobile_tel_segment.htm?tel=13192299856";  //无效
    public static final String HTTPS_IP_PORT = "https://43.224.154.243:443";      //假接口
    public static final String HTTP_IP_NO_PORT = "http://43.224.154.243";
    public static final String HTTP_IP_PORT = "http://162.14.16.182:30025";

    public static final String _HTTPS_IP_PORT_ = "https://43.224.154.243:443/";  //host + /
    public static final String _HTTP_IP_PORT_ = "http://162.14.16.182:30025/";   //host + /
    public static final String _HTTPS_DOMAIN_PORT = "https://sngapm.qq.com:443/";
    public static final String _HTTP_DOMAIN_PORT_ = "http://www.9410.com.cn:80/";
    public static final String _HTTP_IP_NO_PORT_ = "http://43.224.154.243/";     //host + /


    public static final String IP_POST_HTTP_NO_PORT = "http://162.14.17.144:30063/appconfig/v3/config/14199/";
    public static final String IP_POST_HTTPS_NO_PORT = "https://119.29.48.48:443/appconfig/v3/config/1024/";    //无效
    public static final String DOMAIN_HTTPS_POST = "https://ten.sngapm.qq.com/appconfig/v3/config/1024/";
    public static final String DOMAIN_HTTP_POST = "http://sngapm.qq.com/appconfig/v3/config/1024/";     //无效


    public static final String JSON_DATA = "{ \"pid\":\"1024\",\n" +
            "      \"device\":\"HUAWEI,P7-L00\",\n" +
            "      \"version\":\"1.3\",\n" +
            "      \"uin\":\"11223344\",\n" +
            "      \"level\":\"\",\n" +
            "      \"md5code\":\"xxxxxxxxxxx\"}";

}
