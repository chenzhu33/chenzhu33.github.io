package com.example.test_app;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Checkable;
import android.widget.EditText;

public class ApmSetting extends AppCompatActivity {

    private String host = "";
    private String appId = "";
    public static final String EXTRA_MESSAGE = "host";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apm_setting);

        final EditText hostName = (EditText) findViewById(R.id.et_host);
        final EditText app = (EditText)findViewById(R.id.et_app_id);
        Checkable isSave = (Checkable) findViewById(R.id.cb_checkbox);

        Button button = (Button) findViewById(R.id.btn_ok);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                host = hostName.getText().toString();
                appId = app.getText().toString();
                startMainView(host, appId);
            }
        });

    }


    private void startMainView(String host, String appId){
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra(EXTRA_MESSAGE, host);
        intent.putExtra("appId", appId);
        startActivity(intent);
    }
}
