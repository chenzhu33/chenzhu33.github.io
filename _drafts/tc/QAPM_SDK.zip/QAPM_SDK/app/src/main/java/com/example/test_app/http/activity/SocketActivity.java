package com.example.test_app.http.activity;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.test_app.R;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class SocketActivity extends AppCompatActivity {

    private static final String TAG = "SocketActivity";

    private List<String> sockList;
    private ListView listView;
    private Button domainSocket;
    private Button ipSocket;
    private ReadWriteThread thread;
    private SocketHandler socketHandler;
    private ChatAdapter chatAdapter;

    private boolean isConnect = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_socket);
        initView();
    }

    private void initView() {
        listView = findViewById(R.id.socketList);
        sockList = new ArrayList<>();
        chatAdapter = new ChatAdapter();
        listView.setAdapter(chatAdapter);
        socketHandler = new SocketHandler(this);
        domainSocket = findViewById(R.id.socketDomain);
        domainSocket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                connect("towel.blinkenlights.nl", domainSocket);
            }
        });
        ipSocket = findViewById(R.id.socketIp);
        ipSocket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                connect("94.142.241.111", ipSocket);
            }
        });
    }

    public void connect(final String host, final Button which) {
        if (!isConnect) {
            new Thread() {
                @Override
                public void run() {
                    try {
                        Socket socket = new Socket(host, 23);
                        if (socket != null) {
                            isConnect = true;
                            thread = new ReadWriteThread(socket, listener);
                            thread.start();
                            socketHandler.obtainMessage(1, which).sendToTarget();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }.start();
        } else {
            if (thread != null) {
                isConnect = false;
                thread.cancel();
                thread = null;
                if (which == ipSocket) {
                    which.setText("IP Socket");
                } else {
                    which.setText("域名 Socket");
                }
                sockList.clear();
                chatAdapter.notifyDataSetChanged();
            }
        }
    }

    public class ReadWriteThread extends Thread {

        public Socket socket;
        public InputStream inputStream;
        public OutputStream outputStream;
        public ChatListener listener;

        public ReadWriteThread(Socket socket, ChatListener listener) {
            try {
                this.socket = socket;
                this.listener = listener;
                this.inputStream = socket.getInputStream();
                this.outputStream = socket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            byte[] buffer = new byte[2048];
            int len;
            while (true) {
                try {
                    len = inputStream.read(buffer);
                    String result = new String(buffer, 0, len);
                    Log.d(TAG, "run: " + result);
                    if (listener != null) {
                        listener.onReceived(result);
                    }
                } catch (IOException e) {
                    break;
                }
            }
        }

        public void write(byte[] buffer) {
            try {
                outputStream.write(buffer);
            } catch (IOException e) {

            }
        }

        public void cancel() {
            try {
                if (inputStream != null) {
                    inputStream.close();
                    inputStream = null;
                }
                if (outputStream != null) {
                    outputStream.flush();
                    outputStream.close();
                    outputStream = null;
                }
                if (socket != null) {
                    socket.close();
                    socket = null;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public interface ChatListener {
        void onReceived(String content);  //接收信息
    }

    static class SocketHandler extends Handler {
        WeakReference<SocketActivity> weakReference;

        private SocketHandler(SocketActivity activity) {
            weakReference = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            SocketActivity activity = weakReference.get();
            if (activity != null) {
                switch (msg.what) {
                    case 1:
                        Button button = (Button) msg.obj;
                        button.setText("关闭连接");
                        break;
                    case 2:
                        activity.sockList.add((String) msg.obj);
                        activity.chatAdapter.notifyDataSetChanged();
                        activity.listView.smoothScrollToPosition(activity.chatAdapter.getCount() - 1);
                        break;
                }
            }
        }
    }

    class ChatAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return sockList.size();
        }

        @Override
        public Object getItem(int i) {
            return sockList.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = View.inflate(SocketActivity.this, R.layout.item_text, null);
            TextView item = view.findViewById(R.id.itemText);
            item.setText(sockList.get(i));
            return view;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (sockList != null) {
            sockList.clear();
            sockList = null;
        }
        if (socketHandler != null) {
            socketHandler.removeCallbacksAndMessages(null);
            socketHandler = null;
        }
    }

    public ChatListener listener = new ChatListener() {
        @Override
        public void onReceived(String content) {
            socketHandler.obtainMessage(2, content).sendToTarget();
        }
    };
}
