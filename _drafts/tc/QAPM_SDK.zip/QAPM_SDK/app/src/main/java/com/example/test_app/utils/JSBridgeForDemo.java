package com.example.test_app.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import com.tencent.smtt.export.external.interfaces.IX5WebViewBase.FindListener;
import com.tencent.smtt.sdk.QbSdk;
import com.tencent.smtt.sdk.WebStorage;
import com.tencent.smtt.sdk.WebView;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class JSBridgeForDemo {
    private static final String TAG = "JSBridgeForDemo";
    //接口类
    abstract class MethodService{
        private String mMethodName;
        public MethodService(String methodName) {
            mMethodName = methodName;
        }

        public String getMethodName() {
            return mMethodName;
        }

        abstract public boolean canExposeToJs();
        abstract public JSONObject doRun(JSONObject argsJsonObj);
    }

    private String getOptionJsonString(JSONObject json, String key, String defaultValue) {
        try {
            if (json != null && json.has(key)) {
                return json.getString(key);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return defaultValue;
    }

    private static void LOGD(String msg) {
        Log.d(TAG, msg);
    }

    private static final String JS_API_NAME = "tbs_bridge_for_demo";
    private HashMap<String, MethodService> mMethodService = new HashMap<String, MethodService>();
    private WebView mWebView;
    private String mPackageName = "";

    @JavascriptInterface
    public String hasMethod(String methodName) {
        LOGD("hasMethod:" + methodName);
        MethodService methodService = mMethodService.get(methodName);
        if (null == methodService) {
            return null;
        }

        return "";
    }

    @JavascriptInterface
    public String jsExec(String methodName, String args) {
        LOGD("methodName:" + methodName + ",args:" + args);
        MethodService methodService = mMethodService.get(methodName);
        if (null == methodService) {
            LOGD("can't find this methodService");
            return null;
        }

        JSONObject argsJson = null;
        if (!TextUtils.isEmpty(args)) {
            try {
                argsJson = new JSONObject(args);
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
        JSONObject result = methodService.doRun(argsJson);
        if (null != result) {
            return result.toString();
        }
        return null;
    }

    public JSBridgeForDemo(WebView webView) {
        mWebView = webView;
        if (null != mWebView) {
            mPackageName = mWebView.getContext().getPackageName();
        }
    }

    public void injectJsApi() {
        if (null == mWebView) {
            LOGD("Error: WebView is null");
            return;
        }
        mWebView.removeJavascriptInterface(JS_API_NAME);
        mWebView.addJavascriptInterface(this, JS_API_NAME);

        //add all method below
        addMethodService(new TextSizeMethod());
        addMethodService(new ShowToastMethod());
        addMethodService(new FindTextMethod());
        addMethodService(new SnapShotMethod());
    }

    private boolean inX5Mode() {
        if (null != mWebView && mWebView.getX5WebViewExtension() != null) {
            return true;
        }
        return false;
    }

    private void addMethodService(MethodService methodService) {
        if (null == methodService) {
            return;
        }
        if (methodService.canExposeToJs()) {
            mMethodService.put(methodService.getMethodName(), methodService);
        }
    }
    
    private void postRunnable(Runnable runnable) {
        mWebView.post(runnable);
    }

    class TextSizeMethod extends MethodService {
        private static final String METHOD_NAME = "setTextSize";
        private static final String KEY_SIZE = "size";
        public TextSizeMethod() {
            super(METHOD_NAME);
        }

        @Override
        public JSONObject doRun(JSONObject argsJsonObj) {
            String strSize = getOptionJsonString(argsJsonObj, KEY_SIZE, "100");
            try {
                final int fontSize = Integer.parseInt(strSize);
                postRunnable(new Runnable(){
                    @Override
                   public void run() {
                        mWebView.getSettings().setTextZoom(fontSize);
                    }
                });
                
                LOGD(METHOD_NAME + ", fontSize:" + fontSize);
            } catch (Throwable e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        public boolean canExposeToJs() {
            return true;
        }
    }

    class ShowToastMethod extends MethodService {
        private static final String METHOD_NAME = "showToast";
        private static final String KEY_CONTENT = "content";
        private static final String KEY_CALLBACK = "callback";
        public ShowToastMethod() {
            super(METHOD_NAME);
        }

        @Override
        public JSONObject doRun(JSONObject argsJsonObj) {
            final String content = getOptionJsonString(argsJsonObj, KEY_CONTENT, "");
            final String callback = getOptionJsonString(argsJsonObj, KEY_CALLBACK, "");
            try {
                postRunnable(new Runnable(){
                    @Override
                   public void run() {
                        Toast.makeText(mWebView.getContext(), content, Toast.LENGTH_SHORT).show();
                        mWebView.loadUrl("javascript:" + callback);
                    }
                });
                LOGD(METHOD_NAME + ", content:" + content + ", callback:" + callback);
            } catch (Throwable e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        public boolean canExposeToJs() {
            return true;
        }
    }

    private String mFindTextContent = "";
    class FindTextMethod extends MethodService {
        private static final String METHOD_NAME = "findText";
        private static final String KEY_CONTENT = "content";
        private static final String KEY_NEXT = "next";
        public FindTextMethod() {
            super(METHOD_NAME);
        }

        @Override
        public JSONObject doRun(JSONObject argsJsonObj) {
            final String content = getOptionJsonString(argsJsonObj, KEY_CONTENT, "");
            final String next = getOptionJsonString(argsJsonObj, KEY_NEXT, "");
            JSONObject result = new JSONObject();

            try {
                if (TextUtils.isEmpty(content)) {
                    result.put("cmd", "清除选中状态");
                } else {
                    String cmd = "";
                    if (!mFindTextContent.equals(content)) {
                        cmd = getResultText(cmd, "查找[" + content +"]");
                    } else {
                        String nextString = next.equals("true") ? "下一个" : "上一个";
                        cmd = getResultText(cmd, "查找[" + content +"]," + nextString);
                    }
                    result.put("cmd", cmd);
                }
                postRunnable(new Runnable(){
                    @Override
                    public void run() {
                        if (TextUtils.isEmpty(content)) {
                            mFindTextContent = "";
                            mWebView.clearMatches();
                            return;
                        }
                        if (!mFindTextContent.equals(content)) {
                            mFindTextContent = content;
                            mWebView.setFindListener(new FindListener() {

                                @Override
                                public void onFindResultReceived(int activeMatchOrdinal, int numberOfMatches, boolean isDoneCounting) {
                                    if (isDoneCounting) {
                                        consoleResult(activeMatchOrdinal, numberOfMatches);
                                    }
                                }
                            });
                            mWebView.findAllAsync(content);
                        } else {
                            mWebView.findNext( next.equals("true") ? true : false);
                        }
                    }
                });
                LOGD(METHOD_NAME + ", content:" + content + ", next:" + next);
            } catch (Throwable e) {
                e.printStackTrace();
            }
            return result;
        }

        private String getResultText(String cmd, String extraText) {
            String result = cmd;
            if (!TextUtils.isEmpty(result)) {
                result += ", ";
            }
            result += extraText;
            return result;
        }

        private void consoleResult(final int activeMatchOrdinal, final int numberOfMatches) {
            postRunnable(new Runnable(){
                @Override
                public void run() {
                    int currentIndex = (numberOfMatches > 0) ? (activeMatchOrdinal + 1) : activeMatchOrdinal;
                    mWebView.loadUrl("javascript:console.log('共 [ " + numberOfMatches + " ] 个,当前位置 [ " + currentIndex + " ]')");
                }
            });
        }

        @Override
        public boolean canExposeToJs() {
            return inX5Mode();
        }
    }

    class SnapShotMethod extends MethodService {
        private static final String METHOD_NAME = "snapShot";
        private static final String KEY_TYPE = "type";
        public SnapShotMethod() {
            super(METHOD_NAME);
        }

        @Override
        public JSONObject doRun(JSONObject argsJsonObj) {
            final String type = getOptionJsonString(argsJsonObj, KEY_TYPE, "visible");
            try {
                postRunnable(new Runnable(){
                    @Override
                   public void run() {
                        int contentWidth = mWebView.getContentWidth();
                        int contentHeight = mWebView.getContentHeight();
                        int width = mWebView.getView().getWidth();
                        int height = mWebView.getView().getHeight();
                        float scale = mWebView.getScale();
                        LOGD(METHOD_NAME + ", contentWidth:" + contentWidth + ", contentHeight:" + contentHeight + ", width:" + width +", height:" + height + ",scale:" + scale);
                        if ("all".equals(type)) {
                            snapShotWholePage(contentWidth, contentHeight);
                        } else {
                            snapShotVisible(width, height, scale);
                        }
                    }
                });
                LOGD(METHOD_NAME + ", type:" + type);
            } catch (Throwable e) {
                e.printStackTrace();
            }
            return null;
        }

        private void snapShotWholePage(int width, int height) {
            Bitmap bitmap = createTmpBitmap(width, height);
            if (null != bitmap) {
                Canvas canvas = new Canvas(bitmap);
                mWebView.getX5WebViewExtension().snapshotWholePage(canvas, false, false);
                saveBitmap(bitmap);
            } else {
                LOGD(METHOD_NAME + ",snapShotWholePage create bitmap is null.");
            }
        }

        private void snapShotVisible(int width, int height, float scale) {
            Bitmap bitmap = createTmpBitmap((int)(width/scale), (int)(height/scale));
            if (null != bitmap) {
                mWebView.getX5WebViewExtension().snapshotVisible(bitmap, false, false, false, false, 1/scale, 1/scale, null);
                saveBitmap(bitmap);
            } else {
                LOGD(METHOD_NAME + ", snapShotVisible create bitmap is null.");
            }
        }

        private Bitmap createTmpBitmap(int width, int height) {
            Bitmap bmp = null;
            try {
                bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
            } catch (Throwable e) {
            }
            return bmp;
        }

        private void saveBitmap(final Bitmap bitmap) {
            new Thread(new Runnable(){
                @Override
                public void run() {
                    final String result = saveBitmapToSD(bitmap);
                    mWebView.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!TextUtils.isEmpty(result)) {
                                Toast.makeText(mWebView.getContext(), "保存成功,路径:" + result, Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(mWebView.getContext(), "保存失败", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            }).start();
        }

        private String saveBitmapToSD(Bitmap bitmap) {
            try {
                File sdcardDir = Environment.getExternalStorageDirectory();
                final String snapShotDir = sdcardDir.getAbsolutePath() + File.separator + "asnapShot" + File.separator;
                File dirFile = new File(snapShotDir);
                if (!dirFile.exists() && !dirFile.mkdir()) {
                    return null;
                }

                File imageFile = new File(snapShotDir + File.separator + System.currentTimeMillis() + ".jpg");

                FileOutputStream out = new FileOutputStream(imageFile);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
                out.flush();
                out.close();
                bitmap.recycle();
                return imageFile.getAbsolutePath();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        public boolean canExposeToJs() {
            return inX5Mode();
        }
    }
}
