package com.example.test_app.http.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.example.test_app.R;
import com.example.test_app.http.bean.HttpBean;
import com.example.test_app.http.listener.HttpListener;
import com.example.test_app.http.utils.DefaultUtils;
import com.example.test_app.http.utils.HttpClientUtils;
import com.example.test_app.http.utils.HttpUtils;
import com.example.test_app.http.utils.OkHttp_275_Utils;
import com.example.test_app.http.utils.OkHttp_311_Utils;


public class IpActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "IpActivity";

    private OkHttp_275_Utils okHttp275Utils;
    private OkHttp_311_Utils okHttp311Utils;
    private HttpClientUtils httpClientUtils;
    private HttpUtils httpUtils;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ip);
        initData();
        initView();
    }

    private void initData() {
        okHttp275Utils = OkHttp_275_Utils.getInstance();
        okHttp311Utils = OkHttp_311_Utils.getInstance();
        httpClientUtils = HttpClientUtils.getInstance();
        httpUtils = HttpUtils.getInstance();
    }

    private void initView() {
        findViewById(R.id.http2NoPortGet).setOnClickListener(this);
        findViewById(R.id.https2NoPortGet).setOnClickListener(this);
        findViewById(R.id.http2PortGet).setOnClickListener(this);
        findViewById(R.id.https2PortGet).setOnClickListener(this);
        findViewById(R.id.http3NoPortGet).setOnClickListener(this);
        findViewById(R.id.https3NoPortGet).setOnClickListener(this);
        findViewById(R.id.http3PortGet).setOnClickListener(this);
        findViewById(R.id.https3PortGet).setOnClickListener(this);
        findViewById(R.id.httpNoPortGet).setOnClickListener(this);
        findViewById(R.id.httpsNoPortGet).setOnClickListener(this);
        findViewById(R.id.httpPortGet).setOnClickListener(this);
        findViewById(R.id.httpsPortGet).setOnClickListener(this);

        findViewById(R.id.http2NoPortPost).setOnClickListener(this);
        findViewById(R.id.https2NoPortPost).setOnClickListener(this);
        findViewById(R.id.http3NoPortPost).setOnClickListener(this);
        findViewById(R.id.https3NoPortPost).setOnClickListener(this);
        findViewById(R.id.httpNoPortPost).setOnClickListener(this);
        findViewById(R.id.httpsNoPortPost).setOnClickListener(this);

        findViewById(R.id.httpClientNoPortGet).setOnClickListener(this);
        findViewById(R.id.httpClientPortGet).setOnClickListener(this);
        findViewById(R.id.httpsClientNoPortGet).setOnClickListener(this);
        findViewById(R.id.httpsClientPortGet).setOnClickListener(this);
        findViewById(R.id.httpClientNoPortPost).setOnClickListener(this);
        findViewById(R.id.httpsClientNoPortPost).setOnClickListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (okHttp275Utils != null) {
            okHttp275Utils.release();
            okHttp275Utils = null;
        }
        if (okHttp311Utils != null) {
            okHttp311Utils.release();
            okHttp311Utils = null;
        }
        if (httpClientUtils != null) {
            httpClientUtils.release();
            httpClientUtils = null;
        }
        if (httpUtils != null) {
            httpUtils.release();
            httpUtils = null;
        }
    }

    @Override
    public void onClick(View view) {
        HttpBean bean = new HttpBean();
        bean.setIp(true);
        bean.setPort(false);
        int id = view.getId();
        switch (id) {
            case R.id.http2NoPortGet:
            case R.id.http3NoPortGet:
            case R.id.httpNoPortGet:
            case R.id.httpClientNoPortGet:
                bean.setUrl(DefaultUtils.HTTP_IP_NO_PORT);
                break;
            case R.id.https2NoPortGet:
            case R.id.https3NoPortGet:
            case R.id.httpsNoPortGet:
            case R.id.httpsClientNoPortGet:
                bean.setUrl(DefaultUtils.HTTPS_IP_NO_PORT);
                break;
            case R.id.http2PortGet:
            case R.id.http3PortGet:
            case R.id.httpPortGet:
            case R.id.httpClientPortGet:
                bean.setPort(true);
                bean.setUrl(DefaultUtils.HTTP_IP_PORT);
                break;
            case R.id.https2PortGet:
            case R.id.https3PortGet:
            case R.id.httpsPortGet:
            case R.id.httpsClientPortGet:
                bean.setPort(true);
                bean.setUrl(DefaultUtils.HTTPS_IP_PORT);
                break;

            case R.id.httpNoPortPost:
            case R.id.http2NoPortPost:
            case R.id.http3NoPortPost:
            case R.id.httpClientNoPortPost:
                bean.setUrl(DefaultUtils.IP_POST_HTTP_NO_PORT);
                break;

            case R.id.httpsNoPortPost:
            case R.id.https2NoPortPost:
            case R.id.https3NoPortPost:
            case R.id.httpsClientNoPortPost:
                bean.setUrl(DefaultUtils.IP_POST_HTTPS_NO_PORT);
                break;
        }
        if (id == R.id.http2NoPortGet || id == R.id.https2NoPortGet || id == R.id.http2PortGet || id == R.id.https2PortGet) {
            okHttp275Utils.getRequest(bean, listener);
        }
        if (id == R.id.http3PortGet || id == R.id.http3NoPortGet || id == R.id.https3PortGet || id == R.id.https3NoPortGet) {
            okHttp311Utils.getRequest(bean, listener);
        }
        if (id == R.id.httpPortGet || id == R.id.httpNoPortGet) {
            httpUtils.httpGetRequest(bean, listener);
        }
        if (id == R.id.httpsPortGet || id == R.id.httpsNoPortGet) {
            httpUtils.httpsGetRequest(bean, listener);
        }
        if (id == R.id.httpNoPortPost) {
            httpUtils.httpPostRequest(bean, listener);
        }
        if (id == R.id.httpsNoPortPost) {
            httpUtils.httpsPostRequest(bean, listener);
        }
        if (id == R.id.http2NoPortPost || id == R.id.https2NoPortPost) {
            okHttp275Utils.postRequest(bean, listener);
        }
        if (id == R.id.http3NoPortPost || id == R.id.https3NoPortPost) {
            okHttp311Utils.postRequest(bean, listener);
        }
        if (id == R.id.httpClientNoPortGet
                || id == R.id.httpClientPortGet
                || id == R.id.httpsClientNoPortGet
                || id == R.id.httpsClientPortGet) {
            httpClientUtils.getRequest(bean, listener);
        }
        if (id == R.id.httpClientNoPortPost
                || id == R.id.httpsClientNoPortPost) {
            httpClientUtils.postRequest(bean, listener);
        }
    }

    public HttpListener listener = new HttpListener() {
        @Override
        public void onFailed(HttpBean bean) {
            Log.d(TAG, "onFailed: " + bean.toString());
        }

        @Override
        public void onSuccess(HttpBean bean) {
            Log.d(TAG, "onSuccess: " + bean.toString());
        }
    };
}
