package com.example.test_app;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UrlUtils {
    private static Pattern VALID_URL = Pattern.compile("(.+)(\\.)(.+)[^\\w]*(.*)", Pattern.CASE_INSENSITIVE);
    private static Pattern VALID_LOCAL_URL = Pattern.compile("(^file://.+)|(.+localhost:?\\d*/.+\\..+)",
            Pattern.CASE_INSENSITIVE);
    private static Pattern VALID_IP_ADDRESS = Pattern.compile("(\\d){1,3}\\.(\\d){1,3}"
                    + "\\.(\\d){1,3}\\.(\\d){1,3}(:\\d{1,4})?(/(.*))?",
            Pattern.CASE_INSENSITIVE);

    /**
     * 根据输入，得到一个有效URL
     * 如果输入无法被解析为一个URL，返回NULL
     */
    public static String converToValidUrl(final String inUrl) {
        if (inUrl == null || inUrl.length() == 0) {
            return null;
        }

        String url = inUrl.trim();

        if (isJavascript(url) || UrlUtils.isSpecialUrl(url)) {
            return url;
        } else if (isCandidateUrl(url)) {
            if (hasValidProtocal(url)) {
                return url;
            } else {
                return "http://" + url;
            }
        }

        return null;
    }

    private static boolean isJavascript(String url) {
        // javascript:
        return (null != url) && (url.length() > 10) && url.substring(0, 11).equalsIgnoreCase("javascript:");
    }

    private static boolean isSpecialUrl(String url) {
        if (url == null) {
            return false;
        }

        String lowser = url.toLowerCase();
        return lowser.startsWith("about:blank") || lowser.startsWith("data:");
    }

    /**
     * 判断URL是否是一个有效的格式
     */
    private static boolean isCandidateUrl(final String aUrl) {
        if (aUrl == null || aUrl.length() == 0 || aUrl.startsWith("data:")) {
            return false;
        }
        String url = aUrl.trim();

        Matcher validUrl = VALID_URL.matcher(url);
        Matcher validLocal = VALID_LOCAL_URL.matcher(url);
        Matcher validIp = VALID_IP_ADDRESS.matcher(url);

        if (validUrl.find() || validLocal.find() || validIp.find()) {
            return true;
        }

        return false;
    }

    /**
     * 判断URL是否有一个有效的协议头
     */
    private static boolean hasValidProtocal(final String url) {
        if (url == null || url.length() == 0) {
            return false;
        }

        int pos1 = url.indexOf("://");
        int pos2 = url.indexOf('.');

        if (pos1 > 0 && pos2 > 0 && pos1 > pos2) {
            return false;
        }

        return url.contains("://");
    }
}

