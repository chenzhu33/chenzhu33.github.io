package com.example.test_app;

import android.app.Activity;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class TestActivityLeak extends AppCompatActivity {

    private static ArrayList<Activity> sLeakList = new ArrayList<Activity>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ILogUtil.getInstance(false).d("TestActivityLeak","内存泄漏测试用例");
        setContentView(R.layout.activity_test_activit_leak);

        sLeakList.add(this);
        returnMainActivity();
        //这后面的代码不会执行到，如果先要执行，returnMainActivity。
        Button btnTestleak = (Button) findViewById(R.id.buttonleak);
        btnTestleak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                returnMainActivity();
            }
        });
    }

    void returnMainActivity() {
        sLeakList.add(this);
        SystemClock.sleep(1000);
        //此处直接退出页面，制造的泄漏
        finish();
    }

}
