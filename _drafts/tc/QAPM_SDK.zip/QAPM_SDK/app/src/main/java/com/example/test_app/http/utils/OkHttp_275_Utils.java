package com.example.test_app.http.utils;

import android.text.TextUtils;

import com.example.test_app.http.bean.HttpBean;
import com.example.test_app.http.listener.HttpListener;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.ConnectionPool;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import java.io.IOException;
import java.security.cert.CertificateException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;



public class OkHttp_275_Utils {

    private static final String TAG = "OkHttp_275_Utils";

    private volatile static OkHttp_275_Utils okHttp275Utils;

    private OkHttpClient okHttpClient;

    public OkHttp_275_Utils() {
        okHttpClient = getUnsafeOkHttpClient();
    }

    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient builder = new OkHttpClient();
            builder.setConnectionPool(new ConnectionPool(0, 1, TimeUnit.SECONDS));
            builder.setSslSocketFactory(sslSocketFactory);
            builder.setHostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String s, SSLSession sslSession) {
                    return true;
                }
            });
            return builder;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static OkHttp_275_Utils getInstance() {
        if (okHttp275Utils == null) {
            synchronized (OkHttp_275_Utils.class) {
                if (okHttp275Utils == null) {
                    okHttp275Utils = new OkHttp_275_Utils();
                }
            }
        }
        return okHttp275Utils;
    }

    public void getRequest(final HttpBean bean, final HttpListener listener) {
        String url = bean.getUrl();
        if (TextUtils.isEmpty(url)) {
            return;
        }
        Request request = new Request.Builder().url(bean.getUrl()).get().build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Request request, IOException e) {
                bean.setMessage(e.getMessage());
                bean.setException(e.toString().split(":")[0]);
                listener.onFailed(bean);
            }

            @Override
            public void onResponse(Response response) throws IOException {
//                Log.d(TAG, "onResponse: " + response.body().string());
                bean.setMessage(response.body().string());
                bean.setResultCode(response.code());
                listener.onSuccess(bean);
            }
        });
    }

    public void postRequest(final HttpBean bean, final HttpListener listener) {
        RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), DefaultUtils.JSON_DATA);
        Request request = new Request.Builder()
                .url(bean.getUrl())
                .post(body)
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Request request, IOException e) {
                bean.setMessage(e.getMessage());
                bean.setException(e.toString().split(":")[0]);
                listener.onFailed(bean);
            }

            @Override
            public void onResponse(Response response) throws IOException {
                bean.setMessage(response.body().string());
                bean.setResultCode(response.code());
                listener.onSuccess(bean);
            }
        });

    }

    public void release(){
        if (okHttpClient != null) {
            okHttpClient = null;
        }
        if (okHttp275Utils != null) {
            okHttp275Utils = null;
        }
    }

}
