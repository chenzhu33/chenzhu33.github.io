package com.example.test_app;

import android.app.Activity;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


import com.tencent.qapmsdk.QAPM;


import java.util.ArrayList;


public class AnotherActivity extends AppCompatActivity {
    private static ArrayList<Activity> sLeakList = new ArrayList<Activity>();
    private IOTest ioTest;
    private class AnotherRun implements Runnable{
        @Override
        public void run() {
            try {
                ioTest.SQLiteDatabaseTest();
                Thread.sleep(4000);
                ioTest.FileTest();
                Thread.sleep(5000);

            }catch (Exception e){
                e.printStackTrace();
            }

        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_another);
        ILogUtil.getInstance(false).d("AnotherActivity", "AnotherActivity.");
        QAPM.setProperty(QAPM.PropertyKeyAppInstance, getApplication());
        QAPM.setProperty(QAPM.PropertyKeyAppId, "1024").setProperty(QAPM.PropertyKeyAppVersion, "2.1").setProperty(QAPM.PropertyKeySymbolId, "e6ae1282-ceb8-4237-89bd-2d23d00a8e33");
        QAPM.setProperty(QAPM.PropertyKeyUserId, "11223344");

        nextActivity();

        HandlerThread ht = new HandlerThread("TestAnother");
        ht.start();
        Handler testHandler = new Handler(ht.getLooper());
        AnotherRun anotherRun = new AnotherRun();
        testHandler.postDelayed(anotherRun,3000);
    }

    void nextActivity() {
        sLeakList.add(this);
        SystemClock.sleep(1000);
        finish();
    }
}
