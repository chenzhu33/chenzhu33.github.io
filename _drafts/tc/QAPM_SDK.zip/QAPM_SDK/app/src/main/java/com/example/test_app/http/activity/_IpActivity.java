package com.example.test_app.http.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.test_app.R;
import com.example.test_app.http.bean.HttpBean;
import com.example.test_app.http.listener.HttpListener;
import com.example.test_app.http.utils.HttpClientUtils;
import com.example.test_app.http.utils.HttpUtils;
import com.example.test_app.http.utils.OkHttp_275_Utils;
import com.example.test_app.http.utils.OkHttp_311_Utils;

public class _IpActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "_IpActivity";

    private OkHttp_275_Utils okHttp275Utils;
    private OkHttp_311_Utils okHttp311Utils;
    private HttpClientUtils httpClientUtils;
    private HttpUtils httpUtils;

    private Spinner spinner;
    private ArrayAdapter<String> adapter;

    private String url;

    String[] data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity___ip);
        findViewById(R.id.http2).setOnClickListener(this);
        findViewById(R.id.http3).setOnClickListener(this);
        findViewById(R.id.http).setOnClickListener(this);
        findViewById(R.id.https).setOnClickListener(this);
        findViewById(R.id.httpClient).setOnClickListener(this);
        okHttp275Utils = OkHttp_275_Utils.getInstance();
        okHttp311Utils = OkHttp_311_Utils.getInstance();
        httpClientUtils = HttpClientUtils.getInstance();
        httpUtils = HttpUtils.getInstance();

        data = getResources().getStringArray(R.array.data);
        spinner = findViewById(R.id.dataSpinner);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, data);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //将adapter 添加到spinner中
        spinner.setAdapter(adapter);

        url = data[0];
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                url = data[i];
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (okHttp275Utils != null) {
            okHttp275Utils.release();
            okHttp275Utils = null;
        }
        if (okHttp311Utils != null) {
            okHttp311Utils.release();
            okHttp311Utils = null;
        }
        if (httpClientUtils != null) {
            httpClientUtils.release();
            httpClientUtils = null;
        }
        if (httpUtils != null) {
            httpUtils.release();
            httpUtils = null;
        }
        if (data != null) {
            data = null;
        }
        if (adapter != null) {
            adapter = null;
        }
    }

    @Override
    public void onClick(View view) {
        HttpBean bean = new HttpBean();
        int id = view.getId();
        bean.setUrl(url);
        switch (id) {
            case R.id.http2:
                okHttp275Utils.getRequest(bean, listener);
                break;
            case R.id.http3:
                okHttp311Utils.getRequest(bean, listener);
                break;
            case R.id.http:
                if (bean.getUrl().startsWith("http://")) {
                    httpUtils.httpGetRequest(bean, listener);
                }
                break;
            case R.id.https:
                if (bean.getUrl().startsWith("https")) {
                    httpUtils.httpsGetRequest(bean, listener);
                }
                break;
            case R.id.httpClient:
                httpClientUtils.getRequest(bean, listener);
                break;
        }
    }

    public HttpListener listener = new HttpListener() {
        @Override
        public void onFailed(HttpBean bean) {
            Log.d(TAG, "onFailed: " + bean.toString());
        }

        @Override
        public void onSuccess(HttpBean bean) {
            Log.d(TAG, "onSuccess: " + bean.toString());
        }
    };
}
