package com.example.test_app;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.Callable;
import java.util.concurrent.locks.ReentrantLock;

import org.json.JSONObject;
import org.json.JSONException;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Process;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;


import com.example.test_app.utils.SpecialHandle;
import com.example.test_app.utils.X5CoreInitUtils;
import com.example.test_app.utils.X5WebView;
import com.tencent.qapmsdk.Magnifier;
import com.tencent.qapmsdk.QAPM;
import com.tencent.qapmsdk.impl.instrumentation.QAPMJavaScriptBridge;
import com.tencent.qapmsdk.webview.WebViewBreadCrumb;
import com.tencent.qapmsdk.webview.WebViewX5Proxy;
import com.tencent.smtt.export.external.interfaces.JsResult;
import com.tencent.smtt.sdk.CookieSyncManager;
import com.tencent.smtt.sdk.DownloadListener;
import com.tencent.smtt.sdk.ValueCallback;
import com.tencent.smtt.sdk.WebChromeClient;
import com.tencent.smtt.sdk.WebSettings;
import com.tencent.smtt.sdk.WebSettings.LayoutAlgorithm;
import com.tencent.smtt.sdk.WebView;
import com.tencent.smtt.sdk.WebViewClient;
import com.tencent.smtt.utils.TbsLog;
import com.tencent.smtt.export.external.extension.interfaces.IX5WebViewClientExtension;
import com.tencent.smtt.export.external.extension.proxy.ProxyWebViewClientExtension;


public class X5WebViewActivity extends Activity {
    /**
     * 作为一个浏览器的示例展示出来，采用android+web的模式
     */
    private X5WebView mWebView;
    private ViewGroup mViewParent;
    private ImageButton mBack;
    private ImageButton mForward;
    private ImageButton mExit;
    private ImageButton mHome;
    private ImageButton mMore;
    private Button mGo;
    private EditText mUrl;
    private View mFullscreenView = null;

    //private static final String mHomeUrl = "http://app.html5.qq.com/navi/index";
    private static final String mHomeUrl = "file:///android_asset/monitor.html";
    private static final String TAG = "X5WebViewActivity";
    private static final int MAX_LENGTH = 14;
    private static final int KEY_FILE_CHOOSE = 0;

    private final int disable = 120;
    private final int enable = 255;
    private ProgressBar mPageLoadingProgressBar = null;

    private URL mIntentUrl;
    public ValueCallback<Uri> uploadFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFormat(PixelFormat.TRANSLUCENT);
        WebView.setWebContentsDebuggingEnabled(true);

        Intent intent = getIntent();
        if (intent != null) {
            try {
                mIntentUrl = new URL(intent.getData().toString());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {

            } catch (Exception e) {
            }
        }
        //
        try {
            if (Integer.parseInt(android.os.Build.VERSION.SDK) >= 11) {
                getWindow()
                        .setFlags(
                                android.view.WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                                android.view.WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
            }
        } catch (Exception e) {
        }

        /*
         * getWindow().addFlags(
         * android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
         */
        setContentView(R.layout.activity_x5_web_view);
        mViewParent = (ViewGroup) findViewById(R.id.webView1);

        initBtnListenser();

        X5CoreInitUtils.getInstance().onX5CoreInited(new ValueCallback<Boolean>() {
            @Override
            public void onReceiveValue(Boolean arg0) {
                mTestHandler.sendEmptyMessageDelayed(MSG_INIT_UI, 10);
            }
        });
    }

    private void changGoForwardButton(WebView view) {
        if (view.canGoBack())
            mBack.setAlpha(enable);
        else
            mBack.setAlpha(disable);
        if (view.canGoForward())
            mForward.setAlpha(enable);
        else
            mForward.setAlpha(disable);
        if (view.getUrl() != null && view.getUrl().equalsIgnoreCase(mHomeUrl)) {
            mHome.setAlpha(disable);
            mHome.setEnabled(false);
        } else {
            mHome.setAlpha(enable);
            mHome.setEnabled(true);
        }
    }

    private void initProgressBar() {
        mPageLoadingProgressBar = (ProgressBar) findViewById(R.id.progressBar1);// new
        mPageLoadingProgressBar.setMax(100);
        mPageLoadingProgressBar.setProgressDrawable(this.getResources()
                .getDrawable(R.drawable.color_progressbar));
    }

    private void init() {

        mWebView = new X5WebView(this, null);

        mViewParent.addView(mWebView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.FILL_PARENT,
                FrameLayout.LayoutParams.FILL_PARENT));
        initProgressBar();

        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (SpecialHandle.shouldOverrideUrlLoading(view, url)) {
                    return true;
                }
                return false;
            }

            public void onReceivedHttpAuthRequest(WebView view,
                                                  com.tencent.smtt.export.external.interfaces.HttpAuthHandler handler, String host, String realm) {
                Toast.makeText(X5WebViewActivity.this, "should impl onReceivedHttpAuthRequest", Toast.LENGTH_LONG).show();
                super.onReceivedHttpAuthRequest(view, handler, host, realm);
            };

            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (mPageLoadingProgressBar != null) {
                    mPageLoadingProgressBar.setVisibility(View.VISIBLE);
                }
                view.addJavascriptInterface(QAPMJavaScriptBridge.getInstance(),"AndroidQAPMJsBridge");
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (mPageLoadingProgressBar != null) {
                    mPageLoadingProgressBar.setVisibility(View.GONE);
                }
                if (Integer.parseInt(android.os.Build.VERSION.SDK) >= 16)
                    changGoForwardButton(view);
            }
        });

        mWebView.setWebChromeClient(new WebChromeClient() {

            @Override
            public void onReceivedTitle(WebView view, String title) {
                if (mUrl == null)
                    return;
                if (!mWebView.getUrl().equalsIgnoreCase(mHomeUrl)) {
                    if (title != null && title.length() > MAX_LENGTH)
                        mUrl.setText(title.subSequence(0, MAX_LENGTH) + "...");
                    else
                        mUrl.setText(title);
                } else {
                    mUrl.setText("");
                }
                mUrl.clearFocus();
            }

            @Override
            public boolean onJsConfirm(WebView arg0, String arg1, String arg2,
                                       JsResult arg3) {
                return super.onJsConfirm(arg0, arg1, arg2, arg3);
            }

            @Override
            public boolean onJsAlert(WebView arg0, String arg1, String arg2,
                                     JsResult arg3) {
                /**
                 * 这里写入你自定义的window alert
                 */
                return super.onJsAlert(null, arg1, arg2, arg3);
            }

            public void onGeolocationPermissionsShowPrompt(final String origin, final com.tencent.smtt.export.external.interfaces.GeolocationPermissionsCallback callback) {
                SpecialHandle.onGeolocationPermissionsShowPrompt(origin, callback, X5WebViewActivity.this);
            };

            @Override
            public void openFileChooser(com.tencent.smtt.sdk.ValueCallback<Uri> uploadFile, String acceptType, String captureType) {
                Log.i(TAG,"openFileChooser 1");
                enterFileChooser(uploadFile, captureType.equalsIgnoreCase("*"), acceptType, false, "");
            }

            @Override
            public boolean onShowFileChooser (WebView webView, final com.tencent.smtt.sdk.ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams){
                StringBuilder acceptTypeBuilder = new StringBuilder();
                for (int index = 0; index < fileChooserParams.getAcceptTypes().length; index++){
                    acceptTypeBuilder.append(fileChooserParams.getAcceptTypes()[index]);
                }
                String acceptType = acceptTypeBuilder.toString();

                boolean isCaptureEnabled = fileChooserParams.isCaptureEnabled();
                boolean isMul = (fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                ValueCallback<Uri> filePathCallbackAdapter = new com.tencent.smtt.sdk.ValueCallback<Uri>() {

                    @Override
                    public void onReceiveValue(Uri value) {
                        Uri[] uris  = new Uri[1];
                        uris[0] = value;
                        filePathCallback.onReceiveValue(uris);
                    }
                };

                Log.i(TAG,"openFileChooser 2: isCaptureEnabled:" + isCaptureEnabled + ", acceptType:" + acceptType + ", isMul:" +isMul);
                enterFileChooser(filePathCallbackAdapter, isCaptureEnabled, acceptType, isMul, "unite:");
                return true;
            }

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                mPageLoadingProgressBar.setProgress(newProgress);
                if (mPageLoadingProgressBar != null && newProgress >= 100) {
                    mPageLoadingProgressBar.setVisibility(View.GONE);
                }
            }

            @Override
            public void onShowCustomView(View view, com.tencent.smtt.export.external.interfaces.IX5WebChromeClient.CustomViewCallback callback) {
                try {
                    Log.d(TAG,"onShowCustomView begin");
                    if (mFullscreenView != null) {
                        ((ViewGroup) mFullscreenView.getParent()).removeView(mFullscreenView);
                    }
                    mFullscreenView = view;
                    getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                    getWindow().addContentView(mFullscreenView,
                            new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
                    Log.d(TAG,"onShowCustomView end");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onHideCustomView() {
                try {
                    Log.d(TAG,"onHideCustomView begin");
                    if (mFullscreenView == null) {
                        return;
                    }
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                    ((ViewGroup) mFullscreenView.getParent()).removeView(mFullscreenView);
                    mFullscreenView = null;
                    Log.d(TAG,"onHideCustomView end");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        mWebView.setDownloadListener(new DownloadListener() {

            @Override
            public void onDownloadStart(String arg0, String arg1, String arg2,
                                        String arg3, long arg4) {
                TbsLog.d(TAG, "url: " + arg0);
                new AlertDialog.Builder(X5WebViewActivity.this)
                        .setTitle("allow to download？")
                        .setPositiveButton("yes",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog,
                                                        int which) {
                                        Toast.makeText(
                                                X5WebViewActivity.this,
                                                "fake message: i'll download...",
                                                Toast.LENGTH_SHORT).show();
                                    }
                                })
                        .setNegativeButton("no",
                                new DialogInterface.OnClickListener() {

                                    @Override
                                    public void onClick(DialogInterface dialog,
                                                        int which) {
                                        // TODO Auto-generated method stub
                                        Toast.makeText(
                                                X5WebViewActivity.this,
                                                "fake message: refuse download...",
                                                Toast.LENGTH_SHORT).show();
                                    }
                                })
                        .setOnCancelListener(
                                new DialogInterface.OnCancelListener() {

                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        // TODO Auto-generated method stub
                                        Toast.makeText(
                                                X5WebViewActivity.this,
                                                "fake message: refuse download...",
                                                Toast.LENGTH_SHORT).show();
                                    }
                                }).show();
            }
        });

        // mWebView.getX5WebViewExtension().setWebViewClientExtension(mWebViewClientExtension );
        QAPM.setProperty(QAPM.PropertyWebViewBreadCrumbListener, new WebViewBreadCrumb.WebViewBreadCrumbListener() {
            @Override
            public Object saveWebView(){
                return mWebView;
            }

        });

        WebSettings webSetting = mWebView.getSettings();
        webSetting.setAllowFileAccess(true);
        webSetting.setLayoutAlgorithm(LayoutAlgorithm.NARROW_COLUMNS);
        webSetting.setSupportZoom(true);
        webSetting.setBuiltInZoomControls(true);
        webSetting.setUseWideViewPort(true);
        webSetting.setSupportMultipleWindows(false);
        webSetting.setLoadWithOverviewMode(true);
        webSetting.setAppCacheEnabled(true);
        webSetting.setDomStorageEnabled(true);
        webSetting.setJavaScriptEnabled(true);
        webSetting.setGeolocationEnabled(true);
        webSetting.setAppCacheMaxSize(Long.MAX_VALUE);
        webSetting.setAppCachePath(this.getDir("appcache", 0).getPath());
        webSetting.setDatabasePath(this.getDir("databases", 0).getPath());
        webSetting.setGeolocationDatabasePath(this.getDir("geolocation", 0)
                .getPath());
        webSetting.setPluginState(WebSettings.PluginState.ON_DEMAND);
        long time = System.currentTimeMillis();
        if (mIntentUrl == null) {
            mWebView.loadUrl(mHomeUrl);
        } else {
            mWebView.loadUrl(mIntentUrl.toString());
        }
        TbsLog.d("time-cost", "cost time: "
                + (System.currentTimeMillis() - time));
        CookieSyncManager.createInstance(this);
        CookieSyncManager.getInstance().sync();

        if (isInX5Mode(mWebView)) {
            mWebView.getX5WebViewExtension().setWebChromeClientExtension(SpecialHandle.getLocalWebChromeClientExtension(this, mWebView));
            // Bundle bu = new Bundle();
            // bu.putInt("filterType", 65);
            // Object ret = mWebView.getX5WebViewExtension().invokeMiscMethod("setDataFilterForRequestInfo", bu);
        }
    }

    private boolean isInX5Mode(WebView webview) {
        return (webview != null && webview.getX5WebViewExtension() != null);
    }

    private void initBtnListenser() {
        mBack = (ImageButton) findViewById(R.id.btnBack1);
        mForward = (ImageButton) findViewById(R.id.btnForward1);
        mExit = (ImageButton) findViewById(R.id.btnExit1);
        mHome = (ImageButton) findViewById(R.id.btnHome1);
        mGo = (Button) findViewById(R.id.btnGo1);
        mUrl = (EditText) findViewById(R.id.editUrl1);
        mMore = (ImageButton) findViewById(R.id.btnMore);
        if (Integer.parseInt(android.os.Build.VERSION.SDK) >= 16) {
            mBack.setAlpha(disable);
            mForward.setAlpha(disable);
            mHome.setAlpha(disable);
        }
        mHome.setEnabled(false);

        mBack.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mWebView != null && mWebView.canGoBack())
                    mWebView.goBack();
            }
        });

        mForward.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mWebView != null && mWebView.canGoForward())
                    mWebView.goForward();
            }
        });

        mGo.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                String url = UrlUtils.converToValidUrl(mUrl.getText().toString());
                if (null != url && null != mWebView) {
                    mWebView.loadUrl(url);
                    mWebView.requestFocus();
                } else {
                    mUrl.clearFocus();
                }
            }
        });

        mMore.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Toast.makeText(X5WebViewActivity.this, "no more menus",
                        Toast.LENGTH_LONG).show();
            }
        });

        mUrl.setOnFocusChangeListener(new OnFocusChangeListener() {

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (null == mWebView) {
                    return;
                }
                if (hasFocus) {
                    mGo.setVisibility(View.VISIBLE);
                    if (null == mWebView.getUrl())
                        return;
                    if (mWebView.getUrl().equalsIgnoreCase(mHomeUrl)) {
                        mUrl.setText("");
                        mGo.setText("取消");
                        mGo.setTextColor(0X6F0F0F0F);
                    } else {
                        mUrl.setText(mWebView.getUrl());
                        mGo.setText("进入");
                        mUrl.setSelectAllOnFocus(true);
                        mUrl.selectAll();
                        mGo.setTextColor(0X6F0000CD);
                    }
                } else {
                    mGo.setVisibility(View.GONE);
                    String title = mWebView.getTitle();
                    if (title != null && title.length() > MAX_LENGTH)
                        mUrl.setText(title.subSequence(0, MAX_LENGTH) + "...");
                    else
                        mUrl.setText(title);
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
            }

        });

        mUrl.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub

                String url = null;
                if (mUrl.getText() != null) {
                    url = mUrl.getText().toString();
                }

                if (url == null
                        || mUrl.getText().toString().equalsIgnoreCase("")) {
                    mGo.setText("取消");
                    mGo.setTextColor(0X6F0F0F0F);
                } else {
                    mGo.setText("进入");
                    mGo.setTextColor(0X6F0000CD);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1,
                                          int arg2, int arg3) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onTextChanged(CharSequence arg0, int arg1, int arg2,
                                      int arg3) {
                // TODO Auto-generated method stub

            }
        });

        mHome.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mWebView != null)
                    mWebView.loadUrl(mHomeUrl);
            }
        });

        mExit.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (mWebView != null && mWebView.canGoBack()) {
                mWebView.goBack();
                if (Integer.parseInt(android.os.Build.VERSION.SDK) >= 16)
                    changGoForwardButton(mWebView);
                return true;
            } else
                return super.onKeyDown(keyCode, event);
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        if (intent == null || mWebView == null || intent.getData() == null)
            return;
        mWebView.loadUrl(intent.getData().toString());
    }

    @Override
    protected void onDestroy() {
        if (mTestHandler != null)
            mTestHandler.removeCallbacksAndMessages(null);
        if (mWebView != null)
            mWebView.destroy();
        super.onDestroy();
    }

    public static final int MSG_INIT_UI = 1;
    private Handler mTestHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_INIT_UI:
                    init();
                    break;
            }
            super.handleMessage(msg);
        }
    };

    public void enterFileChooser(ValueCallback<Uri> uploadFile, boolean isCaptureEnabled, String acceptType, boolean isMul, String extra) {
        String message = isMul ? "多选" : "单选";
        message = extra + message;
        if (isCaptureEnabled) {
            if (acceptType.startsWith("video")) {
                message += "录像文件";
            } else if (acceptType.startsWith("image")) {
                message += "拍照文件";
            } else if (acceptType.startsWith("audio")) {
                message += "录音文件";
            }
        } else if (!TextUtils.isEmpty(acceptType)) {
            message += acceptType+"文件";
        }
        Toast.makeText(X5WebViewActivity.this, message, Toast.LENGTH_LONG).show();
        this.uploadFile = uploadFile;
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        this.startActivityForResult(Intent.createChooser(i,getResources().getString(R.string.choose_uploadfile)), KEY_FILE_CHOOSE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case KEY_FILE_CHOOSE:
                    if (null != uploadFile) {
                        Uri result = data == null || resultCode != RESULT_OK ? null
                                : data.getData();
                        uploadFile.onReceiveValue(result);
                        uploadFile = null;
                    }
                    break;
                default:
                    break;
            }
        }
        else if (resultCode == RESULT_CANCELED) {
            if (null != uploadFile) {
                uploadFile.onReceiveValue(null);
                uploadFile = null;
            }
        }
    }


    // private IX5WebViewClientExtension mWebViewClientExtension = new ProxyWebViewClientExtension() {

    //     public void invalidate()
    //     {
    //     }

    //     public void onReceivedViewSource(String data) {
    //         TbsLog.d("onReceivedViewSource", data);
    //         Log.e(TAG, "gjq onReceivedViewSource");
    //     };

    //     @Override
    //     public Object onMiscCallBack(String method,
    //             Bundle bundle) {
    //         if (method == "onSecurityLevelGot") {
    //             Toast.makeText(
    //                     X5WebViewActivity.this,
    //                     "Security Level Check: \nit's level is "
    //                             + bundle.getInt("level"), 1000)
    //                     .show();
    //         } else if(method.equals("onReportPerformanceInfo")){
    //             String info = bundle.getString("performance");
    //             JSONObject infoJSON = null;
    //             try {
    //                 infoJSON = new JSONObject(info);
    //                 Log.e(TAG, "onReportPerformanceInfo performance:" + infoJSON.toString());
    //             } catch (JSONException e) {
    //                 e.printStackTrace();
    //             }
    //         }
    //         return null;
    //     }

    // };
}
