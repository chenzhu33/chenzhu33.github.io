package com.example.test_app.http.bean;

public class HttpBean {

    private String url;
    private boolean isPort;
    private boolean isIp;
    private int resultCode;
    private String exception;
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public boolean isPort() {
        return isPort;
    }

    public void setPort(boolean port) {
        isPort = port;
    }

    public boolean isIp() {
        return isIp;
    }

    public void setIp(boolean ip) {
        isIp = ip;
    }

    public int getResultCode() {
        return resultCode;
    }

    public void setResultCode(int resultCode) {
        this.resultCode = resultCode;
    }

    public String getException() {
        return exception;
    }

    public void setException(String exception) {
        this.exception = exception;
    }

    @Override
    public String toString() {
        return "HttpBean{" +
                "url='" + url + '\'' +
                ", isPort=" + isPort +
                ", isIp=" + isIp +
                ", resultCode=" + resultCode +
                ", exception='" + exception + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
