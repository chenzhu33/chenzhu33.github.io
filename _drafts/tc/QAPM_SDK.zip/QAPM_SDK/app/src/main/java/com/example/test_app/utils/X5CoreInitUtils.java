package com.example.test_app.utils;

import java.util.ArrayList;

import com.tencent.smtt.sdk.QbSdk;
import com.tencent.smtt.sdk.network.InterceptManager;
import com.tencent.smtt.sdk.plugin.PluginManager;

import android.content.Context;
import android.os.Looper;
import android.util.Log;
import android.webkit.ValueCallback;

public class X5CoreInitUtils {
    private static final String TAG = "X5CoreInitUtils";

    private static final int STATUS_SysCore = 0;//内核初始化完毕，当前使用系统内核
    private static final int STATUS_X5Core = 1;//内核初始化完毕，当前使用X5内核
    private static final int STATUS_UnInited = 2;//内核尚未初始化完毕

    private static X5CoreInitUtils sX5CoreInitUtils = null;

    private Thread mInitThread = null;
    private ArrayList<ValueCallback<Boolean>> mX5CoreInitedValueCallbackList = new ArrayList<ValueCallback<Boolean>>();
    private Object mX5CoreInitedValueCallbackListLock    = new Object();
    private int mCoreInitStatus = STATUS_UnInited;

    public static X5CoreInitUtils getInstance() {
        if (null != sX5CoreInitUtils) {
            return sX5CoreInitUtils;
        }

        synchronized (X5CoreInitUtils.class) {
            if (null == sX5CoreInitUtils) {
                sX5CoreInitUtils = new X5CoreInitUtils();
            }
        }
        return sX5CoreInitUtils;
    }

    private X5CoreInitUtils(){
        boolean result = InterceptManager.getInstance().setURLStreamHandler();
        Log.d(TAG, "setURLStreamHandler:" + result);
        //临时允许定位请求后台，不请求后台完全依赖GPS的情况下，在室内或GPS信号比较弱时高概率无法定位
        InterceptManager.getInstance().excludeInterceptUrl("https://lbs.map.qq.com/loc?*");
    }

    public void init(final Context context){
        if (null != mInitThread) {
            return;
        }
        mInitThread = new Thread(new Runnable() {
            @Override
            public void run() {
                Looper.prepare();

                long start = System.currentTimeMillis();
                QbSdk.preinstallStaticTbs(context.getApplicationContext());
                long consume_time = System.currentTimeMillis() - start;

                Log.d(TAG, "preinstallStaticTbs consume time:" + consume_time);

                QbSdk.PreInitCallback cb = new QbSdk.PreInitCallback() {

                    @Override
                    public void onViewInitFinished(boolean isX5Core) {
                        //x5內核初始化完成的回调，为true表示x5内核加载成功，否则表示x5内核加载失败，会自动切换到系统内核。
                        Log.d(TAG, " onViewInitFinished is " + isX5Core);
                        coreInitCompleted(isX5Core);
                    }

                    @Override
                    public void onCoreInitFinished() {
                    }
                };
                //x5内核初始化接口
                QbSdk.initX5Environment(context.getApplicationContext(),  cb);
                PluginManager.getInstance(context.getApplicationContext()).installPluginList();
                Looper.loop();
            }
        });
        mInitThread.setName("X5CoreInit");
        mInitThread.start();
    }

    public void onX5CoreInited(ValueCallback<Boolean> callback) {
        synchronized(mX5CoreInitedValueCallbackListLock) {
            if (STATUS_UnInited != mCoreInitStatus) {
                Log.d(TAG, "core inited mCoreInitStatus:" + mCoreInitStatus);
                callback.onReceiveValue(STATUS_X5Core == mCoreInitStatus ? true : false);
            } else {
                Log.d(TAG, "core not inited");
                mX5CoreInitedValueCallbackList.add(callback);
            }
        }
    }

    //内核初始化完毕，isX5Core表示是否可以使用X5内核
    //运行在main线程
    private void coreInitCompleted(boolean isX5Core) {
        synchronized(mX5CoreInitedValueCallbackListLock) {
            mCoreInitStatus = isX5Core ? STATUS_X5Core : STATUS_SysCore;
            int size = mX5CoreInitedValueCallbackList.size();
            for (int index = 0; index < mX5CoreInitedValueCallbackList.size(); index++) {
                Log.d(TAG, "core inited, call all valuecallback from list. isX5Core:" + isX5Core);
                mX5CoreInitedValueCallbackList.get(index).onReceiveValue(isX5Core);
            }
            if (size > 0) {
                mX5CoreInitedValueCallbackList.clear();
            }
        }
    }
}
