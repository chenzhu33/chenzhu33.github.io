package com.example.test_app;

import android.util.Log;

import com.tencent.qapmsdk.battery.BatteryStatsImpl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 *
 * <b>类描述：</b> 自定义一个Log类，发布的时候只需要设置Debug为false就不会再打印log了    <br/>
 * <b>创建人：</b>janksenhu(QQ:799423779)      <br/>
 * <b>修改时间：</b>2016-2-18 下午7:26:19    <br/>
 * @version 1.0.0    <br/>
 *
 */
public class ILogUtil {
    private volatile static ILogUtil ilu;
    private static final String TAG = ILogUtil.getTAG(ILogUtil.class);
    private static int logQueueSize = 1024;

    //如果是Debug版本，全部打印日志
    public static boolean debug = false;
    private static boolean threadRunning = false;

    //记录日志写入文件
    private static BlockingQueue<String> logQueue = null;
    private static SimpleDateFormat logTimeFormatter = new SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US);
    private ILogUtil(boolean isDebug) {
        setDebug(isDebug);
    }

    public static void setDebug(boolean isDebug) {
        debug = isDebug;
        if (debug == true) {
            if (threadRunning == false) {
                //startWriteLogThread();
            }
            if (logQueue == null) {
                logQueue = new LinkedBlockingQueue<String>(logQueueSize);
            }
        }
    }

    /**
     * 单例
     * @param isDebug
     * @return
     */
    public static ILogUtil getInstance(boolean isDebug) {
        if (null == ilu) {
            synchronized(ILogUtil.class) {
                if (null == ilu) {
                    ilu = new ILogUtil(true);
                }
            }
        }
        return ilu;
    }

    public static String getTAG(Class<?> clazz) {
        return "Magnifier_" + clazz.getSimpleName();
    }

    /**
     * verbose 级别日志
     * @param tag 日志tag
     * @param msg 日志
     */
    public void v(String ...args) {
        if (debug) {
            if (args.length==0)
                return;
            String tag = args[0];
            if (tag == null || args.length<=1) return;
            StringBuilder logS = new StringBuilder(256);
            for (int i = 1; i < args.length; i++) {
                logS.append(args[i]);
            }
            String msg = logS.toString();
            BatteryStatsImpl.getInstance().onWriteLog(tag, msg);
            Log.v(tag, msg);
            logS.delete(0, logS.length());
            logS.append(logTimeFormatter.format(System.currentTimeMillis())).append("    V/").append(TAG).append(":    ").append(msg);
            try {
                logQueue.offer(logS.toString());
            } catch (Throwable tr) {
                tr.printStackTrace();
            }
        }
    }

    /**
     * debug 级别日志
     * @param tag 日志tag
     * @param msg 日志
     */
    public void d(String ...args) {
        if (debug) {
            if (args.length==0)
                return;
            String tag = args[0];
            if (tag == null || args.length<=1) return;
            StringBuilder logS = new StringBuilder(256);
            for (int i = 1; i < args.length; i++) {
                logS.append(args[i]);
            }
            String msg = logS.toString();
            BatteryStatsImpl.getInstance().onWriteLog(tag, msg);
            Log.d(tag, msg);
            logS.delete(0, logS.length());
            logS.append(logTimeFormatter.format(System.currentTimeMillis())).append("    V/").append(TAG).append(":    ").append(msg);
            try {
                logQueue.offer(logS.toString());
            } catch (Throwable tr) {
                tr.printStackTrace();
            }
        }
    }


    /**
     * info 级别日志
     * @param tag
     * @param msg
     */
    public void i(String ...args) {
        if (debug) {
            if (args.length==0)
                return;
            String tag = args[0];
            if (tag == null || args.length<=1) return;
            StringBuilder logS = new StringBuilder(256);
            for (int i = 1; i < args.length; i++) {
                logS.append(args[i]);
            }
            String msg = logS.toString();
            BatteryStatsImpl.getInstance().onWriteLog(tag, msg);
            Log.i(tag, msg);
            logS.delete(0, logS.length());
            logS.append(logTimeFormatter.format(System.currentTimeMillis())).append("    V/").append(TAG).append(":    ").append(msg);
            try {
                logQueue.offer(logS.toString());
            } catch (Throwable tr) {
                tr.printStackTrace();
            }
        }
    }

    /**
     * warning 级别日志
     * @param tag
     * @param msg
     */
    public void w(String ...args) {
        if (debug) {
            if (args.length==0)
                return;
            String tag = args[0];
            if (tag == null || args.length<=1) return;
            StringBuilder logS = new StringBuilder(256);
            for (int i = 1; i < args.length; i++) {
                logS.append(args[i]);
            }
            String msg = logS.toString();
            BatteryStatsImpl.getInstance().onWriteLog(tag, msg);
            Log.w(tag, msg);
            logS.delete(0, logS.length());
            logS.append(logTimeFormatter.format(System.currentTimeMillis())).append("    V/").append(TAG).append(":    ").append(msg);
            try {
                logQueue.offer(logS.toString());
            } catch (Throwable tr) {
                tr.printStackTrace();
            }
        }

    }

    /**
     * error 级别日志
     * @param tag
     * @param msg
     */
    public void e(String ...args) {
        if (debug) {
            if (args.length==0)
                return;
            String tag = args[0];
            if (tag == null || args.length<=1) return;
            StringBuilder logS = new StringBuilder(256);
            for (int i = 1; i < args.length; i++) {
                logS.append(args[i]);
            }
            String msg = logS.toString();
            BatteryStatsImpl.getInstance().onWriteLog(tag, msg);
            Log.e(tag, msg);
            logS.delete(0, logS.length());
            logS.append(logTimeFormatter.format(System.currentTimeMillis())).append("    V/").append(TAG).append(":    ").append(msg);
            try {
                logQueue.offer(logS.toString());
            } catch (Throwable tr) {
                tr.printStackTrace();
            }
        }
    }


    /**
     *
     * <b>方法描述：</b>可以调用打印异常信息到logcat    <br/>
     * @param tag
     * @param exc
     * @exception    <br/>
     * @since  1.0.0
     */
    public void exception(String tag, Throwable e) {
        if (tag == null || e == null) return;
        if (debug) {
            String exc = getThrowableMessage(e);
            BatteryStatsImpl.getInstance().onWriteLog(tag, exc);
            Log.e(tag, exc);
            try {
                logQueue.offer(logTimeFormatter.format(System.currentTimeMillis()) + "    Exception/" + tag + ":    " + exc);
            } catch (Throwable tr) {
                tr.printStackTrace();
            }
        }
    }

    /**
     * 获取异常的堆栈信息
     * @param e
     * @return
     */
    public static String getThrowableMessage(Throwable e) {
        if (e == null) return "";
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        return sw.toString();
    }

    /**
     * 启动写入日志到文件流程
     * @return
     */
//    private static void startWriteLogThread() {
//        Handler h = new Handler(ThreadManager.getLogThreadLooper());
//        h.post(new Runnable() {
//            @Override
//            public void run() {
//                boolean externalStorageWritable = true;
//                String state = Environment.getExternalStorageState();
//                if (state.equals(Environment.MEDIA_MOUNTED)) {
//                } else if (state.equals(Environment.MEDIA_MOUNTED) || state.equals(Environment.MEDIA_MOUNTED_READ_ONLY)) {
//                    externalStorageWritable = false;
//                } else {
//                    externalStorageWritable = false;
//                }
//                if (!externalStorageWritable) {
//                    Log.e(TAG, "sdcard could not write");
//                    return;
//                }
//
//                File outPath = Environment.getExternalStorageDirectory();
//                File logDir = new File(outPath, "MagnifierSDK");
//                if (!logDir.exists()) {
//                    logDir.mkdirs();
//                }
//
//                long lastTimeMillis = 0;
//                BufferedWriter writer = null;
//                threadRunning = true;
//                //每隔2小时创建一个日志文件
//                long currentTimeMillis = 0;
//                while (debug) {
//                    try {
//                        currentTimeMillis = System.currentTimeMillis();
//                        String logItem = logQueue.take();
//                        if (null != logItem) {
//                            if (currentTimeMillis - lastTimeMillis > 2*3600*1000) {
//                                try {
//                                    SimpleDateFormat timeFormatter = new SimpleDateFormat("MM.dd.HH", Locale.US);
//                                    File logFile = new File(logDir, timeFormatter.format(currentTimeMillis) + ".log");
//                                    if (logFile != null && !logFile.exists()) {
//                                        logFile.createNewFile();
//                                    }
//                                    writer = new BufferedWriter(new FileWriter(logFile, true));
//                                } catch (Throwable e) {
//                                    Log.e(TAG, getThrowableMessage(e));
//                                }
//                                lastTimeMillis = currentTimeMillis;
//                            }
//                            if (null != writer) {
//                                writer.write(logItem + "\r\n");
//                                writer.flush();
//                            }
//                        } else {
//                            Thread.sleep(30 * 1000);
//                        }
//                    } catch (Exception e) {
//                        Log.e(TAG, "write to file occurs exception: " + e.getStackTrace().toString());
//                        if (null != writer) {
//                            try {
//                                writer.close();
//                            } catch (IOException e1) {
//                                Log.e(TAG, "close log write stream error: " + e1.getStackTrace().toString());
//                            }
//                        }
//                        try {
//                            Thread.sleep(5 * 60 * 1000);
//                        } catch (InterruptedException e1) {
//                        }
//                    }
//                }
//                threadRunning = false;
//            }
//        });
//    }
}