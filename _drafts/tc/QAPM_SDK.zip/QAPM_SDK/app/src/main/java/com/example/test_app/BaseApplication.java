package com.example.test_app;

import android.app.Application;
import android.content.Context;

import com.example.test_app.utils.X5CoreInitTest;
import com.example.test_app.utils.X5CoreInitUtils;
import com.tencent.qapmsdk.crash.CrashMonitor;

public class BaseApplication extends Application {

    @Override
    protected void attachBaseContext(Context base){
        super.attachBaseContext(base);
        CrashMonitor monitor = new CrashMonitor(this).setReportCrash();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        X5CoreInitTest.initTestCode();
        X5CoreInitUtils.getInstance().init(getApplicationContext());
    }
}
