# Module HMS-IM-SDK

**超信**即时通信SDK。


## 主要组建及功能
1. `com.tencent.hms:core:$hms_version`:
    HMS 的核心逻辑，主要通过 [HMSCore] 类暴露接口
2. `com.tencent.hms:ext-wns:$hms_version`:
    [HMSNetworkTransfer] 的 WNS 实现，方便业务侧借助WNS实现HMS的网络传输层
3. `com.tencent.hms:ext-liveData:$hms_version`:
    提供HMS内部的 [HMSObservableData] 与LiveData结合的能力
4. `com.tencent.hms:ext-wcdb:$hms_version`:
    [HMSSqlDriverFactor] 的 wcdb 实现，用于业务侧方便的实现一个解密数据库
5. `com.squareup.sqldelight:android-driver:1.2.1`:
    [HMSSqlDriverFactor] 的 标准Android实现
6. `com.tencent.hms:ext-android:$hms_version`:
    HMS的Android平台扩展，用于业务侧快速的搭建HMS依赖。


## SDK 设计概览
### 1. 消息结构
HMS消息分为两种:
#### 普通消息 [HMSPlainMessage]
 所有用户发送的消息，重点介绍几个字段：
 
    1. text 即消息的文本内容，HMS后台会对其中的文字、链接做安全打击
    
    2. push_text 离线push时，通知显示的文本内容，为null的时候则使用 text 做离线push
    
    2. type 结构化消息的类型
    
    3. payload 结构化消息的二进制内容
消息设计的时候充分考虑了灵活性，因此除了text字段外还有 type和payload用于业务侧自行实现结构化的消息，如，语音，视频，文件，链接分享等。
一种type对应一种payload，业务侧需要实现 [HMSSerializer.serializeMessagePayload] 和 [HMSSerializer.deserializeMessagePayload] 接口，实现特定type的payload如何编解码。（关于这两个接口，详见下一节 关于 BusinessBuffer 的代码实例）

#### 控制消息 [HMSControlMessage]
 系统发出的消息，如 创建回话，退出回话等。

详见对应类的文档

###2. 各种 BusinessBuffer

类似于上节的payload，HMS在数据结构设计时充分考虑了业务侧的可扩展性，因此一些数据结构中都有对应的 businessBuffer 数据。
他们是 二进制数据，HMS内部及Server端均做透传，业务侧自行实现解析，编码逻辑(通过 [HMSSerializer])。
并提供给业务侧使用。
这些数据包括:

    1. [HMSMessageExtension.businessBuffer]
    2. [HMSSession.businessBuffer]
    3. [HMSUser.businessBuffer]
    4. [HMSUserInSession.businessBuffer]
    
从网络协议的角度看，这些BusinessBuffer是 byte数组类型的，但是HMSSDK对外的API上，这些类型都是 Object （Kotlin是Any）。也就是通过 [HMSSerializer] 解析之后的对象。
业务侧可以直接转换成自己的类型，然后获取其数据。

比如，若想在 HMSUser 中添加业务自定义数据结构：
```kotlin

// 业务侧定义的 HMSUser 数据结构
class UserInfo(val age: Int) {
    fun toByteArray(): ByteArray { ... }
    companion object {
        fun fromByteArray(data: ByteArray): UserInfo { ... }
    }
}

// 业务侧需要实现对应的 序列化，反序列化接口
class MyHMSSerializer: HMSSerializer() {
    open fun serializeUserBusinessBuffer(businessBuffer: Any): ByteArray {
        return (businessBuffer as UserInfo).toByteArray()
    }

    open fun deserializeUserBusinessBuffer(businessBuffer: ByteArray): Any {
        return UserInfo.fromByteArray(businessBuffer)
    }
}

// 业务侧可以使用该数据结构
val user : HMSUser = message.senderInfo.user

// 直接转成业务侧的数据结构，类型和 MyHMSSerializer中对应
val userInfo = user.businessBuffer as UserInfo 

userAgeTextView.setText(userInfo.age + "岁")
```

### 3. extension

类似于BusinessBuffer，Extension是设计的专门针对客户端的数据，用户客户端存储本地数据。（BusinessBuffer会透传到server端）。
他们有：

    1. [HMSMessage.extension] 消息的扩展数据结构，业务侧可以存储该消息的额外数据，比如视频的下载路径，语音的播放位置等
    2. [HMSSession.extension] 会话的扩展数据接口，业务侧可以存储该会话的额外数据
    
注意：使用扩展数据是，也要在 [HMSSerializer] 中实现对应的 序列化/反序列化 接口


###3. 消息顺序
后台获取到本地的消息按照消息的后台时间戳展示。

对于客户端本地发送的消息，为了防止消息在发送成功后位置的跳变，HMS的逻辑是消息永远保持在发送时的位置。发送成功之后也不会再次按照server顺序展示。

因此本地发送的消息可能存在和server顺序（别的终端看到的消息顺序）不一致的情况。

PS：此逻辑参考微信

###4. 响应式
    
HMS在设计的时候充分考虑了比较新的技术栈，参考了 RxJava，LiveData 等框架，实现了一套响应式编程的API。

HMS内部很多数据以 [HMSObservableData] 的形式对外暴露，该数据结构会在数据发生变化的时候自动更新。举例说明

```kotlin
val session = hmsCore.getSessionObservableData(sessionId)
// 监听，注意在onDestroy中removeObserver，防止内存泄漏
session.observe { session ->
    sessionNameTextView.setText(session.name)
}

hmsCore.updateSessionInfo(sessionId, name = "new name")
// 更新session名字成功之后，HMSSession数据结构发生了变化，上面的监听器会自动回调，因此UI始终可以展示最新的数据
```

此外，HMS还提供了一个扩展组件 `com.tencent.hms:ext-liveData:$hms_version` 用于将一个 [HMSObservableData] 转换成 Android 的 [LiveData] 来使用，如：

```kotlin
val session = hmsCore.getSessionObservableData(sessionId)
session.liveData.observe(lifeCycleOwner) { ... }
```
借助 LiveData 的能力，我们不需要主动 removeObserver。

还有，作为HMS比较核心的两个类 HMSMessageListLogic， HMSSessionListLogic分别提供了消息列表和回话列表的能力，以消息列表举例：
HMSMessageListLogic实现了 [HMSObservableList] 接口，既是一个 容器List，也能够通知容器内的变化 增删改。

当 HMSMessageListLogic 中的一条消息内容发生变化（或者该消息的sender数据结构发生变化），该类就会自动从db中更新数据并通过 [HMSListUpdateCallback] 接口回调给业务侧数据发生了变化，业务侧进而可以刷新UI。

建议：业务侧直接在 [HMSListUpdateCallback] 中调用 RecyclerView 的各种 notify 操作。借助 [HMSMessageListLogic] 能力，业务侧可以用几十行代码就实现消息列表界面。
    
###5. 灵活性
HMS在设计的时候充分考虑了灵活性，因此很多组件是使用接口隔离开的，业务侧可以自行 选择、实现 对应的组件。

#### HMSSqlDriverFactory

HMS 借助 SqlDelight 实现数据库的ORM，同时也借助其能力实现了数据库实现的隔离。同时我们默认提供了两种数据库的实现：
1. `com.squareup.sqldelight:android-driver:$sqldelight_version` SqlDelight 默认提供的 Android SQLiteDatabase 实现
2. `com.tencent.hms:ext-wcdb:$hms_version` 微信的WCDB数据库实现，业务侧需要数据库加密时可以选择使用该组件
3. `com.squareup.sqldelight:sqlite-driver:$sqldelight_version` SqlDelight 默认提供的JDBC实现，用于在jvm平台跑单元测试使用。


#### HMSNetworkTransfer
HMS 隔离了网络传输层，但是默认提供了基于维纳斯（WNS）的实现：
`com.tencent.hms:ext-wns:$hms_version`

主要提供能力：
1. 发请求 [HMSNetworkTransfer.sendRequest]
2. 收在线push [HMSNetworkTransfer.enablePush]
3. 监听网络状态 [HMSNetworkTransfer.registerNetworkStatusListener]
4. 离线push能力 [HMSNetworkTransfer.registerPushToken]

### HMSExecutorDelegate
初始化HMS的时候提供的线程池实现

### HMSLogDelegate
初始化HMS的时候提供的日志组件实现

## 约定
HMS所有异步接口，如无特殊说明，均在主线程回调。

所有时间单位，如无特殊说明，均为毫秒。

## Kotlin 协程
SDK使用Kotlin语言开发，内部充分利用了Kotlin协程的能力，对外暴露的接口有两种形式

1. 传统的回调形式
2. 协程形式

传统回调形式可供Java语言调用。

协程API只有Kotlin语言能调用，为避免和回调形式混淆，使用 Extension Function 的形式提供。

## 接入流程
1. 接入WNS
    HMS SDK的设计是和网络层解耦的，但是目前网络层的实现是依赖维纳斯（WNS）的，因此业务侧接入之前需要配置WNS，并登陆成功。关于配置WNS的重点，详见下文。
2. 初始化HMSCore
    业务侧调用 [HMSCore.initialize] 方法，异步的初始化HMSCore的实例，初始化需要传入一个 [HMSCore.InitializeArguments]，需要业务侧实现几个相关的Delegate（上文都有提及）。
    对于想要快速接入的业务，HMS还提供了一个 `HMSAndroidInitializeArgumentsBuilder` 类，用于快速构建一个初始化参数，详见该类文档。
    PS：要使用 `HMSAndroidInitializeArgumentsBuilder` 类需要gradle 引入依赖 `com.tencent.hms:ext-android:$hms_version`
4. 业务侧执行实现HMSCore的单例 or service
    HMSCore初始化成功之后会创建一个HMSCore的实例。HMS SDK不负责管理该实例，如：保持单例，或使用Service等，业务侧需要根据自己的使用场景自行实现。
5. **传递正确的前后台状态**
    业务侧在创建了HMSCore的实例之后，HMS默认是处于background。业务侧需要在 聊天模块进入前台，或退出后台的时候正确的设置 `HMSCore.isForeground`，HMS根据前后台状态会有一定的内部逻辑。如在前台时 HMS会定时发送心跳；定时轮询新消息
防止其丢失。
6. 开始使用
    下面就可以开始愉快的使用了。HMS的所有功能都通过 `HMSCore` 类作为入口。


## 收发消息
HMS在发消息的时候会先把消息写入本地的数据库，然后再发送消息到server。HMS内部会关系消息的状态（详见 [HMSMessageStatus])。

### 示例1：发消息
直接调用 `HMSCore.sendMessage` 即可，详见文档。

### 示例2：发送一个富媒体消息
此类消息通常需要业务侧先上传富媒体，比如视频，上传成功之后才能发送到server端。但是在上传过程中又需要该消息在用户本地的消息列表中展示。
HMS提供的方案是：

HMS内部管理了消息的状态，至于富媒体的上传状态，HMS则提供了 [HMSMessage.extension] 方便业务侧来自行实现。

```kotlin
// 1. 先把消息添加到 DB, 利用 message 的extension能力将需要上传的文件path和上传状态存进去
val extension = createMessageExtensionWithLocalFile(localFilePath)
val messageIndex = hmsCore.addLocalMessage(..., extension = extension)

// 2. 调用上传组件
uploadFile(localFilePath) 

// 3. 更新上传进度
extension.uploadProgress = progress
hmsCore.updateLocalMessage(messageIndex, extension = extension)

// 4. 上传成功
//      1. 将视频的url更新到payload中
hmsCore.updateLocalMessage(messageIndex, payload = xxx)
//      2. 将该消息发送出去
hmsCore.sendLocalMessage(messageIndex)

//5. 上传失败，将上传状态置为失败
extension.status = FAILED
hmsCore.updateLocalMessage(messageIndex, extension = extension)
```

更详细的文档请参考上述各个方法的 doc。

### 实例3：撤回，更新消息
HMS提供消息撤回的能力，撤回的消息其 [HMSMessage.isRevokes] 字段为true，消息体的内容完全保留。

撤回一条已经发送的消息：

```kotlin
hmsCore.revokeMessage(message.index)
```

HMS通过控制消息来实现消息的更新撤回，控制消息是一个特殊的消息，详见上问。

更新一条已发送的消息：

```kotlin
hmsCore.updateMessage(
    message.index,
    newType,
    newText,
    newPayload
)
```

详见Doc

## 消息展示

作为通信模块，业务侧一定会有需求展示一个会话的消息列表，HMS提供了一个封装层次高，能力非常强大的实现。
使用者通过 `HmsCore.createMessageListLogic` 创建一个`HMSMessageListLogic`的实例。该列表逻辑会自动监听任何的消息变化，插入，删除，并自动更新数据，然后通过 [HMSListUpdateCallback] 通知到业务层数据变化。
使用者可以通过此类配合 RecyclerView 迅速实现一个列表页面，

## 消息推送 PUSH

HMS目前依赖WNS提供消息通道，因此Push也是通过WNS实现。

后台再发送push时会根据客户端状态发送在线、离线push。客户端在前且处于前台（WNS前台状态），则发送在线push；否则发送离线push。

### 1. 在线push

HMS的在线push依托WNS，业务侧在收到WNS的push时，调用 `HMSWNSNetworkTransfer.onReceiverPush`，HMS内部会判断该push是否属于HMS，如果是则内部处理并返回true；
否则直接返回false。

### 2. 离线push
若要使用离线push能力，业务侧首先要注册WNS的离线push token，详见WNS的文档。

HMS后台发送的离线push有固定格式：
1. title：
2. content：
3. scheme：

这里重点介绍一下scheme。scheme的格式约定如下
```kotlin
"hms" + appid + "://hms/push?sid=" + sessionId
```
如appid是1000580，sessionId是G_101，则scheme是 `hms1000580://hms/push?sid=G_101`.
业务侧需要修改Manifest使得app能够处理该scheme，scheme带有sid参数，表示该消息属于哪一个会话，业务侧可以借助该uid实现直接打开会话页。

此外HMS提供了两个辅助方法，`makeSchemeUri`, `parseSchemeUri`；如果使用Java调用，上述两个方法在 `HMSCommon` 类中。
具体请参看方法kotlin-doc。

PS（坑）：WNS Android侧的push有bug，当app处于后台，WNS状态在线的时候，WNS后台会发一个在线的push（正常应该发离线push），push内容确是离线push的（title，content，scheme）。为了规避这个bug，业务侧也需要处理WNS的通知push。 

### 3. 新消息通知

HMS在线收到新消息时有一个回调接口供业务侧做自己的处理逻辑，如发通知等。该接口是 `HMSCore.setNewMessageListener`。详见kotlin-doc

## 会话逻辑

### 初始化：

HMS初始化的时候会先调用session的初始化逻辑，session初始化分一下几步：
1. 读取本地已存在的所有session id和对应的max sequence，与服务端进行同步，拉取差量session list 信息
2. 将服务端返回的最新session list差量信息落地到db，相应的message user userInSession信息都会依次落地
3. 当差量session list 信息超过服务端承载能力时候，服务端会返回session ids,客户端使用ids进行分片拉取

### session list 轮询

session list 的轮询逻辑的触发条件是：
1. 十分钟内没有收到新的消息
2. 用户进行从后台切换到前台
3. 从无网络状态

三个条件的逻辑关系是: 1 && (2 || 3)

通过初试化逻辑 + 轮询逻辑 + 消息(Notify + Notify Data) 最终保证消息的实时抵达

### session info的更新

1. session info更新的触发条件如下：
2. 回包的message.sequence 大于对应session的max_sequence
3. 回包的message.sender是当前用户，会更新session的local_read_sequence
4. 回包的message.sid在本地没有对应的session，会从server拉取相应的session
5. 业务删除session对应的最新一条消息
6. 业务更新，删除session中的字段

## 会话API

### HMSCore.createSession(type,users,sessionName,avatar,businessBuffer,callback)

创建会话：
. type是会话类型，目前有C2C,Group,ChatRoom三种，定义在HMSSession.Type中
. users是群聊会话需要加入的uid列表
. sessionName是会话名称，HMS不对C2C,Group和ChatRoom的sessionName做特殊处理（比如业务需要C2C显示对方名称，可自行处理)
. avatar是会话头像，HMS不做特殊逻辑，交给业务来做(比如根据群员生成九宫图片等逻辑需要业务自己做)
. businessBuffer是会话自定义数据，传入类型是业务自定义类型，
通过实现HMSSerializer中的serializeSessionBusinessBuffer和deserializeSessionBusinessBuffer来进行序列化和反序列化 

### createSessionListLogic(sessionFilter,sessionComparator)

获得一个完整的会话列表，用于业务侧实现一个会话列表页面
该列表逻辑会自动监听任何的session变化，插入，删除，并自动更新数据，然后通过 [HMSListUpdateCallback] 通知到业务层数据变化。
. sessionFilter  用于业务侧过滤掉不需要的会话
. sessionComparator 用于业务侧实现自定义的排序规则(默认排序规则是按照session更新时间倒序排列)
   
### HMSCore.getSessionObservableData

获得单个session 信息，以 [HMSObservableData] 的形式返回，上层可通过监听随时获知session数据更新


### HMSCore.getSessionListBySid

通过session ids批量获得session相关信息:
. sessionIds: session id的列表
. Count :是否带上未读数信息
. withMsg :是否有最新一条消息


### HMSCore.deleteSession

删除会话：
只会在本地进行会话的删除，当收到新的消息后仍然会出现在session list 中,如需退出会话，使用 [quitSession]

### HMSCore.disableStorage(sessionIds)

禁用消息的本地存储，设置单次有效，重新进入session后需要再次设置
sessionIds:需要禁用本地存储的session list 列表

### HMSCore.quitSession(sessionId)

从群组中退出,退出会清理所有session ,message相关信息，未来也不会再收到此session的消息，除非重新进入

### HMSCore.destroySession(sessionId)

解散群,只有群主有此功能

### HMSCore.setSessionRead(sessionId)

标记会话已读，更新未读计数

### HMSCore.updateSessionExtension

设置会话的自定义字段段,extension 为null是会清空存储，extension字段只做本地存储，不做服务端同步


### HMSCore.addUserToSession(sessionId,uids)

往群组中加人，可批量

### HMSCore.transferSessionOwner(sessionId,toUid)

转让群主，只有群主可以调用:
toUid:将群主转给此人

### HMSCore.deleteSessionMember(sessionId,uids)

批量T除群组中成员

### HMSCore.updateSessionInfo(sessionId,name,avatar,businessbuffer)

更新session info中name, avatar, businessBuffer 三个字段中的任意几个,不需要更新的字段使用ANY_PLACEHOLDER占位

### HMSCore.updateRoleInSession(sessionId,uid,role)

设置Session成员的权限，role权限定义在[HMSUserRole]中


### HMSCore.updateSessionBannedStatus(sessionId,uid,duringTimeOfBan)

设置Session成员禁言，duringTimeOfBan为禁言时长，单位为ms，0表示取消禁言


### HMSCore.getBlackList

获取黑名单

### HMSCore.addToBlackList（toUid）

将toUid加入黑名单，加入黑名单之后将无法收到此人的消息

### HMSCore.removeFromBlackList（toUid）

将toUid移除黑名单


## 用户资料 

用户资料分为[HMSUser]和[HMSUserInSession]两部分：
. 其中[HMSUser]描述的是用户本身的信息（如名称头像等)
. [HMSUserInSession]包含了用户在session中的信息(如session名片，session权限，禁言到期时间等)
. 在HMS中既可以直接使用[HMSUser]和[HMSUserInSession]，也可以使用封装类[HMSMemberInfo]

用户资料的来源和有效性：
. 拉取session和message数据时每条消息自带的用户相关信息：这里的用户信息会进行本地缓存，因此可能存在滞后性
. 业务直接通过getSessionMemberList和getUsersMemberInfo拉取到的用户相关信息：这里的用户信息都是从服务端即时拉取，没有滞后性


## 用户资料API

### HMSCore.getUsers(uids:List)

获得用户资料,优先从本地获取，不足的从服务端补齐； 因此可能存在信息滞后性

### HMSCore.updateUserInfo(uid,name,avatar,businessbuffer)

修改用户资料,name, avatar, businessBuffer 三个字段可以任意更新其中几个,不需要更新的字段可以使用 [STRING_PLACEHOLDER], [ANY_PLACEHOLDER] 占位

### HMSCore.getUserObservableData(uid,getFromServer)

获得基本用户资料，以 [HMSObservableData] 的形式返回，方便上层监听数据更新
getFromServer:true的情况下优先从服务端获取最新资料，适用于有网络且对资料有实时要求的场景（如权限）,false的情况可能有资料滞后的情况，适用于非敏感信息的场景(如名称，头像)


### HMSCore.getUserMemberInfoObservableData(uid,getFromServer)

获得用户MemberInfo 资料，以 [HMSObservableData] 的形式返回，方便上层监听数据更新
getFromServer:true的情况下优先从服务端获取最新资料，适用于有网络且对资料有实时要求的场景（如权限）,false的情况可能有资料滞后的情况，适用于非敏感信息的场景(如名称，头像)

### HMSCore.getUsersMemberInfo（sessionId,uids）

批量获得用户MemberInfo资料，直接从服务端实时获取

### HMSCore.getSessionMemberList

获得所有群成员资料，直接从服务端实时获取

### HMSCore.updaterUserInSession

更新群资料：remark, businessBuffer 字段可以任意更新其中几个，对于不需要更新的字段可以使用 [STRING_PLACEHOLDER], [ANY_PLACEHOLDER] 占位

# Package com.tencent.hms

主 package，核心类是 [HMSCore]

# Package com.tencent.hms.internal

内部实现，业务无需关心



