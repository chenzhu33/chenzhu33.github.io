@file:JvmName("HMSObservableDataUtils")

package com.tencent.hms.extension.livedata

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.tencent.hms.HMSObservableData

/*
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2019-03-01
 * Time:   15:35
 * Life with Passion, Code with Creativity.
 * </pre>
 */


/**
 * 提供了`ext-liveData`扩展，增加`HMSObservableData.liveData`扩展属性, (Java代码可以使用 `HMSObservableDataUtils.asLive
 * Data()` 接口。
 *
 * 用于将 [HMSObservableData] 转换成等价的 [LiveData]
 *
 * @see HMSObservableData
 */
@get:JvmName("asLiveData")
val <T : Any> HMSObservableData<T>.liveData: LiveData<T>
    get() {
        if (this.`interal-use-only-ext-LiveData` == null) {
            this.`interal-use-only-ext-LiveData` = object : MutableLiveData<T>() {

                private val listener: (T?) -> Unit = {
                    value = it
                }

                override fun onActive() {
                    this@liveData.observe(listener)
                }

                override fun onInactive() {
                    this@liveData.removeObserver(listener)
                }
            }
        }

        @Suppress("UNCHECKED_CAST")
        return this.`interal-use-only-ext-LiveData` as LiveData<T>
    }