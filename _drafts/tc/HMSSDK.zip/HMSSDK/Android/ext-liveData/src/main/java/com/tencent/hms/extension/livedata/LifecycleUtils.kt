@file:JvmName("LifecycleUtils")
package com.tencent.hms.extension.livedata

import androidx.lifecycle.GenericLifecycleObserver
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import com.tencent.hms.HMSDisposable
import java.lang.ref.WeakReference

/**
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2019-03-06
 * Time:   14:35
 * Life with Passion, Code with Creativity.
 * </pre>
 */

/**
 * 将一个 [HMSDisposable] 绑定到 [LifecycleOwner]， 当 [LifecycleOwner] destroy 的时候自动 [HMSDisposable.dispose]
 */
fun HMSDisposable.attachToLifecycle(lifecycleOwner: LifecycleOwner) = this.apply {
    val self = WeakReference(this)

    lifecycleOwner.lifecycle.addObserver(GenericLifecycleObserver { _, event ->
        if (event == Lifecycle.Event.ON_DESTROY) {
            self.get()?.dispose()
        }
    })
}
