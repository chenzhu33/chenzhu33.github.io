package com.tencent.hms.sample.impl

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.Person
import androidx.core.graphics.drawable.IconCompat
import com.tencent.hms.HMSCore
import com.tencent.hms.HMSNewMessageListener
import com.tencent.hms.makeSchemeUri
import com.tencent.hms.sample.*

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-02-19
 * Time:   15:52
 * Life with Passion, Code with Creativity.
 * ```
 */

class NewMessageListener(private val context: Context) {

    fun setNewMessageListener(hmsCore: HMSCore) {
        hmsCore.setNewMessageListener(object : HMSNewMessageListener {
            override fun onNewMessage(list: List<HMSNewMessageListener.NewMessages>) {
                // send notification
                list.forEach { new ->
                    SampleApplication.instance.notificationManager.notify(
                        "im-notify-" + new.sessionId,
                        System.currentTimeMillis().toInt(),
                        NotificationCompat.Builder(
                            context,
                            IM_CHANNEL
                        ).setStyle(
                            NotificationCompat.MessagingStyle(
                                Person.Builder()
                                    .setName("小道NML")
                                    .setKey(new.sessionId)
                                    .setIcon(
                                        IconCompat.createWithResource(
                                            context,
                                            R.drawable.user_avatar_default
                                        )
                                    ).build()
                            ).also { style ->
                                new.messages.forEach { message ->
                                    style.addMessage(
                                        explainMessage(message), message.timestamp,
                                        Person.Builder()
                                            .setName("小道")
                                            .setKey(new.sessionId)
                                            .setIcon(
                                                IconCompat.createWithResource(
                                                    context,
                                                    R.drawable.user_avatar_default
                                                )
                                            ).build()
                                    )
                                }
                            }
                        ).setSmallIcon(R.drawable.ic_launcher)
                            .setContentIntent(
                                PendingIntent.getActivity(
                                    context, new.sessionId.hashCode(),
                                    Intent(
                                        Intent.ACTION_VIEW,
                                        Uri.parse(makeSchemeUri(HMS_APPID, new.sessionId))
                                    ).apply { setPackage(context.packageName) },
                                    PendingIntent.FLAG_UPDATE_CURRENT
                                )
                            )
                            .setDefaults(NotificationCompat.DEFAULT_SOUND)
                            .build()
                    )
                }
            }
        })
    }

}