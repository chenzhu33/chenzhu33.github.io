package com.tencent.hms.sample.fragment

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tencent.hms.HMSCore
import com.tencent.hms.HMSDisposableCallback
import com.tencent.hms.HMSResult
import com.tencent.hms.profile.HMSUserRole
import com.tencent.hms.sample.MainActivity
import com.tencent.hms.sample.R
import com.tencent.hms.sample.debug.DebugDialogManager
import com.tencent.hms.session.HMSSession
import java.text.SimpleDateFormat
import java.util.*


/**
 * Created by juliandai on 2019/2/21 1:50 PM.
 * talk and show the code
 */
class SessionMemberListFragment : MainActivity.BaseFragment() {

    private val args: SessionMemberListFragmentArgs by navArgs()
    private var adapter: ProfileAdapter? = null
    private val debugDialog: DebugDialogManager by lazy {
        DebugDialogManager(activity!!, activity!!.hmsCore)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.activity_session, container, false)
        val recyclerView = view.findViewById<RecyclerView>(R.id.session_list_recyclerview)

        adapter = ProfileAdapter(activity!!, {
            if (it.isC2C) {
                hmsCore.value?.createSession(HMSSession.Type.C2C, listOf(it.uid),sessionName = "Session From Group", callback = HMSDisposableCallback {
                    when (it) {
                        is HMSResult.Success -> {
                            (activity as AppCompatActivity as MainActivity).navController.navigate(
                                SessionMemberListFragmentDirections.actionSessionMemberListFragmentToChatFragment(it.data.sid)
                            )
                        }
                    }
                })
            } else {
                (activity as AppCompatActivity as MainActivity).navController.navigate(
                    SessionMemberListFragmentDirections.actionSessionMemberListFragmentToChatFragment(it.sid)
                )
            }
        }, { popView, profile ->
            debugDialog.showPopupForAdmin(popView, profile) {
                getDataAgain()
            }
        })
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        setHasOptionsMenu(true)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        hmsCore.observe(viewLifecycleOwner, Observer {
            getMemberList(it)

            it.getSessionListBySid(
                listOf(args.sessionId),
                callback = HMSDisposableCallback {
                when (it) {
                    is HMSResult.Success -> {
                        val session = it.data.firstOrNull()
                        activity?.title = "群名:${session?.name}"
                    }
                }
            })
        })
    }

    fun getMemberList(hms: HMSCore) {
        hms.getSessionMemberList(args.sessionId, HMSDisposableCallback {
            when (it) {
                is HMSResult.Success -> {
                    val data = it.data.map {
                        val titlePrefix = when (it.userInSession!!.role) {
                            HMSUserRole.NORMAL -> "群员"
                            HMSUserRole.ADMINISTRATOR -> "管理员"
                            HMSUserRole.OWNER -> "群主"
                            else -> "群员"
                        }
                        val profile = Profile(
                            sid = args.sessionId,
                            name = it.user.name ?: it.user.uid,
                            avatar = it.user.avatar,
                            uid = it.user.uid
                        )
                        val remark = if (it.userInSession!!.remark == null) "" else " [备注：${it.userInSession!!.remark}]"

                        val dateFormat = SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
                        val expireTime = dateFormat.format(Date(it.userInSession!!.banExpireTime))
                        val banTips =
                            if (it.userInSession?.banExpireTime ?: 0 > 0) "(禁言到${expireTime}截止)" else ""
                        profile.showText = "${titlePrefix}-${profile.name}(${profile.uid})${remark}${banTips}"
                        profile
                    }
                    adapter?.setData(data)
                    adapter?.notifyDataSetChanged()
                }
                is HMSResult.Fail -> {
                    Toast.makeText(activity, "拉取群成员列表失败", Toast.LENGTH_LONG).show()
                }
            }
        })
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        debugMenuManager.createSessionManagerMenuOption(inflater, menu)
        return super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        debugMenuManager.dispatchOptionSelect(item, args.sessionId) {
            getDataAgain()
        }
        return super.onOptionsItemSelected(item)
    }

    fun getDataAgain() {
        hmsCore.value?.let {
            getMemberList(it)
        }
    }
}


