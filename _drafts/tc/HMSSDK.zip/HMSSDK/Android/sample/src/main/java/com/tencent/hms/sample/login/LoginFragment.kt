package com.tencent.hms.sample.login

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.ProgressBar
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.tencent.connect.common.Constants
import com.tencent.hms.HMSCore
import com.tencent.hms.HMSDisposableCallback
import com.tencent.hms.HMSResult
import com.tencent.hms.sample.HmsManager
import com.tencent.hms.sample.MainActivity
import com.tencent.hms.sample.R
import com.tencent.hms.sample.WnsHelper

class LoginFragment : MainActivity.BaseFragment(), LoginCallback {

    companion object {
        private val TAG = "LOGIN FRAGMENT"
    }

    private val REGISTER_REQUEST_CODE = 0

    private val loginManager by lazy {
        LoginManager(context!!, this@LoginFragment)
    }

    private lateinit var loginLoadingBarView: ProgressBar
    private lateinit var loginQQ: View
    private lateinit var loginAnonumous: View
    private lateinit var loginTip: View

    private var loading: Boolean = false
        set(value) {
            field = value
            if (value) {
                loginLoadingBarView.visibility = View.VISIBLE
                loginTip.visibility = View.VISIBLE
                loginQQ.visibility = View.INVISIBLE
                loginAnonumous.visibility = View.INVISIBLE
            } else {
                loginLoadingBarView.visibility = View.GONE
                loginTip.visibility = View.GONE
                loginQQ.visibility = View.VISIBLE
                loginAnonumous.visibility = View.VISIBLE
                activity?.title = "登录"
            }
        }

    private var navup = MutableLiveData<Boolean>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
        navup.observe(this, Observer {
            if (it) {
                navController.navigateUp()
            }
        })
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        activity?.title = "登录"
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.activity_login, container, false).apply {
            loginAnonumous = findViewById<View>(R.id.anonymous_tour)
            loginAnonumous.setOnClickListener {
                loginManager.loginAnonymous()
            }

            loginQQ = findViewById<View>(R.id.login_qq)
            loginQQ.setOnClickListener {
                loginManager.login(this@LoginFragment)
            }
            loginLoadingBarView = findViewById(R.id.login_loading_bar)
            loginTip = findViewById(R.id.login_tip)

            isFocusableInTouchMode = true
            requestFocus()
            setOnKeyListener { _, keyCode, _ ->
                // swallow back action
                keyCode == KeyEvent.KEYCODE_BACK
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loginManager.autoLogin()
    }

    override fun onResume() {
        super.onResume()
        view?.requestFocus()
    }

    override fun onLoginStart() {
        loading = true
    }


    override fun onLoginFailed(code: Int, msg: String) {
        if (code == -1) {
            Toast.makeText(activity, "登录失败", Toast.LENGTH_SHORT).show()
        }
        loading = false
    }

    override fun onLoginSuccess(openId: String) {
        HmsManager.initHmsCore(context!!, openId, HMSDisposableCallback {
            when (it) {
                is HMSResult.Success -> {
                    Toast.makeText(
                        activity!!,
                        "login succes uid:${WnsHelper.uid}",
                        Toast.LENGTH_LONG
                    ).show()
                    loading = false
                    jumpToSessionPage(it.data)
                }
                is HMSResult.Fail -> {
                    loading = false
                    Toast.makeText(activity, "HMS 服务初始化失败, ${it.error.message}", Toast.LENGTH_LONG).show()
                    Log.e(TAG, "HMS login failed", it.error)
                }
            }
        })
    }


    private fun jumpToSessionPage(hmsCore: HMSCore) {
        activity?.onGetHMSCore(hmsCore)
        navup.value = true
   }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REGISTER_REQUEST_CODE -> if (resultCode == Activity.RESULT_OK) {
                jumpToSessionPage(hmsCore.value!!)
            } else if (resultCode == Activity.RESULT_CANCELED) {
                Toast.makeText(activity, "取消登录", Toast.LENGTH_SHORT).show()
            }

            Constants.REQUEST_LOGIN ->
                // QQ auth hack.
                if (resultCode == Constants.ACTIVITY_OK || resultCode == Constants.REQUEST_APPBAR) {
                    loginManager.dispatchAuthResult(requestCode, resultCode, data!!)
                }
        }
    }
}

interface LoginCallback {
    fun onLoginSuccess(openId: String)
    fun onLoginFailed(code: Int, msg: String)
    fun onLoginStart()
}

