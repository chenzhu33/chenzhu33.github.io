package com.tencent.hms.sample.fragment

import android.app.Activity
import android.graphics.Rect
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tencent.hms.*
import com.tencent.hms.sample.MainActivity
import com.tencent.hms.sample.MainFragmentDirections
import com.tencent.hms.sample.R
import com.tencent.hms.sample.debug.DefaultAvatar
import com.tencent.hms.sample.explainMessage
import com.tencent.hms.session.HMSMessageAlertType
import com.tencent.hms.session.HMSSession
import com.tencent.hms.session.HMSSessionListLogic
import kotlinx.coroutines.launch

/**
 * Created by juliandai on 2019/2/18 4:28 PM.
 * talk and show the code
 */
class SessionFragment : MainActivity.BaseFragment() {

    private var adapter: SessionAdapter? = null

    private var sessionListService: HMSSessionListLogic? = null
    private lateinit var recyclerView: RecyclerView

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val rootView = inflater.inflate(R.layout.activity_session, container, false)
        recyclerView = rootView.findViewById(R.id.session_list_recyclerview)
        recyclerView.layoutManager = LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        recyclerView.addItemDecoration(ItemDec())
        return rootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        hmsCore.observe(viewLifecycleOwner, Observer {
            if (sessionListService == null) {
                sessionListService = it.createSessionListLogic()
            }
            if (adapter == null) {
                adapter = SessionAdapter(activity!!, sessionListService!!, it)
            }
            recyclerView.adapter = adapter
            sessionListService?.setUpdateCallback(adapter)
            adapter?.notifyDataSetChanged()
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        sessionListService?.dispose()
    }

    inner class SessionAdapter(val activity: Activity, val datasource: HMSSessionListLogic, val hmsCore: HMSCore) :
        RecyclerView.Adapter<SessionViewHolder>(),
        HMSListUpdateCallback {

        override fun onInserted(position: Int, count: Int) {
            notifyItemRangeInserted(position, count)
        }

        override fun onRemoved(position: Int, count: Int) {
            notifyItemRangeRemoved(position, count)
        }

        override fun onChanged(position: Int, count: Int) {
            notifyItemRangeChanged(position, count)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SessionViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.im_session_item_layout, parent, false)
            return SessionViewHolder(activity, view, hmsCore)
        }

        override fun getItemCount(): Int {
            return datasource.size
        }

        override fun onBindViewHolder(holder: SessionViewHolder, position: Int) {
            val data = datasource[position]
            holder.bind(data)

            if (data.type == HMSSession.Type.C2C) {
                hmsCore.getUsers(listOf(data.toUid!!), HMSDisposableCallback {
                    when (it) {
                        is HMSResult.Success -> {
                            it.data.firstOrNull {
                                val name = if (it.remark.isNullOrEmpty()) it.name else it.remark
                                holder.changeNameAndAvatar(name ?: "", it.avatar, data.sid)
                                true
                            }
                        }
                    }
                })
            }
        }
    }


    inner class SessionViewHolder(
        val activity: Activity,
        itemView: View,
        val hmsCore: HMSCore
    ) : RecyclerView.ViewHolder(itemView) {
        val content = itemView.findViewById<TextView>(R.id.message_tips)
        val username = itemView.findViewById<TextView>(R.id.user_name_text)
        val unReadText = itemView.findViewById<TextView>(R.id.unread_count_text)
        val avatarView = itemView.findViewById<ImageView>(R.id.my_avatar)

        val defaultAvatar = DefaultAvatar(activity)

        fun bind(data: HMSSession) {
            val message = data.lastMessage
            message?.let {
                content.text = explainMessage(it)
            }

            if (message == null) {
                content.text = ""
            }
            val unreadRemindSequences = data.unreadRemindSequences
            Log.i("icezheng", "bindData:${message?.sessionId}, unreadRemindSequences=${unreadRemindSequences}")

            if (data.unreadCount <= 0 && unreadRemindSequences?.isEmpty() != false) {
                unReadText.visibility = View.GONE
            } else {
                unReadText.text = data.unreadCount.toString() + "|@:" + unreadRemindSequences.toString()
                unReadText.visibility = View.VISIBLE
            }

            itemView.setOnClickListener {
                (activity as MainActivity).navController.navigate(
                    MainFragmentDirections.actionMainFragmentToChatFragment(data.sid)
                )
            }

            itemView.setOnLongClickListener {
                val options = arrayOf(
                    "删除服务器会话",
                    "删除服务器所有会话",
                    "删除本地会话"
                )

                AlertDialog.Builder(activity)
                    .setTitle("选择动作")
                    .setItems(options) { dialog, which ->
                        coroutineScope.launch {
                            try {
                                when (which) {
                                    0 -> hmsCore.deleteSession(data.sid)
                                    1 -> hmsCore.deleteSessionMessages(data.sid)
                                    2 -> hmsCore.deleteLocalSession(data.sid)
                                }
                            } catch (e: HMSException) {
                                Toast.makeText(activity, "${options[which]}失败 ${e.message}", Toast.LENGTH_SHORT)
                                    .show()

                            }
                        }
                        dialog.dismiss()
                    }.show()
                true
            }

            defaultAvatar.setSessionAvatar(data.avatarUrl, data.sid, avatarView)
            val sb = StringBuilder()
            sb.append(if (data.name.isEmpty()) "sid:${data.sid}" else "${data.name}(sid:${data.sid})")
            if (data.type == HMSSession.Type.GROUP) sb.append("[G]")
            if (data.isDestroy) sb.append("[D]")
            if (data.messageAlertType == HMSMessageAlertType.DoNotDisturb) sb.append("[M]")

            username.text = sb.toString()
        }

        fun changeNameAndAvatar(name: String?, avatar: String?, sid: String) {
            if (!name.isNullOrEmpty()) {
                username.text = name
            }
            defaultAvatar.setSessionAvatar(avatar, sid, avatarView)
        }
    }

    class ItemDec : RecyclerView.ItemDecoration() {
        override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
            outRect.set(10, 10, 10, 0)
            super.getItemOffsets(outRect, view, parent, state)
        }
    }
}

