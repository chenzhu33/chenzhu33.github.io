package com.tencent.hms.sample.chat

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.*
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.ContentLoadingProgressBar
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.Transformations
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com.tencent.hms.*
import com.tencent.hms.extension.livedata.liveData
import com.tencent.hms.message.HMSMessage
import com.tencent.hms.message.HMSMessageListLogic
import com.tencent.hms.message.HMSPlainMessage
import com.tencent.hms.sample.MainActivity
import com.tencent.hms.sample.R
import com.tencent.hms.session.HMSSession
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*


/**
 * Created by juliandai on 2019/1/14 9:51 AM.
 * talk and show the code
 */
class ChatFragment : MainActivity.BaseFragment(), View.OnClickListener {
    companion object {
        private const val TAG = "ChatActivity"
    }

    private val args: ChatFragmentArgs by navArgs()

    private var mSendBtn: TextView? = null
    private var mEditText: EditText? = null

    private var mRecyclerView: RecyclerView? = null
    private lateinit var loadingView: ContentLoadingProgressBar
    private var mStatusBarBgView: View? = null
    private var mAdapter: ChatItemAdapter? = null
    private var mLinearLayoutManager: LinearLayoutManager? = null
    private lateinit var scrollDownView: View
    private var followMineNewMessage = false

    private lateinit var messageService: LiveData<HMSMessageListLogic>
    private val isInBlack: MutableLiveData<Boolean> = MutableLiveData()
    private var hmsSession: HMSSession? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
        try {
            args.sessionId
        } catch (e: IllegalArgumentException) {
            // wrong arguments
            navController.navigateUp()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.activity_chat, container, false)
        initView(view)
        return view
    }

    override fun onPause() {
        super.onPause()
        hmsCore.value?.setSessionRead(args.sessionId, HMSDisposableCallback {  })
    }


    override fun onDestroy() {
        super.onDestroy()
        messageService.value?.dispose()
    }

    private fun initView(root: View) = root.apply {
        mStatusBarBgView = findViewById(R.id.status_bar_bg)
        mSendBtn = findViewById(R.id.btn_send_msg)
        mEditText = findViewById(R.id.text_input)
        mRecyclerView = findViewById(R.id.recyclerview)
        scrollDownView = findViewById(R.id.scroll_to_bottom)

        mSendBtn?.setOnClickListener(this@ChatFragment)
        mSendBtn?.setOnLongClickListener {
            sendMessage(true)
            true
        }

        scrollDownView.setOnClickListener { scrollMsgToBottom() }
        scrollDownView.setOnLongClickListener {
            messageService.value?.also { it.reload() } != null
        }

        mLinearLayoutManager = LinearLayoutManager(context, RecyclerView.VERTICAL, true)
        mRecyclerView?.layoutManager = mLinearLayoutManager
        loadingView = findViewById(R.id.loading)

        changeSendBtnColor()
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        hmsCore.observe(viewLifecycleOwner, Observer {
            it.getSessionObservableData(args.sessionId).liveData.observe(viewLifecycleOwner, Observer {
                updateSessionInfo(it)
            })
        })

        messageService = Transformations.map(hmsCore) {
            it.createMessageListLogic(args.sessionId)
        }

        messageService.observe(this@ChatFragment, Observer {
            mAdapter = ChatItemAdapter(
                it, ::messageLongClickPrompt, ::onErrorTipClick
            )

            it.historyMessageLoadStatus.liveData.observe(viewLifecycleOwner, Observer { status ->
                if (status is HMSMessageListLogic.LoadStatus.LOADING) {
                    loadingView.show()
                } else {
                    loadingView.hide()
                }
                Log.i(TAG, "historyMessageLoadStatus $status")
            })

            it.newMessageLoadStatus.liveData.observe(viewLifecycleOwner, Observer {
                if (it is HMSMessageListLogic.LoadStatus.FAILED) {
                    Toast.makeText(context, "Load newMessage Failed ${it.error.message}", Toast.LENGTH_SHORT).show()
                }
                Log.i(TAG, "newMessageLoadStatus $it")
            })

            it.hasDiscontinuousNewMessages.liveData.observe(viewLifecycleOwner, Observer {
                if (it) {
                    Toast.makeText(context, "新消息空洞产生！", Toast.LENGTH_SHORT).show()
                }
            })

            mAdapter!!.registerAdapterDataObserver(object : RecyclerView.AdapterDataObserver() {
                override fun onChanged() {
                    super.onChanged()
                    Log.i(TAG, "onChanged")
                }

                override fun onItemRangeRemoved(positionStart: Int, itemCount: Int) {
                    super.onItemRangeRemoved(positionStart, itemCount)
                    Log.i(TAG, "onItemRangeRemoved $positionStart $itemCount")
                }

                override fun onItemRangeMoved(fromPosition: Int, toPosition: Int, itemCount: Int) {
                    super.onItemRangeMoved(fromPosition, toPosition, itemCount)

                    Log.i(TAG, "onItemRangeMoved $fromPosition $toPosition $itemCount")
                }

                override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {
                    super.onItemRangeInserted(positionStart, itemCount)
                    Log.i(TAG, "onItemRangeInserted $positionStart $itemCount")
                    if (followMineNewMessage || mLinearLayoutManager?.findFirstCompletelyVisibleItemPosition() == 0) {
                        followMineNewMessage = false
                        scrollMsgToBottom()
                    }
                }

                override fun onItemRangeChanged(positionStart: Int, itemCount: Int) {
                    super.onItemRangeChanged(positionStart, itemCount)
                    Log.i(TAG, "onItemRangeChanged $positionStart $itemCount")
                }

                override fun onItemRangeChanged(positionStart: Int, itemCount: Int, payload: Any?) {
                    super.onItemRangeChanged(positionStart, itemCount, payload)
                    Log.i(TAG, "onItemRangeChanged $positionStart $itemCount")
                }
            })
            mRecyclerView?.adapter = mAdapter
        })

        mRecyclerView?.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                val pos = mLinearLayoutManager?.findFirstVisibleItemPosition()
                if (pos == 0) {
                    scrollDownView.visibility = View.INVISIBLE
                } else {
                    scrollDownView.visibility = View.VISIBLE
                }
            }
        })


        isInBlack.observe(this, Observer {
            activity?.invalidateOptionsMenu()
        })
    }

    private fun updateSessionInfo(session: HMSSession?) {
        session?.let {
            if (it.type == HMSSession.Type.GROUP) {
                activity?.title = it.name
            } else if (it.type == HMSSession.Type.C2C) {
                setC2CInfo(it.toUid!!)
            } else {
                activity?.title = it.name
            }
            hmsSession = it
        }
        activity?.invalidateOptionsMenu()
    }

    private fun onErrorTipClick(message: HMSMessage) {
        AlertDialog.Builder(activity!!)
            .setTitle("重发消息 ${message.text} ?")
            .setPositiveButton("删除&重发") { dialog, _ ->
                dialog.dismiss()
                hmsCore.value!!.deleteAndResendLocalMessage(
                    message.index, callback = HMSDisposableCallback { hmsResult ->
                        if (hmsResult is HMSResult.Fail) {
                            hmsResult.error
                            Snackbar.make(
                                mSendBtn!!,
                                "sendMessageFailed ${hmsResult.error.message}",
                                Snackbar.LENGTH_SHORT
                            ).show()
                        }
                    })
            }
            .setNeutralButton("原地重发") { dialog, _ ->
                dialog.dismiss()
                hmsCore.value!!.sendLocalMessage(
                    message.index, true, HMSDisposableCallback { hmsResult ->
                    if (hmsResult is HMSResult.Fail) {
                        hmsResult.error
                        Snackbar.make(
                            mSendBtn!!,
                            "sendMessageFailed ${hmsResult.error.message}",
                            Snackbar.LENGTH_SHORT
                        ).show()
                    }
                })

            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .create()
            .show()
    }

    private fun setC2CInfo(toUid: String) {
        hmsCore.value?.getUsers(listOf(toUid), HMSDisposableCallback {
            when (it) {
                is HMSResult.Success -> {
                    val user = it.data.firstOrNull()
                    user?.let {
                        activity?.title = user.name
                    }
                }
            }
        })

        hmsCore.value?.getBlackList(HMSDisposableCallback {
            when (it) {
                is HMSResult.Success -> {
                    isInBlack.value = it.data.contains(toUid)
                }
            }
        })
    }


    private fun messageLongClickPrompt(message: HMSMessage) {
        AlertDialog.Builder(activity!!)
            .setTitle("选择动作")
            .setItems(
                arrayOf(
                    "删除消息",
                    "撤回消息",
                    "更新消息",
                    "更新本地消息",
                    "发送本地消息"
                )
            ) { dialog, which ->
                when (which) {
                    0 -> deleteMessagePrompt(message)
                    1 -> revokeMessagePrompt(message)
                    2 -> updateMessagePrompt(message)
                    3 -> updateLocalMessagePrompt(message)
                    4 -> sendLocalMessagePrompt(message)
                }
                dialog.dismiss()
            }
            .show()
    }

    private fun deleteMessagePrompt(message: HMSMessage) {
        coroutineScope.launch {
            try {
                hmsCore.value!!.deleteLocalMessage(message.index)
            } catch (e: HMSException) {
                Snackbar.make(
                    mSendBtn!!,
                    "sendMessageFailed ${e.message}",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun revokeMessagePrompt(message: HMSMessage) {
        coroutineScope.launch {
            val success = try {
                hmsCore.value!!.revokeMessage(message.index)
                true
            } catch (e: HMSException) {
                false
            }
            Snackbar.make(
                mSendBtn!!,
                if (success) {
                    "撤回成功"
                } else {
                    "撤回失败"
                },
                Snackbar.LENGTH_SHORT
            ).show()
        }
    }

    private fun updateMessagePrompt(message: HMSMessage) {
        coroutineScope.launch {
            val success = try {
                hmsCore.value!!.updateMessage(
                    message.index,
                    (message as HMSPlainMessage).type,
                    message.text + "->up",
                    message.payload
                )
                true
            } catch (e: HMSException) {
                false
            }
            Snackbar.make(
                mSendBtn!!,
                if (success) {
                    "更新成功"
                } else {
                    "更新失败"
                },
                Snackbar.LENGTH_SHORT
            ).show()
        }
    }

    private fun updateLocalMessagePrompt(message: HMSMessage) {
        coroutineScope.launch {
            val success = try {
                hmsCore.value!!.updateLocalMessage(
                    message.index,
                    text =
                    message.text + "->up"
                )
                true
            } catch (e: HMSException) {
                false
            }
            Snackbar.make(
                mSendBtn!!,
                if (success) {
                    "更新成功"
                } else {
                    "更新失败"
                },
                Snackbar.LENGTH_SHORT
            ).show()
        }
    }

    private fun sendLocalMessagePrompt(message: HMSMessage) {
        coroutineScope.launch {
            val e = try {
                hmsCore.value!!.sendLocalMessage(message.index)
                null
            } catch (e: HMSException) {
                e
            }
            Snackbar.make(
                mSendBtn!!,
                if (e == null) {
                    "sendLocalMessage成功"
                } else {
                    "sendLocalMessage失败 ${e.message}"
                },
                Snackbar.LENGTH_SHORT
            ).show()
        }
    }

    private fun changeSendBtnColor() {
        mEditText?.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {

            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                s?.let { str ->
                    mSendBtn?.let {
                        if (str.length > 0) {
                            // 有输入的时候，按钮高亮
                            it.setTextColor(resources.getColor(R.color.s4))
                            it.setBackground(resources.getDrawable(R.drawable.bg_btn_post_comment_editor))
                        } else if (str.length == 0) {
                            // 没有输入
                            it.setTextColor(resources.getColor(R.color.s7))
                            it.setBackground(resources.getDrawable(R.drawable.bg_btn_post_comment_editor_no_text))
                        }
                    }
                }
            }
        })

    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_send_msg -> sendMessage(false)
        }
    }

    private fun sendMessage(justAddToLocal: Boolean) {
        followMineNewMessage = true
        var text = mEditText?.text?.toString()
        if (text.isNullOrEmpty()) {
            text = "测试消息 ${SimpleDateFormat("yyyy年M月d日 HH:mm:ss.SSS", Locale.CHINA).format(Date())}"
        }

        mEditText?.setText("")
        args.sessionId.let { sid ->
            if (!justAddToLocal) {
                hmsCore.value?.sendMessage(
                    sid, 0, text, null,
                    "0payload_01210", emptyList(), null, callback = HMSDisposableCallback { hmsResult ->
                        when (hmsResult) {
                            is HMSResult.Success -> {
                                val data = hmsResult.data
                                Toast.makeText(activity, "发送成功", Toast.LENGTH_SHORT).show()
                            }
                            is HMSResult.Fail -> {
                                Toast.makeText(activity, "发送失败", Toast.LENGTH_SHORT).show()
                                Log.e(TAG, "send failed", hmsResult.error)
                            }
                        }
                    })
            } else {
                hmsCore.value?.addLocalMessage(
                    sid, 0, text, null,
                    "0payload_01210", emptyList(), null, HMSDisposableCallback { hmsResult ->
                        when (hmsResult) {
                            is HMSResult.Success -> {
                                val data = hmsResult.data
                                Toast.makeText(activity, "addLocalMessage成功", Toast.LENGTH_SHORT).show()
                            }
                            is HMSResult.Fail -> {
                                Toast.makeText(activity, "addLocalMessage失败", Toast.LENGTH_SHORT).show()
                                Log.e(TAG, "send failed", hmsResult.error)
                            }
                        }
                    })
            }
        }

    }

    private fun scrollMsgToBottom() {
        mLinearLayoutManager?.scrollToPosition(0)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        menu.clear()
        hmsSession?.let {
            if (it.type == HMSSession.Type.C2C) {
                debugMenuManager.createC2CMenuOption(inflater, menu, isInBlack.value ?: false)
            } else {
                debugMenuManager.createGroupChatMenuOption(inflater, menu)
            }
        }
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        debugMenuManager.dispatchOptionSelect(item, args.sessionId) {
            //update session callback
            hmsSession?.let {
                if (it.type == HMSSession.Type.C2C) setC2CInfo(it.toUid!!)
            }
        }
        return true
    }
}

