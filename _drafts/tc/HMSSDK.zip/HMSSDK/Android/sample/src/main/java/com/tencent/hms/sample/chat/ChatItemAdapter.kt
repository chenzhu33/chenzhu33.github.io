package com.tencent.hms.sample.chat

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.tencent.hms.HMSListUpdateCallback
import com.tencent.hms.message.HMSMessage
import com.tencent.hms.message.HMSMessageListLogic
import com.tencent.hms.message.HMSPlainMessage


class ChatItemAdapter(
    private val messageList: HMSMessageListLogic,
    val itemLongClickListener: (HMSMessage) -> Unit,
    val itemErrorTipClickListener: (HMSMessage) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    init {
        messageList.setUpdateCallback(object : HMSListUpdateCallback {
            override fun onInserted(position: Int, count: Int) {
                notifyItemRangeInserted(position, count)
            }

            override fun onRemoved(position: Int, count: Int) {
                notifyItemRangeRemoved(position, count)
            }

            override fun onChanged(position: Int, count: Int) {
                notifyItemRangeChanged(position, count)
            }
        })
    }

    override fun getItemCount(): Int {
        return messageList.size
    }


    override fun getItemViewType(position: Int): Int {
        val msg = messageList[position]
        return if (msg.isControlMessage || msg.isRevoked) {
            VIEW_TYPE_TIP
        } else {
            VIEW_TYPE_CHAT
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_CHAT -> ChatItemVH(parent.context, parent).also { item ->
                item.itemView.setOnLongClickListener {
                    itemLongClickListener(messageList[item.adapterPosition])
                    true
                }
                item.mRightStatus.setOnClickListener {
                    itemErrorTipClickListener(messageList[item.adapterPosition])
                }
            }
            VIEW_TYPE_TIP -> TipItemVH(parent.context, parent)
            else -> throw IllegalArgumentException("wrong type $viewType")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message: HMSMessage = messageList[position]
        when (holder) {
            is ChatItemVH -> holder.bind(message as HMSPlainMessage)
            is TipItemVH -> holder.bind(message)

        }
    }

    companion object {
        const val VIEW_TYPE_CHAT = 0
        const val VIEW_TYPE_TIP = 1
    }
}


