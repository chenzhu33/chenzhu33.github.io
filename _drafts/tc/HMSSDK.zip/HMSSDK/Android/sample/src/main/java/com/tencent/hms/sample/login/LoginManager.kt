package com.tencent.hms.sample.login

import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import com.tencent.hms.sample.WnsHelper
import com.tencent.hms.sample.getLongSp
import com.tencent.hms.sample.getSp
import com.tencent.hms.sample.saveSp
import com.tencent.tauth.IUiListener
import com.tencent.tauth.Tencent
import com.tencent.tauth.UiError
import com.tencent.wns.ipc.RemoteCallback
import com.tencent.wns.ipc.RemoteData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.json.JSONException
import org.json.JSONObject
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Created by juliandai on 2019/1/21 4:26 PM.
 * talk and show the code
 */
class LoginManager(val context: Context, val callback: LoginCallback) {
    private val job = Job()
    private val mainScope = CoroutineScope(job + Dispatchers.Main)
    private val workerScope = CoroutineScope(job + Dispatchers.IO)

    companion object {
        private const val QQAPPID = "1108146684"
        private const val SCOPE = "get_user_info"
        private const val OPENID_KEY = "openid"
        private const val ACCESS_TOKEN_KEY = "access_token"
        private const val EXPIRE_TIME_KEY = "expires_in"
        private const val WNS_UID = "wns_uid"
        private const val WNS_NAME = "wns_name"
        private const val WNS_LOCAL_LOGIN_TYPE = "wns_login_type"
        private const val TAG = "LOGIN MANAGER"


        fun logout(context: Context) {
            saveSp(context, WNS_NAME, "")
            saveSp(context, WNS_LOCAL_LOGIN_TYPE, 0L)
            saveSp(context, WNS_UID, "")

            WnsHelper.logout()
        }
    }

    private val mTencent by lazy {
        Tencent.createInstance(QQAPPID, context)
    }

    fun autoLogin() {
        Log.d(TAG, "start auto login")
        workerScope.launch {
            val result: Boolean = suspendCoroutine { continuation ->
                val uid = getSp(context, WNS_UID)
                val name = getSp(context, WNS_NAME)
                val type = getLongSp(context, WNS_LOCAL_LOGIN_TYPE).toInt()

                WnsHelper.wnsAuth(uid, name, type, continuation)
            }
            if (result) {
                mainScope.launch {
                    callback.onLoginSuccess(WnsHelper.uid!!)
                }
            } else {
                Log.d(TAG, "start auto failed")
            }
        }
    }

    fun login(fragment: LoginFragment) {
        workerScope.launch {
            mTencent.logout(context)
            mTencent.login(fragment, SCOPE, mAuthListener)
            mainScope.launch {
                callback.onLoginStart()
            }
        }


    }

    fun loginAnonymous() {
        callback.onLoginStart()
        mainScope.launch {
            val success = wnsLoginAnonymous()
            Toast.makeText(
                context,
                "login ${if (success) "success" else "failed"} uid:${WnsHelper.uid}",
                Toast.LENGTH_LONG
            ).show()

            if (success) {
                callback.onLoginSuccess(WnsHelper.uid!!)
            } else {
                callback.onLoginFailed(-1, "login failed")
            }
        }
    }


    fun dispatchAuthResult(requestCode: Int, resultCode: Int, data: Intent): Boolean {
        try {
            Tencent.onActivityResultData(requestCode, resultCode, data, mAuthListener)
            return true
        } catch (e: Throwable) {

        }
        return false
    }


    private val mAuthListener = object : IUiListener {
        override fun onError(uiError: UiError) {
            onAuthFailed(uiError.errorCode, uiError.errorMessage)
        }

        override fun onCancel() {
            Toast.makeText(context, "登录取消", Toast.LENGTH_SHORT).show()
        }

        override fun onComplete(arg: Any?) {
            if (arg != null && arg is JSONObject) {
                val jsonObject = arg as JSONObject?
                try {
                    val openId = jsonObject!!.getString(OPENID_KEY)
                    val token = jsonObject.getString(ACCESS_TOKEN_KEY)
                    val expiredTime = jsonObject.getLong(EXPIRE_TIME_KEY)
                    onAuthSucceed(openId, token, expiredTime)
                } catch (e: JSONException) {
                    onAuthFailed(-1, null)
                }
            } else {
                onAuthFailed(-1, null)
            }
        }

        //QQ登录成功，进入wns登录
        private fun onAuthSucceed(openId: String, token: String, expireTime: Long) {
            val client = WnsHelper.wnsClient
            client?.let {
                it.logoutExcept(openId, false, null)
                mainScope.launch {
                    Log.d(TAG, "start manual login QQ for WNS")
                    val success = wnsLoginQQ(openId, token, expireTime)
                    if (success) {
                        callback.onLoginSuccess(WnsHelper.uid!!)
                    } else {
                        callback.onLoginFailed(-1,"login failed")
                    }
                    Log.d(TAG, "wns login ${success}")
                }
            }
        }

        private fun onAuthFailed(errorCode: Int, errorMsg: String?) {
            callback.onLoginFailed(errorCode, errorMsg ?: "")
            Log.e(TAG, "QQ auth failed code $errorCode :$errorMsg")
        }
    }

    /**
     * @return true if alreadyLogin
     */
    private suspend fun wnsLoginAnonymous(): Boolean {
        return suspendCoroutine { continuation ->
            if (WnsHelper.uid != null) {
                continuation.resume(true)
                return@suspendCoroutine
            }

            WnsHelper.wnsClient.registerAnonymous(object : RemoteCallback.AuthCallback() {
                override fun onAuthFinished(args: RemoteData.AuthArgs, result: RemoteData.AuthResult) {
                    if (result.resultCode == 0) {
                        WnsHelper.isAnonymous = true
                        continuation.resume(true)
                    } else {
                        continuation.resume(false)
                    }
                    val message =
                        "onLoginFinished ${result.resultCode} ${result.errorMessage} uid:${result.accountInfo?.uid}"
                    Log.i("WnsHelper", message)
                }
            }, null)
        }
    }


    private suspend fun wnsLoginQQ(openId: String, token: String, expireTime: Long): Boolean {
        return suspendCoroutine { continuation ->
            if (WnsHelper.uid != null) {
                WnsHelper.isAnonymous = false
                continuation.resume(true)
                return@suspendCoroutine
            }

            WnsHelper.wnsClient.oAuthPasswordQQ(
                openId,
                token,
                expireTime,
                object : RemoteCallback.OAuthLocalCallback() {
                    override fun onAuthFinished(args: RemoteData.AuthArgs?, result: RemoteData.OAuthResult) {
                        val resultCode = result.resultCode
                        val info = result.accountInfo

                        if (resultCode == 0) {
                            saveSp(context, WNS_NAME, info.nameAccount)
                            saveSp(context, WNS_LOCAL_LOGIN_TYPE, info.localLoginType.toLong())
                            saveSp(context, WNS_UID, info.uid)

                            WnsHelper.wnsAuth(info.uid, info.nameAccount, info.localLoginType, continuation)
                        } else {
                            continuation.resume(false)
                        }
                    }
                })
        }
    }
}



