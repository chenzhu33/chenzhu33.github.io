package com.tencent.hms.sample

import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.HandlerThread
import android.util.Log
import androidx.core.app.NotificationCompat
import com.qq.jce.wup.UniAttribute
import com.tencent.wns.client.WnsClient
import com.tencent.wns.data.PushData
import com.tencent.wns.ipc.AbstractPushService

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-08
 * Time:   20:23
 * Life with Passion, Code with Creativity.
 * ```
 */
class WNSPushService : AbstractPushService() {
    companion object {
        const val TAG = "PushService"
        val pushHandlerThread = HandlerThread("push").apply {
            start()
        }
    }

    override fun getPushHandleThread(): HandlerThread =
        pushHandlerThread

    override fun getWnsClient(): WnsClient =
        WnsHelper.wnsClient

    override fun report(p0: String?, p1: String?, p2: String?): Boolean = false

    override fun onWnsTimer(p0: String?, p1: Boolean) {}

    override fun onPushReceived(datas: Array<PushData>): Boolean {
        datas.forEach {
            val forHMS = WnsHelper.wnsTransfer.onReceivePush(it)
            if (!forHMS) {
                sendNotification(it)
            }
        }
        return true
    }

    private fun sendNotification(data: PushData) {
        // todo: wns server bug???
        val attr = UniAttribute()
        attr.encodeName = "utf-8"
        attr.decode(data.data)
        val title = attr.get<String>("title")
        val content = attr.get<String>("message") ?: attr.get<String>("content")
        val schema = attr.get<String>("schema") ?: attr.get<String>("url") ?: attr.get<String>("schemaUrlAnd")

        Log.i(TAG, "sendNotification title:$title content:$content schema:$schema")

        if (title == null || content == null || schema == null) {
            return
        }

        val app = SampleApplication.instance

        val id = System.currentTimeMillis().toInt()
        app.notificationManager.notify(
            "push",
            id,
            NotificationCompat.Builder(
                app,
                IM_CHANNEL
            )
                .setContentTitle(title + " wnsOnlinePush")
                .setContentText(content)
                .setContentIntent(
                    PendingIntent.getActivity(
                        app,
                        id,
                        Intent(Intent.ACTION_VIEW, Uri.parse(schema)).apply {
                            `package` = app.packageName
                        },
                        PendingIntent.FLAG_UPDATE_CURRENT
                    )
                )
                .setSmallIcon(R.drawable.ic_launcher)
                .setDefaults(NotificationCompat.DEFAULT_SOUND)
                .build()
        )
    }
}
