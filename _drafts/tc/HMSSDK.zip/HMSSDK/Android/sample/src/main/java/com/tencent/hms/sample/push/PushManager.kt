package com.tencent.hms.sample.push

import android.app.Application
import android.content.Context
import android.os.Bundle
import android.util.Log
import com.huawei.android.hms.agent.HMSAgent
import com.huawei.hms.support.api.push.PushReceiver
import com.tencent.hms.HMSDisposableCallback
import com.tencent.hms.HMSPushToken
import com.tencent.hms.sample.HmsManager
import com.tencent.hms.sample.WnsHelper
import com.tencent.hms.sample.getSp
import com.tencent.hms.sample.saveSp

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-02-21
 * Time:   17:29
 * Life with Passion, Code with Creativity.
 * ```
 */

object PushManager {
    /**
     * init on login success
     */
    fun init(context: Application) {
        HMSAgent.init(context)

        val token = getSp(context, SP_HUAWEI_PUSH_TOKEN)
        if (token.isNotEmpty()) {
            bindToken(token)
            Log.i(TAG, "found token")
        } else {
            Log.i(TAG, "request token")
            HMSAgent.Push.getToken {
                Log.i(TAG, "getToken code:$it")
            }
        }
    }

    private fun bindToken(token: String) {
        Log.v(TAG, "bindToken $token")
        HmsManager.getHmsCore(WnsHelper.uid!!)
            ?.registerPushToken(
                HMSPushToken(HMSPushToken.PROVIDER_HUAWEI, token),
                HMSDisposableCallback {
                    Log.i(TAG, "bind result $it")
                }
            )
    }

    private const val TAG = "PushManager"
    private const val SP_HUAWEI_PUSH_TOKEN = "HUAWEI_PUSH_TOKEN"

    class HuaweiPushReceiver : PushReceiver() {
        override fun onToken(context: Context, token: String?, p2: Bundle?) {
            if (token != null) {
                saveSp(context, SP_HUAWEI_PUSH_TOKEN, token)
                bindToken(token)
            }
        }

        override fun onEvent(p0: Context?, p1: Event?, p2: Bundle?) {
            super.onEvent(p0, p1, p2)
            Log.i(TAG, "onEvent $p1")
        }

        override fun onPushMsg(p0: Context?, p1: ByteArray?, p2: String?) {
            super.onPushMsg(p0, p1, p2)
            Log.i(TAG, "onPushMsg $p1 $p2")
        }
    }
}