@file:JvmName("Constants")
package com.tencent.hms.sample

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-10
 * Time:   11:34
 * Life with Passion, Code with Creativity.
 * ```
 */

const val HMS_APPID = "1000580"

const val IM_CHANNEL = "IM"


