package com.tencent.hms.sample

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.tencent.hms.HMSCore
import com.tencent.hms.sample.debug.DebugMenuManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job

class MainActivity : AppCompatActivity() {

    private val _hmsService = MutableLiveData<HMSCore>()

    val hmsCore: LiveData<HMSCore>
        get() = _hmsService

    val navController: NavController by lazy {
        Navigation.findNavController(this, R.id.nav_host_fragment)
    }

    val debugMenuManager = DebugMenuManager(this, hmsCore)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        intent.getStringExtra("")
        Log.i(TAG, "onCreate intent:$intent")

        setContentView(R.layout.navi_host_fragment)
    }

    override fun onStart() {
        super.onStart()
        WnsHelper.setIsInBackground(false)
        hmsCore.value?.isForeground = true
    }

    override fun onStop() {
        super.onStop()
        WnsHelper.setIsInBackground(true)
        hmsCore.value?.isForeground = false
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)

        intent?.getStringExtra("")
        Log.i(TAG, "onNewIntent intent:$intent")
        if (navController.handleDeepLink(intent)) {
            setIntent(intent)
        }
    }

    fun onGetHMSCore(hmsCore: HMSCore) {
        if (!hmsCore.equals(_hmsService.value)) {
            _hmsService.value = hmsCore
            hmsCore.isForeground = true
        }
        WnsHelper.initOfflinePush()
    }

    companion object {
        const val TAG = "MainActivity"
    }

    open class BaseFragment : Fragment() {
        private val coroutineJob = Job()
        protected val coroutineScope = CoroutineScope(coroutineJob + Dispatchers.Main)

        val activity: MainActivity?
            get() = super.getActivity() as MainActivity?

        val navController: NavController
            get() = activity!!.navController

        val hmsCore: LiveData<HMSCore>
            get() = activity!!.hmsCore

        val debugMenuManager
            get() = activity!!.debugMenuManager

        override fun onDestroy() {
            super.onDestroy()
            coroutineJob.cancel()
        }
    }
}

