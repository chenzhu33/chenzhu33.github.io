package com.tencent.hms.sample

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import com.tencent.hms.extension.wns.HMSWnsNetworkTransfer
import com.tencent.wns.client.WnsClient

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-08
 * Time:   20:39
 * Life with Passion, Code with Creativity.
 * ```
 */
class SampleWnsTransfer(wnsClient: WnsClient, val context: Context) : HMSWnsNetworkTransfer(HMS_APPID, wnsClient) {

    private val receiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val info = cm.activeNetworkInfo
            notifyNetworkChange(info != null && info.isConnected)
        }
    }

    init {
        context.registerReceiver(receiver, IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION))
    }

    override fun onDestroy() {
        context.unregisterReceiver(receiver)
    }

    override val uid: String
        get() = WnsHelper.uid!!

    override val isAnonymous: Boolean
        get() = WnsHelper.isAnonymous ?: true
}

