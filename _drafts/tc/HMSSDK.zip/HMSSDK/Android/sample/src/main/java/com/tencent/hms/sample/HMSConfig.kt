package com.tencent.hms.sample

import android.content.Context
import com.tencent.hms.HMSSerializer
import com.tencent.hms.extension.android.HMSAndroidInitializeArgumentsBuilder


/**
 * Created by juliandai on 2019/1/14 11:24 AM.
 * talk and show the code
 */
class HMSConfig(val context: Context,val uid:String) {
    val argu by lazy {
        HMSAndroidInitializeArgumentsBuilder(context)
            .appid(HMS_APPID)
            .uid(uid)
            .networkTransfer(WnsHelper.wnsTransfer)
            .serializer(object : HMSSerializer() {
                override fun serializeMessagePayload(type: Int, payload: Any): ByteArray {
                    return (payload as String).toByteArray()
                }

                override fun deserializeMessagePayload(type: Int, payload: ByteArray): Any {
                    return String(payload)
                }

                override fun serializeSessionExtension(extension: Any): ByteArray {
                    return (extension as String).toByteArray()
                }

                override fun deserializeSessionExtension(extension: ByteArray): Any {
                    return String(extension)
                }

                override fun deserializeSessionBusinessBuffer(businessBuffer: ByteArray): Any {
                    return Unit
                }

                override fun serializeSessionBusinessBuffer(businessBuffer: Any): ByteArray {
                    return byteArrayOf()
                }
            })
            .build()
    }
}

