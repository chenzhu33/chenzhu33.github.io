package com.tencent.hms.sample.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.bumptech.glide.Glide
import com.tencent.hms.HMSCore
import com.tencent.hms.profile.HMSUser
import com.tencent.hms.sample.MainActivity
import com.tencent.hms.sample.R
import com.tencent.hms.sample.debug.DebugDialogManager
import com.tencent.hms.sample.login.LoginManager
import com.tencent.wns.client.WnsClientLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import com.tencent.hms.extension.livedata.liveData
import java.io.File


/**
 * Created by juliandai on 2019/2/18 4:28 PM.
 * talk and show the code
 */
class ProfileFragment : MainActivity.BaseFragment() {
    val profileName = MutableLiveData<String>()
    val profileUrl = MutableLiveData<String>()
    val profileUid = MutableLiveData<String>()

    val service = MutableLiveData<HMSCore>()
    var debugDialogManager: DebugDialogManager? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val rootView = inflater.inflate(R.layout.fragment_my_profile, container, false)
        val avatarView = rootView.findViewById<ImageView>(R.id.my_avatar)
        val nameView = rootView.findViewById<TextView>(R.id.user_name_text)
        val uidView = rootView.findViewById<TextView>(R.id.hms_account_uid)
        val logoutButton = rootView.findViewById<View>(R.id.logout_button)

        profileName.observe(this, Observer {
            nameView.text = it
        })

        profileUrl.observe(this, Observer {
            Glide.with(this).load(it).into(avatarView)
        })

        profileUid.observe(this, Observer {
            uidView.text = "超信号：${it}"
        })

        logoutButton.setOnClickListener {
            activity?.let {
                if (!it.isFinishing) {
                    LoginManager.logout(it)
                    activity?.recreate()
                }
            }
        }

        avatarView.setOnClickListener {
            debugDialogManager?.updateUserAvatar {
            }
        }

        nameView.setOnClickListener {
            debugDialogManager?.updateUserName {
            }
        }

        rootView.findViewById<View>(R.id.send_log).setOnClickListener {
            sendLog()
        }

        return rootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        hmsCore.observe(viewLifecycleOwner, Observer {
            initData(it)
        })
    }

    private fun initData(hms: HMSCore) {
        debugDialogManager = DebugDialogManager(activity!!, service)
        setView(hms.account.data)
        service.value = hms
        hms.account.liveData.observe(viewLifecycleOwner, Observer {
            setView(it)
        })
    }

    private fun setView(account: HMSUser?) {
        account?.name?.let {
            profileName.value = it
        }

        account?.uid?.let {
            profileUid.value = it
        }

        account?.avatar?.let {
            profileUrl.value = it
        }
    }

    private fun sendLog() {
        Toast.makeText(activity!!, "合成日志", Toast.LENGTH_SHORT).show()
        coroutineScope.launch(Dispatchers.IO) {
            val logFile = WnsClientLog.prepareReportLogFileByTime(System.currentTimeMillis(), TimeUnit.DAYS.toMillis(2))
            val shareFile = activity?.externalCacheDir?.let { File(it, "share_log_" + logFile.name) }
            if (shareFile != null) {
                logFile.renameTo(shareFile)
                withContext(Dispatchers.Main) {
                    activity?.let { activity ->
                        val shareLogIntent = Intent(Intent.ACTION_SEND)
                        shareLogIntent.putExtra(
                            Intent.EXTRA_STREAM,
                            FileProvider.getUriForFile(activity, activity.packageName + ".file_provider", shareFile)
                        )
                        shareLogIntent.type = "application/octet-stream"
                        activity.startActivity(shareLogIntent)
                    }
                }
            }
        }
    }
}

