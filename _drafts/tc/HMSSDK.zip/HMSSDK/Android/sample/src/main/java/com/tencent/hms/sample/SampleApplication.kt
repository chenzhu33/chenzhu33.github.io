package com.tencent.hms.sample

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build


/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-08
 * Time:   20:01
 * Life with Passion, Code with Creativity.
 * ```
 */

class SampleApplication : Application() {
    companion object {
        private lateinit var _instance: SampleApplication

        val instance: SampleApplication
            get() = _instance
    }

    override fun onCreate() {
        super.onCreate()
        WnsHelper.initWns(this)
        _instance = this

        DebugToolsInitializer.initDebugTools(this)
    }

    val notificationManager by lazy {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                createNotificationChannel(
                    NotificationChannel(
                        IM_CHANNEL,
                        "新消息",
                        NotificationManager.IMPORTANCE_HIGH
                    )
                )
            }
        }
    }

}