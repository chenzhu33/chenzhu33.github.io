package com.tencent.hms.sample.debug

import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.lifecycle.LiveData
import com.tencent.hms.HMSCore
import com.tencent.hms.HMSDisposableCallback
import com.tencent.hms.HMSResult
import com.tencent.hms.profile.HMSUserRole
import com.tencent.hms.sample.MainActivity
import com.tencent.hms.sample.MainFragmentDirections
import com.tencent.hms.sample.R
import com.tencent.hms.sample.fragment.Profile
import com.tencent.hms.session.HMSSession
import java.text.SimpleDateFormat
import java.util.*


/**
 * Created by juliandai on 2019/1/29 10:18 AM.
 * talk and show the code
 */
class DebugDialogManager(val activity: Activity, val service: LiveData<HMSCore>) {

    fun createSession() {
        showSingleEditDialog("创建单聊", "确定") { params, dialog ->
            val uidlist = params.split(",")
            if (uidlist.isNotEmpty()) {
                val hmscore = service.value
                hmscore?.createSession(HMSSession.Type.C2C, listOf(uidlist.first()),sessionName = "新建的单聊",callback =  HMSDisposableCallback {
                    when (it) {
                        is HMSResult.Success -> {
                            (activity as AppCompatActivity as MainActivity).navController.navigate(
                                MainFragmentDirections.actionMainFragmentToChatFragment(it.data.sid!!)
                            )
                        }
                        is HMSResult.Fail -> {
                            Toast.makeText(activity, "创建聊天失败", Toast.LENGTH_SHORT).show()
                        }
                    }
                })
            }
        }
    }

    fun createGroup() {
        showSingleEditDialog("创建群聊", "确定") { params, dialog ->
            val uidlist = params.split(",")
            val hmscore = service.value
            hmscore?.createSession(HMSSession.Type.GROUP, uidlist,sessionName = "新建的群聊",callback =  HMSDisposableCallback {
                when (it) {
                    is HMSResult.Success -> {
                        (activity as AppCompatActivity as MainActivity).navController.navigate(
                            MainFragmentDirections.actionMainFragmentToChatFragment(it.data.sid!!)
                        )
                    }
                    is HMSResult.Fail -> {
                        Toast.makeText(activity, "创建群聊失败", Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
    }

    fun addSessionMemberDialog(sid: String, callback: () -> Unit?) {
        showSingleEditDialog("请输入需要加群的uid or uids", "确定") { params, dialog ->
            val uidlist = params.split(",")
            val hmscore = service.value
            hmscore?.deleteSessionMember(sid, uidlist, HMSDisposableCallback {
                hmscore.addUserToSession(sid, uidlist, HMSDisposableCallback {
                    when (it) {
                        is HMSResult.Success -> {
                            Toast.makeText(activity, "成功拉人进群", Toast.LENGTH_SHORT).show()
                            callback.invoke()
                        }
                        is HMSResult.Fail -> {
                            Toast.makeText(activity, "拉人进群失败", Toast.LENGTH_SHORT).show()
                        }
                    }
                    dialog.dismiss()
                })
                dialog.dismiss()
            })
        }
    }

    fun updateFriendType(toUid: String, callback: () -> Unit?) {
        showSingleEditDialog("输入新的好友关系(int)", "确定") { params, dialog ->
            val hmscore = service.value
            hmscore?.updateSessionFriendType(toUid,params.toInt(),HMSDisposableCallback {
                when (it) {
                    is HMSResult.Success -> {
                        Toast.makeText(activity, "修改好友类型成功", Toast.LENGTH_SHORT).show()
                        callback.invoke()
                    }
                    is HMSResult.Fail -> {
                        Toast.makeText(activity, "修改好友类型失败", Toast.LENGTH_SHORT).show()
                    }
                }
                dialog.dismiss()
            })

        }
    }

    fun deleteSessionMember(sid: String, callback: () -> Unit?) {
        showSingleEditDialog("请输入需要T出群的uid or uids", "确定") { params, dialog ->
            val uidlist = params.split(",")
            val hmscore = service.value
            hmscore?.deleteSessionMember(sid, uidlist, HMSDisposableCallback {
                when (it) {
                    is HMSResult.Success -> {
                        val successList = it.data.filter { it.code == 0 }.joinToString("-")
                        val failList = it.data.filter { it.code != 0 }.joinToString { "-" }
                        Toast.makeText(activity, "成功删除用户${successList},删除失败${failList}", Toast.LENGTH_SHORT).show()
                        callback.invoke()
                    }
                    is HMSResult.Fail -> {
                        Toast.makeText(activity, "T人失败", Toast.LENGTH_SHORT).show()
                    }
                }
                dialog.dismiss()
            })
        }
    }

    fun quitSession(session: String) {
        showTipDialog("确定要退群(${session})吗？", "确定") {
            val hmscore = service.value
            hmscore?.quitSession(session, HMSDisposableCallback {
                when (it) {
                    is HMSResult.Success -> {
                        Toast.makeText(activity, "退群成功", Toast.LENGTH_SHORT).show()
                        activity.onBackPressed()
                    }
                    is HMSResult.Fail -> {
                        Toast.makeText(activity, "退群失败", Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
    }

    fun enterChatRoom() {
        showSingleEditDialog("输入RoomId，进入聊天室", "进入") { params, _ ->
            (activity as AppCompatActivity as MainActivity).navController.navigate(
                MainFragmentDirections.actionMainFragmentToChatFragment(params)
            )
        }
    }

    fun destroySessionDialog(session: String) {
        showTipDialog("确定要解散群(${session})吗？", "确定") {
            val hmscore = service.value
            hmscore?.destroySession(session, HMSDisposableCallback {
                when (it) {
                    is HMSResult.Success -> {
                        Toast.makeText(activity, "成功解散", Toast.LENGTH_SHORT).show()
                        activity.onBackPressed()
                    }
                    is HMSResult.Fail -> {
                        Toast.makeText(activity, "解散群失败", Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
    }

    //update group name or avatar
    fun updateSessionName(sid: String, callback: () -> Unit?) {
        showSingleEditDialog("修改群名", "确定") { params, dialog ->
            val hmscore = service.value
            hmscore?.updateSessionInfo(
                sid = sid, name = params,
                callback = HMSDisposableCallback {
                    when (it) {
                        is HMSResult.Success -> {
                            callback.invoke()
                            Toast.makeText(activity, "修改成功", Toast.LENGTH_SHORT).show()
                        }
                        is HMSResult.Fail -> {
                            Toast.makeText(activity, "修改失败", Toast.LENGTH_SHORT).show()
                        }
                    }
                    dialog.dismiss()
                })
        }
    }

    //update user in session
    fun updateSessionAvatar(sid: String) {
        showSingleEditDialog("修改群头像", "确定") { params, dialog ->
            val hmscore = service.value
            hmscore?.updateSessionInfo(
                sid = sid, avatar = params,
                callback = HMSDisposableCallback {
                    when (it) {
                        is HMSResult.Success -> {
                            Toast.makeText(activity, "修改成功", Toast.LENGTH_SHORT).show()
                        }
                        is HMSResult.Fail -> {
                            Toast.makeText(activity, "修改失败", Toast.LENGTH_SHORT).show()
                        }
                    }
                    dialog.dismiss()
                })
        }
    }

    fun getSessionMemberInfo(sid: String) {
        showSingleEditDialog("获得群成员信息", "确定") { params, dialog ->
            val uidlist = params.split(",")
            service.value?.getUsersMemberInfo(sid, uidlist, HMSDisposableCallback {
                when (it) {
                    is HMSResult.Success -> {
                        val data = it.data.map {
                            val titlePrefix = when (it.userInSession!!.role) {
                                HMSUserRole.NORMAL -> "群员"
                                HMSUserRole.ADMINISTRATOR -> "管理员"
                                HMSUserRole.OWNER -> "群主"
                                else -> "群员"
                            }
                            val profile = Profile(
                                sid = sid,
                                name = it.user.name ?: it.user.uid,
                                avatar = it.user.avatar,
                                uid = it.user.uid
                            )
                            val remark =
                                if (it.userInSession!!.remark == null) "" else " [备注：${it.userInSession!!.remark}]"

                            val dateFormat = SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
                            val expireTime = dateFormat.format(Date(it.userInSession!!.banExpireTime))
                            val banTips =
                                if (it.userInSession?.banExpireTime ?: 0 > 0) "(禁言到${expireTime}截止)" else ""
                            profile.showText = "${titlePrefix}-${profile.name}(${profile.uid})${remark}${banTips}"
                            profile
                        }
                        val showlist = data.map { it.showText }
                        showTipDialog("群员信息:${showlist}", "确定") {

                        }
                    }
                    is HMSResult.Fail -> {
                        Toast.makeText(activity, "获取失败", Toast.LENGTH_SHORT).show()
                    }
                }
                dialog.dismiss()
            })
        }
    }

    fun updateSessionExtension(sid: String) {
        val hmscore = service.value
        hmscore?.let { core ->
            core.getSessionListBySid(listOf(sid), false, false, HMSDisposableCallback { result ->
                when (result) {
                    is HMSResult.Success -> {
                        val session = result.data.firstOrNull()
                        session?.let {
                            val extStr: String? = it.extension as String?
                            showSingleEditDialog("修改群自定义(当前:${extStr})", "确定") { params, dialog ->
                                core.updateSessionExtension(sid, params, HMSDisposableCallback {
                                    when (it) {
                                        is HMSResult.Success -> {
                                            Toast.makeText(activity, "修改成功", Toast.LENGTH_SHORT).show()
                                        }
                                        is HMSResult.Fail -> {
                                            Toast.makeText(activity, "修改失败", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                })
                            }
                        }
                    }
                }
            })
        }
    }

    fun updateUserName(callback: () -> Unit) {
        showSingleEditDialog("修改姓名", "确认修改") { params, dialog ->
            service.value?.updateUserInfo(
                service.value!!.uid,
                name = params, callback = HMSDisposableCallback {
                    when (it) {
                        is HMSResult.Success -> {
                            Toast.makeText(activity, "修改成功", Toast.LENGTH_SHORT).show()
                            callback.invoke()
                        }
                        is HMSResult.Fail -> {
                            Toast.makeText(activity, "修改失败", Toast.LENGTH_SHORT).show()
                        }
                    }
                    dialog.dismiss()
                })
        }
    }

    fun updateFriendRemark(uid: String, callback: () -> Unit?) {
        showSingleEditDialog("修改好友备注", "确认修改") { params, dialog ->
            service.value?.updateUserInfo(uid = uid, name = params, callback = HMSDisposableCallback {
                when (it) {
                    is HMSResult.Success -> {
                        Toast.makeText(activity, "修改成功", Toast.LENGTH_SHORT).show()
                        callback.invoke()
                    }
                    is HMSResult.Fail -> {
                        Toast.makeText(activity, "修改失败", Toast.LENGTH_SHORT).show()
                    }
                }
                dialog.dismiss()
            })
        }
    }

    fun addBlack(uid: String, callback: () -> Unit?) {
        showTipDialog("确定要拉黑好友(${uid})吗？", "确定") {
            val hmscore = service.value
            hmscore?.addToBlackList(uid, HMSDisposableCallback {
                when (it) {
                    is HMSResult.Success -> {
                        Toast.makeText(activity, "成功加入黑名单", Toast.LENGTH_SHORT).show()
                        callback.invoke()
                    }
                    is HMSResult.Fail -> {
                        Toast.makeText(activity, "加入黑名单失败", Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
    }


    fun removeBlack(uid:String,callback: () -> Unit?) {
        showTipDialog("确定要将(${uid})从黑名单移除吗？", "确定") {
            val hmscore = service.value
            hmscore?.removeFromBlackList(uid, HMSDisposableCallback {
                when (it) {
                    is HMSResult.Success -> {
                        Toast.makeText(activity, "成功移除黑名单", Toast.LENGTH_SHORT).show()
                        callback.invoke()
                    }
                    is HMSResult.Fail -> {
                        Toast.makeText(activity, "移除黑名单失败", Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
    }


    fun updateUserAvatar(callback: () -> Unit) {
        showSingleEditDialog("修改头像，输入url地址", "确认修改") { params, dialog ->
            service.value?.updateUserInfo(
                service.value!!.uid,
                avatar = params,
                callback = HMSDisposableCallback {
                    when (it) {
                        is HMSResult.Success -> {
                            Toast.makeText(activity, "修改成功", Toast.LENGTH_SHORT).show()
                            callback.invoke()
                        }
                        is HMSResult.Fail -> {
                            Toast.makeText(activity, "修改失败", Toast.LENGTH_SHORT).show()
                        }
                    }
                    dialog.dismiss()
                })
        }
    }

    fun updateSessionUserRemark(sid: String) {
        showSingleEditDialog("修改群名片", "确定") { params, dialog ->
            service.value?.let { service ->
                service.account.data?.uid?.let {
                    service.updaterUserInSession(
                        sid, it,
                        remark = params,
                        callback = HMSDisposableCallback {
                            when (it) {
                                is HMSResult.Success -> {
                                    Toast.makeText(activity, "修改群名片成功", Toast.LENGTH_SHORT).show()
                                }
                                is HMSResult.Fail -> {
                                    Toast.makeText(activity, "修改失败", Toast.LENGTH_SHORT).show()
                                }
                            }
                        })
                }

            }
        }
    }

    fun updateRoleSession(name: String, sid: String, uid: String, role: HMSUserRole, succAction: (() -> Unit)?) {
        showTipDialog("确定将此人变成${role.name}", "确定") { dialog ->
            service.value?.let { service ->
                service.updateRoleInSession(sid, uid, role, HMSDisposableCallback {
                    when (it) {
                        is HMSResult.Success -> {
                            Toast.makeText(activity, "修改身份成功", Toast.LENGTH_SHORT).show()
                            succAction?.invoke()
                            dialog.dismiss()
                        }
                        is HMSResult.Fail -> {
                            Toast.makeText(activity, "修改失败", Toast.LENGTH_SHORT).show()
                            dialog.dismiss()
                        }
                    }
                })
            }
        }
    }

    private fun showSingleEditDialog(
        title: String,
        conformText: String,
        conformAction: (String, DialogInterface) -> Unit
    ) {
        val builder = AlertDialog.Builder(activity)
        val dialogView = LayoutInflater.from(activity).inflate(R.layout.dialog_single_chat, null, false)
        val editText = dialogView.findViewById<EditText>(R.id.chat_uid_edittext)

        builder.setView(dialogView).setTitle(title).setPositiveButton(
            conformText
        ) { dialog, which ->
            conformAction.invoke(editText.text.toString(), dialog)
        }.setNegativeButton("取消") { dialog, which -> dialog.dismiss() }
        builder.show()
    }

    private fun showTipDialog(
        title: String,
        conformText: String,
        conformAction: (DialogInterface) -> Unit
    ) {
        val builder = AlertDialog.Builder(activity)
        builder.setMessage(title)
            .setPositiveButton(conformText) { dialog, _ ->
                conformAction.invoke(dialog)
            }
            .setNegativeButton("取消") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    fun showPopupForAdmin(view: View, profile: Profile, succAction: (() -> Unit)?) {
        val popup = PopupMenu(activity, view)
        val inflater = popup.getMenuInflater()
        inflater.inflate(R.menu.menu_memeber_manger, popup.getMenu())
        popup.setOnMenuItemClickListener { menu ->
            when (menu.itemId) {
                R.id.menu_ban_member -> {
                    showSingleEditDialog("禁言时长(ms)", "确定") { banTime, dialog ->
                        service.value?.updateSessionBannedStatus(
                            profile.sid,
                            profile.uid,
                            banTime.toLong(),
                            HMSDisposableCallback {
                                when (it) {
                                    is HMSResult.Success -> {
                                        succAction?.invoke()
                                        Toast.makeText(activity, "设置禁言成功", Toast.LENGTH_LONG).show()
                                    }
                                }
                            })
                    }
                }
                R.id.menu_trans_owner -> {
                    showTipDialog("确定将群主转让给${profile.uid}?", "确定") { dialog ->
                        service.value?.transferSessionOwner(
                            profile.sid,
                            profile.uid,
                            HMSDisposableCallback {
                                when (it) {
                                    is HMSResult.Success -> {
                                        succAction?.invoke()
                                        Toast.makeText(activity, "转让群主成功", Toast.LENGTH_LONG).show()
                                    }
                                }
                            })
                    }
                }
                R.id.menu_trans_group -> {
                    updateRoleSession(
                        profile.name ?: "此人",
                        profile.sid,
                        profile.uid,
                        HMSUserRole.ADMINISTRATOR,
                        succAction
                    )
                }
                R.id.menu_trans_member -> {
                    updateRoleSession(profile.name ?: "此人", profile.sid, profile.uid, HMSUserRole.NORMAL, succAction)
                }
            }
            true
        }
        popup.show()
    }


}