package com.tencent.hms.sample

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.text.TextUtils
import androidx.appcompat.app.AlertDialog
import com.tencent.hms.message.*
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Created by juliandai on 2019/1/14 11:19 AM.
 * talk and show the code
 */

fun isNetworkConnected(context: Context): Boolean {
    try {
        val connMgr = context
            .getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return connMgr!!.getActiveNetworkInfo().isConnected
    } catch (e: Throwable) {
        return false
    }
}

fun isPackageInstalled(context: Context, packageName: String): Boolean {
    if (!TextUtils.isEmpty(packageName)) {
        try {
            val packageInfo = context.packageManager.getPackageInfo(packageName, 0)
            return packageInfo != null
        } catch (e: PackageManager.NameNotFoundException) {
            // ignore.
        }

    }
    return false
}

fun isQQInstalled(context:Context): Boolean {
    return isPackageInstalled(context, "com.tencent.mobileqq")
}

fun saveSp(context: Context, key: String, value: String) {
    context.getSharedPreferences("SAMPLE", Context.MODE_PRIVATE)
        .edit()
        .putString(key, value)
        .commit()
}

fun getSp(context: Context, key: String): String {
    return context.getSharedPreferences("SAMPLE", Context.MODE_PRIVATE).getString(key, "")
}

fun saveSp(context: Context, key: String, value: Long) {
    context.getSharedPreferences("SAMPLE", Context.MODE_PRIVATE)
        .edit()
        .putLong(key, value)
        .commit()
}

fun getLongSp(context: Context, key: String): Long {
    return context.getSharedPreferences("SAMPLE", Context.MODE_PRIVATE).getLong(key, 0L)
}


suspend fun Activity.showPrompt(title: String, ok: String, cancel: String): Boolean =
    suspendCoroutine { continuation ->
        AlertDialog.Builder(this)
            .setTitle(title)
            .setPositiveButton(ok) { dialog, _ ->
                dialog.dismiss()
                continuation.resume(true)
            }
            .setNegativeButton(cancel) { dialog, _ ->
                dialog.dismiss()
                continuation.resume(false)
            }
            .create()
            .show()
    }

fun explainMessage(message: HMSMessage): String {
    return if (message.isRevoked) {
        "[消息已被撤回]"
    } else if (message.isControlMessage) {
        val control = (message as HMSControlMessage).control
        when (control) {
            is HMSAlertJoinSession ->
                if (control.inviter != null) {
                    "${control.inviter?.nameInSession} 邀请 ${control.joinUsers.joinToString { it.nameInSession }} 加入了聊天"
                } else {
                    "${control.joinUsers.joinToString { it.nameInSession }} 加入了聊天"
                }
            is HMSAlertExitSession ->
                "${control.exitedUser.nameInSession} 退出了聊天"
            is HMSAlertTransferSessionOwner ->
                "${control.newOwner.nameInSession} 成为了新群主"
            is HMSAlertDeleteFromSession ->
                "${control.executor.nameInSession} 从群聊中移除了 ${control.deletedUsers.joinToString { it.nameInSession }}"
            is HMSAlertSessionInfoChange -> {
                val sb = StringBuilder()
                    .append(control.executor.nameInSession)
                    .append(" 更新了 ")
                control.changedFields.forEach {
                    when (it) {
                        HMSAlertSessionInfoChange.ChangedSessionField.NAME ->
                            sb.append("群名:").append(control.sessionInfo.name)
                        HMSAlertSessionInfoChange.ChangedSessionField.AVATAR ->
                            sb.append("群头像")
                        HMSAlertSessionInfoChange.ChangedSessionField.BUSINESS_BUFFER ->
                            sb.append("BizBuf")
                    }
                }

                sb.toString()
            }
            is HMSAlertBannedChange -> {
                val time = control.duringTimeOfBan.div(1000)
                "${control.changedUser.nameInSession}被${control.executor.nameInSession}禁言了${time}秒"
            }
            is HMSAlertRoleChange -> {
                "${control.executor.user.name} 将 ${control.changedUser.user.name}变成${control.changedUser.userInSession?.role?.name}"
            }
            is HMSAlertDestroySession -> {
                "${control.executor.user.name} 解散了会话"
            }
            else -> "[Control:${control.javaClass.simpleName}]"
        }
    } else {
        message.text
    }
}

