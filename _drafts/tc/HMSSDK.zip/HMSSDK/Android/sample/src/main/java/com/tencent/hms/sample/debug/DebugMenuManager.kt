package com.tencent.hms.sample.debug

import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.Toast
import androidx.lifecycle.LiveData
import com.tencent.hms.*
import com.tencent.hms.sample.MainActivity
import com.tencent.hms.sample.R
import com.tencent.hms.sample.chat.ChatFragmentDirections
import com.tencent.hms.session.HMSMessageAlertType
import com.tencent.hms.session.HMSSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

/**
 * Created by juliandai on 2019/1/29 10:23 AM.
 * talk and show the code
 */
class DebugMenuManager(val context: MainActivity, val hms: LiveData<HMSCore>) {

    private val debugDialogManager by lazy {
        DebugDialogManager(context, hms)
    }

    fun createGroupChatMenuOption(menuInflate: MenuInflater, menu: Menu?) {
        menuInflate.inflate(R.menu.menu_activity_chat_detail, menu)
    }

    fun createC2CMenuOption(menuInflate: MenuInflater, menu: Menu?, isInBlack: Boolean) {
        menuInflate.inflate(R.menu.menu_activity_c2c, menu)
        if (isInBlack) {
            menu?.removeItem(R.id.menu_add_black)
        } else {
            menu?.removeItem(R.id.menu_del_black)
        }
    }

    fun createSessionMenuOption(menuInflate: MenuInflater, menu: Menu?) {
        menuInflate.inflate(R.menu.menu_activity_session_detail, menu)
    }

    fun createSessionManagerMenuOption(menuInflate: MenuInflater, menu: Menu?) {
        menuInflate.inflate(R.menu.menu_session_member_manger, menu)
    }

    fun dispatchOptionSelect(item: MenuItem?, params: Any?, callback: () -> Unit?) {
        when (item?.itemId) {
            R.id.menu_group_manager -> {
                val sessionId = params as String
                if (!sessionId.isEmpty()) {
                    context.navController.navigate(
                        ChatFragmentDirections.actionChatFragmentToSessionMemberListFragment(sessionId)
                    )
                }
            }
            R.id.menu_add_session -> {
                debugDialogManager.addSessionMemberDialog(params as String,callback)
            }
            R.id.menu_kick_session -> {
                debugDialogManager.deleteSessionMember(params as String,callback)
            }
            R.id.menu_quit_session -> {
                debugDialogManager.quitSession(params as String)
            }
            R.id.menu_destroy_session -> {
                debugDialogManager.destroySessionDialog(params as String)
            }
            R.id.menu_update_session_name -> {
                debugDialogManager.updateSessionName(params as String, callback)
            }
            R.id.menu_update_user -> {
                debugDialogManager.updateSessionUserRemark(params as String)
            }
            R.id.menu_update_session_avatar -> {
                debugDialogManager.updateSessionAvatar(params as String)
            }
           /* R.id.menu_modify_remark -> {
                debugDialogManager.updateFriendRemark(params as String,callback)
            }*/
            R.id.menu_session_extension -> {
                debugDialogManager.updateSessionExtension(params as String)
            }
            R.id.menu_session_member_info-> {
                debugDialogManager.getSessionMemberInfo(params as String)
            }
            R.id.menu_update_friend_type -> {
                hms.value?.getSessionListBySid(listOf(params as String), callback = HMSDisposableCallback {
                    if (it is HMSResult.Success) {
                        it.data.firstOrNull().let { session ->
                            if (session?.type == HMSSession.Type.C2C) {
                                debugDialogManager.updateFriendType(session.toUid!!, callback)
                            }
                        }
                    }
                })
            }
            R.id.menu_add_black -> {
                hms.value?.getSessionListBySid(listOf(params as String), callback = HMSDisposableCallback {
                    if (it is HMSResult.Success) {
                        it.data.firstOrNull().let { session ->
                            if (session?.type == HMSSession.Type.C2C) {
                                debugDialogManager.addBlack(session.toUid!!, callback)
                            }
                        }
                    }
                })
            }
            R.id.menu_del_black -> {
                hms.value?.getSessionListBySid(listOf(params as String), callback = HMSDisposableCallback {
                    if (it is HMSResult.Success) {
                        it.data.firstOrNull().let { session ->
                            if (session?.type == HMSSession.Type.C2C) {
                                debugDialogManager.removeBlack(session.toUid!!, callback)
                            }
                        }
                    }
                })
            }
            R.id.menu_session_delete_messages -> {
                hms.value?.deleteSessionMessages(params as String, null)
            }
            R.id.menu_session_change_alert_type -> {
                val sid = params as String
                hms.value?.let { hms ->
                    GlobalScope.launch(Dispatchers.Main) {
                        val session = hms.getSessionListBySid(listOf(sid)).first()
                        val newType = when (session.messageAlertType) {
                            HMSMessageAlertType.DoNotDisturb -> HMSMessageAlertType.MessageRemind
                            HMSMessageAlertType.MessageRemind -> HMSMessageAlertType.DoNotDisturb
                        }
                        Toast.makeText(context, "change AlertType to $newType", Toast.LENGTH_SHORT).show()
                        try {
                            hms.changeSessionMessageAlertType(session.sid, newType)
                        } catch (e: HMSException) {
                            Toast.makeText(context, "change AlertType failed ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }
}