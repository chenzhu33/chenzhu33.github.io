package com.tencent.hms.sample.chat

import android.content.Context
import android.text.SpannableStringBuilder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tencent.hms.message.HMSMessage
import com.tencent.hms.message.HMSMessageStatus
import com.tencent.hms.message.HMSPlainMessage
import com.tencent.hms.sample.R
import com.tencent.hms.sample.debug.DefaultAvatar

class ChatItemVH(mContext: Context, parentView: ViewGroup) : RecyclerView.ViewHolder(
    LayoutInflater.from(mContext).inflate(
        R.layout.im_chatitem_layout, parentView, false
    )
) {

    private val mMsgTime: TextView

    private val mRightMsgContainer: ViewGroup

    private val mLeftMsgContainer: ViewGroup

    private val mLeftAvatar: ImageView

    private val mRightAvatar: ImageView

    private val mLeftMsg: TextView
    private val mRightMsg: TextView
    private val leftName: TextView
    private val rightName: TextView
    private val avatarManager = DefaultAvatar(mContext)

    val mRightStatus: ImageView

    /**
     * 聊天人的id
     */
    private var mPeerId: String? = null


    init {
        mMsgTime = itemView.findViewById(R.id.msg_time) as TextView

        mRightMsgContainer = itemView.findViewById(R.id.right_msg) as ViewGroup

        mLeftMsgContainer = itemView.findViewById(R.id.left_msg) as ViewGroup

        mLeftAvatar = itemView.findViewById(R.id.left_avatar) as ImageView

        mRightAvatar = itemView.findViewById(R.id.right_avatar) as ImageView

        mLeftMsg = itemView.findViewById(R.id.left_content) as TextView

        mRightMsg = itemView.findViewById(R.id.right_content) as TextView

        mRightStatus = itemView.findViewById(R.id.right_msg_status) as ImageView

        leftName = itemView.findViewById(R.id.left_name) as TextView
        rightName = itemView.findViewById(R.id.right_name) as TextView

    }

    fun bind(message: HMSPlainMessage) {
        val isMe = message.isMine
        mPeerId = message.sender
        mMsgTime.text = message.index.toSimpleString()
        mMsgTime.visibility = View.VISIBLE

        val ssb = SpannableStringBuilder(message.text)

        if (isMe) {
            mLeftMsgContainer.visibility = View.GONE
            mRightMsgContainer.visibility = View.VISIBLE
            mRightMsg.text = ssb
            rightName.text = getGroupName(message)
            avatarManager.setAvatar(message.senderInfo.user.avatar, mRightAvatar)
        } else {
            mRightMsgContainer.visibility = View.GONE
            mLeftMsgContainer.visibility = View.VISIBLE
            mLeftMsg.text = ssb
            leftName.text = getGroupName(message)
            avatarManager.setAvatar(message.senderInfo.user.avatar, mLeftAvatar)
        }

        renderStatus(message)
    }

    private fun getGroupName(msg: HMSPlainMessage):String {
        return msg.senderInfo.userInSession?.remark ?:  msg.senderInfo.user.name ?: msg.sender
    }

    /**
     * 设置消息状态
     */
    fun renderStatus(biz: HMSMessage?) {
        if (biz == null) {
            return
        }
        when (biz.status) {
            HMSMessageStatus.SENDING -> {
                mRightStatus.setImageResource(R.drawable.ic_upload)
                mRightStatus.visibility = View.VISIBLE
            }
            HMSMessageStatus.SEND_FAILED -> {
                mRightStatus.setImageResource(R.drawable.ic_error)
                mRightStatus.visibility = View.VISIBLE
            }
            HMSMessageStatus.LOCAL -> {
                mRightStatus.setImageResource(R.drawable.ic_local)
                mRightStatus.visibility = View.VISIBLE
            }
            HMSMessageStatus.SUCCESS -> {
                mRightStatus.visibility = View.INVISIBLE
            }
        }
    }
}
