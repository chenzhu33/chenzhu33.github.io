package com.tencent.hms.sample.chat

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tencent.hms.message.*
import com.tencent.hms.sample.R
import com.tencent.hms.sample.explainMessage

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-02-18
 * Time:   16:47
 * Life with Passion, Code with Creativity.
 * ```
 */

class TipItemVH(context: Context, parentView: ViewGroup) : RecyclerView.ViewHolder(
    LayoutInflater.from(context).inflate(
        R.layout.im_tip_item_layout, parentView, false
    )
) {
    private val text = itemView.findViewById<TextView>(R.id.tip)

    @SuppressLint("SetTextI18n")
    fun bind(message: HMSMessage) {
        text.text =
            explainMessage(message)
    }
}