package com.tencent.hms.sample

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.lifecycle.Observer
import androidx.viewpager.widget.ViewPager
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.tencent.hms.extension.livedata.liveData
import com.tencent.hms.sample.MainFragment.Companion.PAGE_COUNT
import com.tencent.hms.sample.fragment.FriendFragment
import com.tencent.hms.sample.fragment.ProfileFragment
import com.tencent.hms.sample.fragment.SessionFragment

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-02-19
 * Time:   14:40
 * Life with Passion, Code with Creativity.
 * ```
 */

class MainFragment : MainActivity.BaseFragment() {
    private lateinit var viewPager: ViewPager

    companion object {
        const val TAG = "MainFragment"
        const val PAGE_COUNT = 3
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    private fun checkLoginStatus() {
        val hmsCore = WnsHelper.uid?.let { HmsManager.getHmsCore(it) }
        if (hmsCore != null) {
            activity!!.onGetHMSCore(hmsCore)
        } else {
            navController.navigate(R.id.loginFragment)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.activity_main, container, false).apply {
            viewPager = findViewById(R.id.fragment_viewpager)
            val bottomBar = findViewById<BottomNavigationView>(R.id.bottom_navigation_view)

            viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
                override fun onPageScrollStateChanged(state: Int) {
                }

                override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                }

                override fun onPageSelected(position: Int) {
                    bottomBar.selectedItemId = when (position) {
                        0 -> R.id.action_home
                        1 -> R.id.action_friend
                        2 -> R.id.action_me
                        else -> 0
                    }
                }
            })

            bottomBar.setOnNavigationItemSelectedListener {
                when (it.itemId) {
                    R.id.action_home -> viewPager.currentItem = 0
                    R.id.action_friend -> viewPager.currentItem = 1
                    R.id.action_me -> viewPager.currentItem = 2
                    else -> {
                        //do nothing
                    }
                }
                true
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        checkLoginStatus()
        hmsCore.observe(viewLifecycleOwner, Observer {
            val viewPagerAdapter = ViewPagerAdapter(childFragmentManager)
            viewPager.adapter = viewPagerAdapter
            activity?.invalidateOptionsMenu()

            it.unreadCount.liveData.observe(viewLifecycleOwner, Observer {
                activity?.title = "${getString(R.string.app_cn_name)} $it"
            })
        })
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        activity?.title = getString(R.string.app_cn_name)
        debugMenuManager.createSessionMenuOption(inflater, menu)
        return super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        debugMenuManager.dispatchOptionSelect(item, null) {
            
        }
        return super.onOptionsItemSelected(item)
    }
}

class ViewPagerAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm) {

    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> SessionFragment()
            1 -> FriendFragment()
            else -> ProfileFragment()
        }
    }

    override fun getCount(): Int {
        return PAGE_COUNT
    }

}

