package com.tencent.hms.sample

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import com.tencent.base.Global
import com.tencent.hms.sample.push.PushManager
import com.tencent.wns.client.WnsClient
import com.tencent.wns.data.Client
import com.tencent.wns.data.Const
import com.tencent.wns.ipc.RemoteCallback
import com.tencent.wns.ipc.RemoteData
import java.io.File
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-09
 * Time:   10:28
 * Life with Passion, Code with Creativity.
 * ```
 */

object WnsHelper {

    lateinit var wnsClient: WnsClient
        private set

    @SuppressLint("StaticFieldLeak")
    lateinit var wnsTransfer: SampleWnsTransfer
        private set

    val uid: String?
        get():String? = _internal_uid

    private var _internal_uid: String? = null

    var isAnonymous: Boolean? = null

    fun initOfflinePush() {
        PushManager.init(SampleApplication.instance)
    }

    fun logout() {
        _internal_uid = null
        wnsClient.logoutAll(false, null)
    }


    fun wnsAuth(uid: String, name: String, localLoginType: Int, continuation: Continuation<Boolean>) {
        wnsClient.oAuthLogin(
            name,
            uid,
            false,
            true,
            1,
            object : RemoteCallback.LoginCallback() {
                override fun onLoginFinished(
                    p0: RemoteData.LoginArgs?,
                    result: RemoteData.LoginResult
                ) {
                    isAnonymous = false
                    if (result.resultCode == 0) {
                        _internal_uid = uid
                    } else {
                        Log.e("WNS Helper", "WNS Login error code ${result}")
                    }
                    continuation.resume(result.resultCode == 0)
                }
            },
            localLoginType
        )
    }

    fun setIsInBackground(isBackground: Boolean) {
        wnsClient.setBackgroundMode(isBackground)
    }

    /**
     * Group Notice
    wns登录相关：
    wns appId 1000567

    手Q账户：
    APP ID : 1108071150
    APP KEY : ustcvLNAN4V3IkIJ

    WNS测试环境
    端口: 80, 8080, 443, 14000
    IP:      - 101.226.90.152(电信)
    - 140.207.54.35(联通)
    - 117.135.169.77(移动)
    命令字格式：SnsCommunityService.CreateC2CSession
    这个wns测试环境以及命令字前缀是之前做一个app demo的时候用的，我们做demo可以先用着，登录getuid都调通了的
     */
    internal fun initWns(context: Context) {
        Global.init(context, object : Global.HostInterface {
            override fun getBusiDeviceinfos(): MutableMap<String, String> {
                return mutableMapOf()
            }

            override fun setCrashReportUserID(p0: String?) {
            }

            override fun showDialog(p0: String?, p1: String?) {
            }

            override fun getVersionCode(): Int {
                return BuildConfig.VERSION_CODE
            }

            override fun getWnsLogPath(): File? {
                return File(context.externalCacheDir ?: context.cacheDir, "misc/WnsLog")
            }

            override fun mailLog(p0: String?, p1: String?) {
            }

            override fun getVersionName(): String {
                return BuildConfig.VERSION_NAME
            }

            override fun getForegroundNotiIcon(): Int {
                return 0
            }

            override fun getZZReport(): Global.AbstractZZReport? {
                return null
            }
        })

        wnsClient = WnsClient(
            Client().apply {
                appId = HMS_APPID.toInt()
                build = BuildConfig.VERSION_CODE.toString()
                release = BuildConfig.VERSION_CODE
                version = BuildConfig.VERSION_NAME
                qua = "V1_AND_HMS_1.0.0_1_LOCAL_T"
                business = Const.BusinessType.IM
            }
        )
        wnsClient.setDebugIp(formatTransferEnv())

        wnsTransfer = SampleWnsTransfer(wnsClient, context)

    }

    private fun formatTransferEnv(): String? {
        val cmcc = "117.135.169.77"
        val telecom = "101.226.90.152"
        val unicom = "140.207.54.35"
        val wifi = telecom
        val defaultIp = telecom

        val sb = StringBuilder()
        sb.append("{\"mobile\":")
        sb.append("{")
        sb.append("\"cmcc\":\"").append(cmcc).append((":8080") + "\",")
        sb.append("\"unicom\":\"").append(unicom).append((":8080") + "\",")
        sb.append("\"telecom\":\"").append(telecom).append((":8080") + "\"")
        sb.append("},")
        sb.append("\"wifi\":\"").append(wifi).append((":8080") + "\",")
        sb.append("\"default\":\"").append(defaultIp).append((":80") + "\"")
        sb.append("}")

        return sb.toString()
    }
}