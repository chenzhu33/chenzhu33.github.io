package com.tencent.hms.sample.debug

import android.content.Context
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.tencent.hms.sample.R

/**
 * Created by juliandai on 2019/1/31 3:16 PM.
 * talk and show the code, just for debug
 */
class DefaultAvatar(val context: Context) {


    fun setSessionAvatar(url: String?, sid: String, imageView: ImageView) {
        if (url.isNullOrEmpty() || !url.startsWith("http")) {
            val drawable = context.resources.getDrawable(R.drawable.default_session_avatar, null)
            imageView.setImageDrawable(drawable)
        } else {
            Glide.with(imageView).load(url).into(imageView)
        }
    }


    fun setAvatar(url: String?, imageView: ImageView) {
        if (!url.isNullOrEmpty()) {
            Glide.with(imageView).load(url).into(imageView)
        } else {
            val drawable = context.resources.getDrawable(R.drawable.user_avatar_default, null)
            imageView.setImageDrawable(drawable)
        }
    }
}