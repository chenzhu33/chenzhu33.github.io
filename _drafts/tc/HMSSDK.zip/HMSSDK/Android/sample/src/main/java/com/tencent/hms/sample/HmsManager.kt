package com.tencent.hms.sample

import android.content.Context
import com.tencent.hms.HMSDisposableCallback
import com.tencent.hms.HMSCore
import com.tencent.hms.HMSException
import com.tencent.hms.HMSResult
import com.tencent.hms.sample.impl.NewMessageListener

/**
 * Created by juliandai on 2019/1/25 2:55 PM.
 * talk and show the code
 * 管理hms 实例
 */
object HmsManager {

    private val hmsCoreList = HashMap<String, HMSCore>()
    private val initIngList = mutableListOf<String>()
    private val initLock = Any()

    fun initHmsCore(context: Context, uid: String, callback: HMSDisposableCallback<HMSResult<HMSCore>>) {
        if (uid.isEmpty()) {
            throw IllegalArgumentException()
        }
        val hmscore = hmsCoreList[uid]
        if (hmscore != null) {
            callback.callback(HMSResult.success(hmscore))
            return
        }
        synchronized(initLock) {
            val config = HMSConfig(context, uid).argu
            if (initIngList.contains(uid)) {
                callback.callback(HMSResult.fail(HMSException(-1, "init failed")))
                return
            } else {
                initIngList.add(uid)
            }
            HMSCore.initialize(config, HMSDisposableCallback {
                when (it) {
                    is HMSResult.Success -> {
                        hmsCoreList[uid] = it.data
                        NewMessageListener(context.applicationContext)
                            .setNewMessageListener(it.data)
                        callback.callback(HMSResult.success(it.data))
                    }
                    is HMSResult.Fail -> {
                        callback.callback(HMSResult.fail(HMSException(-1, "init failed")))
                    }
                }
                initIngList.remove(uid)
            })
        }
    }


    fun deInitHmsCore(uid: String) {
        synchronized(initLock) {
            initIngList.remove(uid)
            hmsCoreList.remove(uid)
        }
    }

    fun getHmsCore(uid: String): HMSCore? {
        return hmsCoreList.get(uid)
    }
}