package com.tencent.hms.sample.fragment

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout
import com.tencent.hms.HMSCore
import com.tencent.hms.HMSDisposableCallback
import com.tencent.hms.HMSListUpdateCallback
import com.tencent.hms.HMSResult
import com.tencent.hms.sample.MainActivity
import com.tencent.hms.sample.MainFragmentDirections
import com.tencent.hms.sample.R
import com.tencent.hms.sample.debug.DebugDialogManager
import com.tencent.hms.sample.debug.DefaultAvatar
import com.tencent.hms.session.HMSSession
import com.tencent.hms.session.HMSSession.Type
import com.tencent.hms.session.HMSSessionListLogic

/**
 * Created by juliandai on 2019/2/18 4:28 PM.
 * talk and show the code
 */
class FriendFragment : MainActivity.BaseFragment(), HMSListUpdateCallback {


    private lateinit var debugDialogManager: DebugDialogManager
    private var adapter: ProfileAdapter? = null
    private var tablayout: TabLayout? = null
    private var dataSource: HMSSessionListLogic? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        debugDialogManager = DebugDialogManager(activity!!, hmsCore)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val rootView = inflater.inflate(R.layout.fragment_friends, container, false)
        rootView.findViewById<View>(R.id.create_single_chat).setOnClickListener {
            debugDialogManager.createSession()
        }

        rootView.findViewById<View>(R.id.create_group_chat).setOnClickListener {
            debugDialogManager.createGroup()
        }

        rootView.findViewById<View>(R.id.enter_chat_room).setOnClickListener {
            debugDialogManager.enterChatRoom()
        }

        tablayout = rootView.findViewById(R.id.tab_layout)
        val recyclerView = rootView.findViewById<RecyclerView>(R.id.session_list_recycler)
        if(adapter == null) {
            adapter = ProfileAdapter(activity!!, {
                if (it.isC2C) {
                    hmsCore.value?.createSession(HMSSession.Type.C2C, listOf(it.uid!!),sessionName = "C2C Sample", callback = HMSDisposableCallback {
                        when (it) {
                            is HMSResult.Success -> {
                                val sid = it.data.sid
                                (activity as AppCompatActivity as MainActivity).navController.navigate(
                                    MainFragmentDirections.actionMainFragmentToChatFragment(sid)
                                )
                            }
                        }
                    })
                } else {
                    (activity as AppCompatActivity as MainActivity).navController.navigate(
                        MainFragmentDirections.actionMainFragmentToChatFragment(it.sid)
                    )
                }
            })

        }
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(activity, RecyclerView.VERTICAL, false)

        tablayout?.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabReselected(tab: TabLayout.Tab?) {
                //do nothing
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                //do nothing
            }

            override fun onTabSelected(tab: TabLayout.Tab?) {
                setViewData()
            }
        })
        return rootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        hmsCore.observe(viewLifecycleOwner, Observer { hms ->
            dataSource = hms.createSessionListLogic()
            dataSource!!.setUpdateCallback(this)
            setViewData()
        })
    }


    private fun setViewData() {
        dataSource?.let {
            val position = tablayout?.selectedTabPosition ?: 0
            if (position == 1) {
                getGroupProfile(it)
            } else {
                if (activity != null) {
                    hmsCore.value?.let { core ->
                        getC2CProfile(core, it)
                    }
                }
            }
        }
    }

    override fun onInserted(position: Int, count: Int) {
        setViewData()
    }

    override fun onRemoved(position: Int, count: Int) {
        setViewData()
    }

    override fun onChanged(position: Int, count: Int) {
        setViewData()
    }

    override fun onDestroy() {
        super.onDestroy()
        dataSource?.dispose()
    }

    fun getGroupProfile(dataSource: HMSSessionListLogic) {
        val profiles = dataSource.toList().filter { it.type == HMSSession.Type.GROUP }.map {
            Profile(sid = it.sid, name = it.name, avatar = it.avatarUrl, isC2C = false).apply {
                showText = "(sid:${sid})${name}"
            }
        }.toList()

        adapter?.setData(profiles)
        adapter?.notifyDataSetChanged()
    }


    fun getC2CProfile(hms: HMSCore, sessionList: HMSSessionListLogic) {
        val data = sessionList.toList()
        val uids = data.filter { it.type == Type.C2C && !it.toUid.isNullOrEmpty() }.map { it.toUid!! }.toList()
        hms.getUsers(uids, HMSDisposableCallback {
            when (it) {
                is HMSResult.Success -> {
                    val ret =
                        it.data.map {
                            val profile = Profile(
                                uid = it.uid,
                                name = it.name ?: "",
                                avatar = it.avatar ?: ""
                            )
                            profile.showText = "${profile.name} (${profile.uid})"
                            profile
                        }.toList()

                    adapter?.setData(ret)
                    adapter?.notifyDataSetChanged()
                }
                is HMSResult.Fail -> {
                    adapter?.setData(listOf())
                    adapter?.notifyDataSetChanged()
                }
            }
        })
    }


}


class ProfileAdapter(
    val activity: Activity,
    val itemClickAction: (Profile) -> Unit,
    val itemLongClickAction: ((View,Profile) -> Unit)? = null
) :
    RecyclerView.Adapter<ProfileViewHolder>(), HMSListUpdateCallback {
    override fun onInserted(position: Int, count: Int) {
        notifyItemRangeInserted(position, count)
    }

    override fun onRemoved(position: Int, count: Int) {
        notifyItemRangeRemoved(position, count)
    }

    override fun onChanged(position: Int, count: Int) {
        notifyItemRangeChanged(position, count)
    }

    private var dataSource: MutableList<Profile> = mutableListOf()

    fun setData(data: List<Profile>) {
        dataSource.clear()
        dataSource.addAll(data)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProfileViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.im_profile_item_layout, parent, false)
        return ProfileViewHolder(activity, view, itemClickAction,itemLongClickAction)
    }

    override fun getItemCount(): Int {
        return dataSource.size
    }

    override fun onBindViewHolder(holder: ProfileViewHolder, position: Int) {
        holder.bind(dataSource[position])
    }

}

class ProfileViewHolder(
    val activity: Activity,
    itemView: View,
    val itemClickAction: (Profile) -> Unit,
    val itemLongClickAction: ((View,Profile) -> Unit)? = null
) :
    RecyclerView.ViewHolder(itemView) {
    val nameText = itemView.findViewById<TextView>(R.id.name_text)
    val avatarView = itemView.findViewById<ImageView>(R.id.avatar_view)
    val defaultAvatar:DefaultAvatar = DefaultAvatar(activity)

    fun bind(profile: Profile) {
        //显示格式 title name(id)[备注]
        nameText.text = "${profile.showText}"

        defaultAvatar.setSessionAvatar(profile.avatar,profile.sid,avatarView)
        itemView.setOnClickListener {
            itemClickAction.invoke(profile)
        }
        itemView.setOnLongClickListener {
            itemLongClickAction?.invoke(it,profile)
            true
        }
    }
}

data class Profile(
    val name: String?,
    val avatar: String? = "",
    val sid: String = "",
    val uid: String = "",
    val isC2C: Boolean = true
) {
    var showText: String? = name
}

