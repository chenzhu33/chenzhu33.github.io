package com.tencent.hms.sample

import android.app.Application
import android.os.StrictMode
import com.facebook.stetho.Stetho
import com.facebook.stetho.inspector.console.RuntimeReplFactory
import com.facebook.stetho.rhino.JsRuntimeReplFactoryBuilder

/**
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2017-11-23
 * Time:   18:47
 * Life with Passion, Code with Creativity.
</pre> *
 */
/*package*/ internal object DebugToolsInitializer {
    fun initDebugTools(context: Application) {
        initStetho(context)

        initStrictMode(context)
    }

    private fun initStrictMode(context: Application) {
        StrictMode.setThreadPolicy(
            StrictMode.ThreadPolicy.Builder()
                .detectAll()
                .build()
        )

        StrictMode.setVmPolicy(
            StrictMode.VmPolicy
                .Builder()
                .detectAll()
                .build()
        )
    }

    private fun initStetho(context: Application) {
        Stetho.initialize(
            Stetho.newInitializerBuilder(context)
                .enableWebKitInspector {
                    Stetho.DefaultInspectorModulesBuilder(context)
                        .runtimeRepl(initRhinoJsEngine(context))
                        .finish()
                }
                .build()
        )
    }

    private fun initRhinoJsEngine(context: Application): RuntimeReplFactory {
        // add functions to be used in js console
        // add anything you like latter
        val builder = JsRuntimeReplFactoryBuilder(context)
            .importPackage("java.lang")
            .importPackage("android.widget")
            .importPackage("android.view")

            .importPackage("com.tencent.radio")

            .addVariable("application", context)


        return builder.build()
    }
}
