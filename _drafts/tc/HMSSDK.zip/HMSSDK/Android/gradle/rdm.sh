#!/bin/bash
#########################################################################
# File Name:		rdm.sh
# Author:			taylorcyang
# e-Mail:			taylorcyang@tencent.com
# Created Time:		Fri Jan 18 15:28:46 2019
#########################################################################

PROJECT_ROOT=$(dirname $0)/..
OUTPUT_DIR=$(pwd)/bin

if [[ -n $WORKSPACE ]]; then
    # configure rdm env
    export ANDROID_HOME=$ANDROID_SDK
    export ANDROID_NDK_HOME=$ANDROIDNDK_LINUX_R10E
    export JAVA_HOME=$JDK8
    export PATH=$JDK8/bin:$PATH
    export IS_CI_BUILD=true

    versionName="${MajorVersion}.${MinorVersion}.${FixVersion}.${BuildNo}"
    OUTPUT_DIR=$(pwd)/bin
else
    export IS_CI_BUILD=false

    versionName="0.9.9"
    OUTPUT_DIR=$PROJECT_ROOT/build/bin
fi

GRADLEW="                                                           \
    ./gradlew                                                       \
    --no-daemon                                                     \
    -PVERSION_NAME=${versionName}                                   \
    -PPUBLISH_VERSION_FILE=$OUTPUT_DIR/maven_artifact_${versionName}.txt  \
"

# compile debug for rdm
#   -PDEBUG_BUILD=false                                             \

function build() {
    # run build
    case $ACTION in
        upload)
            echo "gradle uploadArchives"
            $GRADLEW uploadArchives
            ;;
        *)
            echo "gradle :sample:assembleDebug"
            $GRADLEW :sample:assembleDebug
            # copy artifact
            echo "copy artifact"
            mkdir -p $OUTPUT_DIR
            find sample/build/outputs -name "*.apk" -exec cp {} $OUTPUT_DIR/ \;
            ;;
    esac
}

pushd $PROJECT_ROOT
build
popd

