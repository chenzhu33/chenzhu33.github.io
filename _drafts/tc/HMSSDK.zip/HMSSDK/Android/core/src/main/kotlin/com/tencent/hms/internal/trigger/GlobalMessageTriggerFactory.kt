package com.tencent.hms.internal.trigger

import com.squareup.sqldelight.db.SqlDriver
import com.tencent.hms.internal.repository.model.Message_table_write_log

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-07
 * Time:   21:06
 * Life with Passion, Code with Creativity.
 * ```
 */

internal class GlobalMessageTriggerFactory(triggerManager: TriggerManager) :
    SingleInstanceTriggerFactory<List<Message_table_write_log>>(triggerManager) {

    override val type: TriggerManager.TriggerType
        get() = TriggerManager.TriggerType.GLOBAL_MESSAGE

    override fun create(triggerManager: TriggerManager): Trigger<List<Message_table_write_log>> {
        return object : Trigger<List<Message_table_write_log>>(triggerManager) {
            override val type: TriggerManager.TriggerType
                get() = TriggerManager.TriggerType.GLOBAL_MESSAGE

            override fun install(db: SqlDriver) {
                triggerManager.temporaryTriggersQueries.run {
                    installGlobalMessageTriggerLogTable()
                    installGlobalMessageInsertTrigger()
                    installGlobalMessageUpdateTrigger()
                }
            }

            override fun uninstall(db: SqlDriver) {
                triggerManager.temporaryTriggersQueries.run {
                    uninstallGlobalMessageTriggerLogTable()
                    uninstallGlobalMessageInsertTrigger()
                    uninstallGlobalMessageUpdateTrigger()
                }
            }

            override fun process(db: SqlDriver) {
                triggerManager.temporaryTriggersQueries.let {
                    val messages: List<Message_table_write_log> =
                        it.queryGlobalMessageLog().executeAsList()

                    if (messages.isNotEmpty()) {
                        callback(messages)
                        it.clearGlobalMessageLog()
                    }
                }
            }
        }
    }
}

