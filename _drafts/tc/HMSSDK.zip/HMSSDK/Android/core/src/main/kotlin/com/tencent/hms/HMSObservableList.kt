package com.tencent.hms


/**
 * <pre>
 * Author: landerlyoung@gmail.com
 * Date:   2019-02-28
 * Time:   20:15
 * Life with Passion, Code with Creativity.
 * </pre>
 */


interface HMSObservableList<T> {


    val size: Int

    operator fun get(index: Int): T

    fun setUpdateCallback(callback: HMSListUpdateCallback?)

    fun snapshot(): List<T> {
        val list = ArrayList<T>(size)
        for (i in 0 until size) {
            list.add(this[i])
        }
        return list
    }

    /*
    fun compose(
        other: HMSObservableList<T>,
        comparator: Comparator<T>
    ): HMSObservableList<T> = HMSComposedObservableList(this, other, comparator)

    fun <R> map(transform: (T) -> R): HMSObservableList<R> {
        TODO()
    }

    fun filter() {
    }
    */

}


/**
 * An interface that can receive Update operations that are applied to a list.
 *
 * This class can be used together with DiffUtil to detect changes between two lists.
 */
interface HMSListUpdateCallback {
    /**
     * Called when `count` number of items are inserted at the given position.
     *
     * @param position The position of the new item.
     * @param count    The number of items that have been added.
     */
    fun onInserted(position: Int, count: Int)

    /**
     * Called when `count` number of items are removed from the given position.
     *
     * @param position The position of the item which has been removed.
     * @param count    The number of items which have been removed.
     */
    fun onRemoved(position: Int, count: Int)

    /**
     * Called when `count` number of items are updated at the given position.
     *
     * @param position The position of the item which has been updated.
     * @param count    The number of items which has changed.
     */
    fun onChanged(position: Int, count: Int)
}

class HMSObservableMutableList<T> : AbstractMutableList<T>(), HMSObservableList<T> {

    private val underlay = object : ArrayList<T>() {
        // make it public
        public override fun removeRange(fromIndex: Int, toIndex: Int) {
            super.removeRange(fromIndex, toIndex)
        }
    }

    private var updateCallback: HMSListUpdateCallback? = null

    override val size: Int
        get() = underlay.size

    override fun get(index: Int): T =
        underlay[index]

    override fun setUpdateCallback(callback: HMSListUpdateCallback?) {
        updateCallback = callback
    }

    override fun snapshot(): List<T> {
        return underlay.toList()
    }

    override fun add(index: Int, element: T) {
        underlay.add(index, element)
        updateCallback?.onInserted(index, 1)
    }

    override fun addAll(index: Int, elements: Collection<T>): Boolean =
        underlay.addAll(index, elements).also {
            if (it) {
                updateCallback?.onInserted(index, elements.size)
            }
        }

    override fun addAll(elements: Collection<T>): Boolean {
        return addAll(size, elements)
    }

    override fun removeAt(index: Int): T {
        return underlay.removeAt(index).also {
            updateCallback?.onRemoved(index, 1)
        }
    }

    public override fun removeRange(fromIndex: Int, toIndex: Int) {
        underlay.removeRange(fromIndex, toIndex)
        updateCallback?.onRemoved(fromIndex, toIndex - fromIndex)
    }

    override fun set(index: Int, element: T): T {
        return underlay.set(index, element).also {
            updateCallback?.onChanged(index, 1)
        }
    }
}

/*
// todo: half done
private class HMSComposedObservableList<T>(
    private val first: HMSObservableList<T>,
    private val second: HMSObservableList<T>,
    private val _comparator: Comparator<T>
) : HMSObservableList<T> {

    private val underlay = ArrayList<Node<T>>()

    override var updateCallback: HMSListUpdateCallback? = null

    private val comparator: Comparator<Node<T>> = Comparator { o1, o2 ->
        _comparator.compare(o1.data, o2.data)
    }

    override val size: Int
        get() = underlay.size

    override fun get(index: Int): T =
        underlay[index].data

    override fun snapshot(): List<T> {
        return underlay.map { it.data }
    }

    private data class Node<T>(
        val data: T,
        val index: Int
    ) {
        inline val isFirst: Boolean
            get() = index < 0

        inline val firstIndex
            get() = -index - 1

        @Suppress("NOTHING_TO_INLINE")
        companion object {
            inline fun <T> first(data: T, index: Int) = Node(data, -(index + 1))

            inline fun <T> second(data: T, index: Int) = Node(data, index)
        }
    }


    private inner abstract class UpdateCallback : HMSListUpdateCallback {
        override fun onInserted(position: Int, count: Int) {
            for (i in 0 until count) {
                onInsert(position + i)
            }
        }

        override fun onRemoved(position: Int, count: Int) {
            for (i in 0 until count) {
                onRemoved(position + i)
            }
        }

        override fun onChanged(position: Int, count: Int) {
            for (i in 0 until count) {
                onChanged(position + i)
            }
        }

        fun onInsert(position: Int) {
            val index = underlay.binarySearch {
                _comparator.compare(it.data, first[position])
            }
            if (index > 0) {
                underlay.add(index, Node.first(first[position], position))
                //
            }

        }

        fun onRemoved(position: Int) {
            val index = underlay.binarySearch {
                _comparator.compare(it.data, first[position])
            }
        }

        fun onChanged(position: Int) {

        }

        abstract fun findComposedIndex(position: Int): Int
        abstract fun isForList(node: Node<T>): Boolean
        abstract fun index(node: Node<T>): Int

    }

    init {
        val combined = first.snapshot().mapIndexed { index, t -> Node.first(t, index) } +
                second.snapshot().mapIndexed { index, t -> Node.second(t, index) }
        underlay.addAll(combined.sortedWith(comparator))

        first.updateCallback = object : UpdateCallback() {
            override fun isForList(node: Node<T>) = node.isFirst
            override fun index(node: Node<T>): Int = node.firstIndex
            override fun findComposedIndex(position: Int): Int {
                underlay.binarySearch { }
            }
        }

        second.updateCallback = object : UpdateCallback() {
            override fun isForList(node: Node<T>) = !node.isFirst
            override fun index(node: Node<T>): Int = node.index
        }

    }
}
*/

