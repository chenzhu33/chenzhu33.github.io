@file:JvmName("HMSCommon")

package com.tencent.hms

import java.net.URI

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-02-19
 * Time:   10:55
 * Life with Passion, Code with Creativity.
 * ```
 */


/**
 * HMS 离线push的scheme有格式约定，算法是：
 *
 * ```
 * "hms" + appid + "://hms/push?sid=" + sessionId
 * ```
 * 离线push的通知，点击会open这个scheme，业务侧的实现要能够处理该scheme
 * @see parseSchemeUri
 */
fun makeSchemeUri(appid: String, sessionId: String): String =
    "hms$appid://hms/push?sid=$sessionId"

/**
 *
 * 离线push的通知，点击会open HMS 约定的scheme，业务侧的实现要能够处理该scheme。
 * 通过这个方法来解析该scheme，并返回scheme的`sid`参数（即:session id)
 *
 * @return session id if this uri is valid hms uri and the app id matches.
 *
 * @see makeSchemeUri
 */
fun parseSchemeUri(appid: String, uriString: String): String? {
    val uri = URI(uriString)
    if (uri.scheme == "hms$appid") {
        uri.query.split('&').forEach { param ->
            param.split('=').let {
                if (it.size == 2 && it.first() == "sid") {
                    return it[1]
                }
            }
        }
    }

    return null
}

/** 针对允许部分更新的接口，当其中某个参数不需要更新时，可以使用该占位符，SDK内部更新时就会忽略该字段（不更新该字段） */
@get:JvmName("STRING_PLACEHOLDER")
val STRING_PLACEHOLDER: String = String("STRING_PLACEHOLDER".toCharArray()) // make sure this string has a unique instance (ie. not in constant pool)

/** 针对允许部分更新的接口，当其中某个参数不需要更新时，可以使用该占位符，SDK内部更新时就会忽略该字段（不更新该字段） */
@get:JvmName("ANY_PLACEHOLDER")
val ANY_PLACEHOLDER: Any = Any()

/**
 * 针对允许部分更新的接口，当其中某个参数不需要更新时，可以使用该占位符，SDK内部更新时就会忽略该字段（不更新该字段）, Int 的占位符本质上就是 null
 */
@get:JvmName("INT_PLACEHOLDER")
val INT_PLACEHOLDER: Int? = null

private val _LIST_PLACEHOLDER: List<*> =
    ArrayList<Any>(0)

/** 针对允许部分更新的接口，当其中某个参数不需要更新时，可以使用该占位符，SDK内部更新时就会忽略该字段（不更新该字段） */
@Suppress("UNCHECKED_CAST")
fun <T> LIST_PLACEHOLDER(): List<T> = _LIST_PLACEHOLDER as List<T>

/** 针对允许部分更新的接口，当其中某个参数不需要更新时，可以使用该占位符，SDK内部更新时就会忽略该字段（不更新该字段） */
@get:JvmName("BYTE_ARRAY_PLACEHOLDER")
internal val BYTE_ARRAY_PLACEHOLDER: ByteArray = byteArrayOf()

/** 前后台协商的@All的字符串 */
val AT_ALL: String = "all"