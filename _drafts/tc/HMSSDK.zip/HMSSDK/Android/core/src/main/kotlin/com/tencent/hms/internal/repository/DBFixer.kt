package com.tencent.hms.internal.repository

import com.tencent.hms.HMSCore
import com.tencent.hms.internal.DBWrite
import com.tencent.hms.message.HMSMessageStatus
import kotlinx.coroutines.withContext

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-02-25
 * Time:   19:59
 * Life with Passion, Code with Creativity.
 * ```
 */

internal suspend fun HMSCore.fixDirtyRecordsInDatabase() {
    withContext(DBWrite) {
        database.transaction {
            fixSessionData()
            fixMessageStatus()
        }
    }
}

/**
 * change all sending message to sendFailed
 */
private fun HMSCore.fixMessageStatus() {
    database.messageDBQueries.changeAllMessageStatus(
        HMSMessageStatus.SEND_FAILED.value,
        HMSMessageStatus.SENDING.value
    )

}

/**
 * 修复session数据，disable session storage相关的数据都需要清理
 */
private fun HMSCore.fixSessionData() {
    database.sessionDBQueries.queryDisableStorage().executeAsList().forEach {
        database.messageDBQueries.deleteLocalMessagesBySid(it.sid)
        database.sessionDBQueries.deleteSessionBysSids(listOf(it.sid))
        database.userInSessionDBQueries.deleteUserInSessionBySid(it.sid, uid)
    }
}