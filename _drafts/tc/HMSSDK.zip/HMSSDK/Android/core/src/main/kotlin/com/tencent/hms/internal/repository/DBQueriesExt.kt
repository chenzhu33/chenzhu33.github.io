package com.tencent.hms.internal.repository

import com.tencent.hms.AT_ALL
import com.tencent.hms.BYTE_ARRAY_PLACEHOLDER
import com.tencent.hms.HMSCore
import com.tencent.hms.HMSIllegalServerResponseException
import com.tencent.hms.internal.assertServerData
import com.tencent.hms.internal.decode
import com.tencent.hms.internal.message.MessageReceiveManager
import com.tencent.hms.internal.pb
import com.tencent.hms.internal.protocol.*
import com.tencent.hms.internal.repository.model.*
import com.tencent.hms.internal.transactionWithResult
import com.tencent.hms.message.HMSControlElement
import com.tencent.hms.message.HMSMessageIndex
import com.tencent.hms.message.HMSMessageStatus
import kotlin.math.max

/**
 * Created by juliandai on 2019/1/9.
 * Comment:SessionDBQueries和MessageDBQueries的扩展方法
 */
//message list from net to db

internal fun HMSCore.insertOrUpdateMessages(list: List<Message>) {
    //先查DB是否有重复
    val messageDB = database.messageDBQueries
    val hasExistMessages = messageDB.queryMessagesExistance(list.mapNotNull { it.clientKey })
        .executeAsList().associate { it.client_key to it }.toMutableMap()

    messageDB.transaction {
        list.forEach {
            val msgInDB = hasExistMessages[it.clientKey]

            val updateCondition = msgInDB != null &&
                    ((msgInDB.sequence.pb == 0L) || (msgInDB.sequence.pb == it.sequence && msgInDB.update_timestamp.pb < it.updateTimestamp.pb))

            val insertCondition = (msgInDB == null) ||
                    (msgInDB.sequence.pb != 0L && msgInDB.sequence.pb != it.sequence)

            if (updateCondition) {
                messageDB.updateMessageInfoByClientKey(
                    it.type.pb.toLong(),
                    HMSMessageStatus.SUCCESS.value,
                    it.messageTimestamp.pb,
                    it.updateTimestamp.pb,
                    it.element.isControl(),
                    it.isRevoked.pb,
                    it.text!!,
                    it.element?.encode(),
                    it.reminds?.encode(),
                    it.sequence!!,
                    it.countSequence.pb,
                    it.revokeNumber.pb,
                    it.clientKey!!
                )
                hasExistMessages[it.clientKey] = QueryMessagesExistance.Impl(
                    it.clientKey,
                    it.sequence,
                    it.messageTimestamp.pb,
                    it.updateTimestamp.pb
                )
            } else if (insertCondition) {
                // client key 相等，sequence不等，后台的bug，需要重写client key入库这条消息，且设置为不可见
                val isFakeMsg = if (msgInDB == null) false else (msgInDB.sequence.pb != it.sequence)
                val clientKey = if (isFakeMsg) "${it.clientKey}_fake_${it.sequence}" else it.clientKey!!
                val deleteStatus = isFakeMsg || HMSControlElement.isInternalControlMessage(it)

                messageDB.insertMessage(
                    it.sessionID!!,
                    it.messageTimestamp.pb,
                    it.sender?.uid.pb,
                    it.type.pb.toLong(),
                    it.element.isControl(),
                    it.isRevoked.pb,
                    deleteStatus,
                    it.text!!,
                    it.element?.encode(),
                    it.reminds?.encode(),
                    it.sequence!!,
                    it.countSequence.pb,
                    clientKey,
                    it.sequence,
                    it.revokeNumber.pb,
                    it.updateTimestamp.pb
                )
                hasExistMessages[clientKey] =
                    QueryMessagesExistance.Impl(clientKey, it.sequence, it.messageTimestamp.pb, it.updateTimestamp.pb)
            }
            if (updateCondition || insertCondition) {
                if (it.element.isControl()) {
                    processControlMessages(it)
                }
            }
        }
    }
}

private fun HMSCore.processControlMessages(it: Message) {
    try {
        assertServerData {
            when (val control = (it.element?.element as? MessageElement.Element.Control)?.control?.control) {
                is ControlElement.Control.Revoke -> {
                    processMessageRevoke(
                        it.sessionID!!,
                        control,
                        it.sequence.pb,
                        control.revoke.revokedMessageSequence.pb,
                        it.revokeNumber.pb
                    )
                }
                is ControlElement.Control.Update -> {
                    processMessageUpdate(control, it.sessionID!!, it.messageTimestamp!!)
                }
                is ControlElement.Control.SystemAlert -> {
                    val session = when (val alertData = control.systemAlert.alertData) {
                        is ControlElement.SystemAlertElement.AlertData.JoinSession -> alertData.joinSession.session
                        is ControlElement.SystemAlertElement.AlertData.ExitSession -> alertData.exitSession.session
                        is ControlElement.SystemAlertElement.AlertData.DeleteFromSession -> alertData.deleteFromSession.session
                        is ControlElement.SystemAlertElement.AlertData.BecomeOwner -> alertData.becomeOwner.session
                        is ControlElement.SystemAlertElement.AlertData.SessionInfoChange -> alertData.sessionInfoChange.session
                        is ControlElement.SystemAlertElement.AlertData.DestroySession -> alertData.destroySession.session
                        else -> null
                    }
                    // 如果收到的是自己主动退群和解散群的系统消息，那么为了防止是延迟的消息，这里再主动删群一次
                    if ((control.systemAlert.alertData is ControlElement.SystemAlertElement.AlertData.ExitSession && control.systemAlert.alertData.exitSession.exitUser?.user?.uid == uid)
                        || control.systemAlert.alertData is ControlElement.SystemAlertElement.AlertData.DestroySession && control.systemAlert.alertData.destroySession.executor?.user?.uid == uid) {
                        deleteSession(session?.sessionBasicInfo?.sid!!, null)
                    } else {
                        database.sessionDBQueries.insertOrUpdate(session)
                    }
                }
                else -> {
                    // unknown control message element
                }
            }
        }
    } catch (e: HMSIllegalServerResponseException) {
        logger.e(MessageReceiveManager.TAG, e) { "processControlMessage failed" }
    }
}

private fun HMSCore.processMessageRevoke(
    sid: String,
    control: ControlElement.Control.Revoke,
    revokeControlSeq: Long,
    revokedMsgSeq: Long,
    revokeNum: Long
) {
    database.messageDBQueries.markMessageRevoked(sid, control.revoke.revokedMessageSequence!!)
    //回溯revoke num
    database.messageDBQueries.updateRevokeNum(revokeNum, sid, revokeControlSeq, revokedMsgSeq)
}

private fun HMSCore.processMessageUpdate(
    control: ControlElement.Control.Update,
    sid: String,
    messageUpdateTimestamp: Long
) {
    val content = control.update.updateContent!!
    database.messageDBQueries.updateMessageContentBySequence(
        content.type.pb.toLong(),
        content.text!!,
        content.payload?.let {
            MessageElement(MessageElement.Element.Payload(it))
        }?.encode(),
        messageUpdateTimestamp,
        control.update.updatedMessageSequence!!,
        sid
    )
}

internal fun UserDBQueries.insertOrUpdateUsers(list: List<User>) {
    // remove duplicated data
    val users = list.filter { it.uid != null }
    val uids = users.map { it.uid!! }.distinct()

    transaction {
        val hasExistUsers = queryUserByUids(uids).executeAsList().map { it.uid to it }.toMap()
        users.forEach {
            val userdb = hasExistUsers[it.uid]
            if (userdb != null) {
                val newInfo = it
                if (newInfo.updateTimestamp.pb > userdb.update_timestamp.pb) {
                    // update
                    updateUser(
                        newInfo.name,
                        newInfo.avatarUrl,
                        newInfo.remark,
                        newInfo.businessBuffer?.toByteArray(),
                        newInfo.updateTimestamp.pb,
                        newInfo.uid!!
                    )
                }
            } else {
                // insert
                insertUser(
                    it.uid.pb,
                    it.name,
                    it.avatarUrl,
                    it.remark,
                    it.businessBuffer?.toByteArray(),
                    it.updateTimestamp
                )
            }
        }
    }
}

internal fun MessageDBQueries.queryMessagesByIndex(sid: String, indexList: List<HMSMessageIndex>): List<MessageDB> {
    return transactionWithResult {
        indexList.map {
            queryMessageByLocalSequence(it.localSequence, it.helpSequence, sid)
                .executeAsOne()
        }
    }
}

internal fun UserInSessionDBQueries.insertOrUpdateUserInSessions(list: List<UserInSession>) {
    transaction {
        list.filter { it.sid != null && it.uid != null }.forEach { newInfo ->
            val oldInfo = queryBySidUid(newInfo.sid!!, newInfo.uid!!).executeAsOneOrNull()
            if (oldInfo != null) {
                if (newInfo.updateTimestamp.pb > oldInfo.update_timestamp.pb) {
                    updateUserInSessionByUid(
                        newInfo.remarks,
                        newInfo.businessBuffer?.toByteArray() ?: oldInfo.busi_session_buff,
                        newInfo.updateTimestamp ?: oldInfo.update_timestamp,
                        newInfo.banExpirationTimestamp,
                        newInfo.sid,
                        newInfo.uid
                    )
                }
            } else {
                insertUserInSession(
                    newInfo.uid,
                    newInfo.sid,
                    newInfo.remarks,
                    newInfo.businessBuffer?.toByteArray(),
                    newInfo.joinTimestamp.pb,
                    newInfo.updateTimestamp,
                    newInfo.banExpirationTimestamp
                )
            }
        }
    }
}


/**
 * session from net to db
 */
internal fun SessionDBQueries.insertOrUpdate(session: Session?) {
    if (session != null) {
        transaction {
            val hasSession = querySessionExistanceBySid(session.sessionBasicInfo!!.sid!!).executeAsOneOrNull() != null
            if (!hasSession) insertSession(session) else updateSessionNet(session)
        }
    }
}

private fun SessionDBQueries.insertSession(session: Session) {
    val basicInfo = session.sessionBasicInfo!!
    val sequenceInfo = session.userInSessionSequence
    val userRelatedInfo = session.userRelatedSessionInfo
    insertSession(
        basicInfo.sid!!,
        basicInfo.type?.value.pb.toLong(),
        basicInfo.name,
        basicInfo.avatarUrl,
        basicInfo.businessBuffer?.toByteArray(),
        basicInfo.toUid,
        basicInfo.ownerUid,
        basicInfo.createTimestamp.pb,
        basicInfo.isDestroy,
        basicInfo.memberNumber.pb.toLong(),
        basicInfo.updateTimestamp.pb,

        sequenceInfo?.maxSequence.pb,
        sequenceInfo?.readMaxSequence.pb,
        sequenceInfo?.visibleSequence.pb,

        userRelatedInfo?.friendType.pb.toLong(),
        userRelatedInfo?.msgAlertType?.value.pb.toLong(),
        userRelatedInfo?.updateTimestamp.pb,

        sequenceInfo?.reminds?.encode(),
        BYTE_ARRAY_PLACEHOLDER
    )
}

private fun SessionDBQueries.updateSessionNet(session: Session) {
    val basicInfo = session.sessionBasicInfo!!
    val sequenceInfo = session.userInSessionSequence
    val userRelatedInfo = session.userRelatedSessionInfo

    updateSessionBasicInfo(
        basicInfo.name,
        basicInfo.avatarUrl,
        basicInfo.businessBuffer?.toByteArray(),
        basicInfo.toUid,
        basicInfo.ownerUid,
        basicInfo.createTimestamp.pb,
        basicInfo.isDestroy,
        basicInfo.memberNumber.pb.toLong(),
        basicInfo.updateTimestamp.pb,
        basicInfo.sid!!,
        basicInfo.updateTimestamp.pb
    )

    if (userRelatedInfo != null) {
        updateSessionUserRelatedInfo(
            userRelatedInfo.friendType.pb.toLong(),
            userRelatedInfo.msgAlertType?.value.pb.toLong(),
            userRelatedInfo.updateTimestamp.pb,
            basicInfo.sid
        )
    }

    if (sequenceInfo != null) {
        updateSessionMaxSequence(sequenceInfo.maxSequence.pb, basicInfo.sid)
        updateSessionReadMaxSequence(sequenceInfo.readMaxSequence.pb, basicInfo.sid)
        updateSessionVisibleSequence(sequenceInfo.visibleSequence.pb, basicInfo.sid)
        updateServerReminds(basicInfo.sid, sequenceInfo.reminds?.encode())
    }
}

internal fun SessionDBQueries.insertOrUpdateLocalReminds(
    messages: List<Message>?,
    me: String
): HashMap<String, List<Long>> {
    val resultMap = HashMap<String, List<Long>>()
    transaction {
        val messageMap = HashMap<String, MutableList<Long>>()

        // 先过滤一遍是否@我的
        messages?.forEach {
            val seqList = messageMap[it.sessionID] ?: ArrayList()
            val isAtMe = it.reminds?.uids?.contains(me) == true || it.reminds?.uids?.contains(AT_ALL) == true
            if (it.sequence != null && !seqList.contains(it.sequence) && isAtMe) seqList.add(it.sequence)
            messageMap[it.sessionID!!] = seqList
        }

        messageMap.forEach { entry ->
            val sid = entry.key
            val messageUnreadRemindSeqs = entry.value
            val session = queryLocalReminds(sid).executeAsOneOrNull()
            if (session != null) {
                val maxReadSeq =
                    max(session.visible_sequence, max(session.read_max_sequence, session.local_read_sequence))
                val dbLocalRemindSeqs =
                    session.local_reminds?.decode(UserInSessionSequence.Reminds.ADAPTER)?.unreadRemindSequence?.filter { it > maxReadSeq }
                        ?: emptyList()
                var updateList: List<Long> = emptyList()
                if (messageUnreadRemindSeqs.isEmpty()) {
                    updateList = dbLocalRemindSeqs
                } else {
                    if (dbLocalRemindSeqs.isEmpty()) {
                        updateList = messageUnreadRemindSeqs
                    } else if (!dbLocalRemindSeqs.containsAll(messageUnreadRemindSeqs)) {
                        updateList = listOf(
                            dbLocalRemindSeqs,
                            messageUnreadRemindSeqs.filter { !(dbLocalRemindSeqs.contains(it)) })
                            .flatMap { it.asIterable() }.sorted()
                    }
                }
                if (updateList.isNotEmpty()) {
                    resultMap[sid] = updateList
                }
                updateLocalReminds(sid, updateList.let { UserInSessionSequence.Reminds(updateList).encode() })
            }
        }
    }
    return resultMap
}


internal fun MessageElement?.isControl(): Boolean {
    return this?.element is MessageElement.Element.Control
}





