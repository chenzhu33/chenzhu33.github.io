package com.tencent.hms.message

import com.tencent.hms.*
import com.tencent.hms.internal.DBWrite
import com.tencent.hms.internal.assertServerData
import com.tencent.hms.internal.makeHeader
import com.tencent.hms.internal.protocol.GetRangeMessageReq
import com.tencent.hms.internal.protocol.GetRangeMessageRsp
import com.tencent.hms.internal.repository.insertOrUpdateMessages
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max

/*
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-21
 * Time:   11:38
 * Life with Passion, Code with Creativity.
 * </pre>
 */


/**
 * 创建一个消息列表，用于业务侧实现一个聊天页面
 * @see HMSCore.createMessageListLogic
 */
class HMSMessageListLogic internal constructor(
    hmsCore: HMSCore,
    sid: String,
    startIndex: HMSMessageIndex?,
    pageSize: Int,
    prefetchDistance: Int,
    maxListSize: Int,
    configCompleteHoles: Boolean,
    _messageFilter: ((HMSMessage) -> Boolean)? = null
) : HMSDisposable, HMSObservableList<HMSMessage> {


    init {
        /*
         * 约定：
         * 0. pageSize > 0
         * 1. prefetchDistance >= 0 && < pageSize
         * 2. maxListSize > pageSize
         */
        if (pageSize <= 0) {
            throw IllegalArgumentException("invalid pageSize:$pageSize, must >= 0")
        }
        if (prefetchDistance >= pageSize) {
            throw IllegalArgumentException("invalid prefetchDistance:$prefetchDistance, must < pageSize($pageSize)")
        }
        if (maxListSize < pageSize) {
            throw IllegalArgumentException("invalid maxListSize:$maxListSize, must > pageSize($pageSize)")
        }

        // try to fetch latest message on create
        hmsCore.hmsScope.launch {
            try {
                assertServerData {
                    val localMaxSeq = hmsCore.database.sessionDBQueries.queryMaxSequenceBySids(listOf(sid))
                        .executeAsOneOrNull()?.max_sequence
                    val visible_seq = hmsCore.database.sessionDBQueries.querySessionVisibleSequence(sid)
                        .executeAsOneOrNull()

                    val rsp = hmsCore.sendRequestWithRetry(
                        HMSRequestType.GetRangeMessage,
                        GetRangeMessageReq(
                            hmsCore.makeHeader(),
                            sid,
                            ranges = listOf(
                                GetRangeMessageReq.Range(
                                    max(localMaxSeq ?: 0L + 1L, visible_seq ?: 0L),
                                    Long.MAX_VALUE
                                )
                            )
                        ),
                        GetRangeMessageRsp.ADAPTER
                    )

                    withContext(hmsCore.DBWrite) {
                        hmsCore.insertOrUpdateMessages(rsp.messages)
                    }
                }
            } catch (e: HMSException) {
                hmsCore.logger.w("HMSMessageListLogic") { "failed to get latest message for session $sid" }
            }
        }
    }

    private var implementationObservable = HMSObservableData(
        hmsCore.executors,
        HMSMessageListLogicImpl(
            hmsCore,
            sid,
            startIndex,
            pageSize,
            prefetchDistance,
            maxListSize,
            configCompleteHoles,
            _messageFilter
        )
    )

    private inline val implementation: HMSMessageListLogicImpl
        get() = implementationObservable.data!!

    private var updateCallback: HMSListUpdateCallback? = null

    /**
     * get message range of current listPair.
     * from new to old
     * @throws NoSuchElementException when [size] is zero.
     */
    val range: HMSMessageRange
        get() = implementation.range

    override fun setUpdateCallback(callback: HMSListUpdateCallback?) {
        updateCallback = callback
        implementation.setUpdateCallback(callback)
    }

    /**
     * get message list size
     */
    override val size: Int
        get() = implementation.size

    /**
     * get message at index
     */
    override operator fun get(index: Int): HMSMessage =
        implementation[index]

    /**
     * 历史消息的加载进度
     */
    val historyMessageLoadStatus: HMSObservableData<LoadStatus> =
        implementationObservable.switchMap { it.historyMessageLoadStatus }

    /**
     * 新消息的加载进度
     */
    val newMessageLoadStatus: HMSObservableData<LoadStatus> =
        implementationObservable.switchMap { it.newMessageLoadStatus }

    /**
     * 当前是否有新消息空洞：当会话消息过于活跃，有太多消息同时发出时，客户端因为网络等原因不可能一次性全部接受到；此时就会产生新消息空洞。
     * 为了保证消息的连续展示，在这种情况下，开发者有两个选择：
     * 1. 当用户滚动到最新的消息时，利用 [loadMoreNewMessages] （可能是开发者手动调用，也可能是自动预拉取）一页一页的拉取最新消息。
     * 2. 如果用户想直接跳转到最新的消息，而忽略中间未被加载的部分消息，开发者可以使用 [reload] 重新加载。中间被忽略的部分消息将会当成历史消息，
     * 往回看历史消息时可以再利用 [loadMoreHistoryMessages] 加载回来，即：消息始终不会丢失。
     *
     */
    val hasDiscontinuousNewMessages: HMSObservableData<Boolean> =
        implementationObservable.switchMap { it.hasDiscontinuousNewMessages }

    fun loadMoreNewMessages() {
        implementation.loadMoreNewMessages()
    }

    fun loadMoreHistoryMessages() {
        implementation.loadMoreHistoryMessages()
    }

    /**
     * 销毁该实例，避免内存泄漏
     */
    override fun dispose() {
        updateCallback = null
        implementation.dispose()
    }

    /**
     * 重新加载该session的消息列表，仍然沿用创建时指定的配置.
     * 当创建时指定了 startIndex，将从该位置重新加载
     * @see [HMSCore.createMessageListLogic]
     */
    fun reload() {
        reloadWithStartIndex(implementation.startIndex)
    }

    /**
     * 重新从startIndex位置加载该session的消息列表，出startIndex外，其他仍然沿用创建时指定的配置.
     * @param startIndex 指定开始加载的消息位置，null 表示从该会话最新的消息开始加载0
     * @see [HMSCore.createMessageListLogic]
     */
    fun reloadWithStartIndex(startIndex: HMSMessageIndex?) {
        if (implementation.disposed) {
            // we don't reload disposed instance
            return
        }
        val old = implementation
        old.dispose()
        implementationObservable.setData(
            HMSMessageListLogicImpl(
                old.hmsCore,
                old.sid,
                startIndex,
                old.pageSize,
                old.prefetchDistance,
                old.maxListSize,
                old.configCompleteHoles,
                old._messageFilter
            ).also {
                it.setUpdateCallback(updateCallback)
            }
        )
    }

    sealed class LoadStatus {
        object IDLE : LoadStatus() {
            override fun toString(): String {
                return "LoadStatus.IDLE"
            }
        }

        object LOADING : LoadStatus() {
            override fun toString(): String {
                return "LoadStatus.LOADING"
            }
        }

        class FAILED(val error: HMSException) : LoadStatus() {
            override fun toString(): String {
                return "LoadStatus.FAILED ${error.message}"
            }
        }
    }

}

