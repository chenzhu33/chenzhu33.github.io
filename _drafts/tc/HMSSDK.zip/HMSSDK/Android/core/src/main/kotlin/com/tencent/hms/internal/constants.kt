package com.tencent.hms.internal

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-10
 * Time:   13:47
 * Life with Passion, Code with Creativity.
 * ```
 */

internal const val REQUEST_TIMEOUT_MILLIS = 60_000L
internal const val REQUEST_RETRY_COUNT = 3

internal const val COMMON_ERROR_CODE = -1

internal const val INVALID_SESSION_ERROR_CODE = -10001

internal const val HMS_DB_WRITE_THREAD_NAME = "HmsDbWrite"