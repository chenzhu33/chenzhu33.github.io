package com.tencent.hms.internal.session

import com.tencent.hms.*
import com.tencent.hms.internal.*
import com.tencent.hms.internal.protocol.*
import com.tencent.hms.internal.repository.insertOrUpdate
import com.tencent.hms.internal.repository.insertOrUpdateUserInSessions
import com.tencent.hms.internal.repository.model.MessageDB
import com.tencent.hms.internal.repository.model.SessionDB
import com.tencent.hms.internal.repository.model.Session_table_log
import com.tencent.hms.internal.trigger.TriggerManager
import com.tencent.hms.message.HMSMessage
import com.tencent.hms.profile.HMSMemberInfo
import com.tencent.hms.profile.HMSUser
import com.tencent.hms.profile.HMSUserInSession
import com.tencent.hms.session.HMSAddToSessionResultItem
import com.tencent.hms.session.HMSDeleteSessionMemberResultItem
import com.tencent.hms.session.HMSMessageAlertType
import com.tencent.hms.session.HMSSession
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okio.ByteString

/**
 * Created by juliandai on 2019/1/10 4:23 PM.
 * talk and show the code
 *
 * SessionManager
 */
internal class SessionManager(private val hmsCore: HMSCore) {

    companion object {
        const val TAG: String = "SessionManager"
    }

    private val dataManager = SessionDataManager(hmsCore)

    fun dispose() {
        dataManager.dispose()
    }

    internal suspend fun init() {
        dataManager.initSessionList()
    }

    fun onNetworkStatusChange(connected: Boolean) {
        dataManager.onNetworkStatusChange(connected)
    }

    fun onForegroundStatusChange(isForeground: Boolean) {
        dataManager.onForegroundStatusChange(isForeground)
    }


    internal fun addSessionsChangeListener(listener: SessionsChangeListener) {
        dataManager.addSessionChangeListener(listener)
    }

    internal fun removeSessionChangeListener(listener: SessionsChangeListener) {
        dataManager.removeSessionChangeListener(listener)
    }


    suspend fun disableStorage(sids: List<String>) {
        withContext(hmsCore.DBWrite) {
            hmsCore.database.sessionDBQueries.disableStorageBySids(sids)
        }
    }

    internal fun getUnreadCountBySession(session: SessionDB): Long {
        return dataManager.unreadCountCache.getCountBySession(session)
    }

    val unreadCountCache: SessionDataManager.UnreadCountCache = dataManager.unreadCountCache

    internal suspend fun getSessionListBySids(
        sids: List<String>,
        withCount: Boolean = false,
        withMsg: Boolean = false
    ): List<HMSSession> {
        val totalList = mutableListOf<HMSSession>()

        // db first
        val dataInDB = hmsCore.database.sessionDBQueries.querySessionBySids(sids)
            .executeAsList().map { sessionDB ->
                val message: MessageDB? = if (withMsg)
                    hmsCore.database.messageDBQueries.queryLastOneMessageBySidDesc(sessionDB.sid)
                        .executeAsOneOrNull() else null

                val unread = if (withCount) dataManager.unreadCountCache.getCountBySession(sessionDB) else 0L

                HMSSession.fromDB(
                    sessionDB,
                    unread,
                    message?.let { HMSMessage.fromDB(it, hmsCore) },
                    hmsCore.serializer
                )
            }

        totalList.addAll(dataInDB)

        if (totalList.size < sids.size) {
            try {
                assertServerData(message = "GetSessionInfo") {
                    val localSids = dataInDB.map { it.sid }.toSet()
                    val outReply = hmsCore.sendRequestWithRetry(
                        HMSRequestType.GetSessionInfo,
                        GetSessionInfoReq(hmsCore.makeHeader(), sids.filter { !localSids.contains(it) }),
                        GetSessionInfoRsp.ADAPTER
                    )

                    val list = outReply.sessionAndMessageList.map { rsp ->
                        rsp.session!!.let {
                            val sessionDB = hmsCore.toSessionDB(it)

                            var count = 0L
                            if (withCount) {
                                count = getUnreadCountBySession(sessionDB)
                            }

                            var hmsMsg: HMSMessage? = null
                            if (withMsg) {
                                hmsMsg = rsp.latestMessages.firstOrNull()?.let {
                                    val user = it.sender?.let { HMSUser.fromNet(it, hmsCore.serializer) }
                                    val userInSession = it.senderInSession?.let {
                                        HMSUserInSession.fromNet(
                                            it,
                                            hmsCore.serializer
                                        )
                                    }
                                    val member = HMSMemberInfo(user ?: HMSUser.fake(""), userInSession)
                                    HMSMessage.fromDB(toMessageDb(it), hmsCore, member)
                                }
                            }

                            HMSSession.fromDB(sessionDB, count, hmsMsg, hmsCore.serializer)
                        }
                    }
                    totalList.addAll(list)
                }
            } catch (exception: HMSException) {
                hmsCore.logger.e(TAG, exception) {
                    "GetSessionInfo failed"
                }
            }
        }

        if (totalList.isEmpty()) {
            throw HMSTransferException(-1, "GetSessionInfo failed")
        }
        return totalList
    }

    internal fun getSessionObservableData(
        sid: String
    ): HMSObservableData<HMSSession> =
        SessionObservableData(sid)


    suspend fun setSessionRead(sid: String) = withContext(hmsCore.DBWrite) {
        // 将local read max sequence 设置为sequence
        hmsCore.database.sessionDBQueries.transaction {
            hmsCore.database.sessionDBQueries.updateLocalReadSequenceToMax(sid)
            hmsCore.logger.d(TAG, null) { "updateLocalReadSequenceToMax :${sid}" }
        }
        val maxSequence =
            hmsCore.database.sessionDBQueries.queryMaxSequenceBySids(listOf(sid)).executeAsOneOrNull()?.max_sequence

        maxSequence?.let {
            //同时上报
            hmsCore.hmsScope.launch {
                try {
                    assertServerData(message = "ReportRead") {
                        val reply = hmsCore.sendRequestWithRetry(
                            HMSRequestType.ReportRead,
                            ReportReadReq(hmsCore.makeHeader(), sid, maxSequence),
                            ReportReadRsp.ADAPTER
                        )
                        hmsCore.logger.d(TAG, null) { "set read reply is ${reply}" }
                    }
                } catch (exception: HMSException) {
                    hmsCore.logger.e(TAG, exception) { "setSessionRead" }
                }
            }
        }
    }

    /**
     * check session是否存在，否则创建一个
     */
    suspend fun createSessionIfNotExist(
        type: SessionType,
        uids: List<String>,
        name: String? = null,
        avatar: String? = null,
        businessBuffer: ByteString? = null
    ): HMSSession {
        if (type == SessionType.C2C) {
            if (uids.size != 1) {
                throw HMSIllegalArgumentException("C2C session can only have one uid")
            }
            val otherUid = uids.first()
            val sessionlist =
                hmsCore.database.sessionDBQueries.queryC2CSesssionByTouid(otherUid, SessionType.C2C.value.toLong())
                    .executeAsList()
            if (!sessionlist.isEmpty()) {
                return HMSSession.fromDB(sessionlist.first(), 0, null, hmsCore.serializer)
            }
        }

        assertServerData(message = "create session") {
            val reply = hmsCore.sendRequestWithRetry(
                HMSRequestType.CreateSession,
                CreateSessionReq(
                    hmsCore.makeHeader(),
                    type,
                    uids,
                    avatar,
                    name,
                    businessBuffer
                ),
                CreateSessionRsp.ADAPTER
            )

            val session = reply.session!!
            val sid = session.sessionBasicInfo!!.sid!!

            withContext(hmsCore.DBWrite) {
                hmsCore.database.sessionDBQueries.transaction {
                    hmsCore.database.sessionDBQueries.insertOrUpdate(
                        session
                    )

                    if (type == SessionType.C2C) {
                        hmsCore.database.sessionDBQueries.updateC2CSessionUid(uids[0], sid)

                        if (!hmsCore.isEmptyC2CSessionShow) {
                            //本地没有消息的C2C会话默认不展示在最近列表
                            val count =
                                hmsCore.database.messageDBQueries.queryMessageCountBySid(sid).executeAsOneOrNull().pb
                            if (count <= 0) {
                                hmsCore.database.sessionDBQueries.deleteSessionBysSids(listOf(sid))
                            }
                        }
                    }
                }

            }

            return HMSSession.fromNet(session, hmsCore.serializer).apply {
                if (serverUnreadRemindSequences?.isNotEmpty() == true) {
                    hmsCore.logger.v(TAG) { "createSession，unread@me: $serverUnreadRemindSequences" }
                }
            }
        }
    }


    /**
     * 通过toUid获得C2C Session
     *
     * ps:这里完备的逻辑应该是本地不存在时向服务端请求
     */
    suspend fun getC2CSession(toUid: String): HMSSession {
        val reply = hmsCore.sendRequestWithRetry(
            HMSRequestType.GetC2CSessionByToUid,
            GetC2CSessionByToUidReq(
                hmsCore.makeHeader(),
                touid = toUid
            ),
            GetC2CSessionByToUidRsp.ADAPTER
        )

        return HMSSession.fromNet(reply.session!!, hmsCore.serializer).apply {
            if (serverUnreadRemindSequences?.isNotEmpty() == true) {
                hmsCore.logger.v(TAG) { "createSession，unread@me: $serverUnreadRemindSequences" }
            }
        }
    }

    /**
     * 删除session，之前的消息不会再同步
     */
    suspend fun deleteSession(sid: String) {
        assertServerData(message = "DeleteSession") {
            hmsCore.sendRequestWithRetry(
                HMSRequestType.DeleteSession,
                DeleteSessionReq(hmsCore.makeHeader(), sid),
                DeleteSessionRsp.ADAPTER
            )
            withContext(hmsCore.DBWrite) {
                hmsCore.database.sessionDBQueries.deleteSessionBysSids(listOf(sid))
                hmsCore.database.sessionDBQueries.updateSessionVisibleSeqAfterDelete(listOf(sid))
                hmsCore.database.messageDBQueries.deleteLocalMessagesBySid(sid)
            }
        }
    }

    /**
     * 从本地删除session
     */
    suspend fun deleteLocalSession(sid: String) {
        withContext(hmsCore.DBWrite) {
            hmsCore.database.sessionDBQueries.deleteSessionBysSids(listOf(sid))
        }
    }

    /**
     * 更新session info
     */
    suspend fun updateSessionInfo(
        sid: String,
        name: String? = STRING_PLACEHOLDER,
        avatar: String? = STRING_PLACEHOLDER,
        busiBuffer: ByteArray? = BYTE_ARRAY_PLACEHOLDER
    ) {
        assertServerData(message = "UpdateSessionInfo") {
            var fieldFlag = UpdateSessionInfoReq.SessionInfoFieldFlag.NOUSE.value
            if (name !== STRING_PLACEHOLDER) {
                fieldFlag = fieldFlag.or(UpdateSessionInfoReq.SessionInfoFieldFlag.NAME_FIELD.value)
            }
            if (avatar !== STRING_PLACEHOLDER) {
                fieldFlag = fieldFlag.or(UpdateSessionInfoReq.SessionInfoFieldFlag.AVATARURL_FIELD.value)
            }
            if (busiBuffer !== BYTE_ARRAY_PLACEHOLDER) {
                fieldFlag = fieldFlag.or(UpdateSessionInfoReq.SessionInfoFieldFlag.BUSINESSBUFFER_FIELD.value)
            }
            val reply = hmsCore.sendRequestWithRetry(
                HMSRequestType.UpdateSessionInfo,
                UpdateSessionInfoReq(
                    hmsCore.makeHeader(),
                    sid,
                    name,
                    avatar,
                    busiBuffer?.toByteString(),
                    fieldFlag.toLong()
                ),
                UpdateSessionInfoRsp.ADAPTER
            )
            withContext(hmsCore.DBWrite) {
                hmsCore.database.sessionDBQueries.insertOrUpdate(reply.session)
            }
        }
    }

    /**
     * 更新自定义字段
     */
    suspend fun updateSessionExtension(
        sid: String,
        extension: Any?
    ) {
        withContext(hmsCore.DBWrite) {
            hmsCore.database.sessionDBQueries.updateSessionExtension(
                hmsCore.serializer.serializeSessionExtension(
                    extension ?: BYTE_ARRAY_PLACEHOLDER
                ), sid
            )
        }
    }

    /**
     * 更新C2C的好友关系链
     */
    suspend fun updateSessionFriendType(toUid: String, friendType: Int) {
        if (toUid.isEmpty()) {
            return
        }
        withContext(hmsCore.DBWrite) {
            hmsCore.database.sessionDBQueries.updateSessionFriendType(
                friendType.toLong(),
                toUid,
                SessionType.C2C.value.toLong()
            )
        }
        val session =
            hmsCore.database.sessionDBQueries.queryC2CSesssionByTouid(toUid, SessionType.C2C.value.toLong())
                .executeAsOneOrNull() ?: return
        assertServerData(message = "updateSessionFriendType:GetSessionInfo") {
            val outReply = hmsCore.sendRequestWithRetry(
                HMSRequestType.GetSessionInfo,
                GetSessionInfoReq(hmsCore.makeHeader(), listOf(session.sid)),
                GetSessionInfoRsp.ADAPTER
            )

            outReply.sessionAndMessageList.map { rsp ->
                rsp.session!!.let {
                    withContext(hmsCore.DBWrite) {
                        hmsCore.database.sessionDBQueries.insertOrUpdate(it)
                    }
                }
            }
        }
    }


    /**
     * 往群组中加人
     */
    suspend fun addUserToSession(
        sessionId: String,
        uids: List<String>
    ): List<HMSAddToSessionResultItem> {
        assertServerData(message = "AddUserToSession") {
            val reply = hmsCore.sendRequestWithRetry(
                HMSRequestType.AddUserToSession,
                AddUserToSessionReq(hmsCore.makeHeader(), sessionId, uids),
                AddUserToSessionRsp.ADAPTER
            )
            val retList = reply.results.map {
                HMSAddToSessionResultItem(it.uid!!, it.resultCode?.value ?: 0)
            }.toList()
            return retList
        }
    }

    /**
     * 从群组中退出
     */
    suspend fun quitSession(
        sessionID: String
    ) {
        assertServerData(message = "QuitSession") {
            hmsCore.sendRequestWithRetry(
                HMSRequestType.QuitSession,
                QuitSessionReq(hmsCore.makeHeader(), sessionID),
                QuitSessionRsp.ADAPTER
            )
            withContext(hmsCore.DBWrite) {
                hmsCore.database.sessionDBQueries.queryDisableStorageBySids(listOf(sessionID))
                    .executeAsOneOrNull()?.let {
                        hmsCore.database.messageDBQueries.deleteLocalMessagesBySid(it.sid)
                    }

                hmsCore.database.sessionDBQueries.deleteSessionBysSids(listOf(sessionID))
                hmsCore.database.userInSessionDBQueries.deleteUserInSessionBySid(sessionID, hmsCore.uid)
            }
        }
    }

    /**
     * 删除群组中某个成员
     */
    suspend fun deleteSessionMember(
        sid: String,
        uids: List<String>
    ): List<HMSDeleteSessionMemberResultItem> {
        assertServerData(message = "DeleteSessionMember") {
            val reply = hmsCore.sendRequestWithRetry(
                HMSRequestType.DeleteSessionMember,
                DeleteSessionMemberReq(hmsCore.makeHeader(), sid, uids),
                DeleteSessionMemberRsp.ADAPTER
            )
            val list = reply.results.map {
                HMSDeleteSessionMemberResultItem(
                    it.uid!!,
                    it.resultCode?.value ?: DeleteSessionMemberRsp.DeleteSessionMemberResultCode.Success.value
                )
            }.toList()
            return list
        }
    }

    /**
     * 解散群,只有群主有此功能
     */
    suspend fun destroySession(sessionID: String) {
        assertServerData(message = "DestroySession") {
            hmsCore.sendRequestWithRetry(
                HMSRequestType.DestroySession,
                DestroySessionReq(hmsCore.makeHeader(), sessionID),
                DestroySessionRsp.ADAPTER
            )
            withContext(hmsCore.DBWrite) {
                hmsCore.database.sessionDBQueries.deleteSessionBysSids(listOf(sessionID))
            }
        }
    }

    /**
     * 更新群名片
     */
    suspend fun updaterUserInSession(
        sessionID: String,
        uid: String,
        remark: String? = STRING_PLACEHOLDER,
        businessBuffer: ByteArray? = BYTE_ARRAY_PLACEHOLDER
    ) {
        assertServerData(message = "UpdateUserInSession") {
            var flag = 0
            if (remark !== STRING_PLACEHOLDER) {
                flag = flag or UpdateUserInSessionReq.UserInSessionFieldFlag.REMARK_FIELD.value
            }

            if (businessBuffer !== BYTE_ARRAY_PLACEHOLDER) {
                flag = flag or UpdateUserInSessionReq.UserInSessionFieldFlag.BUSINESSBUFFER_FIELD.value
            }

            val reply = hmsCore.sendRequestWithRetry(
                HMSRequestType.UpdateUserInSession,
                UpdateUserInSessionReq(
                    hmsCore.makeHeader(),
                    sessionID,
                    uid,
                    remark,
                    businessBuffer?.toByteString(),
                    flag.toLong()
                ),
                UpdateUserInSessionRsp.ADAPTER
            )
            //save to db
            reply.userInSession?.let { userInSession ->
                withContext(hmsCore.DBWrite) {
                    hmsCore.database.userInSessionDBQueries.insertOrUpdateUserInSessions(listOf(userInSession))
                }
            }
            reply.userInSession
        }
    }


    //黑名单
    suspend fun getBlackList() = hmsCore.sendRequestWithRetry(
        HMSRequestType.GetBlackList,
        GetBlackListReq(hmsCore.makeHeader()),
        GetBlackListRsp.ADAPTER
    )


    suspend fun addToBlackList(
        toUid: String
    ) = hmsCore.sendRequestWithRetry(
        HMSRequestType.AddToBlackList,
        AddToBlackListReq(hmsCore.makeHeader(), toUid),
        AddToBlackListRsp.ADAPTER
    )

    suspend fun removeFromBlackList(
        toUid: String
    ) = hmsCore.sendRequestWithRetry(
        HMSRequestType.RemoveFromBlackList,
        RemoveFromBlackListReq(hmsCore.makeHeader(), toUid),
        RemoveFromBlackListRsp.ADAPTER
    )

    /**
     * 删除session的本地消息（不影响server和其他终端）
     */
    fun deleteSessionMessages(sid: String) {
        hmsCore.database.transaction {
            hmsCore.database.sessionDBQueries.updateSessionVisibleSeqAfterDelete(listOf(sid))
            hmsCore.database.messageDBQueries.deleteLocalMessagesBySid(sid)
        }
    }

    suspend fun changeSessionMessageAlertType(sid: String, messageAlertType: HMSMessageAlertType) {
        hmsCore.sendRequestWithRetry(
            HMSRequestType.ChangeMsgAlertType,
            ChangeMsgAlertTypeReq(hmsCore.makeHeader(), sid, messageAlertType.toProtorol()),
            ChangeMsgAlertTypeRsp.ADAPTER
        ).session?.let {
            withContext(hmsCore.DBWrite) {
                hmsCore.database.sessionDBQueries.insertOrUpdate(it)
            }
        }
    }

    interface SessionsChangeListener {
        fun onSessionsChange(datas: List<SessionDB>)
    }

    private inner class SessionObservableData(val sid: String) : HMSObservableData<HMSSession>(hmsCore.executors) {
        private var triggerCallback: HMSDisposableCallback<List<Session_table_log>>? = null

        override fun onActive() {
            if (hmsCore.isDestroyed) {
                return
            }
            fetch()
            triggerCallback = HMSDisposableCallback {
                if (it.any { it.sid == sid }) {
                    fetch()
                }
            }
            hmsCore.triggerManager.registerTriggerCallback(
                TriggerManager.TriggerType.SESSION,
                triggerCallback!!
            )
        }

        private fun fetch() {
            hmsCore.hmsScope.launch {
                getSessionListBySids(listOf(sid)).firstOrNull()?.let {
                    setData(it)
                }
            }
        }

        override fun onInactive() {
            triggerCallback?.dispose()
            triggerCallback = null
        }
    }
}

