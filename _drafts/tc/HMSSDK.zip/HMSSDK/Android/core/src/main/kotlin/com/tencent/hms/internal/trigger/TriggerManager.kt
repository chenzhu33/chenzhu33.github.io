package com.tencent.hms.internal.trigger

import com.squareup.sqldelight.Transacter
import com.squareup.sqldelight.db.SqlDriver
import com.tencent.hms.HMSCore
import com.tencent.hms.HMSDisposableCallback
import com.tencent.hms.internal.HMSExecutors
import com.tencent.hms.internal.repository.HMSDatabase
import com.tencent.hms.internal.repository.model.*
import kotlinx.coroutines.withContext
import java.util.concurrent.CopyOnWriteArrayList

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-07
 * Time:   10:38
 * Life with Passion, Code with Creativity.
 * ```
 */

/**
 * accessed only from worker thread.
 */
internal class TriggerManager constructor(
    internal val executors: HMSExecutors,
    private val rawSqlDriver: SqlDriver
) {

    /**
     * all trigger should used this database instead of [HMSCore.database]
     */
    internal val temporaryTriggersQueries: TemporaryTriggersQueries =
        HMSDatabase(rawSqlDriver).temporaryTriggersQueries

    enum class TriggerType {
        /**
         * obtain without param
         * callback type `List<Message_table_write_log>`
         * @see Message_table_write_log
         */
        GLOBAL_MESSAGE,

        /**
         * obtain without param
         * callback type `List<New_message_table_write_log>`
         * @see New_message_table_write_log
         */
        NEW_MESSAGE,

        /**
         * obtain with session id
         * callback type `List<Message_table_for_session_write_log>`
         * @see Message_table_for_session_write_log
         */
        SESSION_MESSAGE,

        /**
         * obtain without param
         * callback type `List<Session_table_log>`
         * @see Session_table_log
         */
        SESSION,

        /**
         * obtain without param
         * callback type `List<user_table_log>`
         * @see User_table_log
         */
        USER,
        /**
         * obtain without param
         * callback type `List<user_in_session_trigger_insert>`
         * @see User_in_session_table_log
         */
        USER_IN_SESSION,

        /**
         * obtain without param
         * callback type `Control_message_trigger_table_log`
         * @see Control_message_trigger_table_log
         */
        CONTROL_MESSAGE,
    }

    private val triggers = CopyOnWriteArrayList<Trigger<*>>()
    private val triggerFactories: Map<TriggerType, TriggerFactory<*>> = mapOf(
        TriggerType.GLOBAL_MESSAGE to GlobalMessageTriggerFactory(this),
        TriggerType.NEW_MESSAGE to NewMessageTriggerFactory(this),
        TriggerType.SESSION_MESSAGE to SessionMessageTriggerFactory(this),
        TriggerType.SESSION to SessionTriggerFactory(this),
        TriggerType.USER to UserTriggerFactory(this),
        TriggerType.USER_IN_SESSION to UserInSessionTriggerFactory(this),
        TriggerType.CONTROL_MESSAGE to ControlMessageTriggerFactory(this)
    )

    var _triggerTransaction: Transacter.Transaction? = null

    /**
     * execute all triggers.
     * do the operation on each db transaction end.
     */
    fun processTriggers() {
        try {
            temporaryTriggersQueries.transaction {
                _triggerTransaction = this
                triggers.forEach { it.process(rawSqlDriver) }
            }
        } finally {
            _triggerTransaction = null
        }
    }

    val triggerTransaction: Transacter.Transaction
        get() {
            executors.assertDbWriteThread()
            return _triggerTransaction
                ?: throw IllegalStateException("can only access trigger transaction during a trigger process")
        }

    @Suppress("UNCHECKED_CAST")
    fun <T : Any> registerTriggerCallback(
        triggerType: TriggerType,
        callback: HMSDisposableCallback<T>
    ) {
        executors.executeOnDbWriteOrFail {
            synchronized(triggerType) {
                if (callback.isDisposed) {
                    // double check
                    return@synchronized
                }
                triggerFactories[triggerType]?.also {
                    val (new, trigger) = (it as SingleInstanceTriggerFactory<T>).obtain()
                    if (new) {
                        temporaryTriggersQueries.transaction {
                            trigger.install(rawSqlDriver)
                        }
                        triggers.addIfAbsent(trigger)
                    }
                    trigger.register(callback)
                } ?: throw IllegalStateException("can't find trigger factory for $triggerType")
            }
        }
    }

    @Suppress("UNCHECKED_CAST")
    fun <T : Any> registerTriggerCallback(
        triggerType: TriggerType,
        callback: HMSDisposableCallback<T>,
        vararg param: Any
    ) {
        executors.executeOnDbWriteOrFail {
            synchronized(triggerType) {
                if (callback.isDisposed) {
                    // double check
                    return@synchronized
                }

                triggerFactories[triggerType]?.also {
                    val (new, trigger) = (it as MultiInstanceTriggerFactory<T, Any>).obtain(*param)
                    if (new) {
                        temporaryTriggersQueries.transaction {
                            trigger.install(rawSqlDriver)
                        }
                        triggers.addIfAbsent(trigger)
                    }
                    trigger.register(callback)
                } ?: throw IllegalStateException("can't find trigger factory for $triggerType")
            }
        }
    }

    /**
     * called by [TriggerManager] when this trigger is idle
     */
    @Suppress("UNCHECKED_CAST")
    internal fun removeTrigger(trigger: Trigger<*>) {
        executors.executeOnDbWriteOrFail {
            synchronized(trigger.type) {
                // double check if a trigger is idle
                if (trigger.isIdle) {
                    triggers.remove(trigger)

                    val factory = triggerFactories[trigger.type] as TriggerFactory<Any>
                    factory.removeTrigger(trigger as Trigger<Any>)

                    temporaryTriggersQueries.transaction {
                        trigger.uninstall(rawSqlDriver)
                    }
                }
            }
        }
    }

    /**
     * release all installed triggers
     */
    suspend fun destroy() {
        withContext(executors.DBWrite) {
            triggers.forEach {
                synchronized(it.type) {
                    it.destroy()
                }
            }
        }
    }
}
