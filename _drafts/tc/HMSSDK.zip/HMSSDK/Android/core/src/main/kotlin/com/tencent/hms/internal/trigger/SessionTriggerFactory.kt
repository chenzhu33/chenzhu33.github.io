package com.tencent.hms.internal.trigger

import com.squareup.sqldelight.db.SqlDriver
import com.tencent.hms.internal.repository.model.Session_table_log

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-09
 * Time:   16:41
 * Life with Passion, Code with Creativity.
 * ```
 */
internal class SessionTriggerFactory(triggerManager: TriggerManager) :
    SingleInstanceTriggerFactory<List<Session_table_log>>(triggerManager) {
    override val type: TriggerManager.TriggerType
        get() = TriggerManager.TriggerType.SESSION

    override fun create(triggerManager: TriggerManager): Trigger<List<Session_table_log>> =
        object : Trigger<List<Session_table_log>>(triggerManager) {
            override val type: TriggerManager.TriggerType
                get() = TriggerManager.TriggerType.SESSION

            override fun install(db: SqlDriver) {
                triggerManager.temporaryTriggersQueries.run {
                    installSesssionTriggerLogTable()
                    installSesssionInsertTrigger()
                    installSesssionUpdateTrigger()
                    installSessionDeleteTrigger()
                    installDeleteLastMessageTrigger()
                    installSessionMaxReadSeqChangeTrigger()
                    installSessionVisibleSeqChangeTrigger()
                }
            }

            override fun uninstall(db: SqlDriver) {
                triggerManager.temporaryTriggersQueries.run{
                    uninstallSessionTriggerLogTable()
                    uninstallSesssionInsertTrigger()
                    uninstallSesssionUpdateTrigger()
                    uninstallSessionDelteTrigger()
                    uninstallDeleteLastMessageTrigger()
                    unstallSessionMaxReadSeqChangeTrigger()
                    unstallSessionVisibleSeqChangeTrigger()
                }
            }

            override fun process(db: SqlDriver) {
                triggerManager.temporaryTriggersQueries.let {
                    val sessionList = it.querySessionLog().executeAsList()
                    if (sessionList.isNotEmpty()) {
                        callback(sessionList.map { sid -> Session_table_log.Impl(sid) })
                        it.clearSessionLog()
                    }
                }
            }
        }

}