package com.tencent.hms.internal

import com.tencent.hms.HMSLogDelegate

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-08
 * Time:   15:47
 * Life with Passion, Code with Creativity.
 * ```
 */

@Suppress("NOTHING_TO_INLINE")
internal class HMSLogger(
    internal val proxy: HMSLogDelegate
) {
    internal val verbose = proxy.verbose

    inline fun v(tag: String, throwable: Throwable? = null, messageProvider: () -> String) {
        if (verbose) {
            proxy.log(HMSLogDelegate.LogLevel.VERBOSE, tag, messageProvider(), throwable)
        }
    }

    inline fun d(tag: String, throwable: Throwable? = null, messageProvider: () -> String) {
        if (verbose) {
            proxy.log(HMSLogDelegate.LogLevel.DEBUG, tag, messageProvider(), throwable)
        }
    }

    inline fun i(tag: String, throwable: Throwable? = null, messageProvider: () -> String) {
        proxy.log(HMSLogDelegate.LogLevel.INFO, tag, messageProvider(), throwable)
    }

    inline fun w(tag: String, throwable: Throwable? = null, messageProvider: () -> String) {
        proxy.log(HMSLogDelegate.LogLevel.WARNING, tag, messageProvider(), throwable)
    }

    inline fun e(tag: String, throwable: Throwable? = null, messageProvider: () -> String) {
        proxy.log(HMSLogDelegate.LogLevel.ERROR, tag, messageProvider(), throwable)
    }
}
