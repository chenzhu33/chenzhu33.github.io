package com.tencent.hms.internal

import com.tencent.hms.HMSCore
import com.tencent.hms.HMSException
import com.tencent.hms.HMSRequestType
import com.tencent.hms.internal.protocol.HeartbeatReq
import com.tencent.hms.internal.protocol.HeartbeatRsp
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2019-03-14
 * Time:   17:13
 * Life with Passion, Code with Creativity.
 * </pre>
 */

internal class HeartbeatManager(private val hmsCore: HMSCore) {
    companion object {
        const val MIN_HEARTBEAT_INTERVAL_MS = 10_000L
        const val DEFAULT_HEARTBEAT_INTERVAL_MS = 60_000L
        private const val TAG = "HMSHeartbeatManager"
    }

    private val serialCoroutineExecutor = SerialCoroutineExecutor(
        hmsCore.logger, hmsCore.hmsScope
    )

    private var scheduleToken: Any? = null
    private val mutex = Mutex()

    fun onForegroundStatusChange(isForeground: Boolean) {
        if (isForeground) {
            start()
        } else {
            stop()
        }
    }

    private fun start() {
        serialCoroutineExecutor.execute {
            val notNested = mutex.withLock {
                scheduleToken == null
            }

            if (notNested) {
                scheduleHeartbeat()
            }
        }
    }

    private suspend fun scheduleHeartbeat() {
        val replyIntervalMs = doHeartbeat()
        val interval = if (replyIntervalMs == null || replyIntervalMs < MIN_HEARTBEAT_INTERVAL_MS) {
            DEFAULT_HEARTBEAT_INTERVAL_MS
        } else {
            replyIntervalMs
        }

        hmsCore.logger.v(TAG) { "scheduleHeartBeat delay:$interval ms" }
        mutex.withLock {
            scheduleToken = hmsCore.executors.scheduleTask(interval) {
                serialCoroutineExecutor.execute {
                    scheduleHeartbeat()
                }
            }
        }
    }

    private fun stop() {
        serialCoroutineExecutor.execute {
            hmsCore.logger.v(TAG) { "cancel heartbeat" }
            mutex.withLock {
                scheduleToken?.let { hmsCore.executors.unscheduleTask(it) }
                scheduleToken = null
            }
        }
    }

    private suspend fun doHeartbeat(): Long? {
        return try {
            hmsCore.sendRequestWithRetry(
                HMSRequestType.Heartbeat,
                HeartbeatReq(hmsCore.makeHeader()),
                HeartbeatRsp.ADAPTER
            ).nextRequestTimeInterval
        } catch (e: HMSException) {
            null
        }
    }

}