package com.tencent.hms.message

import com.tencent.hms.HMSException
import com.tencent.hms.internal.COMMON_ERROR_CODE

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-10
 * Time:   17:10
 * Life with Passion, Code with Creativity.
 * ```
 */


class HMSMessageNotFoundException(
    message: String
) : HMSException(COMMON_ERROR_CODE, message, null)

