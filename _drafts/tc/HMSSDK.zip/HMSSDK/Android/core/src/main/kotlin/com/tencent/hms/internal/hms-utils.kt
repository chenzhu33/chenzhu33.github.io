@file:Suppress("NOTHING_TO_INLINE")

package com.tencent.hms.internal

import com.squareup.sqldelight.Transacter
import com.squareup.wire.ProtoAdapter
import com.tencent.hms.*
import com.tencent.hms.internal.protocol.Message
import com.tencent.hms.internal.protocol.Session
import com.tencent.hms.internal.repository.isControl
import com.tencent.hms.internal.repository.model.MessageDB
import com.tencent.hms.internal.repository.model.SessionDB
import com.tencent.hms.message.HMSControlMessage
import com.tencent.hms.message.HMSMessage
import com.tencent.hms.message.InternalControl
import kotlinx.coroutines.*
import okio.ByteString
import java.net.NetworkInterface
import java.net.SocketException
import kotlin.coroutines.AbstractCoroutineContextElement
import kotlin.coroutines.CoroutineContext
import kotlin.random.Random


/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-09
 * Time:   16:12
 * Life with Passion, Code with Creativity.
 * ```
 */

private val regex = "[^a-zA-Z0-9_]".toRegex()
/**
 * convert any string to a valid url string, ie. only contains [A-Za-z0-9_]+
 */
internal fun String.toUrlString(): String =
    this.replace(regex) { matchResult ->
        matchResult.value[0].toInt().toString(16)
    }

internal fun <T : Any> Transacter.transactionWithResult(block: Transacter.Transaction.() -> T): T {
    var exception: Throwable? = null
    lateinit var result: T
    transaction {
        try {
            result = block()
        } catch (e: Throwable) {
            exception = e
            throw e
        }
    }
    exception?.let { throw it }
    return result
}


internal inline fun timestamp(): Long {
    return System.currentTimeMillis()
}

internal inline fun generateClientKey(appid: String, uid: String, sid: String): String {
    return "${appid}_${uid}_${sid}_${timestamp()}_${Random.nextInt(1000)}"
}

internal inline fun <T> ByteArray.decode(adapter: ProtoAdapter<T>): T =
    try {
        adapter.decode(this)
    } catch (e: Exception) {
        throw HMSProtocolException("can't decode protocol", e)
    }

internal class HMSProtocolException(message: String, cause: Throwable? = null) :
    HMSException(COMMON_ERROR_CODE, message, cause, true)

internal inline fun ByteArray.toByteString() =
    ByteString.of(*this)

// get ProtoBuf default value for int
internal inline val Int?.pb
    get() = this ?: 0

internal inline val Long?.pb
    get() = this ?: 0L

internal inline val String?.pb
    get() = this ?: ""

internal inline val Boolean?.pb
    get() = this ?: false

internal inline val Double?.pb
    get() = this ?: 0.0

internal inline fun <T> assertServerData(
    code: Int = COMMON_ERROR_CODE,
    message: String = "invalid server response",
    block: () -> T
): T {
    return try {
        block()
    } catch (e: NullPointerException) {
        throw HMSIllegalServerResponseException(code, message, e)
    } catch (e: NoSuchElementException) {
        throw HMSIllegalServerResponseException(code, message, e)
    } catch (e: HMSProtocolException) {
        throw HMSIllegalServerResponseException(code, message, e)
    }
}


internal fun <T : Any> CoroutineScope.unwrapCoroutine(
    mainDispatcher: CoroutineDispatcher,
    callback: HMSDisposableCallback<HMSResult<T>>?,
    block: suspend () -> T
) {
    val job = launch(mainDispatcher) {
        try {
            val result = block()
            callback?.callback(HMSResult.success(result))
        } catch (e: HMSException) {
            callback?.callback(HMSResult.fail(e))
        } catch (e: CancellationException) {
            callback?.callback(HMSResult.fail(HMSInstanceDestroyedException(e)))
        }
    }
    if (job.isCancelled) {
        callback?.callback(HMSResult.fail(HMSInstanceDestroyedException()))
    }
}

/**
 * we have built in logic to filter out deleted messages ~
 */
internal fun defaultMessageFilter(message: HMSMessage) =
    !message.isDeleted &&
            // we don't want internal controls
            !(message.isControlMessage && (message as HMSControlMessage).control is InternalControl)


internal class HMSCoroutineExceptionHandler(private val logger: HMSLogger) :
    AbstractCoroutineContextElement(CoroutineExceptionHandler), CoroutineExceptionHandler {

    override fun handleException(context: CoroutineContext, exception: Throwable) {
        if (exception is HMSException) {
            logger.w("HMSCoroutineExceptionHandler", Throwable("BacktraceRecorder", exception)) {
                "hms logic error inside coroutine:${context[CoroutineName]}"
            }
        } else {
            logger.e("HMSCoroutineExceptionHandler", Throwable("BacktraceRecorder", exception)) {
                "fatal error inside coroutine:${context[CoroutineName]}"
            }
            (Thread.currentThread().uncaughtExceptionHandler ?: Thread.getDefaultUncaughtExceptionHandler())
                ?.uncaughtException(Thread.currentThread(), exception)
        }
    }
}

internal fun getDeviceInfo(): String {
    return ""
}

internal fun getSdkVersion(): String {
    return BuildConfig.VERSION_NAME
}

internal fun getIpAddress(): String {
    try {
        val en = NetworkInterface
            .getNetworkInterfaces()
        while (en.hasMoreElements()) {
            val intf = en.nextElement()
            val enumIpAddr = intf.getInetAddresses()
            while (enumIpAddr.hasMoreElements()) {
                val inetAddress = enumIpAddr.nextElement()
                if (!inetAddress.isLoopbackAddress() && !inetAddress.isLinkLocalAddress()) {
                    return inetAddress.getHostAddress().toString()
                }
            }
        }
    } catch (ex: SocketException) {
        //do nothing
    }
    return ""
}


internal fun HMSCore.toSessionDB(netSession: Session): SessionDB {
    val basicInfo = netSession.sessionBasicInfo!!
    val sequenceInfo = netSession.userInSessionSequence
    val userRelatedInfo = netSession.userRelatedSessionInfo
    val localColumns =
        database.sessionDBQueries.querySessionLocalColumnsForUnreadCount(basicInfo.sid!!).executeAsOneOrNull()
    val localUnreadRemind = database.sessionDBQueries.queryLocalReminds(basicInfo.sid).executeAsOneOrNull()

    return SessionDB.Impl(
        basicInfo.sid,
        basicInfo.type?.value.pb.toLong(),
        basicInfo.name,
        basicInfo.avatarUrl,
        basicInfo.businessBuffer?.toByteArray(),
        basicInfo.toUid,
        basicInfo.ownerUid,
        basicInfo.createTimestamp.pb,
        basicInfo.isDestroy,
        basicInfo.memberNumber.pb.toLong(),
        basicInfo.updateTimestamp.pb,

        sequenceInfo?.maxSequence.pb,
        sequenceInfo?.readMaxSequence.pb,
        sequenceInfo?.visibleSequence.pb,

        userRelatedInfo?.friendType.pb.toLong(),
        userRelatedInfo?.msgAlertType?.value.pb.toLong(),
        userRelatedInfo?.updateTimestamp.pb,

        localColumns?.is_deleted.pb,
        localColumns?.local_read_sequence.pb,
        false,
        null,
        null,
        localColumns?.latest_message_timestamp.pb,

        sequenceInfo?.reminds?.encode(),
        localUnreadRemind?.local_reminds
    )
}

internal fun toMessageDb(netMesg: Message): MessageDB {
    return MessageDB.Impl(
        netMesg.sessionID!!,
        netMesg.messageTimestamp.pb,
        netMesg.sender?.uid ?: "",
        netMesg.type?.toLong(),
        0,
        netMesg.element?.isControl() == true,
        false,
        false,
        netMesg.isRevoked.pb,
        false,
        netMesg.text!!,
        netMesg.pushText,
        netMesg.element?.encode(),
        netMesg.reminds?.encode(),
        netMesg.sequence,
        netMesg.countSequence.pb,
        netMesg.clientKey.pb,
        0,
        0,
        netMesg.revokeNumber.pb,
        null,
        netMesg.updateTimestamp
    )
}

