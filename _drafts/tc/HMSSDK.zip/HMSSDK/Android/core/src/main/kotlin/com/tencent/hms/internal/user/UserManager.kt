package com.tencent.hms.internal.user

import com.tencent.hms.*
import com.tencent.hms.internal.*
import com.tencent.hms.internal.protocol.*
import com.tencent.hms.internal.repository.insertOrUpdateUserInSessions
import com.tencent.hms.internal.repository.insertOrUpdateUsers
import com.tencent.hms.internal.repository.model.User_in_session_table_log
import com.tencent.hms.internal.repository.model.User_table_log
import com.tencent.hms.internal.trigger.TriggerManager
import com.tencent.hms.profile.HMSMemberInfo
import com.tencent.hms.profile.HMSUser
import com.tencent.hms.profile.HMSUserInSession
import com.tencent.hms.profile.isValid
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Created by juliandai on 2019/2/22 6:27 PM.
 * talk and show the code
 */
internal class UserManager(val hmsCore: HMSCore) {

    companion object {
        const val TAG = "UserManager"
    }

    internal val mineAccount: HMSObservableData<HMSUser> = AccountObservableData(hmsCore.uid, true)

    private val serialCoroutineExecutor = SerialCoroutineExecutor(hmsCore.logger, hmsCore.hmsScope)

    private val updateNotifyList = CopyOnWriteArrayList<HMSDisposableValue<MemberInfoUpdateCallback>>()

    // cache for the user and user session
    private val userCache = object : WeakCache<String, HMSUser>() {
        override fun createMany(keys: List<String>): Map<String, HMSUser> {
            return hmsCore.database.userDBQueries.queryUserByUids(keys).executeAsList()
                .associate { it.uid to HMSUser.fromDB(it, hmsCore.serializer) }
        }
    }

    // key sid to uid
    private val userSessionCache = object : WeakCache<Pair<String, String>, HMSUserInSession>() {
        override fun createMany(keys: List<Pair<String, String>>): Map<Pair<String, String>, HMSUserInSession> {
            val result = mutableMapOf<Pair<String, String>, HMSUserInSession>()
            keys.groupBy { it.first }
                .forEach { (sid, list) ->
                    val uis = hmsCore.database.userInSessionDBQueries.queryUserInSessionByUids(
                        sid, list.map { it.second })
                        .executeAsList()
                        .map { HMSUserInSession.fromDB(it, hmsCore.serializer) }
                    uis.forEach {
                        result[it.sid to it.uid] = it
                    }
                }
            return result
        }
    }

    internal suspend fun init() {
        hmsCore.hmsScope.launch {
            // fulfill account info async
            refreshUserAccountInfo()
        }

        hmsCore.triggerManager.registerTriggerCallback(
            TriggerManager.TriggerType.USER,
            userDBUpdateListener
        )
        hmsCore.triggerManager.registerTriggerCallback(
            TriggerManager.TriggerType.USER_IN_SESSION,
            userInSessionDBUpdateListener
        )
    }

    fun addDataChangeListener(callback: HMSDisposableValue<MemberInfoUpdateCallback>) {
        if (!callback.isDisposed) {
            updateNotifyList.add(callback)
            callback.setDisposeListener {
                updateNotifyList.remove(callback)
            }
        }
    }

    private val userDBUpdateListener = HMSDisposableCallback<List<User_table_log>> { changed ->
        serialCoroutineExecutor.execute {
            // notify change to other logic
            val updateUids = changed.map { it.uid }.toHashSet()

            // remove invalidate caches
            updateUids.forEach { userCache.remove(it) }
            updateNotifyList.forEach {
                it.value?.onUserChange(updateUids)
            }
        }
    }

    private val userInSessionDBUpdateListener = HMSDisposableCallback<List<User_in_session_table_log>> { changed ->
        serialCoroutineExecutor.execute {
            // notify change to other logic
            changed.forEach { userSessionCache.remove(it.sid to it.uid) }

            val pairList = changed.groupBy { it.sid }
                .entries
                .associate {
                    it.key to it.value.map { log -> log.uid }.toHashSet()
                }
            updateNotifyList.forEach {
                it.value?.onUserInSessionChange(pairList)
            }
        }
    }

    fun getUserObservableData(uid: String, getFromServer: Boolean = false): HMSObservableData<HMSUser> =
        AccountObservableData(uid, initialWithFake = false, pullNet = getFromServer)

    fun getUserMemberInfoObservableData(
        sid: String,
        uid: String,
        getFromServer: Boolean = false
    ): HMSObservableData<HMSMemberInfo> = MemberObservableData(sid, uid, getFromServer)

    /**
     * 修改用户资料
     */
    internal suspend fun updateUserInfo(
        uid: String,
        name: String? = STRING_PLACEHOLDER,
        avatar: String? = STRING_PLACEHOLDER,
        busibuffer: ByteArray? = BYTE_ARRAY_PLACEHOLDER
    ): HMSUser {
        assertServerData(message = "UpdateUserInfoReq") {
            var changeFlag = UpdateUserInfoReq.UserInfoFieldFlag.NOUSE.value

            if (name !== STRING_PLACEHOLDER) {
                changeFlag = changeFlag.or(UpdateUserInfoReq.UserInfoFieldFlag.NAME_FIELD.value)
            }
            if (avatar !== STRING_PLACEHOLDER) {
                changeFlag = changeFlag.or(UpdateUserInfoReq.UserInfoFieldFlag.AVATARURL_FIELD.value)
            }
            if (busibuffer !== BYTE_ARRAY_PLACEHOLDER) {
                changeFlag = changeFlag.or(UpdateUserInfoReq.UserInfoFieldFlag.BUSINESSBUFFER_FIELD.value)
            }

            //update 用户的名称，头像，自定义信息
            val reply = hmsCore.sendRequestWithRetry(
                HMSRequestType.UpdateUserInfo,
                UpdateUserInfoReq(
                    hmsCore.makeHeader(),
                    hmsCore.uid,
                    name,
                    avatar,
                    busibuffer?.toByteString(),
                    changeFlag.toLong()
                ),
                UpdateUserInfoRsp.ADAPTER
            )
            reply.user?.let {
                withContext(hmsCore.DBWrite) {
                    hmsCore.database.userDBQueries.insertOrUpdateUsers(listOf(it))
                    hmsCore.logger.d(TAG, null) { "update user info  ${uid} change flag ${changeFlag}" }
                }
            }
            userCache.remove(uid)
            return if (reply.user != null) {
                HMSUser.fromNet(reply.user, hmsCore.serializer)
            } else {
                HMSUser.fake(uid)
            }
        }
    }

    /**
     * 获得用户资料
     *
     * getUsers需要保证能拉取到所有uids的信息
     */
    internal suspend fun getUsers(uids: List<String>, useCache: Boolean = true): List<HMSUser> {
        val uidsList = uids.filter { !it.isBlank() }.distinct().toMutableList()
        val users = mutableListOf<HMSUser>()

        val pullUids: List<String>
        if (useCache) {
            val userFromDb = userCache.getAll(uids)
            uidsList.removeAll(userFromDb.map { it.uid })
            users.addAll(userFromDb)
            pullUids = uidsList
        } else {
            pullUids = uidsList
        }

        //get from net
        if (pullUids.isNotEmpty()) {
            try {
                assertServerData(message = "GetUserProfile") {
                    val reply = hmsCore.sendRequestWithRetry(
                        HMSRequestType.GetUserProfile,
                        GetUserProfileReq(hmsCore.makeHeader(), pullUids),
                        GetUserProfileRsp.ADAPTER
                    )
                    val pullUsers =
                        reply.mapSessionInfo.map { HMSUser.fromNet(it.value, hmsCore.serializer) }

                    withContext(hmsCore.DBWrite) {
                        hmsCore.database.userDBQueries.insertOrUpdateUsers(reply.mapSessionInfo.map { it.value })
                    }
                    pullUsers.forEach {
                        userCache.put(it.uid, it)
                    }
                    users.addAll(pullUsers)
                }
            } catch (exception: HMSException) {
                hmsCore.logger.e(TAG, exception) { "GetUserProfile" }
            }
        }
        return users
    }


    /**
     * 仅从本地获得user member info
     */
    internal fun getUsersMemberInfoCache(
        sessionId: String,
        uidList: List<String>
    ): List<HMSMemberInfo> {
        val users = userCache.getAll(uidList)
        val uis = userSessionCache.getAll(uidList.map { sessionId to it })
            .associateBy { it.uid }

        return users.map {
            HMSMemberInfo(it, uis[it.uid])
        }
    }

    /**
     * 获得用户基本资料和群资料
     *
     */
    internal suspend fun pullUsersMemberInfo(
        sid: String,
        uids: List<String>
    ): List<HMSMemberInfo> {
        try {
            assertServerData {
                val reply = hmsCore.sendRequestWithRetry(
                    HMSRequestType.GetSessionMemberInfoByUids,
                    GetSessionMemberInfoByUidsReq(hmsCore.makeHeader(), sid, uids),
                    GetSessionMemberInfoByUidsRsp.ADAPTER
                )
                val dataMap =
                    reply.memberList.map { HMSMemberInfo.fromNet(it.user!!, it.userInSession, hmsCore.serializer) }
                withContext(hmsCore.DBWrite) {
                    hmsCore.database.userInSessionDBQueries.insertOrUpdateUserInSessions(reply.memberList.mapNotNull { it.userInSession })
                    hmsCore.database.userDBQueries.insertOrUpdateUsers(reply.memberList.mapNotNull { it.user })
                }
                return dataMap
            }
        } catch (exception: HMSException) {
            hmsCore.logger.e(TAG,exception) { "error getUserInSession" }
        }
        return listOf()
    }



    /**
     * 在线获得session 所有成员列表
     */
    internal suspend fun getSessionMemberList(
        sessionID: String
    ): List<HMSMemberInfo> {
        assertServerData(message = "GetSessionMemberList") {
            val reply = hmsCore.sendRequestWithRetry(
                HMSRequestType.GetSessionMemberList,
                GetSessionMemberListReq(sessionID = sessionID),
                GetSessionMemberListRsp.ADAPTER
            )
            val users = reply.memberList.filter {
                it.user != null && it.user.isValid()
            }.map { memberInfo ->
                HMSMemberInfo.fromNet(memberInfo.user!!, memberInfo.userInSession, hmsCore.serializer)
            }.toList()

            hmsCore.hmsScope.launch(hmsCore.DBWrite) {
                //save to db
                val userProfileList = mutableListOf<User>()
                val userInSessionList = mutableListOf<UserInSession>()
                reply.memberList.filter {
                    it.userInSession != null && it.userInSession.isValid()
                }.forEach {
                    it.user?.let {
                        userProfileList.add(it)
                    }
                    it.userInSession?.let {
                        userInSessionList.add(it)
                    }
                    hmsCore.logger.d(TAG, null) { "getSessionMemberList: ${it.user?.uid}" }
                }
                hmsCore.database.userDBQueries.insertOrUpdateUsers(userProfileList)
                hmsCore.database.userInSessionDBQueries.insertOrUpdateUserInSessions(userInSessionList)
            }
            return users
        }
    }



    //禁言
    suspend fun updateSessionBannedStatus(
        sid: String,
        uid: String,
        duringTimeOfBan: Long
    ) {
        hmsCore.sendRequestWithRetry(
            HMSRequestType.UpdateSessionBanned,
            UpdateSessionBannedReq(hmsCore.makeHeader(), sid, uid, duringTimeOfBan),
            UpdateSessionBannedRsp.ADAPTER
        )
        //重新拉一次信息写入本地
        pullUsersMemberInfo(sid, listOf(uid))
    }

    //权限
    suspend fun updateSessionPermission(
        sid: String,
        uid: String,
        permission: PermissionType
    ) {
        hmsCore.sendRequestWithRetry(
            HMSRequestType.UpdateSessionPermission,
            UpdateSessionPermissionReq(hmsCore.makeHeader(), sid, uid, permission),
            UpdateSessionPermissionRsp.ADAPTER
        )
        pullUsersMemberInfo(sid, listOf(uid))
    }

    //转让群主
    suspend fun transferSessionOwner(
        sid: String,
        toUid: String
    ) {
        hmsCore.sendRequestWithRetry(
            HMSRequestType.TransferGroupOwner,
            TransferGroupOwnerReq(hmsCore.makeHeader(), sid, toUid),
            TransferGroupOwnerRsp.ADAPTER
        )
        pullUsersMemberInfo(sid, listOf(toUid, hmsCore.uid))
    }


    private suspend fun refreshUserAccountInfo() {
        try {
            assertServerData {
                val reply = hmsCore.sendRequestWithRetry(
                    HMSRequestType.GetUserProfile,
                    GetUserProfileReq(hmsCore.makeHeader(), listOf(hmsCore.uid)),
                    GetUserProfileRsp.ADAPTER
                )
                withContext(hmsCore.DBWrite) {
                    hmsCore.database.userDBQueries.insertOrUpdateUsers(reply.mapSessionInfo.map { it.value })
                }
                reply.mapSessionInfo.map { HMSUser.fromNet(it.value, hmsCore.serializer) }.firstOrNull()
            }
        } catch (exception: HMSException) {
            hmsCore.logger.e(TAG) { "error refreshUserAccountInfo" }
        }
    }

    private inner class AccountObservableData(
        private val uid: String,
        initialWithFake: Boolean = false,
        private val pullNet: Boolean = false
    ) : HMSObservableData<HMSUser>(
        hmsCore.executors,
        if (initialWithFake) HMSUser.fake(uid) else null
    ) {

        private var dataChangeListener: HMSDisposableValue<MemberInfoUpdateCallback>? = null

        init {
            if (initialWithFake) {
                fetch()
            }
        }

        override fun onActive() {
            if (hmsCore.isDestroyed) {
                return
            }
            fetch()

            dataChangeListener = HMSDisposableValue(object : MemberInfoUpdateCallback {
                override fun onUserChange(uids: Set<String>) {
                    if (uids.contains(uid)) {
                        userCache[uid]?.let {
                            setData(it)
                        }
                    }
                }
            })

            addDataChangeListener(dataChangeListener!!)
        }

        private fun fetch() {
            hmsCore.hmsScope.launch {
                getUsers(listOf(uid), pullNet).firstOrNull()?.let {
                    setData(it)
                }
            }
        }

        override fun onInactive() {
            dataChangeListener?.dispose()
            dataChangeListener = null
        }
    }

    private inner class MemberObservableData(
        private val sid: String,
        private val uid: String,
        private val pullNet: Boolean
    ) : HMSObservableData<HMSMemberInfo>(hmsCore.executors) {

        @Volatile
        private var firstRequest = false
        private var dataChangeListener: HMSDisposableValue<MemberInfoUpdateCallback>? = null

        override fun onActive() {
            if (hmsCore.isDestroyed) {
                return
            }
            fetch()

            dataChangeListener = HMSDisposableValue(object : MemberInfoUpdateCallback {
                override fun onUserChange(uids: Set<String>) {
                    if (uids.contains(uid)) {
                        fetch()
                    }
                }

                override fun onUserInSessionChange(sidUids: Map<String, Set<String>>) {
                    if (sidUids[sid]?.contains(uid) == true) {
                        fetch()
                    }
                }
            })

            addDataChangeListener(dataChangeListener!!)
        }

        private fun fetch() {
            hmsCore.hmsScope.launch {
                val fromServer = pullNet && firstRequest
                firstRequest = false
                if (fromServer) {
                    pullUsersMemberInfo(sid, listOf(uid))
                } else {
                    getUsersMemberInfoCache(sid, listOf(uid))
                }.firstOrNull()?.let {
                    setData(it)
                }
            }
        }

        override fun onInactive() {
            dataChangeListener?.dispose()
            dataChangeListener = null
        }
    }
}

internal interface MemberInfoUpdateCallback {
    fun onUserChange(uids: Set<String>) {}

    /**
     * Map<sid, Set<uid>>
     */
    fun onUserInSessionChange(sidUids: Map<String, Set<String>>) {}
}