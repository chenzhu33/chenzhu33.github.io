package com.tencent.hms.internal.trigger

import com.squareup.sqldelight.db.SqlDriver
import com.tencent.hms.internal.repository.model.User_table_log

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-09
 * Time:   19:42
 * Life with Passion, Code with Creativity.
 * ```
 */

internal class UserTriggerFactory(triggerManager: TriggerManager) :
    SingleInstanceTriggerFactory<List<User_table_log>>(triggerManager) {
    override val type: TriggerManager.TriggerType
        get() = TriggerManager.TriggerType.USER

    override fun create(triggerManager: TriggerManager): Trigger<List<User_table_log>> =
        object : Trigger<List<User_table_log>>(triggerManager) {
            override val type: TriggerManager.TriggerType
                get() = TriggerManager.TriggerType.USER

            override fun install(db: SqlDriver) {
                triggerManager.temporaryTriggersQueries.run {
                    installUserTriggerLogTable()
                    installUserUpdateTrigger()
                    installUserInsertTrigger()
                }
            }

            override fun uninstall(db: SqlDriver) {
                triggerManager.temporaryTriggersQueries.run {
                    uninstallUserTriggerLogTable()
                    uninstallUserUpdateTrigger()
                    uninstallUserInsertTrigger()
                }
            }

            override fun process(db: SqlDriver) {
                triggerManager.temporaryTriggersQueries.let {
                    val list = it.queryUserLog().executeAsList()
                    if (list.isNotEmpty()) {
                        callback(list.map { uid -> User_table_log.Impl(uid) })
                        it.clearUserLog()
                    }
                }
            }
        }
}
