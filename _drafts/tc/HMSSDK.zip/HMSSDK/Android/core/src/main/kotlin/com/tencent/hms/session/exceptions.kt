package com.tencent.hms.session

import com.tencent.hms.HMSException
import com.tencent.hms.internal.COMMON_ERROR_CODE

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-10
 * Time:   17:23
 * Life with Passion, Code with Creativity.
 * ```
 */

class HMSSessionNotFoundException(
    message: String
) : HMSException(COMMON_ERROR_CODE, message, null)