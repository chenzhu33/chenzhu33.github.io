package com.tencent.hms.message

import com.tencent.hms.HMSCore
import com.tencent.hms.HMSSerializer
import com.tencent.hms.internal.pb
import com.tencent.hms.internal.protocol.ControlElement
import com.tencent.hms.internal.protocol.Message
import com.tencent.hms.internal.protocol.MessageElement
import com.tencent.hms.internal.protocol.UpdateSessionInfoReq
import com.tencent.hms.profile.HMSMemberInfo
import com.tencent.hms.profile.HMSUserInSession
import com.tencent.hms.session.HMSSession

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-11
 * Time:   14:45
 * Life with Passion, Code with Creativity.
 * ```
 */

/**
 * HMS 控制消息基类，具体定义详见子类实现
 */
sealed class HMSControlElement {
    companion object {
        internal fun fromProtocol(
            protocol: ControlElement,
            hmsCore: HMSCore
        ): HMSControlElement? {
            return when (val control = protocol.control) {
                null -> null
                is ControlElement.Control.Revoke -> InternalControl("ControlRevoke ${control.revoke.revokedMessageSequence}")
                is ControlElement.Control.Update -> InternalControl("ControlUpdate ${control.update.updatedMessageSequence}")
                is ControlElement.Control.SystemAlert -> convertSystemAlert(
                    control.systemAlert.alertData!!,
                    hmsCore.serializer
                )
            }
        }

        /**
         * 是HMS内部使用的控制消息，
         * 即：是ControlElement，但不是SystemAlert
         * 目前也就是 Revoke & Update
         */
        internal fun isInternalControlMessage(message: Message): Boolean =
            message.element?.element?.let {
                it is MessageElement.Element.Control && it.control.control !is ControlElement.Control.SystemAlert
            } ?: false
    }

    internal fun toProtocol(hmsCore: HMSCore): ControlElement =
        ControlElement(toElementProtocol(hmsCore))

    internal abstract fun toElementProtocol(hmsCore: HMSCore): ControlElement.Control
}

internal data class InternalControl(val name: String) : HMSControlElement() {
    init {
        name.toString()
    }
    override fun toElementProtocol(hmsCore: HMSCore): ControlElement.Control {
        throw IllegalStateException("InternalControl $name can't convert to protocol")
    }
}

private fun convertSystemAlert(
    alertData: ControlElement.SystemAlertElement.AlertData,
    serializer: HMSSerializer
): HMSAlertControl =
    when (alertData) {
        is ControlElement.SystemAlertElement.AlertData.JoinSession ->
            HMSAlertJoinSession(
                alertData.joinSession.inviter?.toHmsUser(serializer),
                alertData.joinSession.joinUsers.map { it.toHmsUser(serializer) })
        is ControlElement.SystemAlertElement.AlertData.ExitSession ->
            HMSAlertExitSession(
                alertData.exitSession.exitUser!!.toHmsUser(serializer)
            )
        is ControlElement.SystemAlertElement.AlertData.DeleteFromSession ->
            HMSAlertDeleteFromSession(
                alertData.deleteFromSession.executor!!.toHmsUser(serializer),
                alertData.deleteFromSession.users.map { it.toHmsUser(serializer) }
            )
        is ControlElement.SystemAlertElement.AlertData.BecomeOwner ->
            HMSAlertTransferSessionOwner(
                alertData.becomeOwner.oldOwner!!.toHmsUser(serializer),
                alertData.becomeOwner.newOwner!!.toHmsUser(serializer)
            )
        is ControlElement.SystemAlertElement.AlertData.PermissionChange ->
            HMSAlertRoleChange(
                alertData.permissionChange.executor!!.toHmsUser(serializer),
                alertData.permissionChange.user!!.toHmsUser(serializer)
            )
        is ControlElement.SystemAlertElement.AlertData.SessionInfoChange ->
            HMSAlertSessionInfoChange(
                alertData.sessionInfoChange.executor!!.toHmsUser(serializer),
                HMSSession.fromNet(alertData.sessionInfoChange.session!!, serializer),
                HMSAlertSessionInfoChange.ChangedSessionField.fromProto(alertData.sessionInfoChange.flag!!)
            )
        is ControlElement.SystemAlertElement.AlertData.BannedChange -> {
            HMSAlertBannedChange(
                alertData.bannedChange.executor!!.toHmsUser(serializer),
                alertData.bannedChange.user!!.toHmsUser(serializer),
                alertData.bannedChange.durationTimestampOfBan.pb
            )
        }
        is ControlElement.SystemAlertElement.AlertData.DestroySession -> {
            HMSAlertDestroySession(alertData.destroySession.executor!!.toHmsUser(serializer))
        }
    }

@Suppress("NOTHING_TO_INLINE")
private inline fun ControlElement.MemberInfo.toHmsUser(serializer: HMSSerializer): HMSMemberInfo =
    HMSMemberInfo.fromNet(
        this.user!!,
        this.userInSession,
        serializer
    )

/**
 * 系统通知类控制消息的基类。
 * 系统通知是和该会话相关的一些通知，由HMS后台发出，具体定义详见子类。
 */
abstract class HMSAlertControl internal constructor() : HMSControlElement() {
    override fun toElementProtocol(hmsCore: HMSCore): ControlElement.Control {
        throw IllegalStateException("HMSAlertControl is designed for upper layer only")
    }
}

/**
 * 系统通知用户加入session
 */
data class HMSAlertJoinSession internal constructor(
    /**
     * 邀请者, 如果是用户自行加入则 [inviter] == `null`
     */
    val inviter: HMSMemberInfo?,
    /**
     * 加入的用户
     */
    val joinUsers: List<HMSMemberInfo>
) : HMSAlertControl()

/**
 * 系统通知用户自行退出session
 */
data class HMSAlertExitSession internal constructor(
    /**
     * 退出的用户
     */
    val exitedUser: HMSMemberInfo
) : HMSAlertControl()

/**
 * 系统通知用户被踢出session
 */
data class HMSAlertDeleteFromSession internal constructor(
    /**
     * 执行者
     */
    val executor: HMSMemberInfo,
    /**
     * 退出的用户
     */
    val deletedUsers: List<HMSMemberInfo>
) : HMSAlertControl()

/**
 * 系统通知SessionOwner转移
 */
data class HMSAlertTransferSessionOwner internal constructor(
    /**
     * 老的owner
     */
    val oldOwner: HMSMemberInfo,
    /**
     * 新owner
     */
    val newOwner: HMSMemberInfo
) : HMSAlertControl()

/**
 * 系统通知用户[HMSUserInSession.role] 变化
 */
data class HMSAlertRoleChange internal constructor(
    /**
     * 执行者
     */
    val executor: HMSMemberInfo,
    /**
     * 被变更用户
     */
    val changedUser: HMSMemberInfo
) : HMSAlertControl()

/**
 * 系统通知session信息变更
 */
data class HMSAlertSessionInfoChange internal constructor(
    /**
     * 执行者
     */
    val executor: HMSMemberInfo,
    /**
     * 变更之后的信息
     */
    val sessionInfo: HMSSession,
    /**
     * 具体有哪些字段发生了变化
     */
    val changedFields: Set<ChangedSessionField>
) : HMSAlertControl() {
    enum class ChangedSessionField {
        NAME,
        AVATAR,
        BUSINESS_BUFFER;

        companion object {
            internal fun fromProto(flag: Long): Set<ChangedSessionField> =
                mutableSetOf<ChangedSessionField>().apply {
                    when {
                        (flag and UpdateSessionInfoReq.SessionInfoFieldFlag.NAME_FIELD.value.toLong()) != 0L ->
                            add(NAME)
                        (flag and UpdateSessionInfoReq.SessionInfoFieldFlag.AVATARURL_FIELD.value.toLong()) != 0L ->
                            add(AVATAR)
                        (flag and UpdateSessionInfoReq.SessionInfoFieldFlag.BUSINESSBUFFER_FIELD.value.toLong()) != 0L ->
                            add(BUSINESS_BUFFER)
                    }
                }
        }
    }
}

/**
 * 用户禁言状态变更，禁言信息在 [HMSUserInSession.banExpireTime]
 */
data class HMSAlertBannedChange internal constructor(
    /**
     * 执行者
     */
    val executor: HMSMemberInfo,
    /**
     * 被变更用户
     */
    val changedUser: HMSMemberInfo,

    /**
     * 被禁言时长
     */
    val duringTimeOfBan: Long

) : HMSAlertControl()

/**
 * session被销毁
 */
data class HMSAlertDestroySession internal constructor(
    /**
     * 执行者
     */
    val executor: HMSMemberInfo


) : HMSAlertControl()