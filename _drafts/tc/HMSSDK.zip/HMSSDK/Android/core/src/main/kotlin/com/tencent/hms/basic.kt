package com.tencent.hms

import com.squareup.sqldelight.db.SqlDriver
import com.tencent.hms.HMSNewMessageListener.NewMessages
import com.tencent.hms.HMSResult.Fail
import com.tencent.hms.HMSResult.Success
import com.tencent.hms.internal.COMMON_ERROR_CODE
import com.tencent.hms.internal.HMSExecutors
import com.tencent.hms.message.HMSMessage
import com.tencent.hms.message.HMSPlainMessage
import com.tencent.hms.profile.HMSUser
import com.tencent.hms.profile.HMSUserInSession
import com.tencent.hms.session.HMSSession
import java.util.concurrent.atomic.AtomicBoolean

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-03
 * Time:   19:22
 * Life with Passion, Code with Creativity.
 * ```
 */

/**
 * HMS所有public结构都通过 [HMSException] 及其子类返回错误及失败
 *
 * @property code 错误码
 * @property message 错误信息
 */
open class HMSException(
    val code: Int,
    message: String,
    cause: Throwable? = null,
    /**
     * hide stacktrace for some exception to prevent from overwhelmingly stacktrace
     */
    private val hideStackTrace: Boolean = false
) : RuntimeException("$code $message", cause) {
    override fun fillInStackTrace(): Throwable {
        return if (hideStackTrace && cause != null) this else super.fillInStackTrace()
    }
}

class HMSIllegalArgumentException(msg: String) : HMSException(COMMON_ERROR_CODE, msg, null)

class HMSIllegalServerResponseException(code: Int, msg: String, cause: Throwable? = null) :
    HMSException(code, msg, cause, true)

class HMSInstanceDestroyedException(cause: Throwable? = null) :
    HMSException(COMMON_ERROR_CODE, "this hms instance is destroyed", cause, true)

/**
 * 对调用结果的封装，有两种情况：
 * 1. [Success] 表示 请求成功，[Success.data] 承载返回结果
 * 2. [Fail] 表示 请求失败，[Fail.error] 承载 错误异常
 */
sealed class HMSResult<T : Any> {
    companion object {
        fun <T : Any> success(data: T) = Success(data)
        fun <T : Any> fail(exception: HMSException) = Fail<T>(exception)
    }

    class Success<T : Any> internal constructor(val data: T) : HMSResult<T>()

    class Fail<T : Any> internal constructor(
        val error: HMSException
    ) : HMSResult<T>()
}

/**
 * HMS 所有 可以/必须 显式释放的接口
 */
interface HMSDisposable {
    fun dispose()
}

/**
 * 回调的封装，该回调可以 [HMSDisposableCallback.dispose] 从而释放对 callback 的引用，避免内存泄漏问题。
 * 通知提供了 [监听](setDisposeListener) dispose和 [获取](isDisposed) dispose状态的能力
 */
class HMSDisposableCallback<T : Any>(
    callback: (T) -> Unit
) : HMSDisposable {

    @Volatile
    private var _callback: ((T) -> Unit)? = callback
    private val disposed = AtomicBoolean(false)
    private var disposeListener: ((HMSDisposableCallback<T>) -> Unit)? = null

    val isDisposed: Boolean
        get() = disposed.get()

    fun callback(result: T) {
        _callback?.invoke(result)
    }

    internal fun setDisposeListener(listener: ((HMSDisposableCallback<T>) -> Unit)?) {
        disposeListener = listener
        // already disposed
        if (listener != null && isDisposed) {
            listener.invoke(this)
        }
    }

    override fun dispose() {
        if (disposed.compareAndSet(false, true)) {
            _callback = null

            disposeListener?.invoke(this)
        }
    }
}

internal class HMSDisposableValue<T>(
    _value: T
) : HMSDisposable {

    var value: T? = _value
        private set
    private val disposed = AtomicBoolean(false)
    private var disposeListener: ((HMSDisposableValue<T>) -> Unit)? = null

    val isDisposed: Boolean
        get() = disposed.get()

    internal fun setDisposeListener(listener: ((HMSDisposableValue<T>) -> Unit)?) {
        disposeListener = listener
        // already disposed
        if (listener != null && isDisposed) {
            listener.invoke(this)
        }
    }

    override fun dispose() {
        if (disposed.compareAndSet(false, true)) {
            value = null
            disposeListener?.invoke(this)
        }
    }
}

/**
 * 参考 LiveData 思想, 提供一个可以监听的数据，该数据可以持续更新.
 *
 * 并提供了`ext-liveData`扩展，增加`HMSObservableData.liveData`扩展属性, (Java代码可以使用 `HMSObservableDataUtils.asLive
 * Data()` 接口。
 *
 * 使用 [HMSObservableData.observe] 接口监听数据，使用 [HMSObservableData.removeObserver] 移除监听，避免内存泄漏。
 *
 * 通常使用者并不需要使用 [HMSObservableData.data] 接口。如果 该实例已经被设置过值，使用者在 [HMSObservableData.observe] 的时候会立即回调。
 *
 * 另外可以使用 `liveData` 扩展，更方便的使用.
 *
 * 注意：该类是非线程安全的，所有接口需要在主线程调用。
 *
 */
open class HMSObservableData<T : Any> internal constructor(
    private val executor: HMSExecutors,
    initialValue: T? = null
) {
    private val observers = mutableListOf<(T) -> Unit>()

    var data: T? = initialValue
        private set

    internal fun setData(value: T) {
        executor.executeOnMainThread {
            if (data != value) {
                data = value
                // callback
                observers.forEach { it(value) }
            }
        }
    }

    /**
     * 监听数据更新，后续需要调用 [removeObserver] 反注册
     *
     * PS：推荐使用LiveData扩展 `com.tencent.hms:ext-liveData:$hms_version`
     */
    fun observe(listener: (T) -> Unit) {
        executor.assertMainThread()

        val wasEmpty = observers.isEmpty()
        observers.add(listener)
        if (data != null) {
            listener(data!!)
        }

        if (wasEmpty && observers.isNotEmpty()) {
            onActive()
        }
    }

    /**
     * 使用 [HMSDisposableCallback] 监听
     * 后续直接使用 [HMSDisposableCallback.dispose] 即可反注册，不需要调用 [removeObserver]
     */
    fun observe(listener: HMSDisposableCallback<T>) {
        if (listener.isDisposed) {
            return
        }
        val l = { data: T -> listener.callback(data) }
        observe(l)
        listener.setDisposeListener {
            removeObserver(l)
        }
    }

    fun hasObservers() = observers.isNotEmpty()

    fun removeObserver(listener: (T) -> Unit?) {
        executor.assertMainThread()

        val wasEmpty = observers.isEmpty()
        observers.remove(listener)

        if (!wasEmpty && observers.isEmpty()) {
            onInactive()
        }
    }


    internal open fun onActive() {

    }

    internal open fun onInactive() {

    }

    /**
     * 内部使用，不要用这个字段！！！
     */
    @get:JvmSynthetic
    @set:JvmSynthetic
    var `interal-use-only-ext-LiveData`: Any? = null

    internal fun <R : Any> map(transformation: (T) -> R): HMSObservableData<R> {
        val m = HMSMediatorObservableData<R>(executor)
        m.setSource(this) { t ->
            m.setData(transformation(t))
        }
        return m
    }

    internal fun <R : Any> switchMap(transformation: (T) -> HMSObservableData<R>): HMSObservableData<R> {
        val m = HMSMediatorObservableData<R>(executor)
        var current: HMSObservableData<R>? = null
        m.setSource(this) { t ->
            val new = transformation(t)
            if (current === new) {
                return@setSource
            }
            current?.let { m.removeSource() }
            current = new

            m.setSource(new) { r ->
                m.setData(r)
            }
        }
        return m
    }
}

/**
 * imitate MediatorLiveData
 */
internal open class HMSMediatorObservableData<T : Any>(
    hmsExecutors: HMSExecutors
) : HMSObservableData<T>(hmsExecutors) {
    private var source: Source<*>? = null

    fun <S : Any> setSource(source: HMSObservableData<S>, observer: (S) -> Unit) {
        removeSource()
        val s = Source(source, observer)
        this.source = s
        if (hasObservers()) {
            s.plug()
        }
    }

    fun removeSource() {
        source?.let {
            if (hasObservers()) {
                it.unplug()
            }
            source = null
        }
    }

    override fun onActive() {
        source?.plug()
    }

    override fun onInactive() {
        source?.unplug()
    }

    private class Source<S : Any>(
        val observable: HMSObservableData<S>,
        val observer: (S) -> Unit
    ) {
        fun plug() {
            observable.observe(observer)
        }

        fun unplug() {
            observable.removeObserver(observer)
        }
    }
}

/**
 * 初始化HMS的时候提供的线程池实现
 */
interface HMSExecutorDelegate {
    fun isMainThread(): Boolean

    fun postToMainThread(block: () -> Unit)

    fun postToWorker(block: () -> Unit)
}

/**
 * 初始化HMS的时候提供的日志实现
 */
interface HMSLogDelegate {
    enum class LogLevel {
        VERBOSE,
        DEBUG,
        INFO,
        WARNING,
        ERROR
    }

    fun log(level: LogLevel, tag: String, message: String, throwable: Throwable?)

    /**
     * 是否允许 [LogLevel.VERBOSE] 和 [LogLevel.DEBUG] 级别的日志。
     * 这两个级别的日志比较多，但是对于排查问题非常有用。
     * 可以在debug版开启，release版关闭。
     */
    val verbose: Boolean
}

/**
 * 初始化HMS的时候提供的数据库实现。
 *
 * HMS 直接提供两种实现：
 * 1. Android的原生API
 *      * `implementation "com.squareup.sqldelight:android-driver:1.0.0"`
 * 2. 微信的WCDB实现（提供wcdb的一切特性，如数据库加密）
 *      * `implementation "com.tencent.hms:ext-wcdb:1.0.0"`
 *
 * 业务如有特殊需求，可以自行实现一个 [SqlDriver] ，具体参考 [SQLDelight](https://github.com/square/sqldelight)
 */
interface HMSSqlDriverFactory {
    fun createSqlDriver(schema: SqlDriver.Schema, databaseName: String): SqlDriver
}

/**
 * 收到新消息时的回调，通过 [HMSCore.setNewMessageListener] 注册
 * 新消息按照回话分组批量回调
 * @see [NewMessages]
 */
interface HMSNewMessageListener {

    /**
     * @property sessionId 会话 id
     * @property messages 该会话的新消息, 按照消息顺序排列，老消息在前，新消息在后
     */
    data class NewMessages(
        val sessionId: String,
        val messages: List<HMSMessage>
    )

    fun onNewMessage(list: List<NewMessages>)
}

/**
 * HMS 内部有许多供业务使用，SDK透传的数据，为了方便这些数据的使用。
 *
 * HMS在API上会以反序列化的对象的形式暴露给外部，类型是[Any]上层自行转换类型后使用。
 *
 * 因此这里需要上层初始化的时候执行这些数据的 序列化/反序列化 实现。
 *
 * 如果业务侧没有使用过特定类型的 透传数据(即对应接口传入的参数为 `null`)，不用提供对应的实现，
 * HMS 不会调用对应的方法，可以直接在方法中抛出 [UnsupportedOperationException] (默认实现既是如此）。
 *
 * 这些透传数据包括:
 *
 * 1. [HMSPlainMessage.payload]
 * 2. [HMSMessage.extension]
 * 3. [HMSSession.businessBuffer]
 * 4. [HMSUser.businessBuffer]
 * 5. [HMSUserInSession.businessBuffer]
 */
abstract class HMSSerializer {

    /**
     * for [HMSPlainMessage.payload]
     * @param type [HMSPlainMessage.type]
     */
    open fun serializeMessagePayload(type: Int, payload: Any): ByteArray {
        error("HMSMessage.payload")
    }

    /**
     * for [HMSPlainMessage.payload]
     * @param type [HMSPlainMessage.type]
     */
    open fun deserializeMessagePayload(type: Int, payload: ByteArray): Any {
        error("HMSMessage.payload")
    }

    /**
     * for [HMSMessage.extension]
     */
    open fun serializeMessageExtension(extension: Any): ByteArray {
        error("HMSMessage.extension")
    }

    /**
     * for [HMSMessage.extension]
     */
    open fun deserializeMessageExtension(extension: ByteArray): Any {
        error("HMSMessage.extension")
    }

    /** for [HMSSession] */
    open fun serializeSessionBusinessBuffer(businessBuffer: Any): ByteArray {
        error("HMSSession.businessBuffer")
    }

    /** for [HMSSession] */
    open fun deserializeSessionBusinessBuffer(businessBuffer: ByteArray): Any {
        error("HMSSession.businessBuffer")
    }

    /** for [HMSSession.extension] */
    open fun serializeSessionExtension(extension: Any): ByteArray {
        error("HMSSession.extension")
    }

    /** for [HMSSession.extension] */
    open fun deserializeSessionExtension(extension: ByteArray): Any {
        error("HMSSession.extension")
    }

    /** for [HMSUser.businessBuffer] */
    open fun serializeUserBusinessBuffer(businessBuffer: Any): ByteArray {
        error("HMSUser.businessBuffer")
    }

    /** for [HMSUser.businessBuffer] */
    open fun deserializeUserBusinessBuffer(businessBuffer: ByteArray): Any {
        error("HMSUser.businessBuffer")
    }

    /** for [HMSUserInSession.businessBuffer] */
    open fun serializeUserInSessionBusinessBuffer(businessBuffer: Any): ByteArray {
        error("HMSUserInSession.businessBuffer")
    }

    /** for [HMSUserInSession.businessBuffer] */
    open fun deserializeUserInSessionBusinessBuffer(businessBuffer: ByteArray): Any {
        error("HMSUserInSession.businessBuffer")
    }

    @Suppress("NOTHING_TO_INLINE")
    private inline fun error(name: String): Nothing {
        throw UnsupportedOperationException("""
            |serialize/deserialize $name is not supported, please implement the corresponding method(this one) first.
            |如果你遇到这个异常，请查看 HMS的文档，了解 HMSSerializer 的相关介绍。
        """.trimMargin())
    }
}

