package com.tencent.hms

import com.squareup.sqldelight.db.SqlDriver
import com.squareup.wire.ProtoAdapter
import com.tencent.hms.internal.*
import com.tencent.hms.internal.message.MessageReceiveManager
import com.tencent.hms.internal.message.MessageSendManager
import com.tencent.hms.internal.protocol.PushData
import com.tencent.hms.internal.report.ReportLogManager
import com.tencent.hms.internal.repository.HMSDatabase
import com.tencent.hms.internal.repository.fixDirtyRecordsInDatabase
import com.tencent.hms.internal.session.SessionManager
import com.tencent.hms.internal.trigger.TriggerManager
import com.tencent.hms.internal.trigger.TriggerSqlDriver
import com.tencent.hms.internal.user.UserManager
import com.tencent.hms.message.*
import com.tencent.hms.profile.HMSMemberInfo
import com.tencent.hms.profile.HMSUser
import com.tencent.hms.profile.HMSUserRole
import com.tencent.hms.session.*
import kotlinx.coroutines.*

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-07
 * Time:   19:36
 * Life with Passion, Code with Creativity.
 * ```
 */
/**
 * HMS sdk 的核心入口类，提供了 会话、消息、用户数据等的操作接口。
 */
class HMSCore internal constructor(
    val appId: String,
    val uid: String,
    private val networkTransfer: HMSNetworkTransfer,
    _sqlDriver: SqlDriver,
    internal val executors: HMSExecutors,
    internal val serializer: HMSSerializer,
    internal val logger: HMSLogger,
    internal val isEmptyC2CSessionShow: Boolean

) {

    internal val triggerManager: TriggerManager
    internal val database: HMSDatabase
    internal val databaseNoLog: HMSDatabase //没有log记录的database实例，防止db log循环问题
    internal val sqlDriver: SqlDriver

    private val hmsJob = SupervisorJob()
    internal val hmsScope: CoroutineScope = CoroutineScope(
        hmsJob + Worker + HMSCoroutineExceptionHandler(logger)
    )

    val isDestroyed
        get() = hmsJob.isCancelled

    init {
        // init database
        val sqlDriverWithLog = LoggedSqlDriver(_sqlDriver, this)

        triggerManager = TriggerManager(executors, sqlDriverWithLog)
        sqlDriver = TriggerSqlDriver(executors, triggerManager, sqlDriverWithLog)

        database = HMSDatabase(sqlDriver)
        databaseNoLog = HMSDatabase(_sqlDriver)
    }

    // internal managers
    internal val messageSendManager = MessageSendManager(this)
    internal val messageReceiveManager = MessageReceiveManager(this)
    internal val sessionManager = SessionManager(this)
    internal val userManager = UserManager(this)
    internal val heartBeatManager = HeartbeatManager(this)
    internal val reportLogManager = ReportLogManager(this)

    init {
        // init network transfer
        networkTransfer.attachHmsCore(this)
    }

    internal suspend fun <T> sendRequest(
        type: HMSRequestType,
        wireMessage: com.squareup.wire.Message<*, *>,
        wireAdapter: ProtoAdapter<T>
    ): T = withContext(Worker) {
        val requestData = wireMessage.encode()
        logger.v(TAG) { "request: [$type] size:${requestData.size} \n$wireMessage" }
        try {
            assertServerData(message = "sendRequest $type") {
                val replyData = networkTransfer.sendRequest(
                    type,
                    requestData,
                    REQUEST_TIMEOUT_MILLIS
                )
                val reply = replyData.decode(wireAdapter)
                logger.v(TAG) { "reply: [$type] size:${replyData.size} \n$reply" }
                reply
            }
        } catch (e: HMSException) {
            logger.e(TAG, e) { "sendRequest type: [$type] failed" }
            throw e
        }
    }

    internal suspend fun <T> sendRequestWithRetry(
        type: HMSRequestType,
        wireMessage: com.squareup.wire.Message<*, *>,
        wireAdapter: ProtoAdapter<T>
    ): T = withContext(Worker) {
        val requestData = wireMessage.encode()
        logger.v(TAG) { "request: [$type] size:${requestData.size} \n$wireMessage" }
        try {
            assertServerData(message = "sendRequest $type") {
                val replyData = networkTransfer.sendRequest(
                    type,
                    requestData,
                    REQUEST_TIMEOUT_MILLIS,
                    REQUEST_RETRY_COUNT
                )
                val reply = replyData.decode(wireAdapter)
                logger.v(TAG) { "reply: [$type] size:${replyData.size} \n$reply" }
                reply
            }
        } catch (e: HMSException) {
            logger.e(TAG, e) { "sendRequestWithRetry type: [$type] failed" }
            throw e
        }
    }

    /**
     * initialize HMSCore
     */
    internal suspend fun initialize() {
        logger.i(TAG) { "HMSCore::initialize versionName:$VERSION versionCode:0x${VERSION_CODE.toString(16)} $this" }

        // migrate db if necessary
        // SqlDelight handles this

        // fix dirty data
        fixDirtyRecordsInDatabase()

        // fetch latest session data asynchronously
        sessionManager.init()
        userManager.init()
        reportLogManager.init()
    }

    /**
     * 销毁当前实例，释放内部资源。当业务侧需要注销等场景的时候可以使用该接口。
     * 注意：销毁之后，相关的 [HMSMessageListLogic] [HMSSessionListLogic] 等实例都将失效,
     * 相关的接口调用会抛出/回调 [HMSInstanceDestroyedException] 异常。
     *
     * @throws HMSInstanceDestroyedException 当该HMSCore实例已经 [destroy] 了
     */
    fun destroy(callback: HMSDisposableCallback<HMSResult<Unit>>?) {
        assertNonDestroy()
        logger.i(TAG) { "HMSCore::destroy versionName:$VERSION versionCode:$VERSION_CODE $this" }

        networkTransfer.detachHmsCore()
        GlobalScope.launch(Worker) {
            destroyInternal()
            callback?.callback(HMSResult.success(Unit))
        }
    }

    private suspend fun destroyInternal() {
        hmsJob.cancel()
        triggerManager.destroy()
        executors.destroy()
        @Suppress("BlockingMethodInNonBlockingContext")
        sqlDriver.close()
    }

    /**
     * register an offline push token
     */
    fun registerPushToken(token: HMSPushToken, callback: HMSDisposableCallback<HMSResult<Unit>>) {
        networkTransfer.registerPushToken(token, callback)
    }

    /**
     * currently login user info
     */
    val account: HMSObservableData<HMSUser>
        get() = userManager.mineAccount

    /**
     * 提供一个获取全量session未读数的Observable Data
     *
     * 该数据会自动监听未读数的数据变化，通过observable 可获得实时的变化结果
     */
    val unreadCount: HMSObservableData<Long>
        get() = sessionManager.unreadCountCache


    /**
     *
     * 获取全部session的未读计数总和，可以通过 filter 过滤掉不想计算进去的session
     * @param sessionFilter  用于业务侧过滤掉不需要的会话
     * 类型是一个lambda，参数是 [HMSSession], 返回 `true` 表示需要计算未读计数
     *
     * @return 返回一个 [HMSObservableData]，会持续更新
     */
    @JvmOverloads
    fun getAllSessionUnreadCount(sessionFilter: ((HMSSession) -> Boolean)? = null): HMSObservableData<Long> =
        HMSSessionCountLogic(this, sessionFilter)

    /**
     * 创建一个会话列表，用于业务侧实现一个会话列表页面
     *
     * 该列表逻辑会自动监听任何的session变化，插入，删除，并自动更新数据，然后通过 [HMSListUpdateCallback] 通知到业务层数据变化。
     *
     * @param sessionFilter  用于业务侧过滤掉不需要的会话
     * 类型是一个lambda，参数是 [HMSSession], 返回 `true` 表示需要保留，返回`false`表示从列表中移除
     * @param sessionComparator 用于业务侧实现自定义的排序规则
     * 默认排序规则是按照session更新时间倒序排列（最后更新的session在上）
     *
     * @throws HMSInstanceDestroyedException 当该HMSCore实例已经 [destroy] 了
     */
    @JvmOverloads
    fun createSessionListLogic(
        sessionFilter: ((HMSSession) -> Boolean)? = null,
        sessionComparator: Comparator<HMSSession>? = null
    ): HMSSessionListLogic {
        assertNonDestroy()
        return HMSSessionListLogic(this, sessionFilter, sessionComparator)
    }

    /**
     * 创建一个消息列表，用于业务侧实现一个聊天页面
     *
     * 该列表逻辑会自动监听任何的消息变化，插入，删除，并自动更新数据，然后通过 [HMSListUpdateCallback] 通知到业务层数据变化。
     *
     * @param sessionId 会话id
     *
     * @param startIndex 指定开始加载的消息位置，null（默认值）表示从该会话最新的消息开始加载
     *
     * @param pageSize 分页大小,默认20，[HMSMessageListLogic] 内部自动处理消息的分页加载，消息按需一页一页加载出来，页的大小可以通过 pageSize 设置
     *
     * @param prefetchDistance 预拉取距离,默认为5. [HMSMessageListLogic] 内部会自动触发加载更多
     * （即，调用 [HMSMessageListLogic.loadMoreHistoryMessages] 或  [HMSMessageListLogic.loadMoreNewMessages])
     * 触发条件是调用 [HMSMessageListLogic.get] 的index距离边界距离小于该 prefetchDistance。
     * 当业务侧因为其他原因不想要自动预拉取的时候，可以将该参数至为0.
     *
     * @param maxListSize 消息列表在内存中最多存储的消息数量（默认是 [Int.MAX_VALUE] 即不限制）。
     * 当消息数量超过该上限时，[HMSMessageListLogic] 会自动淘汰消息，需要时重新从DB中重新加载。
     *
     * @param completeMessageHoles 当会话中消息数量过于巨大，server的push来不及下发所有消息，本地数据库中可能不会保留会话中的所有消息（即产生消息空洞）。该参数表示当有消息不在本地时，是否需要再次向server获取这部分消息。
     * 默认值为 `true`，业务侧可以针对自己的使用场景决定。
     * 1. （比如聊天室类型 [HMSSession.Type.CHAT_ROOM] 允许消息丢失就不需要补空洞）。
     * 2. 亦或是业务侧在无网络环境下仅展示本地消息，等
     *
     * @param messageFilter  用于业务侧过滤掉不需要的消息
     * 类型是一个lambda，参数是 [HMSSession], 返回 `true` 表示需要保留，返回`false`表示从列表中移除
     *
     * @throws HMSInstanceDestroyedException 当该HMSCore实例已经 [destroy] 了
     *
     *
     * 约定：
     * 0. pageSize > 0
     * 1. prefetchDistance < pageSize
     *  * prefetchDistance <= 0 表示禁用自动预拉取
     * 2. maxListSize > pageSize
     * 3. 当使用自动预拉取的时候 maxListSize 要适当比 pageSize 大 (一个合理的例子pageSize 20，maxListSize = 100)，
     * 否则容易出现前面的消息被淘汰后又被自动预拉取获取回来的情况。(要配合上层使用的RecyclerView的加载逻辑分析）
     */
    @JvmOverloads
    fun createMessageListLogic(
        sessionId: String,
        startIndex: HMSMessageIndex? = null,
        pageSize: Int = 20,
        prefetchDistance: Int = 5,
        maxListSize: Int = Integer.MAX_VALUE,
        completeMessageHoles: Boolean = true,
        messageFilter: ((HMSMessage) -> Boolean)? = null
    ): HMSMessageListLogic {
        assertNonDestroy()
        return HMSMessageListLogic(
            this,
            sessionId,
            startIndex,
            pageSize,
            prefetchDistance,
            maxListSize,
            completeMessageHoles,
            messageFilter
        )
    }

    /**
     * 设置一个监听，用于监听新消息到达，回调默认已经剔除了"自己"的消息。
     *
     * 该方法线程安全。且回调函数在主线程执行。
     */
    fun setNewMessageListener(newMessageListener: HMSNewMessageListener?) {
        messageReceiveManager.setNewMessageListener(newMessageListener)
    }

    internal fun onPushData(data: ByteArray) {
        assertNonDestroy()
        hmsScope.launch {
            try {
                assertServerData(message = "onPushData") {
                    val pushData = data.decode(PushData.ADAPTER).data
                    logger.v(TAG) { "onPushData size:${data.size} \n$pushData" }
                    when (pushData) {
                        is PushData.Data.Notify -> messageReceiveManager.onNotify(pushData.notify)
                        is PushData.Data.NotifyData -> messageReceiveManager.onNotifyData(pushData.notifyData)
                        null -> logger.w(TAG) { "unknown push data" }
                    }
                }
            } catch (e: HMSException) {
                logger.e(TAG, e) { "onPushData failed" }
            }
        }
    }

    internal fun onNetworkStatusChange(isConnected: Boolean) {
        if (!isDestroyed) {
            sessionManager.onNetworkStatusChange(isConnected)
        }
    }

    /**
     * 上层来设置 HMS IM的状态是在前台还是后台。
     * 对于上层业务来说 IM 可能只是一个业务模块，因此只有当该模块可见时才算做前台。
     * 具体由业务决定。
     *
     * 当HMS处于前台时，为保证消息的及时可达会有额外动作来保证（如心跳），
     * 因此正确的设置HMS为后台状态可以节省资源。
     *
     * 注意：HMS初始化完成后默认处于后台状态
     *
     * @throws HMSInstanceDestroyedException 当该HMSCore实例已经 [destroy] 了
     */
    var isForeground: Boolean = false
        set(value) {
            assertNonDestroy()
            field = value
            logger.v(TAG) { "setIsForeground $value" }
            sessionManager.onForegroundStatusChange(value)
            heartBeatManager.onForegroundStatusChange(value)
        }

    companion object {
        private const val TAG = "HMSCore"
        /**
         * version for HMS sdk
         */
        const val VERSION = BuildConfig.VERSION_NAME

        internal const val VERSION_CODE = BuildConfig.VERSION_CODE

        /**
         * 初始化 HMS，创建一个HMS的实例
         * @param arguments 初始化参数，详见 [HMSCore.InitializeArguments]
         */
        @JvmStatic
        fun initialize(
            arguments: InitializeArguments,
            callback: HMSDisposableCallback<HMSResult<HMSCore>>
        ) {
            val executors = HMSExecutors(arguments.executorDelegate)
            GlobalScope.launch(executors.Worker) {
                unwrapCoroutine(executors.Main, callback) {
                    initialize(arguments)
                }
            }
        }
    }

    /**
     * HMS的初始化参数
     *
     * 针对 Android 应用，推荐使用 [HMSAndroidInitializeArgumentsBuilder], 其针对大部分参数提供默认实现
     *
     * @see com.tencent.hms.extension.android.HMSAndroidInitializeArgumentsBuilder
     */
    data class InitializeArguments(
        /**
         * HMS 的 APPID
         */
        internal val appId: String,
        /**
         * 该用户的 id
         */
        internal val uid: String,
        /**
         * 注入一个线程池实现，HMS内部复用业务线程池，防止创建过多线程消耗资源。
         */
        internal val executorDelegate: HMSExecutorDelegate,
        /**
         * HMS的网络层实现，HMS提供了 [WnsNetworkTransfer] 实现，依赖 WNS 实现网络接口。
         */
        internal val networkTransfer: HMSNetworkTransfer,
        /**
         * HMS 的数据库实现，HMS 依赖 SQLDelight 提供了默认的 [AndroidSqlDriverFactory] 实现，
         * 同时还提供了基于微信的 WCDB 的实现 [WcdbSqlDriver]
         */
        internal val sqlDriverFactory: HMSSqlDriverFactory,
        /**
         * 业务透传数据的 序列化/反序列化 实现，详见 [HMSSerializer]
         *
         * @see HMSSerializer
         */
        internal val serializer: HMSSerializer,
        /**
         * HMS的日志代理，业务可以将hms的日志记录到自己的日志框架中
         */
        internal val logDelegate: HMSLogDelegate,

        /**
         * 没有消息的C2C会话是否出现在最近会话列表，默认是不出现（修改此项只会对新数据生效）
         */
        internal val isEmptyC2CSessionShow: Boolean
    )

    /** MARK: expose methods of [SessionManager] */


    /**
     * 创建会话(新方法，业务无需每次序列化）
     *
     * saveToRecentSessionList ,创建session后是否存储到最近会话列表中
     */
    fun createSession(
        type: HMSSession.Type,
        users: List<String>,
        sessionName: String? = null,
        avatar: String? = null,
        businessBuffer: Any? = null,
        callback: HMSDisposableCallback<HMSResult<HMSSession>>
    ) = unwrapCoroutine(callback) { createSession(type, users, sessionName, avatar, businessBuffer) }


    /**
     * 通过对方的uid，获得C2C会话
     */
    fun getC2CSession(toUid: String, callback: HMSDisposableCallback<HMSResult<HMSSession>>) =
        unwrapCoroutine(callback) { getC2CSession(toUid) }

    /**
     * 通过sessionIds批量获得session相关信息
     *
     * withCount :是否带上未读数信息
     * withMsg :是否有最新一条消息
     */
    fun getSessionListBySid(
        sids: List<String>,
        withCount: Boolean = false,
        withMsg: Boolean = false,
        callback: HMSDisposableCallback<HMSResult<List<HMSSession>>>
    ) = unwrapCoroutine(callback) { getSessionListBySid(sids, withCount, withMsg) }

    /**
     * 获得会话资料，以 [HMSObservableData] 的形式返回，方便上层监听数据更新。
     * @see HMSObservableData
     */
    fun getSessionObservableData(sid: String) =
        sessionManager.getSessionObservableData(sid)

    /**
     * 禁用消息的本地存储（用于无需持久化的会话类型，比如chat room)
     */
    fun disableStorage(sids: List<String>, callback: HMSDisposableCallback<HMSResult<Unit>>?) =
        unwrapCoroutine(callback) { sessionManager.disableStorage(sids) }

    /**
     * 标记会话已读，更新未读计数
     */
    fun setSessionRead(
        sid: String,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { setSessionRead(sid) }

    /**
     * 强制刷新会话列表
     */
    fun syncSessionList(callback: HMSDisposableCallback<HMSResult<Unit>>?) =
        unwrapCoroutine(callback) { syncSessionList() }

    /**
     * 设置会话的自定义字段
     * extension 为null是会清空extension
     */
    fun updateSessionExtension(
        sid: String,
        extension: Any?,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) =  unwrapCoroutine(callback) { updateSessionExtension(sid, extension) }


    /**
     * 更新C2C好友关系链
     */
    fun updateSessionFriendType(toUid:String,friendType:Int,callback:HMSDisposableCallback<HMSResult<Unit>>?) =
        unwrapCoroutine(callback) { updateSessionFriendType(toUid,friendType) }


    /**
     * 往群组中加人
     * 1. 邀请人进群组时填写被邀请人的uid
     * 2. 主动加入群组时，填写自己的uid
     */
    fun addUserToSession(
        sessionId: String,
        uids: List<String>,
        callback: HMSDisposableCallback<HMSResult<List<HMSAddToSessionResultItem>>>
    ) = unwrapCoroutine(callback) { addUserToSession(sessionId, uids) }

    /**
     *从服务端最近列表中删除会话，之前的消息都无法拉取到
     *
     */
    fun deleteSession(
        sid: String,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { deleteSession(sid) }


    /**
     * 删除本地session, 仅删除本地记录，当该session有新的消息时，会再次出现在 [HMSSessionListLogic] 中。
     * 如需退出会话，使用 [quitSession]
     */
    fun deleteLocalSession(
        sid: String,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { deleteLocalSession(sid) }

    /**
     * 从群组中退出
     */
    fun quitSession(
        sessionID: String,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { quitSession(sessionID) }

    /**
     * 删除群组中某个成员
     */
    fun deleteSessionMember(
        sid: String,
        uids: List<String>,
        callback: HMSDisposableCallback<HMSResult<List<HMSDeleteSessionMemberResultItem>>>
    ) = unwrapCoroutine(callback) { deleteSessionMember(sid, uids) }


    /**
     * 解散群,只有群主有此功能
     */
    fun destroySession(
        sessionID: String,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { destroySession(sessionID) }

    /**
     * 删除session的本地消息（不影响server和其他终端）
     */
    fun deleteSessionMessages(
        sessionID: String,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { deleteSessionMessages(sessionID) }

    /**
     * 更新会话的消息提醒类型
     */
    fun changeSessionMessageAlertType(
        sessionId: String,
        messageAlertType: HMSMessageAlertType,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) {
        changeSessionMessageAlertType(sessionId, messageAlertType)
    }

    /**
     * 更新群名片
     * remark, businessBuffer 字段可以任意更新其中几个。
     * 对于不需要更新的字段可以使用 [STRING_PLACEHOLDER], [ANY_PLACEHOLDER] 占位，或者使用Kotlin的函数默认值。
     */
    fun updaterUserInSession(
        sessionID: String,
        uid: String,
        remark: String? = STRING_PLACEHOLDER,
        businessBuffer: Any? = ANY_PLACEHOLDER,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { updaterUserInSession(sessionID, uid, remark, businessBuffer) }

    /**
     * 更新session info
     * name, avatar, businessBuffer 三个字段可以任意更新其中几个。
     * 对于不需要更新的字段可以使用 [STRING_PLACEHOLDER], [ANY_PLACEHOLDER] 占位，或者使用Kotlin的函数默认值。
     */
    fun updateSessionInfo(
        sid: String,
        name: String? = STRING_PLACEHOLDER,
        avatar: String? = STRING_PLACEHOLDER,
        businessBuffer: Any? = ANY_PLACEHOLDER,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { updateSessionInfo(sid, name, avatar, businessBuffer) }

    /**
     * 禁言
     */
    fun updateSessionBannedStatus(
        sid: String,
        uid: String,
        duringTimeOfBan: Long,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { updateSessionBannedStatus(sid, uid, duringTimeOfBan) }

    /**
     * 权限
     */
    fun updateRoleInSession(
        sid: String,
        uid: String,
        role: HMSUserRole,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { updateRoleInSession(sid, uid, role) }

    /**
     * 转让群主
     */
    fun transferSessionOwner(
        sid: String,
        toUid: String,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { transferSessionOwner(sid, toUid) }

    /**
     * 黑名单
     */
    fun getBlackList(
        callback: HMSDisposableCallback<HMSResult<List<String>>>
    ) = unwrapCoroutine(callback) { getBlackList() }

    fun addToBlackList(
        toUid: String,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { addToBlackList(toUid) }

    fun removeFromBlackList(
        toUid: String,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { removeFromBlackList(toUid) }

    /** MARK: expose methods of [MessageSendManager] */

    /**
     *
     * 将普通消息插入本地存储，并发送至server。
     * 消息插入本地存储之后就会立即在 [HMSMessageListLogic] 中出现，
     * 即便消息发送失败（如无网络），消息也能够呈现在UI上，业务侧可以通过 [sendLocalMessage] 重试发送。
     *
     * @param text 消息的文本，其中的文字及url会被后台的安全策略扫描打击
     * @param pushText 离线push的文本，默认使用text，当业务需要特殊的离线push文本，可以填写该字段
     * @param type 消息的类型，由上层指定，HMS透传，一个type对应一种payload
     * @param payload 消息的负载，会发送到server，并同步到各终端
     * @param extension 消息的本地扩展，只会存在本地，不会发送到server
     * @param reminds 消息提醒哪些用户看（即 "at" 逻辑）
     * @param isNeedClearRedPoint 客户端发送消息的时候，是否需要将该会话的所有消息置为已读，默认为true
     *
     * @see HMSPlainMessage
     * @see HMSMessageIndex
     */
    @JvmOverloads
    fun sendMessage(
        sessionId: String,
        type: Int,
        text: String,
        pushText: String?,
        payload: Any?,
        reminds: List<String>,
        extension: Any?,
        isNeedClearRedPoint: Boolean = true,
        callback: HMSDisposableCallback<HMSResult<HMSMessageIndex>>
    ) = unwrapCoroutine(callback) {
        sendMessage(
            sessionId,
            type,
            text,
            pushText,
            payload,
            reminds,
            extension,
            isNeedClearRedPoint
        )
    }

    /**
     * 撤回一个已经发送出去的消息，当一个消息被撤回后，其[HMSMessage.isRevoked]为true
     * @param messageIndex 要更新的消息的index，该消息的状态必须是 [HMSMessageStatus.SUCCESS]，即必须是一个服务端存在的消息
     * **当 messageIndex 的消息是一个本地消息时 （只能revoke一个server消息），该调用必然失败！**
     */
    fun revokeMessage(
        messageIndex: HMSMessageIndex,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { revokeMessage(messageIndex) }

    /**
     * 更新一个已经发送出去的消息。
     *
     * 与 [updateLocalMessage] 不同，该请求会更新后台消息，并将新的消息内容推送到各个用户。
     *
     * @param messageIndex 要更新的消息的index，该消息的状态必须是 [HMSMessageStatus.SUCCESS]，即必须是一个服务端存在的消息
     * @param type 更新到新的type
     * @param text 更新新的消息文本
     * @param payload 更新新的消息payload
     *
     * **当 messageIndex 的消息是一个本地消息时 （只能update一个server消息），该调用必然失败！**
     */
    fun updateMessage(
        messageIndex: HMSMessageIndex,
        type: Int,
        text: String,
        payload: Any?,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { updateMessage(messageIndex, type, text, payload) }

    /**
     * 参数含义详见 [sendMessage]
     */
    fun addLocalMessage(
        sessionId: String,
        type: Int,
        text: String,
        pushText: String?,
        payload: Any?,
        reminds: List<String>,
        extension: Any?,
        callback: HMSDisposableCallback<HMSResult<HMSMessageIndex>>
    ) = unwrapCoroutine(callback) {
        addLocalMessage(
            sessionId,
            type,
            text,
            pushText,
            payload,
            reminds,
            extension
        )
    }

    /**
     * 主要针对发送的消息消息进行重发逻辑
     * 或发送[addLocalMessage]的本地消息
     *
     * @param isNeedClearRedPoint 客户端发送消息的时候，是否需要将该会话的所有消息置为已读，默认为true
     */
    @JvmOverloads
    fun sendLocalMessage(
        index: HMSMessageIndex,
        isNeedClearRedPoint: Boolean = true,
        callback: HMSDisposableCallback<HMSResult<HMSMessageIndex>>
    ) = unwrapCoroutine(callback) { sendLocalMessage(index, isNeedClearRedPoint) }

    /**
     * 将消息从本地存储中删除，然后重新插入到本地存储的最后（最新一个消息），然后重新发送。
     * 主要针对发送失败的消息进行重发逻辑。
     * 该方法会导致重发的消息重新排序到最新的一条消息。
     * @param isNeedClearRedPoint 客户端发送消息的时候，是否需要将该会话的所有消息置为已读，默认为true
     */
    @JvmOverloads
    fun deleteAndResendLocalMessage(
        index: HMSMessageIndex,
        isNeedClearRedPoint: Boolean = true,
        callback: HMSDisposableCallback<HMSResult<HMSMessageIndex>>
    ) = unwrapCoroutine(callback) { deleteAndResendLocalMessage(index, isNeedClearRedPoint) }

    /**
     * 查询本地database中的消息，可以是[addLocalMessage]消息，也可以是server上同步下来的消息。
     *
     * Anything in the database。
     */
    fun queryLocalMessage(
        index: HMSMessageIndex,
        callback: HMSDisposableCallback<HMSResult<HMSMessage>>
    ) = unwrapCoroutine(callback) { queryLocalMessage(index) }

    /**
     * 删除database中的**任何**一条消息，可以是自己的，也可以是别人的
     *
     * @see queryLocalMessage
     */
    fun deleteLocalMessage(
        index: HMSMessageIndex,
        callback: HMSDisposableCallback<HMSResult<Unit>>?
    ) = unwrapCoroutine(callback) { deleteLocalMessage(index) }

    /**
     * 更新database中的消息，可以是自己的，也可以是别人的
     * 参数分别对应 [HMSPlainMessage] 中的字段
     * 允许部分更新 type, text, pushText, payload, reminds, extension 中的任意一到多个。
     * 需要更新的字段参数传入其最新值，不需要更新的字段使用 [STRING_PLACEHOLDER] 等一系列占位符标记即可。
     *
     * 注意：**当需要更新[HMSPlainMessage.payload]的时候，需要传入正确的type（不能是[INT_PLACEHOLDER]，也就是 `null`).**
     *
     * 对于Kotlin的用户，建议使用命名参数，如：
     * ```
     * hmsCore.updateLocalMessage(index = messageIndex, text = "new message")
     * ```
     * 可使代码尽量简洁。
     *
     * @param extension 对应 [HMSMessage.extension]
     *
     */
    fun updateLocalMessage(
        index: HMSMessageIndex,
        type: Int? = INT_PLACEHOLDER,
        text: String = STRING_PLACEHOLDER,
        pushText: String? = STRING_PLACEHOLDER,
        payload: Any? = ANY_PLACEHOLDER,
        reminds: List<String> = LIST_PLACEHOLDER(),
        extension: Any? = ANY_PLACEHOLDER,
        callback: HMSDisposableCallback<HMSResult<HMSMessageIndex>>
    ) = unwrapCoroutine(callback) {
        updateLocalMessage(
            index,
            type,
            text,
            pushText,
            payload,
            reminds,
            extension
        )
    }

    /** MARK: expose methods of [UserManager] */

    /**
     * 修改用户资料
     *
     * name, avatar, businessBuffer 三个字段可以任意更新其中几个。
     * 对于不需要更新的字段可以使用 [STRING_PLACEHOLDER], [ANY_PLACEHOLDER] 占位，或者使用Kotlin的函数默认值。
     *
     */
    fun updateUserInfo(
        uid: String,
        name: String? = STRING_PLACEHOLDER,
        avatar: String? = STRING_PLACEHOLDER,
        businessBuffer: Any? = ANY_PLACEHOLDER,
        callback: HMSDisposableCallback<HMSResult<HMSUser>>
    ) = unwrapCoroutine(callback) { updateUserInfo(uid, name, avatar, businessBuffer) }

    /**
     * 获得用户资料
     *
     */
    fun getUsers(
        uids: List<String>,
        callback: HMSDisposableCallback<HMSResult<List<HMSUser>>>
    ) = unwrapCoroutine(callback) { getUsers(uids) }

    /**
     * 获得用户资料，以 [HMSObservableData] 的形式返回，方便上层监听数据更新。
     * @see HMSObservableData
     */
    fun getUserObservableData(uid: String, getFromServer: Boolean = false): HMSObservableData<HMSUser> =
        userManager.getUserObservableData(uid, getFromServer)

    /**
     * 获得会话用户资料，以 [HMSObservableData] 的形式返回，方便上层监听数据更新。
     * @see HMSObservableData
     */
    fun getUserMemberInfoObservableData(
        sessionId: String,
        uid: String,
        getFromServer: Boolean = false
    ): HMSObservableData<HMSMemberInfo> =
        userManager.getUserMemberInfoObservableData(sessionId, uid, getFromServer)

    /**
     * 获得user profile and useInSession profile
     */
    fun getUsersMemberInfo(
        sessionId: String,
        uids: List<String>,
        callback: HMSDisposableCallback<HMSResult<List<HMSMemberInfo>>>
    ) = unwrapCoroutine(callback) { getUsersMemberInfo(sessionId, uids) }


    /**
     * 在线获得session 所有成员列表
     */
    fun getSessionMemberList(
        sessionID: String,
        callback: HMSDisposableCallback<HMSResult<List<HMSMemberInfo>>>
    ) = unwrapCoroutine(callback) { getSessionMemberList(sessionID) }
}


