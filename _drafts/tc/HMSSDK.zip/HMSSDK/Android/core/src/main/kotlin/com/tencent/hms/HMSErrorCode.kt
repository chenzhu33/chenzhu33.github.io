package com.tencent.hms

/**
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2019-03-12
 * Time:   17:15
 * Life with Passion, Code with Creativity.
 * </pre>
 */

/**
 * HMS 请求失败的错误码对照表
 * 其他段的错误码一般为维纳斯错误，可以参见维纳斯错误码列表 http://km.oa.com/articles/show/290780
 */
class HMSErrorCode private constructor() {
    companion object {

        /** =========== SDK 错误码 [-8000, -8999] =========== */
        /** 数据库初始化错误 */
        const val DBInitError = -8001

        /** 数据库操作错误 */
        const val DBOperationError = -8002

        /** 网络有问题 */
        const val BadNetwork = -8003

        /** 网络超时 */
        const val NetworkTimeout = -8004


        /** =========== 后台返回的错误 =========== */
        /** message is nil */
        const val MessageNil = -9001

        /** pb打包失败 */
        const val PbMarshalError = -9002

        /** base64 decode失败 */
        const val Base64DecodeError = -9003

        /** 无效HMS appid */
        const val HMSAppidInvaild = -9004

        /** Uid列表为空 */
        const val UidListEmpty = -9005

        /** client请求失败 */
        const val ClientReqError = -9006

        /** Map key不存在 */
        const val MapKeyNil = -9007

        /** 参数列表格式错误 */
        const val ParamListInvalid = -9008

        /** string转int64失败 */
        const val ParseIntError = -9009

        /** pb解包失败 */
        const val PbUnMarshalError = -9010

        /** map to strutct失败 */
        const val Map2structureError = -9011

        /** qmfClient服务调用出错 */
        const val QmfClientError = -9012

        /** 参数列表为空 */
        const val ParamListEmtpyError = -9013

        /** 参数错误 */
        const val ParamError = -9014

        /** 参数列表格式错误 */
        const val SessionTypeInvalid = -9015


        // HMS消息会话中心 返回码
        // 范围：[-10101, -10300]

        /** 获取TList存储列表失败 */
        const val GetTListError = -10101

        /** 超过撤回的时间限制 */
        const val ExceedRevokeTimeLimit = -10103

        /** 消息列表为空 */
        const val MessageListEmpty = -10104

        /** 撤回seq有问题 */
        const val RevokeNumberError = -10105

        /** 要撤回的消息早已经被撤回了 */
        const val RevokeMessageDuplication = -10106

        /** TList修改行存储错误 */
        const val TListModRowError = -10109

        /** 设置消息的Sender和SenderInSession信息失败 */
        const val SetSenderAndSenderInSessionError = -10110

        /** 通过SessionID获取会话中的成员列表失败 */
        const val GetUidsInSessionError = -10111

        /** 黑名单或被禁言 */
        const val InBlackListOrBanned = -10112

        /** 拿消息要发的Uid列表失败 */
        const val PackageToUidsErr = -10113


        // HMS关系链svr 返回码
        // 范围：[-10301, -10500]

        /** 非群聊会话 */
        const val NotGroupSessionIDError = -10301

        /** 非私聊会话 */
        const val NotPrivateSessionIDError = -10302

        /** 会话ID不存在 */
        const val SessionIDNotExistError = -10303

        /** 用户不是会话成员 */
        const val UserNotInSessionError = -10304

        /** 权限不足 */
        const val PermissionDeniedError = -10305

        /** 用户不存在 */
        const val UserNotExistError = -10306

        /** 无效权限 */
        const val InvalidPermission = -10307

        /** 删除群成员失败 */
        const val DeleteSessionMemberError = -10308

        /** 会话成员列表为空 */
        const val SessionMemberListEmptyError = -10309

        /** SessionInfo nil */
        const val SessionInfoEmptyError = -10310

        /** UserProfile nil */
        const val UserProfileEmptyError = -10311

        /** 无效会话类别 */
        const val SessionTypeInvalidError = -10312

        /** 无效uid列表 */
        const val UidListInvalid = -10313

        /** 获取Session完整信息失败 */
        const val GetSessionError = -10314

        /** 单聊创建会话，uid长度不对 */
        const val C2CSessionUidLenError = -10315

        /** 更新成员列表的字段错误 */
        const val GetUpdateMemberInfoFieldError = -10316

        /** MemberInfo nil */
        const val MemberInfoEmptyError = -10317

        /** 只能改自己的UserInfo */
        const val OnlyChangeInfoOfYourself = -10318


        // HMS下行svr 返回码
        // 范围：[-10501, -10700]

        /** 将会话ID存到最近会话列表失败 */
        const val SetSessionListError = -10501

        /** 从会话列表中删除某一会话失败 */
        const val DeleteSessionError = -10502

        /** 往会话禁言名单中添加uid失败 */
        const val AddToWordForbiddenListError = -10503

        /** 从会话禁言名单移除uid失败 */
        const val RemoveFromWordForbiddenListError = -10504

        /** 往黑名单中添加uid失败 */
        const val AddToBlackListError = -10505

        /** 从黑名单中移除uid失败 */
        const val RemoveFromBlackListError = -10506

        /** 获取黑名单列表失败 */
        const val GetBlackListError = -10507


        // 业安 返回码
        // 范围： [-10701, -10800]

        /** 频率控制 */
        const val BusiSecurityFreControl = -10702

        /** 控制开关 */
        const val BusiSecurityControlSwitch = -10703

        /** 恶意分析 */
        const val BusiSecurityHostilityAnalyze = -10704

        /** 评论去重 */
        const val BusiSecurityCommentRepeated = -10705

        /** 命中信安关键词 */
        const val BusiSecurityDirtyWord = -10706

        /** 命中U镜 */
        const val BusiSecurityUmirroBeat = -10707

        /** 1 */
        const val BusiSecurityUseridIllegal = -10708

        /** 命中黑白名单(UINIP内容等 */
        const val BusiSecurityBlackList = -10709

    }
}

