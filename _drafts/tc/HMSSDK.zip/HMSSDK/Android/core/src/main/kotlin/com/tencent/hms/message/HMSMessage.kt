package com.tencent.hms.message

import com.tencent.hms.HMSCore
import com.tencent.hms.HMSIllegalServerResponseException
import com.tencent.hms.HMSSerializer
import com.tencent.hms.internal.assertServerData
import com.tencent.hms.internal.decode
import com.tencent.hms.internal.pb
import com.tencent.hms.internal.protocol.Message
import com.tencent.hms.internal.protocol.MessageElement
import com.tencent.hms.internal.repository.model.MessageDB
import com.tencent.hms.profile.HMSMemberInfo

/**
 * HMS消息数据结构
 * HMS消息分为两种:
 * ### 普通消息 [HMSPlainMessage]
 *  所有用户发送的消息，重点介绍几个字段：
 * 1. text 即消息的文本内容，HMS后台会对其中的文字、链接做安全打击
 * 2. push_text 离线push时，通知显示的文本内容，为null的时候则使用 text 做离线push
 * 2. type 结构化消息的类型
 * 3. payload 结构化消息的二进制内容
 * 消息设计的时候充分考虑了灵活性，因此除了text字段外还有 type和payload用于业务侧自行实现结构化的消息，如，语音，视频，文件，链接分享等。
 * 一种type对应一种payload，业务侧需要实现 [HMSSerializer.serializeMessagePayload] 和 [HMSSerializer.deserializeMessagePayload] 接口，实现特定type的payload如何编解码。
 *
 * ### 控制消息 [HMSControlMessage]
 *  系统发出的消息，如 创建回话，退出回话等。
 */
sealed class HMSMessage {
    /**
     * 消息的文本，其中的文字及url会被后台的安全策略扫描打击
     */
    abstract val text: String

    /**
     * 消息提醒阅读用户名单（ie. at 用户功能）
     */
    abstract val reminds: List<String>

    /**
     * 消息本地扩展
     */
    abstract val extension: Any?

    /**
     * 消息对应session的id
     */
    abstract val sessionId: String

    /**
     * 消息的时间戳（server time）
     */
    abstract val timestamp: Long

    /**
     * 消息状态
     */
    abstract val status: HMSMessageStatus

    /**
     * 消息是否已被删除（本地状态，删除消息不会同步到server上）
     */
    abstract val isDeleted: Boolean

    /**
     * 消息是否已被撤回
     */
    abstract val isRevoked: Boolean

    /**
     * 快捷判断消息是否是用户自己的
     */
    abstract val isMine: Boolean

    /**
     * 消息是否为控制消息 [HMSControlMessage]
     */
    abstract val isControlMessage: Boolean

    /**
     * 消息的索引，所有消息相关接口都需要这个索引来定位到具体消息
     */
    abstract val index: HMSMessageIndex

    /**
     * 消息体被更新后，updateTimeStamp会随之更新
     */

    abstract val updateTimeStamp: Long

    companion object {
        internal fun fromDB(
            db: MessageDB,
            hmsCore: HMSCore,
            senderInfo: HMSMemberInfo? = null
        ): HMSMessage {
            return try {
                assertServerData(message = "error parsing message [${db.text}]") {
                    val messageElement = db.data?.decode(MessageElement.ADAPTER)?.element
                    if (messageElement is MessageElement.Element.Control) {
                        val control = messageElement.control

                        val hmsControl =
                            control.let {
                                try {
                                    HMSControlElement.fromProtocol(it, hmsCore)
                                } catch (e: NullPointerException) {
                                    InternalControl("Error parse element ${e.message}")
                                }
                            } ?: InternalControl("invalidate")

                        HMSControlMessage(
                            db.text,
                            hmsControl,
                            db.reminds?.decode(Message.Reminds.ADAPTER)?.uids ?: emptyList(),
                            db.extension?.let { hmsCore.serializer.deserializeMessageExtension(it) },
                            db.sid,
                            db.timestamp,
                            db.update_timestamp.pb,
                            HMSMessageStatus.fromValue(db.status),
                            db.is_deleted,
                            db.is_revoked,
                            HMSMessageIndex(db.client_key, db.sid, db.local_sequence, db.help_sequence, db.sequence),
                            hmsCore.uid == db.sender
                        )
                    } else {
                        val dbSenderInfo =
                            senderInfo ?: hmsCore.userManager.getUsersMemberInfoCache(
                                db.sid,
                                listOf(db.sender)
                            ).firstOrNull()

                        HMSPlainMessage(
                            db.text,
                            db.type!!.toInt(),
                            db.push_text,
                            messageElement?.let {
                                hmsCore.serializer.deserializeMessagePayload(
                                    db.type!!.toInt(),
                                    (it as MessageElement.Element.Payload).payload.toByteArray()
                                )
                            },
                            db.reminds?.decode(Message.Reminds.ADAPTER)?.uids ?: emptyList(),
                            db.extension?.let { hmsCore.serializer.deserializeMessageExtension(it) },
                            db.sid,
                            db.timestamp,
                            db.update_timestamp.pb,
                            db.sender,
                            HMSMessageStatus.fromValue(db.status),
                            db.is_deleted,
                            db.is_revoked,
                            HMSMessageIndex(db.client_key, db.sid, db.local_sequence, db.help_sequence, db.sequence),
                            hmsCore.uid == db.sender,
                            dbSenderInfo ?: HMSMemberInfo.fake(db.sender)
                        )
                    }
                }
            } catch (e: HMSIllegalServerResponseException) {
                val error = e.message ?: "error decode message ${db.client_key}"
                hmsCore.logger.w(TAG, e) { error }

                HMSControlMessage(
                    error,
                    InternalControl(error),
                    emptyList(),
                    null,
                    db.sid,
                    db.timestamp,
                    db.update_timestamp.pb,
                    HMSMessageStatus.fromValue(db.status),
                    db.is_deleted,
                    db.is_revoked,
                    HMSMessageIndex(db.client_key, db.sid, db.local_sequence, db.help_sequence, db.sequence),
                    hmsCore.uid == db.sender
                )
            }
        }

        private const val TAG = "HMSMessage"
    }

    override fun toString(): String {
        return "HMSMessage(index=${index.toSimpleString()}, text=$text)"
    }
}

data class HMSControlMessage internal constructor(
    override val text: String,

    /**
     * 控制消息的控制信息
     *
     * @see HMSControlElement
     */
    val control: HMSControlElement,

    override val reminds: List<String>,

    override val extension: Any?,

    override val sessionId: String,

    override val timestamp: Long,

    override val updateTimeStamp: Long,

    override val status: HMSMessageStatus,

    override val isDeleted: Boolean,

    override val isRevoked: Boolean,

    override val index: HMSMessageIndex,

    override val isMine: Boolean

) : HMSMessage() {
    override val isControlMessage: Boolean
        get() = true
}

data class HMSPlainMessage internal constructor(
    override val text: String,

    /**
     * 消息的类型，由上层指定，HMS透传，一个type对应一种 [payload]
     */
    val type: Int,

    /**
     * 离线push的文本，默认使用text，当业务需要特殊的离线push文本，可以填写该字
     */
    val pushText: String?,

    /**
     * 业务侧自有定义的消息负载，通过 [HMSSerializer.serializeMessagePayload] 反序列化
     */
    val payload: Any?,

    override val reminds: List<String>,

    override val extension: Any?,

    override val sessionId: String,

    override val timestamp: Long,

    override val updateTimeStamp: Long,

    /**
     * 消息的发送发
     */
    val sender: String,

    override val status: HMSMessageStatus,

    override val isDeleted: Boolean,

    override val isRevoked: Boolean,

    override val index: HMSMessageIndex,

    override val isMine: Boolean,

    /**
     * 消息发送者
     */
    val senderInfo: HMSMemberInfo

) : HMSMessage() {
    override val isControlMessage: Boolean
        get() = false
}
