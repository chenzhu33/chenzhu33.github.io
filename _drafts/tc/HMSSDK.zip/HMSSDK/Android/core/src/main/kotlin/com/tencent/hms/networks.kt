package com.tencent.hms

import com.tencent.hms.HMSPushToken.Companion.PROVIDER_GOOGLE
import com.tencent.hms.HMSPushToken.Companion.PROVIDER_HUAWEI
import com.tencent.hms.HMSPushToken.Companion.PROVIDER_OPPO
import com.tencent.hms.HMSPushToken.Companion.PROVIDER_VIVO
import com.tencent.hms.HMSPushToken.Companion.PROVIDER_XIAOMI
import kotlinx.coroutines.launch
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-03
 * Time:   19:46
 * Life with Passion, Code with Creativity.
 * ```
 */

enum class HMSRequestType {
    GetSessionInfo,
    CreateSession,
    GetSessionList,
    GetC2CSessionByToUid,
    GetNotifyMessage,
    GetRangeMessage,
    ReceiveMessageAck,
    ReportRead,
    SendMessage,

    QuitSession,
    AddUserToSession,
    DestroySession,
    UpdateUserInSession,
    UpdateSessionInfo,
    DeleteSession,
    GetSessionMemberList,
    DeleteSessionMember,
    UpdateSessionPermission,
    UpdateSessionBanned,
    TransferGroupOwner,
    RemoveFromBlackList,
    GetBlackList,
    AddToBlackList,
    GetSessionMemberInfoByUids,
    ChangeMsgAlertType,

    GetUserProfile,
    UpdateUserInfo,

    Heartbeat,
    DataReport
}

data class HMSPushToken(
    /**
     * @see PROVIDER_GOOGLE
     * @see PROVIDER_HUAWEI
     * @see PROVIDER_XIAOMI
     * @see PROVIDER_OPPO
     * @see PROVIDER_VIVO
     */
    val provider: String,
    val token: String
) {
    companion object {
        const val PROVIDER_GOOGLE = "google"
        const val PROVIDER_HUAWEI = "huawei"
        const val PROVIDER_XIAOMI = "xiaomi"
        const val PROVIDER_OPPO = "oppo"
        const val PROVIDER_VIVO = "vivo"
        // reserved
        private const val PROVIDER_APPLE = "apple"
    }
}

class HMSTransferException(
    code: Int,
    message: String
) : HMSException(code, message, null, true)

/**
 * HMS的网络传输层实现，主要提供能力：
 * 1. 发请求 [HMSNetworkTransfer.sendRequest]
 * 2. 收在线push [HMSNetworkTransfer.enablePush]
 * 3. 监听网络状态 [HMSNetworkTransfer.registerNetworkStatusListener]
 * 4. 离线push能力 [HMSNetworkTransfer.registerPushToken]
 *
 * HMS 默认提供了基于维纳斯（WNS）的网络传输层实现:
 * gradle依赖引入 `com.tencent.hms:ext-wns:$hms_version`
 */
abstract class HMSNetworkTransfer {
    private var hmsCore: HMSCore? = null

    internal fun attachHmsCore(hmsCore: HMSCore) {
        if (this.hmsCore != null) {
            throw IllegalStateException("you MUST create one instance of HMSNetworkTransfer for each HMSCore")
        }
        this.hmsCore = hmsCore
    }

    internal fun detachHmsCore() {
        this.hmsCore = null
        onDestroy()
    }

    /**
     * Send request to server, and receive result through callback.
     * This method does'n retry.
     *
     * @param type requestType described in [HMSRequestType]
     * @param data request data
     * @param timeoutMillis request timeout in milli seconds
     * @param callback callback result data (or error code), more info infer to [HMSDisposableCallback]
     */
    protected abstract fun sendRequest(
        type: HMSRequestType,
        data: ByteArray,
        timeoutMillis: Long,
        callback: HMSDisposableCallback<HMSResult<ByteArray>>
    )

    /**
     * Send request with retry enabled,
     * the default implementation is to call [sendRequest] repeatably until retry count.
     *
     * @see sendRequest
     */
    protected open fun sendRequest(
        type: HMSRequestType,
        data: ByteArray,
        timeoutMillis: Long,
        retryCount: Int,
        callback: HMSDisposableCallback<HMSResult<ByteArray>>
    ) {
        hmsCore!!.hmsScope.launch {
            for (i in 0 until retryCount) {
                try {
                    val responseData = sendRequest(type, data, timeoutMillis)
                    callback.callback(HMSResult.success(responseData))
                    return@launch
                } catch (exception: HMSException) {
                    if (i == retryCount - 1) {
                        // last request failed
                        callback.callback(HMSResult.Fail(exception))
                    }
                }
            }
        }
    }

    /**
     * coroutine version of [sendRequest]
     */
    internal suspend fun sendRequest(
        type: HMSRequestType,
        data: ByteArray,
        timeoutMillis: Long
    ): ByteArray {
        return suspendCoroutine { continuation: Continuation<ByteArray> ->
            sendRequest(type, data, timeoutMillis, HMSDisposableCallback {
                if (it is HMSResult.Success) {
                    continuation.resume(it.data)
                } else {
                    continuation.resumeWithException((it as HMSResult.Fail).error)
                }
            })
        }
    }

    /**
     * coroutine version of [sendRequest]
     */
    internal suspend fun sendRequest(
        type: HMSRequestType,
        data: ByteArray,
        timeoutMillis: Long,
        retryCount: Int
    ): ByteArray {
        return suspendCoroutine { continuation: Continuation<ByteArray> ->
            sendRequest(type, data, timeoutMillis, retryCount, HMSDisposableCallback {
                if (it is HMSResult.Success) {
                    continuation.resume(it.data)
                } else {
                    continuation.resumeWithException((it as HMSResult.Fail).error)
                }
            })
        }
    }

    /**
     * register an offline push token
     */
    abstract fun registerPushToken(token: HMSPushToken, callback: HMSDisposableCallback<HMSResult<Unit>>)

    /**
     * 向 HMS 传递push数据
     */
    fun notifyPushData(data: ByteArray) {
        hmsCore?.onPushData(data)
    }

    fun notifyNetworkChange(isConnected: Boolean) {
        hmsCore?.onNetworkStatusChange(isConnected)
    }

    /**
     * 当对应的 HMSCore [HMSCore.destroy] 时，调用该方法，内部可以做资源释放。
     */
    protected open fun onDestroy() {

    }
}