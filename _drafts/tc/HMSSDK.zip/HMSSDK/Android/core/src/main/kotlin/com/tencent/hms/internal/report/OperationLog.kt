package com.tencent.hms.internal.report

import com.squareup.sqldelight.db.SqlPreparedStatement
import com.tencent.hms.internal.HMSLogger
import java.io.Writer
import java.text.SimpleDateFormat
import java.util.*
import java.util.regex.Pattern
import kotlin.collections.ArrayList

/**
 * Created by juliandai on 2019/3/12 10:21 AM.
 * talk and show the code
 *
 */
internal class OperationLog(var logger: HMSLogger) {

    private val mOperations = arrayOfNulls<Operation>(MAX_RECENT_OPERATIONS)
    private var mIndex: Int = 0
    private var mGeneration: Int = 0

    companion object {
        private val MAX_RECENT_OPERATIONS = 50
        private val COOKIE_GENERATION_SHIFT = 8
        private val COOKIE_INDEX_MASK = 0xff
        private const val SHOULD_LOG_SLOW_QUERY = 100
        private const val TAG = "OperationLog"
    }

    fun beginOperation(kind: String, sql: String?, bindArgs: (SqlPreparedStatement.() -> Unit)?): Operation {
        synchronized(mOperations) {
            val index = (mIndex + 1) % MAX_RECENT_OPERATIONS
            var operation: Operation? = mOperations[index]
            if (operation == null) {
                operation = Operation()
                mOperations[index] = operation
            } else {
                operation.mFinished = false
                operation.mException = null
            }
            operation.mStartTime = System.currentTimeMillis()
            operation.mKind = kind
            operation.mSql = sql
            operation.mTid = Thread.currentThread().id.toInt()
            operation.mBindArgs = bindArgs
            operation.mCookie = newOperationCookieLocked(index)
            mIndex = index
            return operation
        }
    }


    fun failOperation(cookie: Int, ex: Exception) {
        synchronized(mOperations) {
            getOperationLocked(cookie)?.mException = ex
        }
    }

    /**
     * slow query记录到logger
     */
    fun endOperation(cookie: Int) {
        synchronized(mOperations) {
            val operation = getOperationLocked(cookie)
            if (endOperationDeferLogLocked(operation)) {
                logOperationLocked(operation!!, "exception or slow query")
            }
        }
    }

    /**
     * 返回值:1,是否exception,2,是否slow query
     */
    fun endOperationDeferLog(cookie: Int): Boolean {
        val result: Boolean

        synchronized(mOperations) {
            val operation = getOperationLocked(cookie) ?: return false
            result = endOperationDeferLogLocked(operation)
        }

        return result
    }

    /**
     * 记录到logger
     */
    fun logOperation(cookie: Int, detail: String) {
        synchronized(mOperations) {
            val operation = getOperationLocked(cookie)
            if (operation != null)
                logOperationLocked(operation, detail)
        }
    }

    private fun endOperationDeferLogLocked(operation: Operation?): Boolean {
        if (operation != null) {
            operation.mEndTime = System.currentTimeMillis()
            operation.mFinished = true
            if (operation.mException != null && operation.mException?.message != null) {
                return true
            }

            val elapsedTimeMillis = operation.mEndTime - operation.mStartTime
            return elapsedTimeMillis > SHOULD_LOG_SLOW_QUERY
        }
        return false
    }

    fun slowQueryOrException(operation: Operation?): Boolean {
        return endOperationDeferLogLocked(operation)
    }

    private fun logOperationLocked(operation: Operation, detail: String?) {
        val msg = StringBuilder()
        operation.describe(msg)
        if (detail != null) {
            msg.append(", ").append(detail)
        }
        logger.i(TAG, null) { msg.toString() }
    }

    private fun newOperationCookieLocked(index: Int): Int {
        val generation = mGeneration++
        return generation shl COOKIE_GENERATION_SHIFT or index
    }

    private fun getOperationLocked(cookie: Int): Operation? {
        val index = cookie and COOKIE_INDEX_MASK
        val operation = mOperations[index]
        return if (operation?.mCookie == cookie) operation else null
    }

    fun describeCurrentOperation(): String? {
        synchronized(mOperations) {
            val operation = mOperations[mIndex]
            if (operation != null && !operation.mFinished) {
                val msg = StringBuilder()
                operation.describe(msg)
                return msg.toString()
            }
            return null
        }
    }

    /**
     * dump所有log
     */
    fun dump(writer: Writer, verbose: Boolean, header: String = "") {
        synchronized(mOperations) {
            writer.write(" ${header} executed operations:")
            var index = mIndex
            var operation: Operation? = mOperations[index]
            if (operation != null) {
                var n = 0
                do {
                    val msg = StringBuilder()
                    msg.append("    ").append(n).append(": [")
                    msg.append(operation!!.formattedStartTime)
                    msg.append("] ")
                    operation.describe(msg)
                    writer.write(msg.toString())

                    if (index > 0) {
                        index -= 1
                    } else {
                        index = MAX_RECENT_OPERATIONS - 1
                    }
                    n += 1
                    operation = mOperations[index]
                } while (operation != null && n < MAX_RECENT_OPERATIONS)
            } else {
                writer.write("    <none>")
            }
        }
    }

    fun asList(): List<Operation> {
        val list = mutableListOf<Operation>()
        synchronized(mOperations) {
            var index = mIndex
            do {
                val operation = mOperations[index]
                operation?.let {
                    list.add(it)
                    mOperations[index] = null
                }
                index--
                if (index < 0) {
                    index = MAX_RECENT_OPERATIONS - 1
                }
            } while (operation != null && index < MAX_RECENT_OPERATIONS)
        }
        return list.reversed()
    }
}

internal class Operation {

    companion object {
        private val sDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.CHINESE)
    }

    var mStartTime: Long = 0
    var mEndTime: Long = 0
    var mKind: String? = null
    var mSql: String? = null
    var mBindArgs: (SqlPreparedStatement.() -> Unit)? = null
    var mFinished: Boolean = false
    var mException: Exception? = null
    var mCookie: Int = 0
    var mType: Int = 0
    var mTid: Int = 0

    private val TRIM_SQL_PATTERN = Pattern.compile("[\\s]*\\n+[\\s]*")

    private val status: String
        get() {
            if (!mFinished) {
                return "running"
            }
            return if (mException != null) "failed" else "succeeded"
        }

    val formattedStartTime: String
        get() = sDateFormat.format(Date(mStartTime))

    fun describe(msg: StringBuilder) {
        msg.append(mKind)
        if (mFinished) {
            msg.append(" took ").append(mEndTime - mStartTime).append("ms")
        } else {
            msg.append(" started ").append(System.currentTimeMillis() - mStartTime)
                .append("ms ago")
        }
        msg.append(" - ").append(status)
        if (mSql != null) {
            msg.append(", sql=\"").append(trimSqlForDisplay(mSql!!)).append("\"")
        }
        if (mTid > 0) {
            msg.append(", tid=").append(mTid)
        }
        val bindArgs = dumpBindArgs(mBindArgs)
        if (bindArgs != null) {
            msg.append(", bindArgs=[")
            val count = bindArgs.size
            for (i in 0 until count) {
                val arg = bindArgs[i]
                if (i != 0) {
                    msg.append(", ")
                }
                when (arg) {
                    null -> msg.append("null")
                    is ByteArray -> msg.append("<byte[${arg.size}]>")
                    is String -> msg.append("\"").append(arg).append("\"")
                    else -> msg.append(arg)
                }
            }
            msg.append("]")
        }
        if (mException != null && mException!!.message != null) {
            msg.append(", exception=\"").append(mException!!.message).append("\"")
        }
    }

    private fun trimSqlForDisplay(sql: String): String {
        return TRIM_SQL_PATTERN.matcher(sql).replaceAll(" ")
    }

    private fun dumpBindArgs(binders: (SqlPreparedStatement.() -> Unit)?): List<Any?>? =
        binders?.let {
            ArrayList<Any?>().also { list ->
                object : SqlPreparedStatement {
                    override fun bindBytes(index: Int, value: ByteArray?) {
                        ensureSize(index)
                        list[index] = value
                    }

                    override fun bindDouble(index: Int, value: Double?) {
                        ensureSize(index)
                        list[index] = value
                    }

                    override fun bindLong(index: Int, value: Long?) {
                        ensureSize(index)
                        list[index] = value
                    }

                    override fun bindString(index: Int, value: String?) {
                        ensureSize(index)
                        list[index] = value
                    }

                    private fun ensureSize(index: Int) {
                        list.ensureCapacity(index + 1)
                        while (list.size <= index) {
                            list.add(null)
                        }
                    }
                }.binders()
            }
        }
}