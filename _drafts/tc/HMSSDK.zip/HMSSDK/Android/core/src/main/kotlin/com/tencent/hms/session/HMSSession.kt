package com.tencent.hms.session

import com.tencent.hms.HMSCore
import com.tencent.hms.HMSIllegalArgumentException
import com.tencent.hms.HMSSerializer
import com.tencent.hms.internal.decode
import com.tencent.hms.internal.pb
import com.tencent.hms.internal.protocol.MsgAlertType
import com.tencent.hms.internal.protocol.Session
import com.tencent.hms.internal.protocol.SessionType
import com.tencent.hms.internal.protocol.UserInSessionSequence
import com.tencent.hms.internal.repository.model.SessionDB
import com.tencent.hms.message.HMSMessage
import com.tencent.hms.session.HMSSession.Type
import kotlin.math.max
import kotlin.math.sign

/**
 * Created by juliandai on 2019/1/10 4:56 PM.
 * talk and show the code
 */
data class HMSSession internal constructor(
    /**
     * session id
     */
    val sid: String,
    val avatarUrl: String,
    val name: String,
    internal val maxSequence: Long,
    internal val visibleSequence: Long,
    internal val maxLocalReadSequence: Long,
    /**
     * 已读的最大seq
     */
    internal val maxReadSequence: Long,
    /**
     * 会话是否被解散
     */
    val isDestroy: Boolean,
    /**
     * is locally deleted
     * @see HMSCore.deleteSession
     */
    internal val isDeleted: Boolean,
    val type: Type,
    /**
     * 会话创建时间，unix时间戳，单位毫秒
     */
    val createTime: Long,
    /**
     * 当[type] 是 [Type.C2C] 的时候，表示这是一个单聊会话，此时 [toUid] 表示对方的uid。
     * 其他type下，该字段为`null`
     */
    val toUid: String?,
    /**
     * 当[type] 是 [Type.GROUP] 或者 [Type.CHAT_ROOM] 的时候，此时 [ownerUid] 表示群组owner的uid。
     * 其他type下，该字段为`null`
     */
    val ownerUid: String?,
    val friendType: Int,
    /**
     * 会话消息提醒类型
     */
    val messageAlertType: HMSMessageAlertType,
    /**
     * 会话中成员的个数
     */
    val memberNumber: Int,
    val unreadCount: Long = 0,
    val lastMessage: HMSMessage?,
    /**
     * 会话里最后一条消息的unix时间戳，单位毫秒
     */
    val businessBuffer: Any?,
    val extension: Any?,

    internal val serverUnreadRemindSequences: List<Long>?,

    internal val localUnreadRemindSequences: List<Long>?

) {
    /**
     * 未读@的seqs
     */
    val unreadRemindSequences: List<Long>?
        get() {
            val maxSeq = max(visibleSequence, max(maxReadSequence, maxLocalReadSequence))
            if (serverUnreadRemindSequences?.isEmpty() != false) return localUnreadRemindSequences?.filter { it > maxSeq }
            if (localUnreadRemindSequences?.isEmpty() != false) return serverUnreadRemindSequences.filter { it > maxSeq }
            return listOf(
                serverUnreadRemindSequences,
                localUnreadRemindSequences.filter { !serverUnreadRemindSequences.contains(it) })
                .flatMap {
                    it.asIterable()
                }.filter { it > maxSeq }.sorted()
        }

    enum class Type {
        /** 单聊 */
        C2C,
        /** 群聊 */
        GROUP,
        /** 聊天室 */
        CHAT_ROOM;

        internal fun toProtocol() =
            when (this) {
                C2C -> SessionType.C2C
                GROUP -> SessionType.GROUP
                CHAT_ROOM -> SessionType.CHAT_ROOM
            }

        companion object {
            internal fun fromProtocol(type: Int) =
                when (type) {
                    SessionType.C2C.value -> C2C
                    SessionType.GROUP.value -> GROUP
                    SessionType.CHAT_ROOM.value -> CHAT_ROOM
                    else -> {
                        throw HMSIllegalArgumentException("Illegal session type $type")
                    }
                }
        }
    }

    companion object {

        internal fun fromDB(
            sessionDB: SessionDB,
            unreadCount: Long,
            lastMessage: HMSMessage?,
            serializer: HMSSerializer
        ): HMSSession {

            return HMSSession(
                sessionDB.sid,
                sessionDB.avatar_url.pb,
                sessionDB.name.pb,
                sessionDB.max_sequence.pb,
                sessionDB.visible_sequence.pb,
                sessionDB.local_read_sequence,
                sessionDB.read_max_sequence,
                sessionDB.is_destroy.pb,
                sessionDB.is_deleted,
                Type.fromProtocol(sessionDB.type.toInt()),
                sessionDB.create_timestamp,
                sessionDB.to_uid,
                sessionDB.owner_uid,
                sessionDB.friend_type?.toInt().pb,
                HMSMessageAlertType.fromProtocol(MsgAlertType.fromValue(sessionDB.message_alert_type.toInt())),
                sessionDB.member_number.toInt(),
                unreadCount,
                lastMessage,
                sessionDB.business_buffer?.let { serializer.deserializeSessionBusinessBuffer(it) },
                sessionDB.extension_busi_buff?.let { serializer.deserializeSessionExtension(it) },
                sessionDB.server_reminds?.decode(UserInSessionSequence.Reminds.ADAPTER)?.unreadRemindSequence,
                sessionDB.local_reminds?.decode(UserInSessionSequence.Reminds.ADAPTER)?.unreadRemindSequence
            )
        }

        internal fun fromNet(session: Session, serializer: HMSSerializer): HMSSession {
            val basicInfo = session.sessionBasicInfo!!
            val sequenceInfo = session.userInSessionSequence
            val userRelatedInfo = session.userRelatedSessionInfo
            return HMSSession(
                basicInfo.sid!!,
                basicInfo.avatarUrl.pb,
                basicInfo.name.pb,
                sequenceInfo?.maxSequence.pb,
                sequenceInfo?.visibleSequence.pb,
                0,
                sequenceInfo?.readMaxSequence.pb,
                basicInfo.isDestroy.pb,
                false,
                Type.fromProtocol(basicInfo.type?.value.pb),
                basicInfo.createTimestamp.pb,
                basicInfo.toUid.pb,
                basicInfo.ownerUid.pb,
                userRelatedInfo?.friendType.pb,
                HMSMessageAlertType.fromProtocol(userRelatedInfo?.msgAlertType),
                basicInfo.memberNumber.pb,
                0,
                null,
                basicInfo.businessBuffer?.let { serializer.deserializeSessionBusinessBuffer(it.toByteArray()) },
                null,
                sequenceInfo?.reminds?.unreadRemindSequence,
                null
            )
        }

        @JvmStatic
        @get:JvmName("getSessionByTimestampComparator")
        val SESSION_BY_TIMESTAMP_COMPARATOR = Comparator<HMSSession> { self, other ->
            val seqTime = self.lastMessage?.timestamp ?: self.createTime
            val otherSeqTime = other.lastMessage?.timestamp ?: other.createTime
            (otherSeqTime - seqTime).sign
        }
    }
}


data class HMSAddToSessionResultItem(val uid: String, val code: Int)

data class HMSDeleteSessionMemberResultItem(
    val uid: String,
    val code: Int
)