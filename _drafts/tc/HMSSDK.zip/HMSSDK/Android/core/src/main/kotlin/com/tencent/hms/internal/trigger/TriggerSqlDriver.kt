package com.tencent.hms.internal.trigger

import com.squareup.sqldelight.Transacter
import com.squareup.sqldelight.db.SqlCursor
import com.squareup.sqldelight.db.SqlDriver
import com.squareup.sqldelight.db.SqlPreparedStatement
import com.tencent.hms.internal.HMSExecutors

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-09
 * Time:   13:44
 * Life with Passion, Code with Creativity.
 * ```
 */

/**
 * A wrapped [SqlDriver] that processes triggers.
 */
internal class TriggerSqlDriver(
    private val executors: HMSExecutors,
    private val triggerManager: TriggerManager,
    private val concreteDriver: SqlDriver
) : SqlDriver {

    override fun newTransaction(): Transacter.Transaction =
        concreteDriver.newTransaction().also {
            if (executors.isDbWriteThread()) {
                // process db trigger after each transaction completes
                it.afterCommit { triggerManager.processTriggers() }
            }
        }

    override fun execute(identifier: Int?, sql: String, parameters: Int, binders: (SqlPreparedStatement.() -> Unit)?) {
        executors.assertDbWriteThread()

        concreteDriver.execute(identifier, sql, parameters, binders)

        if (currentTransaction() == null) {
            // db write operation not in transaction, process trigger afterwords
            triggerManager.processTriggers()
        }
    }

    override fun executeQuery(
        identifier: Int?,
        sql: String,
        parameters: Int,
        binders: (SqlPreparedStatement.() -> Unit)?
    ): SqlCursor {
        return concreteDriver.executeQuery(identifier, sql, parameters, binders)
    }

    override fun close() {
        concreteDriver.close()
    }

    override fun currentTransaction(): Transacter.Transaction? {
        return concreteDriver.currentTransaction()
    }


}