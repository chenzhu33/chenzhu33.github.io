package com.tencent.hms.internal.message

import com.tencent.hms.*
import com.tencent.hms.internal.*
import com.tencent.hms.internal.protocol.*
import com.tencent.hms.internal.repository.insertOrUpdateLocalReminds
import com.tencent.hms.internal.repository.insertOrUpdateMessages
import com.tencent.hms.internal.repository.insertOrUpdateUserInSessions
import com.tencent.hms.internal.repository.insertOrUpdateUsers
import com.tencent.hms.internal.repository.model.MessageDB
import com.tencent.hms.internal.repository.model.New_message_table_write_log
import com.tencent.hms.internal.trigger.TriggerManager
import com.tencent.hms.message.HMSMessage
import com.tencent.hms.message.HMSMessageIndex
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicReference

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-10
 * Time:   10:44
 * Life with Passion, Code with Creativity.
 * ```
 */

/**
 * receiver manager need to make sure for each session
 * > get new message calls are queues sequentially
 */
internal class MessageReceiveManager(private val hmsCore: HMSCore) {

    private val sessionStatus = mutableMapOf<String, Long>()
    private val sessionStatusMutex = Mutex()

    suspend fun onNotifyData(notifyData: NotifyData) {
        val sid = notifyData.sessionID
            ?: throw HMSIllegalServerResponseException(COMMON_ERROR_CODE, "onNotifyData null sid")

        assertServerData(message = "NotifyData") {
            updateSessionNumbers(sid, notifyData.readMaxSequence.pb, notifyData.visibleSequence.pb)
            internalInsertMessage(notifyData.messages)
        }
        sendAck(sid)
    }

    suspend fun onNotify(notify: Notify) {
        assertServerData(message = "Notify") {
            val sid = notify.sessionID!!

            updateSessionNumbers(sid, notify.readMaxSequence.pb, notify.visibleSequence.pb)
            receiveLatestMessageForSession(sid, notify.maxSequence.pb)
        }
    }

    private suspend fun receiveLatestMessageForSession(
        sid: String,
        maxSequence: Long
    ) {
        sessionStatusMutex.withLock {
            val lastRequestMaxSequence = sessionStatus[sid]
            if (lastRequestMaxSequence != null) {
                // client is already requesting latest message
                // we don't want a concurrent request, aborting
                if (lastRequestMaxSequence < maxSequence) {
                    sessionStatus[sid] = maxSequence
                }
                hmsCore.logger.i(TAG) {
                    "onNotify is already requesting:$lastRequestMaxSequence suspend load for $maxSequence"
                }
                return
            }
            sessionStatus[sid] = maxSequence
        }

        try {
            val clientMaxSequence = hmsCore.database.sessionDBQueries.queryMaxSequenceBySids(listOf(sid))
                .executeAsOneOrNull()?.max_sequence ?: 0

            if (clientMaxSequence < maxSequence) {
                assertServerData(message = "GetNotifyMessage") {
                    val reply = hmsCore.sendRequestWithRetry(
                        HMSRequestType.GetNotifyMessage,
                        GetNotifyMessageReq(
                            hmsCore.makeHeader(),
                            sid,
                            clientMaxSequence
                        ),
                        GetNotifyMessageRsp.ADAPTER
                    )

                    internalInsertMessage(reply.messages)
                }

                sendAck(sid)
            }
        } catch (e: HMSException) {
            hmsCore.logger.e(TAG, e) { "receiver notify message failed for sid:$sid maxSequence:$maxSequence" }
        } finally {
            val needReceive = sessionStatusMutex.withLock {
                val lastRequestMaxSequence = sessionStatus[sid]
                if (lastRequestMaxSequence != null && lastRequestMaxSequence > maxSequence) {
                    // a newer request is aborted during our request, start them again
                    sessionStatus.remove(sid)
                    lastRequestMaxSequence
                } else {
                    sessionStatus.remove(sid)
                    null
                }
            }

            if (needReceive != null) {
                hmsCore.logger.i(TAG) { "onNotify resume suspend load for $maxSequence" }
                receiveLatestMessageForSession(sid, needReceive)
            }
        }
    }

    internal class MessageHolesFoundException(
        val completeHolesAsync: Deferred<Unit>,
        val holes: List<LongRange>
    ) : Exception()

    /**
     * @throws HMSException
     * @throws MessageHolesFoundException if there are holes, and trying to complete them. caller should fetch data source from db trigger.
     */
    suspend fun getLatestMessage(
        sid: String,
        from: HMSMessageIndex?,
        length: Int,
        completeHoles: Boolean
    ): Pair<List<MessageDB>, List<LongRange>> {
        val messages = if (from != null) {
            hmsCore.database.messageDBQueries.queryLatestMessagesFromIndexDesc(
                sid, from.localSequence, from.localSequence, from.helpSequence,
                length.toLong()
            ).executeAsList()
        } else {
            hmsCore.database.messageDBQueries.queryLastMessagesDesc(
                sid, length.toLong()
            ).executeAsList()
        }

        hmsCore.logger.v(TAG) {
            """
            |getLatestMessage from:
            |${from?.toSimpleString() ?: "latest"}
            |results:
            |${messages.map { it.local_sequence.toString() + " " + it.help_sequence + " " + it.sequence + " " + it.text }}
            |""".trimMargin()
        }

        return if (completeHoles) {
            completeHolesIfAny(
                sid,
                false,
                messages.map { HoleMeta(it.sequence, it.has_hole) },
                length
            )
            messages to emptyList()
        } else {
            messages to findHoles(
                sid,
                false,
                messages.map { HoleMeta(it.sequence, it.has_hole) },
                length
            )
        }
    }

    suspend fun getHistoryMessage(
        sid: String,
        from: HMSMessageIndex,
        length: Int,
        completeHoles: Boolean
    ): Pair<List<MessageDB>, List<LongRange>> {
        val messages = hmsCore.database.messageDBQueries.queryHistoryMessagesFromIndexDesc(
            sid, from.localSequence, from.localSequence, from.helpSequence,
            length.toLong()
        ).executeAsList()

        hmsCore.logger.v(TAG) {
            """
            |getHistoryMessage from:
            |${from.toSimpleString()}
            |results:
            |${messages.map { it.local_sequence.toString() + " " + it.help_sequence + " " + it.sequence + " " + it.text }}
            |""".trimMargin()
        }

        return if (completeHoles) {
            completeHolesIfAny(
                sid,
                true,
                messages.map { HoleMeta(it.sequence, it.has_hole) },
                length
            )
            messages to emptyList()
        } else {
            messages to findHoles(
                sid,
                true,
                messages.map { HoleMeta(it.sequence, it.has_hole) },
                length
            )
        }
    }

    suspend fun completeHolesAfterIndex(
        sid: String,
        after: HMSMessageIndex,
        length: Int
    ) {
        val messages = hmsCore.database.messageDBQueries.queryMessagesIndexAfterDesc(
            sid, after.localSequence, after.localSequence, after.helpSequence,
            length.toLong()
        ).executeAsList()

        hmsCore.logger.v(TAG) {
            """
            |completeHolesAfterIndex from:
            |${after.toSimpleString()}
            |results:
            |${messages.map { it.local_sequence.toString() + " " + it.help_sequence + " " + it.sequence + " " }}
            |""".trimMargin()
        }

        completeHolesIfAny(
            sid,
            false,
            messages.map { HoleMeta(it.sequence, it.has_hole) },
            length
        )
    }

    private data class HoleMeta(
        val sequence: Long?,
        val hasHole: Boolean
    )

    /**
     * @param isHistory getHistoryMessage or getLatestMessage
     * @return has hole
     */
    private suspend fun completeHolesIfAny(
        sid: String,
        isHistory: Boolean,
        messages: List<HoleMeta>,
        expectedLength: Int
    ) {
        val holes = findHoles(sid, isHistory, messages, expectedLength)
        if (holes.isNotEmpty()) {
            hmsCore.logger.v(TAG) { "completeHoles:\n$holes" }

            // async complete hole operation
            val deferred = hmsCore.hmsScope.async<Unit>(hmsCore.Worker + SupervisorJob(), CoroutineStart.LAZY) {
                getRangeMessage(sid, holes)
            }
            throw MessageHolesFoundException(deferred, holes)
        }
    }

    /**
     * @param messages a message list used [MessageDB.sequence] & [MessageDB.has_hole]
     */
    private fun findHoles(
        sid: String,
        isHistory: Boolean,
        messages: List<HoleMeta>,
        expectedLength: Int
    ): List<LongRange> {
        val holes = mutableListOf<LongRange>()

        // filter out local message, and order by sequence
        val serverMessages = messages
            .filter { it.sequence != null }
            .sortedBy { it.sequence!! }

        // holes before the start sequence can't be completed!!
        val sessionVisibleSequence = hmsCore.database.sessionDBQueries
            .querySessionVisibleSequence(sid)
            .executeAsOneOrNull() ?: 1

        serverMessages.forEachIndexed { index, item ->
            if (item.hasHole && item.sequence!! >= sessionVisibleSequence) {
                if (index + 1 < serverMessages.size) {
                    val holeEnd = serverMessages[index + 1]
                    holes.add((item.sequence + 1) until holeEnd.sequence!!)
                } else {
                    // end of the list has a hole
                    // query db to complete the hole
                    val endSequence = hmsCore.database
                        .messageDBQueries.queryOneMessageAfterSequence(sid, item.sequence)
                        .executeAsOneOrNull()?.sequence

                    if (endSequence != null) {
                        holes.add((item.sequence + 1) until endSequence)
                    }
                }
            }
        }

        val holeMessageCount = holes.fold(0L) { acc, range ->
            acc + range.endInclusive - range.start + 1
        }
        if (isHistory && messages.size + holeMessageCount < expectedLength) {
            // when holes are completed, we still don't get enough data
            // check holes in the front !!!
            val frontHoleSequence = if (serverMessages.isNotEmpty()) {
                serverMessages.first().sequence!!
            } else {
                // we can be sure there is no server message in the front of db now!
                // find the very first of the whole db

                hmsCore.database.messageDBQueries.queryOneMessageAfterSequence(sid, 0)
                    .executeAsOneOrNull()?.sequence.also {
                    if (it == null) {
                        // Apparently there is no any message in db of this session.
                        // There nothing we can do!
                        // Maybe we should refresh session now?
                    }
                }
            }

            // sequence starts from 1
            if (frontHoleSequence != null && frontHoleSequence > sessionVisibleSequence) {
                val beforeHole = hmsCore.database
                    .messageDBQueries.queryOneMessageBeforeSequence(sid, frontHoleSequence)
                    .executeAsOneOrNull()

                // complete front hole by a decent sequence
                val begin = (beforeHole?.sequence ?: 0).coerceAtLeast(sessionVisibleSequence)
                holes.add(0, begin until frontHoleSequence)
            }
        }

        return if (isHistory) {
            // reverse range
            holes.map {
                it.endInclusive..it.start
            }.reversed()
        } else {
            holes
        }
    }

    private suspend fun updateSessionNumbers(sid: String, readMaxSequence: Long, visibleMaxSequence: Long) {
        // NOTE: we don't update maxSequence in here

        withContext(hmsCore.DBWrite) {
            hmsCore.database.sessionDBQueries.transaction {
                hmsCore.database.sessionDBQueries.updateReadMaxSequence(sid, readMaxSequence)
                hmsCore.database.sessionDBQueries.updateVisibleSequence(sid, visibleMaxSequence)
            }
        }
    }

    private suspend fun sendAck(sid: String) {
        val clientMaxSequence = hmsCore.database.sessionDBQueries.queryMaxSequenceBySids(listOf(sid))
            .executeAsOneOrNull()?.max_sequence ?: 0

        hmsCore.sendRequestWithRetry(
            HMSRequestType.ReceiveMessageAck,
            ReceiveMessageAckReq(
                hmsCore.makeHeader(),
                sid,
                clientMaxSequence
            ),
            ReceiveMessageAckRsp.ADAPTER
        )
    }


    /**
     * get messages from server, and write them into db
     *
     * note this method is not managed to queues sequentially
     *
     * @return server returned message count
     * @throws HMSException
     */
    suspend fun getRangeMessage(sid: String, ranges: List<LongRange>): Int {
        val reply = hmsCore.sendRequestWithRetry(
            HMSRequestType.GetRangeMessage,
            GetRangeMessageReq(
                hmsCore.makeHeader(),
                sid,
                ranges.map { GetRangeMessageReq.Range(it.start, it.endInclusive) }
            ),
            GetRangeMessageRsp.ADAPTER)

        internalInsertMessage(reply.messages)

        return reply.messages.size
    }

    suspend fun internalInsertMessage(messages: List<Message>) {
        withContext(hmsCore.DBWrite) {
            insertMessages(messages)
        }
    }

    fun insertMessages(messages: List<Message>) {
        if(messages.isEmpty()) {
            return
        }
        hmsCore.executors.executeOnDbWriteOrFail {
            assertServerData(message = "insert message") {
                val unreadRemindMe = hmsCore.database.sessionDBQueries.insertOrUpdateLocalReminds(messages, hmsCore.uid)
                if (unreadRemindMe.isNotEmpty()) {
                    hmsCore.logger.v(TAG) { "unread @me from message: $unreadRemindMe"}
                }
                hmsCore.insertOrUpdateMessages(messages)
                hmsCore.database.userDBQueries.insertOrUpdateUsers(messages.filter { it.sender != null }.map { it.sender!! })
                hmsCore.database.userInSessionDBQueries.insertOrUpdateUserInSessions(
                    messages.filter { it.senderInSession != null }.map {
                        it.senderInSession!!
                    }
                )
            }
        }
    }

    private var newMessageTriggerListener = AtomicReference<HMSDisposableCallback<List<New_message_table_write_log>>>()

    /**
     * Set a listener which listens new message arrival.
     */
    fun setNewMessageListener(newMessageListener: HMSNewMessageListener?) {
        val triggerListener = if (newMessageListener != null) {
            HMSDisposableCallback<List<New_message_table_write_log>> { newMessageLog ->
                handleNewMessageTrigger(newMessageLog, newMessageListener)
            }
        } else {
            null
        }

        val previous = newMessageTriggerListener.getAndSet(triggerListener)
        previous?.dispose()

        triggerListener?.let {
            hmsCore.triggerManager.registerTriggerCallback(TriggerManager.TriggerType.NEW_MESSAGE, it)
        }
    }

    private fun handleNewMessageTrigger(
        newMessageLog: List<New_message_table_write_log>,
        newMessageListener: HMSNewMessageListener
    ) {
        hmsCore.logger.v(TAG) { "onNewMessage:\n$newMessageLog" }

        hmsCore.hmsScope.launch {
            convertNewMessages(newMessageLog.filter { it.sender != hmsCore.uid })
                .let { list ->
                    hmsCore.logger.v(TAG) { "onNewMessage converts:\n$list" }
                    if (list.isNotEmpty()) {
                        withContext(hmsCore.Main) {
                            try {
                                newMessageListener.onNewMessage(list)
                            } catch (e: Throwable) {
                                throw IllegalStateException(
                                    "exception during callback newMessageListener:$newMessageListener",
                                    e
                                )
                            }
                        }
                    }
                }
        }
    }

    private suspend fun convertNewMessages(list: List<New_message_table_write_log>) = withContext(hmsCore.Worker) {
        list.groupBy { it.sid }
            .map { (sid, news) ->
                sid to news.sortedBy { it.sequence }
            }.map { (sid, news) ->
                val messages = getRanges(news).flatMap {
                    hmsCore.database.messageDBQueries
                        .queryMessagesBySequenceRangeAsc(it.start, it.endInclusive, sid)
                        .executeAsList()
                }.map {
                    HMSMessage.fromDB(it, hmsCore)
                }.filter { defaultMessageFilter(it) }

                HMSNewMessageListener.NewMessages(
                    sid,
                    messages
                )
            }.filter {
                // just in case
                it.messages.isNotEmpty()
            }
    }


    companion object {
        const val TAG = "MessageReceiveManager"

        /**
         * visible for test only
         */
        internal fun getRanges(news: List<New_message_table_write_log>): List<LongRange> {
            if (news.size == 1) {
                return listOf(news.first().let { it.sequence..it.sequence })
            }

            val ranges = mutableListOf<LongRange>()

            var startIndex: Int? = null
            var lastSeq = 0L
            news.forEachIndexed { index, log ->
                if (startIndex == null && log.sequence > lastSeq) {
                    startIndex = index
                } else if (startIndex != null && log.sequence != news[index - 1].sequence + 1) {
                    // not continuous
                    lastSeq = log.sequence
                    ranges.add(news[startIndex!!].sequence..lastSeq)
                    startIndex = null
                }
            }
            if (startIndex != null) {
                ranges.add(news[startIndex!!].sequence..news.last().sequence)
            }

            return ranges
        }
    }

}