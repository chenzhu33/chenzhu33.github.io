package com.tencent.hms.internal.trigger

import com.squareup.sqldelight.db.SqlDriver
import com.tencent.hms.internal.repository.model.New_message_table_write_log

/**
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-18
 * Time:   15:56
 * Life with Passion, Code with Creativity.
 * </pre>
 */

internal class NewMessageTriggerFactory(triggerManager: TriggerManager) :
    SingleInstanceTriggerFactory<List<New_message_table_write_log>>(triggerManager) {
    override val type: TriggerManager.TriggerType
        get() = TriggerManager.TriggerType.NEW_MESSAGE

    override fun create(triggerManager: TriggerManager): Trigger<List<New_message_table_write_log>> {
        return object : Trigger<List<New_message_table_write_log>>(triggerManager) {
            override val type: TriggerManager.TriggerType
                get() = TriggerManager.TriggerType.NEW_MESSAGE

            override fun install(db: SqlDriver) {
                triggerManager.temporaryTriggersQueries.run {
                    insetallNewNewMessageTriggerLogTable()
                    installNewMessageInsertTrigger()
                    installNewMessageUpdateTrigger()
                }
            }

            override fun uninstall(db: SqlDriver) {
                triggerManager.temporaryTriggersQueries.run {
                    uninstallNewMessageTriggerLog()
                    uninstallNewMessageInsertTrigger()
                    uninstallNewMessageUpdateTrigger()
                }
            }

            override fun process(db: SqlDriver) {
                triggerManager.temporaryTriggersQueries.run {
                    val list = queryNewMessageLog().executeAsList()
                    if (list.isNotEmpty()) {
                        clearNewMessageLog()
                        callback(list)
                        // update notify sequence
                    }
                }
            }
        }
    }
}