package com.tencent.hms.internal.trigger

import com.squareup.sqldelight.db.SqlDriver
import com.tencent.hms.internal.repository.model.Control_message_trigger_table_log

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-02-18
 * Time:   15:53
 * Life with Passion, Code with Creativity.
 * ```
 */

internal class ControlMessageTriggerFactory(triggerManager: TriggerManager) :
    SingleInstanceTriggerFactory<List<Control_message_trigger_table_log>>(triggerManager) {
    override val type: TriggerManager.TriggerType
        get() = TriggerManager.TriggerType.CONTROL_MESSAGE

    override fun create(triggerManager: TriggerManager): Trigger<List<Control_message_trigger_table_log>> =
        object : Trigger<List<Control_message_trigger_table_log>>(triggerManager) {
            override val type: TriggerManager.TriggerType
                get() = TriggerManager.TriggerType.CONTROL_MESSAGE

            override fun install(db: SqlDriver) {
                triggerManager.temporaryTriggersQueries.apply {
                    installControlMessageTriggerLogTable()
                    installControlMessageInsertTrigger()
                }
            }

            override fun uninstall(db: SqlDriver) {
                triggerManager.temporaryTriggersQueries.apply {
                    uninstallControlMessageTriggerLogTable()
                    uninstallControlMessageInsertTrigger()
                }
            }

            override fun process(db: SqlDriver) {
                val list = triggerManager.temporaryTriggersQueries.queryControlMessageLog()
                    .executeAsList()
                if (list.isNotEmpty()) {
                    callback(list)
                    triggerManager.temporaryTriggersQueries.clearControlMessageLog()
                }
            }
        }
}
