package com.tencent.hms.internal.report

import com.tencent.hms.HMSIllegalArgumentException

/**
 * 统一上报数据
 * sdk_version //sdk版本
 * event_id //事件，枚举值，需要提前定义
 * event_info //事件带上去的一些信息，例如session id等，用|分割，可以约定
 * timestamp //事件发生的时间
 * time_cost //时间耗时，例如统计sql查询耗时等
 * err_code //错误码
 * err_msg //错误信息
 * ext1 //预留字段
 * ext2 //预留字段
 * ext3 //预留字段
 */
internal data class CommonReportData(
    val appId: String,
    val uid: String,
    val ip: String,
    val deviceInfo: String,
    val sdkVersion: String,
    val eventId: String,
    val eventInfo: String,
    val timestamp: Long,
    val timeCost: Long,
    val errorCode: String,
    val errorMessage: String,
    val ext1: String?,
    val ext2: String?,
    val ext3: String?
)



/**
 * wns 命令字上报
 * 命令字，设备号，设备ip , 设备信息 ,sdk 版本， appid , uid，上报时间，命令字耗时 ，error msg ,error code ,ext1, ext2, ext3
 */
internal data class WnsReportData(
    val command: String,
    val appId: String,
    val uid: String,
    val errorCode: Long,
    val errorMsg: String,
    val upTime: Long,
    val costTime: Long,
    val deviceId: String,
    val ipAddress: String,
    val sdkVersion: String,
    val ext1: String?,
    val ext2: String?,
    val ext3: String?
)


internal enum class ReportDataStatus { READY, SENDING, FAILED;

    internal fun value() = when (this) {
        READY -> 0L
        SENDING -> 1L
        FAILED -> 2L
    }

    companion object {
        internal fun convert(type: Int): ReportDataStatus = when (type) {
            0 -> READY
            1 -> SENDING
            2 -> FAILED
            else -> {
                throw HMSIllegalArgumentException("Illegal ReportDataStatus type $type")
            }
        }
    }
}

internal enum class ReportEventID {
    SQLITE, WNS;

    internal fun value() = when (this) {
        ReportEventID.SQLITE -> "SQLITE"
        ReportEventID.WNS -> "WNS"
    }

    companion object {
        internal fun convert(eventId: String): ReportEventID = when (eventId) {
            "SQLITE" -> ReportEventID.SQLITE
            "WNS" -> ReportEventID.WNS
            else -> {
                throw HMSIllegalArgumentException("Illegal ReportEventID eventId")
            }
        }
    }

}



