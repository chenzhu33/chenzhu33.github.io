package com.tencent.hms.internal

import com.tencent.hms.HMSInstanceDestroyedException
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext

/**
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-23
 * Time:   11:05
 * Life with Passion, Code with Creativity.
 * </pre>
 */

internal class SerialCoroutineExecutor(
    private val logger: HMSLogger,
    private val scope: CoroutineScope
) {
    private var currentJob: Job? = null
    private val jobMutex = Mutex()

    fun execute(
        context: CoroutineContext = EmptyCoroutineContext,
        cancellationHandler: ((HMSInstanceDestroyedException) -> Unit)? = null,
        block: suspend () -> Unit
    ) {
        var predecessorJob: Job? = null
        lateinit var newJob: Job
        newJob = scope.launch(context = context, start = CoroutineStart.LAZY) {
            try {
                predecessorJob?.join()
            } catch (e: Exception) {
                if (e is CancellationException) {
                    throw e
                } else {
                    logger.e(TAG, e) { "failed while join previous job" }
                }
            }

            try {
                block()
            } finally {
                jobMutex.withLock {
                    if (currentJob == newJob) {
                        // avoid memory leak
                        currentJob = null
                    }
                }
            }
        }

        val job = scope.launch(context) {
            try {
                jobMutex.withLock {
                    predecessorJob = currentJob
                    currentJob = newJob
                }
                newJob.start()
            } catch (e: CancellationException) {
                cancellationHandler?.invoke(HMSInstanceDestroyedException(e))
            }
        }

        if (job.isCancelled) {
            cancellationHandler?.invoke(HMSInstanceDestroyedException())
        }
    }

    companion object {
        private const val TAG = "SerialCoroutineExecutor"
    }
}

