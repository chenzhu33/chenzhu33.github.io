package com.tencent.hms.internal.message

import com.tencent.hms.*
import com.tencent.hms.internal.*
import com.tencent.hms.internal.protocol.*
import com.tencent.hms.internal.repository.insertOrUpdateMessages
import com.tencent.hms.internal.repository.model.MessageDB
import com.tencent.hms.message.HMSMessageIndex
import com.tencent.hms.message.HMSMessageNotFoundException
import com.tencent.hms.message.HMSMessageStatus
import kotlinx.coroutines.withContext

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-10
 * Time:   10:45
 * Life with Passion, Code with Creativity.
 * ```
 */

internal class MessageSendManager(private val hmsCore: HMSCore) {

    @Suppress("NOTHING_TO_INLINE")
    private inline fun generateClientKey(sid: String) =
        generateClientKey(hmsCore.appId, hmsCore.uid, sid)

    /**
     * @return message sequence
     * @throws HMSException on failure
     */
    suspend fun saveAndSendMessage(
        sid: String,
        type: Int,
        text: String,
        pushText: String?,
        payload: ByteArray?,
        reminds: Message.Reminds?,
        extension: ByteArray?,
        isNeedClearRedPoint: Boolean
    ): HMSMessageIndex = withContext(hmsCore.DBWrite) {
        val index = addLocalMessage(
            sid, type, text, pushText, payload,
            reminds, extension
        )
        sendMessageToServer(
            sid,
            type,
            index.clientKey,
            text,
            pushText,
            payload?.let { MessageElement(MessageElement.Element.Payload(it.toByteString())) },
            reminds,
            isNeedClearRedPoint
        )
        index
    }

    /**
     * send message to server, only save to db when request success
     * @return message sequence
     * @throws HMSException on failure
     */
    suspend fun sendMessageToServer(
        sid: String,
        type: Int,
        text: String,
        pushText: String?,
        element: MessageElement?,
        reminds: Message.Reminds?,
        isNeedClearRedPoint: Boolean
    ): HMSMessageIndex = withContext(hmsCore.DBWrite) {
        val clientKey = generateClientKey(sid)
        sendMessageToServer(sid, type, clientKey, text, pushText, element, reminds, isNeedClearRedPoint)
        queryMessageIndexByClientKey(clientKey)
    }

    /**
     * add a draft message, prepared to send
     * @return clientKey
     * @throws HMSException on failure
     */
    suspend fun addLocalMessage(
        sid: String,
        type: Int,
        text: String,
        pushText: String?,
        payload: ByteArray?,
        reminds: Message.Reminds?,
        extension: ByteArray?
    ): HMSMessageIndex = withContext(hmsCore.DBWrite) {
        addLocalMessage(
            sid, type, text, pushText, payload,
            reminds?.encode(), extension
        )
    }

    private fun addLocalMessage(
        sid: String,
        type: Int,
        text: String,
        pushText: String?,
        payload: ByteArray?,
        reminds: ByteArray?,
        extension: ByteArray?
    ): HMSMessageIndex {
        val clientKey = generateClientKey(sid)
        return hmsCore.database.transactionWithResult {
            val maxLocalSequence = hmsCore.database
                .sessionDBQueries
                .queryMaxSequenceBySids(listOf(sid))
                .executeAsOneOrNull()
                ?.max_sequence
                ?: 0L

            hmsCore.database.messageDBQueries.insertLocalMessage(
                sid,
                timestamp(),
                hmsCore.uid,
                type.toLong(),
                HMSMessageStatus.LOCAL.value,
                text,
                pushText,
                payload?.let { MessageElement(MessageElement.Element.Payload(it.toByteString())).encode() },
                reminds,
                clientKey,
                maxLocalSequence,
                extension
            )

            queryMessageIndexByClientKey(clientKey)
        }
    }

    private fun queryMessageIndexByClientKey(clientKey: String) =
        hmsCore.database.messageDBQueries.queryMessageIndex(
            clientKey
        ).executeAsOne().run {
            HMSMessageIndex(clientKey, sid, local_sequence, help_sequence, sequence)
        }

    /**
     * update a local message, prepared to send
     * @throws HMSException on failure
     */
    suspend fun updateLocalMessage(
        index: HMSMessageIndex,
        type: Int? = INT_PLACEHOLDER,
        text: String = STRING_PLACEHOLDER,
        pushText: String? = STRING_PLACEHOLDER,
        payload: Any? = ANY_PLACEHOLDER,
        reminds: List<String> = LIST_PLACEHOLDER(),
        extension: Any? = ANY_PLACEHOLDER
    ) = withContext(hmsCore.DBWrite) {
        hmsCore.database.transaction {
            val dbMessage by lazy(LazyThreadSafetyMode.NONE) {
                hmsCore.database.messageDBQueries.queryMessagesByClientKey(listOf(index.clientKey))
                    .executeAsOneOrNull() ?: throw IllegalArgumentException("can't find message with index $index")
            }

            val dbType = if (type != INT_PLACEHOLDER) type!!.toLong() else dbMessage.type
            val dbText = if (text !== STRING_PLACEHOLDER) text else dbMessage.text
            val dbPushText = if (pushText !== STRING_PLACEHOLDER) pushText else dbMessage.push_text

            val dbPayload = if (payload !== ANY_PLACEHOLDER) {
                if (dbMessage.is_control) {
                    throw IllegalArgumentException("can't change payload of a control message!")
                }

                if (type == INT_PLACEHOLDER) {
                    throw IllegalArgumentException("payload is not default value, but type is! payload must be appeared with the existence of type!")
                }
                payload?.let {
                    MessageElement(
                        MessageElement.Element.Payload(
                            hmsCore.serializer.serializeMessagePayload(type!!, payload).toByteString()
                        )
                    ).encode()
                }
            } else {
                dbMessage.data
            }

            val dbReminds = if (reminds !== LIST_PLACEHOLDER<String>()) {
                Message.Reminds(reminds).encode()
            } else {
                dbMessage.reminds
            }

            val dbExtension = if (extension !== ANY_PLACEHOLDER) {
                extension?.let { hmsCore.serializer.serializeMessageExtension(it) }
            } else {
                dbMessage.extension
            }

            hmsCore.database.messageDBQueries.updateLocalMessage(
                dbText, dbPushText, dbPayload, dbReminds, dbExtension, dbType, index.clientKey
            )
        }
    }

    /**
     *
     * @throws HMSException on failure
     */
    fun queryLocalMessage(index: HMSMessageIndex): MessageDB? {
        return hmsCore.database
            .messageDBQueries
            .queryMessagesByClientKey(listOf(index.clientKey))
            .executeAsOneOrNull()
    }

    suspend fun markLocalMessageDeleted(index: HMSMessageIndex) = withContext(hmsCore.DBWrite) {
        // delete use flag, not really delete
        hmsCore.database
            .messageDBQueries
            .setMessageDelete(index.clientKey)
    }

    /**
     *
     * @throws HMSException on failure
     */
    private fun deleteLocalMessage(index: HMSMessageIndex) {
        hmsCore.database
            .messageDBQueries
            .deleteLocalMessagesByClientKey(listOf(index.clientKey))
    }

    /**
     *
     * @throws HMSException on failure
     */
    suspend fun sendLocalMessage(
        index: HMSMessageIndex,
        isNeedClearRedPoint: Boolean
    ): Long = withContext(hmsCore.DBWrite) {
        val db = queryLocalMessage(index)
            ?: throw HMSMessageNotFoundException("local message $index not found")

        checkForSendLocalMessage(db, index)

        sendMessageToServer(
            db.sid,
            db.type!!.toInt(),
            index.clientKey,
            db.text,
            db.push_text,
            db.data?.decode(MessageElement.ADAPTER),
            db.reminds?.decode(Message.Reminds.ADAPTER),
            isNeedClearRedPoint
        )
    }

    /**
     * 删除本地的一条消息，并重新发送，此时消息会展示在最新的位置。
     * @throws HMSException on failure
     */
    suspend fun deleteAndResendLocalMessage(
        index: HMSMessageIndex,
        isNeedClearRedPoint: Boolean
    ): HMSMessageIndex = withContext(hmsCore.DBWrite) {
        val message = queryLocalMessage(index)
            ?: throw HMSMessageNotFoundException("local message $index not found")

        checkForSendLocalMessage(message, index)

        val newIndex = hmsCore.database.transactionWithResult {
            deleteLocalMessage(index)
            addLocalMessage(
                message.sid,
                message.type!!.toInt(),
                message.text,
                message.push_text,
                message.data,
                message.reminds,
                message.extension
            )
        }

        hmsCore.logger.v(TAG) { "deleteAndResendLocalMessage old:${index.toSimpleString()} new:${newIndex.toSimpleString()}" }

        val sequence = sendMessageToServer(
            message.sid,
            message.type!!.toInt(),
            newIndex.clientKey,
            message.text,
            message.push_text,
            message.data?.let { MessageElement(MessageElement.Element.Payload(it.toByteString())) },
            message.reminds?.decode(Message.Reminds.ADAPTER),
            isNeedClearRedPoint
        )
        newIndex.copy(sequence = sequence)
    }

    @Suppress("NOTHING_TO_INLINE")
    private inline fun checkForSendLocalMessage(
        message: MessageDB,
        index: HMSMessageIndex
    ) {
        if (message.status == HMSMessageStatus.SENDING.value) {
            throw HMSIllegalArgumentException("message is already sending $index ")
        }
        if (message.status == HMSMessageStatus.SUCCESS.value) {
            throw HMSIllegalArgumentException("can't send a server message $index ")
        }
    }

    private suspend fun sendMessageToServer(
        sid: String,
        type: Int,
        clientKey: String,
        text: String,
        pushText: String?,
        element: MessageElement?,
        reminds: Message.Reminds?,
        isNeedClearRedPoint: Boolean
    ): Long = try {
        hmsCore.database.messageDBQueries.updateMessageStatus(
            null,
            0,
            0,
            timestamp(),
            HMSMessageStatus.SENDING.value,
            clientKey
        )

        val sessionMaxSequence = hmsCore.database.sessionDBQueries.queryMaxSequenceBySids(listOf(sid))
            .executeAsOneOrNull()
            ?.max_sequence

        val request = SendMessageReq(
            hmsCore.makeHeader(),
            listOf(
                SendMessageReq.SendMessageStruct(
                    Message(
                        sessionID = sid,
                        type = type,
                        text = text,
                        element = element,
                        pushText = pushText,
                        reminds = reminds,
                        clientKey = clientKey,
                        isNeedClearRedPoint = isNeedClearRedPoint
                    ),
                    sessionMaxSequence
                )
            )
        )
        val reply = hmsCore.sendRequestWithRetry(
            HMSRequestType.SendMessage,
            request,
            SendMessageRsp.ADAPTER
        )
        assertServerData {
            processSendMessageReply(request, reply).first()
        }
    } catch (e: HMSException) {
        hmsCore.logger.e(TAG, e) { "send message failed" }
        // update status to fail
        hmsCore.database.messageDBQueries.updateMessageStatus(
            null,
            0,
            0,
            timestamp(),
            HMSMessageStatus.SEND_FAILED.value,
            clientKey
        )
        throw e
    }

    private fun processSendMessageReply(request: SendMessageReq, reply: SendMessageRsp): List<Long> =
        reply.results.mapIndexed { index, sendMessageResult ->
            try {
                if (sendMessageResult.returnCode.pb != 0) {
                    throw HMSIllegalServerResponseException(
                        sendMessageResult.returnCode ?: COMMON_ERROR_CODE,
                        "send message failed"
                    )
                }

                assertServerData(message = "send message failed") {
                    val message = sendMessageResult.message
                        ?: request.messageStructs[index].message!!.copy(
                            sender = User(hmsCore.uid),
                            sequence = sendMessageResult.sequence!!,
                            countSequence = sendMessageResult.countSequence.pb,
                            revokeNumber = sendMessageResult.revokeNumber.pb,
                            messageTimestamp = sendMessageResult.timestamp.pb
                        )

                    hmsCore.insertOrUpdateMessages(listOf(message))
                    if (hmsCore.uid == message.sender?.uid.pb
                        && request.messageStructs[index].message?.isNeedClearRedPoint == true
                    ) {
                        // 解决自己发的消息回包比setSessionRead晚，未读计数加一的情况
                        hmsCore.database.sessionDBQueries.updateLocalReadSequenceIncrement(
                            message.sequence.pb,
                            message.sessionID.pb
                        )
                    }
                    return@mapIndexed message.sequence.pb
                }
            } catch (e: HMSException) {
                hmsCore.logger.e(TAG, e) { "send message failed" }
                // update status to fail
                if (sendMessageResult.message != null) {
                    sendMessageResult.message.clientKey
                } else {
                    sendMessageResult.clientKey
                }?.let {
                    hmsCore.database.messageDBQueries.updateMessageStatus(
                        null,
                        0,
                        0,
                        timestamp(),
                        HMSMessageStatus.SEND_FAILED.value,
                        it
                    )
                }
                // abort
                throw e
            }
        }

    companion object {
        private const val TAG = "MessageSendManager"
    }
}
