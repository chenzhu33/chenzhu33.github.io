package com.tencent.hms.profile

import com.tencent.hms.internal.protocol.PermissionType

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-02-28
 * Time:   15:13
 * Life with Passion, Code with Creativity.
 * ```
 */

enum class HMSUserRole {
    /**
     * Session的创建者，主人（群主）
     */
    OWNER,
    /**
     * 管理员
     */
    ADMINISTRATOR,
    /**
     * 普通用户
     */
    NORMAL;

    internal fun toProtocol(): PermissionType =
        when (this) {
            OWNER -> PermissionType.GroupOwner
            ADMINISTRATOR -> PermissionType.Administrator
            NORMAL -> PermissionType.OrdinaryMember
        }

    companion object {
        internal fun fromProtocol(protocorl: PermissionType) =
            when (protocorl) {
                PermissionType.Administrator -> ADMINISTRATOR
                PermissionType.GroupOwner -> OWNER
                PermissionType.OrdinaryMember -> NORMAL
            }
    }
}