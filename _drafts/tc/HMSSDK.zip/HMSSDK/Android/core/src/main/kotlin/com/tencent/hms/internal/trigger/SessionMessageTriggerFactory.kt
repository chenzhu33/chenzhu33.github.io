package com.tencent.hms.internal.trigger

import com.squareup.sqldelight.db.SqlDriver
import com.tencent.hms.internal.repository.model.Message_table_for_session_write_log
import com.tencent.hms.internal.repository.model.TemporaryTriggersQueries
import com.tencent.hms.internal.toUrlString

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-07
 * Time:   21:10
 * Life with Passion, Code with Creativity.
 * ```
 */


internal class SessionMessageTriggerFactory(triggerManager: TriggerManager) :
    MultiInstanceTriggerFactory<List<Message_table_for_session_write_log>, String>(triggerManager) {

    companion object {
        internal const val OP_INSERT = 0L
        internal const val OP_UPDATE = 1L
        internal const val OP_DELETE = 2L
    }

    override val type: TriggerManager.TriggerType
        get() = TriggerManager.TriggerType.SESSION_MESSAGE

    override fun generateInstanceKey(vararg param: Any): String {
        if (!(param.size == 1 && param[0] is String)) {
            throw IllegalArgumentException("invalid param for SessionMessageTrigger only one String is accepted. passed ${param.toList()}")
        }
        return param[0] as String
    }

    override fun create(
        instanceKey: String,
        triggerManager: TriggerManager
    ) = object : MultiInstanceTrigger<List<Message_table_for_session_write_log>, String>(triggerManager) {
        override val instanceKey: String
            get() = instanceKey

        override val type: TriggerManager.TriggerType
            get() = TriggerManager.TriggerType.SESSION_MESSAGE

        // -- 1.1 单个 session 的 message 更新
        val logTableName = "message_table_for_session_${instanceKey}_write_log".toUrlString()
        val insertTriggerName = "message_table_for_session_${instanceKey}_write_trigger_insert".toUrlString()
        val updateTriggerName = "message_table_for_session_${instanceKey}_write_trigger_update".toUrlString()
        val deleteTriggerName = "message_table_for_session_${instanceKey}_write_trigger_delete".toUrlString()

        override fun install(db: SqlDriver) {
            db.execute(
                null,
                """
                    |CREATE TEMP TABLE IF NOT EXISTS $logTableName(
                    |   id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    |   local_sequence INTEGER NOT NULL,
                    |   help_sequence INTEGER NOT NULL,
                    |   operation INTEGER NOT NULL -- 0 insert, 1 update, 2 delete
                    |);
                    |""".trimMargin(),
                0
            )

            db.execute(
                null,
                """
                    |CREATE TEMP TRIGGER IF NOT EXISTS $insertTriggerName
                    |AFTER INSERT ON messageDB WHEN new.sid='$instanceKey'
                    |BEGIN
                    |    INSERT OR REPLACE INTO $logTableName (local_sequence, help_sequence, operation)
                    |       VALUES(new.local_sequence, new.help_sequence, $OP_INSERT);
                    |END;
                    """.trimMargin(),
                0
            )

            db.execute(
                null,
                """
                    |CREATE TEMP TRIGGER IF NOT EXISTS $updateTriggerName
                    |AFTER UPDATE OF message_timestamp,type,status,is_read,is_deleted,is_revoked,text,data,push_text,reminds ON messageDB WHEN new.sid='$instanceKey'
                    |BEGIN
                    |   INSERT OR REPLACE INTO $logTableName (local_sequence, help_sequence, operation)
                    |       VALUES(new.local_sequence, new.help_sequence, $OP_UPDATE);
                    |END;
                    |""".trimMargin(),
                0
            )


            db.execute(
                null,
                """
                    |CREATE TEMP TRIGGER IF NOT EXISTS $deleteTriggerName
                    |AFTER DELETE ON messageDB WHEN old.sid='$instanceKey'
                    |BEGIN
                    |    INSERT OR REPLACE INTO $logTableName (local_sequence, help_sequence, operation)
                    |       VALUES(old.local_sequence, old.help_sequence, $OP_DELETE);
                    |END;
                    """.trimMargin(),
                0
            )
        }

        override fun uninstall(db: SqlDriver) {
            db.execute(null, "DROP TABLE IF EXISTS $logTableName;", 0)
            db.execute(null, "DROP TRIGGER IF EXISTS $updateTriggerName;", 0)
            db.execute(null, "DROP TRIGGER IF EXISTS $insertTriggerName;", 0)
            db.execute(null, "DROP TRIGGER IF EXISTS $deleteTriggerName;", 0)
        }

        /**
         * refer to [TemporaryTriggersQueries.sampleMessageForSessionQuery]
         */
        override fun process(db: SqlDriver) {
            db.executeQuery(
                null,
                "SELECT * FROM $logTableName ORDER BY id ASC;",
                0
            ).use { cursor ->
                val list = mutableListOf<Message_table_for_session_write_log>()
                while (cursor.next()) {
                    list.add(
                        Message_table_for_session_write_log.Impl(
                            cursor.getLong(0)!!,
                            cursor.getLong(1)!!,
                            cursor.getLong(2)!!,
                            cursor.getLong(3)!!
                        )
                    )
                }

                if (list.isNotEmpty()) {
                    callback(processChanges(list))
                    db.execute(null, "DELETE FROM $logTableName;", 0)
                }
            }
        }

        // fold multiple db operation into one
        private fun processChanges(list: MutableList<Message_table_for_session_write_log>) =
            list.groupBy { it.local_sequence to it.help_sequence }
                .map { (lh, changeList) ->
                    changeList.fold(-1L) { acc, log ->
                        when {
                            acc == -1L -> log.operation
                            // * + delete = delete
                            //      insert + delete = delete
                            //      update + delete = delete
                            // delete + update = NO-OP
                            // delete + delete = NO-OP
                            log.operation == OP_DELETE -> OP_DELETE
                            // update + update = update
                            // update + insert = NO-OP
                            acc == OP_UPDATE -> OP_UPDATE
                            // insert + update = insert
                            // insert + insert = NO-OP
                            acc == OP_INSERT -> OP_INSERT
                            // delete + insert = update
                            // delete + update = NO-OP
                            // delete + delete = NO-OP
                            acc == OP_DELETE -> OP_UPDATE
                            else -> throw IllegalStateException(
                                "Invalid db operation, acc:$acc now:${log.operation}"
                            )
                        }
                    }.let { op ->
                        Message_table_for_session_write_log.Impl(-1, lh.first, lh.second, op)
                    }
                }
    }
}
