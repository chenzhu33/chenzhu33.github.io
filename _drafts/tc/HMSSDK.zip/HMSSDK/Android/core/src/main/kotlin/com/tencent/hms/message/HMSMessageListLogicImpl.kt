package com.tencent.hms.message

import com.tencent.hms.*
import com.tencent.hms.internal.*
import com.tencent.hms.internal.message.MessageReceiveManager
import com.tencent.hms.internal.repository.model.MessageDB
import com.tencent.hms.internal.repository.model.Message_table_for_session_write_log
import com.tencent.hms.internal.repository.model.Session_table_log
import com.tencent.hms.internal.repository.queryMessagesByIndex
import com.tencent.hms.internal.trigger.SessionMessageTriggerFactory
import com.tencent.hms.internal.trigger.TriggerManager
import com.tencent.hms.internal.user.MemberInfoUpdateCallback
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.plus
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

/**
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2019-03-22
 * Time:   17:01
 * Life with Passion, Code with Creativity.
 * </pre>
 */

internal class HMSMessageListLogicImpl internal constructor(
    internal val hmsCore: HMSCore,
    internal val sid: String,
    internal val startIndex: HMSMessageIndex?,
    internal val pageSize: Int,
    internal val prefetchDistance: Int,
    internal val maxListSize: Int,
    internal val configCompleteHoles: Boolean,
    internal val _messageFilter: ((HMSMessage) -> Boolean)? = null
) : HMSDisposable, HMSObservableList<HMSMessage> {

    private val messageList = HMSObservableMutableList<HMSMessage>()
    private val usersInList = HashSet<String>()

    private val MESSAGE_INDEX_NONE = HMSMessageIndex("null_index", "", 0, 0, 0)
    @Volatile
    private var historyLoadingHolesLoadingIndex: HMSMessageIndex = MESSAGE_INDEX_NONE
    @Volatile
    private var newLoadingHolesLoadingIndex: HMSMessageIndex? = MESSAGE_INDEX_NONE
    // for debug only
    @Volatile
    private var newLoadingToken = 0
    private val newLoadingTrace: String get() = "loadNewMessage-$newLoadingToken"
    // for debug only
    @Volatile
    private var historyLoadingToken = 0
    private val historyLoadingTrace: String get() = "loadHistoryMessage-$historyLoadingToken"

    // sessionMaxSequence must > messageListMaxSequence on initialize
    @Volatile
    private var sessionMaxSequence: Long = -1
    private var messageListMaxSequence: Long = -2

    private var historyLoadIndex: HMSMessageIndex? = null
    private var newLoadIndex: HMSMessageIndex? = startIndex

    private val messageFilter: (HMSMessage) -> Boolean = {
        defaultMessageFilter(it) && (_messageFilter?.invoke(it) ?: true)
    }

    private val coroutineJob = Job(parent = hmsCore.hmsScope.coroutineContext[Job])
    private val serialCoroutineExecutor = SerialCoroutineExecutor(
        hmsCore.logger,
        hmsCore.hmsScope + coroutineJob
    )
    val disposed: Boolean
        get() = coroutineJob.isCancelled

    private val triggerListener = HMSDisposableCallback(::onSessionMessageUpdate)
    private val sessionListener = HMSDisposableCallback(::onSessionUpdate)
    private val userChangeListener = HMSDisposableValue<MemberInfoUpdateCallback>(
        object : MemberInfoUpdateCallback {
            override fun onUserChange(uids: Set<String>) {
                dispatchUserChange(uids)
            }

            override fun onUserInSessionChange(sidUids: Map<String, Set<String>>) {
                sidUids[sid]?.let {
                    dispatchUserChange(it)
                }
            }
        })

    init {
        /*
         * 约定：
         * 0. pageSize > 0
         * 1. prefetchDistance >= 0 && < pageSize
         * 2. maxListSize > pageSize
         */
        if (pageSize <= 0) {
            throw IllegalArgumentException("invalid pageSize:$pageSize, must >= 0")
        }
        if (prefetchDistance >= pageSize) {
            throw IllegalArgumentException("invalid prefetchDistance:$prefetchDistance, must < pageSize($pageSize)")
        }
        if (maxListSize < pageSize) {
            throw IllegalArgumentException("invalid maxListSize:$maxListSize, must > pageSize($pageSize)")
        }
    }

    /**
     * get message range of current listPair.
     * from new to old
     * @throws NoSuchElementException when [size] is zero.
     */
    val range: HMSMessageRange
        get() = HMSMessageRange(messageList.first().index, messageList.last().index)

    override fun setUpdateCallback(callback: HMSListUpdateCallback?) {
        messageList.setUpdateCallback(callback)
    }

    /**
     * get message list size
     */
    override val size: Int get() = messageList.size

    /**
     * get message at index
     */
    override operator fun get(index: Int): HMSMessage {
        if (index - prefetchDistance < 0) {
            loadMoreNewMessages()
        }
        if (index + prefetchDistance >= size) {
            loadMoreHistoryMessages()
        }

        return messageList[index]
    }

    /**
     * loading status of history message
     */
    val historyMessageLoadStatus =
        HMSObservableData<HMSMessageListLogic.LoadStatus>(hmsCore.executors, HMSMessageListLogic.LoadStatus.IDLE)

    /**
     * loading status of new message
     */
    val newMessageLoadStatus =
        HMSObservableData<HMSMessageListLogic.LoadStatus>(hmsCore.executors, HMSMessageListLogic.LoadStatus.IDLE)

    /**
     * When there are too many new massages, we can't receive them all at once, this is how discontinuous new message
     * come in to being. In such scenario, we can:
     *
     * 1. Either let user scroll to latest message page by page.
     * 2. Or create a new [HMSMessageListLogic] instance ([dispose] this one) and restart display the latest message as first page.
     *
     */
    val hasDiscontinuousNewMessages = HMSObservableData<Boolean>(hmsCore.executors, false)

    init {
        hmsCore.hmsScope.launch {
            sessionMaxSequence = hmsCore.database.sessionDBQueries.queryMaxSequenceBySids(listOf(sid))
                .executeAsOneOrNull()
                ?.max_sequence ?: 0L

            loadMoreNewMessages()
            serialCoroutineExecutor.execute(hmsCore.DBWrite) {
                // register trigger only after first page is loaded
                hmsCore.triggerManager.registerTriggerCallback(
                    TriggerManager.TriggerType.SESSION_MESSAGE,
                    triggerListener,
                    sid
                )
                hmsCore.triggerManager.registerTriggerCallback(
                    TriggerManager.TriggerType.SESSION,
                    sessionListener
                )
                hmsCore.userManager.addDataChangeListener(userChangeListener)
            }
        }
    }

    /**
     * dispose this instance when no longer used, to avoid memory leaks.
     */
    override fun dispose() {
        messageList.clear()
        setUpdateCallback(null)
        coroutineJob.cancel()
        triggerListener.dispose()
        sessionListener.dispose()
        userChangeListener.dispose()
    }

    fun loadMoreNewMessages() {
        if (hmsCore.isDestroyed || coroutineJob.isCancelled) {
            noteDestroyed(newMessageLoadStatus)
            return
        }
        if (messageListMaxSequence >= sessionMaxSequence) {
            // no more new message
            return
        }

        if (newMessageLoadStatus.data == HMSMessageListLogic.LoadStatus.LOADING) {
            // don't do concurrent loading
            return
        }

        newLoadingToken++
        newMessageLoadStatus.setData(HMSMessageListLogic.LoadStatus.LOADING)

        val from: HMSMessageIndex? = newLoadIndex

        hmsCore.logger.v(TAG) { "$newLoadingTrace loadMoreNewMessages from:$from starting" }

        serialCoroutineExecutor.execute(hmsCore.Main, {
            newMessageLoadStatus.setData(HMSMessageListLogic.LoadStatus.FAILED(it))
        }) {
            try {
                getAndInsertNewMessages(from, configCompleteHoles)
            } catch (e: HMSException) {
                hmsCore.logger.e(TAG, e) { "$newLoadingTrace loadMoreNewMessages from:$from failed" }
                newLoadingHolesLoadingIndex = MESSAGE_INDEX_NONE
                newMessageLoadStatus.setData(HMSMessageListLogic.LoadStatus.FAILED(e))

            } catch (holesFoundException: MessageReceiveManager.MessageHolesFoundException) {
                newLoadingHolesLoadingIndex = from

                try {
                    hmsCore.logger.v(TAG) {
                        "$newLoadingTrace loadMoreNewMessages from:$from foundMessageHoles:${holesFoundException.holes}, waiting for trigger"
                    }

                    holesFoundException.completeHolesAsync.await() // this may fail with exception

                    installNewMessageTriggerBarrier() // trigger may still fail...
                } catch (e: HMSException) {
                    try {
                        hmsCore.logger.i(TAG, e) {
                            "$newLoadingTrace loadMoreNewMessages from:$from complete holes failed ${holesFoundException.holes}, we accept holes now"
                        }
                        getAndInsertNewMessages(from, false)
                    } catch (e: HMSException) {
                        // still failed? Well, there is not much we can do here, let's fail
                        hmsCore.logger.e(
                            TAG,
                            e
                        ) { "$newLoadingTrace loadMoreNewMessages from:$from accepting holes failed" }
                        newLoadingHolesLoadingIndex = MESSAGE_INDEX_NONE
                        newMessageLoadStatus.setData(HMSMessageListLogic.LoadStatus.FAILED(e))
                    }
                }
            }
        }
    }

    private fun installNewMessageTriggerBarrier() {
        serialCoroutineExecutor.execute(hmsCore.Main) {
            if (newLoadingHolesLoadingIndex !== MESSAGE_INDEX_NONE) {
                val fromIndex = newLoadingHolesLoadingIndex
                hmsCore.logger.w(TAG) {
                    "$newLoadingTrace installNewMessageTriggerBarrier trigger barrier:$fromIndex " +
                            "trigger not processed " +
                            "or trigger message still has holes"
                }
                try {
                    newLoadingHolesLoadingIndex = MESSAGE_INDEX_NONE
                    getAndInsertNewMessages(fromIndex, false)
                } catch (e: HMSException) {
                    hmsCore.logger.e(TAG, e) {
                        "$newLoadingTrace installNewMessageTriggerBarrier from:$fromIndex accepting holes failed"
                    }
                    newMessageLoadStatus.setData(HMSMessageListLogic.LoadStatus.FAILED(e))
                }
            }
        }
    }

    private suspend fun getAndInsertNewMessages(fromIndex: HMSMessageIndex?, completeHoles: Boolean) {
        val result = withContext(hmsCore.Worker) {
            // this may fail with exception
            // or throw MessageHolesFoundException
            hmsCore.messageReceiveManager.getLatestMessage(
                sid, fromIndex, pageSize, completeHoles
            ).first.toHmsMessages()
        }

        // dispatch result
        insertAndNotify(result.filter(messageFilter), "$newLoadingTrace getAndInsertNewMessages")
        newMessageLoadStatus.setData(HMSMessageListLogic.LoadStatus.IDLE)
        hmsCore.logger.v(TAG) { "$newLoadingTrace getAndInsertNewMessages from:$fromIndex completeHoles:$completeHoles result:\n${result.map { it.index.toSimpleString() }}" }
    }

    fun loadMoreHistoryMessages() {
        if (hmsCore.isDestroyed || coroutineJob.isCancelled) {
            noteDestroyed(historyMessageLoadStatus)
            return
        }
        if (sessionMaxSequence == -1L) {
            // not ready
            return
        }
        val from = historyLoadIndex
        if (historyMessageLoadStatus.data == HMSMessageListLogic.LoadStatus.LOADING || from == null) {
            // don't do concurrent loading
            return
        }

        historyLoadingToken++
        historyMessageLoadStatus.setData(HMSMessageListLogic.LoadStatus.LOADING)

        serialCoroutineExecutor.execute(hmsCore.Main, {
            historyMessageLoadStatus.setData(HMSMessageListLogic.LoadStatus.FAILED(it))
        }) {
            hmsCore.logger.v(TAG) { "$historyLoadingTrace loadMoreHistoryMessages from:$from starting" }
            try {
                getAndInsertHistoryMessage(from, configCompleteHoles)
            } catch (e: HMSException) {
                hmsCore.logger.e(TAG, e) { "$historyLoadingTrace loadMoreHistoryMessages from:$from failed" }
                historyLoadingHolesLoadingIndex = MESSAGE_INDEX_NONE
                historyMessageLoadStatus.setData(HMSMessageListLogic.LoadStatus.FAILED(e))

            } catch (holesFoundException: MessageReceiveManager.MessageHolesFoundException) {
                historyLoadingHolesLoadingIndex = from

                try {
                    hmsCore.logger.v(TAG) {
                        "$historyLoadingTrace loadMoreHistoryMessages from:$from foundMessageHoles:${holesFoundException.holes}, waiting for trigger"
                    }

                    holesFoundException.completeHolesAsync.await() // this may fail with exception

                    installHistoryMessageTriggerBarrier() // trigger may still fail...
                } catch (e: HMSException) {
                    try {
                        hmsCore.logger.i(TAG, e) {
                            "$historyLoadingTrace loadMoreHistoryMessages from:$from accepting holes failed ${holesFoundException.holes}, we accept holes now"
                        }
                        getAndInsertHistoryMessage(from, false)
                    } catch (e: HMSException) {
                        // still failed??? WTF
                        hmsCore.logger.e(
                            TAG,
                            e
                        ) { "$historyLoadingTrace loadMoreHistoryMessages from:$from accepting holes failed" }
                        historyLoadingHolesLoadingIndex = MESSAGE_INDEX_NONE
                        historyMessageLoadStatus.setData(HMSMessageListLogic.LoadStatus.FAILED(e))
                    }
                }
            }
        }
    }

    private fun installHistoryMessageTriggerBarrier() {
        // ensure this action is executed after loadMoreHistoryMessages (also after db trigger)
        serialCoroutineExecutor.execute(hmsCore.Main) {
            if (historyLoadingHolesLoadingIndex !== MESSAGE_INDEX_NONE) {
                val fromIndex = historyLoadingHolesLoadingIndex
                hmsCore.logger.w(TAG) {
                    "$historyLoadingTrace installHistoryMessageTriggerBarrier trigger barrier:$fromIndex " +
                            "trigger not processed " +
                            "or trigger message still has holes"
                }
                try {
                    historyLoadingHolesLoadingIndex = MESSAGE_INDEX_NONE
                    getAndInsertHistoryMessage(fromIndex, false)
                } catch (e: HMSException) {
                    hmsCore.logger.e(TAG, e) {
                        "$historyLoadingTrace installNewMessageTriggerBarrier from:$fromIndex accepting holes failed"
                    }
                    newMessageLoadStatus.setData(HMSMessageListLogic.LoadStatus.FAILED(e))
                }
            }
        }
    }

    private suspend fun getAndInsertHistoryMessage(from: HMSMessageIndex, completeHoles: Boolean) {
        val result = withContext(hmsCore.Worker) {
            // this may fail with exception
            // or throw MessageHolesFoundException
            hmsCore.messageReceiveManager.getHistoryMessage(
                sid, from, pageSize, completeHoles
            ).first.toHmsMessages()
        }

        // dispatch result
        insertAndNotify(result.filter(messageFilter), "$historyLoadingTrace getAndInsertHistoryMessage")
        if (result.isEmpty()) {
            // no more history message
            historyLoadIndex = null
        }
        historyMessageLoadStatus.setData(HMSMessageListLogic.LoadStatus.IDLE)
        hmsCore.logger.v(TAG) { "$historyLoadingTrace getAndInsertHistoryMessage from:$from completeHoles:$completeHoles result:\n${result.map { it.index.toSimpleString() }}" }
    }

    private fun noteDestroyed(status: HMSObservableData<HMSMessageListLogic.LoadStatus>) {
        val data = status.data
        if (data !is HMSMessageListLogic.LoadStatus.FAILED || data.error !is HMSInstanceDestroyedException) {
            status.setData(HMSMessageListLogic.LoadStatus.FAILED(HMSInstanceDestroyedException()))
        }
    }

    private fun onSessionUpdate(triggerLog: List<Session_table_log>) {
        triggerLog.firstOrNull { it.sid == sid }?.let {
            sessionMaxSequence = max(
                hmsCore.database.sessionDBQueries.queryMaxSequenceBySids(listOf(sid))
                    .executeAsOneOrNull()
                    ?.max_sequence ?: -1L,
                sessionMaxSequence
            )
        }
    }

    private fun onSessionMessageUpdate(triggerLog: List<Message_table_for_session_write_log>) {
        serialCoroutineExecutor.execute {
            hmsCore.logger.v(TAG) { "onSessionMessageUpdate $triggerLog" }

            val currentRange = try {
                range
            } catch (e: NoSuchElementException) {
                null
            }
            val changes = triggerLog.groupBy { it.operation }

            val deleted = currentRange?.let { range ->
                changes[SessionMessageTriggerFactory.OP_DELETE]?.map {
                    HMSMessageIndex("", sid, it.local_sequence, it.help_sequence, null)
                }?.filter { range.contains(it) }
            }

            val updatedMessages = currentRange?.let { range ->
                changes[SessionMessageTriggerFactory.OP_UPDATE]?.map {
                    HMSMessageIndex("", sid, it.local_sequence, it.help_sequence, null)
                }?.filter { range.contains(it) }
            }?.let { hmsCore.database.messageDBQueries.queryMessagesByIndex(sid, it) }
                ?.toHmsMessagesOrNull()

            val insertIndexes = changes[SessionMessageTriggerFactory.OP_INSERT]?.map {
                HMSMessageIndex("", sid, it.local_sequence, it.help_sequence, null)
            }?.sorted()

            val historyPageIndex = historyLoadIndex
            val insertHistory = (historyLoadingHolesLoadingIndex !== MESSAGE_INDEX_NONE) &&
                    historyPageIndex != null &&
                    currentRange != null &&
                    (insertIndexes?.any { it.olderThan(historyPageIndex) } == true)

            val newPageIndex = newLoadIndex
            val insertNew = (newLoadingHolesLoadingIndex !== MESSAGE_INDEX_NONE) ||
                    (newPageIndex == null || (insertIndexes?.any { it.newerThan(newPageIndex) } == true))

            val historyMessages = insertHistory.takeIf { it }
                ?.let { hmsCore.messageReceiveManager.getHistoryMessage(sid, historyPageIndex!!, pageSize, false) }
                ?.takeIf { it.second.isEmpty() }
                ?.let { it.first.toHmsMessagesOrNull() }
                ?.takeIf { it.isNotEmpty() }
                ?.filter(messageFilter)

            val newMessagesAndHoles = insertNew.takeIf { it }
                ?.let { hmsCore.messageReceiveManager.getLatestMessage(sid, newPageIndex, pageSize, false) }
            val newMessageHasHole = newMessagesAndHoles?.second?.isNotEmpty() == true

            val newMessages = if (!newMessageHasHole) {
                newMessagesAndHoles
                    ?.first
                    ?.toHmsMessagesOrNull()
                    ?.filter(messageFilter)
            } else {
                null
            }

            if (newMessageHasHole) {
                hmsCore.logger.w(TAG) { "new message has hole for $sid" }
            }

            // updated an not filtered out
            val realUpdated = updatedMessages?.filter(messageFilter)
            // deleted or updated and filtered out
            val realDeleted = (deleted ?: emptyList()) +
                    (updatedMessages?.filter { !messageFilter(it) }?.map { it.index } ?: emptyList())

            withContext(hmsCore.Main) {
                dispatchTriggerChanges(
                    historyMessages,
                    newMessages,
                    newMessageHasHole,
                    realUpdated,
                    realDeleted
                )
            }
        }
    }

    private fun dispatchUserChange(uids: Set<String>) {
        serialCoroutineExecutor.execute(hmsCore.Main) {
            val changed = usersInList.intersect(uids).toList()

            val memberInfos = withContext(hmsCore.Worker) {
                hmsCore.userManager.getUsersMemberInfoCache(sid, changed)
                    .associateByTo(HashMap()) { it.user.uid }
            }

            messageList.forEachIndexed { index, msg ->
                if (msg is HMSPlainMessage) {
                    if (memberInfos.containsKey(msg.sender)) {
                        val newPlainMsg = msg.copy(
                            senderInfo = memberInfos[msg.sender]!!
                        )
                        messageList[index] = newPlainMsg
                    }
                }
            }
        }
    }

    private fun dispatchTriggerChanges(
        historyMessages: List<HMSMessage>?,
        newMessages: List<HMSMessage>?,
        newMessageHasHole: Boolean,
        updatedMessages: List<HMSMessage>?,
        deleted: List<HMSMessageIndex>?
    ) {
        if (!historyMessages.isNullOrEmpty()) {
            val reason = "$historyLoadingTrace triggerHistory ${historyLoadingHolesLoadingIndex.toSimpleString()}"
            historyLoadingHolesLoadingIndex = MESSAGE_INDEX_NONE
            historyMessageLoadStatus.setData(HMSMessageListLogic.LoadStatus.IDLE)
            insertAndNotify(historyMessages, reason)
        }

        if (!newMessages.isNullOrEmpty()) {
            val reason = "$newLoadingTrace triggerNew ${newLoadingHolesLoadingIndex?.toSimpleString()}"
            newLoadingHolesLoadingIndex = MESSAGE_INDEX_NONE
            newMessageLoadStatus.setData(HMSMessageListLogic.LoadStatus.IDLE)
            insertAndNotify(newMessages, reason)
        }

        // process change
        updatedMessages?.forEach { update ->
            val index = messageList.binarySearchBy(update.index, 0, messageList.size) { it.index }
            if (index >= 0) {
                messageList[index] = update
            }
        }

        updatedMessages?.let { update ->
            updateMessageListMaxSequenceByNewMessages(update)
        }

        // process remove
        deleted?.forEach { delete ->
            val index = messageList.binarySearchBy(delete, 0, messageList.size) { it.index }
            if (index >= 0) {
                messageList.removeAt(index)
            }
        }

        if (hasDiscontinuousNewMessages.data!! && !newMessageHasHole) {
            // previously has discontinuous, now new page has no hole
            // we unset discontinuous flag, only when we have the latest message
            hasDiscontinuousNewMessages.setData(messageListMaxSequence >= sessionMaxSequence)
        } else {
            hasDiscontinuousNewMessages.setData(newMessageHasHole)
        }
    }

    private fun insertAndNotify(insert: List<HMSMessage>, reason: String) {
        if (insert.isNotEmpty()) {
            var index = findInsertLocation(insert.first().index, messageList)
            val doCheckNewMessageHoles = index == 0
            if (insert.isNotEmpty()) {
                index = spareSpaceForInsertion(index, insert.size)
                messageList.addAll(index, insert)
                insert.forEach {
                    if (it is HMSPlainMessage) {
                        usersInList.add(it.sender)
                    }

                    newLoadIndex = messageList.first().index
                    historyLoadIndex = messageList.last().index
                }
                hmsCore.logger.v(TAG) {
                    "notifyItemInsert(reason=$reason) index:$index count:${insert.size} startMessageIndex:${insert.first().index}\n" +
                            "${insert.map { it.index.toSimpleString() + " " + it.text }}"
                }

                updateMessageListMaxSequenceByNewMessages(insert, doCheckNewMessageHoles)
            }
        }
    }

    private fun spareSpaceForInsertion(index: Int, size: Int): Int {
        if (size > maxListSize) {
            messageList.clear()
            return 0
        }
        var newIndex = index
        var spared = false

        var sizeToSpare = messageList.size + size - maxListSize
        if (sizeToSpare > 0 && index < messageList.size) {
            // spare size from back
            val spareBackCount = min(sizeToSpare, messageList.size - index)
            messageList.removeRange(messageList.size - spareBackCount, messageList.size)
            sizeToSpare -= spareBackCount
            spared = true
        }
        if (sizeToSpare > 0 && index > 0) {
            // spare size from front
            val spareFrontCount = min(sizeToSpare, index + 1)
            messageList.removeRange(0, spareFrontCount)
            newIndex = index - spareFrontCount
            spared = true
        }

        if (spared) {
            // recalculate max sequence
            messageListMaxSequence = messageList.maxBy { it.index.sequence ?: -1L }
                ?.index?.sequence ?: -1L
        }
        return newIndex
    }

    private fun updateMessageListMaxSequenceByNewMessages(
        update: List<HMSMessage>,
        doCheckNewMessageHoles: Boolean = false
    ) {
        // update messageListMaxSequence
        val oldMax = messageListMaxSequence
        val newMax = max(
            oldMax,
            update.maxBy { it.index.sequence ?: -1L }?.index?.sequence ?: 0L
        )
        messageListMaxSequence = newMax

        if (doCheckNewMessageHoles) {
            checkNewMessageHoles(oldMax, newMax)
        }
    }

    /**
     * Corner case where we have lost all pushes.
     * When user send a new message, it would cause hole(s) in new message.
     */
    private fun checkNewMessageHoles(oldMax: Long, newMax: Long) {
        if (oldMax != -1L && newMax - oldMax > 1 && (newLoadingHolesLoadingIndex === MESSAGE_INDEX_NONE)) {
            val newList = messageList.subList(
                0,
                messageList.indexOfFirst { it.index.sequence == oldMax } + 1
            )
                .filter { it.index.sequence != null }
                .sortedByDescending { it.index.sequence!! }

            var holeStartIndex: HMSMessageIndex? = null

            var prevSeq = newMax
            for (msg in newList) {
                val seq = msg.index.sequence!!
                if (seq < oldMax) {
                    break
                }

                if (prevSeq - seq > 1) {
                    // not contiguous, ie. found holes
                    holeStartIndex = msg.index
                }

                prevSeq = seq
            }

            if (holeStartIndex != null) {
                hmsCore.logger.d(TAG) {
                    "lost push!! and found hole [${newMax - 1} .. ${holeStartIndex.sequence!! + 1}] when send message"
                }
                serialCoroutineExecutor.execute {
                    try {
                        hmsCore.messageReceiveManager.completeHolesAfterIndex(
                            sid,
                            holeStartIndex,
                            max(pageSize.toLong(), newMax - holeStartIndex.sequence!!).toInt()
                        )
                    } catch (holesFoundException: MessageReceiveManager.MessageHolesFoundException) {
                        hmsCore.logger.v(TAG) { "checkNewMessageHoles completing holes:${holesFoundException.holes}" }
                        try {
                            holesFoundException.completeHolesAsync.await()
                        } catch (e: HMSException) {
                            hmsCore.logger.e(TAG, e) {
                                "checkNewMessageHoles completing holes failed again!:${holesFoundException.holes}"
                            }
                        }
                    }
                }
            } else {
                hmsCore.logger.d(TAG) { "lost push!! WTF old:$oldMax new:$newMax" }
            }
        }
    }

    private fun findInsertLocation(
        item: HMSMessageIndex,
        list: List<HMSMessage>
    ): Int {
        val size = list.size
        // short cuts
        if (size == 0 || item < list.first().index) {
            return 0
        } else if (item > list.last().index) {
            return size
        }
        val index = list.binarySearch {
            it.index.compareTo(item)
        }
        return if (index >= 0) {
            index
        } else {
            -index - 1
        }
    }


    private fun List<MessageDB>.toHmsMessages() = map {
        HMSMessage.fromDB(it, hmsCore)
    }

    private fun List<MessageDB>.toHmsMessagesOrNull() = try {
        map { HMSMessage.fromDB(it, hmsCore) }
        } catch (e: NullPointerException) {
            // invalid server data
            hmsCore.logger.e(TAG, e) { "convert MessageDB to HMSMessage failed" }
            null
        }

    companion object {
        private const val TAG = "HMSMessageListLogic"
    }


}

