package com.tencent.hms.internal

import com.tencent.hms.HMSCore
import com.tencent.hms.HMSInstanceDestroyedException
import com.tencent.hms.internal.protocol.HmsHeader
import kotlinx.coroutines.CoroutineDispatcher

/**
 * <pre>
 * Author: landerlyoung@gmail.com
 * Date:   2019-03-07
 * Time:   17:29
 * Life with Passion, Code with Creativity.
 * </pre>
 */

/**
 * Coroutine dispatcher for main thread.
 */
internal inline val HMSCore.Main: CoroutineDispatcher
    get() = executors.Main

/**
 * Coroutine dispatcher for worker thread.
 */
internal inline val HMSCore.Worker: CoroutineDispatcher
    get() = executors.Worker

/**
 * Coroutine dispatcher for db write worker thread.
 */
internal inline val HMSCore.DBWrite: CoroutineDispatcher
    get() = executors.DBWrite


@Suppress("NOTHING_TO_INLINE")
internal inline fun HMSCore.makeHeader() =
    HmsHeader(appId, HMSCore.VERSION_CODE)

@Suppress("NOTHING_TO_INLINE")
internal inline fun HMSCore.assertNonDestroy() {
    if (isDestroyed) {
        throw HMSInstanceDestroyedException()
    }
}