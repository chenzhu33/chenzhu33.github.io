package com.tencent.hms.session

import com.tencent.hms.*
import com.tencent.hms.internal.Main
import com.tencent.hms.internal.SerialCoroutineExecutor
import com.tencent.hms.internal.Worker
import com.tencent.hms.internal.repository.model.MessageDB
import com.tencent.hms.internal.repository.model.SessionDB
import com.tencent.hms.internal.session.SessionManager
import com.tencent.hms.message.HMSMessage
import kotlinx.coroutines.Job
import kotlinx.coroutines.plus
import kotlinx.coroutines.withContext

/**
 * 创建一个会话列表，用于业务侧实现一个会话列表页面
 *
 * 详细描述见 [HMSCore.createSessionListLogic]
 * @see HMSCore.createSessionListLogic
 */
class HMSSessionListLogic internal constructor(
    private val hmsCore: HMSCore,
    _sessionFilter: ((HMSSession) -> Boolean)? = null,
    _sessionComparator: Comparator<HMSSession>? = null
) : HMSDisposable, HMSObservableList<HMSSession> {

    companion object {
        const val TAG = "HMSSessionListLogic"
    }

    private val coroutineJob = Job(parent = hmsCore.hmsScope.coroutineContext[Job])
    private val serialCoroutineExecutor = SerialCoroutineExecutor(
        hmsCore.logger, hmsCore.hmsScope + coroutineJob
    )

    private val sessionList = HMSObservableMutableList<HMSSession>()

    private val sessionFilter: (HMSSession) -> Boolean = {
        !it.isDeleted && (_sessionFilter?.invoke(it) ?: true)
    }

    private val sessionComparator: Comparator<HMSSession> =
        _sessionComparator ?: HMSSession.SESSION_BY_TIMESTAMP_COMPARATOR

    /**
     * get message list size
     */
    override val size: Int get() = sessionList.size

    fun toList(): List<HMSSession> {
        return sessionList
    }

    /**
     * get message at index
     */
    override operator fun get(index: Int): HMSSession {
        return sessionList[index]
    }
    /**
     * session更新的trigger callback
     */
    private val sessionListChangeProcess = object : SessionManager.SessionsChangeListener {
        override fun onSessionsChange(datas: List<SessionDB>) {
            serialCoroutineExecutor.execute {
                hmsCore.logger.d(TAG, null) { "trigger update sids" + datas.map { it.sid }.toList().toString() }

                val newlist = datas.map { sessionDB ->
                    val message: MessageDB? =
                        hmsCore.database.messageDBQueries.queryLastOneMessageBySidDesc(sessionDB.sid)
                            .executeAsOneOrNull()

                    val unread = hmsCore.sessionManager.getUnreadCountBySession(sessionDB)

                    HMSSession.fromDB(
                        sessionDB,
                        unread,
                        message?.let { HMSMessage.fromDB(it, hmsCore) },
                        hmsCore.serializer
                    )
                }


                val newSession = newlist.filter(sessionFilter)
                    .associateBy { it.sid }
                    .toMutableMap()
                val deleted = newlist.filter { !sessionFilter(it) }
                    .map { it.sid }
                    .toSet()

                withContext(hmsCore.Main) {
                    dispatchUpdates(deleted, newSession)
                }
            }
        }
    }



    private fun dispatchUpdates(
        deleteSids: Set<String>,
        newSessions: MutableMap<String, HMSSession>
    ) {
        // 清掉已删除的session
        val iterator = sessionList.iterator()
        while (iterator.hasNext()) {
            val session = iterator.next()
            if (deleteSids.contains(session.sid)) {
                iterator.remove()
            }
        }

        // get new total list
        val newSessionIds = newSessions.keys.toList()
        val mergeList = mutableListOf<HMSSession>()
        mergeList.addAll(sessionList)
        mergeList.forEachIndexed { index, hmsSession ->
            if (newSessions.contains(hmsSession.sid)) {
                mergeList[index] = newSessions[hmsSession.sid]!!
                newSessions.remove(hmsSession.sid)
            }
        }
        mergeList.addAll(newSessions.values)

        val sortedMergeList = mergeList.sortedWith(sessionComparator)
        sortedMergeList.forEachIndexed { newPosition, newSession ->
            val oldPosition = sessionList.indexOfFirst { it.sid.equals(newSession.sid) }
            if (oldPosition < 0) {
                // 新增 item
                if (newPosition < sessionList.size) {
                    sessionList.add(newPosition, newSession)
                } else {
                    sessionList.add(newSession)
                }
            } else if (oldPosition == newPosition) {
                if (newSessionIds.contains(newSession.sid)) {
                    // 更新 item
                    sessionList[newPosition] = newSession
                }
            } else {
                //replace item
                sessionList.removeAt(oldPosition)

                if (newPosition < sessionList.size) {
                    sessionList.add(newPosition, newSession)
                } else {
                    sessionList.add(newSession)
                }
            }
        }
    }

    init {
        hmsCore.sessionManager.addSessionsChangeListener(sessionListChangeProcess)
        serialCoroutineExecutor.execute(hmsCore.Worker) {
            getTotalSessions()
        }
    }


    private fun getTotalSessions() {
        hmsCore.logger.d(TAG, null) { "start getTotalSessions" }
        try {
            val list = hmsCore.database.sessionDBQueries.queryAllSession()
                .executeAsList().filter { !it.is_deleted }
                .map { sessionDB ->
                    val message: MessageDB? =
                        hmsCore.database.messageDBQueries.queryLastOneMessageBySidDesc(sessionDB.sid)
                            .executeAsOneOrNull()
                    val unread = hmsCore.sessionManager.getUnreadCountBySession(sessionDB)
                    val userInfo =
                        if (message != null) hmsCore.userManager.getUsersMemberInfoCache(
                            sessionDB.sid,
                            listOf(message.sender)
                        ) else null

                    HMSSession.fromDB(
                        sessionDB,
                        unread,
                        message?.let {
                            HMSMessage.fromDB(
                                it,
                                hmsCore,
                                userInfo?.firstOrNull()
                            )
                        },
                        hmsCore.serializer
                    )
                }.filter(sessionFilter)
            val sortedList = list.sortedWith(sessionComparator)
            hmsCore.logger.d(TAG, null) { "start getTotalSessions size ${sortedList.size}" }

            serialCoroutineExecutor.execute(hmsCore.Main) {
                sessionList.clear()
                sessionList.addAll(sortedList)
            }
        } catch (exception: HMSException) {
            hmsCore.logger.e(TAG, exception) { "get Total Session" }
        }
    }


    override fun setUpdateCallback(callback: HMSListUpdateCallback?) {
        sessionList.setUpdateCallback(callback)
    }

    /**
     * 当不再使用该实例的时候，一定要调用该接口
     */
    override fun dispose() {
        coroutineJob.cancel()
        setUpdateCallback(null)
        hmsCore.sessionManager.removeSessionChangeListener(sessionListChangeProcess)
    }

}


