package com.tencent.hms.session

import com.tencent.hms.internal.protocol.MsgAlertType

/**
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2019-06-13
 * Time:   15:18
 * Life with Passion, Code with Creativity.
 * </pre>
 */

/**
 * 会话消息提醒类型
 */
enum class HMSMessageAlertType {
    /**
     * 消息提醒
     */
    MessageRemind,

    /**
     * 消息免打扰
     */
    DoNotDisturb;

    internal fun toProtorol(): MsgAlertType = when (this) {
        MessageRemind -> MsgAlertType.MessageRemind
        DoNotDisturb -> MsgAlertType.Disturb
    }

    internal companion object {
        fun fromProtocol(protocol: MsgAlertType?) = when (protocol) {
            null, MsgAlertType.MessageRemind -> MessageRemind
            MsgAlertType.Disturb -> DoNotDisturb
        }
    }
}