package com.tencent.hms.internal.trigger

import com.squareup.sqldelight.db.SqlDriver
import com.tencent.hms.HMSDisposableCallback
import java.util.concurrent.CopyOnWriteArrayList

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-07
 * Time:   21:02
 * Life with Passion, Code with Creativity.
 * ```
 */
internal abstract class Trigger<T : Any>(private val triggerManager: TriggerManager) {

    private val callbacks = CopyOnWriteArrayList<HMSDisposableCallback<T>>()

    private val disposeListener: (HMSDisposableCallback<T>) -> Unit = { callback ->
        synchronized(type) {
            callbacks.remove(callback)
            if (isIdle) {
                triggerManager.removeTrigger(this)
            }
        }
    }

    val isIdle: Boolean
        get() = callbacks.isEmpty()

    abstract val type: TriggerManager.TriggerType

    fun destroy() {
        callbacks.forEach { it.dispose() }
    }

    abstract fun install(db: SqlDriver)

    abstract fun uninstall(db: SqlDriver)

    fun register(callback: HMSDisposableCallback<T>) {
        synchronized(type) {
            callbacks.add(callback)
            callback.setDisposeListener(disposeListener)
        }
    }

    fun callback(data: T) {
        callbacks.forEach { it.callback(data) }
    }

    abstract fun process(db: SqlDriver)
}