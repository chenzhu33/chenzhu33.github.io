package com.tencent.hms.session

import com.tencent.hms.HMSCore
import com.tencent.hms.HMSDisposable
import com.tencent.hms.HMSObservableData
import com.tencent.hms.internal.repository.model.SessionDB
import com.tencent.hms.internal.session.SessionManager
import java.util.concurrent.ConcurrentHashMap

/**
 * Created by juliandai on 2019/3/27 5:33 PM.
 * talk and show the code
 */
class HMSSessionCountLogic internal constructor(
    private val hmsCore: HMSCore,
    private val _sessionFilter: ((HMSSession) -> Boolean)? = null
) : HMSDisposable, HMSObservableData<Long>(hmsCore.executors) {

    companion object {
        private const val TAG: String = "HMSSessionCountLogic"
    }

    private val unreadCache = ConcurrentHashMap<String, Long>()

    private val sessionChangeListener = object : SessionManager.SessionsChangeListener {
        override fun onSessionsChange(datas: List<SessionDB>) {
            datas.forEach {
                if (it.is_deleted) {
                    unreadCache.remove(it.sid)
                } else {
                    getSessionCountWithFilter(it).let { count ->
                        if (count >= 0) {
                            unreadCache.put(it.sid, count)
                        } else {
                            unreadCache.remove(it.sid)
                        }
                    }
                }
            }
            hmsCore.logger.d(TAG, null) { "unread count cache:$unreadCache" }
            setData(unreadCache.values.sum())
        }
    }

    init {
        fetch()
        hmsCore.sessionManager.addSessionsChangeListener(sessionChangeListener)
    }

    private fun fetch() {
        hmsCore.executors.run {
            unreadCache.clear()

            val oldSessionList = hmsCore.database.sessionDBQueries.queryAllSession()
                .executeAsList()

            oldSessionList.forEach { sessionDB ->
                if (!sessionDB.is_deleted) {
                    getSessionCountWithFilter(sessionDB).let {
                        if (it >= 0) {
                            unreadCache[sessionDB.sid] = it
                        }
                    }
                }
            }
            hmsCore.logger.v(TAG, null) { "after fetch :$unreadCache" }
            setData(unreadCache.values.sum())
        }
    }


    override fun dispose() {
        hmsCore.sessionManager.removeSessionChangeListener(sessionChangeListener)
        unreadCache.clear()

        hmsCore.logger.v(TAG, null) { "clear the unread cache" }
    }

    private fun getSessionCountWithFilter(sessionDB: SessionDB): Long {
        if (_sessionFilter != null) {
            HMSSession.fromDB(sessionDB, 0, null, hmsCore.serializer).let {
                if (_sessionFilter.invoke(it)) {
                    return hmsCore.sessionManager.unreadCountCache.getCountBySession(sessionDB)
                }
            }
            return -1L
        } else {
            return hmsCore.sessionManager.unreadCountCache.getCountBySession(sessionDB)
        }
    }


}