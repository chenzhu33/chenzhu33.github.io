package com.tencent.hms.internal.session

import com.tencent.hms.*
import com.tencent.hms.internal.*
import com.tencent.hms.internal.protocol.GetSessionInfoReq
import com.tencent.hms.internal.protocol.GetSessionInfoRsp
import com.tencent.hms.internal.protocol.GetSessionListReq
import com.tencent.hms.internal.protocol.GetSessionListRsp
import com.tencent.hms.internal.repository.insertOrUpdate
import com.tencent.hms.internal.repository.insertOrUpdateUserInSessions
import com.tencent.hms.internal.repository.insertOrUpdateUsers
import com.tencent.hms.internal.repository.model.Message_table_write_log
import com.tencent.hms.internal.repository.model.New_message_table_write_log
import com.tencent.hms.internal.repository.model.SessionDB
import com.tencent.hms.internal.repository.model.Session_table_log
import com.tencent.hms.internal.trigger.TriggerManager
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Created by juliandai on 2019/3/26 2:16 PM.
 * talk and show the code
 */
internal class SessionDataManager(private val hmsCore: HMSCore) {

    companion object {
        const val TAG: String = "SessionDataManager"
        const val PULL_SIZE = 20
        const val NETWORK_DISCONNECTED_TO_REFRESH_TIME_THRESHOLD_MS = 10_000L
        const val SESSION_PULL_LOOP_TIME = 600_000L
    }

    private var networkDisconnectedTimestamp: Long = 0
    private var sessionChangeTimestamp: Long = 0

    private var loopToken: Any? = null

    init {
        registerNewMessageTriggerToUpdateSessionMaxSequence()
        registerNewMessageTriggerToGetSessionInfo()
        registerSessionUpdateTrigger()
    }

    //默认创建所有会话的未读计数
    internal val unreadCountCache = UnreadCountCache()

    fun dispose() {
        unscheduleLoop()
    }

    private fun unscheduleLoop() {
        loopToken?.let {
            hmsCore.executors.unscheduleTask(it)
        }
        loopToken = null
    }

    private fun doSessionPull() {
        hmsCore.hmsScope.launch {
            if (timestamp().minus(sessionChangeTimestamp) > SESSION_PULL_LOOP_TIME) {
                hmsCore.logger.d(TAG) { "10 min event cycle to pull session list" }
                initSessionList()
            }

            withContext(hmsCore.Main) {
                if (loopToken != null) {
                    // still foreground, schedule for the next loop
                    loopToken = hmsCore.executors.scheduleTask(
                        SESSION_PULL_LOOP_TIME, ::doSessionPull
                    )
                }
            }
        }
    }

    internal suspend fun initSessionList() = withContext(hmsCore.DBWrite) {
        try {
            val oldSessionList = hmsCore.database.sessionDBQueries.queryAllSession()
                .executeAsList()
            unreadCountCache.updateData(oldSessionList)

            //pull new session list
            assertServerData(message = "GetSessionList") {

                val reply = hmsCore.sendRequestWithRetry(
                    HMSRequestType.GetSessionList,
                    GetSessionListReq(
                        hmsCore.makeHeader(),
                        oldSessionList.filter { !it.is_deleted }.map { it.sid to it.max_sequence.pb }.toMap()
                    ),
                    GetSessionListRsp.ADAPTER
                )

                hmsCore.database.transaction {
                    reply.sessionAndMessageList.forEach {
                        hmsCore.database.sessionDBQueries.insertOrUpdate(it.session)
                        val list = reply.sessionAndMessageList.flatMap { it.latestMessages }
                        hmsCore.messageReceiveManager.insertMessages(list)
                    }
                }

                //只有id没有info的session
                val sidlist = reply.sessionIDs
                val size = sidlist.size
                var startPosition = 0
                do {
                    val endPosition =
                        if (startPosition + PULL_SIZE >= size) size else startPosition + PULL_SIZE
                    val subList = sidlist.subList(startPosition, endPosition)

                    assertServerData(message = "GetSessionInfo") {
                        val outReply = hmsCore.sendRequestWithRetry(
                            HMSRequestType.GetSessionInfo,
                            GetSessionInfoReq(hmsCore.makeHeader(), subList),
                            GetSessionInfoRsp.ADAPTER
                        )
                        outReply.sessionAndMessageList.forEach {
                            hmsCore.database.sessionDBQueries.insertOrUpdate(it.session)
                        }
                        val list = outReply.sessionAndMessageList.flatMap { it.latestMessages }
                        hmsCore.messageReceiveManager.insertMessages(list)
                    }

                    startPosition = endPosition + 1
                } while (startPosition < size)
            }

            sessionChangeTimestamp = timestamp()
        } catch (exception: HMSException) {
            hmsCore.logger.e(TAG, exception) {
                "request session from net"
            }
        }
    }


    fun onNetworkStatusChange(connected: Boolean) {
        networkDisconnectedTimestamp = if (!connected) {
            timestamp()
        } else {
            if (timestamp() - networkDisconnectedTimestamp >= NETWORK_DISCONNECTED_TO_REFRESH_TIME_THRESHOLD_MS || sessionChangeTimestamp == 0L) {
                hmsCore.hmsScope.launch {
                    hmsCore.logger.d(TAG, null) { "onNetworkStatusChange to pull session list" }
                    initSessionList()
                }
            }
            0
        }
    }

    fun onForegroundStatusChange(isForeground: Boolean) {
        if (isForeground) {
            unscheduleLoop()
            // 启动10分钟轮询逻辑，防止一直没收到notify就没有更新消息
            loopToken = hmsCore.executors.scheduleTask(SESSION_PULL_LOOP_TIME, ::doSessionPull)
        } else {
            unscheduleLoop()
        }
    }

    // 有新消息来时，更新session的max sequence，没有放在trigger中是因为会跟installNewMessageInsertTrigger冲突
    private fun registerNewMessageTriggerToUpdateSessionMaxSequence() {
        // 注册trigger
        hmsCore.triggerManager.registerTriggerCallback(
            TriggerManager.TriggerType.NEW_MESSAGE,
            HMSDisposableCallback<List<New_message_table_write_log>> { log ->
                // we are already inside a trigger transaction
                // post to make the next db write will have trigger
                hmsCore.triggerManager.triggerTransaction.afterCommit {
                    val newSeq: Map<String, Long?> = log.groupBy { it.sid }
                        .mapValues { it.value.maxBy { it.sequence }?.sequence }
                        .filter { it.value != null }
                    hmsCore.logger.d(TAG, null) { "update session seq :$newSeq" }
                    hmsCore.database.sessionDBQueries.transaction {
                        newSeq.entries.forEach {
                            hmsCore.database.sessionDBQueries.updateMaxSequenceBySid(it.value!!, it.key)
                        }
                    }
                }
            })
    }

    //有新消息但本地没有对应的session
    private fun registerNewMessageTriggerToGetSessionInfo() {
        hmsCore.triggerManager.registerTriggerCallback(TriggerManager.TriggerType.GLOBAL_MESSAGE
            , HMSDisposableCallback<List<Message_table_write_log>> {
                val sids = it.map { it.sid }.toList()
                val localSids =
                    hmsCore.database.sessionDBQueries.queryAllSids().executeAsList()
                val newSids = sids.filter { !localSids.contains(it) }.distinct()
                if (!newSids.isEmpty()) {
                    hmsCore.logger.d(TAG, null) { "new msg to trigger get new session ${newSids} " }
                    hmsCore.hmsScope.launch(hmsCore.DBWrite) {
                        assertServerData(message = "GetSessionInfo") {
                            val outReply = hmsCore.sendRequestWithRetry(
                                HMSRequestType.GetSessionInfo,
                                GetSessionInfoReq(hmsCore.makeHeader(), newSids),
                                GetSessionInfoRsp.ADAPTER
                            )
                            outReply.sessionAndMessageList.forEach {
                                it.session?.let {
                                    hmsCore.database.sessionDBQueries.insertOrUpdate(it)
                                }
                                hmsCore.database.userDBQueries.insertOrUpdateUsers(
                                    it.latestMessages.filter { it.sender != null }.map {
                                        it.sender!!
                                    })
                                hmsCore.database.userInSessionDBQueries.insertOrUpdateUserInSessions(
                                    it.latestMessages.filter { it.senderInSession != null }.map {
                                        it.senderInSession!!
                                    }
                                )
                            }
                        }
                    }
                }
            })
    }


    //session 有更新时的trigger
    private fun registerSessionUpdateTrigger() {
        hmsCore.triggerManager.registerTriggerCallback(
            TriggerManager.TriggerType.SESSION, HMSDisposableCallback<List<Session_table_log>> {
                val sids = it.map { it.sid }
                val datas = hmsCore.database.sessionDBQueries.querySessionBySids(sids).executeAsList()
                //先计算未读数
                unreadCountCache.updateData(datas)
                var sessionChangeListenersCopy: List<SessionManager.SessionsChangeListener>
                synchronized(sessionChangeListeners) {
                    sessionChangeListenersCopy = sessionChangeListeners.toList()
                }
                sessionChangeListenersCopy.forEach { listener ->
                    listener.onSessionsChange(datas)
                }

                sessionChangeTimestamp = timestamp()
            }
        )
    }

    internal fun addSessionChangeListener(listener: SessionManager.SessionsChangeListener) {
        synchronized(sessionChangeListeners) {
            sessionChangeListeners.add(listener)
        }
    }

    internal fun removeSessionChangeListener(listener: SessionManager.SessionsChangeListener) {
        synchronized(sessionChangeListeners) {
            sessionChangeListeners.remove(listener)
        }
    }

    private val sessionChangeListeners = mutableListOf<SessionManager.SessionsChangeListener>()

    /**
     *计算会话未读数
     */
    private fun calculateUnreadCount(session: SessionDB): Long {
        //max unread sequence 对应消息
        val unreadMaxMsg = hmsCore.database.messageDBQueries
            .queryMessageBySequence(session.max_sequence, session.sid)
            .executeAsOneOrNull()
        if (unreadMaxMsg == null || unreadMaxMsg.count_sequence == 0L) {
            return 0
        }
        val unreadCountSeq = unreadMaxMsg.count_sequence
        val unreadRevokeNum = unreadMaxMsg.revoke_number

        val maxReadLocalSeq = session.local_read_sequence //本地最大已读seq
        val maxReadServerSeq = Math.min(session.read_max_sequence, session.max_sequence)//服务端最大已读seq
        val visibleSeq = session.visible_sequence  //服务消息最大可见的seq
        val readMaxSeq = Math.max(maxReadLocalSeq, maxReadServerSeq) //最大已读seq

        if (readMaxSeq == session.max_sequence) {
            hmsCore.logger.d(TAG) { "readMaxSeq == session.max_sequence $readMaxSeq" }
            return 0
        }

        val readMaxOrVisibleSeq = if (visibleSeq <= readMaxSeq) readMaxSeq else visibleSeq
        val isUseVisibleSeq = visibleSeq > readMaxSeq
        hmsCore.logger.d(TAG) {
            "sid:${session.sid}-calUnread:Local-$maxReadLocalSeq,Server-$maxReadServerSeq,Visible-$visibleSeq" +
                    ",session.max_sequence-${session.max_sequence}"
        }


        //已读最大的sequence对应消息
        val maxSeqReadMsg = hmsCore.database.messageDBQueries.queryMessageBySequence(readMaxOrVisibleSeq, session.sid)
            .executeAsOneOrNull()
        val readRevokeNum = maxSeqReadMsg?.revoke_number ?: 0

        //get msg info from network and wait for the trigger to retry caculate the unread count
        val needUpdateSeqs = mutableListOf<LongRange>()
        if (maxSeqReadMsg == null) {
            needUpdateSeqs.add(readMaxOrVisibleSeq..readMaxOrVisibleSeq)
        }
        if (needUpdateSeqs.isNotEmpty()) {
            hmsCore.hmsScope.launch {
                try {
                    hmsCore.messageReceiveManager.getRangeMessage(session.sid, needUpdateSeqs)
                } catch (e: HMSException) {
                    hmsCore.logger.e(TAG, e) { "failed to get range method for session ${session.sid}" }
                }
            }
        }
        val readCountSeq = maxSeqReadMsg?.count_sequence ?: 0

        //计算结果
        hmsCore.logger.d(
            TAG,
            null
        ) { "sid:${session.sid}-calculateUnread:unreadSeq-$unreadCountSeq,readSeq-$readCountSeq" +
                ",unreadRevokeNum-$unreadRevokeNum,readRevoke-$readRevokeNum" }

        if (isUseVisibleSeq && maxSeqReadMsg != null) {
            if (!maxSeqReadMsg.is_revoked && !maxSeqReadMsg.is_control) {
                val result = unreadCountSeq.minus(readCountSeq).plus(unreadRevokeNum.minus(readRevokeNum)) + 1
                return Math.max(result, 0)
            }
        }
        val result = unreadCountSeq.minus(readCountSeq).minus(unreadRevokeNum.minus(readRevokeNum))
        return Math.max(result, 0)
    }

    //未读计数管理
    inner class UnreadCountCache : HMSObservableData<Long>(hmsCore.executors) {

        private val unreadBySidMap = HashMap<String, Long>()

        fun getCountBySession(session: SessionDB): Long {
            return unreadBySidMap[session.sid] ?: calculateUnreadCount(session)
        }

        internal fun updateData(sessionList: List<SessionDB>) {
            sessionList.forEach { sessionDB ->
                if (sessionDB.is_deleted) {
                    unreadBySidMap.remove(sessionDB.sid)
                } else {
                    unreadBySidMap.put(sessionDB.sid, calculateUnreadCount(sessionDB))
                }
            }
            setData(unreadBySidMap.values.sum())
        }

    }


}