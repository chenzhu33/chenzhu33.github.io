package com.tencent.hms.internal

import com.tencent.hms.HMSExecutorDelegate
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Runnable
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.ScheduledThreadPoolExecutor
import java.util.concurrent.TimeUnit
import kotlin.coroutines.CoroutineContext

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-07
 * Time:   10:38
 * Life with Passion, Code with Creativity.
 * ```
 */

internal class HMSExecutors(private val delegate: HMSExecutorDelegate) {
    private val isDbWriteThread = ThreadLocal<Boolean>()

    fun assertMainThread(method: String? = null) {
        if (!isMainThread()) {
            throw AssertionError("${method ?: "method"} must be called on main thread")
        }
    }

    fun assertWorkerThread(method: String? = null) {
        if (isMainThread()) {
            throw AssertionError("${method ?: "method"} must be called on worker thread")
        }
    }

    fun assertDbWriteThread() {
        if (!isDbWriteThread()) {
            throw AssertionError("DB write not on $HMS_DB_WRITE_THREAD_NAME thread current thread is ${Thread.currentThread().name}")
        }
    }

    fun isDbWriteThread(): Boolean {
        return isDbWriteThread.get() == true
    }

    /**
     * Coroutine dispatcher for main thread.
     */
    val Main = object : CoroutineDispatcher() {
        override fun dispatch(context: CoroutineContext, block: Runnable) {
            executeOnMainThread { block.run() }
        }
    }

    /**
     * Coroutine dispatcher for worker thread.
     */
    val Worker = object : CoroutineDispatcher() {
        override fun dispatch(context: CoroutineContext, block: Runnable) {
            delegate.postToWorker { block.run() }
        }
    }

    /**
     * Immediate Coroutine Dispatcher for database write operation
     */
    val DBWrite = object : CoroutineDispatcher() {
        override fun dispatch(context: CoroutineContext, block: Runnable) {
            dbWriteExecutor.execute(block)
        }

        @ExperimentalCoroutinesApi
        override fun isDispatchNeeded(context: CoroutineContext): Boolean {
            return !isDbWriteThread()
        }
    }

    private val dbWriteExecutor by lazy {
        ScheduledThreadPoolExecutor(1) { runnable ->
            object : Thread(runnable, HMS_DB_WRITE_THREAD_NAME) {
                init {
                    priority = 4 // background priority, ANDROID_PRIORITY_BACKGROUND for android
                }
                override fun run() {
                    isDbWriteThread.set(true)
                    super.run()
                }
            }
        }.apply {
            executeExistingDelayedTasksAfterShutdownPolicy = false
        }
    }

    fun destroy() {
        assertWorkerThread()
        dbWriteExecutor.shutdown()
        // wait for all db task to be done
        dbWriteExecutor.awaitTermination(1L, TimeUnit.MINUTES)
    }

    fun isMainThread(): Boolean =
        delegate.isMainThread()

    fun postToMainThread(block: () -> Unit) =
        delegate.postToMainThread(block)

    fun postToDBWrite(block: () -> Unit) =
        dbWriteExecutor.execute(block)

    /**
     * @return a token to be used with [unscheduleTask]
     */
    fun scheduleTask(delayMillis: Long, block: () -> Unit): Any =
        dbWriteExecutor.schedule(
            block,
            delayMillis,
            TimeUnit.MILLISECONDS
        )

    fun unscheduleTask(token: Any) =
        (token as ScheduledFuture<*>).cancel(true)

    /**
     * @return isExecuted immediately (ie. is currently in main thread)
     */
    inline fun executeOnMainThread(crossinline block: () -> Unit): Boolean =
        if (isMainThread()) {
            block()
            true
        } else {
            postToMainThread { block() }
            false
        }

    inline fun executeOnDbWriteOrFail(crossinline block: () -> Unit) =
        if (isDbWriteThread()) {
            block()
            true
        } else {
            try {
                dbWriteExecutor.execute { block() }
            } catch (e: RejectedExecutionException) {
            }
            false
        }
}

