package com.tencent.hms.message

import com.tencent.hms.HMSCore

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-15
 * Time:   10:51
 * Life with Passion, Code with Creativity.
 * ```
 */

/**
 * 消息的状态，由HMS SDK内部处理.
 */
enum class HMSMessageStatus(internal val value: Long) {
    /**
     * 发送成功
     */
    SUCCESS(0),
    /**
     * 正在发送中
     */
    SENDING(1),
    /**
     * 发送失败
     */
    SEND_FAILED(2),
    /**
     * 本地消息
     * 通过 [HMSCore.addLocalMessage]添加。
     */
    LOCAL(3);

    companion object {
        internal fun fromValue(value: Long) =
            when (value) {
                0L -> SUCCESS
                1L -> SENDING
                2L -> SEND_FAILED
                3L -> LOCAL
                else -> throw IllegalArgumentException()
            }
    }
}
