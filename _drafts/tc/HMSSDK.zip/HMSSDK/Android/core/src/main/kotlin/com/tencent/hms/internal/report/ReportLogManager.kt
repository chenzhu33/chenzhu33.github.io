package com.tencent.hms.internal.report

import com.tencent.hms.HMSCore
import com.tencent.hms.HMSException
import com.tencent.hms.HMSRequestType
import com.tencent.hms.internal.*
import com.tencent.hms.internal.protocol.DataReportReq
import com.tencent.hms.internal.protocol.DataReportRsp
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Created by juliandai on 2019/3/18 2:20 PM.
 * talk and show the code
 *
 * report manager for the sqlite or wns command report
 */
internal class ReportLogManager(private val hms: HMSCore) {


    companion object {
        const val BATCH_REPORT_SIZE = 50
        const val TAG = "ReportManager"
        const val HMS_SQL_DC_NAME = "10012"
    }

    /**
     * report manager 应该在init的时候做延时上报
     */
    internal suspend fun init() {
        hms.hmsScope.launch {
            // db fix to set all sending status to ready to send
            withContext(hms.DBWrite) {
                hms.databaseNoLog.transaction {
                    hms.databaseNoLog.reportLogQueries.fixReportStatus()
                }
            }
            do {
                val logs =
                    hms.databaseNoLog.reportLogQueries.queryReportForSend(BATCH_REPORT_SIZE.toLong())
                        .executeAsList()
                if (logs.isEmpty()) {
                    break
                }
                //start to report
                withContext(hms.DBWrite) {
                    hms.databaseNoLog.reportLogQueries.updateReportLogStatus(
                        ReportDataStatus.SENDING.value(),
                        logs.map { it.report_id }.toList()
                    )
                }
                try {
                    val reportList = logs.map {
                        val map = mutableMapOf<String, String>()
                        map["report_id"] = it.report_id.toString()
                        map["app_id"] = it.app_id.toString()
                        map["uid"] = it.uid.toString()
                        map["device_info"] = it.device_info.pb
                        map["sdk_version"] = it.sdk_version.pb
                        map["send_status"] = it.send_status.toString().pb
                        map["event_id"] = it.event_id.toString().pb
                        map["event_info"] = it.event_info.toString().pb
                        map["timestamp"] = it.timestamp.toString().pb
                        map["time_cost"] = it.time_cost.toString().pb
                        map["error_code"] = it.error_code.toString().pb
                        map["error_message"] = it.error_message.toString().pb
                        map["ext1"] = it.ext1.toString().pb
                        map["ext2"] = it.ext2.toString().pb
                        map["ext3"] = it.ext3.toString().pb
                        DataReportReq.DataRecord(HMS_SQL_DC_NAME, map)
                    }

                    assertServerData {
                        val reply = hms.sendRequestWithRetry(
                            HMSRequestType.DataReport,
                            DataReportReq(hms.makeHeader(),records = reportList),
                            DataReportRsp.ADAPTER
                        )
                        if (reply.placeholder != null) {
                            withContext(hms.DBWrite) {
                                hms.databaseNoLog.reportLogQueries.deleteReportLogForSuccess(logs.map { it.report_id })
                            }
                        }
                    }
                } catch (exception: HMSException) {
                    hms.logger.e(TAG, exception) {
                        "init to send report log to wns failed"
                    }
                }
            } while (true)
        }
    }

    /***
     *
     * sqlite 慢查询和异常上报
     */
    fun reportSQLiteLog(
        sqliteLog: Operation
    ) {
        hms.hmsScope.launch {
            val appId = hms.appId
            val uid = hms.uid
            val ipAddress = getIpAddress()
            val deviceInfo = getDeviceInfo()
            val sdkVersion = getSdkVersion()
            val errorCode = if (sqliteLog.mException != null) "Exception" else "Normal"

            val data = CommonReportData(
                appId, uid, ipAddress,
                deviceInfo, sdkVersion, ReportEventID.SQLITE.value(),
                sqliteLog.mSql ?: "", com.tencent.hms.internal.timestamp(),
                sqliteLog.mEndTime - sqliteLog.mStartTime, errorCode,
                sqliteLog.mException.toString(), null, null, null
            )
            saveLog(data)
        }

    }

    private suspend fun saveLog(data: CommonReportData) {
        withContext(hms.DBWrite) {
            hms.databaseNoLog.transaction {
                hms.databaseNoLog.reportLogQueries.addReportLog(
                    data.appId,
                    data.uid,
                    data.ip,
                    data.deviceInfo,
                    data.sdkVersion,
                    ReportDataStatus.READY.value(),
                    data.eventId,
                    data.eventInfo,
                    timestamp(),
                    data.timeCost,
                    data.errorCode,
                    data.errorMessage
                )
            }
        }
        batchReportLate()
    }

    private suspend fun batchReportLate() {
        val list = hms.databaseNoLog.reportLogQueries.queryReportForSend(BATCH_REPORT_SIZE.toLong()).executeAsList()
        if (list.size <= BATCH_REPORT_SIZE) {
            return
        }
        withContext(hms.DBWrite) {
            hms.databaseNoLog.reportLogQueries.updateReportLogStatus(
                ReportDataStatus.SENDING.value(),
                list.map { it.report_id })
        }

        try {
            assertServerData {
                val reportList = list.map {
                    val map = mutableMapOf<String, String>()
                    map["report_id"] = it.report_id.toString()
                    map["app_id"] = it.app_id.toString()
                    map["uid"] = it.uid.toString()
                    map["device_info"] = it.device_info.pb
                    map["sdk_version"] = it.sdk_version.pb
                    map["send_status"] = it.send_status.toString().pb
                    map["event_id"] = it.event_id.toString().pb
                    map["event_info"] = it.event_info.toString().pb
                    map["timestamp"] = it.timestamp.toString().pb
                    map["time_cost"] = it.time_cost.toString().pb
                    map["error_code"] = it.error_code.toString().pb
                    map["error_message"] = it.error_message.toString().pb
                    map["ext1"] = it.ext1.toString().pb
                    map["ext2"] = it.ext2.toString().pb
                    map["ext3"] = it.ext3.toString().pb
                    DataReportReq.DataRecord(HMS_SQL_DC_NAME, map)
                }

                val reply = hms.sendRequestWithRetry(
                    HMSRequestType.DataReport,
                    DataReportReq(hms.makeHeader(),reportList),
                    DataReportRsp.ADAPTER
                )
                if (reply.placeholder != null) {
                    withContext(hms.DBWrite) {
                        hms.databaseNoLog.transaction {
                            hms.databaseNoLog.reportLogQueries.deleteReportLogForSuccess(list.map { it.report_id })
                        }
                    }
                }
            }
        } catch (exception: HMSException) {
            hms.logger.e(TAG, exception) {
                "batch report log to wns failed"
            }
        }

    }

}