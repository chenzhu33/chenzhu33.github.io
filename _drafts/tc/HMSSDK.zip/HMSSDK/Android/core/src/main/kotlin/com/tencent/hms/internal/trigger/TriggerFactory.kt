package com.tencent.hms.internal.trigger

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-07
 * Time:   20:52
 * Life with Passion, Code with Creativity.
 * ```
 */


/**
 * This class and sub classes are properly synchronized be [TriggerManager].
 */
internal sealed class TriggerFactory<T : Any>(
    protected val triggerManager: TriggerManager
) {
    abstract val type: TriggerManager.TriggerType

    abstract fun removeTrigger(trigger: Trigger<T>)
}

/**
 * For those one trigger type corresponding to one trigger instance.
 */
internal abstract class SingleInstanceTriggerFactory<T : Any>(
    triggerManager: TriggerManager
) : TriggerFactory<T>(triggerManager) {

    private var instance: Trigger<T>? = null

    fun obtain(): Pair<Boolean, Trigger<T>> {
        if (instance == null) {
            val ins = create(triggerManager)
            instance = ins
            return true to ins
        }
        return false to instance!!
    }

    override fun removeTrigger(trigger: Trigger<T>) {
        instance = null
    }

    abstract fun create(triggerManager: TriggerManager): Trigger<T>
}

/**
 * For those one trigger type corresponding to multiple trigger instance.
 */
internal abstract class MultiInstanceTriggerFactory<T : Any, InstanceKey>(
    triggerManager: TriggerManager
) : TriggerFactory<T>(triggerManager) {

    protected abstract class MultiInstanceTrigger<T : Any, InstanceKey>(triggerManager: TriggerManager) :
        Trigger<T>(triggerManager) {

        abstract val instanceKey: InstanceKey
    }

    private val instanceMap = mutableMapOf<InstanceKey, MultiInstanceTrigger<T, InstanceKey>>()

    /**
     * @return Pair of `isTrigger newly created (ie. needs install)` to `trigger instance`
     */
    fun obtain(vararg param: Any): Pair<Boolean, Trigger<T>> {
        val instanceKey = generateInstanceKey(*param)
        val ins = instanceMap[instanceKey]

        if (ins != null) {
            return false to ins
        }

        val newIns = create(instanceKey, triggerManager)
        instanceMap[instanceKey] = newIns

        return true to newIns
    }

    @Suppress("UNCHECKED_CAST")
    override fun removeTrigger(trigger: Trigger<T>) {
        instanceMap.remove((trigger as MultiInstanceTrigger<T, InstanceKey>).instanceKey)
    }

    abstract fun generateInstanceKey(vararg param: Any): InstanceKey

    protected abstract fun create(
        instanceKey: InstanceKey,
        triggerManager: TriggerManager
    ): MultiInstanceTrigger<T, InstanceKey>
}