package com.tencent.hms.message

import com.tencent.hms.HMSIllegalArgumentException

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-14
 * Time:   10:15
 * Life with Passion, Code with Creativity.
 * ```
 */

/**
 * HMS的消息索引，用于定位数据库中唯一的一个消息。
 * 因此这只是客户端本地已有消息的索引。
 * 用于对消息做 删除、查询、修改 动作。
 *
 */
data class HMSMessageIndex internal constructor(
    /**
     * 这个是SDK内部逻辑，一般业务无需了解。
     *
     * 如果一定要了解：
     * clientKey是HMS前后台统一算法生成的消息全局唯一ID，因此相同clientKey的消息会被后台当成同一个消息。
     * 比如如下场景：
     * 1. 客户端插入本地假消息 A
     * 2. 客户端处理完后，调用业务后台
     * 3. 业务后台发送真消息 A'
     *HMSMessageStatus
     * 此时客户端希望后台发送的真消息A'能覆盖客户端的假消息A。
     *
     * 通常情况下这个不能实现。借助clientKey可以这么实现：
     * 客户端第二步把A.clientKey发给后台，后台发真消息A'时，填写clientKey的时候直接使用A.clientKey（而不是再次生成一个）
     * 这样，A'发送成功之后，HMS会将其推送给客户端，客户端检查 clientKey 会找到A，因此将使用 A' 覆盖 A。
     */
    val clientKey: String,
    // extra
    internal val sid: String,
    internal val localSequence: Long,
    internal val helpSequence: Long,
    /**
     * 现在后台是用squence+sid来定位一条消息，而不是clientKey，所以需要将sequence暴露出来
     */
    val sequence: Long?
) : Comparable<HMSMessageIndex> {
    /**
     * this message is older than to `other`, ie. previous position in local order
     */
    fun olderThan(other: HMSMessageIndex): Boolean {
        return localSequence < other.localSequence ||
                (localSequence == other.localSequence && helpSequence < other.helpSequence)
    }

    /**
     * this message is newer than to `other`, ie. next position in local order
     */
    fun newerThan(other: HMSMessageIndex): Boolean {
        return localSequence > other.localSequence ||
                (localSequence == other.localSequence && helpSequence > other.helpSequence)
    }

    /**
     * this message is same as `other`, ie. same position in local order
     */
    fun sameAs(other: HMSMessageIndex): Boolean =
        localSequence == other.localSequence && helpSequence == other.helpSequence

    @Suppress("NOTHING_TO_INLINE")
    inline infix operator fun rangeTo(other: HMSMessageIndex): HMSMessageRange =
        HMSMessageRange(this, other)

    /**
     * newer in the front
     */
    override fun compareTo(other: HMSMessageIndex): Int {
        // newer is smaller
        return when {
            this.newerThan(other) -> -1
            this.olderThan(other) -> 1
            else -> 0
        }
    }

    // don't compare sequence
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is HMSMessageIndex) return false

        if (clientKey != other.clientKey) return false
        if (sid != other.sid) return false
        if (localSequence != other.localSequence) return false
        if (helpSequence != other.helpSequence) return false

        return true
    }

    // don't calculate sequence
    override fun hashCode(): Int {
        var result = clientKey.hashCode()
        result = 31 * result + sid.hashCode()
        result = 31 * result + localSequence.hashCode()
        result = 31 * result + helpSequence.hashCode()
        return result
    }

    fun toSimpleString() = "l:$localSequence h:$helpSequence s:$sequence sid:$sid"

    /**
     * serialize this instance into string format
     * @see deserializeFromString
     */
    fun serializeToString(): String =
        "[$clientKey|$sid|$localSequence|$helpSequence|$sequence]"

    companion object {
        /**
         * deserialize this instance from string format
         * @throws HMSIllegalArgumentException when string is invalid
         * @see serializeToString
         */
        @JvmStatic
        fun deserializeFromString(string: String): HMSMessageIndex {
            val split = string.trim('[', ']').split('|')
            try {
                if (split.size == 5) {
                    val clientKey = split[0]
                    val sid = split[1]
                    val localSequence = split[2].toLong()
                    val helpSequence = split[3].toLong()
                    val sequence = if (split[4] == "null") null else split[4].toLong()
                    return HMSMessageIndex(clientKey, sid, localSequence, helpSequence, sequence)
                }
            } catch (e: NumberFormatException) {
            }
            throw HMSIllegalArgumentException("can't deserializeFromString $string")
        }
    }
}

data class HMSMessageRange(
    /**
     * from new
     */
    val from: HMSMessageIndex,
    /**
     * to old
     */
    val to: HMSMessageIndex
) {
    fun contains(index: HMSMessageIndex): Boolean =
        index.sameAs(from) || index.sameAs(to) ||
                (index.olderThan(from) && index.newerThan(to))
}