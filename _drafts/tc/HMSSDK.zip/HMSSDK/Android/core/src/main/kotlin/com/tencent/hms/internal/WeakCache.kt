package com.tencent.hms.internal

import java.lang.ref.ReferenceQueue
import java.lang.ref.WeakReference


/*
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2019-03-08
 * Time:   17:00
 * Life with Passion, Code with Creativity.
 * </pre>
 *
 */

/**
 * copy and modified from afc-utils 😁
 */
internal open class WeakCache<K : Any, V : Any> {
    private val weakMap = HashMap<K, Entry<K, V>>()
    private var queue: ReferenceQueue<V> = ReferenceQueue()
    // when some value is for sure can't be created, add a placeholder.
    @Suppress("UNCHECKED_CAST")
    private val notPresent: V = Any() as V

    @Suppress("UNCHECKED_CAST")
    private fun cleanUpWeakMap() {
        var entry: WeakCache.Entry<K, V>? = queue.poll() as Entry<K, V>?
        while (entry != null) {
            weakMap.remove(entry.mKey)
            entry = queue.poll() as Entry<K, V>?
        }
    }

    @Suppress("NOTHING_TO_INLINE")
    private inline fun V?.strip() =
        if (this === notPresent) {
            null
        } else {
            this
        }

    @Synchronized
    fun put(key: K, value: V?): V? {
        cleanUpWeakMap()
        return weakMap.put(
            key,
            WeakCache.Entry(key, value ?: notPresent, queue)
        )?.get().strip()
    }

    @Synchronized
    operator fun get(key: K): V? {
        cleanUpWeakMap()
        var value = weakMap[key]?.get()
        if (value == null) {
            value = create(key)
            put(key, value ?: notPresent)
        }
        return value?.strip()
    }

    @Synchronized
    fun getAll(keys: List<K>): List<V> {
        cleanUpWeakMap()
        val allKeys = keys.toMutableList()
        val result = mutableListOf<V>()
        val it = allKeys.iterator()
        while (it.hasNext()) {
            val key = it.next()
            val value = weakMap[key]?.get()
            if (value != null) {
                it.remove()
                if (value !== notPresent) {
                    result.add(value)
                }
            }
        }

        if (allKeys.isNotEmpty()) {
            val new = createMany(allKeys)

            allKeys.forEach { key ->
                new[key]?.also { value ->
                    put(key, value)
                    result.add(value)
                } ?: put(key, notPresent)
            }
        }
        return result
    }

    @Synchronized
    fun remove(key: K): V? {
        cleanUpWeakMap()
        return weakMap.remove(key)?.get().strip()
    }

    @Synchronized
    fun evictAll() {
        weakMap.clear()
        queue = ReferenceQueue()
    }

    open fun create(key: K): V? =
        createMany(listOf(key)).values.firstOrNull()

    open fun createMany(keys: List<K>): Map<K, V> = emptyMap()

    private class Entry<K, V>(
        internal var mKey: K,
        value: V,
        queue: ReferenceQueue<V>
    ) : WeakReference<V>(value, queue) {
        override fun toString(): String {
            return "${get()}"
        }
    }
}
