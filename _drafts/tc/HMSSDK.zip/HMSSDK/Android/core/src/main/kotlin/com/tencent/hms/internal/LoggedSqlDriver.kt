package com.tencent.hms.internal

import com.squareup.sqldelight.Transacter
import com.squareup.sqldelight.db.SqlCursor
import com.squareup.sqldelight.db.SqlDriver
import com.squareup.sqldelight.db.SqlPreparedStatement
import com.tencent.hms.HMSCore
import com.tencent.hms.internal.report.OperationLog

/**
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2019-03-13
 * Time:   14:58
 * Life with Passion, Code with Creativity.
 * </pre>
 */
internal class LoggedSqlDriver(
    private val concreteDriver: SqlDriver,
    private val hms: HMSCore
) : SqlDriver {
    companion object {
        private const val TAG = "SqlDriver"
    }

    private val operationLog = OperationLog(hms.logger)

    override fun execute(identifier: Int?, sql: String, parameters: Int, binders: (SqlPreparedStatement.() -> Unit)?) {
        val operation = operationLog.beginOperation("execute", sql, binders)
        try {
            concreteDriver.execute(identifier, sql, parameters, binders)
        } catch (ex: Exception) {
            operationLog.failOperation(operation.mCookie, ex)
            throw ex
        } finally {
            operationLog.endOperation(operation.mCookie)
        }
    }

    override fun executeQuery(
        identifier: Int?,
        sql: String,
        parameters: Int,
        binders: (SqlPreparedStatement.() -> Unit)?
    ): SqlCursor {
        val operation = operationLog.beginOperation("query", sql, binders)
        try {
            return concreteDriver.executeQuery(identifier, sql, parameters, binders)
        } catch (ex: Exception) {
            operationLog.failOperation(operation.mCookie, ex)
            throw ex
        } finally {
            operationLog.endOperation(operation.mCookie)
        }

    }

    override fun close() {
        concreteDriver.close()
    }

    override fun currentTransaction(): Transacter.Transaction? {
        return concreteDriver.currentTransaction()
    }

    override fun newTransaction(): Transacter.Transaction {
        return concreteDriver.newTransaction().also {
            it.afterCommit {
                operationLog.asList().forEach {
                    //debug log
                    if (BuildConfig.DEBUG) {
                        val builder = StringBuilder()
                        it.describe(builder)
                        hms.logger.v(TAG, null) { builder.toString() }
                    }

                    if (operationLog.slowQueryOrException(it)) {
                        hms.reportLogManager.reportSQLiteLog(it)
                    }
                }
            }
        }
    }
}