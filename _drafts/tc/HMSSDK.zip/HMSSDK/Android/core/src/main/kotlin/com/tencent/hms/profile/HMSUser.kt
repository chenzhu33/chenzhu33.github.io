package com.tencent.hms.profile

import com.tencent.hms.HMSSerializer
import com.tencent.hms.internal.pb
import com.tencent.hms.internal.protocol.PermissionType
import com.tencent.hms.internal.protocol.User
import com.tencent.hms.internal.protocol.UserInSession
import com.tencent.hms.internal.repository.model.UserDB
import com.tencent.hms.internal.repository.model.UserInSessionDB

/**
 * Created by juliandai on 2019/1/29 10:47 AM.
 * talk and show the code
 */

/**
 * 用户信息
 */
data class HMSUser internal constructor(
    /**
     * 用户id
     */
    val uid: String,
    /**
     * 用户名
     */
    val name: String?,
    /**
     * 用户头像
     */
    val avatar: String?,
    /**
     * 用户备注
     */
    val remark: String?,
    /**
     * 用户信息更新时间戳
     * unix 时间戳，单位毫秒
     */
    val timestamp: Long,
    /**
     * 业务数据
     */
    val businessBuffer: Any?
) {
    companion object {
        internal fun fromDB(user: UserDB, serializer: HMSSerializer): HMSUser {
            return HMSUser(
                user.uid,
                user.name,
                user.avatar_url,
                user.remarks,
                user.update_timestamp.pb,
                user.busi_buff?.let { serializer.deserializeUserBusinessBuffer(it) }
            )
        }

        internal fun fromNet(user: User, serializer: HMSSerializer): HMSUser {
            return HMSUser(
                user.uid!!,
                user.name,
                user.avatarUrl,
                user.remark,
                user.updateTimestamp.pb,
                user.businessBuffer?.let { serializer.deserializeUserBusinessBuffer(it.toByteArray()) }
            )
        }

        internal fun fake(uid: String): HMSUser {
            return HMSUser(
                uid,
                null,
                null,
                null,
                0L,
                null
            )
        }
    }
}

/**
 * 用户在一个会话中的信息，同一个用户在不同会话会有不同的 [HMSUserInSession] 数据
 */
data class HMSUserInSession internal constructor(
    /**
     * 用户id
     */
    val uid: String,
    /**
     * 用户所在会话id
     */
    val sid: String,
    /**
     * 用户在会话中的"群名片"
     */
    val remark: String?,
    /**
     * 业务数据
     */
    val businessBuffer: Any?,
    /**
     * 用户加入会话的时间
     * unix 时间戳，单位毫秒
     */
    val joinTimestamp: Long,
    /**
     * 用户在会话中的信息最近更新时间
     * unix 时间戳，单位毫秒
     */
    val updateTimestamp: Long,
    /**
     * 用户在会话中的角色
     */
    val role: HMSUserRole,
    /**
     * 用户被禁言到该时间点为止（即：在该时间点之前都是禁言状态）
     * unix 时间戳，单位毫秒
     * 0 表示未禁言
     */
    val banExpireTime: Long

) {
    companion object {
        internal fun fromNet(userInSession: UserInSession, serializer: HMSSerializer): HMSUserInSession {
            return HMSUserInSession(
                userInSession.uid!!,
                userInSession.sid!!,
                userInSession.remarks,
                userInSession.businessBuffer?.let { serializer.deserializeUserBusinessBuffer(it.toByteArray()) },
                userInSession.joinTimestamp.pb,
                userInSession.updateTimestamp.pb,
                HMSUserRole.fromProtocol(userInSession.permission ?: PermissionType.OrdinaryMember),
                userInSession.banExpirationTimestamp.pb
            )
        }

        fun fromDB(userInSession: UserInSessionDB, serializer: HMSSerializer): HMSUserInSession {
            return HMSUserInSession(
                userInSession.uid,
                userInSession.sid,
                userInSession.remarks,
                userInSession.busi_session_buff?.let { serializer.deserializeUserBusinessBuffer(it) },
                userInSession.join_timestamp,
                userInSession.update_timestamp.pb,
                HMSUserRole.fromProtocol(
                    PermissionType.fromValue(userInSession.role?.toInt().pb)
                ),
                userInSession.ban_expire_time.pb
            )
        }
    }
}

/**
 * 用户在 Session 中的资料，组合了 [HMSUser] 和 [HMSUserInSession]
 * @see HMSUser
 * @see HMSUserInSession
 */
data class HMSMemberInfo internal constructor(
    /**
     * @see HMSUser
     */
    val user: HMSUser,
    /**
     * @see HMSUserInSession
     */
    val userInSession: HMSUserInSession?
) {
    companion object {
        internal fun fromNet(user: User, userInSession: UserInSession?, serializer: HMSSerializer): HMSMemberInfo {
            return HMSMemberInfo(
                HMSUser.fromNet(user, serializer),
                if (userInSession != null) HMSUserInSession.fromNet(userInSession, serializer) else null
            )
        }

        internal fun fromDB(user: UserDB, userInSession: UserInSessionDB?, serializer: HMSSerializer): HMSMemberInfo {
            return HMSMemberInfo(
                HMSUser.fromDB(user, serializer),
                if (userInSession != null) HMSUserInSession.fromDB(userInSession, serializer) else null
            )
        }

        internal fun fake(uid: String): HMSMemberInfo {
            return HMSMemberInfo(HMSUser.fake(uid), null)
        }
    }

    /**
     * util方法获取用户在session中的名字，业务侧不一定调用这个方法，可以有自己的逻辑去获取。
     * 该方法只是针对通用场景下的一个便捷操作。
     *
     * 获取算法：[用户备注](HMSUser.remark]) > [群名片](HMSUserInSession.remark) > [用户昵称](HMSUser.name) > [用户id](HMSUser.uid)
     */
    val nameInSession: String
        get() = user.remark ?: userInSession?.remark ?: user.name ?: user.uid


}


internal fun User.isValid(): Boolean {
    return !this.uid.isNullOrEmpty()
}

internal fun UserInSession.isValid(): Boolean {
    return !this.uid.isNullOrEmpty() && !this.sid.isNullOrEmpty()
}

