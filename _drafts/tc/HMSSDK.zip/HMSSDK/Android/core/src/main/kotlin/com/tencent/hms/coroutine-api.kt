package com.tencent.hms

import com.tencent.hms.internal.*
import com.tencent.hms.internal.protocol.ControlElement
import com.tencent.hms.internal.protocol.Message
import com.tencent.hms.internal.protocol.MessageElement
import com.tencent.hms.internal.repository.HMSDatabase
import com.tencent.hms.message.*
import com.tencent.hms.profile.HMSUserRole
import com.tencent.hms.session.HMSMessageAlertType
import com.tencent.hms.session.HMSSession
import kotlinx.coroutines.withContext

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-16
 * Time:   11:22
 * Life with Passion, Code with Creativity.
 * ```
 */

/**
 * 初始化 HMS，创建一个HMS的实例
 * @param arguments 初始化参数，详见 [HMSCore.InitializeArguments]
 */
suspend fun HMSCore.Companion.initialize(
    arguments: HMSCore.InitializeArguments
): HMSCore {
    val executors = HMSExecutors(arguments.executorDelegate)
    return withContext(executors.Worker) {
        HMSCore(
            arguments.appId,
            arguments.uid,
            arguments.networkTransfer,
            arguments.sqlDriverFactory.createSqlDriver(
                HMSDatabase.Schema,
                "hms_database_${arguments.appId}_${arguments.uid}".toUrlString()
            ),
            executors,
            arguments.serializer,
            HMSLogger(arguments.logDelegate),
            arguments.isEmptyC2CSessionShow
        ).apply {
            initialize()
        }
    }
}


/** MARK: expose methods of [SessionManager] */

/**
 * 创建会话
 */
suspend fun HMSCore.createSession(
    type: HMSSession.Type,
    users: List<String>,
    name: String? = null,
    avatar: String? = null,
    businessBuffer: Any? = null
    ) = withContext(Worker) {
    sessionManager.createSessionIfNotExist(
        type.toProtocol(),
        users,
        name,
        avatar,
        businessBuffer?.let { serializer.serializeSessionBusinessBuffer(it) }?.toByteString()
    )
}

/**
 * 通过对方的uid，获得C2C会话
 */
suspend fun HMSCore.getC2CSession(toUid: String): HMSSession = withContext(Worker) {
    sessionManager.getC2CSession(toUid)
}

/**
 * 标记会话已读，更新未读计数
 */
suspend fun HMSCore.setSessionRead(
    sid: String
) = withContext(Worker) {
    sessionManager.setSessionRead(sid)
}

/**
 * 设置session extension 自定义数据
 */
suspend fun HMSCore.updateSessionExtension(
    sid: String,
    extension: Any?
) = withContext(Worker) {
    sessionManager.updateSessionExtension(sid, extension)
}

/**
 * 更新session info
 * name, avatar, businessBuffer 三个字段可以任意更新其中几个。
 * 对于不需要更新的字段可以使用 [STRING_PLACEHOLDER], [ANY_PLACEHOLDER] 占位，或者使用Kotlin的函数默认值。
 */
suspend fun HMSCore.updateSessionInfo(
    sid: String,
    name: String? = STRING_PLACEHOLDER,
    avatar: String? = STRING_PLACEHOLDER,
    businessBuffer: Any? = ANY_PLACEHOLDER
) = withContext(Worker) {
    sessionManager.updateSessionInfo(
        sid,
        name,
        avatar,
        if (businessBuffer === ANY_PLACEHOLDER) {
            BYTE_ARRAY_PLACEHOLDER
        } else {
            businessBuffer?.let { serializer.serializeSessionBusinessBuffer(it) }
        }
    )
}

/**
 * 拉取session info，本地没有的从服务端拉取补齐
 */
suspend fun HMSCore.getSessionListBySid(
    sids: List<String>,
    withCount: Boolean = false,
    withMsg: Boolean = false
) = withContext(Worker) {
    sessionManager.getSessionListBySids(sids, withCount, withMsg)
}

/**
 * 强制刷新会话列表
 */
suspend fun HMSCore.syncSessionList() = withContext(Worker) {
    sessionManager.init()
}

/**
 * 更新C2C好友关系链
 */
suspend fun HMSCore.updateSessionFriendType(toUid: String, friendType: Int) = withContext(Worker) {
    sessionManager.updateSessionFriendType(toUid, friendType)
}

/**
 * 往群组中加人
 * 1. 邀请人进群组时填写被邀请人的uid
 * 2. 主动加入群组时，填写自己的uid
 */
suspend fun HMSCore.addUserToSession(
    sessionId: String,
    uids: List<String>
) = withContext(Worker) {
    sessionManager.addUserToSession(sessionId, uids)
}

/**
 * 从服务端最近列表中删除会话，之前的消息都无法拉取到
 */
suspend fun HMSCore.deleteSession(sid: String) =
    sessionManager.deleteSession(sid)

/**
 * 删除本地session, 仅删除本地记录，当该session有新的消息时，会再次出现在 [HMSSessionListLogic] 中
 * 如需退出会话，使用 [quitSession]
 */
suspend fun HMSCore.deleteLocalSession(sid: String) =
    sessionManager.deleteLocalSession(sid)

/**
 * 从群组中退出
 */
suspend fun HMSCore.quitSession(
    sessionID: String
) = withContext(Worker) {
    sessionManager.quitSession(sessionID)
}

/**
 * 删除群组中某个成员
 */
suspend fun HMSCore.deleteSessionMember(
    sid: String,
    uids: List<String>
) = withContext(Worker) {
    sessionManager.deleteSessionMember(sid, uids)
}


/**
 * 解散群,只有群主有此功能
 */
suspend fun HMSCore.destroySession(
    sessionID: String
) = withContext(Worker) {
    sessionManager.destroySession(sessionID)
}

/**
 * 删除session的本地消息（不影响server和其他终端）
 */
suspend fun HMSCore.deleteSessionMessages(
    sessionID: String
) = withContext(DBWrite) {
    sessionManager.deleteSessionMessages(sessionID)
}

/**
 * 更新会话的消息提醒类型
 */
suspend fun HMSCore.changeSessionMessageAlertType(
    sessionId: String,
    messageAlertType: HMSMessageAlertType
) = withContext(Worker) {
    sessionManager.changeSessionMessageAlertType(sessionId, messageAlertType)
}

/**
 * 更新群名片
 * remark, businessBuffer 字段可以任意更新其中几个。
 * 对于不需要更新的字段可以使用 [STRING_PLACEHOLDER], [ANY_PLACEHOLDER] 占位，或者使用Kotlin的函数默认值。
 */
suspend fun HMSCore.updaterUserInSession(
    sessionID: String,
    uid: String,
    remark: String? = STRING_PLACEHOLDER,
    businessBuffer: Any? = ANY_PLACEHOLDER
) = withContext(Worker) {
    sessionManager.updaterUserInSession(
        sessionID, uid, remark,
        if (businessBuffer === ANY_PLACEHOLDER) {
            BYTE_ARRAY_PLACEHOLDER
        } else {
            businessBuffer?.let { serializer.serializeUserInSessionBusinessBuffer(it) }
        }
    )
}


/**
 * 禁言
 */
suspend fun HMSCore.updateSessionBannedStatus(
    sid: String,
    uid: String,
    duringTimeOfBan: Long
) {
    withContext(Worker) {
        userManager.updateSessionBannedStatus(sid, uid, duringTimeOfBan)
    }
}

/**
 * 权限
 */
suspend fun HMSCore.updateRoleInSession(
    sid: String,
    uid: String,
    role: HMSUserRole
) {
    withContext(Worker) {
        userManager.updateSessionPermission(sid, uid, role.toProtocol())
    }
}

/**
 * 转让群主
 */
suspend fun HMSCore.transferSessionOwner(
    sid: String,
    toUid: String
) {
    withContext(Worker) {
        userManager.transferSessionOwner(sid, toUid)
    }
}

/**
 * 黑名单
 */
suspend fun HMSCore.getBlackList() = withContext(Worker) {
    sessionManager.getBlackList().userIDList
}

suspend fun HMSCore.addToBlackList(
    toUid: String
) {
    withContext(Worker) {
        sessionManager.addToBlackList(toUid)
    }
}

suspend fun HMSCore.removeFromBlackList(
    toUid: String
) {
    withContext(Worker) {
        sessionManager.removeFromBlackList(toUid)
    }
}

/** MARK: expose methods of [MessageSendManager] */

/**
 *
 * 将普通消息插入本地存储，并发送至server。
 * 消息插入本地存储之后就会立即在 [HMSMessageListLogic] 中出现，
 * 即便消息发送失败（如无网络），消息也能够呈现在UI上，业务侧可以通过 [sendLocalMessage] 重试发送。
 *
 * @param text 消息的文本，其中的文字及url会被后台的安全策略扫描打击
 * @param pushText 离线push的文本，默认使用text，当业务需要特殊的离线push文本，可以填写该字段
 * @param type 消息的类型，由上层指定，HMS透传，一个type对应一种payload
 * @param payload 消息的负载，会发送到server，并同步到各终端
 * @param extension 消息的本地扩展，只会存在本地，不会发送到server
 * @param reminds 消息提醒哪些用户看（即 "at" 逻辑）
 * @param isNeedClearRedPoint 客户端发送消息的时候，是否需要将该会话的所有消息置为已读，默认为true
 *
 * @see HMSPlainMessage
 * @see HMSMessageIndex
 */
suspend fun HMSCore.sendMessage(
    sessionId: String,
    type: Int,
    text: String,
    pushText: String?,
    payload: Any?,
    reminds: List<String>,
    extension: Any?,
    isNeedClearRedPoint: Boolean = true
): HMSMessageIndex = withContext(Worker) {
    messageSendManager.saveAndSendMessage(
        sessionId,
        type,
        text,
        pushText,
        payload?.let { serializer.serializeMessagePayload(type, payload) },
        if (reminds.isNotEmpty()) {
            Message.Reminds(reminds)
        } else {
            null
        },
        extension?.let { serializer.serializeMessageExtension(it) },
        isNeedClearRedPoint
    )
}

/**
 * 撤回一个已经发送出去的消息，当一个消息被撤回后，其[HMSMessage.isRevoked]为true
 * @param messageIndex 要更新的消息的index，该消息的状态必须是 [HMSMessageStatus.SUCCESS]，即必须是一个服务端存在的消息
 * @throws HMSIllegalArgumentException **当 messageIndex 的消息是一个本地消息时 （只能revoke一个server消息），该调用必然失败！**
 */
suspend fun HMSCore.revokeMessage(messageIndex: HMSMessageIndex) = withContext(Worker) {
    val sequence = messageIndex.sequence
        ?: database.messageDBQueries.queryMessageIndex(messageIndex.clientKey).executeAsOneOrNull()?.sequence
        ?: throw HMSIllegalArgumentException("messageIndex is for local message, can't be used to revoke")

    messageSendManager.sendMessageToServer(
        messageIndex.sid,
        -1,
        "revoke message ${messageIndex.sid} ${messageIndex.sequence}",
        null,
        MessageElement(
            MessageElement.Element.Control(
                ControlElement(
                    ControlElement.Control.Revoke(
                        ControlElement.ControlRevokeElement(
                            revokedMessageSequence = sequence
                        )
                    )
                )
            )
        ),
        null,
        true
    )
}


/**
 * 更新一个已经发送出去的消息。
 *
 * 与 [updateLocalMessage] 不同，该请求会更新后台消息，并将新的消息内容推送到各个用户。
 *
 * @param messageIndex 要更新的消息的index，该消息的状态必须是 [HMSMessageStatus.SUCCESS]，即必须是一个服务端存在的消息
 * @param type 更新到新的type
 * @param text 更新新的消息文本
 * @param payload 更新新的消息payload
 *
 * @throws HMSIllegalArgumentException **当 messageIndex 的消息是一个本地消息时 （只能update一个server消息），该调用必然失败！**
 */
suspend fun HMSCore.updateMessage(
    messageIndex: HMSMessageIndex,
    type: Int,
    text: String,
    payload: Any?
) = withContext(Worker) {
    val sequence = messageIndex.sequence
        ?: database.messageDBQueries.queryMessageIndex(messageIndex.clientKey).executeAsOneOrNull()?.sequence
        ?: throw HMSIllegalArgumentException("messageIndex is for local message, can't be used to update")

    messageSendManager.sendMessageToServer(
        messageIndex.sid,
        -1,
        "update message ${messageIndex.sid} ${messageIndex.sequence}",
        null,
        MessageElement(
            MessageElement.Element.Control(
                ControlElement(
                    ControlElement.Control.Update(
                        ControlElement.ControlUpdateElement(
                            updatedMessageSequence = sequence,
                            updateContent = ControlElement.ControlUpdateElement.Update(
                                type = type,
                                text = text,
                                payload = payload?.let {
                                    serializer.serializeMessagePayload(type, it).toByteString()
                                }
                            )
                        )
                    )
                )
            )
        ),
        null,
        true
    )
}

/**
 * 参数含义详见 [sendMessage]
 */
suspend fun HMSCore.addLocalMessage(
    sessionId: String,
    type: Int,
    text: String,
    pushText: String?,
    payload: Any?,
    reminds: List<String>,
    extension: Any?
): HMSMessageIndex = withContext(Worker) {
    messageSendManager.addLocalMessage(
        sessionId,
        type,
        text,
        pushText,
        payload?.let { serializer.serializeMessagePayload(type, payload) },
        if (reminds.isNotEmpty()) {
            Message.Reminds(reminds)
        } else {
            null
        },
        extension?.let { serializer.serializeMessageExtension(it) }
    )
}


/**
 * 主要针对发送的消息消息进行重发逻辑
 * 或发送[addLocalMessage]的本地消息
 * @param isNeedClearRedPoint 客户端发送消息的时候，是否需要将该会话的所有消息置为已读，默认为true
 */
suspend fun HMSCore.sendLocalMessage(
    index: HMSMessageIndex,
    isNeedClearRedPoint: Boolean = true
): HMSMessageIndex {
    withContext(Worker) {
        messageSendManager.sendLocalMessage(index, isNeedClearRedPoint)
    }
    return index
}

/**
 * 将消息从本地存储中删除，然后重新插入到本地存储的最后（最新一个消息），然后重新发送。
 * 主要针对发送失败的消息进行重发逻辑。
 * 该方法会导致重发的消息重新排序到最新的一条消息。
 * @param isNeedClearRedPoint 客户端发送消息的时候，是否需要将该会话的所有消息置为已读，默认为true
 */
suspend fun HMSCore.deleteAndResendLocalMessage(
    index: HMSMessageIndex,
    isNeedClearRedPoint: Boolean = true
): HMSMessageIndex = withContext(Worker) {
    messageSendManager.deleteAndResendLocalMessage(index, isNeedClearRedPoint)
}

/**
 * 查询本地database中的消息，可以是[addLocalMessage]消息，也可以是server上同步下来的消息。
 *
 * Anything in the database。
 */
suspend fun HMSCore.queryLocalMessage(
    index: HMSMessageIndex
): HMSMessage = withContext(Worker) {
    messageSendManager.queryLocalMessage(index)
        ?.let { HMSMessage.fromDB(it, this@queryLocalMessage) }
        ?: throw HMSMessageNotFoundException("message $index not found")
}

/**
 * 删除database中的**任何**一条消息，可以是自己的，也可以是别人的
 *
 * @see queryLocalMessage
 */
suspend fun HMSCore.deleteLocalMessage(
    index: HMSMessageIndex
): Unit = messageSendManager.markLocalMessageDeleted(index)


/**
 * 更新database中的消息，可以是自己的，也可以是别人的
 * 参数分别对应 [HMSPlainMessage] 中的字段
 * 允许部分更新 type, text, pushText, payload, reminds, extension 中的任意一到多个。
 * 需要更新的字段参数传入其最新值，不需要更新的字段使用 [STRING_PLACEHOLDER] 等一系列占位符标记即可。
 *
 * 注意：**当需要更新[HMSPlainMessage.payload]的时候，需要传入正确的type（不能是[INT_PLACEHOLDER]，也就是 `null`).**
 *
 * 对于Kotlin的用户，建议使用命名参数，如：
 * ```
 * hmsCore.updateLocalMessage(index = messageIndex, text = "new message")
 * ```
 * 可使代码尽量简洁。
 *
 * @param extension 对应 [HMSMessage.extension]
 *
 */
suspend fun HMSCore.updateLocalMessage(
    index: HMSMessageIndex,
    type: Int? = INT_PLACEHOLDER,
    text: String = STRING_PLACEHOLDER,
    pushText: String? = STRING_PLACEHOLDER,
    payload: Any? = ANY_PLACEHOLDER,
    reminds: List<String> = LIST_PLACEHOLDER(),
    extension: Any? = ANY_PLACEHOLDER
): HMSMessageIndex {
    messageSendManager.updateLocalMessage(
        index,
        type,
        text,
        pushText,
        payload,
        reminds,
        extension
    )
    return index
}

/** MARK: expose methods of [UserManager] */

/**
 * 修改用户资料
 *
 * name, avatar, businessBuffer 三个字段可以任意更新其中几个。
 * 对于不需要更新的字段可以使用 [STRING_PLACEHOLDER], [ANY_PLACEHOLDER] 占位，或者使用Kotlin的函数默认值。
 *
 */
suspend fun HMSCore.updateUserInfo(
    uid: String,
    name: String? = STRING_PLACEHOLDER,
    avatar: String? = STRING_PLACEHOLDER,
    businessBuffer: Any? = ANY_PLACEHOLDER
) = withContext(Worker) {
    userManager.updateUserInfo(
        uid,
        name,
        avatar,
        if (businessBuffer === ANY_PLACEHOLDER) {
            BYTE_ARRAY_PLACEHOLDER
        } else {
            businessBuffer?.let { serializer.serializeUserBusinessBuffer(it) }
        })
}


/**
 * 获得用户资料
 *
 */
suspend fun HMSCore.getUsers(uids: List<String>) =
    withContext(Worker) {
        userManager.getUsers(uids)
    }

/**
 * 获得user profile and useInSession profile
 */
suspend fun HMSCore.getUsersMemberInfo(
    sessionId: String,
    uids: List<String>
) = withContext(Worker) {
    userManager.pullUsersMemberInfo(sessionId, uids)
}


/**
 * 在线获得session 所有成员列表
 */
suspend fun HMSCore.getSessionMemberList(
    sessionID: String
) = withContext(Worker) {
    userManager.getSessionMemberList(sessionID)
}

// MARK: utils
internal fun <T : Any> HMSCore.unwrapCoroutine(
    callback: HMSDisposableCallback<HMSResult<T>>?,
    block: suspend () -> T
) {
    hmsScope.unwrapCoroutine(Main, callback, block)
}

