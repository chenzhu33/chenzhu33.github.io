package com.tencent.hms.test.mock

import com.tencent.hms.HMSLogDelegate

/**
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-23
 * Time:   11:46
 * Life with Passion, Code with Creativity.
 * </pre>
 */

class Logger:HMSLogDelegate {
    override fun log(level: HMSLogDelegate.LogLevel, tag: String, message: String, throwable: Throwable?) {
    }

    override val verbose: Boolean
        get() = false
}
