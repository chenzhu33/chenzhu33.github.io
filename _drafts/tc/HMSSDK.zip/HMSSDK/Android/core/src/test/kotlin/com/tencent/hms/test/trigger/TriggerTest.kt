
import com.tencent.hms.HMSDisposableCallback
import com.tencent.hms.internal.repository.model.Session_table_log
import com.tencent.hms.internal.timestamp
import com.tencent.hms.internal.trigger.TriggerManager
import com.tencent.hms.test.db.DbTestHelper
import org.junit.Test

class TriggerTest : DbTestHelper() {
    @Test
    fun globalMessage() {
        lateinit var triggeredList: List<Session_table_log>
        val listener = HMSDisposableCallback { list: List<Session_table_log> ->
            triggeredList = list
        }
        triggerManager.registerTriggerCallback(
            TriggerManager.TriggerType.SESSION,
            listener
        )

        database.sessionDBQueries.insertSession(
            "1",
            1L,
            "",
            "session_name",
            "",
            1,
            1,
            1, 1,
            null,
            null,
            timestamp(),
            timestamp(), timestamp()
        )

       // Assert.assertTrue(triggeredList[0].run { sessionId == "sessionId" })

        // un listen
        listener.dispose()

    }

    @Test
    fun testSessionSequenceUpdateTrigger() {
        val sid = "123123"
        var session = database.sessionDBQueries.querySessionBySids(listOf(sid)).executeAsOneOrNull()
        if (session == null) {
            database.sessionDBQueries.insertSession(
                sid,
                1,
                "name",
                null,
                null,
                0,
                0,
                1,
                0,
                null,
                null,
                timestamp(),
                timestamp(),
                timestamp()
            )
        }
        session = database.sessionDBQueries.querySessionBySids(listOf(sid)).executeAsOneOrNull()
        //assert(session != null && session.sid == sid)

        val clientKey = "client-key" + timestamp()
        database.messageDBQueries.insertLocalMessage(
            sid,
            timestamp(),
            "linxhome",
            1,
            1,
            "text",
            "push",
            byteArrayOf(),
            null,
            clientKey,
            0,
            null
        )
        val sequence = 2L
        database.messageDBQueries.updateMessageInfoByClientKey(
            1,
            1,
            0,
            0,
            false,
            false,
            "",
            null,
            null,
            sequence,
            0,
            0,
            "client_key"
        )

        session = database.sessionDBQueries.querySessionBySids(listOf(sid)).executeAsOneOrNull()
        session?.let {
            assert(it.max_sequence == sequence)
        }
        //assert(session != null && session.sid == sid)
    }

    @Test
    fun getSessionTriggerWhenNewMsgCome() {
        triggerManager.registerTriggerCallback(
            TriggerManager.TriggerType.SESSION,
            HMSDisposableCallback<List<Session_table_log>> { list ->
                val sids = mutableListOf<String>()
                list.forEach {
                    sids.add(it.sid)
                }
            }
        )

        val sid = "12312"

//        database.sessionDBQueries.insertSession(
//            sid,
//            1,
//            "name",
//            null,
//            "12312",
//            12,
//            2,
//            0,
//            null,
//            timestamp(),
//            timestamp(),
//            timestamp()
//        )
//
//        database.messageDBQueries.insertMessage(
//            sid,
//            timestamp(),
//            "sender haha",
//            1,
//            false,
//            false,
//            "",
//            null,
//            null,
//            1,
//            1,
//            "client key",
//            1,
//            -1
//        )

        Thread.sleep(3000)

    }

    @Test
    fun testCompare() {

        val list = mutableListOf<Person>()
        list.add(Person(2))
        list.add(Person(9))
        list.add(Person(5))
        list.sort()
        list.forEach {
            println(it.age)
        }
    }

    class Person(val age: Int) : Comparable<Person> {
        override fun compareTo(other: Person): Int {
            return other.age - this.age
        }

    }

    @Test
    fun testExcelude() {
        val list = listOf<Int>(1, 2, 3)
        println(list.subList(0, 3))
    }


}