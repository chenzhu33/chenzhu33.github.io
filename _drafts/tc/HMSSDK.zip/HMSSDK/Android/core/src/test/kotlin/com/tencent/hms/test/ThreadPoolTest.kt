package com.tencent.hms.test

import org.junit.Assert
import org.junit.Test
import java.util.concurrent.*

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-03-09
 * Time:   22:41
 * Life with Passion, Code with Creativity.
 * ```
 */

class ThreadPoolTest {
    @Test
    fun t() {
        val executors = ThreadPoolExecutor(
            3, 10,
            1000_100, TimeUnit.DAYS,
            LinkedBlockingQueue<Runnable>()
        )
        Assert.assertEquals(0, executors.poolSize)

        val wait = CountDownLatch(2)
        executors.submit { wait.countDown() }
        Assert.assertEquals(1, executors.poolSize)

        executors.submit { wait.countDown() }
        Assert.assertEquals(2, executors.poolSize)

        wait.await()
        Assert.assertEquals(0, executors.activeCount)
        // two core thread sleeps, but it still will add core thread
        executors.submit { Thread.sleep(100) }
        Assert.assertEquals(3, executors.poolSize)

        // queue offer always success, thus no more worker-thread is added
        executors.submit { }
        executors.submit { }
        executors.submit { }
        Assert.assertEquals(3, executors.poolSize)

        executors.shutdownNow()
    }

    @Test
    fun tt() {
        val executors = ThreadPoolExecutor(
            0, 1,
            1000_100, TimeUnit.DAYS,
            LinkedBlockingQueue<Runnable>()
        )
        Assert.assertEquals(0, executors.poolSize)

        executors.submit { Thread.sleep(100) }
        Assert.assertEquals(1, executors.poolSize)
        executors.shutdownNow()
    }

    @Test
    fun ttt() {
        val blockingQueue = object : LinkedBlockingQueue<Runnable>() {
            override fun offer(e: Runnable?): Boolean {
                return if (isNotEmpty()) {
                    // all works are busy, try to add new workers
                    false
                } else {
                    super.offer(e)
                }
            }

            fun offerUnlimited(e: Runnable?) {
                super.offer(e)
            }
        }
        val executors = ThreadPoolExecutor(
            3, 10,
            1, TimeUnit.DAYS,
            blockingQueue, RejectedExecutionHandler { r, _ ->
                blockingQueue.offerUnlimited(r)
            }
        )

        Assert.assertEquals(0, executors.poolSize)

        val wait = CountDownLatch(1)
        executors.submit { wait.await() }
        Assert.assertEquals(1, executors.poolSize)

        executors.submit { wait.await() }
        Assert.assertEquals(2, executors.poolSize)

        wait.countDown()
        Assert.assertEquals(2, executors.poolSize)
        // two core thread sleeps, but it still will add core thread
        executors.submit { Thread.sleep(100) }
        Assert.assertEquals(3, executors.poolSize)

        repeat(3) { executors.submit { Thread.sleep(100) } }
        Assert.assertTrue(executors.poolSize > 3)
        repeat(10) { executors.submit { Thread.sleep(100) } }
        // max thread count is 10
        Assert.assertEquals(10, executors.poolSize)
        executors.shutdownNow()
    }


    @Test
    fun tttt() {
        val blockingQueue = object : LinkedTransferQueue<Runnable>() {

            override fun offer(e: Runnable): Boolean {
                return tryTransfer(e)
            }

            fun offerUnlimited(e: Runnable?) {
                super.offer(e)
            }
        }

        val executors = ThreadPoolExecutor(
            3, 10,
            1, TimeUnit.DAYS,
            blockingQueue, RejectedExecutionHandler { r, _ ->
                blockingQueue.offerUnlimited(r)
            }
        )

        Assert.assertEquals(0, executors.poolSize)

        val wait = CountDownLatch(1)
        executors.submit { wait.await() }
        Assert.assertEquals(1, executors.poolSize)

        executors.submit { wait.await() }
        Assert.assertEquals(2, executors.poolSize)

        wait.countDown()
        Assert.assertEquals(2, executors.poolSize)
        // two core thread sleeps, but it still will add core thread
        executors.submit { Thread.sleep(100) }
        Assert.assertEquals(3, executors.poolSize)

        repeat(3) { executors.submit { Thread.sleep(100) } }
        Assert.assertTrue(executors.poolSize > 3)
        repeat(10) { executors.submit { Thread.sleep(100) } }
        // max thread count is 10
        Assert.assertEquals(10, executors.poolSize)
        executors.shutdownNow()
    }


    @Test
    fun mmm() {
        val unreadCache = ConcurrentHashMap<String, Long>()
        unreadCache.put("1",2)
        unreadCache.put("2",323)
        println("dfdf${unreadCache}")
    }
}