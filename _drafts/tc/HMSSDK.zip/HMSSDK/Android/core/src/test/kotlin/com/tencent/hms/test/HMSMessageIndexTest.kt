package com.tencent.hms.test

import com.tencent.hms.internal.message.MessageReceiveManager
import com.tencent.hms.internal.repository.model.New_message_table_write_log
import com.tencent.hms.message.HMSMessageIndex
import org.junit.Assert
import org.junit.Test

/**
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2019-03-12
 * Time:   15:55
 * Life with Passion, Code with Creativity.
 * </pre>
 */
class HMSMessageIndexTest {
    @Test
    fun serialize() {
        val first = HMSMessageIndex(
            "xxx_ooo",
            "g_100",
            10,
            20,
            30
        )
        Assert.assertEquals(first, HMSMessageIndex.deserializeFromString(first.serializeToString()))


        val second = HMSMessageIndex(
            "xxx_ooo_111_000",
            "g_101",
            42,
            84,
            null
        )
        Assert.assertEquals(second, HMSMessageIndex.deserializeFromString(second.serializeToString()))

    }

    @Test
    fun newMessageRanges() {
        val log = listOf(
            New_message_table_write_log.Impl(123, "", ""),
            New_message_table_write_log.Impl(123, "", ""),
            New_message_table_write_log.Impl(124, "", "")
        )

        val ranges = MessageReceiveManager.getRanges(log)

        Assert.assertEquals(listOf(123L..123L, 124L..124L), ranges)

    }
}