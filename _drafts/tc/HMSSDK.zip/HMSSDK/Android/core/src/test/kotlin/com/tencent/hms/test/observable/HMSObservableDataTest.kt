package com.tencent.hms.test.observable

import com.tencent.hms.HMSExecutorDelegate
import com.tencent.hms.HMSObservableData
import com.tencent.hms.internal.HMSExecutors
import org.junit.Assert
import org.junit.Test

/**
 * <pre>
 * Author: taylorcyang@tencent.com
 * Date:   2019-03-22
 * Time:   16:33
 * Life with Passion, Code with Creativity.
 * </pre>
 */
class HMSObservableDataTest {
    private val executor = HMSExecutors(object : HMSExecutorDelegate {
        override fun isMainThread(): Boolean = true

        override fun postToMainThread(block: () -> Unit) {
            block()
        }

        override fun postToWorker(block: () -> Unit) {
            throw UnsupportedOperationException()
        }
    })

    @Test
    fun testObservableData() {
        val ob = HMSObservableData<Int>(executor)
        Assert.assertNull(ob.data)
        ob.setData(10)
        Assert.assertEquals(10, ob.data)

        var data = 0
        ob.observe {
            data = it
        }
        ob.setData(100)
        Assert.assertEquals(100, data)
    }

    @Test
    fun testObservableDataWithInitialData() {
        val ob = HMSObservableData(executor, 10)
        Assert.assertEquals(10, ob.data)
    }

    @Test
    fun testObservableDataMap() {
        val ob = HMSObservableData<Int>(executor)
        val obMap = ob.map { -it }

        Assert.assertNull(obMap.data)
        ob.setData(10)
        Assert.assertEquals(null, obMap.data)

        var data = 0
        obMap.observe {
            data = it
        }
        Assert.assertEquals(-10, data)
        Assert.assertEquals(-10, obMap.data)
        ob.setData(100)
        Assert.assertEquals(-100, data)
        Assert.assertEquals(-100, obMap.data)
    }

    @Test
    fun testObservableDataMapWithInitialData() {
        val ob = HMSObservableData<Int>(executor, 10)
        val obMap = ob.map { -it }
        Assert.assertEquals(null, obMap.data)
    }


    @Test
    fun testObservableDataSwitchMap() {
    }

}