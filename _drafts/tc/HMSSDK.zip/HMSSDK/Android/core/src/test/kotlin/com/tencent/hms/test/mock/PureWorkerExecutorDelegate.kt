package com.tencent.hms.test.mock

import com.tencent.hms.HMSExecutorDelegate

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-09
 * Time:   20:24
 * Life with Passion, Code with Creativity.
 * ```
 */

object PureWorkerExecutorDelegate : HMSExecutorDelegate {
    override fun isMainThread(): Boolean = false

    override fun postToMainThread(block: () -> Unit) {
        TODO("not implemented")
    }

    override fun postToWorker(block: () -> Unit) {
        block()
    }

}