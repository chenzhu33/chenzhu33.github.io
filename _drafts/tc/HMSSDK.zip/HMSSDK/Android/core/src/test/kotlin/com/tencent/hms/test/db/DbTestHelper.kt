package com.tencent.hms.test.db

import com.squareup.sqldelight.db.SqlDriver
import com.squareup.sqldelight.sqlite.driver.JdbcSqliteDriver
import com.tencent.hms.internal.HMSExecutors
import com.tencent.hms.internal.repository.HMSDatabase
import com.tencent.hms.internal.trigger.TriggerManager
import com.tencent.hms.internal.trigger.TriggerSqlDriver
import com.tencent.hms.test.mock.PureWorkerExecutorDelegate
import org.junit.After
import org.junit.Before

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-09
 * Time:   20:27
 * Life with Passion, Code with Creativity.
 * ```
 */

open class DbTestHelper {
    internal lateinit var sqlDriver: SqlDriver
        private set
    internal lateinit var rawSqlDriver: SqlDriver
        private set

    internal lateinit var database: HMSDatabase
        private set
    internal lateinit var triggerManager: TriggerManager
        private set

    @Before
    fun setup() {
        // https://github.com/xerial/sqlite-jdbc
        rawSqlDriver = JdbcSqliteDriver(
            name = "jdbc:sqlite::memory:"
        )
        HMSDatabase.Schema.create(rawSqlDriver)
        triggerManager = TriggerManager(HMSExecutors(PureWorkerExecutorDelegate), rawSqlDriver)

        sqlDriver = TriggerSqlDriver(HMSExecutors(PureWorkerExecutorDelegate), triggerManager, rawSqlDriver)

        database = HMSDatabase(sqlDriver)
    }

    @After
    fun teardown() {
        rawSqlDriver.close()
    }
}