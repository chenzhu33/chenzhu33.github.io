package com.tencent.hms.test.learn_coroutine

import kotlinx.coroutines.*
import org.junit.Assert
import org.junit.Test
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.AbstractCoroutineContextElement
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * <pre>
 * Author: landerlyoung@gmail.com
 * Date:   2019-03-05
 * Time:   16:07
 * Life with Passion, Code with Creativity.
 * </pre>
 * https://github.com/Kotlin/kotlinx.coroutines/blob/master/docs/exception-handling.md#cancellation-and-exceptions
 */
class LearnCoroutine {
    private var e: Throwable? = null
    private val eh: CoroutineExceptionHandler =
        object : AbstractCoroutineContextElement(CoroutineExceptionHandler), CoroutineExceptionHandler {
            override fun handleException(context: CoroutineContext, exception: Throwable) {
                e = exception
            }
        }

    @Test
    fun exceptionHandler() {
        runBlocking(eh) {
            try {
                throwImmediately()
                Assert.assertTrue(false)
            } catch (e: TE) {
                println("caught immediately")
            }

            try {
                throwDelayed()
                Assert.assertTrue(false)
            } catch (e: TE) {
                println("caught delayed")
            }

            try {
                await().await()
                Assert.assertTrue(false)
            } catch (e: TE) {
                println("caught await")
            }
        }
        Assert.assertNull(e)
    }

    @Test
    fun testLaunch() {
        e = null
        val done = AtomicBoolean(false)
        GlobalScope.launch(eh) {
            val job = Job()
            job.cancel()

            try {
                withContext(job) {
                }
                Assert.assertTrue(false)
            } catch (e: Exception) {
                println(e.message)
                throw e
            } finally {
                done.set(true)
            }
        }

        while (done.get()) {
        }

        // CancellationException is always ignored by ExceptionHandler
        Assert.assertNull(e)
    }

    @Test
    fun testCoroutineName() {
        var exceptionCoroutineName: CoroutineName? = null
        val exceptionHandler =
            object : AbstractCoroutineContextElement(CoroutineExceptionHandler), CoroutineExceptionHandler {
                override fun handleException(context: CoroutineContext, exception: Throwable) {
                    exceptionCoroutineName = context[CoroutineName]
                }
            }

        GlobalScope.launch(exceptionHandler + CoroutineName("0")) {
            withContext(CoroutineName("1")) {
                withContext(CoroutineName("2")) {
                    throw TE()
                }
            }
        }

        Thread.sleep(100)
        Assert.assertEquals("0", exceptionCoroutineName?.name)
    }

    @Test
    fun nestedJoin() {
        runBlocking {
            var parent: Job? = null
            var child: Job? = null

            parent = launch(start = CoroutineStart.LAZY) {
                println("parent start")
                child = launch(start = CoroutineStart.LAZY) {
                    println("child start")
                    // hangs
                    parent?.join()
                    println("child end")
                }
                child?.start()
                println("parent end")
            }

            parent.start()
            delay(100)
            Assert.assertTrue(parent.isActive)
            Assert.assertFalse(parent.isCompleted)
            parent.cancel()
        }
    }


    @Test
    fun nonNestedJoin() {
        runBlocking {
            var parent: Job? = null
            var child: Job? = null


            parent = launch(start = CoroutineStart.LAZY) {
                println("parent start")
                child = launchChild(GlobalScope)
                child?.start()
                println("parent end")
            }

            parent.start()
            delay(10)
            println(parent.isActive)
            println(parent.isCompleted)
            Assert.assertFalse(parent.isActive)
            Assert.assertTrue(parent.isCompleted)
        }
    }

    private suspend fun launchChild(scope: CoroutineScope): Job = scope.launch(start = CoroutineStart.LAZY) {
        println("child start")
        delay(100)
        println("child end")
    }


    private class TE : RuntimeException()

    private suspend fun throwImmediately() {
        withContext(Dispatchers.IO) {
            throw TE()
        }
    }

    private suspend fun throwDelayed() {
        withContext(Dispatchers.IO) {
            delay(1)
            throw TE()
        }
    }

    private suspend fun dispatched() {
        suspendCoroutine<Unit> { continuation ->
            continuation.resumeWithException(TE())
        }
    }

    private fun await() =
        GlobalScope.async(eh) {
            throw TE()
        }
}