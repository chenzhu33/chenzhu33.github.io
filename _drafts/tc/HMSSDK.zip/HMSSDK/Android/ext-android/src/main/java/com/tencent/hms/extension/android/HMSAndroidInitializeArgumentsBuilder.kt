package com.tencent.hms.extension.android

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.ApplicationInfo
import android.database.sqlite.SQLiteDatabase
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.util.Log
import com.squareup.sqldelight.android.AndroidSqliteDriver
import com.squareup.sqldelight.db.SqlDriver
import com.tencent.hms.*
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicInteger

/*
 * <pre>
 * Author: taylorcyang
 * Date:   2019-03-19
 * Time:   16:54
 * Life with Passion, Code with Creativity.
 * </pre>
 */

/**
 * Android 上的 [HMSCore.InitializeArguments] builder实现，提供了默认的
 * 1. [HMSCore.InitializeArguments.executorDelegate] [2, cpu-core]线程数量的线程池
 * 2. [HMSCore.InitializeArguments.logDelegate] 所有log输出到 Logcat 的日志组件
 * 3. [HMSCore.InitializeArguments.serializer] 所有序列化/反序列化方法 抛出 [UnsupportedOperationException] 的 [HMSSerializer]
 * 4. [HMSCore.InitializeArguments.sqlDriverFactory] 基于Android [SQLiteDatabase] 的 [HMSSqlDriverFactory] 实现
 *  * 依赖 `com.squareup.sqldelight:android-driver:$sqldelight_version`
 *
 *  除此之外，业务侧仍需提供
 *  1. [HMSAndroidInitializeArgumentsBuilder.appid]
 *  2. [HMSAndroidInitializeArgumentsBuilder.uid]
 *  3. [HMSAndroidInitializeArgumentsBuilder.networkTransfer]
 *   * 建议借助 `com.tencent.hms:ext-wns:$hms_version` 实现
 *
 */
class HMSAndroidInitializeArgumentsBuilder(
    _appContext: Context
) {

    private val appContext: Context = _appContext.applicationContext

    private var appid: String? = null
    private var uid: String? = null
    private var networkTransfer: HMSNetworkTransfer? = null

    private var executorDelegate: HMSExecutorDelegate? = null
    private var sqlDriverFactory: HMSSqlDriverFactory? = null
    private var serializer: HMSSerializer? = null
    private var logDelegate: HMSLogDelegate? = null
    private var isEmptyC2CSessionShow:Boolean = false


    fun appid(appid: String) = apply {
        this.appid = appid
    }

    fun uid(uid: String) = apply {
        this.uid = uid
    }

    fun setEmptyC2CSessionShow(isShow:Boolean) {
        isEmptyC2CSessionShow = isShow
    }

    fun executorDelegate(executorDelegate: HMSExecutorDelegate) = apply {
        this.executorDelegate = executorDelegate
    }

    fun networkTransfer(networkTransfer: HMSNetworkTransfer) = apply {
        this.networkTransfer = networkTransfer
    }

    fun sqlDriverFactory(sqlDriverFactory: HMSSqlDriverFactory) = apply {
        this.sqlDriverFactory = sqlDriverFactory
    }

    fun serializer(serializer: HMSSerializer) = apply {
        this.serializer = serializer
    }

    fun logDelegate(logDelegate: HMSLogDelegate) = apply {
        this.logDelegate = logDelegate
    }

    fun build(): HMSCore.InitializeArguments {
        return HMSCore.InitializeArguments(
            appid ?: throw HMSIllegalArgumentException("appid must be set"),
            uid ?: throw HMSIllegalArgumentException("uid must be set"),
            executorDelegate ?: AndroidExecutorDelegate(),
            networkTransfer ?: throw HMSIllegalArgumentException("networkTransfer must be set"),
            sqlDriverFactory ?: AndroidSqlDriverFactory(appContext),
            serializer ?: object : HMSSerializer() {},
            logDelegate ?: LogcatLogDelegate(appContext),
            isEmptyC2CSessionShow
        )
    }
}

internal class AndroidExecutorDelegate : HMSExecutorDelegate {
    private val mainHandler = Handler(Looper.getMainLooper())

    private val executors: ExecutorService by lazy {
        val cores = Runtime.getRuntime().availableProcessors()
        val blockingQueue: BlockingQueue<Runnable> =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                object : LinkedTransferQueue<Runnable>() {
                    @SuppressLint("NewApi")
                    override fun offer(e: Runnable): Boolean {
                        return tryTransfer(e)
                    }
                }
            } else {
                object : LinkedBlockingQueue<Runnable>() {
                    override fun offer(e: Runnable?): Boolean {
                        return if (isNotEmpty()) {
                            // all works are busy, try to add new workers
                            false
                        } else {
                            super.offer(e)
                        }
                    }
                }
            }

        val threadId = AtomicInteger()
        ThreadPoolExecutor(
            2, cores.coerceAtLeast(2),
            1, TimeUnit.MINUTES,
            blockingQueue,
            ThreadFactory { work ->
                object : Thread(work, "HmsWorker-${threadId.getAndIncrement()}") {
                    override fun run() {
                        Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
                        super.run()
                    }
                }
            },
            RejectedExecutionHandler { r, _ ->
                blockingQueue.put(r)
            }
        ).also { it.allowCoreThreadTimeOut(true) }
    }


    override fun isMainThread(): Boolean {
        return Looper.getMainLooper() == Looper.myLooper()
    }

    override fun postToMainThread(block: () -> Unit) {
        mainHandler.post(block)
    }

    override fun postToWorker(block: () -> Unit) {
        executors.execute(block)
    }
}

internal class AndroidSqlDriverFactory(private val appContext: Context) : HMSSqlDriverFactory {
    override fun createSqlDriver(schema: SqlDriver.Schema, databaseName: String): SqlDriver {
        return AndroidSqliteDriver(schema, appContext, databaseName)
    }
}

internal class LogcatLogDelegate(context: Context) : HMSLogDelegate {

    override val verbose: Boolean = context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0

    override fun log(level: HMSLogDelegate.LogLevel, tag: String, message: String, throwable: Throwable?) {
        when (level) {
            HMSLogDelegate.LogLevel.VERBOSE -> Log.v(tag, message, throwable)
            HMSLogDelegate.LogLevel.DEBUG -> Log.d(tag, message, throwable)
            HMSLogDelegate.LogLevel.INFO -> Log.i(tag, message, throwable)
            HMSLogDelegate.LogLevel.WARNING -> Log.w(tag, message, throwable)
            HMSLogDelegate.LogLevel.ERROR -> Log.e(tag, message, throwable)
        }
    }
}
