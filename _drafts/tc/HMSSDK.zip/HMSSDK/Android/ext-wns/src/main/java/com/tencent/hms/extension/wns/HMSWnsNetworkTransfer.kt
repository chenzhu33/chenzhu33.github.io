package com.tencent.hms.extension.wns

/*
 * ```
 * Author: taylorcyang@tencent.com
 * Date:   2019-01-08
 * Time:   17:39
 * Life with Passion, Code with Creativity.
 * ```
 */

import android.util.Base64
import android.util.Log
import com.qq.jce.wup.UniAttribute
import com.tencent.hms.*
import com.tencent.wns.client.WnsClient
import com.tencent.wns.data.Client
import com.tencent.wns.data.Const
import com.tencent.wns.data.Error
import com.tencent.wns.data.PushData
import com.tencent.wns.ipc.AbstractPushService
import com.tencent.wns.ipc.RemoteCallback
import com.tencent.wns.ipc.RemoteData

/**
 * 为了让wns正确上报前后台状态，业务在初始化WNS的时候**一定**要设置
 * [Client.business] 为 [Const.BusinessType.IM]
 */
abstract class HMSWnsNetworkTransfer(
    private val appid: String,
    private val wnsClient: WnsClient
) : HMSNetworkTransfer() {

    protected abstract val uid: String
    protected abstract val isAnonymous: Boolean

    override fun sendRequest(
        type: HMSRequestType,
        data: ByteArray,
        timeoutMillis: Long,
        callback: HMSDisposableCallback<HMSResult<ByteArray>>
    ) {
        sendRequest(type, data, timeoutMillis, 1, callback)
    }

    override fun sendRequest(
        type: HMSRequestType,
        data: ByteArray,
        timeoutMillis: Long,
        retryCount: Int,
        callback: HMSDisposableCallback<HMSResult<ByteArray>>
    ) {
        val transferArgs = RemoteData.TransferArgs().apply {
            uid = this@HMSWnsNetworkTransfer.uid
            command = makeCommand(type)
            busiData = data
            isNeedCompress = true
            this.retryCount = retryCount
            retryFlag = if (retryCount > 1) 1 else 0
            retryPkgId = System.currentTimeMillis()
            timeout = timeoutMillis.toInt()
            isTlvFlag = false
            priority = 3
            accountUin = try {
                this@HMSWnsNetworkTransfer.uid.toLong()
            } catch (e: NumberFormatException) {
                0
            }
        }

        val transferCallback = object : RemoteCallback.TransferCallback() {
            override fun onTransferFinished(args: RemoteData.TransferArgs, result: RemoteData.TransferResult) {
                if (result.wnsCode == Error.SUCCESS && result.bizCode == Error.SUCCESS) {
                    // success
                    callback.callback(HMSResult.success(result.bizBuffer))
                } else {
                    val isWnsError = result.wnsCode != 0
                    // network fail
                    callback.callback(
                        HMSResult.fail(
                            HMSTransferException(
                                if (isWnsError) result.wnsCode else result.bizCode,
                                if (!result.bizMsg.isNullOrEmpty()) {
                                    result.bizMsg
                                } else if (isWnsError) {
                                    "unknown wns error"
                                } else {
                                    "unknown biz error"
                                } + " [${args.command}]"
                            )
                        )
                    )
                }
            }
        }

        if (isAnonymous) {
            wnsClient.transferAnonymous(transferArgs, transferCallback)
        } else {
            wnsClient.transfer(transferArgs, transferCallback)
        }
    }

    open fun makeCommand(type: HMSRequestType): String {
        return "hms." + type.name
    }

    /**
     * 在 WNS 的 [AbstractPushService.onPushReceived] 的方法中调用该接口，用于将HMS的push数据传给 HMS SDK
     * 业务侧可能无法判断该push数据是否属于HMS。
     * 业务侧可以直接调用该接口，当该push数据属于HMS的时候，HMS内部会消费掉该数据，并返回true。
     * 当该数据不属于HMS的时候，该方法什么都不做并返回false
     *
     * @param data wns push 的 [PushData], see [AbstractPushService.onPushReceived]
     * @return 该Push数据是否属于这个 HMS实例。
     */
    fun onReceivePush(data: PushData): Boolean {
        return onReceivePush(data.data)
    }

    /**
     * 在 WNS 的 [AbstractPushService.onPushReceived] 的方法中调用该接口，用于将HMS的push数据传给 HMS SDK
     * 业务侧可能无法判断该push数据是否属于HMS。
     * 业务侧可以直接调用该接口，当该push数据属于HMS的时候，HMS内部会消费掉该数据，并返回true。
     * 当该数据不属于HMS的时候，该方法什么都不做并返回false
     *
     * @return 该Push数据是否属于这个 HMS实例。
     * @see onReceivePush
     */
    fun onReceivePush(data: ByteArray): Boolean {
        val attr = UniAttribute()
        attr.encodeName = "utf-8"
        attr.decode(data)
        return onReceivePush(attr)
    }

    /**
     * 在 WNS 的 [AbstractPushService.onPushReceived] 的方法中调用该接口，用于将HMS的push数据传给 HMS SDK
     * 业务侧可能无法判断该push数据是否属于HMS。
     * 业务侧可以直接调用该接口，当该push数据属于HMS的时候，HMS内部会消费掉该数据，并返回true。
     * 当该数据不属于HMS的时候，该方法什么都不做并返回false
     *
     * @param attr Wns push de [UniAttribute]
     * @return 该Push数据是否属于这个 HMS实例。
     *
     * @see onReceivePush
     */
    fun onReceivePush(attr: UniAttribute): Boolean {
        attr.get<String>("hms.push.appid")?.also { appid ->
            if (this.appid == appid) {
                val base64 = attr.get<String>("hms.push.data")
                if (base64 != null) {
                    notifyPushData(
                        Base64.decode(base64, 0)
                    )
                }
                return true
            } else {
                Log.w(TAG, "HMS push with unknown appid:$appid expected:${this.appid}")
            }
        }
        return false
    }

    override fun registerPushToken(token: HMSPushToken, callback: HMSDisposableCallback<HMSResult<Unit>>) {
        // wns doggy api
        val uid = try {
            this.uid.toLong()
        } catch (e: NumberFormatException) {
            callback.callback(
                HMSResult.fail(
                    HMSTransferException(-1, "uid:$uid can't convert to long, wns rejects this")
                )
            )
            return
        }
        val success = when (token.provider) {
            HMSPushToken.PROVIDER_HUAWEI -> wnsClient.setHuaweiId(uid, token.token)
            HMSPushToken.PROVIDER_OPPO -> wnsClient.setOppoId(uid, token.token)
            HMSPushToken.PROVIDER_VIVO -> wnsClient.setVivoId(uid, token.token)
            HMSPushToken.PROVIDER_XIAOMI -> wnsClient.setXiaoMiId(uid, token.token)
            else -> throw IllegalArgumentException("can't register push token for ${token.provider}")
        }
        callback.callback(
            if (success) HMSResult.success(Unit)
            else HMSResult.fail(HMSTransferException(-1, "register push token failed"))
        )
    }


    companion object {
        private const val TAG = "HMSWnsNetworkTransfer"
    }
}