package com.tencent.oskplayerdemo;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.util.Pair;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.tencent.oskplayer.util.PlayerUtils;
import com.tencent.oskplayerdemo.contrib.OskNative;

import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Locale;

/**
 * Created by leoliu on 17/4/17.
 */

public class MediaCodecDemoActivity extends Activity {

    public static final String LOG_TAG = "MediaCodecDemoActivity";

    public static final int REQUEST_CODE_SELECT_FILE = 0x1;

    public static final int REQUEST_EXTERNAL_STORAGE = 0x2;

    static final String PREF_KEY_VIDEO_PATH = "video_path";

    private TextView mIptVideoPathView;
    private String mVideoPath;
    private MediaExtractor mExtractor;
    private boolean mExtractorInited;
    private volatile String mLogStr;

    private Thread mDecodeThread;
    private static int mDecodeThreadCountIdx = 1;

    private final int mOutputColorFormat = 0x7F420888;//MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible;

    private File mDumpFile;
    private FileOutputStream mDumpFileOutputStream;
    private boolean mIsDumpSaved;

    private ImageView mImageView;

    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mediacodec_demo_activity);
        init();
    }

    void init() {
        Button mediaCodecDecoderInfoBtn = (Button) findViewById(R.id.btn_display_mediacodec_decoder_info);
        Button mediaCodecEncoderInfoBtn = (Button) findViewById(R.id.btn_display_mediacodec_encoder_info);
        Button selectVideoBtn = (Button) findViewById(R.id.btn_select_video);
        Button showLogBtn = (Button) findViewById(R.id.btn_show_log);
        Button runBtn = (Button) findViewById(R.id.btn_run);
        Button stopBtn = (Button) findViewById(R.id.btn_stop);
        mImageView = (ImageView) findViewById(R.id.image_view);

        mIptVideoPathView = (TextView) findViewById(R.id.ipt_video_path);
        mVideoPath = PreferenceManager.get(this, PREF_KEY_VIDEO_PATH, "");

        mIptVideoPathView.setText(mVideoPath);
        mediaCodecDecoderInfoBtn.setOnClickListener(mClickListener);
        mediaCodecEncoderInfoBtn.setOnClickListener(mClickListener);
        selectVideoBtn.setOnClickListener(mClickListener);
        showLogBtn.setOnClickListener(mClickListener);
        runBtn.setOnClickListener(mClickListener);
        stopBtn.setOnClickListener(mClickListener);
        mediaCodecDecoderInfoBtn.setText("解码器列表");
        mediaCodecEncoderInfoBtn.setText("编码器列表");
        showLogBtn.setText("运行日志");
        runBtn.setText("硬解测试");
        stopBtn.setText("硬解停止");
//        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }

    void actShowMediaCodecInfo(View anchor, boolean decoder) {
        if (decoder) {
            DialogUtil.showContent(anchor, MediaCodecUtil.getStyledDecoderList());
        } else {
            DialogUtil.showContent(anchor, MediaCodecUtil.getStyledEncoderList());
        }
    }

    void actSelectVideo() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(intent, "选择一个视频"), REQUEST_CODE_SELECT_FILE);
    }

    void onVideoSelected(String path) {
        mVideoPath = path;
        mIptVideoPathView.setText(path);
        PreferenceManager.saveAsync(this, PREF_KEY_VIDEO_PATH, path);
    }

    void actRun() {
        if (!maybeRequestPermissions()) {
            doRun();
        }
    }

    void actStop() {
        if (mDecodeThread != null) {
            mDecodeThread.interrupt();
            appendLog( Thread.currentThread().getName() + " stop");
        }
    }

    void maybeRestartDecode() {
        if (mDecodeThread != null) {
            mDecodeThread.interrupt(); // interrupt previous decode thread;
            while(mDecodeThread.isAlive()) {
            }
            appendLog("previous thread is died");
        }
    }
    void doRun() {
        maybeRestartDecode();
        clearLog();
        //init media extractor
        maybeInitExtractor();
        Pair<String, MediaFormat> trackInfo = maybeSelectTrack();
        if (trackInfo.first == null) {
            DialogUtil.showSimpleMessage(this, "mime is null");
            return;
        }
        if (trackInfo.second == null) {
            DialogUtil.showSimpleMessage(this, "mediaformat is null");
            return;
        }
        maybeStartDecode(trackInfo.first, trackInfo.second);
    }

    void actShowLog() {
        DialogUtil.showSimpleMessage(this, mLogStr);
    }

    boolean maybeRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int result = checkSelfPermission(PERMISSIONS_STORAGE[0]);
            if (result != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);
                return true;
            }
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        actRun();
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    void maybeInitExtractor() {
        if (!mExtractorInited) {
            mExtractor = new MediaExtractor();
            try {
                mExtractor.setDataSource(mVideoPath);
                mExtractorInited = true;
            } catch (IOException ex) {
                destroyExtractor();
                DialogUtil.showSimpleMessage(this, ex.toString());
                ex.printStackTrace();
            }
        }
    }

    void destroyExtractor() {
        appendLog("release extractor");
        mExtractor.release();
        mExtractor = null;
        mExtractorInited = false;
    }

    Pair<String, MediaFormat> maybeSelectTrack() {
        String trackMIME = null;
        MediaFormat format = null;
        if (mExtractor != null) {
            for (int i=0; i < mExtractor.getTrackCount(); i++) {
                format = mExtractor.getTrackFormat(i);
                trackMIME = format.getString(MediaFormat.KEY_MIME);
                if (trackMIME.startsWith("video")) {
                    mExtractor.selectTrack(i);
                    appendLog("select track " + i);
                    appendLog("mime: " + format.getString(MediaFormat.KEY_MIME));
                    appendLog("duration: " + format.getLong(MediaFormat.KEY_DURATION));
                    appendLog("width: " + format.getInteger(MediaFormat.KEY_WIDTH));
                    appendLog("height: " + format.getInteger(MediaFormat.KEY_HEIGHT));
                    appendLog("bitrate: " + format.getString(MediaFormat.KEY_BIT_RATE));
                    try {
                        appendLog("framerate: " + format.getInteger(MediaFormat.KEY_FRAME_RATE));
                    } catch (NullPointerException ex) {
                        appendLog("framerate: -");
                    }
                    appendLog("colorFormat: " + format.getString(MediaFormat.KEY_COLOR_FORMAT));
                    if (Build.VERSION.SDK_INT >= 21) {
                        appendLog("profile: " + format.getString(MediaFormat.KEY_PROFILE));
                        appendLog("bitrateMode: " + format.getString(MediaFormat.KEY_BITRATE_MODE));
                    }
                    if (Build.VERSION.SDK_INT >= 23) {
                        appendLog("rotation: " + format.getInteger(MediaFormat.KEY_ROTATION));
                    }
                    appendLog("iframeInterval: " + format.getString(MediaFormat.KEY_I_FRAME_INTERVAL));
                    break;
                }
            }
        }
        return new Pair<String, MediaFormat>(trackMIME, format);
    }

    void onDecodeStart() {
        mDumpFile = new File(mVideoPath + ".yuv");
        if (mDumpFile.exists()) {
            mDumpFile.delete();
        }
        mIsDumpSaved = false;
        mRenderMeter.onRenderStart();
    }

    void onFrameDecoded(MediaCodec.BufferInfo info, ByteBuffer buffer, MediaFormat mediaFormat) {
        // process buffer
        appendLog("output pts" + info.presentationTimeUs);
        if (false) {
            saveToDump(info, buffer);
        }
        renderOnScreen(info, buffer, mediaFormat);
    }

    void onDecodeFinish() {
        if (mDumpFileOutputStream != null) {
            try {
                mDumpFileOutputStream.getFD().sync();
            } catch (IOException ignore) {
            }
        }
        closeSilently(mDumpFileOutputStream);
        mDumpFileOutputStream = null;
    }


    private void closeSilently(Closeable closeable) {
        try {
            if (closeable != null) {
                closeable.close();
            }
        } catch (IOException ignore) {
            ignore.printStackTrace();
        }
    }



    public static class RenderMeter {
        private int mBitmapCreateCount = 0;
        private long mBitmapCreateTimeCost = 0;
        private long mColorConversionTimeCost = 0;
        private long mRenderStartTime = 0;
        private long mRenderEndTime = 0;

        private long mEventBitmapCreateStartTime = 0;

        synchronized void clear() {
            mBitmapCreateCount = 0;
            mBitmapCreateTimeCost = 0;
            mColorConversionTimeCost = 0;
            mEventBitmapCreateStartTime = 0;
        }

        synchronized void onBeforeCreateBitmap() {
            mEventBitmapCreateStartTime = SystemClock.elapsedRealtime();
            mBitmapCreateCount++;
        }

        synchronized void onAfterColorConversion() {
            mColorConversionTimeCost += SystemClock.elapsedRealtime() - mEventBitmapCreateStartTime;
        }

        synchronized void onAfterCreateBitmap() {
            mBitmapCreateTimeCost += SystemClock.elapsedRealtime() - mEventBitmapCreateStartTime;

        }

        synchronized void onRenderStart() {
            clear();
            mRenderStartTime = SystemClock.elapsedRealtime();
        }

        synchronized void onRenderFrameEnd() {
            mRenderEndTime = SystemClock.elapsedRealtime();
        }

        synchronized float getBitmapCreateEfficiency() {
            return (float) mBitmapCreateTimeCost / mBitmapCreateCount;
        }

        synchronized float getColorConversionEfficiency() {
            return (float) mColorConversionTimeCost / mBitmapCreateCount;
        }

        synchronized int getRenderFPS() {
            return (int)((mBitmapCreateCount * 1000) / (mRenderEndTime - mRenderStartTime));
        }
    }

    private RenderMeter mRenderMeter = new RenderMeter();
    private Paint mTextPainter = null;

    void maybeInitTextPainter() {
        if (mTextPainter == null) {
            mTextPainter = new Paint();
            mTextPainter.setColor(Color.RED);
            mTextPainter.setTextSize(30);
            mTextPainter.setStyle(Paint.Style.FILL);
        }
    }

    void renderOnScreen(MediaCodec.BufferInfo info, ByteBuffer buffer, MediaFormat mediaFormat) {
        int colorFormat = mediaFormat.getInteger(MediaFormat.KEY_COLOR_FORMAT);
        if (colorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar) {
            int width = mediaFormat.getInteger(MediaFormat.KEY_WIDTH);
            int height = mediaFormat.getInteger(MediaFormat.KEY_HEIGHT);
            byte[] buf = new byte[info.size];
            buffer.get(buf, info.offset, info.size);
            // I420
            mRenderMeter.onBeforeCreateBitmap();
            final Bitmap bitmap = MiscUtil.createBitMapI420Native(mRenderMeter, buf, width, height);
            mRenderMeter.onAfterCreateBitmap();

            PlayerUtils.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Canvas canvas = new Canvas(bitmap);
                    maybeInitTextPainter();
                    canvas.drawText(String.format("FPS: %s", mRenderMeter.getRenderFPS()), 0, 25, mTextPainter);
                    canvas.drawText(String.format(Locale.ENGLISH, "Bitmap:%.2fms", mRenderMeter.getBitmapCreateEfficiency()), 0, 50, mTextPainter);
                    canvas.drawText(String.format(Locale.ENGLISH, "Conversion:%.2fms", mRenderMeter.getColorConversionEfficiency()), 0, 75, mTextPainter);
                    mImageView.setImageBitmap(bitmap);
                    mRenderMeter.onRenderFrameEnd();
                }
            });
        }
    }

    void saveToDumpOnce(MediaCodec.BufferInfo info, ByteBuffer buffer) {
        if (!mIsDumpSaved) {
            saveToDump(info, buffer);
            mIsDumpSaved = true;
        }
    }

    void saveToDump(MediaCodec.BufferInfo info, ByteBuffer buffer) {
        try {
            if (mDumpFileOutputStream == null) {
                mDumpFileOutputStream = new FileOutputStream(mDumpFile);
            }
            if (info.size > 0) { // a valid buffer
                byte[] buf = new byte[info.size];
                buffer.get(buf, info.offset, info.size);
                mDumpFileOutputStream.write(buf);
            }
        } catch (IOException ex) {
            DialogUtil.showSimpleMessage(this, "write dump file error " + ex.toString());
        }
    }

    void maybeStartDecode(final String mime, final MediaFormat format) {
        mDecodeThread = new Thread(new Runnable() {
            @Override
            public void run() {
                appendLog(Thread.currentThread().getName() + " started");
                MediaCodec decoder = null;
                boolean hasError = false;
                MediaFormat outputFormat = null;
                // create decoder
                try {
                     if (mime.equals("video/avc")) {
                         decoder = MediaCodec.createByCodecName("OMX.google.h264.decoder");
                     }
                    if (Build.VERSION.SDK_INT >= 18) {
                        appendLog("create decoder " + decoder.getName());
                    } else {
                        appendLog("create decoder unknown");
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                    appendLog("create decoder failed " + ex.toString());
                }


                if (decoder != null) {
                    //
                    int frameWidth = format.getInteger(MediaFormat.KEY_WIDTH);
                    int frameHeight = format.getInteger(MediaFormat.KEY_HEIGHT);
                    int inFrameCount = 0;
                    int outFrameCount = 0;

                    //
                    MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();

                    // check decoder supports selected track
                    if (Build.VERSION.SDK_INT >= 18) {
                        MediaCodecInfo info = decoder.getCodecInfo();
                        MediaCodecInfo.CodecCapabilities caps = info.getCapabilitiesForType(mime);
                        // check if decoder supports color format we need
                        if (caps != null) {
                            boolean supportOurColorFormat = false;
                            for (int colorFormat : caps.colorFormats ) {
                                if (colorFormat == mOutputColorFormat) {
                                    supportOurColorFormat = true;
                                    break;
                                }
                            }
                            if (supportOurColorFormat) {
                                appendLog("decoder supports " + Integer.toHexString(mOutputColorFormat));
                                // 指定输出格式
                                format.setInteger(MediaFormat.KEY_COLOR_FORMAT, mOutputColorFormat);
                            } else {
                                appendLog("decoder not supports " + Integer.toHexString(mOutputColorFormat));
                            }

                            hasError = !supportOurColorFormat;

                            if (Build.VERSION.SDK_INT >= 21) {
                                MediaCodecInfo.VideoCapabilities vcaps = caps.getVideoCapabilities();
                                if (vcaps != null) {
                                    if (!vcaps.isSizeSupported(frameWidth, frameHeight)) {
                                        hasError = true;
                                        appendLog("video size is not supported by decoder ");
                                    }
                                }
                            }
                        } else {
                            appendLog("cant determine codec caps");
                        }
                    } else {
                        appendLog("be careful, compatibilities check skipped");
                    }

                    appendLog("configure decoder");
                    // configure without a surface
                    decoder.configure(format, null, null, 0 /* flag_decode */);
                    // not available
                    // decoder.setOutputSurface();
                    appendLog("start decoder");
                    decoder.start();

                    //
                    boolean flagEndOutput = false;
                    boolean flagEndInput = false;
                    String threadName = Thread.currentThread().getName();

                    onDecodeStart();

                    while (!hasError) {
                        if (Thread.currentThread().isInterrupted()) {
                            appendLog(threadName + " interrupted");
                            break;
                        }
                        if (flagEndOutput) {
                            appendLog("decode finish");
                            break;
                        }
                        if (!flagEndInput) {
                            int inputBufferId = decoder.dequeueInputBuffer(0);
                            if (inputBufferId >= 0) { // inputbuffer available
                                ByteBuffer inputBuffer = null;
                                if (Build.VERSION.SDK_INT >= 21) {
                                    inputBuffer = decoder.getInputBuffer(inputBufferId);
                                } else {
                                    inputBuffer = decoder.getInputBuffers()[inputBufferId];
                                }
                                int sampleSize = mExtractor.readSampleData(inputBuffer, 0);
                                if (sampleSize < 0) {
                                    decoder.queueInputBuffer(inputBufferId, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                    flagEndInput = true;
                                    appendLog("input end");
                                } else {
                                    MiscUtil.printByteBuffer(inputBuffer, Math.min(100,sampleSize));
                                    inFrameCount++;
                                    long pts = mExtractor.getSampleTime();
                                    decoder.queueInputBuffer(inputBufferId, 0, sampleSize, pts, 0);
                                    mExtractor.advance();
                                    appendLog("input pts " + pts);
                                }
                            }
                        }

                        int outputBufferId = decoder.dequeueOutputBuffer(bufferInfo, 0);
                        if (outputBufferId == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                            appendLog("output format changed \n old->" + outputFormat + "\n new->" + decoder.getOutputFormat());
                            outputFormat = decoder.getOutputFormat();
                            int colorStandard = -1;
                            int colorRange = -1;
                            if (Build.VERSION.SDK_INT >= 24) {
                                colorStandard = outputFormat.getInteger(MediaFormat.KEY_COLOR_STANDARD);
                                colorRange = outputFormat.getInteger(MediaFormat.KEY_COLOR_RANGE);
                            }
                            appendLog("colorStandard:" + colorStandard);
                            appendLog("colorRange:" + colorRange);
                        } else if (outputBufferId == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED) {
                            // DO NOTHING
                        } else if (outputBufferId == MediaCodec.INFO_TRY_AGAIN_LATER) {
                            // DO NOTHING
                        } else  if (outputBufferId >= 0) { // outputbuffer available
                            if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                flagEndOutput = true;
                            }
                            if (bufferInfo.size > 0) {
                                //
                                ByteBuffer outputBuffer = null;
                                if (Build.VERSION.SDK_INT >= 21) {
                                    outputBuffer = decoder.getOutputBuffer(outputBufferId);
                                } else {
                                    outputBuffer = decoder.getOutputBuffers()[outputBufferId];
                                }

                                // render the output buffer
                                outFrameCount++;

                                if (outputFormat == null) {
                                    if (Build.VERSION.SDK_INT >= 21) {
                                        outputFormat = decoder.getOutputFormat(outputBufferId);
                                    } else {
                                        outputFormat = decoder.getOutputFormat();
                                    }
                                }
                                onFrameDecoded(bufferInfo, outputBuffer, outputFormat);

                                // release the output buffer
                                decoder.releaseOutputBuffer(outputBufferId, false);
                            }
                        }

                    }

                    onDecodeFinish();
                    appendLog(threadName + "input frame count " + inFrameCount);
                    appendLog(threadName + "output frame count " + inFrameCount);

                    appendLog("stop decoder");
                    decoder.stop();
                    appendLog("release decoder");
                    decoder.release();

                    if (mExtractor != null) {
                        destroyExtractor();
                    }
                }
                appendLog(Thread.currentThread().getName() + " quit");
            }

        }, "DecodeThread_" + (mDecodeThreadCountIdx++));
        mDecodeThread.start();
    }

    void clearLog() {
        mLogStr = "";
    }

    void appendLog(String moreLog) {
        mLogStr += moreLog + "\n";
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_SELECT_FILE) {
            if (resultCode == RESULT_OK) {
                Uri uri = data.getData();
                String path = MiscUtil.getPath(this, uri);
                onVideoSelected(path);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private View.OnClickListener mClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.btn_display_mediacodec_decoder_info) {
                actShowMediaCodecInfo(v, true);
            }
            if (v.getId() == R.id.btn_display_mediacodec_encoder_info) {
                actShowMediaCodecInfo(v, false);
            } else if (v.getId() == R.id.btn_select_video) {
                actSelectVideo();
            } else if (v.getId() == R.id.btn_run) {
                actRun();
            } else if (v.getId() == R.id.btn_show_log) {
                actShowLog();
            } else if (v.getId() == R.id.btn_stop) {
                actStop();
            }
        }
    };

    @Override
    protected void onPause() {
        actStop();
        super.onPause();
    }

    // Tools
    public static class MediaCodecUtil {

        public static final String LOG_TAG = "MediaCodecUtil";

        public static final String LEVEL_ONE = "    ";
        public static final String LEVEL_TWO = LEVEL_ONE + "    ";
        public static final String LEVEL_THREE = LEVEL_TWO + "    ";
        public static final String LEVEL_FOUR = LEVEL_THREE + "    ";
        public static final String CRLF = "\n";
        public static final String MIME_VIDEO_AVC = "video/avc";
        public static final String MIME_VIDEO_HEVC = "video/hevc";

        public static String describeDecoderByMIME(MediaCodecInfo info, String mime) {
            String describe = "";
            MediaCodecInfo.CodecCapabilities caps = info.getCapabilitiesForType(mime);
            int maxSupportedInstance = 0;
            if (Build.VERSION.SDK_INT >= 23) {
                maxSupportedInstance = caps.getMaxSupportedInstances();
            }
            describe += LEVEL_TWO + "capabilities:" + CRLF;
            describe += LEVEL_THREE + "MaxInstance:" + maxSupportedInstance + CRLF;
            describe += LEVEL_THREE + "CodecProfileLevels:" + CRLF;

            for (MediaCodecInfo.CodecProfileLevel cpl : caps.profileLevels) {
                describe += LEVEL_FOUR + "[0x" + Integer.toHexString(cpl.profile) +  ",0x" + Integer.toHexString(cpl.level) + "]" + CRLF;
            }

            if (caps.colorFormats.length > 1) {
                describe += LEVEL_THREE + "ColorFormats:" + CRLF;
                for (int colorFormat : caps.colorFormats) {
                    describe += LEVEL_FOUR + "0x" + Integer.toHexString(colorFormat) + CRLF;
                }
            }

            if (Build.VERSION.SDK_INT >= 21) {
                MediaCodecInfo.VideoCapabilities videoCapabilities = caps.getVideoCapabilities();
                if (videoCapabilities != null) {
                    describe += LEVEL_TWO + "video capabilities:" + CRLF;
                    describe += LEVEL_THREE + "FrameRateRange:" + videoCapabilities.getSupportedFrameRates() + CRLF;
                    describe += LEVEL_THREE + "BitrateRange:" + videoCapabilities.getBitrateRange() + CRLF;
                    describe += LEVEL_THREE + "WidthAlignment:" + videoCapabilities.getWidthAlignment() + CRLF;
                    describe += LEVEL_THREE + "HeightAlignment:" + videoCapabilities.getHeightAlignment() + CRLF;
                    describe += LEVEL_THREE + "SupportedWidths:" + videoCapabilities.getSupportedWidths() + CRLF;
                    describe += LEVEL_THREE + "SupportedHeights:" + videoCapabilities.getSupportedHeights() + CRLF;
                    describe += LEVEL_THREE + "VideoSizeSupport:" + CRLF;
                    describe += LEVEL_FOUR + "360P:" + videoCapabilities.isSizeSupported(480,360) + CRLF;
                    describe += LEVEL_FOUR + "480P:" + videoCapabilities.isSizeSupported(640,480) + CRLF;
                    describe += LEVEL_FOUR + "540P:" + videoCapabilities.isSizeSupported(960,540) + CRLF;
                    describe += LEVEL_FOUR + "720P:" + videoCapabilities.isSizeSupported(1280,720) + CRLF;
                    describe += LEVEL_FOUR + "1080P:" + videoCapabilities.isSizeSupported(1920,1080) + CRLF;
                    describe += LEVEL_FOUR + "2K:" + videoCapabilities.isSizeSupported(2560,1440) + CRLF;
                    describe += LEVEL_FOUR + "4K:" + videoCapabilities.isSizeSupported(3840,2160) + CRLF;
                }
            }
            return describe;
        }

        public static String getDecoderList() {
            String decoderList="";
            int numCodec = MediaCodecList.getCodecCount();
            for (int i=0; i < numCodec; i++) {
               MediaCodecInfo info = MediaCodecList.getCodecInfoAt(i);
               if (info.isEncoder()) continue;
                decoderList += info.getName() + CRLF;
                String[] supportedTypes = info.getSupportedTypes();
                for (String supportedType : supportedTypes) {
                    decoderList += LEVEL_ONE + supportedType + CRLF;
                    if (supportedType.toLowerCase().equals(MIME_VIDEO_AVC)) {
                        decoderList += describeDecoderByMIME(info, MIME_VIDEO_AVC);
                    } else if (supportedType.equals(MIME_VIDEO_HEVC)) {
                        decoderList += describeDecoderByMIME(info, MIME_VIDEO_HEVC);
                    }
                }
            }
            return decoderList;
        }

        public static String getEncoderList() {
            String decoderList="";
            int numCodec = MediaCodecList.getCodecCount();
            for (int i=0; i < numCodec; i++) {
                MediaCodecInfo info = MediaCodecList.getCodecInfoAt(i);
                if (!info.isEncoder()) continue;
                decoderList += info.getName() + CRLF;
                String[] supportedTypes = info.getSupportedTypes();
                for (String supportedType : supportedTypes) {
                    decoderList += LEVEL_ONE + supportedType + CRLF;
                    if (supportedType.toLowerCase().equals(MIME_VIDEO_AVC)) {
                        decoderList += describeDecoderByMIME(info, MIME_VIDEO_AVC);
                    } else if (supportedType.equals(MIME_VIDEO_HEVC)) {
                        decoderList += describeDecoderByMIME(info, MIME_VIDEO_HEVC);
                    }
                }
            }
            return decoderList;
        }

        public static SpannableString getStyledDecoderList() {
            String decoderList = getDecoderList();
            SpannableString spannableString = new SpannableString(decoderList);
            String keyword = "video/";
            int videoIdx = decoderList.indexOf(keyword);
            while (videoIdx > -1) {
                int lineEnd = decoderList.indexOf(CRLF,videoIdx);
                spannableString.setSpan(new ForegroundColorSpan(Color.RED), videoIdx , lineEnd/*videoIdx + keyword.length()*/, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                videoIdx = decoderList.indexOf(keyword, videoIdx + keyword.length());
            }
            return spannableString;
        }

        public static SpannableString getStyledEncoderList() {
            String decoderList = getEncoderList();
            SpannableString spannableString = new SpannableString(decoderList);
            String keyword = "video/";
            int videoIdx = decoderList.indexOf(keyword);
            while (videoIdx > -1) {
                int lineEnd = decoderList.indexOf(CRLF,videoIdx);
                spannableString.setSpan(new ForegroundColorSpan(Color.RED), videoIdx , lineEnd/*videoIdx + keyword.length()*/, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                videoIdx = decoderList.indexOf(keyword, videoIdx + keyword.length());
            }
            return spannableString;
        }

    }

    public static class DialogUtil {

        public static void showContent(View anchor, String content) {
            showContent(anchor, new SpannableString(content));
        }

        public static void showContent(View anchor, SpannableString spannableString) {
            Context ctx = anchor.getContext();
            LayoutInflater inflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View popupLayout = inflater.inflate(R.layout.mediacodec_demo_popup, null);
            TextView contentView = (TextView) popupLayout.findViewById(R.id.popup_content);
            contentView.setText(spannableString);
            PopupWindow popupWindow = new PopupWindow(popupLayout, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            popupWindow.setTouchable(true);
            popupWindow.setOutsideTouchable(true);
            popupWindow.setBackgroundDrawable(new BitmapDrawable(anchor.getResources(), (Bitmap) null));
            popupWindow.showAsDropDown(anchor);
        }

        public static void showSimpleMessage(Activity ctx, String message) {
            View anyView = null;
            anyView = ctx.getWindow().getDecorView().getRootView();
            LayoutInflater inflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View popupLayout = inflater.inflate(R.layout.mediacodec_demo_popup, null);
            TextView contentView = (TextView) popupLayout.findViewById(R.id.popup_content);
            contentView.setText(message);
            PopupWindow popupWindow = new PopupWindow(popupLayout, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            popupWindow.setTouchable(true);
            popupWindow.setOutsideTouchable(true);
            popupWindow.setBackgroundDrawable(new BitmapDrawable(anyView.getResources(), (Bitmap) null));
            popupWindow.showAtLocation(anyView, Gravity.CENTER, 0, 0);
        }
    }

    public static class MiscUtil {
        public static String getPath(Context context, Uri uri) {
            if ("content".equalsIgnoreCase(uri.getScheme())) {
                String[] projection = { "_data" };
                Cursor cursor = null;
                try {
                    cursor = context.getContentResolver().query(uri, projection, null, null, null);
                    if (cursor != null) {
                        int column_index = cursor.getColumnIndexOrThrow("_data");
                        if (cursor.moveToFirst()) {
                            return cursor.getString(column_index);
                        }
                        cursor.close();
                    }
                } catch (Exception e) {
                    // Eat it
                }
            }
            else if ("file".equalsIgnoreCase(uri.getScheme())) {
                return uri.getPath();
            }
            return null;
        }

        public static Bitmap createBitMapI420Native(RenderMeter meter, byte[] yuv, int width, int height) {
            int frameSize = width * height;
            int[] rgba = new int[frameSize];
            long t1 = System.currentTimeMillis();
            OskNative.yuvConvertI420toARBG(yuv, width, height, rgba);
//            Log.d(LOG_TAG, "cost " + (System.currentTimeMillis() - t1) + "ms");
            meter.onAfterColorConversion();
            Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            //PlayerUtils.log(QLog.INFO, LOG_TAG, "NativeDecode " + (System.currentTimeMillis() - t1));
            bmp.setPixels(rgba, 0 , width, 0, 0, width, height);
            return bmp;
        }

        public static Bitmap createBitmapFromI420(RenderMeter meter, byte[] yuv, int width, int height) {
            int frameSize = width * height;
            int[] rgba = new int[frameSize];
            int positionOfU = frameSize; // FOR I420
            int positionOfV = frameSize/4 + frameSize;
//            Log.d(LOG_TAG,"Decode Begin");
            for (int i = 0; i < height; i++) {
                int startY = i * width;
                int step = (i / 2) * (width / 2);
                int startU = positionOfU + step;
                int startV = positionOfV + step;

                for (int j = 0; j < width; j++) {
                    int y = startY + j;
                    int u = startU + j / 2;
                    int v = startV + j / 2;
                    //y = y < 16 ? 16 : y;
                    int r,g,b;

//                    if (i < 4 && j < 4) {
//                        Log.d(LOG_TAG,"YUV Offsets: YI=" + y +" UI=" + u +" VI=" + v);
//                    }

                    r = (int) ((yuv[y] & 0xff) + 1.402 * ((yuv[v] & 0xff) - 128));
                    g = (int) ((yuv[y] & 0xff) - 0.344 * ((yuv[u] & 0xff) - 128) - 0.714 * ((yuv[v] & 0xff) - 128));
                    b = (int) ((yuv[y] & 0xff) + 1.772 * ((yuv[u] & 0xff) - 128));

                    r = r < 0 ? 0 : (r > 255 ? 255 : r);
                    g = g < 0 ? 0 : (g > 255 ? 255 : g);
                    b = b < 0 ? 0 : (b > 255 ? 255 : b);
                    rgba[i * width + j] = 0xff000000 + (r << 16) + (g << 8) + b;
                }
            }
//            PlayerUtils.log(QLog.INFO, LOG_TAG, "JavaDecode " + (System.currentTimeMillis() - t1));
            Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            bmp.setPixels(rgba, 0 , width, 0, 0, width, height);
            return bmp;
        }
        //
        public static void printByteBuffer(ByteBuffer buffer, int size) {
            String hex = "";
            Log.d(LOG_TAG, "printByteBuffer " + buffer.hasRemaining() + " size=" + size);
            for (int i=0; i<size; i++) {
                byte b = buffer.get(i);
                hex += String.format("%02X", b);
            }
            Log.d(LOG_TAG, hex);
        }
    }

    public static class PreferenceManager {
        static final String DEFAULT_PREFERENCE_NAME = "general_settings";
        public static void saveAsync(Context ctx, String key, String value) {
            SharedPreferences prefs = ctx.getSharedPreferences(DEFAULT_PREFERENCE_NAME, MODE_PRIVATE);
            prefs.edit().putString(key, value).apply();
        }

        public static final String get(Context ctx, String key, String defaultValue) {
            SharedPreferences prefs = ctx.getSharedPreferences(DEFAULT_PREFERENCE_NAME, MODE_PRIVATE);
            return prefs.getString(key, defaultValue);
        }
    }
}