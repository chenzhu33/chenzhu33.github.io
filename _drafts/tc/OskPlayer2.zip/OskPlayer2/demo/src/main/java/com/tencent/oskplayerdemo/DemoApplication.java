package com.tencent.oskplayerdemo;

import android.app.Application;

/**
 * Created by leoliu on 17/9/19.
 */

public class DemoApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
