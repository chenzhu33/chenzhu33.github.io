package com.tencent.oskplayerdemo.contrib;

import android.graphics.Bitmap;
import android.support.annotation.IntDef;

import com.tencent.oskplayer.util.PlayerUtils;
import com.tencent.oskplayer.util.QLog;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by leoliu on 17/4/23.
 */

public class OskNative {
    public static final String LOG_TAG = "OskNative";
    // DO NOT CHANGE THESE VALUES UNLESS CHANGE NATIVE CODE ACCORDINGLY!!!
    // see osk_jni.c calculateBitmapHash
    public static final int PHASH = 1;
    public static final int OHASH = 2;
    public static final int MSE = 3;

    public static boolean sLoadLibraryError = false;
    public static final int HASH_ERROR = 0;

    @IntDef({PHASH, OHASH, MSE})
    @Retention(RetentionPolicy.SOURCE)
    public @interface HashAlgorithm {}

    public static final void init() {
        try {
            System.loadLibrary("c++_shared");
            System.loadLibrary("osk");
        } catch (Exception e) {
            sLoadLibraryError = true;
            PlayerUtils.log(QLog.ERROR, LOG_TAG, "error while loading library osk,c++_shared", e);
        }
    }

    public native static int findClass(String className);

    //YuvDecodeYUVtoRBGA(JNIEnv * env, jobject obj, jbyteArray yuv420sp, jint width, jint height, jintArray rgbOut);
    public native static void yuvDecodeYUVtoRBGA(byte[] yuv, int width, int height, int[] out);
    public native static void yuvDecodeYUVtoARBG(byte[] yuv, int width, int height, int[] out);
    public native static void yuvConvertI420toARBG(byte[] yuv, int width, int height, int[] out);
    public static long getPHash(Bitmap bitmap) {
        if (!sLoadLibraryError) {
            return getHash(bitmap, PHASH);
        }
        return HASH_ERROR;
    }
    public native static long getHash(Bitmap bitmap, @HashAlgorithm int algorithm);
    public native static long getHammingDistance(long hash1, long hash2);
}