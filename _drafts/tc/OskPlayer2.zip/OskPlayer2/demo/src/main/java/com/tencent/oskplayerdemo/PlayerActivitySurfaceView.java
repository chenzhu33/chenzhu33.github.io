package com.tencent.oskplayerdemo;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.oskplayer.OskPlayer;
import com.tencent.oskplayer.datasource.HttpHeader;
import com.tencent.oskplayer.player.FFSegmentMediaPlayer;
import com.tencent.oskplayer.player.OskExoMediaPlayer;
import com.tencent.oskplayer.util.PlayerUtils;

import tv.danmaku.ijk.media.player.IMediaPlayer;

public class PlayerActivitySurfaceView extends Activity implements
        SurfaceHolder.Callback,
        SeekBar.OnSeekBarChangeListener,
        IMediaPlayer.OnPreparedListener,
        IMediaPlayer.OnSeekCompleteListener,
        IMediaPlayer.OnBufferingUpdateListener,
        IMediaPlayer.OnErrorListener,
        CheckBox.OnCheckedChangeListener,
        View.OnClickListener {

    public static final String TAG = "PlayerActivity";

    private SeekBar mSeekBar;
    private SurfaceHolder mMainSurfaceHolder;
    private SurfaceHolder mCurrentSurfaceHolder;
    private IMediaPlayer mMediaPlayer;
    private ImageButton mPlayPauseButton;
    private boolean mJustCreatePlayer;
    private TextView mDebugTextView;
    private TextView mVideoDurationView;
    private TextView mVideoProcessView;
    private boolean mIsLoopingPlay;
    private Handler mMainHandler;
    private long mPrepareTimeStart;
    private RadioGroup mPlayerChoice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.single_surfaceview);
        SurfaceView surfaceView0 = (SurfaceView) findViewById(R.id.main_surface);
        SurfaceView surfaceView1 = (SurfaceView) findViewById(R.id.second_surface);
        SurfaceView surfaceView2 = (SurfaceView) findViewById(R.id.third_surface);
        CheckBox loopCheckBox = (CheckBox)findViewById(R.id.loopcheckbox);
        mMainSurfaceHolder = surfaceView0.getHolder();
        mMainSurfaceHolder.addCallback(this);
        surfaceView1.getHolder().addCallback(this);
        surfaceView2.getHolder().addCallback(this);
        surfaceView0.setOnClickListener(this);
        surfaceView1.setOnClickListener(this);
        surfaceView2.setOnClickListener(this);
        mSeekBar = (SeekBar) findViewById(R.id.seekbar);
        mSeekBar.setOnSeekBarChangeListener(this);
        mPlayPauseButton = (ImageButton) findViewById(R.id.playpausebtn);
        mPlayPauseButton.setOnClickListener(this);
        mPlayPauseButton.setEnabled(false);
        mDebugTextView = (TextView) findViewById(R.id.debugtextview);
        mVideoDurationView = (TextView) findViewById(R.id.videoDuration);
        mVideoProcessView = (TextView) findViewById(R.id.videoProgress);
        mPlayerChoice = findViewById(R.id.playerchoice);
        mIsLoopingPlay = loopCheckBox.isChecked();
        mMainHandler = new Handler(Looper.getMainLooper());
        loopCheckBox.setOnCheckedChangeListener(this);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Log.e(TAG, "surfaceCreated " + holder.getSurface());
        mPlayPauseButton.setEnabled(true);
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        Log.d(TAG, "surfaceChanged[" + width + "," + height + "] " + holder.getSurface());
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.d(TAG, "surfaceDestroyed " + holder.getSurface());
        destroyPlayer(holder);
    }

    @Override
    public void onPrepared(IMediaPlayer mp) {
        Log.d(TAG, "onPrepared timeCost=" + (System.currentTimeMillis() - mPrepareTimeStart) + "ms");
//        Debug.stopMethodTracing();
        try {
            mMediaPlayer.start();
        } catch (IMediaPlayer.InternalOperationException ex) {
            ex.printStackTrace();
        }
        mSeekBar.setMax((int) mMediaPlayer.getDuration());
        updateDuration();
        refreshProgressbarLoop();
        updatePlayStatus();
    }

    @Override
    public void onBufferingUpdate(IMediaPlayer mp, int percent) {
        Log.d(TAG, "onBufferingUpdate " + percent);
    }

    @Override
    public void onSeekComplete(IMediaPlayer mp) {
        Log.d(TAG, "onSeekComplete");
    }


    @Override
    public boolean onError(IMediaPlayer mediaPlayerInterface, int what, int extra) {
        Log.d(TAG, "onError " + what + "," + extra);
        Toast.makeText(this, "Error[" + what + "," + extra + "]", Toast.LENGTH_SHORT).show();
        return false;
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        if (fromUser) {
            mDebugTextView.setText(String.valueOf(progress));
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
        mDebugTextView.setVisibility(View.VISIBLE);
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        int progress=seekBar.getProgress();
        Log.d(TAG, "seekTo " + progress);
        mMediaPlayer.seekTo(progress);
        mDebugTextView.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.playpausebtn) {
            if (mMediaPlayer == null) {
                initPlayer();
            }
            if (mJustCreatePlayer) {
                //String url = "https://base-n.de/webm/out9.webm";
                String url = "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4";
                String urlfmp4 = "https://tungsten.aaplimg.com/VOD/bipbop_adv_fmp4_example/v5/prog_index.m3u8";
                String urlhls = "https://tungsten.aaplimg.com/VOD/bipbop_adv_example_v2/v5/prog_index.m3u8";

                String wsfmp4_single = "http://10.66.93.130:8080/weishi/fmp4/fragment.mp4";
                String ws_hls_fmp4 = "http://10.66.93.130:8080/weishi/ws_hls_fmp4_diskfile/playlist.m3u8";
                String ws_hls_ts = "http://10.66.93.130:8080/weishi/hls_ts/playlist.m3u8";
                String wsmp4_normal = "http://10.66.93.130:8080/weishi/mp4/normal.mp4";
                String url5 = "https://dlied5.qq.com/ABCmouse/aol/content/MusicVideo/13333/movie.mp4";
                String url6 = "https://dlied5.qq.com/ABCmouse/aol/content/Animation/28997/ellclass_cn_b001_cid28997.mp4";
                String url7 = "http://10.66.93.121:8080/gop120.mp4";
                String url8 = "http://10.66.93.95:8080/weishi2/gop120_720p.mp4";
                String url9 = "http://10.66.93.74:8080/weishi2/sample1.f31.mp4";
                String url10 = "https://183.56.150.169/ABCmouse/aol/content/Animation/18051301/mothers_day.mp4"; // Host: dlied5.qq.com // ip: 183.56.150.169
                String url11 = "http://183.57.53.29/video.jystatic.com/1110_cab5c1938a9442bb9b16a0d89de11b86.f0.mp4?vkey=629C982E201CF56DD259B72C353D7C7808D523C40C2D318EC5AC6B3528980A778BACF8CDD16A84216E09634854043A0FA9D24DE8A9CCCCC20A484EAADC25459B639C0E4BAE88AA9CD6A1E672B84F62E3F049ED9368DCFD68&vid=1110_cab5c1938a9442bb9b16a0d89de11b86";
                String url12 = "android.resource://" + getPackageName() + "/" + R.raw.h265probe;

                HttpHeader header = new HttpHeader();
                header.set("Host", "dlied5.qq.com");

                String proxyUrl = OskPlayer.getInstance().getUrl(url12, header);
//                proxyUrl = url9;

                Log.d(TAG, "proxyUrl=" + proxyUrl);
                try {
                    Log.d(TAG, "LoopingCheckBox isChecked " + mIsLoopingPlay);
//                    Debug.startMethodTracing("osk");
                    mPrepareTimeStart = System.currentTimeMillis();
                    mMediaPlayer.setDataSource(proxyUrl);
                    mMediaPlayer.prepareAsync();
                    mJustCreatePlayer = false;
                } catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), ex.toString(), Toast.LENGTH_SHORT).show();
                    ex.printStackTrace();
                }
            } else {
                try {
                    if (mMediaPlayer.isPlaying()) {
                        mMediaPlayer.pause();
                    } else {
                        mMediaPlayer.start();
                    }
                } catch (IMediaPlayer.InternalOperationException ex) {
                    ex.printStackTrace();
                }
            }
            updatePlayStatus();
        } else if (v instanceof SurfaceView) {
            // 点击切换surfaceview
            if (mMediaPlayer == null) {
                return;
            }
            SurfaceHolder holder = ((SurfaceView)v).getHolder();
            mMediaPlayer.setDisplay(holder);
            mCurrentSurfaceHolder = holder;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        Log.d(TAG, "LoopingCheckBox isChecked " + isChecked);
        mIsLoopingPlay = isChecked;
        if(mMediaPlayer == null) {
            return;
        }
        Log.d(TAG, "setLooping " + isChecked);
        mMediaPlayer.setLooping(isChecked);
    }

    private void initPlayer() {
        long id = mPlayerChoice.getCheckedRadioButtonId();
        if (id == R.id.playerchoice_oskexo) {
//          ExoMediaPlayer.updateLoadControlConfig("65536,15000,30000,2000,5000");
            mMediaPlayer = new OskExoMediaPlayer();
        } else if (id == R.id.playerchoice_ijk) {
            mMediaPlayer = new FFSegmentMediaPlayer();
        }
        mMediaPlayer.setDisplay(mMainSurfaceHolder);
        mMediaPlayer.setOnPreparedListener(this);
        mMediaPlayer.setOnBufferingUpdateListener(this);
        mMediaPlayer.setOnSeekCompleteListener(this);
        mMediaPlayer.setOnErrorListener(this);
        mMediaPlayer.setLooping(mIsLoopingPlay);
        mJustCreatePlayer = true;
        mCurrentSurfaceHolder = mMainSurfaceHolder;
    }

    private void destroyPlayer(SurfaceHolder holder) {
        if (mMediaPlayer != null && mCurrentSurfaceHolder.equals(holder)) {
            mMediaPlayer.release();
            mJustCreatePlayer = false;
            mMediaPlayer = null;
        }
        updatePlayStatus();
    }

    private void updateDuration() {
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                mVideoDurationView.setText(PlayerUtils.formatVideoTime((int) mMediaPlayer.getDuration()));
            }
        });
    }
    
    private void updatePlayStatus() {
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mMediaPlayer != null && mMediaPlayer.isPlaying()) {
                    mPlayPauseButton.setImageResource(android.R.drawable.ic_media_pause);
                } else {
                    mPlayPauseButton.setImageResource(android.R.drawable.ic_media_play);
                }
            }
        });
    }

    private void refreshProgressbarLoop() {
        if (mMediaPlayer != null) {
            mSeekBar.setProgress((int) mMediaPlayer.getCurrentPosition());
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mVideoProcessView.setText(PlayerUtils.formatVideoTime((int)mMediaPlayer.getCurrentPosition()));
                }
            });
            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    refreshProgressbarLoop();
                }
            }, 1000);
        }
    }
}
