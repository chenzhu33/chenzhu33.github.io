package com.tencent.oskplayerdemo;

import android.app.Activity;
import android.graphics.SurfaceTexture;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.tencent.oskplayer.OskPlayer;
import com.tencent.oskplayer.datasource.VideoDownloadListener;
import com.tencent.oskplayer.player.PlayerType;
import com.tencent.oskplayer.player.StateMediaPlayer;
import com.tencent.oskplayer.proxy.VideoManager;
import com.tencent.oskplayer.util.PlayerUtils;
import com.tencent.oskplayer.util.QLog;

import java.io.IOException;
import java.util.Arrays;

import tv.danmaku.ijk.media.player.IMediaPlayer;

/**
 * Created by leoliu on 17/3/2.
 */

public class BasicPlayActivity extends Activity {
    public static final String LOG_TAG = "BasicPlayActivity";

    private StateMediaPlayer mPlayer;
    private InternalListener mListener;
    private TextureView mVideoSurface;
    private long mPrepareTimeStart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initData();
        initUI();
    }

    private void initData() {
        mListener = new InternalListener();
        try {
            mPlayer = OskPlayer.getInstance().createPlayer(PlayerType.SELF_DECODE);
        } catch (Exception ex) {
            mPlayer = OskPlayer.getInstance().createPlayer(PlayerType.EXO2);
            ex.printStackTrace();
        }
    }

    private void initUI() {
        setContentView(R.layout.basic_play_activity);
        Button startPlay = (Button) findViewById(R.id.start_play);
        Button downloadBtn = findViewById(R.id.download_video);
        mVideoSurface = (TextureView) findViewById(R.id.textureview);
        startPlay.setOnClickListener(mListener);
        downloadBtn.setOnClickListener(mListener);
        mVideoSurface.setSurfaceTextureListener(mListener);
    }

    private void startPlay() {
        String url7 = "http://qzonelivehls.tc.qq.com/vbigts.tc.qq.com/izxK-vFdRNoCRexyyJrcl2MhHc3vRf83AtQP_2BmMXR5zvnr8floO8wBNdNMjNBpiEVgbIMtGwo/1057_9b2ecfd16a4446e9af925facf12a0db2.h0.ts.m3u8?ver=4";
        String url6 = "http://183.61.62.142:1863/1000000_nextradio/7DE6B428143DC1B443C0D920170ECD55218F739E1D8BDAA6A9CAB33A9D8EC30558747FCA780685D4002B797873CA271C9B5EC344DDF8D52ECC996425AA5C30B928AD9AF30CFA9C25/200001624.m3u8?buname=nextradio2&aac=1&useblockid=1";
        String url5 = "http://2486.liveplay.myqcloud.com/2486_31388ac5ff4511e691eae435c87f075e.m3u8";
        String url4 = "http://qzonelivehls.tc.qq.com/vbigts.tc.qq.com/Ezh_ZL8TIvAbLyQ92Dz8JAefEb5Ncq2A0vazhlaIcNrUVPw77aBqdmjeAssj-kJii5T4slKRvtQ/1057_463699481c104a1694d50225bf174ecc.h0.ts.m3u8?ver=4";
        String url3 = "http://ws.stream.fm.qq.com/R396003Po0yb4LRFuK.m4a?fromtag=36&guid=1488451782&vkey=D327318863B8A7205805C4E694CE82391A67893D7129C53711A77CA52653026416B02CEDA617F7636F43BE83D8999D24EC994108AE3AAD68";
        String url2 = "http://2527.vod.myqcloud.com/2527_7cf9fdea310b11e5be00d51f0439f0b3.f0.mp4";
        String url = "/sdcard/bunny.MP4";
        String url9 = "http://10.66.93.74:8080/weishi2/sample1.f31.mp4";

        String proxyUrl = OskPlayer.getInstance().getUrl(url9);

        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mPlayer.setOnPreparedListener(mListener);
        mPlayer.setOnVideoSizeChangedListener(mListener);
        mPlayer.setVolume(1.0f, 1.0f);
        mPlayer.setMode(StateMediaPlayer.PLAY_MODE_AUDIO);
        try {
            mPrepareTimeStart = System.currentTimeMillis();
            mPlayer.setDataSource(proxyUrl);
            mPlayer.prepareAsync();
        } catch (IOException ex) {
            PlayerUtils.log(QLog.INFO, LOG_TAG, ex.toString());
        }
    }

    private class InternalListener implements View.OnClickListener,
            StateMediaPlayer.OnPreparedListener,
            StateMediaPlayer.OnVideoSizeChangedListener,
            TextureView.SurfaceTextureListener {

        @Override
        public void onClick(View view) {
            if (view.getId() == R.id.start_play) {
                startPlay();
            } else if (view.getId() == R.id.download_video) {
                String urls[] = {
                        "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4",
                        "https://dlied5.qq.com/ABCmouse/aol/content/Animation/33755/lleclass_cn_001_cid_33755_bc.mp4",
                        "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4"};
                VideoManager.getInstance().downloadVideosAsync(Arrays.asList(urls), 1, false, new VideoDownloadListener() {
                    @Override
                    public void onStart(String url) {
                        PlayerUtils.log(QLog.INFO, LOG_TAG, "onStart " + url);
                    }

                    @Override
                    public boolean onProgress(String url, long bytesWritten, long bytesTotal) {
                        PlayerUtils.log(QLog.INFO, LOG_TAG, "onProgress " + url + "," + bytesWritten + "/" + bytesTotal);
                        return true;
                    }

                    @Override
                    public void onError(String url, int code) {
                        PlayerUtils.log(QLog.INFO, LOG_TAG, "onError " + url + ",code=" + code);
                    }

                    @Override
                    public void onSuccess(String url, String localFile) {
                        PlayerUtils.log(QLog.INFO, LOG_TAG, "onSuccess " + url + ",localFile=" + localFile);
                    }

                    @Override
                    public void onCancel(String url) {
                        PlayerUtils.log(QLog.INFO, LOG_TAG, "onCancel " + url);
                    }
                }, null);
            }
        }

        @Override
        public void onVideoSizeChanged(IMediaPlayer IMediaPlayer, int videoWidth, int videoHeight) {
            ViewGroup.LayoutParams layoutParams = mVideoSurface.getLayoutParams();
            //
            //int containerHeight = ((View)mVideoSurface.getParent()).getMeasuredHeight();
            int containerWidth = ((View)mVideoSurface.getParent()).getMeasuredWidth();

            //
            int videoLayoutWidth = Math.min(containerWidth, videoWidth);
            float scaleRatio = (float) videoLayoutWidth / videoWidth;
            int videoLayoutHeight = (int) (videoHeight * scaleRatio);

            layoutParams.width = videoLayoutWidth;
            layoutParams.height = videoLayoutHeight;

            mVideoSurface.setLayoutParams(layoutParams);
        }

        @Override
        public void onPrepared(IMediaPlayer IMediaPlayer) {
            try {
                PlayerUtils.log(QLog.INFO, LOG_TAG, "onPrepared timeCost=" + (System.currentTimeMillis() - mPrepareTimeStart) + "ms");
                mPlayer.start();
                PlayerUtils.log(QLog.INFO, LOG_TAG, "start play");
            } catch (IMediaPlayer.InternalOperationException ex) {
                //ignore
            }
        }

        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i1) {
            mPlayer.setSurface(new Surface(surfaceTexture));
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i1) {

        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
            mPlayer.setSurface(null);
            return false;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {

        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            mPlayer.stop();
            mPlayer.release();
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), ex.toString(), Toast.LENGTH_LONG).show();
        }
    }
}
