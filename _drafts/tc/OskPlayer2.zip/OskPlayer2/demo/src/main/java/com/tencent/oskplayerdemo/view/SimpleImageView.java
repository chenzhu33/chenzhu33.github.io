package com.tencent.oskplayerdemo.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

public class SimpleImageView extends View {

    private int mMaxWidth = Integer.MAX_VALUE;
    private int mMaxHeight = Integer.MAX_VALUE;

    private Bitmap mBitmap;
    private static Paint sPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static Paint sTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    static {
        sTextPaint.setColor(0xffff0000); //red
        sTextPaint.setTypeface(Typeface.DEFAULT);
        sTextPaint.setTextSize(36);
    }

    public SimpleImageView(Context context) {
        super(context);
    }

    public SimpleImageView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public SimpleImageView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int widthSize = 0;
        int heightSize = 0;

        if (mBitmap != null) {
            widthSize = mBitmap.getWidth();
            heightSize = mBitmap.getHeight();
        }

        widthSize = resolveSize(widthSize, mMaxWidth, widthMeasureSpec);
        heightSize = resolveSize(heightSize, mMaxHeight, heightMeasureSpec);

        setMeasuredDimension(widthSize, heightSize);
    }

    private int resolveSize(int desiredSize, int maxSize, int measureSpec) {
        int result = desiredSize;
        final int specMode = MeasureSpec.getMode(measureSpec);
        final int specSize = MeasureSpec.getSize(measureSpec);

        switch (specMode) {
            case MeasureSpec.UNSPECIFIED:
                // parent says we can be as big as we want, Just don't be
                // larger than max size imposed on ourselves
                result = Math.min(desiredSize, maxSize);
                break;
             case MeasureSpec.AT_MOST:
                 // parent says we can be as big as we want, up to specSize
                 // Don't be larger than specSize, and don't be larger than
                 // the max size imposed on ourselves
                 result = Math.min(Math.min(desiredSize, specSize), maxSize);
                break;
             case MeasureSpec.EXACTLY:
                 // No choice, Do what we are told.
                 result = specSize;
                break;
        }
        return result;
    }

    public void setImageBitmap(Bitmap bitmap) {
        mBitmap = bitmap;
        requestLayout();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mBitmap != null) {
            canvas.drawBitmap(mBitmap, 0, 0, sPaint);
            int w = mBitmap.getWidth();
            int h = mBitmap.getHeight();
            String text = + w + "*" + h;
            canvas.drawText(text, 5, 48, sTextPaint);
        }

    }
}
