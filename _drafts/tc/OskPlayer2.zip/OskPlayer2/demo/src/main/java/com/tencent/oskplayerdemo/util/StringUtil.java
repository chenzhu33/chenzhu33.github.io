package com.tencent.oskplayerdemo.util;

public class StringUtil {
    public static String removeLastChar(String s) {
        if (s == null || s.length() == 0) {
            return s;
        }
        return s.substring(0, s.length()-1);
    }
}
