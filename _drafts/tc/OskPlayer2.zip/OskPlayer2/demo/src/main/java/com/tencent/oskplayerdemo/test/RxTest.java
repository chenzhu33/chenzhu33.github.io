package com.tencent.oskplayerdemo.test;

import android.util.Log;

import java.util.List;
import java.util.concurrent.TimeUnit;

import rx.Completable;
import rx.Observable;
import rx.Single;
import rx.SingleSubscriber;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

public class RxTest {

    public static final String LOG_TAG = "RxTest";

    public static void simpleTest() {
        Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
                Log.v(LOG_TAG, "do something");
                subscriber.onNext("hello world");
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.computation()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<String>() {
            @Override
            public void call(String s) {
                Log.v(LOG_TAG, s);
            }
        });
    }

    public static void simpleTest1() {
        Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
                Log.v(LOG_TAG, "do something");
                subscriber.onNext("hello world");
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.computation()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<String>() {
            @Override
            public void onCompleted() {
                Log.v(LOG_TAG, "simpleTest1 onCompleted");
            }

            @Override
            public void onError(Throwable e) {
                Log.v(LOG_TAG, "simpleTest1 onError");
            }

            @Override
            public void onNext(String s) {
                Log.v(LOG_TAG, "simpleTest1 onNext");
            }
        });
    }

    public static void singleTest() {
        Single.create(new Single.OnSubscribe<String>() {
            @Override
            public void call(SingleSubscriber<? super String> singleSubscriber) {
                Log.v(LOG_TAG, "do something");
                singleSubscriber.onSuccess("hello world");
            }
        }).subscribeOn(Schedulers.computation()).observeOn(AndroidSchedulers.mainThread()).subscribe(new SingleSubscriber<String>() {
            @Override
            public void onSuccess(String value) {
                Log.v(LOG_TAG, "singleTest onNext " + value);
            }

            @Override
            public void onError(Throwable error) {
                Log.v(LOG_TAG, "singleTest onError " + error);
            }
        });
    }

    public static void completableTest() {
        Completable.create(new Completable.CompletableOnSubscribe() {
            @Override
            public void call(Completable.CompletableSubscriber completableSubscriber) {
                Log.v(LOG_TAG, "do something");
                completableSubscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.computation()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Completable.CompletableSubscriber() {
            @Override
            public void onCompleted() {
                Log.v(LOG_TAG, "completableTest onCompleted");
            }

            @Override
            public void onError(Throwable e) {
                Log.v(LOG_TAG, "completableTest onError");
            }

            @Override
            public void onSubscribe(Subscription d) {
                Log.v(LOG_TAG, "onSubscribe " + d);
            }
        });
    }

    public static void mergeDelayErrorTest() {
        Observable.mergeDelayError(
                Observable.just("Hello1"),
                Observable.error(new RuntimeException()),
                Observable.just("Hello2"),
                Observable.error(new IllegalStateException("xx"))
                )
                .subscribe(new Action1<Object>() {
                    @Override
                    public void call(Object o) {
                        Log.v(LOG_TAG, "onNext" + o);
                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable throwable) {
                        Log.v(LOG_TAG, "onError" + throwable);
                    }
                });
    }

    public static void onErrorReturnTest() {
        Observable.create(new Observable.OnSubscribe<Integer>() {
            @Override
            public void call(Subscriber<? super Integer> subscriber) {
                for (int i=0; i < 10; i++) {
                    if (i < 5) {
                        subscriber.onNext(i);
                    } else {
                        subscriber.onError(new IllegalStateException("xx"));
                    }
                }
            }
        }).onErrorReturn(new Func1<Throwable, Integer>() {
            @Override
            public Integer call(Throwable throwable) {
                return -1;
            }
        }).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.computation()).subscribe(new Subscriber<Integer>() {
            @Override
            public void onCompleted() {
                Log.v(LOG_TAG, "onErrorReturnTest onComplete");
            }

            @Override
            public void onError(Throwable e) {
                Log.v(LOG_TAG, "onErrorReturnTest onError" + e);
            }

            @Override
            public void onNext(Integer integer) {
                Log.v(LOG_TAG, "onErrorReturnTest onNext" + integer);
            }
        });
    }

    public static void onErrorResumeTest() {
        Observable.create(new Observable.OnSubscribe<Integer>() {
            @Override
            public void call(Subscriber<? super Integer> subscriber) {
                for (int i=0; i < 10; i++) {
                    if (i < 5) {
                        subscriber.onNext(i);
                    } else {
                        subscriber.onError(new IllegalStateException("xx"));
                    }
                }
            }
        }).onErrorResumeNext(new Func1<Throwable, Observable<? extends Integer>>() {
            @Override
            public Observable<? extends Integer> call(Throwable throwable) {
                return Observable.just(100,101,102);
            }
        }).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.computation()).subscribe(new Subscriber<Integer>() {
            @Override
            public void onCompleted() {
                Log.v(LOG_TAG, "onErrorReturnTest onComplete");
            }

            @Override
            public void onError(Throwable e) {
                Log.v(LOG_TAG, "onErrorReturnTest onError" + e);
            }

            @Override
            public void onNext(Integer integer) {
                Log.v(LOG_TAG, "onErrorReturnTest onNext" + integer);
            }
        });
    }

    public static void onExceptionResumeNext() {
        Observable.create(new Observable.OnSubscribe<Integer>() {
            @Override
            public void call(Subscriber<? super Integer> subscriber) {
                for (int i=0; i < 10; i++) {
                    if (i < 5) {
                        subscriber.onNext(i);
                    } else {
                        // subscriber.onError(new IllegalStateException("xx")); // continue emmit 101,102,103
                        subscriber.onError(null); // not continue 101,102,103
                    }
                }
            }
        }).onExceptionResumeNext(Observable.just(101,102,103))
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeOn(Schedulers.computation())
            .subscribe(new Subscriber<Integer>() {
            @Override
            public void onCompleted() {
                Log.v(LOG_TAG, "onExceptionResumeNext onComplete");
            }

            @Override
            public void onError(Throwable e) {
                Log.v(LOG_TAG, "onExceptionResumeNext onError" + e);
            }

            @Override
            public void onNext(Integer integer) {
                Log.v(LOG_TAG, "onExceptionResumeNext onNext" + integer);
            }
        });
    }

    public static void mergeTest() {
        Observable<Integer> seq1 = Observable.just(1,2,3);
        Observable<Integer> seq2 = Observable.just(4,5,6);
        Observable.merge(seq1, seq2).observeOn(Schedulers.computation()).subscribeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<Integer>() {
            @Override
            public void onCompleted() {
                Log.v(LOG_TAG, "mergeTest onCompleted");
            }

            @Override
            public void onError(Throwable e) {
                Log.v(LOG_TAG, "mergeTest onError " + e);
            }

            @Override
            public void onNext(Integer integer) {
                Log.v(LOG_TAG, "mergeTest onNext " + integer);
            }
        });
    }

    public static void flatMapTest() {
        // flatmap
        /*
        o=10000
        o=10001
        o=10002
        o=20000
        o=20002
        o=20004
        o=30000
        o=30003
        o=30006
        o=40000
        o=40004
        o=40008
        onCompleted
        */
        Observable.just(1,2,3,4).flatMap(new Func1<Integer, Observable<Long>>() {
            @Override
            public Observable<Long> call(final Integer integer) {
                return Observable.create(new Observable.OnSubscribe<Long>() {
                    @Override
                    public void call(Subscriber<? super Long> subscriber) {
                        subscriber.onNext(integer*10000L);
                        subscriber.onNext(integer*10001L);
                        subscriber.onNext(integer*10002L);
                        subscriber.onCompleted();
                    }
                });
            }
        }).map(new Func1<Long, String>() {
            @Override
            public String call(Long o) {
                return o.toString();
            }
        }).subscribeOn(Schedulers.computation())
                .observeOn(Schedulers.computation())
                .subscribe(new Subscriber<String>() {
                    @Override
                    public void onCompleted() {
                        Log.v(LOG_TAG, "onCompleted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.v(LOG_TAG, "onError", e);
                    }

                    @Override
                    public void onNext(String s) {
                        Log.v(LOG_TAG, "o=" + s);
                    }
                });
    }

    public static void switchMapTest() {
        // switchMap
        Log.v(LOG_TAG, "switchMapTest");
        Observable.just(1,2,3,4).flatMap(new Func1<Integer, Observable<Long>>() {
            @Override
            public Observable<Long> call(final Integer integer) {
                return Observable.create(new Observable.OnSubscribe<Long>() {
                    @Override
                    public void call(Subscriber<? super Long> subscriber) {
                        subscriber.onNext(integer*10000L);
                        subscriber.onNext(integer*10001L);
                        subscriber.onNext(integer*10002L);
                        subscriber.onCompleted();
                    }
                });
            }
        }).map(new Func1<Long, String>() {
            @Override
            public String call(Long o) {
                return o.toString();
            }
        }).subscribeOn(Schedulers.computation())
                .observeOn(Schedulers.computation())
                .subscribe(new Subscriber<String>() {
                    @Override
                    public void onCompleted() {
                        Log.v(LOG_TAG, "onCompleted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.v(LOG_TAG, "onError", e);
                    }

                    @Override
                    public void onNext(String s) {
                        Log.v(LOG_TAG, "o=" + s);
                    }
                });
    }

    public static void ignoreErrorTest() {
        // output 0,1,2,3,4,-1,6,7,8,9
        Observable.create(new Observable.OnSubscribe<Integer>() {
            @Override
            public void call(Subscriber<? super Integer> subscriber) {
                for (int i=0; i < 10; i++){
                    subscriber.onNext(i);
                    // WARNING: error can not happen here !!!
                }
            }
        }).flatMap(new Func1<Integer, Observable<Integer>>() {
            @Override
            public Observable<Integer> call(final Integer integer) {
                return Observable.create(new Observable.OnSubscribe<Integer>() {
                    @Override
                    public void call(Subscriber<? super Integer> subscriber) {
                        if (integer == 5) {
                            // this is an error
                            throw new IllegalStateException("error occurred");
                        }
                        subscriber.onNext(integer); // Rethrow as it is
                    }
                }).onErrorReturn(new Func1<Throwable, Integer>() {
                    @Override
                    public Integer call(Throwable throwable) {
                        return -1; // EAT ERROR!!
                    }
                });
            }
        }).subscribeOn(Schedulers.computation()).observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<Integer>() {
            @Override
            public void onCompleted() {
                Log.v(LOG_TAG, "ignoreErrorTest onCompleted");
            }

            @Override
            public void onError(Throwable e) {
                Log.v(LOG_TAG, "ignoreErrorTest onError " + e);
            }

            @Override
            public void onNext(Integer integer) {
                Log.v(LOG_TAG, "ignoreErrorTest onNext " + integer);
            }
        });
    }

    public static void missingBackPressureException() {
        Observable.interval(10, TimeUnit.MILLISECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.computation())
                .subscribe(new Subscriber<Long>() {
                    @Override
                    public void onCompleted() {
                        Log.v(LOG_TAG, "missingBackPressureException onCompleted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        // will throw MissingBackpressureException
                        Log.v(LOG_TAG, "missingBackPressureException onError " + e);
                    }

                    @Override
                    public void onNext(Long aLong) {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                    }
                });
    }

    public static void missingBackPressureExceptionFix() {
        Observable.interval(10, TimeUnit.MILLISECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.computation())
                .buffer(10, TimeUnit.MILLISECONDS)
                .subscribe(new Subscriber<List<Long>>() {
                    @Override
                    public void onCompleted() {
                        Log.v(LOG_TAG, "missingBackPressureException onCompleted");
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.v(LOG_TAG, "missingBackPressureException onError " + e);
                    }

                    @Override
                    public void onNext(List<Long> longList) {
                        for (Long l : longList) {
                            Log.v(LOG_TAG, l + "");
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException ex) {
                                ex.printStackTrace();
                            }
                        }
                    }
                });
    }
}
