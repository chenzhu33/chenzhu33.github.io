package com.tencent.oskplayerdemo;

import android.app.Activity;
import android.os.Bundle;

import com.tencent.oskplayer.OskPlayer;
import com.tencent.oskplayer.proxy.PreloadListener;
import com.tencent.oskplayer.util.PlayerUtils;
import com.tencent.oskplayer.util.QLog;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by leoliu on 17/3/7.
 */

public class PreloadDemoActivity extends Activity {
    public static final String LOG_TAG = "PreloadDemoActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startPreload();
    }

    void startPreload() {
        String urlNormal = "http://2527.vod.myqcloud.com/2527_7cf9fdea310b11e5be00d51f0439f0b3.f0.mp4";
        String urlM3u8 = "http://qzonelivehls.tc.qq.com/vbigts.tc.qq.com/izxK-vFdRNoCRexyyJrcl2MhHc3vRf83AtQP_2BmMXR5zvnr8floO8wBNdNMjNBpiEVgbIMtGwo/1057_9b2ecfd16a4446e9af925facf12a0db2.h0.ts.m3u8?ver=4";
        String[] urls = {urlM3u8};
        OskPlayer.getInstance().preloadMedia(Arrays.asList(urls), 2, 65536, mPreloadListener);
    }

    private PreloadListener mPreloadListener = new PreloadListener() {
        @Override
        public void onStart(String url) {
            PlayerUtils.log(QLog.INFO, LOG_TAG, "preload start" + url);
        }

        @Override
        public void onUpdate(String url, long cachedBytes, long maxCachedBytesAllowed,  long totalLength) {
            PlayerUtils.log(QLog.INFO, LOG_TAG, "preload update cached bytes " + cachedBytes + ", totalLength=" + totalLength + ", url=" + url);
        }

        @Override
        public void onFinish(String url) {
            PlayerUtils.log(QLog.INFO, LOG_TAG, "preload finish " + url);
        }
    };
}
