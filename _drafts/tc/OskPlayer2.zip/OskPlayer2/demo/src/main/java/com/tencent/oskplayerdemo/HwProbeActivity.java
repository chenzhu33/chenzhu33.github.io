package com.tencent.oskplayerdemo;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.tencent.oskplayer.OskPlayer;
import com.tencent.oskplayer.miscellaneous.DecodeProbe;
import com.tencent.oskplayer.miscellaneous.HardwareDecodeProbe;
import com.tencent.oskplayer.miscellaneous.SoftwareDecodeProbe;
import com.tencent.oskplayer.util.PlayerUtils;
import com.tencent.oskplayer.util.QLog;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class HwProbeActivity extends Activity implements HardwareDecodeProbe.HwProbeCallback, SoftwareDecodeProbe.SwProbeCallback{
    public static final String TAG = "HwProbeActivity";

    private static final int COLOR_FormatI420 = 1;
    private static final int COLOR_FormatNV21 = 2;

    public static final int HW_PROBE_DONE = 1;
    public static final int SW_PROBE_DONE = 2;
    public static final int ALL_PROBE_DONE = 3;

    private TextView mTvCpuInfo;
    private TextView mTvHwDone;
    private TextView mTvSwDone;
    private TextView mTvProbeDone;
    private TextView mTvModelName;

    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            int result = msg.arg1;
            switch(msg.what) {
                case HW_PROBE_DONE:
                    int hwCost = msg.arg2;
                    mTvHwDone.setText("hw probe done, result="+result+", avg cost="+hwCost);
                    break;
                case SW_PROBE_DONE:
                    int swCost = msg.arg2;
                    mTvSwDone.setText("sw probe done, result="+result+", avg cost="+swCost);
                    break;
                case ALL_PROBE_DONE:
                    int hwCost1 = msg.arg2;
                    int swCost1 = (int)msg.obj;
                    mTvProbeDone.setText("probe done, result="+result+", hw avg cost="+hwCost1+", sw avg cost="+swCost1);
                    break;
            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_hw_probe);

        mTvHwDone = findViewById(R.id.tv_hw_done);
        mTvSwDone = findViewById(R.id.tv_sw_done);
        mTvProbeDone = findViewById(R.id.tv_probe_done);
        mTvCpuInfo = findViewById(R.id.tv_cpuinfo);
        mTvModelName = findViewById(R.id.tv_modelname);

        mTvCpuInfo.setText(Build.HARDWARE);
        mTvModelName.setText(Build.MODEL);
        PlayerUtils.log(QLog.DEBUG, TAG, "model name="+Build.MODEL);


        findViewById(R.id.btn_hw_probe).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                //copyFromAssets();
                                String h265Url = "android.resource://" + getPackageName() + "/" + R.raw.h265probe;
                                String proxyUrl = OskPlayer.getInstance().getUrl(h265Url);

                                DecodeProbe.getInstance().setHwProbeCallback(HwProbeActivity.this);
                                DecodeProbe.getInstance().addSaveFrame(1, 50, 100);
                                int result = DecodeProbe.getInstance().hwProbe(proxyUrl);
                                Message msg = mHandler.obtainMessage();
                                msg.what = HW_PROBE_DONE;
                                msg.arg1 = result;
                                msg.arg2 = (int)DecodeProbe.getInstance().getHwDecodeAvgCost();
                                msg.sendToTarget();
                            }
                        }).start();
                    }
                }).start();
            }
        });
        findViewById(R.id.btn_sw_probe).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                //copyFromAssets();

                                String h265Url = "android.resource://" + getPackageName() + "/" + R.raw.h265probe;
                                String proxyUrl = OskPlayer.getInstance().getUrl(h265Url);

                                DecodeProbe.getInstance().setSwProbeCallback(HwProbeActivity.this);
                                DecodeProbe.getInstance().addSaveFrame(1, 50, 100);
                                int result = DecodeProbe.getInstance().swProbe(proxyUrl);
                                Message msg = mHandler.obtainMessage();
                                msg.what = SW_PROBE_DONE;
                                msg.arg1 = result;
                                msg.arg2 = (int)DecodeProbe.getInstance().getSwDecodeAvgCost();
                                msg.sendToTarget();
                                DecodeProbe.getInstance().setSwProbeCallback(null);
                            }
                        }).start();
                    }
                }).start();
            }
        });
        findViewById(R.id.btn_probe).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        DecodeProbe.getInstance().setHwProbeCallback(HwProbeActivity.this);
                        DecodeProbe.getInstance().setSwProbeCallback(HwProbeActivity.this);
                        DecodeProbe.getInstance().addSaveFrame(1, 50, 100);

                        String h265Url = "android.resource://" + getPackageName() + "/" + R.raw.h265probe;
                        String proxyUrl = OskPlayer.getInstance().getUrl(h265Url);

                        int result = DecodeProbe.getInstance().probe(proxyUrl);
                        Message msg = mHandler.obtainMessage();
                        msg.what = ALL_PROBE_DONE;
                        msg.arg1 = result;
                        msg.arg2 = (int)DecodeProbe.getInstance().getHwDecodeAvgCost();
                        msg.obj = (int)DecodeProbe.getInstance().getSwDecodeAvgCost();
                        msg.sendToTarget();
                        DecodeProbe.getInstance().setSwProbeCallback(null);
                    }
                }).start();
            }
        });
    }

    @Override
    public void onHwProbeOneFrame(int frameNo) {
        PlayerUtils.log(QLog.DEBUG, TAG, "[onHwProbeOneFrame] frameNo="+frameNo);
    }

    @Override
    public void onSwProbeOneFrame(int frameNo) {
        PlayerUtils.log(QLog.DEBUG, TAG, "[onSwProbeOneFrame] frameNo="+frameNo);
    }

    private void copyFromAssets() {
        try {
            InputStream is = getAssets().open("probe_video.mp4");
            FileOutputStream os = new FileOutputStream(new File("/sdcard/1.mp4"));
            byte[] buffer = new byte[1024];
            int byteCount = 0;
            while ((byteCount = is.read(buffer)) != -1) {
                os.write(buffer, 0, byteCount);
            }
            os.flush();
            os.close();
            is.close();
        } catch (Exception e) {
            PlayerUtils.log(QLog.ERROR, TAG, e.toString());
        }
    }

//    private void probe() {
//        Log.d(TAG, "[probe] thread="+Thread.currentThread().getName());
//        MediaCodec decoder = null;
//        MediaExtractor extractor = null;
//        File file = new File("/mnt/sdcard/1.mp4");
//        if(!file.canRead()) {
//            Log.e(TAG, "[probe] file can not read");
//            return;
//        }
//
//        try {
//            extractor = new MediaExtractor();
//            extractor.setDataSource(file.getAbsolutePath());
//
//            int videoTrack = selectVideoTrack(extractor);
//            Log.d(TAG, "[probe] video track ="+videoTrack);
//            if(videoTrack < 0) {
//                return;
//            }
//            extractor.selectTrack(videoTrack);
//
//            MediaFormat videoFormat = extractor.getTrackFormat(videoTrack);
//            String mimetype = videoFormat.getString(MediaFormat.KEY_MIME);
//            Log.d(TAG, "[probe] video format="+mimetype);
//            decoder = MediaCodec.createDecoderByType(mimetype);
//            //need to check wether support this color format
//            videoFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
//            Surface surface = new Surface(mTextureView.getSurfaceTexture());
//            decoder.configure(videoFormat, surface, null, 0);
//            decoder.start();
//
//            doExtract(extractor, videoTrack, decoder);
//
//        } catch (IOException e) {
//            Log.e(TAG, "[probe]", e);
//        } finally {
//            if(null != decoder) {
//                decoder.stop();
//                decoder.release();
//            }
//            if(null != extractor) {
//                extractor.release();
//            }
//        }
//    }
//
//    private int selectVideoTrack(MediaExtractor extractor) {
//        int count = extractor.getTrackCount();
//        for(int i = 0; i < count; ++i) {
//            MediaFormat format = extractor.getTrackFormat(i);
//            String mimetype = format.getString(MediaFormat.KEY_MIME);
//            if(mimetype.startsWith("video/")) {
//                return i;
//            }
//        }
//        return -1;
//    }
//
//    @TargetApi(21)
//    private void doExtract(MediaExtractor extractor, int videoTrack, MediaCodec decoder) {
//        if(Build.VERSION.SDK_INT < 21) {
//            return;
//        }
//
//        boolean outputDone = false;
//        boolean inputDone = false;
//        MediaCodec.BufferInfo bufferInfo;
//
//        while(!outputDone) {
//            try {
//                Thread.sleep(20);
//            } catch(Exception e) {
//                Log.w(TAG, "[doExtract]", e);
//            }
//            if(!inputDone) {
//                int inputIndex = decoder.dequeueInputBuffer(10000);
//                Log.d(TAG, "[doExtract] input index=" + inputIndex);
//                if (inputIndex < 0) {
//                    return;
//                } else {
//                    ByteBuffer inputBuffer = decoder.getInputBuffer(inputIndex);
//                    int chunkSize = extractor.readSampleData(inputBuffer, 0);
//                    if (chunkSize < 0) {
//                        decoder.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
//                        Log.d(TAG, "[doExtract] queue input EOS");
//                        inputDone = true;
//                    } else {
//                        long presentationTimeUs = extractor.getSampleTime();
//                        decoder.queueInputBuffer(inputIndex, 0, chunkSize, presentationTimeUs, 0);
//                        extractor.advance();
//                    }
//                }
//            }
//
//            if(!outputDone) {
//                bufferInfo = new MediaCodec.BufferInfo();
//                int outputIndex = decoder.dequeueOutputBuffer(bufferInfo, 10000);
//                Log.d(TAG, "[doExtract] output index=" + outputIndex);
//                if (outputIndex < 0) {
//                    Log.d(TAG, "failed to dequeue output buffer, reason="+outputIndex);
//                } else {
//                    if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
//                        Log.d(TAG, "[doExtract] queue output EOS");
//                        outputDone = true;
//                    }
//
//                    boolean render = bufferInfo.size > 0;
//                    if (render) {
//                        Image image = decoder.getOutputImage(outputIndex);
//                        int imageFormat = image.getFormat();
//                        Log.d(TAG, "[doExtract] image format=" + imageFormat);
//
//                        //compressToJpeg("/mnt/sdcard/1.jpg", image);
////                        dumpFile("/mnt/sdcard/1.yuv", getDataFromImage(image, COLOR_FormatI420));
//
//                        image.close();
//                    }
//                    decoder.releaseOutputBuffer(outputIndex, render);
//                }
//            }
//        }
//    }
//
//    private static void dumpFile(String fileName, byte[] data) {
//        FileOutputStream outStream;
//        try {
//            outStream = new FileOutputStream(fileName);
//        } catch (FileNotFoundException e) {
//            Log.e(TAG, "[dumpFile]", e);
//            return;
//        }
//
//        try {
//            outStream.write(data);
//            outStream.close();
//        } catch (IOException e) {
//            Log.e(TAG, "[dumpFile]", e);
//        } finally {
//            try {
//                if (null != outStream) {
//                    outStream.close();
//                }
//            } catch (Exception e) {
//                Log.e(TAG, "[dumpFile]", e);
//            }
//        }
//    }
//
//    @TargetApi(21)
//    private void compressToJpeg(String fileName, Image image) {
//        FileOutputStream outStream;
//        try {
//            outStream = new FileOutputStream("/mnt/sdcard/1.jpg");
//        } catch (IOException ioe) {
//            throw new RuntimeException("Unable to create output file ", ioe);
//        }
//        Rect rect = image.getCropRect();
//        YuvImage yuvImage = new YuvImage(getDataFromImage(image, COLOR_FormatNV21), ImageFormat.NV21, rect.width(), rect.height(), null);
//        yuvImage.compressToJpeg(rect, 100, outStream);
//    }
//
//    @TargetApi(21)
//    private static boolean isImageFormatSupported(Image image) {
//        int format = image.getFormat();
//        switch (format) {
//            case ImageFormat.YUV_420_888:
//            case ImageFormat.NV21:
//            case ImageFormat.YV12:
//                return true;
//        }
//        return false;
//    }
//
//    @TargetApi(21)
//    private static byte[] getDataFromImage(Image image, int colorFormat) {
//        if (colorFormat != COLOR_FormatI420 && colorFormat != COLOR_FormatNV21) {
//            throw new IllegalArgumentException("only support COLOR_FormatI420 " + "and COLOR_FormatNV21");
//        }
//        if (!isImageFormatSupported(image)) {
//            throw new RuntimeException("can't convert Image to byte array, format " + image.getFormat());
//        }
//        Rect crop = image.getCropRect();
//        int format = image.getFormat();
//        int width = crop.width();
//        int height = crop.height();
//        Image.Plane[] planes = image.getPlanes();
//        byte[] data = new byte[width * height * ImageFormat.getBitsPerPixel(format) / 8];
//        byte[] rowData = new byte[planes[0].getRowStride()];
//        Log.v(TAG, "get data from " + planes.length + " planes");
//        int channelOffset = 0;
//        int outputStride = 1;
//        for (int i = 0; i < planes.length; i++) {
//            switch (i) {
//                case 0:
//                    channelOffset = 0;
//                    outputStride = 1;
//                    break;
//                case 1:
//                    if (colorFormat == COLOR_FormatI420) {
//                        channelOffset = width * height;
//                        outputStride = 1;
//                    } else if (colorFormat == COLOR_FormatNV21) {
//                        channelOffset = width * height + 1;
//                        outputStride = 2;
//                    }
//                    break;
//                case 2:
//                    if (colorFormat == COLOR_FormatI420) {
//                        channelOffset = (int) (width * height * 1.25);
//                        outputStride = 1;
//                    } else if (colorFormat == COLOR_FormatNV21) {
//                        channelOffset = width * height;
//                        outputStride = 2;
//                    }
//                    break;
//            }
//            ByteBuffer buffer = planes[i].getBuffer();
//            int rowStride = planes[i].getRowStride();
//            int pixelStride = planes[i].getPixelStride();
//
//            Log.v(TAG, "pixelStride " + pixelStride);
//            Log.v(TAG, "rowStride " + rowStride);
//            Log.v(TAG, "width " + width);
//            Log.v(TAG, "height " + height);
//            Log.v(TAG, "buffer size " + buffer.remaining());
//
//            int shift = (i == 0) ? 0 : 1;
//            int w = width >> shift;
//            int h = height >> shift;
//            buffer.position(rowStride * (crop.top >> shift) + pixelStride * (crop.left >> shift));
//            for (int row = 0; row < h; row++) {
//                int length;
//                if (pixelStride == 1 && outputStride == 1) {
//                    length = w;
//                    buffer.get(data, channelOffset, length);
//                    channelOffset += length;
//                } else {
//                    length = (w - 1) * pixelStride + 1;
//                    buffer.get(rowData, 0, length);
//                    for (int col = 0; col < w; col++) {
//                        data[channelOffset] = rowData[col * pixelStride];
//                        channelOffset += outputStride;
//                    }
//                }
//                if (row < h - 1) {
//                    buffer.position(buffer.position() + rowStride - length);
//                }
//            }
//            Log.v(TAG, "Finished reading data from plane " + i);
//        }
//        return data;
//    }
}
