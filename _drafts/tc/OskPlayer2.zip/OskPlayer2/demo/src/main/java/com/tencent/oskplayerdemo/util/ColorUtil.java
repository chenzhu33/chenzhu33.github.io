package com.tencent.oskplayerdemo.util;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.support.annotation.ColorInt;
import android.support.annotation.NonNull;
import android.support.annotation.Size;
import android.util.Log;

import com.tencent.oskplayer.util.PlayerUtils;

public class ColorUtil {
    public static final String TAG = "ColorUtil";

    public static @ColorInt int lighten(@ColorInt int color, float value) {
        float[] hsl = colorToHSL(color);
        hsl[2] += value / 100;
        hsl[2] = Math.max(0f, Math.min(hsl[2], 1f));
        return HSLToColor(hsl);
    }

    public static @ColorInt int darken(@ColorInt int color, float value) {
        float[] hsl = colorToHSL(color);
        hsl[2] -= value / 100;
        hsl[2] = Math.max(0f, Math.min(hsl[2], 1f));
        return HSLToColor(hsl);
    }

    public static @NonNull @Size(3) float[] colorToHSL(@ColorInt int color) {
        return colorToHSL(color, new float[3]);
    }

    public static @NonNull @Size(3) float[] colorToHSL(@ColorInt int color, @NonNull @Size(3) float[] hsl) {
        final float r = Color.red(color) / 255f;
        final float g = Color.green(color) / 255f;
        final float b = Color.blue(color) / 255f;

        final float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        hsl[2] = (max + min) / 2;

        if (max == min) {
            hsl[0] = hsl[1] = 0;
        } else {
            float d = max - min;
            //noinspection Range
            hsl[1] = (hsl[2] > 0.5f) ? d / (2 - max - min) : d / (max + min);
            if (max == r) hsl[0] = (g - b) / d + (g < b ? 6 : 0);
            else if (max == g) hsl[0] = (b - r) / d + 2;
            else if (max == b) hsl[0] = (r - g) / d + 4;
            hsl[0] /= 6;
        }

        return hsl;
    }

    public static @ColorInt int HSLToColor(@NonNull @Size(3) float[] hsl) {
        float r, g, b;

        final float h = hsl[0];
        final float s = hsl[1];
        final float l = hsl[2];

        if (s == 0) {
            r = g = b = l;
        } else {
            float q = l < 0.5f ? l * (1 + s) : l + s - l * s;
            float p = 2 * l - q;
            r = hue2rgb(p, q, h + 1f/3);
            g = hue2rgb(p, q, h);
            b = hue2rgb(p, q, h - 1f/3);
        }

        return Color.rgb((int) (r*255), (int) (g*255), (int) (b*255));
    }

    private static float hue2rgb(float p, float q, float t) {
        if(t < 0) t += 1;
        if(t > 1) t -= 1;
        if(t < 1f/6) return p + (q - p) * 6 * t;
        if(t < 1f/2) return q;
        if(t < 2f/3) return p + (q - p) * (2f/3 - t) * 6;
        return p;
    }

    public static void testRgbHsvConversion() {
        int color = Color.rgb(206,43,55);
        int red = Color.red(color);
        int green = Color.green(color);
        int blue = Color.blue(color);
        Log.v(TAG, "rgb:" + red + ", " + green + ", " + blue);
        float[] hsv = new float[3];
        Color.RGBToHSV(red, green, blue, hsv);
        int rgb = Color.HSVToColor(hsv);
        int r = Color.red(rgb);
        int g = Color.green(rgb);
        int b = Color.blue(rgb);
        Log.v(TAG, "rgb:" + r + "," + g + "," + b);
    }

    public static int getRandomHsvColor() {
        float[] hsv = new float[3];
        hsv[0] = 360f * (float) Math.random();
        hsv[1] = 1.0f;
        hsv[2] = 0.85f;
        return Color.HSVToColor(hsv);
    }

    public static int[] getRandomComplementaryHsvColor() {
        float[] hsv = new float[3];
        float[] hsvComplementary = new float[3];
        float hue = 360f * (float) Math.random();
        float hueComplementary = (hue + 180f) % 360;
        float saturation = 1.0f;
        float value = 0.85f;
        hsv[0] = hue;
        hsv[1] = saturation;
        hsv[2] = value;
        hsvComplementary[0] = hueComplementary;
        hsvComplementary[1] = saturation;
        hsvComplementary[2] = value;
        int[] colors = new int[2];
        colors[0] = Color.HSVToColor(hsv);
        colors[1] = Color.HSVToColor(hsvComplementary);
        return colors;
    }

    //https://docsify.js.org
    public static int getRandomHslColor() {
        float[] hsv = new float[3];
        hsv[0] = (float) Math.random();
        hsv[1] = 1.0f;
        hsv[2] = 0.85f;
        return HSLToColor(hsv);
    }

    public static int[] getRandomComplementaryHslColor() {
        float[] hsl = new float[3];
        float[] hslComplementary = new float[3];
        float hue = (float) Math.random();
        float hueComplementary = (hue + 0.5f) % 1.0f;
        float saturation = 1.0f;
        float lightness = 0.85f;
        hsl[0] = hue;
        hsl[1] = saturation;
        hsl[2] = lightness;
        hslComplementary[0] = hueComplementary;
        hslComplementary[1] = saturation;
        hslComplementary[2] = lightness;
        int[] colors = new int[2];
        colors[0] = HSLToColor(hsl);
        colors[1] = HSLToColor(hslComplementary);
        Log.v(TAG, "color0:" + Integer.toHexString(colors[0]) + ",color1:" + Integer.toHexString(colors[1]));
        return colors;
    }

    //https://stackoverflow.com/questions/13929877/how-to-make-gradient-background-in-android
    //https://stackoverflow.com/questions/4381033/multi-gradient-shapes
    public static Drawable getRandomDosifyGradientDrawable() {
        int[] colors = getRandomComplementaryHslColor();
        return new GradientDrawable(GradientDrawable.Orientation.TR_BL, colors);
    }
}
