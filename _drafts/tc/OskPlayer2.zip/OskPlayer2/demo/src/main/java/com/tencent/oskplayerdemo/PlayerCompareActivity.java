package com.tencent.oskplayerdemo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.SurfaceTexture;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

//import com.google.android.exoplayer2.util.LibraryLoader;
import com.google.android.exoplayer2.ext.mediaplayer.ExoMediaPlayer;
import com.tencent.oskplayer.OskPlayer;
import com.tencent.oskplayer.PlayerConfig;
import com.tencent.oskplayer.player.OskExoMediaPlayer;
import com.tencent.oskplayer.proxy.VideoManager;
import com.tencent.oskplayer.proxy.VideoProxy;
import com.tencent.oskplayer.report.VideoResultCode;
import com.tencent.oskplayer.service.DNSService;
import com.tencent.oskplayer.ui.SafeTextureView;
import com.tencent.oskplayer.util.PlayerUtils;
import com.tencent.oskplayer.util.QLog;
import com.tencent.oskplayerdemo.util.PlatformUtil;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import tv.danmaku.ijk.media.player.IMediaPlayer;
import tv.danmaku.ijk.media.player.IjkMediaPlayer;

/**
 * Created by leoliu on 2018/5/26.
 */

public class PlayerCompareActivity extends Activity {

    public static final String LOG_TAG = "PlayerCompareActivity";

    IMediaPlayer mIjkPlayer;
    IMediaPlayer mOskExoPlayer;

    private InternalListener oskExoListener;
    private InternalListener ijkListener;

    private Handler mMainHandler;
    private Setting mSetting;

    private CommonViews mViews = null;

    public static final int AUDIO_LEVEL_BAR_MAX = 1000;

    public static final int REQUEST_CODE_SELECT_FILE = 0x1;
    public static final int REQUEST_EXTERNAL_STORAGE = 0x2;

    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    public static final String INTENT_KEY_ENABLE_EXO_PLAY = "enable_exo_play";
    public static final String INTENT_KEY_ENABLE_IJK_PLAY = "enable_ijk_play";
    public static final String INTENT_KEY_VIDEO_URL = "video_url";
    public static final String INTENT_KEY_PLAY_DIRECT = "play_direct";

    private boolean mExtraEnableExoPlay = false;
    private boolean mExtraEnableIjkPlay = false;
    private boolean mExtraPlayDirect = false;
    private String mExtraVideoUrl = null;

    private boolean mNewPlayer = false;

    private String mCurrentUuid = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        if (intent != null) {
            mExtraEnableExoPlay = intent.getBooleanExtra(INTENT_KEY_ENABLE_EXO_PLAY, false);
            mExtraEnableIjkPlay = intent.getBooleanExtra(INTENT_KEY_ENABLE_IJK_PLAY, false);
            mExtraPlayDirect = intent.getBooleanExtra(INTENT_KEY_PLAY_DIRECT, false);
            mExtraVideoUrl = intent.getStringExtra(INTENT_KEY_VIDEO_URL);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        initData();
        initUI();
    }

    private void initData() {
        mIjkPlayer = new IjkMediaPlayer();
        mOskExoPlayer = new OskExoMediaPlayer();
        mNewPlayer = true;
        mMainHandler = new Handler(Looper.getMainLooper());
        mSetting = new Setting();
    }

    private void initUI() {
        setContentView(R.layout.player_compare_activity);
        final Button startPlay = (Button) findViewById(R.id.start_play);
        final Button selectMedia = (Button) findViewById(R.id.select_video);
        final EditText mediaPath = (EditText) findViewById(R.id.media_path);

        mViews = new CommonViews();
        mViews.mediaPath = mediaPath;
        mSetting.initViewStatus(mViews);

        final ViewHolder vhOsk = new ViewHolder();
        vhOsk.textureView = (SafeTextureView) findViewById(R.id.textureview_1);
        vhOsk.seekBar = (SeekBar) findViewById(R.id.seekbar_1);
        vhOsk.audioLevelBar = (ProgressBar) findViewById(R.id.audiolevelbar_1);
        vhOsk.txtProgress = (TextView) findViewById(R.id.video_txt_progress_1);
        vhOsk.txtDuration = (TextView) findViewById(R.id.video_txt_duration_1);
        vhOsk.playCb = (CheckBox) findViewById(R.id.video_play_cb_1);
        vhOsk.playCbMenuId = Setting.PREF_KEY_CB1_ENABLE;
        vhOsk.txtDebug = findViewById(R.id.debug_info_1);
        mSetting.initViewHolderStatus(vhOsk);


        final ViewHolder vhIjk = new ViewHolder();
        vhIjk.textureView = (SafeTextureView) findViewById(R.id.textureview_2);
        vhIjk.seekBar = (SeekBar) findViewById(R.id.seekbar_2);
        vhIjk.txtProgress = (TextView) findViewById(R.id.video_txt_progress_2);
        vhIjk.txtDuration = (TextView) findViewById(R.id.video_txt_duration_2);
        vhIjk.playCb = (CheckBox) findViewById(R.id.video_play_cb_2);
        vhIjk.playCbMenuId = Setting.PREF_KEY_CB2_ENABLE;
        vhIjk.txtDebug = findViewById(R.id.debug_info_2);
        mSetting.initViewHolderStatus(vhIjk);


        oskExoListener = new InternalListener(mOskExoPlayer, vhOsk);
        ijkListener = new InternalListener(mIjkPlayer, vhIjk);

        startPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startPlay(oskExoListener, vhOsk);
                startPlay(ijkListener, vhIjk);
            }
        });

        selectMedia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actSelectVideo();
            }
        });
        mediaPath.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                mSetting.updateViewStatus(mViews);
            }
        });

        if (mExtraPlayDirect) {
            startPlay(oskExoListener, vhOsk);
            startPlay(ijkListener, vhIjk);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_SELECT_FILE) {
            if (resultCode == RESULT_OK) {
                Uri uri = data.getData();
                String path = PlatformUtil.getPath(this, uri);
                onVideoSelected(path);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    void actSelectVideo() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(intent, "选择一个视频"), REQUEST_CODE_SELECT_FILE);
    }

    // 需要权限时返回true
    boolean maybeRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int result = checkSelfPermission(PERMISSIONS_STORAGE[0]);
            if (result != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);
                return true;
            }
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_EXTERNAL_STORAGE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                int result = checkSelfPermission(PERMISSIONS_STORAGE[0]);
                if (result != PackageManager.PERMISSION_GRANTED) {
//                    requestPermissions(PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);
                    Toast.makeText(this, "读取存储的权限被拒绝，播放可能失败", Toast.LENGTH_SHORT).show();
                }
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    void onVideoSelected(String path) {
        mViews.mediaPath.setText(path);
        mSetting.updateViewStatus(mViews);
        maybeRequestPermissions();
    }

    private void startPlay(InternalListener listener, ViewHolder vh) {
        listener.setPrepareStartTimeStamp(System.currentTimeMillis());
        if (!vh.playCb.isChecked()) {
            if (!TextUtils.isEmpty(mExtraVideoUrl)) {
                IMediaPlayer player = listener.getPlayer();
                if (player instanceof OskExoMediaPlayer && mExtraEnableExoPlay) {
                    vh.textureView.setVisibility(View.VISIBLE);
                } else if (player instanceof IjkMediaPlayer && mExtraEnableIjkPlay) {
                    vh.textureView.setVisibility(View.VISIBLE);
                } else {
                    PlayerUtils.log(QLog.WARN, LOG_TAG, "mExtraEnableExoPlay:" + mExtraEnableExoPlay
                            + ",mExtraEnableIjkPlay:" + mExtraEnableIjkPlay);
                    return;
                }
            } else {
                return;
            }
        }
        String urlTyped = mViews.mediaPath.getText().toString();
        // https://android.googlesource.com/platform/cts/+/master/tests/tests/media/assets?autodive=0/
        // http://samplemedia.linaro.org/
//        flv:
//        http://flv.6721.liveplay.now.qq.com/live/6721_7384403d891787365873ab776610f20f.flv?txSecret=35c9f17108eb8b3ffc88456f3cb1b09e&txTime=5D00C498
//
//        hls:
//        http://6721.liveplay.now.qq.com/live/6721_7384403d891787365873ab776610f20f.m3u8?txSecret=35c9f17108eb8b3ffc88456f3cb1b09e&txTime=5D00C498
//
//        rtmp:
//        rtmp://6721.liveplay.now.qq.com/live/6721_7384403d891787365873ab776610f20f?txSecret=35c9f17108eb8b3ffc88456f3cb1b09e&txTime=5D00C498
        String[] urls = {
                "http://10.66.93.56:8080/weishi2/sample1.f31.mp4",
                "/sdcard/sample.f0.mp4",
                "/sdcard/sample1.f31.mp4",
                "/sdcard/seg001.ts",
                "/sdcard/1.mp4",
                "/android_asset/h264probe.mp4", // 5
                "file://" + "/android_asset/h264probe.mp4",
                "android.resource://" + getPackageName() + "/" + R.raw.h265probe,
                "android.resource://" + getPackageName() + "/" + R.raw.h265clock,
                "android.resource://" + getPackageName() + "/" + R.raw.hevc_4k,
                "android.resource://" + getPackageName() + "/" + R.raw.moov_at_end, /// 10
                "android.resource://" + getPackageName() + "/" + R.raw.h264_yuv444p,
                "android.resource://" + getPackageName() + "/" + R.raw.first_frame_not_key_frame,
                "http://ly.weishi.qq.com/shg_1578971675_1047_a8e5a808cbda40e1ade979e90b08vide.f40.mp4",
                "http://ly.weishi.qq.com/shg_1052577522_1047_be9dc376030b44ceba0139097f8fvide.f40.mp4",
                "http://graph.qq.com/v3/video/get_v_key", //15
                "https://dlied5.qq.com/ABCmouse/aol/content/Animation/33755/lleclass_cn_001_cid_33755_bc.mp4",
                "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4",
                "http://2527.vod.myqcloud.com/2527_7cf9fdea310b11e5be00d51f0439f0b3.f0.mp4",
                "https://media.w3.org/2010/05/sintel/trailer.mp4",
                "http://mirror.aarnet.edu.au/pub/TED-talks/911Mothers_2010W-480p.mp4", // 20
                "android.resource://" + getPackageName() + "/" + R.raw.bobblehead, // can only play first frame
                "android.resource://" + getPackageName() + "/" + R.raw.bobble_bg_music, // can not play
                // flv live 23
                "http://flv.6721.liveplay.now.qq.com/live/6721_7384403d891787365873ab776610f20f.flv?txSecret=35c9f17108eb8b3ffc88456f3cb1b09e&txTime=5D00C498",
                "android.resource://" + getPackageName() + "/" + R.raw.rotation_cw_90, // can not play
                // hls encrypted
                "https://1258712167.vod2.myqcloud.com/fb8e6c92vodtranscq1258712167/ccc62b395285890790493262876/drm/voddrm.token.dWluPTtwc2tleT07ZXh0PTthcHB0b2tlbj07b3BlbmlkPTthcHBpZD07dWlkX3R5cGU9MTAwNTt0ZXJtX2lkPTEwMDQ5Njc0OQ==.v.f30741.m3u8?t=5d60af47&exper=0&us=3585348032552968482&sign=73b1c3b3ae4b6517b06c1d0649c9cf04"
        };
        int idx = 25;

        String finalUrl = !TextUtils.isEmpty(urlTyped) ? urlTyped : urls[idx];
        if (!TextUtils.isEmpty(mExtraVideoUrl)) {
            finalUrl = mExtraVideoUrl;
        }
        String proxyUrl = OskPlayer.getInstance().getUrl(finalUrl);

        // remove掉上一次的listener
        if (!TextUtils.isEmpty(mCurrentUuid)) {
            VideoManager.getInstance().removeUuidErrorListener(mCurrentUuid);
        }

        // 当次播放视频的uuid
        mCurrentUuid = PlayerUtils.getVideoUuidFromVideoUrl(proxyUrl);
        VideoManager.getInstance().addUuidErrorListener(mCurrentUuid, listener);

        initPlayerOptions(listener);
        IMediaPlayer player = listener.getPlayer();
        player.setOnInfoListener(listener);
        player.setAudioStreamType(AudioManager.STREAM_MUSIC);
        player.setOnPreparedListener(listener);
        player.setOnVideoSizeChangedListener(listener);
        player.setOnSeekCompleteListener(listener);
        player.setOnErrorListener(listener);
        player.setVolume(1.0f, 1.0f);
        try {
//            Debug.startMethodTracing("/sdcard/osk.trace");
            player.setDataSource(proxyUrl);
            player.prepareAsync();
            updateDebugTxt(vh, player, "prepareAsync");
        } catch (IOException ex) {
            PlayerUtils.log(QLog.INFO, LOG_TAG, ex.toString());
        }
    }

    private void initPlayerOptions(InternalListener listener) {
        IMediaPlayer player = listener.getPlayer();
        if (!mNewPlayer) {
            if (player instanceof IjkMediaPlayer) {
                player.stop();
                player.release();
                player = new IjkMediaPlayer();
                player.setSurface(listener.mSurface);
                listener.mPlayer = player;
            } else if (player instanceof OskExoMediaPlayer) {
                player.reset();
            }
        }
        if (player instanceof IjkMediaPlayer) {
            initIjkPlayerOptions((IjkMediaPlayer) player);
        } else if (player instanceof OskExoMediaPlayer) {
            initExoPlayerOptions((OskExoMediaPlayer) player);
        }
        mNewPlayer = false;
    }

    private void initIjkPlayerOptions(IjkMediaPlayer player) {
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "mediacodec-all-videos", 1);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "enable-accurate-seek", 1);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_CODEC, "skip_loop_filter", 0);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "http-detect-range-support", 0);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "start-on-prepared", 0);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "infbuf", 1);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "fast", 1);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "framedrop", 5);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "enable-accurate-seek", 1);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "max-fps", 30);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_FORMAT, "analyzeduration", 1);
        player.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "mediacodec-auto-rotate", 1);
//        player.setPreReadingBuffer(0);
    }

    private void initExoPlayerOptions(OskExoMediaPlayer player) {
        player.setCalculateAudioLevel(true);
    }

    private class InternalListener implements
            IMediaPlayer.OnPreparedListener,
            IMediaPlayer.OnVideoSizeChangedListener,
            IMediaPlayer.OnSeekCompleteListener,
            IMediaPlayer.OnErrorListener,
            IMediaPlayer.OnInfoListener,
            VideoProxy.HttpErrorListener,
            TextureView.SurfaceTextureListener,
            SeekBar.OnSeekBarChangeListener,
            CheckBox.OnCheckedChangeListener {

        IMediaPlayer mPlayer;
        ViewHolder mViewHolder;
        long mPrepareStartTimeStamp;
        int mTextureUpdateNotifyCount;
        Surface mSurface;

        InternalListener(IMediaPlayer player,
                         ViewHolder vh) {
            mPlayer = player;
            mViewHolder = vh;
            mViewHolder.textureView.setSurfaceTextureListener(this);
            mViewHolder.seekBar.setOnSeekBarChangeListener(this);
            mViewHolder.playCb.setOnCheckedChangeListener(this);
        }

        IMediaPlayer getPlayer() {
            return mPlayer;
        }

        void setPrepareStartTimeStamp(long timeStamp) {
            mPrepareStartTimeStamp = timeStamp;
        }

        // TextureViewListener
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int width, int height) {
            mTextureUpdateNotifyCount = 0;
            PlayerUtils.log(QLog.INFO, LOG_TAG, "onSurfaceTextureAvailable [" + width + "," + height + "], " + mPlayer);
            mSurface = new Surface(surfaceTexture);
            mPlayer.setSurface(mSurface);
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int width, int height) {
            PlayerUtils.log(QLog.INFO, LOG_TAG, "onSurfaceTextureSizeChanged [" + width + "," + height + "], " + mPlayer);
        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
            mTextureUpdateNotifyCount = 0;
            PlayerUtils.log(QLog.INFO, LOG_TAG, "onSurfaceTextureDestroyed, " + mPlayer);
            destroyPlayer();
            return false;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
            if (mTextureUpdateNotifyCount == 0) {
                PlayerUtils.log(QLog.INFO, LOG_TAG, "onSurfaceTextureUpdated timeCost=" + (System.currentTimeMillis() - mPrepareStartTimeStamp) + "ms, " + mPlayer);
            }
            updateDebugTxt(mViewHolder, mPlayer, "onSurfaceTextureUpdated " + mTextureUpdateNotifyCount++);
            PlayerUtils.log(QLog.VERBOSE, LOG_TAG, "onSurfaceTextureUpdated, " + mTextureUpdateNotifyCount);
        }

        @Override
        public boolean onInfo(IMediaPlayer mp, int what, int extra) {
            if (what == IMediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) {
                PlayerUtils.log(QLog.INFO, LOG_TAG, "onVideoRenderingStart timeCost=" + (System.currentTimeMillis() - mPrepareStartTimeStamp) + "ms, " + mPlayer);
                updateDebugTxt(mViewHolder, mPlayer, "onVideoRenderingStart");
            }
            return false;
        }

        // MediaPlayerListener
        @Override
        public void onPrepared(IMediaPlayer iMediaPlayer) {
            try {
//                Debug.stopMethodTracing();
//                TraceUtil.beginSection("PlayerCompareActivity.startPlay");
                mPlayer.start();
                PlayerUtils.log(QLog.INFO, LOG_TAG, "onVideoPrepared timeCost=" + (System.currentTimeMillis() - mPrepareStartTimeStamp) + "ms, " + mPlayer);
                PlayerUtils.log(QLog.INFO, LOG_TAG, "start play, " + mPlayer);
                updateDebugTxt(mViewHolder, mPlayer, "onPrepared+startPlay");
                doOnPrepared();
//                TraceUtil.endSection();
            } catch (IMediaPlayer.InternalOperationException ex) {
                //ignore
            }
        }

        @Override
        public void onVideoSizeChanged(IMediaPlayer iMediaPlayer, int videoWidth, int videoHeight) {
            final ViewGroup.LayoutParams layoutParams = mViewHolder.textureView.getLayoutParams();
            int containerWidth = ((View)mViewHolder.textureView.getParent()).getMeasuredWidth();

            int videoLayoutWidth = Math.min(containerWidth, videoWidth);
            float scaleRatio = (float) videoLayoutWidth / videoWidth;
            int videoLayoutHeight = (int) (videoHeight * scaleRatio);

            layoutParams.width = videoLayoutWidth;
            layoutParams.height = videoLayoutHeight;

            PlayerUtils.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mViewHolder.textureView.setLayoutParams(layoutParams);
                }
            });
        }

        @Override
        public boolean onError(IMediaPlayer iMediaPlayer, int what, int extra) {
            PlayerUtils.log(QLog.INFO, LOG_TAG, "onError what=" + what + ",extra=" + extra);
            return false;
        }

        @Override
        public void onHttpError(String uuid, // 播放id
                                String url, // 视频url
                                int responseCode, // http返回码
                                Map<String, Object> extendInfo, // 出错其它详细信息可能包含 "priority", error_msg" 等，也可能为空
                                Map<String, List<String>> headerFields, // 当次http请求头部信息
                                int requestTime, // 请求发起时间
                                long downloadRetCode, // 出错主错误码
                                long downloadSubRetCode) { // 出错子错误码
            //HTTP下载出错回调
            if (TextUtils.isEmpty(uuid)) { // uuid为空，说明是播放的本地文件
                PlayerUtils.log(QLog.INFO, LOG_TAG, "onHttpError uuid is null");
                return;
            }
            if (!uuid.equals(mCurrentUuid)) { // 虽然下载出错了，但并不是当前播放的视频，所以忽略
                PlayerUtils.log(QLog.INFO, LOG_TAG, "not current playing video");
                return;
            }
            boolean realError = true;
            if (responseCode == VideoResultCode.DOWNLOAD_ILLEGAL_LIVE_PLAYLIST || // m3u8非法
                    responseCode == VideoResultCode.DOWNLOAD_LIVE_PLAYLIST_ERROR) { // 直播流中断，并非错误
                realError = false;
            }
            if (!realError) {
                PlayerUtils.log(QLog.INFO, LOG_TAG, "not real error responseCode=" + responseCode);
                return;
            }
            // 真正错误
            boolean networkAvailable = PlayerUtils.isNetworkAvailable();
            if (networkAvailable) { // 说明有网络，但不一定能上网（弱网或者内网等情况）
                DNSService dnsService = PlayerConfig.g().getDNSService();
                if (dnsService != null) {
                    boolean netReachable = dnsService.isNetReachable();
                    if (!netReachable) {
                        // 网络不通，应判断为逻辑失败，没有网络怎么播？
                    }
                } else {
                    // 无法判断网络是否通畅
                }
            } else {
                // 无网络，通常为断网
                PlayerUtils.log(QLog.INFO, LOG_TAG, "视频播放失败，无网络");
            }
        }

        @Override
        public void onSeekComplete(IMediaPlayer mediaPlayer) {
            PlayerUtils.log(QLog.INFO, LOG_TAG, "onSeekComplete" + mediaPlayer);
        }

        // SeekBar
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromuser) {
            if (fromuser) {
                Log.d(LOG_TAG, "seekTo " + progress);
                mPlayer.seekTo(progress);
            }
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }

        // Checkbox
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (mViewHolder.playCb.isChecked()) {
                mViewHolder.textureView.setVisibility(View.VISIBLE);
            }
            mSetting.updateViewHolderStatus(mViewHolder);
        }

        // Others
        private void doOnPrepared() {
            updateDuration();
            refreshProgressbarLoop();
            mViewHolder.seekBar.setMax((int) mPlayer.getDuration());
            if (mViewHolder.audioLevelBar != null) {
                mViewHolder.audioLevelBar.setMax(AUDIO_LEVEL_BAR_MAX);
            }
        }

        private void updateProgress() {
            mViewHolder.txtDuration.setText(String.valueOf(mPlayer.getCurrentPosition()));
        }

        private void updateDuration() {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    updateProgress();
                }
            });
        }

        private void refreshProgressbarLoop() {
            if (mPlayer != null) {
                mViewHolder.seekBar.setProgress((int) mPlayer.getCurrentPosition());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateProgress();
                        if (mViewHolder.audioLevelBar != null) {
                            if (mPlayer instanceof OskExoMediaPlayer) {
                                double audioLevel = ((OskExoMediaPlayer) mPlayer).getAudioLevel();
                                mViewHolder.audioLevelBar.setProgress((int) (audioLevel * AUDIO_LEVEL_BAR_MAX));
                            }
                        }
                    }
                });
                mMainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        refreshProgressbarLoop();
                    }
                }, 100);
            }
        }

        private void destroyPlayer() {
            mPlayer.setSurface(null);
            if (mPlayer != null) {
                mPlayer.release();
                mPlayer = null;
            }
        }
    }

    private void updateDebugTxt(final ViewHolder vh, final IMediaPlayer player, final String txt) {
        String playerImpl = "unknown";
        if (player instanceof IjkMediaPlayer) {
            playerImpl = "ijk";
        } else if (player instanceof OskExoMediaPlayer) {
            playerImpl = "exo";
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(txt);
        sb.append(",impl:");
        sb.append(playerImpl);
        PlayerUtils.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                vh.txtDebug.setText(sb.toString());
            }
        });
    }

    private class ViewHolder {
        TextureView textureView;
        SeekBar seekBar;
        ProgressBar audioLevelBar;
        TextView txtProgress;
        TextView txtDuration;
        TextView txtDebug;
        CheckBox playCb;
        String playCbMenuId;
    }

    private class CommonViews {
        EditText mediaPath;
    }

    private class Setting {
        public static final String PREF_KEY_CB1_ENABLE = "checkboxcb1";
        public static final String PREF_KEY_CB2_ENABLE = "checkboxcb2";
        public static final String PREF_KEY_MEDIA_PATH = "mediapath";
        public static final boolean DEFAULT_PREF_KEY_CB_ENABLE = false;

        private SharedPreferences mPrefs;

        public Setting() {
            mPrefs = getApplicationContext().getSharedPreferences("player_compare_activity_settings", MODE_PRIVATE);
        }

        public void initViewHolderStatus(ViewHolder viewHolder) {
            viewHolder.playCb.setChecked(mPrefs.getBoolean(viewHolder.playCbMenuId, DEFAULT_PREF_KEY_CB_ENABLE));
            if (viewHolder.playCb.isChecked()) {
                viewHolder.textureView.setVisibility(View.VISIBLE);
            }
        }

        public void updateViewHolderStatus(ViewHolder viewHolder) {
            mPrefs.edit()
                    .putBoolean(viewHolder.playCbMenuId, viewHolder.playCb.isChecked())
                    .apply();
            viewHolder.textureView.setVisibility(viewHolder.playCb.isChecked() ? View.VISIBLE : View.GONE);
        }

        public void initViewStatus(CommonViews views) {
            views.mediaPath.setText(mPrefs.getString(PREF_KEY_MEDIA_PATH,""));
        }

        public void updateViewStatus(CommonViews views) {
            mPrefs.edit()
                    .putString(PREF_KEY_MEDIA_PATH,views.mediaPath.getText().toString())
                    .apply();
        }
    }
}

//        private void loadOpenHevcLibrary() {
//            // test code
//            boolean sucess = new LibraryLoader("openhevc").isAvailable();
//            if (sucess) {
//                PlayerUtils.log(QLog.INFO, LOG_TAG, "openhevc success");
//            } else {
//                PlayerUtils.log(QLog.INFO, LOG_TAG, "openhevc failed");
//            }
//        }
//        System.setProperty("proxySet", "true");
//        System.setProperty("proxyHost", "[240e:ff:f040:f801:ab:9ed4:b7fa:c8af]");
//        System.setProperty("proxyPort", "8686");
//
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                String ipaddr = "";
//                try {
//                    ipaddr = InetAddress.getByName("graph.qq.com").getHostAddress();
//                } catch (Exception ex) {
//                    ex.printStackTrace();
//                }
//                Log.d(LOG_TAG, ipaddr);
//            }
//        }).start();