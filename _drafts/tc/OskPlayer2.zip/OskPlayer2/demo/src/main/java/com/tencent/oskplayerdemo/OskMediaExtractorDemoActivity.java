package com.tencent.oskplayerdemo;

import android.app.Activity;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

import com.tencent.oskplayer.OskPlayer;
import com.tencent.oskplayer.contrib.mediaextractor.ExtractorFactory;
import com.tencent.oskplayer.contrib.mediaextractor.IMediaExtractor;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.LinkedList;

public class OskMediaExtractorDemoActivity extends Activity implements
        SurfaceHolder.Callback,
        SeekBar.OnSeekBarChangeListener,
        View.OnClickListener{

    public static final String TAG = "OskMediaExtractorDemo";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    private SeekBar mSeekBar;
    private SurfaceHolder mSurfaceHolder;
    private ImageButton mPlayPauseButton;
    private TextView mDebugTextView;
    private TextView mVideoDurationView;
    private TextView mVideoProcessView;
    private Handler mMainHandler;
    private RadioGroup mChoice;
    private boolean mJustCreateExtractor;
    private HandlerThread mHandlerThread;
    private Handler mHandler;

    private IMediaExtractor mExtractor;

    private static final int MAX_SIZE_SAMPLES_IN_MEMORY_BYTES = 12 << 20;  // 12MB
    private static final int TOTAL_FRAMES = 30000;
    private LinkedList<Pair<ByteBuffer, Double>> mSamplesInMemory = new LinkedList<Pair<ByteBuffer, Double>>();
    private int mBitrate;
    private Surface mSurface;

    @Override
    protected void onResume() {
        super.onResume();
        initData();
        initUI();
    }

    private void initData() {
        mHandlerThread = new HandlerThread("MediaExtractorDemo");
        mHandlerThread.start();
        mHandler = new Handler(mHandlerThread.getLooper());
    }

    private void initUI() {
        setContentView(R.layout.osk_media_extractor_demo);
        SurfaceView surfaceView = (SurfaceView) findViewById(R.id.main_surface);
        mSurfaceHolder = surfaceView.getHolder();
        mSurfaceHolder.addCallback(this);
        mSeekBar = (SeekBar) findViewById(R.id.seekbar);
        mSeekBar.setOnSeekBarChangeListener(this);
        mPlayPauseButton = (ImageButton) findViewById(R.id.playpausebtn);
        mPlayPauseButton.setOnClickListener(this);
        mPlayPauseButton.setEnabled(false);
        mDebugTextView = (TextView) findViewById(R.id.debugtextview);
        mVideoDurationView = (TextView) findViewById(R.id.videoDuration);
        mVideoProcessView = (TextView) findViewById(R.id.videoProgress);
        mChoice = findViewById(R.id.extractor_choice);
        mMainHandler = new Handler(Looper.getMainLooper());
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Log.i(TAG, "surfaceCreated");
        mPlayPauseButton.setEnabled(true);
        mSurface = holder.getSurface();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        Log.d(TAG, "surfaceChanged[" + width + "," + height + "]");
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.d(TAG, "surfaceDestroyed");
        destroyExtractor();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.playpausebtn) {
            initExtractor();
            String url = "android.resource://" + getPackageName() + "/" + R.raw.h265clock;
            String proxyUrl = OskPlayer.getInstance().getUrl(url);
            startExtract(proxyUrl);
        }
    }

    private void startExtract(final String path) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    mExtractor.setDataSource(path);
                    int nTracks = mExtractor.getTrackCount();
                    int width = -1;
                    int height = -1;
                    String mime = null;
                    for (int i=0; i<nTracks; i++) {
                        MediaFormat fmt = mExtractor.getTrackFormat(i);
                        if (fmt != null) {
                            mime = fmt.getString(MediaFormat.KEY_MIME);
                            if (!TextUtils.isEmpty(mime) && mime.startsWith("video")) {
                                width = fmt.getInteger(MediaFormat.KEY_WIDTH);
                                height = fmt.getInteger(MediaFormat.KEY_HEIGHT);
                                mExtractor.selectTrack(i);
                                break;
                            }
                        }
                    }
                    doDecode(width, height, mSurface);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    // https://android.googlesource.com/platform/cts/+/master/tests/tests/media/src/android/media/cts/VideoDecoderPerfTest.java
    private void doDecode(int w, int h, Surface surface) {
        int trackIndex = mExtractor.getSampleTrackIndex();
        MediaFormat format = mExtractor.getTrackFormat(trackIndex);
        String mime = format.getString(MediaFormat.KEY_MIME);

        // use framerate to calculate PTS offset used for PTS scaling
        double frameRate = 0; // default - 0 is used for using zero PTS offset

        if (format.containsKey(MediaFormat.KEY_FRAME_RATE)) {
            frameRate = format.getInteger(MediaFormat.KEY_FRAME_RATE);
        }

        ByteBuffer[] codecInputBuffers;
        ByteBuffer[] codecOutputBuffers;

        if (mSamplesInMemory.size() == 0) {
            int totalMemory = 0;
            ByteBuffer tmpBuf = ByteBuffer.allocate( w * h * 3 / 2);
            int sampleSize = 0;
            int index = 0;
            long firstPTS = 0;
            double presentationOffset = 0;
            while ((sampleSize = mExtractor.readSampleData(tmpBuf, 0)) > 0) {
                if (totalMemory + sampleSize > MAX_SIZE_SAMPLES_IN_MEMORY_BYTES) {
                    break;
                }
                if (mSamplesInMemory.size() == 0) {
                    firstPTS = mExtractor.getSampleTime();
                }
                Log.d(TAG, "pts=" + mExtractor.getSampleTime() + ",sampleSize=" + sampleSize + ",flag=" + mExtractor.getSampleFlags());
                ByteBuffer copied = ByteBuffer.allocate(sampleSize);
                copied.put(tmpBuf);
                if (frameRate > 0.) {
                    // presentation offset is an offset from the frame index
                    presentationOffset = (mExtractor.getSampleTime() - firstPTS) * frameRate / 1E6 - index;
                }
                mSamplesInMemory.addLast(Pair.create(copied, presentationOffset));
                totalMemory += sampleSize;
                ++index;
                mExtractor.advance();
            }
            // bitrate normalized to 30fps
            mBitrate = (int) Math.round(totalMemory * 30. * 8. / mSamplesInMemory.size());
            Log.d(TAG, mSamplesInMemory.size() + " samples in memory for " + (totalMemory / 1024) + " KB. BitRate: " + mBitrate);
        }
        format.setInteger(MediaFormat.KEY_FRAME_RATE, mBitrate);

        try {
            int sampleIndex = 0;
            mExtractor.release();
            MediaCodec codec = MediaCodec.createDecoderByType(mime);
            MediaCodecInfo.VideoCapabilities cap = codec.getCodecInfo().getCapabilitiesForType(mime).getVideoCapabilities();
            frameRate = cap.getSupportedFrameRatesFor(w, h).getUpper();
            codec.configure(format, surface, null /* crypto */, 0 /* flags */);
            codec.start();
            codecInputBuffers = codec.getInputBuffers();
            codecOutputBuffers = codec.getOutputBuffers();
            MediaFormat mDecInputFormat = codec.getInputFormat();
            MediaFormat mDecOutputFormat;

            // start decode loop
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            final long kTimeOutUs = 1000; // 1ms timeout
            double[] frameTimeUsDiff = new double[TOTAL_FRAMES - 1];
            long lastOutputTimeUs = 0;
            boolean sawInputEOS = false;
            boolean sawOutputEOS = false;
            int inputNum = 0;
            int outputNum = 0;
            long start = System.currentTimeMillis();
            while (!sawOutputEOS) {
                // handle input
                if (!sawInputEOS) {
                    int inputBufIndex = codec.dequeueInputBuffer(kTimeOutUs);
                    if (inputBufIndex >= 0) {
                        ByteBuffer dstBuf = codecInputBuffers[inputBufIndex];
                        // sample contains the buffer and the PTS offset normalized to frame index
                        Pair<ByteBuffer, Double> sample =
                                mSamplesInMemory.get(sampleIndex++ % mSamplesInMemory.size());
                        sample.first.rewind();
                        int sampleSize = sample.first.remaining();
                        dstBuf.put(sample.first);
                        // use max supported framerate to compute pts
                        long presentationTimeUs = (long) ((inputNum + sample.second) * 1e6 / frameRate);
                        sawInputEOS = ((++inputNum == TOTAL_FRAMES));
                        if (sawInputEOS) {
                            Log.d(TAG, "saw input EOS (stop at sample).");
                        }
                        codec.queueInputBuffer(
                                inputBufIndex,
                                0 /* offset */,
                                sampleSize,
                                presentationTimeUs,
                                sawInputEOS ? MediaCodec.BUFFER_FLAG_END_OF_STREAM : 0);
                    } else {
                        if (inputBufIndex != MediaCodec.INFO_TRY_AGAIN_LATER) {
                            Log.e(TAG, "codec.dequeueInputBuffer() unrecognized return value: " + inputBufIndex);
                        }
                    }
                }
                // handle output
                int outputBufIndex = codec.dequeueOutputBuffer(info, kTimeOutUs);
                if (outputBufIndex >= 0) {
                    if (info.size > 0) { // Disregard 0-sized buffers at the end.
                        long nowUs = (System.nanoTime() + 500) / 1000;
                        if (outputNum > 1) {
                            frameTimeUsDiff[outputNum - 1] = nowUs - lastOutputTimeUs;
                        }
                        lastOutputTimeUs = nowUs;
                        outputNum++;
                    }
                    codec.releaseOutputBuffer(outputBufIndex, true /* render */);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        Log.d(TAG, "saw output EOS.");
                        sawOutputEOS = true;
                    }
                } else if (outputBufIndex == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED) {
                    codecOutputBuffers = codec.getOutputBuffers();
                    Log.d(TAG, "output buffers have changed.");
                } else if (outputBufIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    mDecOutputFormat = codec.getOutputFormat();
                    int width = mDecOutputFormat.getInteger(MediaFormat.KEY_WIDTH);
                    int height = mDecOutputFormat.getInteger(MediaFormat.KEY_HEIGHT);
                    Log.d(TAG, "output resolution " + width + "x" + height);
                } else {
                    if (outputBufIndex != MediaCodec.INFO_TRY_AGAIN_LATER) {
                        Log.e(TAG, "codec.dequeueOutputBuffer() unrecognized return index: "
                                + outputBufIndex);
                    }
                }
            }
            codec.stop();
            codec.release();
            Log.d(TAG, "input num " + inputNum + " vs output num " + outputNum);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void initExtractor() {
        long id = mChoice.getCheckedRadioButtonId();
        if (id == R.id.extractorchoice_and) {
            mExtractor = ExtractorFactory.create(true);
        } else if (id == R.id.extractorchoice_osk) {
            mExtractor = ExtractorFactory.create(false);
        }
    }

    private void destroyExtractor() {
        if (mExtractor != null) {
            mExtractor.release();
            mExtractor = null;
        }
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}
