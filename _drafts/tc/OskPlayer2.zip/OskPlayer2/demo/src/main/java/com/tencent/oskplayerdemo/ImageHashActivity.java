package com.tencent.oskplayerdemo;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.oskplayer.OskPlayer;
import com.tencent.oskplayer.contrib.ImageHash;
import com.tencent.oskplayer.contrib.ImageHashError;
import com.tencent.oskplayer.miscellaneous.DecodeProbe;
import com.tencent.oskplayer.miscellaneous.HardwareDecodeProbe;
import com.tencent.oskplayer.miscellaneous.SoftwareDecodeProbe;
import com.tencent.oskplayer.support.OskSupport;
import com.tencent.oskplayer.support.util.OskBitmap;
import com.tencent.oskplayer.util.PlayerUtils;
import com.tencent.oskplayer.util.QLog;
import com.tencent.oskplayerdemo.util.PlatformUtil;
import com.tencent.oskplayerdemo.util.ProgressMum;
import com.tencent.oskplayerdemo.util.StringUtil;
import com.tencent.oskplayerdemo.view.SimpleImageView;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Locale;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action0;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

public class ImageHashActivity extends Activity {

    public static final String LOG_TAG = "imagehash";

    public static final int REQUEST_EXTERNAL_STORAGE = 0x2;

    private boolean firstCreate = true;

    private ViewHolder mViews;
    private Setting mSetting;

    public static final int REQUEST_CODE_SELECT_PIC_A = 0x1;
    public static final int REQUEST_CODE_SELECT_PIC_B = 0x2;

    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    private static Rect sScreenRect = null;

    private static final int[] sFrameSeq = {1,8,64};

    private static final String sHtmlResult = "检测结果:<font color=%s>%s</font> <br/> 硬解平均耗时:%s <br/>软解平均耗时:%s <br/>总耗时:%s <br/>错误码:%s";

    private static Rect computeScreenDimension(Context context) {
        int width = -1;
        int height = -1;
        if (context.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            width = context.getResources().getDisplayMetrics().heightPixels;
            height = context.getResources().getDisplayMetrics().widthPixels;
        } else {
            width = context.getResources().getDisplayMetrics().widthPixels;
            height = context.getResources().getDisplayMetrics().heightPixels;
        }
        return new Rect(0,0,width,height);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (firstCreate) {
            sScreenRect = computeScreenDimension(this);
            initUI();
            initData();
            initEvent();
            firstCreate = false;
        }
    }

    private void initUI() {
        setContentView(R.layout.image_hash_activity);
    }

    private void initData() {
        mViews = new ViewHolder();
        mViews.ahash = findViewById(R.id.aHash_btn);
        mViews.phash = findViewById(R.id.pHash_btn);
        mViews.h264_probe = findViewById(R.id.h264_probe_btn);
        mViews.h265_probe = findViewById(R.id.h265_probe_btn);
        mViews.h265_play = findViewById(R.id.h265_play_btn);
        mViews.pica = findViewById(R.id.image_hash_pic_path_a);
        mViews.picb = findViewById(R.id.image_hash_pic_path_b);
        mViews.sela = findViewById(R.id.image_hash_pic_select_a);
        mViews.selb = findViewById(R.id.image_hash_pic_select_b);
        mViews.disp_a = findViewById(R.id.image_disp_a);
        mViews.disp_b = findViewById(R.id.image_disp_b);
        mViews.desc_a = findViewById(R.id.image_desc_a);
        mViews.desc_b = findViewById(R.id.image_desc_b);
        mViews.misc_desc = findViewById(R.id.misc_desc);
        mViews.misc_desc_l2 = findViewById(R.id.misc_desc_l2);
        mViews.probe_progress = findViewById(R.id.probe_progress);
        mSetting = new Setting();
        mSetting.initViewHolderStatus(mViews);
        String txt = "屏幕大小:" + sScreenRect.width() + "*" + sScreenRect.height();
        ((TextView)findViewById(R.id.common_desc)).setText(txt);
        ImageHash.loadLibrariesOnce(OskSupport.getLibLoader());
    }

    private void initEvent() {
        View.OnClickListener clickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch(v.getId()) {
                    case R.id.image_hash_pic_select_a:
                        actSelectPic(REQUEST_CODE_SELECT_PIC_A);
                        break;
                    case R.id.image_hash_pic_select_b:
                        actSelectPic(REQUEST_CODE_SELECT_PIC_B);
                        break;
                    case R.id.aHash_btn:
                        performAverageHash();
                        break;
                    case R.id.pHash_btn:
                        performPerceptualHash();
                        break;
                    case R.id.h264_probe_btn:
                        performH264Probe();
                        break;
                    case R.id.h265_probe_btn:
                        performH265Probe();
                        break;
                    case R.id.h265_play_btn:
                        performH265Play();
                        break;
                }
            }
        };
        View.OnFocusChangeListener focusChangeListener = new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {
                    mSetting.updateViewHolderStatus(mViews);
                    mSetting.initViewHolderStatus(mViews);
                }
            }
        };
        mViews.ahash.setOnClickListener(clickListener);
        mViews.phash.setOnClickListener(clickListener);
        mViews.sela.setOnClickListener(clickListener);
        mViews.selb.setOnClickListener(clickListener);
        mViews.h265_probe.setOnClickListener(clickListener);
        mViews.h265_play.setOnClickListener(clickListener);
        mViews.h264_probe.setOnClickListener(clickListener);
        mViews.pica.setOnFocusChangeListener(focusChangeListener);
        mViews.picb.setOnFocusChangeListener(focusChangeListener);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    void actSelectPic(int code) {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("*/*");
//        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
//        intent.setType("*/*");
//        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(intent, "选择图片"), code);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_SELECT_PIC_A ||
                requestCode == REQUEST_CODE_SELECT_PIC_B) {
            if (resultCode == RESULT_OK) {
                Uri uri = data.getData();
                String path = PlatformUtil.getPath(this, uri);
                onPicSelected(path, requestCode);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }


    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_EXTERNAL_STORAGE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                int result = checkSelfPermission(PERMISSIONS_STORAGE[0]);
                if (result != PackageManager.PERMISSION_GRANTED) {
//                    requestPermissions(PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);
                    showToast("读取存储的权限被拒绝，功能可能异常");
                }
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    void onPicSelected(String path, int what) {
        BitmapHolder bh = null;
        if (what == REQUEST_CODE_SELECT_PIC_A) {
            mViews.pica.setText(path);
            bh = new BitmapHolder();
            bh.iv = mViews.disp_a;
            bh.path = path;
            bh.bitmap = null;
            bh.tv = mViews.desc_a;
        } else if (what == REQUEST_CODE_SELECT_PIC_B) {
            mViews.picb.setText(path);
            bh = new BitmapHolder();
            bh.iv = mViews.disp_b;
            bh.tv = mViews.desc_b;
            bh.path = path;
            bh.bitmap = null;
        }
        if (bh == null) {
            showToast("图片选择错误" + what);
            return;
        }
        processBitmapHolder(bh);
        mSetting.updateViewHolderStatus(mViews);
        maybeRequestPermissions();
    }

    private void performAverageHash() {
        showToast("AverageHash Algorithm");
    }

    private void performPerceptualHash() {
        showToast("Perceptual Algorithm");
    }

    private void performH264Probe() {
        showToast("performH264Probe");
        String h264Url = "/android_asset/h264probe.mp4";
        probe(h264Url, new ProbeResultCallback() {
            @Override
            public void onProbeResult(ProbeResult result) {
                // callback on ui thread
                String timeCost = PlayerUtils.formatVideoTime(result.timeCostTotal);
//                String hwDecodeCost = PlayerUtils.formatVideoTime(result.timeCostHwDecode);
//                String swDecodeCost = PlayerUtils.formatVideoTime(result.timeCostSwDecode);
                mViews.misc_desc_l2.setText(Html.fromHtml(String.format(Locale.getDefault(), sHtmlResult,
                        result.resultCode == ImageHashError.NOERR ? "green" : "red",
                        result.resultCode == ImageHashError.NOERR ? "通过" : "不通过",
                        result.avgHwDecFrameCost, result.avgSwDecFrameCost, timeCost, result.resultCode)));
                mViews.probe_progress.setProgress(Math.round(result.progress * mViews.probe_progress.getMax()));
            }
        });
    }

    private void performH265Probe() {
        showToast("performH265Probe");
        String h265Url = "android.resource://" + getPackageName() + "/" + R.raw.h265probe;
        probe(h265Url, new ProbeResultCallback() {
            @Override
            public void onProbeResult(ProbeResult result) {
                // callback on ui thread
                String timeCost = PlayerUtils.formatVideoTime(result.timeCostTotal);
//                String hwDecodeCost = PlayerUtils.formatVideoTime(result.timeCostHwDecode);
//                String swDecodeCost = PlayerUtils.formatVideoTime(result.timeCostSwDecode);
                mViews.misc_desc_l2.setText(Html.fromHtml(String.format(Locale.getDefault(), sHtmlResult,
                        result.resultCode == ImageHashError.NOERR ? "green" : "red",
                        result.resultCode == ImageHashError.NOERR ? "通过" : "不通过",
                        result.avgHwDecFrameCost, result.avgSwDecFrameCost, timeCost, result.resultCode)));
                mViews.probe_progress.setProgress(Math.round(result.progress * mViews.probe_progress.getMax()));
            }
        });
    }

    private void performH265Play() {
        Intent intent = new Intent(ImageHashActivity.this, PlayerCompareActivity.class);
        intent.putExtra(PlayerCompareActivity.INTENT_KEY_VIDEO_URL, "android.resource://" + getPackageName() + "/" + R.raw.h265probe);
        intent.putExtra(PlayerCompareActivity.INTENT_KEY_ENABLE_IJK_PLAY, true);
        intent.putExtra(PlayerCompareActivity.INTENT_KEY_ENABLE_EXO_PLAY, false);
        intent.putExtra(PlayerCompareActivity.INTENT_KEY_PLAY_DIRECT, true);
        startActivity(intent);
    }

    private static class ProbeResultHolder {
        static final int TYPE_PROBE_PROGRESS = 1; // type == 1 value is frameNo
        static final int TYPE_PROBE_RESULT = 2; // type == 2 value is probe result
        static final String SOURCE_HW = "hw";
        static final String SOURCE_SW = "sw";
        String source;
        int type;
        int value;
        long timeCost;
        long avgDecFrameCost;
    }

    private Integer[] wrapIntArray(int[] ints) {
        Integer[] integers = new Integer[ints.length];
        int i=0;
        for (int v : ints) {
            integers[i++] = v;
        }
        return integers;
    }

    private void probe(String url, final ProbeResultCallback callback) {
        mViews.misc_desc_l2.setText("检测结果:-");
        final long probe_start_time = SystemClock.uptimeMillis();
        final Integer[] frameSeqFlat = wrapIntArray(sFrameSeq);
        final String proxyUrl = OskPlayer.getInstance().getUrl(url);

        DecodeProbe.getInstance().addSaveFrame(sFrameSeq);
        DecodeProbe.getInstance().cleanPicOutDir();

        final ProgressMum hwProgressMum = new ProgressMum(); // non-group record hwProgress on probe
        hwProgressMum.setMaxStep(frameSeqFlat[frameSeqFlat.length - 1]);

        final ProgressMum swProgressMum = new ProgressMum(); // non-group record swProgress on probe
        swProgressMum.setMaxStep(frameSeqFlat[frameSeqFlat.length - 1]);

        final ProgressMum hashProgressMum = new ProgressMum(); // non-group record hashProgress
        hashProgressMum.setMaxStep(frameSeqFlat.length);

        ProgressMum decProgressMum = new ProgressMum(); // group overall decode progress
        decProgressMum.addProgress(hwProgressMum, 0.5f);
        decProgressMum.addProgress(swProgressMum, 0.5f);

        final ProgressMum allProgress = new ProgressMum(); // group overall progress
        allProgress.addProgress(decProgressMum, 0.5f);
        allProgress.addProgress(hashProgressMum, 0.5f);

        final ProbeResultHolder hwProbeResultHolder = new ProbeResultHolder();
        final ProbeResultHolder swProbeResultHolder = new ProbeResultHolder();

        mViews.probe_progress.setProgress(Math.round(allProgress.getProgress() * mViews.probe_progress.getMax()));

        Observable<ProbeResultHolder> hwDecode = Observable.create(new Observable.OnSubscribe<ProbeResultHolder>() {
            @Override
            public void call(final Subscriber<? super ProbeResultHolder> subscriber) {
                DecodeProbe.getInstance().setHwProbeCallback(new HardwareDecodeProbe.HwProbeCallback() {
                    @Override
                    public void onHwProbeOneFrame(int frameNo) {
                        ProbeResultHolder holder = new ProbeResultHolder();
                        hwProgressMum.updateStep(frameNo);
                        holder.source = ProbeResultHolder.SOURCE_HW;
                        holder.type = ProbeResultHolder.TYPE_PROBE_PROGRESS;
                        holder.value = frameNo;
                        subscriber.onNext(holder);
                    }
                });
                long hwDecodeStart = SystemClock.uptimeMillis();
                int result = DecodeProbe.getInstance().hwProbe(proxyUrl);
                hwProbeResultHolder.source = ProbeResultHolder.SOURCE_HW;
                hwProbeResultHolder.type = ProbeResultHolder.TYPE_PROBE_RESULT;
                hwProbeResultHolder.value = result;
                hwProbeResultHolder.timeCost = SystemClock.uptimeMillis() - hwDecodeStart;
                hwProbeResultHolder.avgDecFrameCost = DecodeProbe.getInstance().getHwDecodeAvgCost();
                hwProgressMum.markFinishForce();
                subscriber.onNext(hwProbeResultHolder);
                if (result == 0) {
                    subscriber.onCompleted();
                } else {
                    subscriber.onError(new ImageHashError(result, "hwProbe Error " + result));
                }
            }
        }).subscribeOn(Schedulers.computation());
        Observable<ProbeResultHolder> swDecode = Observable.create(new Observable.OnSubscribe<ProbeResultHolder>() {
            @Override
            public void call(final Subscriber<? super ProbeResultHolder> subscriber) {
                DecodeProbe.getInstance().setSwProbeCallback(new SoftwareDecodeProbe.SwProbeCallback() {
                    @Override
                    public void onSwProbeOneFrame(int frameNo) {
                        ProbeResultHolder holder = new ProbeResultHolder();
                        swProgressMum.updateStep(frameNo);
                        holder.source = ProbeResultHolder.SOURCE_SW;
                        holder.type = ProbeResultHolder.TYPE_PROBE_PROGRESS;
                        holder.value = frameNo;
                        subscriber.onNext(holder);
                    }
                });
                long swDecodeStart = SystemClock.uptimeMillis();
                int result = DecodeProbe.getInstance().swProbe(proxyUrl);
                swProbeResultHolder.source = ProbeResultHolder.SOURCE_SW;
                swProbeResultHolder.type = ProbeResultHolder.TYPE_PROBE_RESULT;
                swProbeResultHolder.value = result;
                swProbeResultHolder.timeCost = SystemClock.uptimeMillis() - swDecodeStart;
                swProbeResultHolder.avgDecFrameCost = DecodeProbe.getInstance().getSwDecodeAvgCost();
                swProgressMum.markFinishForce();
                subscriber.onNext(swProbeResultHolder);
                if (result == 0) {
                    subscriber.onCompleted();
                } else {
                    subscriber.onError(new ImageHashError(result, "swProbe Error " + result));
                }
            }
        }).subscribeOn(Schedulers.computation());

        Observable.concat(hwDecode, swDecode)
          .observeOn(AndroidSchedulers.mainThread())
          .doOnCompleted(new Action0() {
              @Override
              public void call() {
                  // init bitmap holder
                  Observable.from(frameSeqFlat)
                          .flatMap(new Func1<Integer, Observable<BitmapHolder[]>>() {
                              @Override
                              public Observable<BitmapHolder[]> call(Integer value) {
                                  File picOutDir = DecodeProbe.getInstance().getPicOutDir();
                                  final File hwPic = new File(picOutDir, String.format(Locale.getDefault(),"hw-%d.jpg", value));
                                  final File swPic = new File(picOutDir, String.format(Locale.getDefault(),"sw-%d.jpg", value));
                                  return Observable.create(new Observable.OnSubscribe<BitmapHolder[]>() {
                                      @Override
                                      public void call(Subscriber<? super BitmapHolder[]> subscriber) {
                                          BitmapHolder bhHw = new BitmapHolder();
                                          bhHw.iv = mViews.disp_a;
                                          bhHw.tv = mViews.desc_a;
                                          bhHw.path = hwPic.getAbsolutePath();
                                          bhHw.bitmap = null;
                                          BitmapHolder bhSw = new BitmapHolder();
                                          bhSw.iv = mViews.disp_b;
                                          bhSw.tv = mViews.desc_b;
                                          bhSw.path = swPic.getAbsolutePath();
                                          bhSw.bitmap = null;
                                          BitmapHolder[] bhs = new BitmapHolder[2];
                                          bhs[0] = bhHw;
                                          bhs[1] = bhSw;
                                          subscriber.onNext(bhs);
                                          subscriber.onCompleted();
                                      }
                                  });
                              }
                          })
                          .map(new Func1<BitmapHolder[], BitmapHolder[]>() {
                              @Override
                              public BitmapHolder[] call(BitmapHolder[] holders) {
                                  for (BitmapHolder holder : holders) {
                                      if (holder != null && !TextUtils.isEmpty(holder.path)) {
                                          File file = new File(holder.path);
                                          if (file.isFile() && file.exists()) {
                                              holder.opts = getBitmapBounds(holder.path);
                                              holder.bitmap = getBitmap(holder.path, holder.opts);
                                          }
                                      }
                                  }
                                  return holders;
                              }
                          })
                          .map(new Func1<BitmapHolder[], BitmapHolder[]>() {
                              @Override
                              public BitmapHolder[] call(BitmapHolder[] holders) {
                                  // printPixelValue(holder.bitmap);
                                  for (BitmapHolder holder : holders) {
                                      if (holder.bitmap != null) {
                                          long t1 = System.currentTimeMillis();
                                          holder.phash = ImageHash.getPHash(holder.bitmap);
                                          Log.i(LOG_TAG, "calculate hash " + holder.path
                                                  + " [" + holder.bitmap.getWidth() + holder.bitmap.getHeight() + "]"
                                                  + ",timeCost:" + (System.currentTimeMillis() - t1) + "ms");
                                      }
//                              Log.i(LOG_TAG, "hash is:" + Long.toHexString(holder.phash));
                                  }
                                  return holders;
                              }
                          })
                          .subscribeOn(Schedulers.io())
                          .observeOn(AndroidSchedulers.mainThread())
                          .subscribe(new Subscriber<BitmapHolder[]>() {
                              final int UNKNOWN = -1;

                              long maxDistance = UNKNOWN;
                              int averageDistance = UNKNOWN;
                              int totalDistance = UNKNOWN;
                              int count = 0;

                              @Override
                              public void onCompleted() {
                                  long timeCostTotal = SystemClock.uptimeMillis() - probe_start_time;
                                  int code = ImageHashError.NOERR;
                                  long hwDecFrameFps = 0;
                                  long swDecFrameFps = 0;
                                  if (count > 0) {
                                      averageDistance = totalDistance / count;
                                      if (maxDistance != UNKNOWN
                                              && maxDistance <= 4
                                              && averageDistance <= 2) {

//                                          hwDecFrameFps = 1000L / (hwProbeResultHolder.timeCost / frameSeqFlat[frameSeqFlat.length - 1]);
                                          if (hwProbeResultHolder.avgDecFrameCost == 0) {
                                              // 硬解太快的话，耗时非常低有可能为0，造成误判
                                              hwProbeResultHolder.avgDecFrameCost = 1;
                                          }
                                          if (hwProbeResultHolder.avgDecFrameCost > 0) {
                                              hwDecFrameFps = 1000L / hwProbeResultHolder.avgDecFrameCost;
                                          }
//                                          if (hwDecFrameFps < 30) {
//                                              code = ImageHashError.ERROR_LOW_FPS;
//                                          }
                                          if (hwProbeResultHolder.avgDecFrameCost > 33) { // 硬解速度至少30帧每秒，才满足要求
                                              code = ImageHashError.ERROR_LOW_FPS;
                                          }
                                      } else {
                                          code = ImageHashError.ERROR_LARGE_DISTANCE;
                                      }
                                  } else {
                                      code = ImageHashError.ERROR_DECODE_FLOW;
                                  }

                                  if (swProbeResultHolder.avgDecFrameCost > 0) {
                                      swDecFrameFps = 1000L / swProbeResultHolder.avgDecFrameCost;
                                  }
                                  ProbeResult probeResult = new ProbeResult();
                                  probeResult.resultCode = code;
                                  probeResult.timeCostHwDecode = hwProbeResultHolder.timeCost;
                                  probeResult.fpsHwDec = hwDecFrameFps;
                                  probeResult.avgHwDecFrameCost = hwProbeResultHolder.avgDecFrameCost;
                                  probeResult.timeCostSwDecode = swProbeResultHolder.timeCost;
                                  probeResult.fpsSwDec = swDecFrameFps;
                                  probeResult.avgSwDecFrameCost = swProbeResultHolder.avgDecFrameCost;
                                  probeResult.timeCostTotal = timeCostTotal;
                                  probeResult.progress = allProgress.getProgress();

                                  PlayerUtils.log(QLog.INFO, LOG_TAG, "onCompleted maxDistance=" + maxDistance
                                          + ",averageDistance=" + averageDistance
                                          + ",totalDistance=" + totalDistance
                                          + ",hwDecodeTimeCost=" + hwProbeResultHolder.timeCost
                                          + ",swDecodeTimeCost=" + swProbeResultHolder.timeCost
                                          + ",totalTimeCost=" + (SystemClock.uptimeMillis() - probe_start_time)
                                          + ",hwDecFrameFPS=" + hwDecFrameFps
                                          + ",hwDecFrameCostAvg=" + probeResult.avgHwDecFrameCost
                                          + ",swDecFrameFPS=" + swDecFrameFps
                                          + ",swDecFrameCostAvg=" + probeResult.avgSwDecFrameCost
                                          + ",frameCount=" + count);

                                  callback.onProbeResult(probeResult);
                              }

                              @Override
                              public void onError(Throwable e) {
                                  PlayerUtils.log(QLog.ERROR, LOG_TAG,"哈希计算流程失败",e);
                                  long timeCostTotal = SystemClock.uptimeMillis() - probe_start_time;
                                  hashProgressMum.markFinishForce();
                                  ProbeResult result = new ProbeResult();
                                  result.resultCode = getErrorCode(e);
                                  result.timeCostHwDecode = hwProbeResultHolder.timeCost;
                                  result.timeCostSwDecode = swProbeResultHolder.timeCost;
                                  result.timeCostTotal = timeCostTotal;
                                  result.progress = allProgress.getProgress();
                                  callback.onProbeResult(result);
                              }

                              @Override
                              public void onNext(BitmapHolder[] holders) {
                                  for (BitmapHolder holder : holders) {
                                      if (holder.opts != null) {
                                          int sampleSize = OskBitmap.calculateInSampleSizeLow(holder.opts);
                                          String text = "原始图片:" + holder.opts.outWidth + "*" + holder.opts.outHeight + "\n"
                                                  + "sampleSize:" + sampleSize + "\n"
                                                  + "hash:" + Long.toHexString(holder.phash) + "\n";
                                          holder.tv.setText(text);
                                      } else {
                                          String text = "";
                                          holder.tv.setText(text);
                                      }
                                      if (holder.bitmap != null) {
                                          holder.iv.setImageBitmap(holder.bitmap);
                                      }
                                  }
                                  StringBuilder result = new StringBuilder("相似度:");
                                  for (int i=0; i < holders.length && (i+1 < holders.length); i+=2) {
                                      BitmapHolder a = holders[i];
                                      BitmapHolder b = holders[i+1];
                                      if (a.phash != ImageHash.HASH_ERROR && b.phash != ImageHash.HASH_ERROR) {
                                          long distance = ImageHash.getHammingDistance(a.phash, b.phash);
                                          result.append(distance);
                                          if (distance > maxDistance) {
                                              maxDistance = distance;
                                          }
                                          if (totalDistance == UNKNOWN) {
                                              totalDistance = 0;
                                          }
                                          totalDistance += distance;
                                          count++;
                                          hashProgressMum.updateStep(count);
                                      } else {
                                          result.append("err");
                                          PlayerUtils.log(QLog.WARN, LOG_TAG, "hash_error occurred");
                                      }
                                  }
                                  mViews.misc_desc.setText(result.toString());
                                  mViews.probe_progress.setProgress(Math.round(allProgress.getProgress() * mViews.probe_progress.getMax()));
                              }
                          });
                  //end doOnCompleted
              }
          })
          .doOnError(new Action1<Throwable>() {
              @Override
              public void call(Throwable e) {
                  PlayerUtils.log(QLog.ERROR, LOG_TAG,"解码流程失败 " + e);
                  long timeCostTotal = SystemClock.uptimeMillis() - probe_start_time;
                  hashProgressMum.markFinishForce();
                  swProgressMum.markFinishForce();
                  hwProgressMum.markFinishForce();
                  ProbeResult result = new ProbeResult();
                  result.resultCode = getErrorCode(e);
                  result.timeCostHwDecode = hwProbeResultHolder.timeCost;
                  result.timeCostSwDecode = swProbeResultHolder.timeCost;
                  result.timeCostTotal = timeCostTotal;
                  result.progress = allProgress.getProgress();
                  callback.onProbeResult(result);
              }
          })
          .subscribe(new Subscriber<ProbeResultHolder>() {
              @Override
              public void onCompleted() {
                  PlayerUtils.log(QLog.INFO, LOG_TAG, "ProbeCompleted");
              }

              @Override
              public void onError(Throwable e) {
                  PlayerUtils.log(QLog.INFO, LOG_TAG, "ProbeError", e);
              }

              @Override
              public void onNext(ProbeResultHolder result) {
                  mViews.probe_progress.setProgress(Math.round(allProgress.getProgress() * mViews.probe_progress.getMax()));
                  PlayerUtils.log(QLog.INFO, LOG_TAG, "ProbeEvent type:" + result.type + ",source:" + result.source + ",value=" + result.value);
              }
          });
    }

    private int getErrorCode(Throwable e) {
        if (e instanceof ImageHashError) {
            return ((ImageHashError) e).errCode;
        }
        return ImageHashError.ERROR_UNKNOWN;
    }

    private BitmapFactory.Options getBitmapBounds(String path) {
        BitmapFactory.Options option = new BitmapFactory.Options();
        option.inJustDecodeBounds = true;
        Rect paddingRect = new Rect();
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(path);
        } catch (IOException ioe) {
            ioe.printStackTrace();
            return null;
        }
        try {
            BitmapFactory.decodeStream(new BufferedInputStream(fis, 8192), paddingRect, option);
        } catch (OutOfMemoryError err) {
            showToast("内存占用过大，图片解码失败");
        } catch (Throwable e) {
            showToast(e.toString());
        }
        return option;
    }

    private Bitmap getBitmap(String path, BitmapFactory.Options options) {
        BitmapFactory.Options a = new BitmapFactory.Options();
//        a.outWidth = 800;
//        a.outHeight = 800;
//        Log.v("michalliu", "a" + calculateInSampleSize2(a, 400, 400));
        FileInputStream fis = null;
        int sampleSize = OskBitmap.calculateInSampleSizeLow(options);
        BitmapFactory.Options opt = new BitmapFactory.Options();
        opt.inSampleSize = sampleSize;
        opt.inPreferredConfig = Bitmap.Config.RGB_565;
        try {
            fis = new FileInputStream(path);
        } catch (IOException ioe) {
            ioe.printStackTrace();
            return null;
        }
        try {
            return BitmapFactory.decodeStream(new BufferedInputStream(fis, 8192), null, opt);
        } catch (OutOfMemoryError err) {
            showToast("内存占用过大，图片解码失败");
        } catch (Throwable e) {
            showToast(e.toString());
        }
        return null;
    }

    // 需要权限时返回true
    boolean maybeRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int result = checkSelfPermission(PERMISSIONS_STORAGE[0]);
            if (result != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);
                return true;
            }
        }
        return false;
    }

    private class ViewHolder {
        EditText pica;
        EditText picb;
        Button sela;
        Button selb;
        SimpleImageView disp_a;
        SimpleImageView disp_b;
        Button phash;
        Button ahash;
        Button h265_probe;
        Button h265_play;
        Button h264_probe;
        TextView desc_a;
        TextView desc_b;
        TextView misc_desc;
        TextView misc_desc_l2;
        ProgressBar probe_progress;
    }

    private class BitmapHolder {
        String path;
        SimpleImageView iv;
        TextView tv;
        Bitmap bitmap;
        long phash = 0;
        BitmapFactory.Options opts;
    }

    private class Setting {
        final String PREF_KEY_PICA_PATH = "picapath";
        final String PREF_KEY_PICB_PATH = "picbpath";
        final String PIC_PATH_DEFAULT = "";

        private SharedPreferences mPrefs;

        public Setting() {
            mPrefs = getApplicationContext().getSharedPreferences("image_hash_activity_settings", MODE_PRIVATE);
        }

        public void initViewHolderStatus(ViewHolder viewHolder) {
            viewHolder.pica.setText(mPrefs.getString(PREF_KEY_PICA_PATH, PIC_PATH_DEFAULT));
            viewHolder.picb.setText(mPrefs.getString(PREF_KEY_PICB_PATH, PIC_PATH_DEFAULT));

            final BitmapHolder bh1 = new BitmapHolder();
            bh1.iv = mViews.disp_a;
            bh1.tv = mViews.desc_a;
            bh1.path = viewHolder.pica.getText().toString();
            bh1.bitmap = null;

            BitmapHolder bh2 = new BitmapHolder();
            bh2.iv = mViews.disp_b;
            bh2.tv = mViews.desc_b;
            bh2.path = viewHolder.picb.getText().toString();
            bh2.bitmap = null;

            processBitmapHolder(bh1, bh2);
        }

        public void updateViewHolderStatus(ViewHolder viewHolder) {
            mPrefs.edit()
                    .putString(PREF_KEY_PICA_PATH,viewHolder.pica.getText().toString())
                    .putString(PREF_KEY_PICB_PATH,viewHolder.picb.getText().toString())
                    .apply();
        }
    }

    private void processBitmapHolder(final BitmapHolder... bhs) {
        Observable.from(bhs)
                .map(new Func1<BitmapHolder, BitmapHolder>() {
                    @Override
                    public BitmapHolder call(BitmapHolder holder) {
                        if (holder != null && !TextUtils.isEmpty(holder.path)) {
                            holder.opts = getBitmapBounds(holder.path);
                            holder.bitmap = getBitmap(holder.path, holder.opts);
                        }
                        return holder;
                    }
                })
                .map(new Func1<BitmapHolder, BitmapHolder>() {
                    @Override
                    public BitmapHolder call(BitmapHolder holder) {
                        // printPixelValue(holder.bitmap);
                        if (holder.bitmap != null) {
                            long t1 = System.currentTimeMillis();
                            holder.phash = ImageHash.getPHash(holder.bitmap);
                            Log.i(LOG_TAG, "calculate hash " + holder.path
                                    + " [" + holder.bitmap.getWidth() + holder.bitmap.getHeight() + "]"
                                    + ",timeCost:" + (System.currentTimeMillis() - t1) + "ms");
                        }
//                        Log.i(LOG_TAG, "hash is:" + Long.toHexString(holder.phash));
                        return holder;
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<BitmapHolder>() {
                    @Override
                    public void onCompleted() {
                        StringBuilder result = new StringBuilder("相似度:");
                        for (int i=0; i < bhs.length && (i+1 < bhs.length); i+=2) {
                            BitmapHolder a = bhs[i];
                            BitmapHolder b = bhs[i+1];
                            if (!TextUtils.isEmpty(a.path) && !TextUtils.isEmpty(b.path)) {
                                long distance = ImageHash.getHammingDistance(a.phash, b.phash);
                                result.append(distance).append("\n");
                            } else {
                                result.append("-").append("\n");
                            }
                        }
                        mViews.misc_desc.setText(StringUtil.removeLastChar(result.toString()));
//                        Log.v(LOG_TAG, "distanceTest:"
//                                + ImageHash.getHammingDistance(
//                                        new BigInteger("c91cb262705a95b1", 16).longValue(),
//                                new BigInteger("c90cb262775a95b0", 16).longValue()
//                        ));
                    }

                    @Override
                    public void onError(Throwable e) {
                        showToast("流程失败 " + e.toString());
                    }

                    @Override
                    public void onNext(BitmapHolder holder) {
                        if (holder.opts != null) {
                            int sampleSize = OskBitmap.calculateInSampleSizeLow(holder.opts);
                            String text = "原始图片:" + holder.opts.outWidth + "*" + holder.opts.outHeight + "\n"
                                    + "sampleSize:" + sampleSize + "\n"
                                    + "long:" + holder.phash + "\n"
                                    + "hash:" + Long.toHexString(holder.phash) + "\n"
                                    + "conv:" + new BigInteger(Long.toHexString(holder.phash),16).longValue();
                            holder.tv.setText(text);
                        } else {
                            String text = "";
                            holder.tv.setText(text);
                        }
                        if (holder.bitmap != null) {
                            holder.iv.setImageBitmap(holder.bitmap);
                        }
                    }
                });
    }

    private interface ProbeResultCallback {
        void onProbeResult(ProbeResult result);
    }

    private static class ProbeResult {
        int resultCode;
        long timeCostTotal;
        long timeCostHwDecode;
        long fpsHwDec;
        long avgHwDecFrameCost;
        long fpsSwDec;
        long avgSwDecFrameCost;
        long timeCostSwDecode;
        float progress;
    }
}
