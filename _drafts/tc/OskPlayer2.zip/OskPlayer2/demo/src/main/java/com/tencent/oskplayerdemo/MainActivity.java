package com.tencent.oskplayerdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.tencent.oskplayer.OskPlayer;
import com.tencent.oskplayer.OskPlayerConfig;
import com.tencent.oskplayer.cache.DefaultCacheKeyGenerator;
import com.tencent.oskplayer.util.DefaultLogger;
import com.tencent.oskplayer.util.PlayerUtils;
import com.tencent.oskplayer.util.QLog;
import com.tencent.oskplayerdemo.contrib.OskNative;
import com.tencent.oskplayerdemo.util.ColorUtil;

/**
 * Created by leoliu on 17/2/17.
 */

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initOskPlayer();
        OskNative.init();
    }

    @Override
    protected void onResume() {
        setContentView(R.layout.main);
        initUI();
        super.onResume();
    }

    private void testNative() {
        int result1 = OskNative.findClass("com/tencent/oskplayerdemo/BasicPlayActivitxy");
        PlayerUtils.log(QLog.INFO, "xx", "isclassfound com/tencent/oskplayerdemo/BasicPlayActivitxy" + result1);
        int result2 = OskNative.findClass("com/tencent/oskplayerdemo/BasicPlayActivity");
        PlayerUtils.log(QLog.INFO, "xx", "isclassfound com/tencent/oskplayerdemo/BasicPlayActivity" + result2);
    }

    private void initUI() {
        LinearLayout content = (LinearLayout) ((FrameLayout)findViewById(android.R.id.content)).getChildAt(0);
        Button demo1 = (Button) findViewById(R.id.demo1);
        Button demo2 = (Button) findViewById(R.id.demo2);
        Button demo3 = (Button) findViewById(R.id.demo3);
        Button demo4 = (Button) findViewById(R.id.demo4);
        Button demo5 = (Button) findViewById(R.id.demo5);
        Button demo6 = (Button) findViewById(R.id.demo6);
        Button demo7 = (Button) findViewById(R.id.demo7);
        Button demo8 = (Button) findViewById(R.id.demo8);

        demo1.setOnClickListener(mClickListener);
        demo2.setOnClickListener(mClickListener);
        demo3.setOnClickListener(mClickListener);
        demo4.setOnClickListener(mClickListener);
        demo5.setOnClickListener(mClickListener);
        demo6.setOnClickListener(mClickListener);
        demo7.setOnClickListener(mClickListener);
        demo8.setOnClickListener(mClickListener);

        content.setBackground(ColorUtil.getRandomDosifyGradientDrawable());
//        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }

    private void initOskPlayer() {
        OskPlayerConfig cfg = new OskPlayerConfig();
        cfg.setEnableHLSCache(true);
        cfg.setDebugVersion(true);
        cfg.setLogger(new DefaultLogger());
        // 默认的缓存key生成算法
        cfg.setCacheKeyGenerator(new DefaultCacheKeyGenerator());
        cfg.setEnableSSLVerify(false);
        OskPlayer.init(this.getApplicationContext(), cfg);
    }

    private void demo1Func() {
        Intent intent = new Intent(MainActivity.this, PreloadDemoActivity.class);
        startActivity(intent);
    }

    private void demo2Func() {
        Intent intent = new Intent(MainActivity.this, BasicPlayActivity.class);
        startActivity(intent);
    }

    private void demo3Func() {
        Intent intent = new Intent(MainActivity.this, MediaCodecDemoActivity.class);
        startActivity(intent);
    }

    private void demo4Func() {
        Intent intent = new Intent(MainActivity.this, PlayerActivitySurfaceView.class);
        startActivity(intent);
    }

    private void demo5Func() {
        Intent intent = new Intent(MainActivity.this, PlayerCompareActivity.class);
        startActivity(intent);
    }

    private void demo6Func() {
        Intent intent = new Intent(MainActivity.this, ImageHashActivity.class);
        startActivity(intent);
    }

    private void demo7Func() {
        Intent intent = new Intent(MainActivity.this, HwProbeActivity.class);
        startActivity(intent);
    }

    private void demo8Func() {
        Intent intent = new Intent(MainActivity.this, OskMediaExtractorDemoActivity.class);
        startActivity(intent);
    }

    private View.OnClickListener mClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (view.getId() == R.id.demo1) {
                demo1Func();
            } else if (view.getId() == R.id.demo2) {
                demo2Func();
            } else if (view.getId() == R.id.demo3) {
                demo3Func();
            } else if (view.getId() == R.id.demo4) {
                demo4Func();
            } else if (view.getId() == R.id.demo5) {
                demo5Func();
            } else if (view.getId() == R.id.demo6) {
                demo6Func();
            } else if (view.getId() == R.id.demo7) {
                demo7Func();
            } else if (view.getId() == R.id.demo8) {
                demo8Func();
            }
        }
    };

}
