#include <jni.h>
#include "log.h"
#include "libyuv.h"

void YuvDecodeYUVtoRBGA(JNIEnv * env, jobject obj, jbyteArray yuv420sp, jint width, jint height, jintArray rgbOut)
{
    int             sz;
    int             i;
    int             j;
    int             Y;
    int             Cr = 0;
    int             Cb = 0;
    int             pixPtr = 0;
    int             jDiv2 = 0;
    int             R = 0;
    int             G = 0;
    int             B = 0;
    int             cOff;
    int w = width;
    int h = height;
    sz = w * h;

    jint *rgbData = (jint*) ((*env)->GetPrimitiveArrayCritical(env, rgbOut, 0));
    jbyte* yuv = (jbyte*) (*env)->GetPrimitiveArrayCritical(env, yuv420sp, 0);

    for(j = 0; j < h; j++) {
        pixPtr = j * w;
        jDiv2 = j >> 1;
        for(i = 0; i < w; i++) {
            Y = yuv[pixPtr];
            if(Y < 0) Y += 255;
            if((i & 0x1) != 1) {
                cOff = sz + jDiv2 * w + (i >> 1) * 2;
                Cb = yuv[cOff];
                if(Cb < 0) Cb += 127; else Cb -= 128;
                Cr = yuv[cOff + 1];
                if(Cr < 0) Cr += 127; else Cr -= 128;
            }

            //ITU-R BT.601 conversion
            //
            //R = 1.164*(Y-16) + 2.018*(Cr-128);
            //G = 1.164*(Y-16) - 0.813*(Cb-128) - 0.391*(Cr-128);
            //B = 1.164*(Y-16) + 1.596*(Cb-128);
            //
            Y = Y + (Y >> 3) + (Y >> 5) + (Y >> 7);
            R = Y + (Cr << 1) + (Cr >> 6);
            if(R < 0) R = 0; else if(R > 255) R = 255;
            G = Y - Cb + (Cb >> 3) + (Cb >> 4) - (Cr >> 1) + (Cr >> 3);
            if(G < 0) G = 0; else if(G > 255) G = 255;
            B = Y + Cb + (Cb >> 1) + (Cb >> 4) + (Cb >> 5);
            if(B < 0) B = 0; else if(B > 255) B = 255;
            rgbData[pixPtr++] = 0xff000000 + (R << 16) + (G << 8) + B;
        }
    }

    (*env)->ReleasePrimitiveArrayCritical(env, rgbOut, rgbData, 0);
    (*env)->ReleasePrimitiveArrayCritical(env, yuv420sp, yuv, 0);
}

void YuvDecodeYUVtoARBG(JNIEnv * env, jobject obj, jbyteArray yuv420sp, jint width, jint height, jintArray rgbOut)
{
    int             sz;
    int             i;
    int             j;
    int             Y;
    int             Cr = 0;
    int             Cb = 0;
    int             pixPtr = 0;
    int             jDiv2 = 0;
    int             R = 0;
    int             G = 0;
    int             B = 0;
    int             cOff;
    int w = width;
    int h = height;
    sz = w * h;

    jint *rgbData = (jint*) ((*env)->GetPrimitiveArrayCritical(env, rgbOut, 0));
    jbyte* yuv = (jbyte*) (*env)->GetPrimitiveArrayCritical(env, yuv420sp, 0);

    for(j = 0; j < h; j++) {
        pixPtr = j * w;
        jDiv2 = j >> 1;
        for(i = 0; i < w; i++) {
            Y = yuv[pixPtr];
            if(Y < 0) Y += 255;
            if((i & 0x1) != 1) {
                cOff = sz + jDiv2 * w + (i >> 1) * 2;
                Cb = yuv[cOff];
                if(Cb < 0) Cb += 127; else Cb -= 128;
                Cr = yuv[cOff + 1];
                if(Cr < 0) Cr += 127; else Cr -= 128;
            }

            //ITU-R BT.601 conversion
            //
            //R = 1.164*(Y-16) + 2.018*(Cr-128);
            //G = 1.164*(Y-16) - 0.813*(Cb-128) - 0.391*(Cr-128);
            //B = 1.164*(Y-16) + 1.596*(Cb-128);
            //
            Y = Y + (Y >> 3) + (Y >> 5) + (Y >> 7);
            R = Y + (Cr << 1) + (Cr >> 6);
            if(R < 0) R = 0; else if(R > 255) R = 255;
            G = Y - Cb + (Cb >> 3) + (Cb >> 4) - (Cr >> 1) + (Cr >> 3);
            if(G < 0) G = 0; else if(G > 255) G = 255;
            B = Y + Cb + (Cb >> 1) + (Cb >> 4) + (Cb >> 5);
            if(B < 0) B = 0; else if(B > 255) B = 255;
            rgbData[pixPtr++] = 0xff000000 + (B << 16) + (G << 8) + R;
        }
    }

    (*env)->ReleasePrimitiveArrayCritical(env, rgbOut, rgbData, 0);
    (*env)->ReleasePrimitiveArrayCritical(env, yuv420sp, yuv, 0);
}

void yuvConvertI420toARBG(JNIEnv * env, jobject obj, jbyteArray i420, jint width, jint height, jintArray rgbOut)
{
    int             sz;
    int             i;
    int             j;
    int             Y;
    int             Cr = 0;
    int             Cb = 0;
    int             pixPtr = 0;
    int             jDiv2 = 0;
    int             R = 0;
    int             G = 0;
    int             B = 0;
    int             vOff;
    int             cOff;
    int             vOffBase;
    int w = width;
    int h = height;
    sz = w * h;
    vOffBase = sz + (sz >> 2);

    jint *rgbData = (jint*) ((*env)->GetPrimitiveArrayCritical(env, rgbOut, 0));
    jbyte* yuv = (jbyte*) (*env)->GetPrimitiveArrayCritical(env, i420, 0);

    for(j = 0; j < h; j++) {
        pixPtr = j * w;
        jDiv2 = j >> 1;
        for(i = 0; i < w; i++) {
            Y = yuv[pixPtr];
            if(Y < 0) Y += 256;
            if((i & 0x1) != 1) {
//                cOff = sz + jDiv2 * w + (i >> 1) * 2;
                cOff = sz + jDiv2 * (w >> 1) + (i >> 1);
                Cb = yuv[cOff];
                if(Cb < 0) Cb += 127; else Cb -= 128;
                vOff = vOffBase + jDiv2 * (w >> 1) + (i >> 1);
                Cr = yuv[vOff];
                if(Cr < 0) Cr += 127; else Cr -= 128;
            }

            //ITU-R BT.601 conversion
            //
            //R = 1.164*(Y-16) + 2.018*(Cr-128);
            //G = 1.164*(Y-16) - 0.813*(Cb-128) - 0.391*(Cr-128);
            //B = 1.164*(Y-16) + 1.596*(Cb-128);
            //
            Y = Y + (Y >> 3) + (Y >> 5) + (Y >> 7);
            R = Y + (Cr << 1) + (Cr >> 6);
            if(R < 0) R = 0; else if(R > 255) R = 255;
            G = Y - Cb + (Cb >> 3) + (Cb >> 4) - (Cr >> 1) + (Cr >> 3);
            if(G < 0) G = 0; else if(G > 255) G = 255;
            B = Y + Cb + (Cb >> 1) + (Cb >> 4) + (Cb >> 5);
            if(B < 0) B = 0; else if(B > 255) B = 255;
            rgbData[pixPtr++] = 0xff000000 + (R << 16) + (G << 8) + B;
        }
    }

    (*env)->ReleasePrimitiveArrayCritical(env, rgbOut, rgbData, 0);
    (*env)->ReleasePrimitiveArrayCritical(env, i420, yuv, 0);
}

void yuvConvertJ420toARBG(JNIEnv * env, jobject obj, jbyteArray j420, jint width, jint height, jintArray rgbOut)
{
    int             sz;
    int             i;
    int             j;
    int             Y;
    int             Cr = 0;
    int             Cb = 0;
    int             pixPtr = 0;
    int             jDiv2 = 0;
    int             R = 0;
    int             G = 0;
    int             B = 0;
    int             vOff;
    int             uOff;
    int             vOffBase;
    int w = width;
    int h = height;
    sz = w * h;
    vOffBase = sz + (sz >> 2);

    jint *rgbData = (jint*) ((*env)->GetPrimitiveArrayCritical(env, rgbOut, 0));
    jbyte* yuv = (jbyte*) (*env)->GetPrimitiveArrayCritical(env, j420, 0);

    for(j = 0; j < h; j++) {
        pixPtr = j * w;
        jDiv2 = j >> 1;
        for(i = 0; i < w; i++) {
            Y = yuv[pixPtr];
            if(Y < 0) Y += 256;
            if((i & 0x1) != 1) {
                uOff = sz + jDiv2 * (w >> 1) + (i >> 1);
                Cb = yuv[uOff];
#if 0
                if (Cb<0) Cb += 256;
#else
                if(Cb < 0) Cb += 127; else Cb -= 128;
#endif
                vOff = vOffBase + jDiv2 * (w >> 1) + (i >> 1);
                Cr = yuv[vOff];
#if 0
                if(Cr<0) Cr += 256;
#else
                if(Cr < 0) Cr += 127; else Cr -= 128;
#endif
            }

//            R = Y + 1.402 * (Cr - 128)
//            G = Y - 0.3441362862 * (Cb-128) - 0.7141362862*(Cr-128)
//            B = Y + 1.772 * (Cb - 128)

#if 0
            R = (int) (Y + 1.402 * (Cr - 128));
            G = (int) (Y - 0.344 * (Cb - 128) - 0.714 * (Cr - 128));
            B = (int) (Y+ 1.772 * (Cb - 128));
#else
//            R = (int) (Y + 1.402 * Cr);
//            G = (int) (Y - 0.344 * Cb - 0.714 * Cr);
//            B = (int) (Y+ 1.772 * Cb);
//            R = (int) (Y + 1.402 * Cr);
            R = Y + Cr + (Cr >> 2) + (Cr >> 3) + (Cr >> 5);
            G = (int) (Y - (Cb >> 2) - (Cb >> 4) - (Cb >> 5) - (Cr >> 1) - (Cr >> 3) - (Cr >> 4) - (Cr >> 5));
            B = (int) (Y+ Cb + (Cb >> 1) + (Cb >> 2) + (Cb >> 6));
#endif
            R = R < 0 ? 0 : (R > 255 ? 255 : R);
            G = G < 0 ? 0 : (G > 255 ? 255 : G);   //这里会增加10-15ms
            B = B < 0 ? 0 : (B > 255 ? 255 : B);

            rgbData[pixPtr++] = 0xff000000 + (R << 16) + (G << 8) + B;
        }
    }

//    for (int i=0; i < sz; i++) {
//        if (i < 5) {
//            ALOGI("NON-NEON ARGB[%d]->%02X", i, rgbData[i]);
//        }
//        uint8 A = (rgbData[i] >> 24) & 0xFF; if (i < 5) ALOGI("NON-NEON A %02X", A);
//        uint8 R = (rgbData[i] >> 16) & 0xFF; if (i < 5) ALOGI("NON-NEON B %02X", B);
//        uint8 G = (rgbData[i] >> 8) & 0xFF;  if (i < 5) ALOGI("NON-NEON G %02X", G);
//        uint8 B = rgbData[i] & 0xFF; if (i < 5) ALOGI("NON-NEON R %02X", R);
//
//        rgbData[i] = (A << 24) + (B << 16) + (G << 8) + R;
//        if (i < 5) {
//            ALOGI("NONE-NEON ABGR[%d]->%02X", i, rgbData[i]);
//        }
//    }

    (*env)->ReleasePrimitiveArrayCritical(env, rgbOut, rgbData, 0);
    (*env)->ReleasePrimitiveArrayCritical(env, j420, yuv, 0);
}
//int I420ToARGB(const uint8* src_y, int src_stride_y,
//               const uint8* src_u, int src_stride_u,
//               const uint8* src_v, int src_stride_v,
//               uint8* dst_argb, int dst_stride_argb,
//               int width, int height);
//
void yuvConvertI420toARBGFast(JNIEnv * env, jobject obj, jbyteArray yuv420sp, jint width, jint height, jintArray rgbOut) {
    int w = width;
    int h = height;
    int sz = w * h;
    int vOffBase = sz + (sz >> 2);

    jint *rgbData = (jint *) ((*env)->GetPrimitiveArrayCritical(env, rgbOut, 0));
    jbyte *yuv = (jbyte *) (*env)->GetPrimitiveArrayCritical(env, yuv420sp, 0);

    //__________________
//    int j=0;
//    int i=0;
//    int pixPtr=0;
//    int vOff;
//    int uOff;
//    int jDiv2=0;
//    for(j = 0; j < h; j++) {
//        pixPtr = j * w;
//        jDiv2 = j >> 1;
//        for(i = 0; i < w; i++) {
//            yuv[pixPtr] = 210;// modifyY
//            if((i & 0x1) != 1) {
//                uOff = sz + jDiv2 * (w >> 1) + (i >> 1);
//                yuv[uOff] = 16;
//                vOff = vOffBase + jDiv2 * (w >> 1) + (i >> 1);
//                yuv[vOff] = 146;
//            }
//            pixPtr++;
//        }
//    }
    //___________________

    J420ToARGB(yuv, w, yuv + sz, w >> 1, yuv + vOffBase, w >> 1, (uint8 *)rgbData, w * 4, w, h);

//    for (int i=0; i < sz; i++) {
//        if (count++ > 10) break;
//        if (i < 5) {
//            ALOGI("NEON ARGB[%d]->%02X", i, rgbData[i]);
//
//            uint8 A = (rgbData[i] >> 24) & 0xFF; if (i < 5) ALOGI("NON-NEON A %02X", A);
//            uint8 R = (rgbData[i] >> 16) & 0xFF; if (i < 5) ALOGI("NON-NEON R %02X", R);
//            uint8 G = (rgbData[i] >> 8) & 0xFF;  if (i < 5) ALOGI("NON-NEON G %02X", G);
//            uint8 B = rgbData[i] & 0xFF; if (i < 5) ALOGI("NON-NEON B %02X", B);
//
//            rgbData[i] = (A << 24) + (B << 16) + (G << 8) + R;
//        }
//    }

    (*env)->ReleasePrimitiveArrayCritical(env, rgbOut, rgbData, 0);
    (*env)->ReleasePrimitiveArrayCritical(env, yuv420sp, yuv, 0);
}