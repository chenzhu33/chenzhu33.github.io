#include <jni.h>
#include <android/bitmap.h>
#include <unistd.h>
#include <pthread.h>
#include <assert.h>
#include "common.h"
#include "misc.h"
#include "log.h"
#include "yuv/yuvdecode.h"
#include "imagehash.h"

#define JNI_CLASS_NATIVE_INTERFACE   "com/tencent/oskplayerdemo/contrib/OskNative"

static JavaVM* g_jvm;

typedef struct methods_holder_t {
    pthread_mutex_t mutex;
    jclass clazz;
} methods_holder;

static methods_holder g_methods_holder;

static jint
OSK_findClass(JNIEnv *env, jobject thiz, jstring clazz) {
    const char* clazzName = (*env)->GetStringUTFChars(env, clazz, JNI_FALSE);
    //FIXME: not released when class not found
    jclass theClazz;
    OSK_FIND_JAVA_CLASS(env, theClazz, clazzName);
    (*env)->ReleaseStringUTFChars(env, clazz, clazzName);
    (*env)->DeleteGlobalRef(env, theClazz);
    return 0;
}

static jlong calculateBitmapHash(JNIEnv * env, jobject jclass, jobject bitmap, jint algorithm) {
    AndroidBitmapInfo info;
    void* pixels = NULL;
    int ret;
    jlong result = 0;

    if ((ret = AndroidBitmap_getInfo(env, bitmap, &info)) < 0) {
        ALOGE("AndroidBitmap_getInfo() failed ! error=%d", ret);
        return result;
    }

    if (info.width <= 0 || info.height <= 0) {
        ALOGE("Invalid Bitmap %d %d!", info.width, info.height);
        return result;
    }

    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888 &&
            info.format != ANDROID_BITMAP_FORMAT_RGB_565) {
        ALOGE("Invalid Bitmap format %d !", info.format);
        return result;
    }

    if ((ret = AndroidBitmap_lockPixels(env, bitmap, &pixels)) < 0) {
        ALOGE("AndroidBitmap_lockPixels() failed ! error=%d", ret);
        return result;
    }

    if (pixels == NULL) {
        ALOGE("AndroidBitmap_lockPixels() failed !");
        return result;
    }

    switch(algorithm) {
        case 1: // PHASH
            result = dct_image_hash(pixels, info);
            break;
        case 2: // OHASH (stands for oskplayer hash algorithm)
            break;
        case 3: // MSE
            break;
        default:
            result = dct_image_hash(pixels, info);
    }

    AndroidBitmap_unlockPixels(env, bitmap);

    return result;
}

static jlong calculateHammingDistance(JNIEnv * env, jobject jclass, jlong hash1, jlong hash2) {
    return hamming_distance(hash1, hash2);
}

static JNINativeMethod g_methods[] = {
        {"findClass","(Ljava/lang/String;)I", (void *) OSK_findClass},
        {"yuvDecodeYUVtoRBGA","([BII[I)V", (void *) YuvDecodeYUVtoRBGA},
        {"yuvDecodeYUVtoARBG","([BII[I)V", (void *) YuvDecodeYUVtoARBG},
        {"yuvConvertI420toARBG","([BII[I)V", (void *) yuvConvertI420toARBGFast},
        {"getHash","(Landroid/graphics/Bitmap;I)J", (void *) calculateBitmapHash},
        {"getHammingDistance","(JJ)J", (void *) calculateHammingDistance},
};

JNIEXPORT jint JNI_OnLoad(JavaVM *vm, void *reserved)
{
    ALOGI("JNI_OnLoad %s", __BASE_FILE__);
    JNIEnv* env = NULL;

    g_jvm = vm;
    if ((*vm)->GetEnv(vm, (void**) &env, JNI_VERSION_1_4) != JNI_OK) {
    return -1;
    }
    assert(env != NULL);

    pthread_mutex_init(&g_methods_holder.mutex, NULL );

    // FindClass returns LocalReference
    OSK_FIND_JAVA_CLASS(env, g_methods_holder.clazz, JNI_CLASS_NATIVE_INTERFACE);
    (*env)->RegisterNatives(env, g_methods_holder.clazz, g_methods, NELEM(g_methods) );

    //ijkmp_global_init();
    //ijkmp_global_set_inject_callback(inject_callback);

    //FFmpegApi_global_init(env);

    return JNI_VERSION_1_4;
}

JNIEXPORT void JNI_OnUnload(JavaVM *jvm, void *reserved)
{
    ALOGI("JNI_UnLoad %s",  __BASE_FILE__);
//    ijkmp_global_uninit();

    pthread_mutex_destroy(&g_methods_holder.mutex);
}

//http://blog.tingyun.com/web/article/detail/921