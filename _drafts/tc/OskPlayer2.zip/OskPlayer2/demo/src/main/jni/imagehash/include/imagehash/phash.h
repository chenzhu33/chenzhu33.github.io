#ifndef INCLUDE_IMAGEHASH_PHASH_H_
#define INCLUDE_IMAGEHASH_PHASH_H_

#ifdef __cplusplus
#include <jni.h>
#include <android/bitmap.h>
#define cimg_use_jpeg
#define cimg_display 0
#define cimg_OS 1
#include "cimg/CImg.h"
#include <sstream>

#include <iomanip>
#include "log.h"


#define phash_debug 0

#define RGB565_R(p) ((((((p) >> 11) & 0x1F) * 527) + 23) >> 6)
#define RGB565_G(p) ((((((p) >> 5) & 0x3F) * 259) + 33) >> 6)
#define RGB565_B(p) (((((p) & 0x1F) * 527) + 23) >> 6)


#define RGBA_A(p) (((p) & 0xFF000000) >> 24)
#define RGBA_B(p) (((p) & 0x00FF0000) >> 16)
#define RGBA_G(p) (((p) & 0x0000FF00) >>  8)
#define RGBA_R(p)  ((p) & 0x000000FF)

typedef unsigned long long ulong64;

using namespace cimg_library;

extern "C" {
#endif

jlong dct_image_hash(void* pixels, AndroidBitmapInfo info);
jlong hamming_distance(jlong hash1, jlong hash2);

#ifdef __cplusplus
}
#endif

#endif  // INCLUDE_IMAGEHASH_PHASH_H_