#include <android/bitmap.h>
#include "imagehash/phash.h"

static CImg<double_t >* dct_matrix(const int N){
    CImg<double_t> *ptr_matrix = new CImg<double_t>(N,N,1,1,1/sqrt((float)N));
    const double_t c1 = sqrt(2.0/N);
    for (uint32_t x=0;x<N;x++){ // x(width)->j, y(height)->i
        for (uint32_t y=1;y<N;y++){
            *ptr_matrix->data(x,y) = c1*cos((cimg::PI/2/N)*y*(2*x+1));
        }
    }
    return ptr_matrix;
}

static ulong64 calculate_hamming_distance(const ulong64 hash1, const ulong64 hash2) {
    ulong64 x=hash1^hash2;
    const ulong64 m1 = 0x5555555555555555ULL;
    const ulong64 m2 = 0x3333333333333333ULL;
    const ulong64 h01 = 0x0101010101010101ULL;
    const ulong64 m4 = 0x0f0f0f0f0f0f0f0fULL;
    x -= (x >> 1) & m1;
    x = (x & m2) + ((x >> 2) & m2);
    x = (x + (x >> 4)) & m4;
    return (x * h01) >> 56;
}

static int dct_image_hash(CImg<uint8_t>& src, ulong64 &hash) {
    CImg<float> meanfilter(7,7,1,1,1); // x,y,d,v,c
    CImg<float> img;

    if (src.spectrum() == 3) {
        img = src.RGBtoYCbCr().channel(0).get_convolve(meanfilter);
    } else if (src.spectrum() == 4) {
        int width = img.width();
        int height = img.height();
        int depth = img.depth();
        img = src.crop(0, 0, 0, 0, width-1, height-1,depth-1,2)
                .RGBtoYCbCr()
                .channel(0)
                .get_convolve(meanfilter);
    } else {
        img = src.channel(0).get_convolve(meanfilter);
    }
    img.resize(32,32);
    CImg<double_t > *C = dct_matrix(32);
    CImg<float> cTrans = C->get_transpose();

    CImg<float> dctImage = (*C) * img * cTrans;
    CImg<float> subSec = dctImage.crop(2, 2, 9, 9);
    subSec = subSec.unroll('x');

    float median = subSec.median();
    ulong64 one = 0x0000000000000001;
    hash = 0x0000000000000000;

    for (uint32_t i=0; i<64; i++) {
        float current = subSec(i);
        if (current > median) {
            hash |= one;
        }
        one = one << 1;
    }
    delete C;
    return 0;
}

static std::string hex_value_16(uint16_t value) {
    char res[5]; /* two bytes of hex = 4 characters, plus NULL terminator */

    if (value <= 0xFFFF)
    {
        sprintf(&res[0], "%04x", value);
    }
    std::string s(res);
    return s;
}

static std::string hex_value_64(ulong64 value) {
    char res[17];
    if (value <= 0xFFFFFFFFFFFFFFFF) {
        sprintf(&res[0], "%llx", value);
    }
    std::string s(res);
    return s;
}

std::string format(int num) {
    std::ostringstream oss;
    oss << num;
    return oss.str();
};

jlong dct_image_hash(void* pixels, AndroidBitmapInfo info) {
    CImg<uint8_t> img(info.width, info.height, 1, 3, 0); // width, height, depth, spectrum
    uint32_t x=0, y=0;

#if defined(phash_debug) && phash_debug == 1
    std::string hexOut = "";
    std::string redOut = "";
    std::string greenOut = "";
    std::string blueOut = "";
    std::string alphaOut = "";
#endif

    // top->bottom
    for (y = 0; y < info.height; y++) {
        // left->right
        for (x = 0; x < info.width; x++) {
            int a = -1, r = 0, g = 0, b = 0;
            void* pixel = NULL;
            if (info.format == ANDROID_BITMAP_FORMAT_RGBA_8888) {
                //ARGBARGBARGB
                pixel = (uint32_t *)pixels + y * info.width + x;
                uint32_t v = *(uint32_t *)pixel;
                // drop alpha
                a = RGBA_A(v);
                r = (int) (RGBA_R(v) * 255.0 / a + 0.5);
                g = (int) (RGBA_G(v) * 255.0 / a + 0.5);
                b = (int) (RGBA_B(v) * 255.0 / a + 0.5);

#if defined(phash_debug) && phash_debug == 1
                redOut += format(r);redOut += ",";
                greenOut += format(g);greenOut += ",";
                blueOut += format(b);blueOut += ",";
                alphaOut += format(a);alphaOut += ",";
#endif
                img(x, y) = (uint8_t)r;
                img(x, y, 0, 1) = (uint8_t)g;
                img(x, y, 0, 2) = (uint8_t)b;
            } else if (info.format == ANDROID_BITMAP_FORMAT_RGB_565) {
                //RGBRGBRGB
                pixel = (uint16_t *)pixels + y * info.width + x;
                uint16_t v = *(uint16_t *)pixel;
                // no alpha
                r = RGB565_R(v);
                g = RGB565_G(v);
                b = RGB565_B(v);

                img(x, y) = (uint8_t)r;
                img(x, y, 0, 1) = (uint8_t)g;
                img(x, y, 0, 2) = (uint8_t)b;
                img(x, y, 0, 2) = (uint8_t)b;

#if defined(phash_debug) && phash_debug == 1
                hexOut += hex_value_16(v); hexOut += ",";
                redOut += format(r);redOut += ",";
                greenOut += format(g);greenOut += ",";
                blueOut += format(b);blueOut += ",";
                alphaOut += format(a);alphaOut += ",";
#endif
            }
        }
#if defined(phash_debug) && phash_debug == 1
        hexOut += "\n";
        redOut += "\n";
        greenOut += "\n";
        blueOut += "\n";
        alphaOut += "\n";
#endif
    }

#if defined(phash_debug) && phash_debug == 1
    ALOGI("%s", ("jni_S:\n" + format(info.width) + "*" + format(info.height)).c_str());
    ALOGI("%s", ("jni_H:\n" + hexOut).c_str());
    ALOGI("%s", ("jni_R:\n" + redOut).c_str());
    ALOGI("%s", ("jni_G:\n" + greenOut).c_str());
    ALOGI("%s", ("jni_B:\n" + blueOut).c_str());
    ALOGI("%s", ("jni_A:\n" + alphaOut).c_str());
#endif

    ulong64 hash = 0x0000000000000000;

#if defined(phash_debug) && phash_debug == 1
    char buff[100];
    snprintf(buff, sizeof(buff), "/sdcard/test.jpg");
    img.save(buff);
#endif
    dct_image_hash(img, hash);
    std::string hex = hex_value_64(hash);
    ALOGI("dct_image_hash %s", hex.c_str());
    return hash;
}

static int dct_image_hash(const char* file, ulong64 &hash) {
    if (!file) {
        return -1;
    }
    CImg<uint8_t> src;
    try {
        src.load(file);
    } catch(CImgIOException ex) {
        return -1;
    }
    return dct_image_hash(src, hash);
}

jlong hamming_distance(jlong hash1, jlong hash2) {
    return calculate_hamming_distance(hash1, hash2);
}