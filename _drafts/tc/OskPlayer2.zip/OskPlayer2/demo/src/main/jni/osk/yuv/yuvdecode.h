#ifndef INCLUDE_YUV_YUVDECODE_H_
#define INCLUDE_YUV_YUVDECODE_H_
void YuvDecodeYUVtoRBGA(JNIEnv * env, jobject obj, jbyteArray yuv420sp, jint width, jint height, jintArray rgbOut);
void YuvDecodeYUVtoARBG(JNIEnv * env, jobject obj, jbyteArray yuv420sp, jint width, jint height, jintArray rgbOut);
void yuvConvertI420toARBG(JNIEnv * env, jobject obj, jbyteArray i420, jint width, jint height, jintArray rgbOut);
void yuvConvertI420toARBGFast(JNIEnv * env, jobject obj, jbyteArray i420, jint width, jint height, jintArray rgbOut);
#endif