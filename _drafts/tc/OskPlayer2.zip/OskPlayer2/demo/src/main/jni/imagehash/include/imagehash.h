#ifndef INCLUDE_IMAGEHASH_H_
#define INCLUDE_IMAGEHASH_H_

#include "imagehash/phash.h"

#endif  // INCLUDE_IMAGEHASH_H_