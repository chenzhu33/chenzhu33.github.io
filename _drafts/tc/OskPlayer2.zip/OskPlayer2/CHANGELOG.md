v1.6.0(2019.2.25)
- 功能：Beta版`OskMeidaExtractor`实现,用以替换系统 `MediaExtractor`,接口与系统保持一致
- 下载：修复多线程环境下安全token解析报 BadPaddingException (by harveyxia)
- 下载：修复批量获取下载地址接口,没有指定header时的NP
- 下载：添加代理内部错误监控,即非下载阶段的异常,参见IllegalDataSpecException
- 下载：默认允许使用`原始url`重连
- 下载：可通过OskPlayerConfig.setEnableSSLVerify接口关闭SSL客户端证书校验,解决HTTPS IP直出情况下证书与域名不匹配导致的下载异常.相关提交: bfeed3b3
- 下载：修复文件名含有空格时通过代理无法播放的问题
- 缓存：缓存文件打开或写入异常均不影响播放.相关提交: 1670f92d, d94f3cc1,8a13449
- 缓存：确保设置的缓存总大小不大于实际剩余空间 (by harveyxia) 相关提交: 18d26e7e
- 缓存：缓存文件版本号升级为v5
- 播放：修复timorzheng反馈的AbstractMediaPlayer的一处死锁问题. [issue 13](https://git.code.oa.com/michalliu/OskPlayer2/issues/13)
- 播放：播放错误码细化,区分下载导致的解码异常和真正的解码异常. [a6be0eeb](https://git.code.oa.com/oskplayer2/mediaplayer-extension/commit/a6be0eebf9564fe53b2620abefdfbc98db79baad)
- 播放：添加**预热解码器**接口warmDecoder,提升首次播放视频性能
- 播放：硬件解码器创建异常时自动降级到系统可用的软件解码器 [6d73ff4b](https://git.code.oa.com/oskplayer2/exoplayer/commit/6d73ff4bea43c2134950e99ea62c7f5e576f5017)
- 工具：改进堆栈LOG打印能力OskDebug.getPrintableStackTrace,避免出现堆栈过深而无法打印出现`... xx more`的尴尬局面
- Demo: 支持切换surface能力测试PlayerActivitySurfaceView

v1.5.9
- 下载：log性能改进，合并多行log到单行
- 下载：完善多线程取消下载的能力，可通过VideoRequest跟踪原因
- 下载：完善HLS/M3U8预下载请求取消逻辑
- 解码：完善硬解探测异常捕获，错误码更加细化全面
- 解码：修复硬解MediaFormat.getTrackFormat失败的问题
- 解码：修复硬解探测模块创建输出图片目录创建失败的crash
- 播放：硬解探测在手Q空间接入接口优化，以及移除rxjava依赖
- 播放：ffsegmentmediaplayer循环播实现onLoopStart接口
- 播放：修复OskExoMediaplayer多线程下NP的问题
- 播放：硬解探测结果改进，分为6种情况返回（原来为4种）
- 播放：硬解探测修复软解丢帧引起的帧数不匹配可能造成的误判
- 播放：硬解探测修复硬解速度过快(<1ms)引起的误判
- 播放：ijkplayer支持pre-reading-buffer（QQ音乐贡献）
- 播放：修复并行解码抛的异常可以抛出onError事件
- 播放：修复升级exoplayer引起直播回放必现失败的问题(TS格式不兼容)
- 播放：修复mediaplayer-extension的reset接口未按照预期实现(兴趣阅读反馈的问题)
- 播放：修复mediaplayer-extension的isPlaying接口在循环播切换的一瞬间状态不对问题
- 播放：mediaplayer-extension实现函数获取当前视频的音视频解码器信息，真实码率等信息
- 播放：mediaplayer-extension移除字幕解析，章节解析，元数据解析减少首次缓冲耗时
- 播放：mediaplayer-extension支持设置外部Logger
- 播放：mediaplayer-extension支持多mp4无缝拼接模式播放
- 播放：mediaplayer-extension的notifyOnBufferingUpdate接口实现为进度有更新才回调（原实现为固定每秒回调）
- 播放：修复mediaplayer-extension播放出错时notifyOnError多次回调问题
- 播放：硬解码器信息全局缓存(video/hevc,video/avc,audio/mp4a-latm)，减少首次播放视频耗时
- 播放：音频数据回调增加audioFormat，描述回调的音频数据格式，不依赖于约定
- 播放：多mp4无缝拼接播放支持动态真实时长修正
- 工程：修复编译时引用avcodec.h文件的问题（两个模块都有这个文件，这个文件基本一致，保险起见还是各自引用各自的）
- 工程：增加example_proguard.cfg组件proguard规则推荐
- 工程：增加ffmpeg静态库编译说明
- 工程：支持通过setNativeLibLoader接口自定义加载so能力
- 工程：拆分出oskplayer-support，oskplayer-contrib-decprobe模块，与主功能模块解耦
- 工程：增加AbsThreadManager类，方便与外部工程对接线程管理框架
- 工具：拆分submitTask接口，支持捕捉和不捕捉异常两种场景
- Demo: 播放器对比页支持重播功能

v1.5.7
- 下载：修复RawDataSource、AssetDataSource兼容性问题
- 播放：支持H265硬解能力主动探测
- 播放：硬解探测Demo完善，支持软硬解播放能力以及完成探测流程和结果显示对比
- 播放：优化extractor顺序，减少首缓耗时(MP4,TS放在最前面)
- 播放：首帧实现音视频并行解码，减少首缓耗时
- 播放：onPrepared耗时优化，以音频数据prepared为准
- 播放：音频数据回调接口支持关闭，减少大多场景下的没必要的内存占用
- 播放：捕获MediaCodec运行时出错的异常(by zebzhang)
- 解码：支持软解、硬解视频导出JPEG图片
- 工具：支持解码帧感知哈希计算及相似度计算
- 工程：拆分出oskplayer-contrib模块，与主要功能模块解耦

v1.5.6
- 下载：支持HTTPS数据源代理
- 下载：支持IP直出后底层HTTPS证书校验异常的情况下，客户端禁用证书校验正常播放的能力
- 下载：支持通过OskPlayerConfig.setGlobalExtraHeader传入全局HTTP头/Cookie，支持每个下载线程GetUrl接口设置单独HTTP头/Cookie
- 下载：修复某些手机拍摄的视频本地路径中含有冒号导致播放失败的问题
- 缓存：修复创建缓存目录失败造成的播放失败问题
- 播放：ijkplayer升级至v0.8.5.1，exoplayer升级至v2.7.1
- 播放：支持解码后的音频PCM数据回调
- 播放：支持播放时通过getAudioLevel接口获取实时[AudioLevel](https://w3c.github.io/webrtc-stats/#aststats-dict*)
- 工程：支持Native代码调试
- 工程：支持发布到maven.oa.com仓库，支持输出maven组件到本地. gradle installArchives 或 gradle uploadArchives,详细说明请查看README
- 工程：支持缺少必要的本地配置异常告警
- 工程：引入libjpeg-9c支持YUV/RGB到jpeg转码
- 工程：gradle升级到3.x，工程编译使用api,implementation代替api提升编译速度
- 工程：NDK版本10d升级为13b
- UI：修复SafeTextureView编译告警问题
- Demo: 支持枚举硬编码器列表
- Demo: 支持播放器下载渲染性能对比功能(PlayerCompareActivity)

v1.5.5
- 下载: 支持asset和res/raw下的资源直接访问，如"/android_asset/h264probe.mp4", "android.resource://PackageName/R.raw.h265probe"等
- 下载: 支持获取实时下载速度的接口 VideoManager.getInstance().getDownloadBitrate()
- 工程: 补充README说明Maven接入方法和Proguard混淆规则

v1.5.4
- initial version
