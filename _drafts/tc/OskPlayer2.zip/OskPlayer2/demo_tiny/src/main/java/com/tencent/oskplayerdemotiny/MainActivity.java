package com.tencent.oskplayerdemotiny;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.tencent.oskplayer.OskPlayerConfig;
import com.tencent.oskplayer.OskPlayerCore;
import com.tencent.oskplayer.cache.DefaultCacheKeyGenerator;
import com.tencent.oskplayer.datasource.HttpHeader;
import com.tencent.oskplayer.util.DefaultLogger;

import java.util.logging.Logger;

/**
 * Created by leoliu on 2017/12/15.
 */

public class MainActivity extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        initOskPlayer();
        initUI();
    }

    private void initOskPlayer() {
        OskPlayerConfig cfg = new OskPlayerConfig();
        cfg.setEnableHLSCache(true);
        cfg.setDebugVersion(true);
        cfg.setLogger(new DefaultLogger());
        // 默认的缓存key生成算法
        cfg.setCacheKeyGenerator(new DefaultCacheKeyGenerator());

        HttpHeader properties = new HttpHeader();
        properties.set("Cookie", "uin=123456");

        cfg.setGlobalExtraHeader(properties);
        OskPlayerCore.init(this.getApplicationContext(), cfg);
    }

    private void initUI() {
        Button demo2 = (Button) findViewById(R.id.demo1);
        demo2.setOnClickListener(mClickListener);
//        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }

    private void demo1Func() {
        Intent intent = new Intent(MainActivity.this, PlayerActivitySurfaceView.class);
        startActivity(intent);
    }

    private View.OnClickListener mClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (view.getId() == R.id.demo1) {
                demo1Func();
            }
        }
    };
}
