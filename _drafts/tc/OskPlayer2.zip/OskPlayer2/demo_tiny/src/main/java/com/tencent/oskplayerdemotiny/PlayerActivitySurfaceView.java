package com.tencent.oskplayerdemotiny;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.oskplayer.OskPlayerCore;
import com.tencent.oskplayer.util.PlayerUtils;
import com.tencent.oskplayer.util.QLog;

public class PlayerActivitySurfaceView extends Activity implements
        SurfaceHolder.Callback,
        SeekBar.OnSeekBarChangeListener,
        MediaPlayer.OnPreparedListener,
        MediaPlayer.OnSeekCompleteListener,
        MediaPlayer.OnBufferingUpdateListener,
        CheckBox.OnCheckedChangeListener,
        View.OnClickListener {

    public static final String TAG = "PlayerActivity";

    private SeekBar mSeekBar;
    private SurfaceHolder mSurfaceHolder;
    private MediaPlayer mMediaPlayer;
    private ImageButton mPlayPauseButton;
    private boolean mJustCreatePlayer;
    private TextView mDebugTextView;
    private TextView mVideoDurationView;
    private boolean mIsLoopingPlay;
    private Handler mMainHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.single_surfaceview);
        SurfaceView surfaceView = (SurfaceView) findViewById(R.id.main_surface);
        CheckBox loopCheckBox = (CheckBox)findViewById(R.id.loopcheckbox);
        mSurfaceHolder = surfaceView.getHolder();
        mSurfaceHolder.addCallback(this);
        mSeekBar = (SeekBar) findViewById(R.id.seekbar);
        mSeekBar.setOnSeekBarChangeListener(this);
        mPlayPauseButton = (ImageButton) findViewById(R.id.playpausebtn);
        mPlayPauseButton.setOnClickListener(this);
        mPlayPauseButton.setEnabled(false);
        mDebugTextView = (TextView) findViewById(R.id.debugtextview);
        mVideoDurationView = (TextView) findViewById(R.id.videoDuration);
        mIsLoopingPlay = loopCheckBox.isChecked();
        mMainHandler = new Handler(Looper.getMainLooper());
        loopCheckBox.setOnCheckedChangeListener(this);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Log.e(TAG, "surfaceCreated");
        mPlayPauseButton.setEnabled(true);
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        Log.d(TAG, "surfaceChanged[" + width + "," + height + "]");
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.d(TAG, "surfaceDestroyed");
        destroyPlayer();    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        Log.d(TAG, "onPrepared");
        mMediaPlayer.start();
        mSeekBar.setMax((int) mMediaPlayer.getDuration());
        updateDuration();
        refreshProgressbarLoop();
        updatePlayStatus();
    }

    @Override
    public void onBufferingUpdate(MediaPlayer mp, int percent) {
        Log.d(TAG, "onBufferingUpdate " + percent);
    }

    @Override
    public void onSeekComplete(MediaPlayer mp) {
        Log.d(TAG, "onSeekComplete");
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        if (fromUser) {
            mDebugTextView.setText(String.valueOf(progress));
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
        mDebugTextView.setVisibility(View.VISIBLE);
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        int progress=seekBar.getProgress();
        Log.d(TAG, "seekTo " + progress);
        mMediaPlayer.seekTo(progress);
        mDebugTextView.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.playpausebtn) {
            if (mMediaPlayer == null) {
                initPlayer();
            }
            if (mJustCreatePlayer) {
                //String url = "https://base-n.de/webm/out9.webm";
                String url = "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4";
                String httpsUrl = "https://dlied5.qq.com/ABCmouse/aol/content/MusicVideo/13333/movie.mp4";

                String proxyUrl = OskPlayerCore.getInstance().getUrl(httpsUrl);

                Log.d(TAG, "proxyUrl=" + proxyUrl);

                try {
                    mMediaPlayer.setDataSource(proxyUrl);
                    mMediaPlayer.prepareAsync();
                    mJustCreatePlayer = false;
                } catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), ex.toString(), Toast.LENGTH_SHORT).show();
                }
            } else {
                if (mMediaPlayer.isPlaying()) {
                    mMediaPlayer.pause();
                } else {
                    mMediaPlayer.start();
                }
            }
            updatePlayStatus();
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        Log.d(TAG, "LoopingCheckBox isChecked " + isChecked);
        mIsLoopingPlay = isChecked;
        if(mMediaPlayer == null) {
            return;
        }
        Log.d(TAG, "setLooping " + isChecked);
        mMediaPlayer.setLooping(isChecked);
    }

    private void initPlayer() {
        mMediaPlayer = new MediaPlayer();
        mMediaPlayer.setDisplay(mSurfaceHolder);
        mMediaPlayer.setOnPreparedListener(this);
        mMediaPlayer.setOnBufferingUpdateListener(this);
        mMediaPlayer.setOnSeekCompleteListener(this);
        mMediaPlayer.setLooping(mIsLoopingPlay);
        mJustCreatePlayer = true;
    }

    private void destroyPlayer() {
        if (mMediaPlayer != null) {
            mMediaPlayer.release();
            mJustCreatePlayer = false;
            mMediaPlayer = null;
        }
        updatePlayStatus();
    }

    private void updateDuration() {
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                mVideoDurationView.setText(String.valueOf(mMediaPlayer.getDuration()));
            }
        });
    }

    private void updatePlayStatus() {
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mMediaPlayer != null && mMediaPlayer.isPlaying()) {
                    mPlayPauseButton.setImageResource(android.R.drawable.ic_media_pause);
                } else {
                    mPlayPauseButton.setImageResource(android.R.drawable.ic_media_play);
                }
            }
        });
    }

    private void refreshProgressbarLoop() {
        if (mMediaPlayer != null) {
            mSeekBar.setProgress((int) mMediaPlayer.getCurrentPosition());
            mMainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    refreshProgressbarLoop();
                }
            }, 1000);
        }
    }
}