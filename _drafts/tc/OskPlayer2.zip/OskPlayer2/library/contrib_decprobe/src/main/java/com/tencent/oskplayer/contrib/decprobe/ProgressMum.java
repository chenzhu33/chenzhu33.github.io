package com.tencent.oskplayer.contrib.decprobe;

import android.util.Pair;

import com.tencent.oskplayer.support.log.Logger;

import java.util.ArrayList;

public class ProgressMum {
    public static final String LOG_TAG = "ProgressMum";
    private final static float STEP_MAX = 100.0f; // internal MAX
    float currentStep = 0.0f;

    int mMaxStep = 100;
    String name = "";

    ArrayList<Pair<ProgressMum,Float>> subProgreses = new ArrayList<Pair<ProgressMum, Float>>();

    public void addProgress(ProgressMum subProgress, float weight) {
        subProgreses.add(new Pair<ProgressMum, Float>(subProgress, weight));
    }

    public void setMaxStep(int maxStep) {
        mMaxStep = maxStep;
    }

    public void updateStep(int step) {
        if (subProgreses.size() == 0) { // 非group progress类型的 updateStep才有意义
            currentStep = ((float) step / mMaxStep) * STEP_MAX;
        }
    }

    public int getMaxStep() {
        return mMaxStep;
    }

    // use only you know what you are doing
    @Deprecated
    public void markFinishForce() {
        updateStep(getMaxStep());
    }

    public float getProgress() {
        if (subProgreses.size() > 0) {
            float pall = 0.0f;
            for (Pair<ProgressMum, Float> p : subProgreses) {
                pall += p.first.getProgress() * STEP_MAX * p.second;
            }
            currentStep = pall;
        }
        return currentStep / STEP_MAX;
    }

    public static void test() {
        ProgressMum p1 = new ProgressMum(); // non group
        ProgressMum p2 = new ProgressMum(); // non group
        ProgressMum p3 = new ProgressMum(); // non group
        ProgressMum all = new ProgressMum(); // group

        all.addProgress(p1, 0.1f);
        all.addProgress(p2, 0.2f);
        all.addProgress(p3, 0.7f);

        p1.setMaxStep(1000);
        p1.updateStep(100);
        p2.updateStep(0);
        p3.updateStep(0);

        Logger.g().i(LOG_TAG, all.getProgress() + ""); // should 50
    }

    public static void nestingTest() {
        ProgressMum p1 = new ProgressMum(); // non group
        ProgressMum p2 = new ProgressMum(); // non group
        ProgressMum p3 = new ProgressMum();

        ProgressMum g1 = new ProgressMum();
        g1.addProgress(p1, 0.5f);
        g1.addProgress(p2, 0.5f);

        ProgressMum g = new ProgressMum();
        g.addProgress(g1, 0.2f);
        g.addProgress(p3, 0.8f);

        p1.updateStep(50);
        p2.updateStep(50);

        Logger.g().i(LOG_TAG, g.getProgress() + ""); // should 0.1
    }
}
