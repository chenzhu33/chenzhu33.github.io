package com.tencent.oskplayer.contrib.decprobe;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.os.Build;
import android.os.SystemClock;
import android.support.annotation.IntDef;
import android.support.annotation.StringDef;
import android.text.TextUtils;
import android.util.Pair;

import com.tencent.oskplayer.contrib.ImageHash;
import com.tencent.oskplayer.contrib.ImageHashError;
import com.tencent.oskplayer.miscellaneous.DecodeProbe;
import com.tencent.oskplayer.miscellaneous.HardwareDecodeProbe;
import com.tencent.oskplayer.miscellaneous.SoftwareDecodeProbe;
import com.tencent.oskplayer.support.OskSupport;
import com.tencent.oskplayer.support.io.AbsDownloader;
import com.tencent.oskplayer.support.io.AbsDownloaderFactory;
import com.tencent.oskplayer.support.log.Logger;
import com.tencent.oskplayer.support.thread.AbsThreadManager;
import com.tencent.oskplayer.support.util.OskBitmap;
import com.tencent.oskplayer.support.util.OskCollection;
import com.tencent.oskplayer.support.util.OskDebug;
import com.tencent.oskplayer.support.util.OskFile;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.BitSet;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class DecoderProbe {
    public static final String LOG_TAG = "DecoderProbe";

    private String mResDir = null;

    private static DecoderProbe sInstance;

    private volatile boolean mIsDownloading = false;

    private volatile boolean mIsProbing = false;

    private static final int[] sFrameSeq = {1,8,64};

    private SharedPreferences mPreferences;

    public static final int SP_VERSION = 1;
    private static final String SP_NAME = "decoderprobe";

    public static final String VIDEO_PROFILE_UNKNOWN = "profile_unknown";
    public static final String VIDEO_PROFILE_HVC_720P = "hvc720P";
    public static final String VIDEO_PROFILE_HVC_540P = "hvc540P";
    public static final String VIDEO_PROFILE_HVC_1080P = "hvc1080P";

    public static final int RESULT_UNKNOWN = -1; // 标记为还未检测，不能为硬解检测本身的错误码

    public static final int RESULT_PROBE_NOT_SUPPORT = -2 ; // 不支持硬解探测, 如:SDK版本限制
    public static final int RESULT_BLACKLIST = -3; // 硬解有已知有非必现问题的机型，这类问题探测不一定能发现
    public static final int RESULT_ERR_LIBRARY = -4; // 库加载失败

    public static final int RESULT_YES = 1; // 支持硬解
    public static final int RESULT_NO = 2;  // 不支持硬解

    private Map<String, ProbeResultCache> mProbeResultCache;
    private Map<String, String> mVideoProfileResource = new HashMap<>();

    @IntDef({RESULT_UNKNOWN, RESULT_PROBE_NOT_SUPPORT, RESULT_BLACKLIST, RESULT_ERR_LIBRARY, RESULT_YES, RESULT_NO})
    @Retention(RetentionPolicy.SOURCE)
    public @interface HwDecodeStatus {}

    @StringDef({VIDEO_PROFILE_UNKNOWN,VIDEO_PROFILE_HVC_1080P,VIDEO_PROFILE_HVC_720P,VIDEO_PROFILE_HVC_540P})
    @Retention(RetentionPolicy.SOURCE)
    public @interface HwDecodeVideoProfile {}

    private String blacklistModels;
    private boolean isResourceAvailable;
    private boolean isSupport;
    private AbsDownloaderFactory downloaderFactory;
    private AbsThreadManager threadManager;

    public String[] supportedProfiles = {
            DecoderProbe.VIDEO_PROFILE_HVC_540P,
            DecoderProbe.VIDEO_PROFILE_HVC_720P,
            DecoderProbe.VIDEO_PROFILE_HVC_1080P
    };

    BitSet printFlags = new BitSet(16);

    public static DecoderProbe getInstance() {
        if (sInstance == null) {
            synchronized (DecoderProbe.class) {
                if (sInstance == null) {
                    sInstance = new DecoderProbe();
                }
            }
        }
        return sInstance;
    }

    private DecoderProbe() {
        mResDir = OskFile.ensureFilesDir("decoder_probe_res");
        mPreferences  = OskSupport.getContext().getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
        mProbeResultCache = new ConcurrentHashMap<String, ProbeResultCache>();
        StringBuilder sb = new StringBuilder("readSp ");
        for (String profile : supportedProfiles) {
            ProbeResultCache cache = new ProbeResultCache();
            cache.cachedResult = readSp(profile, RESULT_UNKNOWN);
            mProbeResultCache.put(getSpKey(profile), cache);
            sb.append(profile).append(":").append(cache.cachedResult).append(",");
        }
        Logger.g().i(LOG_TAG, sb.toString());
    }

    private synchronized boolean isDownloading() {
        return mIsDownloading;
    }

    private synchronized void setDownloading(boolean downloading) {
        mIsDownloading = downloading;
    }

    private synchronized boolean isProbing() {
        return mIsProbing;
    }

    private synchronized void setProbing(boolean probing) {
        mIsProbing = probing;
    }

    private Pair<String,Integer> parseConfig(String item) {
        Pair<String, Integer> pair = null;
        if (!TextUtils.isEmpty(item)) {
            String[] parts = item.split("\\|");
            try {
                if (parts.length >= 2) {
                    String url = parts[0];
                    Integer length = Integer.parseInt(parts[1]);
                    pair = new Pair<String,Integer>(url, length);
                }
            } catch (Exception ex) {
                Logger.g().e(LOG_TAG, "unable parseConfig " + item, ex);
            }
        }
        return pair;
    }

    private String getSpKey(@HwDecodeVideoProfile String profile) {
        return profile + SP_VERSION;
    }
    /**
     * 不要直接设置值!!! 除非你确定这样做没问题
     * 请使用canHwDecodeVideoProfile接口自动探测设置
     * @param profile
     * @param statusCode
     */
    @Deprecated
    public void saveResult(@HwDecodeVideoProfile String profile, int statusCode) {
        if (mPreferences != null) {
            mPreferences.edit().putInt(getSpKey(profile), statusCode).apply();
        } else {
            Logger.g().i(LOG_TAG, "no preference");
        }

        ProbeResultCache newState = new ProbeResultCache();
        newState.cachedResult = statusCode;
        mProbeResultCache.put(getSpKey(profile), newState);
    }

    private int readSp(@HwDecodeVideoProfile String profile, int defaultVal) {
        if (mPreferences != null) {
            return mPreferences.getInt(getSpKey(profile), defaultVal);
        } else {
            Logger.g().i(LOG_TAG, "no preference");
        }
        return RESULT_UNKNOWN;
    }

    public void setBlackListModel(String blacklistmodel) {
        this.blacklistModels = blacklistmodel;
    }

    public void setIsResourceAvailable(boolean isResourceAvailable) {
        this.isResourceAvailable = isResourceAvailable;
    }

    public void setIsSupport(boolean isSupport) {
        this.isSupport = isSupport;
    }

    public void setDownloader(AbsDownloaderFactory downloaderFactory) {
        this.downloaderFactory = downloaderFactory;
    }

    public void setThreadManager(AbsThreadManager threadManager) {
        this.threadManager = threadManager;
    }

    public void addDecResource(@HwDecodeVideoProfile String videoProfile, String resourceUri) {
        mVideoProfileResource.put(videoProfile, resourceUri);
    }

    private String downloadVideoResource(@HwDecodeVideoProfile String videoProfile) {
        // F31格式视频
        final String configStr;
        final String localFileName;
        configStr = mVideoProfileResource.get(videoProfile);
        if (!TextUtils.isEmpty(configStr)) {
            localFileName = videoProfile + ".mp4";
        } else {
            localFileName = null;
        }

        if (TextUtils.isEmpty(configStr) || TextUtils.isEmpty(localFileName)) {
            Logger.g().w( LOG_TAG, "empty configStr for key " + videoProfile);
            return null;
        }


        // 下载视频资源
        Pair<String, Integer> configPair = parseConfig(configStr);
        if (configPair == null) {
            Logger.g().w( LOG_TAG, "invalid config " + configStr);
            return null;
        }

        String downloadUrl = configPair.first;
        final Integer expectedLength = configPair.second;

        final File dstFile = new File(mResDir + File.separator + localFileName);

        if (dstFile.exists() && dstFile.isFile() && dstFile.length() == expectedLength) {
            Logger.g().i(LOG_TAG, "found a valid file for " + videoProfile);
            return dstFile.getAbsolutePath();
        }

        // 可多次调用本函数，有资源下载任务的话不处理，一次只下载一个资源
        if (isDownloading()) {
            Logger.g().w( LOG_TAG, "something is downloading, try again");
            return null;
        }

        AbsDownloader downloader = downloaderFactory.create(downloadUrl, null);
        downloader.setDownloadListener(new AbsDownloader.DownloadListener() {
            @Override
            public void onDownloadCanceled(String url) {
                setDownloading(false);
                Logger.g().w( LOG_TAG, "download canceled " + url);
            }

            @Override
            public void onDownloadFailed(String url) {
                setDownloading(false);
                Logger.g().w( LOG_TAG, "download failed " + url);
            }

            @Override
            public void onDownloadSucceed(String url, String localPath) {
                File f = new File(localPath);
                if (f.exists() && f.isFile() && f.length() == expectedLength) {
                    if(dstFile.exists()) {
                        dstFile.delete();
                    }
                    boolean succ = f.renameTo(dstFile);
                    if (succ) {
                        Logger.g().i(LOG_TAG, "download success " + url);
                    } else {
                        try {
                            OskFile.copy(f, dstFile);
                        } catch (Exception e) {
                            Logger.g().i(LOG_TAG, "failed copy file from " + f);
                        }
                        if (dstFile.exists() && dstFile.isFile() && dstFile.length() == expectedLength) {
                            Logger.g().i(LOG_TAG, "download copy success " + url);
                        }
                    }
                } else {
                    Logger.g().e(LOG_TAG, "download file error, length not match " + f.length()
                            + " vs " + expectedLength);
                    f.delete();
                }
                setDownloading(false);
            }

            @Override
            public void onDownloadProgress(String url, float progress) {
                setDownloading(true);
            }
        });
        setDownloading(true);
        downloader.download();
        return null;
    }

    /**
     * 查询硬解状态
     * @param videoProfile 视频probe,目前为固定的几个典型分辨率,必须是 @HwDecodeVideoProfile 中的一种才支持
     * @return @HwDecodeState 中的一种
     */
    public @HwDecodeStatus int canHwDecByProfile(@HwDecodeVideoProfile String videoProfile) {
        if (TextUtils.isEmpty(videoProfile)) {
            Logger.g().w( LOG_TAG, "canHwDecByProfile empty video profile");
            return RESULT_UNKNOWN;
        }

        ProbeResultCache resultCache = mProbeResultCache.get(getSpKey(videoProfile));

        if (resultCache == null) {
            Logger.g().i(LOG_TAG, "canHwDecByProfile unsupported profile " + videoProfile);
            return RESULT_UNKNOWN;
        }

        int statusCode = (Integer) resultCache.cachedResult;

        if (statusCode != RESULT_UNKNOWN) { // probe已完成
            int idx = OskCollection.index(supportedProfiles, videoProfile);
            if (!printFlags.get(idx)) { // 只打印一次
                if (printFileContentToLog(getProbeResultFile(videoProfile))) {
                    printFlags.set(idx);
                }
            }
            Logger.g().d(LOG_TAG, "canHwDecByProfile " + videoProfile + ":" + statusCode);
            if (statusCode == ImageHashError.NOERR) {
                return RESULT_YES;
            } else if (statusCode == RESULT_BLACKLIST
                    || statusCode == RESULT_PROBE_NOT_SUPPORT
                    || statusCode == RESULT_ERR_LIBRARY) {
                return statusCode;
            }
            return RESULT_NO; // blacklist or other problem
        }

        return RESULT_UNKNOWN;
    }

    /**
     * 尝试执行probe流程,同一时间执行执行这个
     * @param videoProfile 视频probe,目前为固定的几个典型分辨率
     * @param callback 回调,可以为null
     */
    public synchronized void runProbe(@HwDecodeVideoProfile String videoProfile,
                                                            ProbeResultCallback callback) {
        // 入参检查
        if (TextUtils.isEmpty(videoProfile)) {
            Logger.g().w( LOG_TAG, "runProbe empty video profile");
            return;
        }

        if (!ImageHash.isNativeLibReady(OskSupport.getLibLoader())){
            Logger.g().w( LOG_TAG, "runProbe wait probe library ready");
            return;
        }

        ProbeResultCache resultCache = mProbeResultCache.get(getSpKey(videoProfile));

        if (resultCache == null) {
            Logger.g().i(LOG_TAG, "runProbe unknown profile " + videoProfile);
            return;
        }

        @HwDecodeStatus int status = canHwDecByProfile(videoProfile);

        ProbeResult probeResult = new ProbeResult();
        probeResult.videoProfile =  videoProfile;
        if (status == RESULT_UNKNOWN) { // Unknown的状态尝试运行探测流程
            if (!TextUtils.isEmpty(blacklistModels) &&
                    blacklistModels.toLowerCase().contains(Build.MODEL.toLowerCase())) { // 已知探测结果不准确的机型,偶现绿屏异常
                saveResult(videoProfile, RESULT_BLACKLIST);
                probeResult.statusCode = RESULT_BLACKLIST;
                callback.onProbeResult(probeResult);
            } else if (!isProbing()){ // 可以执行探测
                Logger.g().i(LOG_TAG, "canUseHardDecodeForVideoProfile isSupport=" + isSupport
                        + ",ResourceAvailable=" + isResourceAvailable);
                if (isSupport) {
                    if (!isResourceAvailable) {
                        ImageHash.loadLibrariesOnce(OskSupport.getLibLoader());
                        if (ImageHash.sIsLibLoadSuccess) { // 库加载失败
                            probe(videoProfile, callback);
                        } else {
                            saveResult(videoProfile, RESULT_ERR_LIBRARY);
                            probeResult.statusCode = RESULT_ERR_LIBRARY;
                            callback.onProbeResult(probeResult);
                        }
                    } else {
                        Logger.g().i(LOG_TAG, "abort, sysbusy");
                    }
                } else {
                    saveResult(videoProfile, RESULT_PROBE_NOT_SUPPORT);
                    probeResult.statusCode = RESULT_PROBE_NOT_SUPPORT;
                    callback.onProbeResult(probeResult);
                }
            }
        }
    }

    private void probe(@HwDecodeVideoProfile final String videoProfile, final ProbeResultCallback callback) {
        String localFile = downloadVideoResource(videoProfile);
        if (TextUtils.isEmpty(localFile)) {
            Logger.g().i( LOG_TAG, "probe " + videoProfile + ", local file missing, try later");
            return;
        }
        setProbing(true);
        probeUrl(localFile, videoProfile, new ProbeResultCallback() {
            @Override
            public void onProbeResult(ProbeResult result) {
                Logger.g().i( LOG_TAG, "probe " + videoProfile + ", resultCode=" + result.statusCode);
                saveResult(videoProfile, result.statusCode);
                if (callback != null) {
                    callback.onProbeResult(result);
                }
                setProbing(false);
            }
        });
    }

    private void probeUrl(final String url, final String profile, final ProbeResultCallback callback) {
//        mViews.misc_desc_l2.setText("Result:");
        final long probe_start_time = SystemClock.uptimeMillis();
        final Integer[] frameSeqFlat = wrapIntArray(sFrameSeq);

        DecodeProbe.getInstance().addSaveFrame(sFrameSeq);
        DecodeProbe.getInstance().cleanPicOutDir();

        final ProgressMum hwProgressMum = new ProgressMum(); // non-group record hwProgress on probe
        hwProgressMum.setMaxStep(frameSeqFlat[frameSeqFlat.length - 1]);

        final ProgressMum swProgressMum = new ProgressMum(); // non-group record swProgress on probe
        swProgressMum.setMaxStep(frameSeqFlat[frameSeqFlat.length - 1]);

        final ProgressMum hashProgressMum = new ProgressMum(); // non-group record hashProgress
        hashProgressMum.setMaxStep(frameSeqFlat.length);

        ProgressMum decProgressMum = new ProgressMum(); // group overall decode progress
        decProgressMum.addProgress(hwProgressMum, 0.5f);
        decProgressMum.addProgress(swProgressMum, 0.5f);

        final ProgressMum allProgress = new ProgressMum(); // group overall progress
        allProgress.addProgress(decProgressMum, 0.5f);
        allProgress.addProgress(hashProgressMum, 0.5f);

        final ProbeResultHolder hwProbeResultHolder = new ProbeResultHolder();
        final ProbeResultHolder swProbeResultHolder = new ProbeResultHolder();

        final File probeResultFile = getProbeResultFile(profile);
//        mViews.probe_progress.setProgress(Math.round(allProgress.getProgress() * mViews.probe_progress.getMax()));

        threadManager.postJobOnIOThread(new Runnable() {
            @Override
            public void run() {
                boolean decodeSuccess = false;
                boolean hashSuccess = false;
                try {
                    DecodeProbe.getInstance().setHwProbeCallback(new HardwareDecodeProbe.HwProbeCallback() {
                        @Override
                        public void onHwProbeOneFrame(int frameNo) {
                            ProbeResultHolder holder = new ProbeResultHolder();
                            hwProgressMum.updateStep(frameNo);
                            holder.source = ProbeResultHolder.SOURCE_HW;
                            holder.type = ProbeResultHolder.TYPE_PROBE_PROGRESS;
                            holder.value = frameNo;
                            Logger.g().i(LOG_TAG, "ProbeDecEvent type:" + holder.type
                                    + ",source:" + holder.source + ",value=" + holder.value);
                        }
                    });
                    long hwDecodeStart = SystemClock.uptimeMillis();
                    int hwResult = DecodeProbe.getInstance().hwProbe(url);
                    hwProbeResultHolder.source = ProbeResultHolder.SOURCE_HW;
                    hwProbeResultHolder.type = ProbeResultHolder.TYPE_PROBE_RESULT;
                    hwProbeResultHolder.value = hwResult;
                    hwProbeResultHolder.timeCost = SystemClock.uptimeMillis() - hwDecodeStart;
                    hwProbeResultHolder.avgDecFrameCost = DecodeProbe.getInstance().getHwDecodeAvgCost();
                    hwProgressMum.markFinishForce();
                    Logger.g().i(LOG_TAG, "ProbeDecEvent type:" + hwProbeResultHolder.type
                            + ",source:" + hwProbeResultHolder.source + ",value=" + hwProbeResultHolder.value);
                    if (hwResult != 0) {
                        throw new ImageHashError(hwResult, "hwProbe Error " + hwResult);
                    }
                    DecodeProbe.getInstance().setSwProbeCallback(new SoftwareDecodeProbe.SwProbeCallback() {
                        @Override
                        public void onSwProbeOneFrame(int frameNo) {
                            ProbeResultHolder holder = new ProbeResultHolder();
                            swProgressMum.updateStep(frameNo);
                            holder.source = ProbeResultHolder.SOURCE_SW;
                            holder.type = ProbeResultHolder.TYPE_PROBE_PROGRESS;
                            holder.value = frameNo;
                            Logger.g().i(LOG_TAG, "ProbeDecEvent type:" + holder.type
                                    + ",source:" + holder.source + ",value=" + holder.value);
                        }
                    });
                    long swDecodeStart = SystemClock.uptimeMillis();
                    int swResult = DecodeProbe.getInstance().swProbe(url);
                    swProbeResultHolder.source = ProbeResultHolder.SOURCE_SW;
                    swProbeResultHolder.type = ProbeResultHolder.TYPE_PROBE_RESULT;
                    swProbeResultHolder.value = swResult;
                    swProbeResultHolder.timeCost = SystemClock.uptimeMillis() - swDecodeStart;
                    swProbeResultHolder.avgDecFrameCost = DecodeProbe.getInstance().getSwDecodeAvgCost();
                    swProgressMum.markFinishForce();
                    Logger.g().i(LOG_TAG, "ProbeDecEvent type:" + swProbeResultHolder.type
                            + ",source:" + swProbeResultHolder.source + ",value=" + swProbeResultHolder.value);
                    if (swResult != 0) {
                        throw new ImageHashError(swResult, "swProbe Error " + swResult);
                    }
                    decodeSuccess = true;
                } catch (Throwable e) {
                    Logger.g().e(LOG_TAG,"解码流程失败 " + e);
                    long timeCostTotal = SystemClock.uptimeMillis() - probe_start_time;
                    hashProgressMum.markFinishForce();
                    swProgressMum.markFinishForce();
                    hwProgressMum.markFinishForce();
                    ProbeResult result = new ProbeResult();
                    result.videoProfile = profile;
                    result.statusCode = getErrorCode(e);
                    result.timeCostHwDecode = hwProbeResultHolder.timeCost;
                    result.timeCostSwDecode = swProbeResultHolder.timeCost;
                    result.timeCostTotal = timeCostTotal;
                    result.progress = allProgress.getProgress();

                    String probeResultLog =  "error decoding "
                            + ",hwDecodeTimeCost=" + hwProbeResultHolder.timeCost
                            + ",swDecodeTimeCost=" + swProbeResultHolder.timeCost
                            + OskDebug.getPrintableStackTrace(e);

                    writeStringAsFile(probeResultLog, probeResultFile);
                    callback.onProbeResult(result);
                } finally {
                    // clean memory
                    DecodeProbe.getInstance().setHwProbeCallback(null);
                    DecodeProbe.getInstance().setSwProbeCallback(null);
                }

                // 判断硬解是否成功
                final int UNKNOWN = -1;

                long maxDistance = UNKNOWN;
                int averageDistance = UNKNOWN;
                int totalDistance = UNKNOWN;
                int count = 0;

                if (decodeSuccess) {
                    try {
                        File picOutDir = DecodeProbe.getInstance().getPicOutDir();
                        for (int frameSeq : sFrameSeq) {
                            final File hwPic = new File(picOutDir, String.format(Locale.getDefault(), "hw-%d.jpg", frameSeq));
                            final File swPic = new File(picOutDir, String.format(Locale.getDefault(), "sw-%d.jpg", frameSeq));
                            BitmapHolder bhHw = new BitmapHolder();
//                                                bhHw.iv = mViews.disp_a;
//                                                bhHw.tv = mViews.desc_a;
                            bhHw.path = hwPic.getAbsolutePath();
                            bhHw.bitmap = null;
                            BitmapHolder bhSw = new BitmapHolder();
//                                                bhSw.iv = mViews.disp_b;
//                                                bhSw.tv = mViews.desc_b;
                            bhSw.path = swPic.getAbsolutePath();
                            bhSw.bitmap = null;
                            BitmapHolder[] bhs = new BitmapHolder[2];
                            bhs[0] = bhHw;
                            bhs[1] = bhSw;

                            //
                            for (BitmapHolder holder : bhs) {
                                if (holder != null && !TextUtils.isEmpty(holder.path)) {
                                    File file = new File(holder.path);
                                    if (file.isFile() && file.exists()) {
                                        holder.opts = getBitmapBounds(holder.path);
                                        holder.bitmap = getBitmap(holder.path, holder.opts);
                                    }
                                }
                            }

                            //
                            for (BitmapHolder holder : bhs) {
                                if (holder.bitmap != null) {
                                    holder.phash = ImageHash.getPHash(holder.bitmap);
                                }
                            }

                            //
                            for (BitmapHolder holder : bhs) {
                                if (holder.opts != null) {
                                    int sampleSize = OskBitmap.calculateInSampleSizeLow(holder.opts);
                                    String text = "原始图片:" + holder.opts.outWidth + "*" + holder.opts.outHeight + "\n"
                                            + "sampleSize:" + sampleSize + "\n"
                                            + "hash:" + Long.toHexString(holder.phash) + "\n";
//                                                holder.tv.setText(text);
                                } else {
                                    String text = "";
//                                                holder.tv.setText(text);
                                }
                                if (holder.bitmap != null) {
//                                                holder.iv.setImageBitmap(holder.bitmap);
                                }
                            }
                            StringBuilder result = new StringBuilder("Hamming Distance:");
                            for (int i = 0; i < bhs.length && (i + 1 < bhs.length); i += 2) {
                                BitmapHolder a = bhs[i];
                                BitmapHolder b = bhs[i + 1];
                                if (a.phash != ImageHash.HASH_ERROR && b.phash != ImageHash.HASH_ERROR) {
                                    long distance = ImageHash.getHammingDistance(a.phash, b.phash);
                                    result.append(distance);
                                    if (distance > maxDistance) {
                                        maxDistance = distance;
                                    }
                                    if (totalDistance == UNKNOWN) {
                                        totalDistance = 0;
                                    }
                                    totalDistance += distance;
                                    count++;
                                    hashProgressMum.updateStep(count);
                                } else {
                                    result.append("unknown");
                                    Logger.g().w(LOG_TAG, "hash_error occurred");
                                }
                            }
                            Logger.g().i(LOG_TAG, result.toString());
                            hashSuccess = true;
                        }
                    } catch (Exception e) {
                        Logger.g().e(LOG_TAG,"哈希计算流程失败",e);
                        long timeCostTotal = SystemClock.uptimeMillis() - probe_start_time;
                        hashProgressMum.markFinishForce();
                        ProbeResult result = new ProbeResult();
                        result.videoProfile = profile;
                        result.statusCode = getErrorCode(e);
                        result.timeCostHwDecode = hwProbeResultHolder.timeCost;
                        result.timeCostSwDecode = swProbeResultHolder.timeCost;
                        result.timeCostTotal = timeCostTotal;
                        result.progress = allProgress.getProgress();

                        String probeResultLog =  "error hashing maxDistance=" + maxDistance
                                + ",averageDistance=" + averageDistance
                                + ",totalDistance=" + totalDistance
                                + ",hwDecodeTimeCost=" + hwProbeResultHolder.timeCost
                                + ",swDecodeTimeCost=" + swProbeResultHolder.timeCost
                                + ",totalTimeCost=" + (SystemClock.uptimeMillis() - probe_start_time)
                                + ",frameCount=" + count
                                + OskDebug.getPrintableStackTrace(e);

                        writeStringAsFile(probeResultLog, probeResultFile);
                        callback.onProbeResult(result);
                    }
                }// end if

                if (hashSuccess) {
                    long timeCostTotal = SystemClock.uptimeMillis() - probe_start_time;
                    int code = ImageHashError.NOERR;
                    long hwDecFrameFps = 0;
                    long swDecFrameFps = 0;
                    if (count > 0) {
                        averageDistance = totalDistance / count;
                        if (maxDistance != UNKNOWN
                                && maxDistance <= 4
                                && averageDistance <= 2) {

//                                          hwDecFrameFps = 1000L / (hwProbeResultHolder.timeCost / frameSeqFlat[frameSeqFlat.length - 1]);
                            if (hwProbeResultHolder.avgDecFrameCost == 0) {
                                // 硬解太快的话，耗时非常低有可能为0，造成误判
                                hwProbeResultHolder.avgDecFrameCost = 1;
                            }
                            if (hwProbeResultHolder.avgDecFrameCost > 0) {
                                hwDecFrameFps = 1000L / hwProbeResultHolder.avgDecFrameCost;
                            }
//                                                if (hwDecFrameFps < 30) {
//                                                    code = ImageHashError.ERROR_LOW_FPS;
//                                                }
                            if (hwProbeResultHolder.avgDecFrameCost > 33) { // 硬解速度至少30帧每秒，才满足要求
                                code = ImageHashError.ERROR_LOW_FPS;
                            }
                        } else {
                            code = ImageHashError.ERROR_LARGE_DISTANCE;
                        }
                    } else {
                        code = ImageHashError.ERROR_DECODE_FLOW;
                    }

                    if (swProbeResultHolder.avgDecFrameCost > 0) {
                        swDecFrameFps = 1000L / swProbeResultHolder.avgDecFrameCost;
                    }
                    ProbeResult probeResult = new ProbeResult();
                    probeResult.videoProfile = profile;
                    probeResult.statusCode = code;
                    probeResult.timeCostHwDecode = hwProbeResultHolder.timeCost;
                    probeResult.fpsHwDec = hwDecFrameFps;
                    probeResult.avgHwDecFrameCost = hwProbeResultHolder.avgDecFrameCost;
                    probeResult.timeCostSwDecode = swProbeResultHolder.timeCost;
                    probeResult.fpsSwDec = swDecFrameFps;
                    probeResult.avgSwDecFrameCost = swProbeResultHolder.avgDecFrameCost;
                    probeResult.timeCostTotal = timeCostTotal;
                    probeResult.progress = allProgress.getProgress();

                    String probeResultLog =  "onCompleted videoProfile=" + profile
                            + ",maxDistance=" + maxDistance
                            + ",averageDistance=" + averageDistance
                            + ",totalDistance=" + totalDistance
                            + ",hwDecodeTimeCost=" + hwProbeResultHolder.timeCost
                            + ",swDecodeTimeCost=" + swProbeResultHolder.timeCost
                            + ",totalTimeCost=" + (SystemClock.uptimeMillis() - probe_start_time)
                            + ",hwDecFrameFPS=" + hwDecFrameFps
                            + ",hwDecFrameCostAvg=" + probeResult.avgHwDecFrameCost
                            + ",swDecFrameFPS=" + swDecFrameFps
                            + ",swDecFrameCostAvg=" + probeResult.avgSwDecFrameCost
                            + ",resultCode=" + code
                            + ",frameCount=" + count;

                    Logger.g().i( LOG_TAG, probeResultLog);
                    writeStringAsFile(probeResultLog, probeResultFile);
                    callback.onProbeResult(probeResult);
                }
            }
        });
    }

    private Integer[] wrapIntArray(int[] ints) {
        Integer[] integers = new Integer[ints.length];
        int i=0;
        for (int v : ints) {
            integers[i++] = v;
        }
        return integers;
    }

//    private static String removeLastChar(String s) {
//        if (s == null || s.length() == 0) {
//            return s;
//        }
//        return s.substring(0, s.length()-1);
//    }

    private BitmapFactory.Options getBitmapBounds(String path) {
        BitmapFactory.Options option = new BitmapFactory.Options();
        option.inJustDecodeBounds = true;
        Rect paddingRect = new Rect();
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(path);
        } catch (IOException ioe) {
            ioe.printStackTrace();
            return null;
        }
        try {
            BitmapFactory.decodeStream(new BufferedInputStream(fis, 8192), paddingRect, option);
        } catch (OutOfMemoryError err) {
            Logger.g().e(LOG_TAG, "内存占用过大，图片解码失", err);
        } catch (Throwable e) {
            Logger.g().e(LOG_TAG, "decode bitmap failed", e);
        }
        return option;
    }

    private Bitmap getBitmap(String path, BitmapFactory.Options options) {
        BitmapFactory.Options a = new BitmapFactory.Options();
//        a.outWidth = 800;
//        a.outHeight = 800;
//        Log.v("michalliu", "a" + calculateInSampleSize2(a, 400, 400));
        FileInputStream fis = null;
        int sampleSize = OskBitmap.calculateInSampleSizeLow(options);
        BitmapFactory.Options opt = new BitmapFactory.Options();
        opt.inSampleSize = sampleSize;
        opt.inPreferredConfig = Bitmap.Config.RGB_565;
        try {
            fis = new FileInputStream(path);
        } catch (IOException ioe) {
            ioe.printStackTrace();
            return null;
        }
        try {
            return BitmapFactory.decodeStream(new BufferedInputStream(fis, 8192), null, opt);
        } catch (OutOfMemoryError err) {
            Logger.g().e(LOG_TAG, "内存占用过大，图片解码失", err);
        } catch (Throwable e) {
            Logger.g().e(LOG_TAG, "decode bitmap failed", e);
        }
        return null;
    }

    private int getErrorCode(Throwable e) {
        if (e instanceof ImageHashError) {
            return ((ImageHashError) e).errCode;
        }
        return ImageHashError.ERROR_UNKNOWN;
    }

    private static class ProbeResultHolder {
        static final int TYPE_PROBE_PROGRESS = 1; // type == 1 value is frameNo
        static final int TYPE_PROBE_RESULT = 2; // type == 2 value is probe result
        static final String SOURCE_HW = "hw";
        static final String SOURCE_SW = "sw";
        String source;
        int type;
        int value;
        long timeCost;
        long avgDecFrameCost;
    }

    private File getProbeResultFile(String profile) {
        return new File(mResDir + File.separator + profile + "_pr.txt");
    }

    private static void writeStringAsFile(final String fileContents, File f) {
        try {
            FileWriter out = new FileWriter(f);
            out.write(fileContents);
            out.close();
        } catch (IOException e) {
            Logger.g().w( LOG_TAG, "error writing file " + f.getAbsolutePath(), e);
        }
    }

    private static String readFileAsString(File f) {
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        BufferedReader in = null;

        try {
            in = new BufferedReader(new FileReader(f));
            while ((line = in.readLine()) != null) stringBuilder.append(line);

        } catch (FileNotFoundException e) {
            Logger.g().w( LOG_TAG, "read file no such file " + f.getAbsolutePath(), e);
        } catch (IOException e) {
            Logger.g().w( LOG_TAG, "read file io exception " + f.getAbsolutePath(), e);
        }

        return stringBuilder.toString();
    }

    private boolean printFileContentToLog(File file) {
        if (file != null && file.isFile() && file.exists()) {
            String content = readFileAsString(file);
            Logger.g().i( LOG_TAG, file.getName() + ":" + content);
            return true;
        }
        return false;
    }

    private class BitmapHolder {
        String path;
        Bitmap bitmap;
        long phash = 0;
        BitmapFactory.Options opts;
    }

    public interface ProbeResultCallback {
        void onProbeResult(ProbeResult result);
    }

    public static class ProbeResult {
        public String videoProfile;
        public int statusCode;
        public long timeCostTotal;
        public long timeCostHwDecode;
        public long fpsHwDec;
        public long avgHwDecFrameCost;
        public long timeCostSwDecode;
        public long fpsSwDec;
        public long avgSwDecFrameCost;
        public float progress;
    }

    private static class ProbeResultCache {
        Object cachedResult; // 进程内只读取一次sp，缓存结果避免频繁读取，为null代表未读取，否则是个布尔值
    }
}